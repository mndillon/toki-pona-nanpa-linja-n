import type {
  NanpaParserRuntime,
  NanpaReferenceModule,
  SitelenRendererRuntime,
} from "./types.js";

export * from "./types.js";

const REQUIRED_CORE_METHODS = Object.freeze([
  "parseNumber",
  "encodeDecimal",
  "decimalToUcsurCodepoints",
  "properNameToUcsurCodepoints",
  "splitCapsToProperName",
  "capsToUniqueCode",
  "decodeCaps",
  "parseIdentifier",
  "capsToWords",
  "capsToCodepoints",
  "codepointsToWords",
] as const);

export class NanpaRuntimeError extends Error {
  override name = "NanpaRuntimeError";
}

/**
 * Runtime validation for the canonical JavaScript NanpaParser object.
 * This does not reinterpret or duplicate any nanpa-linja-n parsing logic.
 */
export function assertNanpaParserRuntime(value: unknown): asserts value is NanpaParserRuntime {
  if (value == null || (typeof value !== "object" && typeof value !== "function")) {
    throw new NanpaRuntimeError("NanpaParser runtime is missing or is not an object.");
  }

  const candidate = value as Record<string, unknown>;
  const missing = REQUIRED_CORE_METHODS.filter((name) => typeof candidate[name] !== "function");
  if (missing.length > 0) {
    throw new NanpaRuntimeError(
      `NanpaParser runtime is missing required method${missing.length === 1 ? "" : "s"}: ${missing.join(", ")}`,
    );
  }
}

/**
 * Returns a typed, method-safe façade over the canonical JavaScript runtime.
 *
 * JavaScript methods such as decimalToUcsurCodepoints use `this.parseNumber`.
 * Every function is therefore bound back to the original runtime so that
 * destructuring a method cannot accidentally change its behaviour.
 *
 * The façade deliberately uses a fresh proxy target rather than proxying the
 * runtime object itself. The canonical NanpaParser may be frozen, which makes
 * its methods non-configurable/non-writable. ECMAScript proxy invariants forbid
 * a `get` trap from returning a bound function in place of such a property when
 * the frozen object is the proxy target. Using an independent target preserves
 * the runtime unchanged and avoids that invariant violation.
 */
export function bindNanpaParser(runtime: NanpaParserRuntime): NanpaParserRuntime {
  assertNanpaParserRuntime(runtime);
  const bound = new Map<PropertyKey, Function>();
  const facadeTarget = Object.create(null) as Record<PropertyKey, unknown>;

  return new Proxy(facadeTarget, {
    get(_target, property) {
      const value = Reflect.get(runtime as object, property, runtime as object);
      if (typeof value !== "function") return value;

      const existing = bound.get(property);
      if (existing) return existing;

      const fn = value.bind(runtime);
      bound.set(property, fn);
      return fn;
    },
    has(_target, property) {
      return property in (runtime as object);
    },
    ownKeys() {
      return Reflect.ownKeys(runtime as object);
    },
    getOwnPropertyDescriptor(_target, property) {
      const descriptor = Reflect.getOwnPropertyDescriptor(runtime as object, property);
      if (!descriptor) return undefined;
      // Descriptors reported for a proxy target must be compatible with that
      // target. Make the façade properties configurable while preserving the
      // observable enumerability/writability shape where practical.
      return {
        configurable: true,
        enumerable: descriptor.enumerable ?? false,
        writable: "writable" in descriptor ? descriptor.writable ?? false : false,
        value: Reflect.get(runtime as object, property, runtime as object),
      };
    },
  }) as unknown as NanpaParserRuntime;
}

export function parserFromModule(module: NanpaReferenceModule): NanpaParserRuntime {
  const defaultExport = module.default;
  const parser =
    module.NanpaParser ??
    module.SitelenRenderer?.NanpaParser ??
    (defaultExport && typeof defaultExport === "object" ? defaultExport.NanpaParser : undefined);

  assertNanpaParserRuntime(parser);
  return bindNanpaParser(parser);
}

/** Load the canonical JavaScript reference module and expose it with TypeScript types. */
export async function importNanpaParser(moduleSpecifier: string | URL): Promise<NanpaParserRuntime> {
  const specifier = moduleSpecifier instanceof URL ? moduleSpecifier.href : moduleSpecifier;
  const module = (await import(specifier)) as NanpaReferenceModule;
  return parserFromModule(module);
}

/** Obtain a reference runtime that has already been loaded as a browser global. */
export function getGlobalNanpaParser(): NanpaParserRuntime {
  const globals = globalThis as typeof globalThis & {
    NanpaParser?: NanpaParserRuntime;
    SitelenRenderer?: SitelenRendererRuntime;
  };

  const parser = globals.NanpaParser ?? globals.SitelenRenderer?.NanpaParser;
  assertNanpaParserRuntime(parser);
  return bindNanpaParser(parser);
}

/** Narrow a runtime SitelenRenderer object without altering it. */
export function assertSitelenRendererRuntime(value: unknown): asserts value is SitelenRendererRuntime {
  if (value == null || typeof value !== "object") {
    throw new NanpaRuntimeError("SitelenRenderer runtime is missing or is not an object.");
  }
  const candidate = value as Record<string, unknown>;
  if (typeof candidate.create !== "function") {
    throw new NanpaRuntimeError("SitelenRenderer runtime is missing required method: create");
  }
  assertNanpaParserRuntime(candidate.NanpaParser);
}
