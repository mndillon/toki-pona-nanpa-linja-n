export type NumericMode = "uniform" | "traditional";

export type DecimalSemanticStartGlyph = "nanpa" | "tenpo" | "suno" | "toki";
export type NumericStartGlyph = DecimalSemanticStartGlyph | "nasa" | "noka" | (string & {});
export type SemanticKind = "time" | "date" | (string & {});

/**
 * Options accepted by the canonical JavaScript NanpaParser.
 *
 * Known options are typed explicitly. The index signature is intentional:
 * the JavaScript reference implementation has accumulated compatibility and
 * renderer options over time, and the TypeScript facade must not reject a
 * valid future/reference-runtime option merely because its declaration has
 * not yet been updated.
 */
export interface NanpaParserOptions {
  mode?: NumericMode;
  numericMode?: NumericMode;
  mixedStyle?: "short" | "long" | (string & {});

  relaxedNanpaLinjanParsing?: boolean;
  relaxedNanpaLinjanRendering?: boolean;
  nanpaColonParsing?: boolean;
  nanpaColonRendering?: boolean;
  enableHexParsing?: boolean;
  enableBinaryParsing?: boolean;
  enableBinaryRendering?: boolean;
  numericCartoucheStartGlyph?: NumericStartGlyph;

  thousandsChar?: string;
  groupFractionTriplets?: boolean;
  fractionGroupSize?: number;

  intEneSep?: string;
  intGroupSep?: string;
  fracEneSep?: string;
  fracGroupSep?: string;

  abbreviateNumericCartouches?: boolean;
  numericCartoucheAbbreviation?: boolean;
  abbreviatedNumericCartouches?: boolean;
  preserveNumericCartoucheBreaksInAbbreviation?: boolean;

  [key: string]: unknown;
}

export interface SplitCapsToProperNameOptions {
  titleCase?: boolean;
  relaxedNanpaLinjanParsing?: boolean;
  relaxedNanpaLinjanRendering?: boolean;
  nanpaColonRendering?: boolean;
}

export interface NanpaIdentifierResult {
  input: string;
  innerCodepoints: number[];
  codepoints: number[];
  words: string[];
  numericMode: NumericMode;
}

export interface NanpaCapsCodepointsResult {
  innerCodepoints: number[];
  codepoints: number[];
  words: string[];
  numericMode: NumericMode;
  isTimeLike: boolean;
}

export interface NanpaParseResult {
  input: string;
  caps: string | null;
  properName: string | null;
  uniqueCode: string;

  ucsurCodepoints: number[];
  hexCodepoints: string;
  hexWithCartouche: string;
  tpWords: string[];
  words: string[];
  displayValue: string;

  isTime: boolean;
  isDate: boolean;
  semanticKind?: SemanticKind | null;
  semanticStartGlyph?: NumericStartGlyph | null;
  isTimeLike: boolean;

  innerCodepoints: number[];
  codepoints: number[];
  numericMode: NumericMode;

  /** Hexadecimal/binary structured results. */
  kind?: "hex" | "binary" | (string & {});
  numberBase?: 2 | 16 | number;
  isHex?: boolean;
  isBinary?: boolean;
  hexDigits?: string;
  binaryDigits?: string;
  hexParts?: unknown[];
  binaryParts?: unknown[];
  abbreviatedUcsurCodepoints?: number[];
  abbreviatedWords?: string[];

  /** Permit reference-runtime extensions without weakening known fields. */
  [key: string]: unknown;
}

export interface NanpaParserRuntime {
  parseNumber(input: unknown, opts?: NanpaParserOptions): NanpaParseResult | null;
  encodeDecimal(input: unknown, opts?: NanpaParserOptions): string | null;
  decimalToUcsurCodepoints(input: unknown, opts?: NanpaParserOptions): number[];
  properNameToUcsurCodepoints(input: unknown, opts?: NanpaParserOptions): number[];
  splitCapsToProperName(caps: string, opts?: SplitCapsToProperNameOptions): string;
  capsToUniqueCode(caps: string, opts?: NanpaParserOptions): string;

  decodeCaps(caps: string, opts?: NanpaParserOptions): string | null;

  ucsurCodepointsToTpWords(codepoints: Iterable<number>): string[];
  codepointsToWords(codepoints: Iterable<number>): string[];
  tpWordsToText(words: Iterable<string>): string;
  parseTpWordsToCodepoints(input: unknown): number[];
  tpWordsToUcsurCodepoints(words: Iterable<string>): number[];

  codepointsToHex(codepoints: Iterable<number>): string;
  codepointsToHexWithCartouche(codepoints: Iterable<number>): string;
  parseHexCodepoints(input: unknown): number[];
  withCartoucheMarkers(codepoints: Iterable<number>): number[];
  stripCartoucheMarkers(codepoints: Iterable<number>): number[];

  isValidCaps(input: unknown): boolean;
  isValidProperName(input: unknown, opts?: NanpaParserOptions): boolean;
  isValidTimeOrDate(caps: string, opts?: NanpaParserOptions): boolean;
  isValidTime?(caps: string, opts?: NanpaParserOptions): boolean;
  isValidDate?(caps: string, opts?: NanpaParserOptions): boolean;

  tokenizeCaps(caps: string, opts?: NanpaParserOptions): string[];
  capsTokensToTpWords(tokens: Iterable<string>, opts?: NanpaParserOptions): string[];
  capsToWords(caps: string, opts?: NanpaParserOptions): string[];
  capsToCodepoints(caps: string, opts?: NanpaParserOptions): NanpaCapsCodepointsResult | null;
  parseIdentifier(input: unknown, opts?: NanpaParserOptions): NanpaIdentifierResult | null;

  normalizeVulgarFraction(input: unknown): string | null;
  normalizeTpWord(input: unknown): string;

  getSmallCodepointsSet(): Set<number>;
  getQuarterCodepointsSet(): Set<number>;
  getOneThirdCodepointsSet(): Set<number>;
  getTwoThirdsCodepointsSet(): Set<number>;
  getHalfCodepointsSet(): Set<number>;
  isAllowedTpUcsurCodepoint(codepoint: number): boolean;

  [key: string]: unknown;
}

export interface SitelenRendererRuntime {
  NanpaParser: NanpaParserRuntime;
  create(config?: Record<string, unknown>): Promise<unknown>;
  registerRenderAdapter?(id: string, adapter: unknown): unknown;
  unregisterRenderAdapter?(id: string): unknown;
  hasRenderAdapter?(id: string): boolean;
  getDefaultRenderAdapterId?(): string;
  [key: string]: unknown;
}

export interface NanpaReferenceModule {
  NanpaParser?: NanpaParserRuntime;
  SitelenRenderer?: SitelenRendererRuntime;
  default?: SitelenRendererRuntime | { NanpaParser?: NanpaParserRuntime };
  [key: string]: unknown;
}
