import assert from "node:assert/strict";
import {
  bindNanpaParser,
  assertNanpaParserRuntime,
  NanpaRuntimeError,
} from "../dist/index.js";

function makeRuntime() {
  return {
    parseNumber(input) { return input === "ok" ? { input: "ok" } : null; },
    encodeDecimal(input) { return `caps:${input}`; },
    decimalToUcsurCodepoints(input) { return this.parseNumber(input) ? [1, 2, 3] : []; },
    properNameToUcsurCodepoints() { return [4]; },
    splitCapsToProperName(caps) { return caps.toLowerCase(); },
    capsToUniqueCode(caps) { return `#~${caps}`; },
    decodeCaps(caps) { return caps; },
    parseIdentifier() { return null; },
    capsToWords() { return []; },
    capsToCodepoints() { return null; },
    codepointsToWords() { return []; },
  };
}

for (const runtime of [makeRuntime(), Object.freeze(makeRuntime())]) {
  assert.doesNotThrow(() => assertNanpaParserRuntime(runtime));
  const parser = bindNanpaParser(runtime);
  assert.deepEqual(parser.parseNumber("ok"), { input: "ok" });
  const detached = parser.decimalToUcsurCodepoints;
  assert.deepEqual(detached("ok"), [1, 2, 3]);
  assert.deepEqual(detached("no"), []);
  assert.equal(parser.encodeDecimal("7"), "caps:7");
  assert.equal("parseNumber" in parser, true);
  assert.equal(Object.keys(parser).includes("parseNumber"), true);
}

assert.throws(
  () => assertNanpaParserRuntime({ parseNumber() {} }),
  (err) => err instanceof NanpaRuntimeError && /missing required method/.test(err.message),
);

console.log("facade frozen-runtime tests: PASS");
