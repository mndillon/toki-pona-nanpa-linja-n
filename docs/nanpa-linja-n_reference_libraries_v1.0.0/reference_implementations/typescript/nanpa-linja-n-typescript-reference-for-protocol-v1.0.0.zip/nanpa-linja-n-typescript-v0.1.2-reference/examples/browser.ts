import { getGlobalNanpaParser } from "../src/index.js";

// Load the canonical renderer JavaScript in the page first. It publishes
// window.NanpaParser / window.SitelenRenderer, then this wrapper supplies types.
const parser = getGlobalNanpaParser();
const time = parser.parseNumber("12:30", {
  numericMode: "uniform",
  nanpaColonParsing: true,
  nanpaColonRendering: true,
});

console.log(time?.properName);
