import { importNanpaParser } from "../src/index.js";

// Point this at the canonical JavaScript reference implementation.
const parser = await importNanpaParser(
  new URL("../vendor/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js", import.meta.url),
);

const parsed = parser.parseNumber("2026-09-13", {
  numericMode: "uniform",
  relaxedNanpaLinjanParsing: true,
  relaxedNanpaLinjanRendering: true,
  nanpaColonParsing: true,
  nanpaColonRendering: true,
});

if (!parsed) throw new Error("Unexpected parse failure");
console.log(parsed.properName, parsed.tpWords, parsed.ucsurCodepoints);
