# v0.1.8

- Requires exactly 8 full + 8 abbreviated SVG cases.
- Requires every abbreviated `-abbr` case to have a matching full case.
- Requires artifact count = production font-pair count × 16.
- Current expected total: 128 SVG artifacts (64 full + 64 abbreviated).
- A 64-artifact SVG run is now a hard failure rather than a false PASS.

# Changelog

## 0.1.7

- Expand the production SVG golden matrix from 8 to 16 cases per vector-enabled font pair: every existing case now has a matching `-abbr` case with `abbreviateNumericCartouches: true`.
- Preserve numeric cartouche breaks in abbreviated golden cases with `preserveNumericCartoucheBreaksInAbbreviation: true`.
- Apply the abbreviation flags per golden case instead of reusing one full-cartouche parser configuration for all SVG exports.
- Add a runtime regression guard for every abbreviated case: build the corresponding full render plan and require the abbreviated cartouche to be present, different from the full cartouche, and shorter.
- With the current eight production font pairs, the approved SVG baseline grows from 64 to 128 artifacts.
- Existing full-cartouche golden IDs and cases are retained unchanged; no parser, renderer, font-controller, vector-exporter, font, or production-manifest behavior is modified.

## 0.1.6

- Fix real vector-WASM initialization in the embedded browser harness.
- The browser runner now embeds `sitelen_vector_wasm_bg.wasm` as bytes, imports the wasm-bindgen JS wrapper, calls its default initializer with those bytes, and only then permits `healthcheck()` / vector export calls.
- This fixes the prior `TypeError: Cannot read properties of undefined (reading '__wbindgen_free')` produced when `healthcheck()` was called before wasm-bindgen initialization.
- The same initialized Blob-module URL remains the URL supplied to `SitelenVectorExporter`; repeated `default()` calls are safe because the generated wrapper returns the already initialized WASM instance.
- Fix the browser-font canvas probe to use the renderer's documented `{ canvas, ast, linesElements }` return object from `renderTextToNewCanvas()` instead of incorrectly treating that wrapper as a bare canvas.
- No parser, renderer, font-controller, vector-exporter, production manifest, font, or expected-output behavior changed.

## 0.1.5

- Correct legacy adapter font-conformance handling and add browser render-adapter probes.
