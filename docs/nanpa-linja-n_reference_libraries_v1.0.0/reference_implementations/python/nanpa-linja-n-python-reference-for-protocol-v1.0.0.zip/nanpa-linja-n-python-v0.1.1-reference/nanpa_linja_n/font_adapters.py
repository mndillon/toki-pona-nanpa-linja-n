"""Numeric-cartouche render adapters used by the Python font regression layer.

The canonical parser output is UCSUR.  Most production companion fonts consume
that stream directly.  ``linja pona`` and ``linja sike`` are legacy ASCII
ligature fonts; for numeric cartouches the production renderer converts each
canonical cell to ``[_word_word...]`` syntax.  This module implements that
numeric-cartouche subset, which is exactly what the 128 full/abbreviated font golden cases need.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, Sequence

from . import number_glyph_renderer as legacy

CARTOUCHE_START = 0xF1990
CARTOUCHE_END = 0xF1991
COLON = 0xF199D
LEGACY_ASCII_ADAPTERS = {"linja-pona-legacy-v1", "linja-sike-legacy-v1"}

# Build an unambiguous canonical codepoint -> Toki Pona name table from the
# source map. Aliases added later to WORDS_TO_UNC_CODES_MAP do not replace the
# canonical names here.
_CP_TO_WORD: Dict[int, str] = {}
for hex_cp, word in getattr(legacy, "UNC_CODES_TO_WORDS_MAP", {}).items():
    try:
        _CP_TO_WORD[int(hex_cp, 16)] = str(word).lower()
    except Exception:
        pass
_CP_TO_WORD[COLON] = ":"


@dataclass(frozen=True)
class AdaptedRun:
    text: str
    adapter_id: str
    canonical_codepoints: tuple[int, ...]
    legacy_ascii: bool


def _legacy_numeric_cartouche(cps: Sequence[int], adapter_id: str) -> str:
    values = [int(cp) for cp in cps]
    if len(values) < 2 or values[0] != CARTOUCHE_START or values[-1] != CARTOUCHE_END:
        raise ValueError(f"{adapter_id}: numeric regression input is not a complete canonical cartouche")
    parts = ["["]
    for cp in values[1:-1]:
        word = _CP_TO_WORD.get(cp)
        if word is None:
            raise ValueError(f"{adapter_id}: no legacy numeric encoding for U+{cp:04X}")
        parts.append("_")
        parts.append(word)
    parts.append("]")
    return "".join(parts)


def adapt_numeric_cartouche(codepoints: Iterable[int], render_adapter_id: str = "identity", settings: Dict[str, Any] | None = None) -> AdaptedRun:
    cps = tuple(int(cp) for cp in codepoints)
    adapter_id = str(render_adapter_id or "identity").strip() or "identity"
    if adapter_id in LEGACY_ASCII_ADAPTERS:
        text = _legacy_numeric_cartouche(cps, adapter_id)
        return AdaptedRun(text=text, adapter_id=adapter_id, canonical_codepoints=cps, legacy_ascii=True)
    # The remaining production adapters accept canonical UCSUR numeric
    # cartouches directly. Their special translations concern ordinary text,
    # unsupported punctuation/compounds or long-glyph structures rather than
    # these numeric golden cases.
    return AdaptedRun(
        text="".join(chr(cp) for cp in cps),
        adapter_id=adapter_id,
        canonical_codepoints=cps,
        legacy_ascii=False,
    )
