"""Production font-manifest loading for the Python regression/rendering layer.

The loader intentionally consumes the same ``fonts/preloaded-font-pairs.manifest.json``
format used by the JavaScript application.  It does not invent a Python-only font
configuration format.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional
import json


DEFAULT_MANIFEST = Path("fonts/preloaded-font-pairs.manifest.json")


@dataclass(frozen=True)
class FontFaceSpec:
    role: str
    family: str
    path: Path
    format: str
    sample: str = ""
    sha256: Optional[str] = None


@dataclass(frozen=True)
class FontPairSpec:
    font_key: str
    label: str
    rev: str
    parser_mode: str
    render_adapter_id: str
    render_adapter_settings: Dict[str, Any]
    settings: Dict[str, Any]
    support: Dict[str, Any]
    faces: tuple[FontFaceSpec, ...]
    raw: Dict[str, Any]

    def face(self, role: str) -> Optional[FontFaceSpec]:
        return next((face for face in self.faces if face.role == role), None)

    @property
    def base(self) -> FontFaceSpec:
        face = self.face("base")
        if face is None:
            raise KeyError(f"{self.font_key}: no base face")
        return face

    @property
    def companion(self) -> FontFaceSpec:
        face = self.face("companion")
        if face is None:
            raise KeyError(f"{self.font_key}: no companion face")
        return face

    @property
    def literal_cartouche(self) -> Optional[FontFaceSpec]:
        return self.face("literalCartouche")


@dataclass(frozen=True)
class FontManifest:
    path: Path
    schema: int
    generated: str
    pairs: tuple[FontPairSpec, ...]
    raw: Dict[str, Any]


def _without_query_hash(value: Any) -> str:
    text = str(value or "").strip().replace("\\", "/")
    for sep in ("?", "#"):
        if sep in text:
            text = text.split(sep, 1)[0]
    return text


def _normalise_format(value: Any, filename: str = "") -> str:
    raw = str(value or "").strip().lower()
    if raw in {"otf", "opentype"}:
        return "opentype"
    if raw in {"ttf", "truetype"}:
        return "truetype"
    if raw in {"woff", "woff2"}:
        return raw
    lower = filename.lower()
    if lower.endswith(".otf"):
        return "opentype"
    if lower.endswith(".woff2"):
        return "woff2"
    if lower.endswith(".woff"):
        return "woff"
    return "truetype"


def resolve_asset_path(project_root: Path, manifest_path: Path, raw_url: Any, filename_hint: Any = "") -> Path:
    """Resolve a production manifest font URL without permitting network assets."""
    root = Path(project_root).resolve()
    manifest_dir = Path(manifest_path).resolve().parent
    raw = _without_query_hash(raw_url)
    hint = _without_query_hash(filename_hint)
    if raw and ":" in raw.split("/", 1)[0] and not raw.startswith("file:"):
        raise ValueError(f"Network/data URL is not allowed in offline regression assets: {raw}")

    candidates: List[Path] = []
    def add(path: Optional[Path]) -> None:
        if path is not None and path not in candidates:
            candidates.append(path)

    stripped = raw.lstrip("./").lstrip("/")
    if stripped.startswith("fonts/"):
        add(root / stripped)
    if stripped.startswith("assets/"):
        add(root / stripped)
    if raw and not Path(raw).is_absolute():
        add((manifest_dir / raw).resolve())
    base = Path(hint).name if hint else (Path(stripped).name if stripped else "")
    if base:
        add(root / "fonts" / base)
        add(manifest_dir / base)
        # Also accept the JS regression-suite layout when the Python suite is
        # pointed directly at that manifest.
        add(root / "assets" / "fonts" / base)

    for candidate in candidates:
        if candidate.exists():
            return candidate
    if not candidates:
        raise ValueError(f"No local path can be resolved for {raw_url!r} / {filename_hint!r}")
    return candidates[0]


def _sha_field(pair: Dict[str, Any], prefix: str) -> Optional[str]:
    return pair.get(prefix + "Sha256") or pair.get(prefix + "SHA256") or None


def _faces_for_pair(root: Path, manifest_path: Path, pair: Dict[str, Any]) -> tuple[FontFaceSpec, ...]:
    defs = [
        (
            "base",
            pair.get("baseFamily") or pair.get("textFamily") or pair.get("fontKey") or "",
            pair.get("baseUrl"), pair.get("baseFilename"), pair.get("baseFormat"), pair.get("baseSample"),
            _sha_field(pair, "base"),
        ),
        (
            "companion",
            pair.get("companionFamily") or pair.get("cartoucheFamily") or f"{pair.get('fontKey','')}-nanpa-linja-n",
            pair.get("companionUrl"), pair.get("companionFilename"), pair.get("companionFormat"), pair.get("companionSample"),
            _sha_field(pair, "companion"),
        ),
    ]
    literal_url = pair.get("literalCartoucheUrl") or pair.get("literalCartoucheFontUrl") or ""
    literal_filename = pair.get("literalCartoucheFilename") or pair.get("literalCartoucheFileName") or ""
    if literal_url or literal_filename:
        defs.append((
            "literalCartouche",
            pair.get("literalCartoucheFamily") or pair.get("literalCartoucheFontFamily") or pair.get("baseFamily") or pair.get("fontKey") or "",
            literal_url, literal_filename, pair.get("literalCartoucheFormat"), pair.get("literalCartoucheSample"),
            _sha_field(pair, "literalCartouche"),
        ))
    out = []
    for role, family, url, filename, fmt, sample, sha in defs:
        path = resolve_asset_path(root, manifest_path, url, filename)
        out.append(FontFaceSpec(
            role=role,
            family=str(family or ""),
            path=path,
            format=_normalise_format(fmt, str(filename or url or "")),
            sample=str(sample or ""),
            sha256=str(sha) if sha else None,
        ))
    return tuple(out)


def load_font_manifest(project_root: Path | str = ".", manifest_path: Path | str | None = None, *, required: bool = True) -> Optional[FontManifest]:
    root = Path(project_root).resolve()
    mp = Path(manifest_path) if manifest_path is not None else root / DEFAULT_MANIFEST
    if not mp.is_absolute():
        mp = root / mp
    mp = mp.resolve()
    if not mp.exists():
        if required:
            raise FileNotFoundError(f"Production font manifest not found: {mp}")
        return None
    raw = json.loads(mp.read_text(encoding="utf-8"))
    if not isinstance(raw.get("pairs"), list):
        raise ValueError("manifest.pairs must be an array")
    pairs: List[FontPairSpec] = []
    seen = set()
    for pair in raw["pairs"]:
        key = str(pair.get("fontKey") or "").strip()
        if not key:
            raise ValueError("manifest pair is missing fontKey")
        if key in seen:
            raise ValueError(f"duplicate manifest fontKey: {key}")
        seen.add(key)
        pairs.append(FontPairSpec(
            font_key=key,
            label=str(pair.get("label") or key),
            rev=str(pair.get("rev") or ""),
            parser_mode=str(pair.get("parserMode") or ""),
            render_adapter_id=str(pair.get("renderAdapterId") or "identity").strip() or "identity",
            render_adapter_settings=dict(pair.get("renderAdapterSettings") or {}),
            settings=dict(pair.get("settings") or {}),
            support=dict(pair.get("support") or {}),
            faces=_faces_for_pair(root, mp, pair),
            raw=dict(pair),
        ))
    return FontManifest(
        path=mp,
        schema=int(raw.get("schema") or 0),
        generated=str(raw.get("generated") or ""),
        pairs=tuple(pairs),
        raw=raw,
    )
