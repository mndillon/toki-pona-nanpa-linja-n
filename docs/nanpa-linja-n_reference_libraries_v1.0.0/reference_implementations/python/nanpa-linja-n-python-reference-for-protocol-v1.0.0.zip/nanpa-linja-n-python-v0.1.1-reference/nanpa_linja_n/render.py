"""Semantic-aware Pillow rendering helpers for current nanpa-linja-n output.

These helpers obtain the exact numeric cartouche codepoint stream from the
current Python NanpaParser implementation, then give that complete stream to
Pillow/OpenType in one shaping call.  They are intended for UCSUR-capable
companion fonts.  Legacy ASCII-adapter fonts require their native adapter port.
"""
from __future__ import annotations
from typing import Any, Dict, Optional, Tuple
from PIL import Image, ImageFont

from .parser import NanpaParser
from . import number_glyph_renderer as _legacy


def encode_numeric_cartouche_ucsur(value: Any, opts: Optional[Dict[str, Any]] = None, *, include_cartouche_controls: bool = True) -> str:
    parsed = NanpaParser.parseNumber(value, dict(opts or {}))
    if parsed is None:
        raise ValueError(f"Not a valid nanpa-linja-n numeric input: {value!r}")
    cps = parsed["codepoints"] if include_cartouche_controls else parsed["innerCodepoints"]
    return "".join(chr(int(cp)) for cp in cps)


def render_numeric_cartouche_to_new_base(
    value: Any,
    *,
    font: ImageFont.FreeTypeFont,
    opts: Optional[Dict[str, Any]] = None,
    outer_padding: int = 0,
    fg: Tuple[int, int, int, int] = (0, 0, 0, 255),
    background: Tuple[int, int, int, int] = (0, 0, 0, 0),
) -> Image.Image:
    stream = encode_numeric_cartouche_ucsur(value, opts, include_cartouche_controls=True)
    return _legacy.render_shaped_ucsur_run_to_new_base(
        stream,
        font=font,
        outer_padding=outer_padding,
        fg=fg,
        background=background,
        features=_legacy.numeric_cartouche_opentype_features_for_font(font),
    )
