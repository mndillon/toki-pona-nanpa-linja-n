# Production fonts for Python regression

Copy the **same production font directory** used by the JavaScript regression suite here.
The directory must contain `preloaded-font-pairs.manifest.json` alongside the font files.

For example, from the JavaScript suite:

```bash
cp -a ../nanpa-linja-n-browser-font-regression-v0.1.3/assets/fonts/. ./fonts/
```

The Python suite reads the production manifest directly. No Python-only font manifest is used.
Font binaries are deliberately not bundled in this package.
