# Changelog

## 0.1.3

- Fixed migration of the approved Python 64-full-cartouche golden baseline to the 128-artifact full+abbreviated matrix.
- Legacy v0.1.1 records without `abbreviateNumericCartouches` are explicitly treated as full-cartouche records.
- Added metadata fallback matching by `fontKey` + `caseId` and baseline/current overlap diagnostics.
- Added `python scripts/font_goldens.py --extend`, which verifies and preserves all existing approved full goldens and adds only missing abbreviated goldens.
- `--extend` refuses to overwrite an approved full artifact if its hash, dimensions, companion hash, or adapter changed.

## 0.1.2

- Expanded Python font visual regression to 128 artifacts: 64 full + 64 abbreviated.
