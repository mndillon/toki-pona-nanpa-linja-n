Python step 5: corpus reference-name synchronization

This overlay changes only tests/nanpa-linja-n-regression-v1.0.2.json.
It makes suite.referenceImplementation use the canonical renderer filename:
renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js

No parser, renderer, API, font, or golden behavior is changed.
