import unittest
from nanpa_linja_n import NanpaParser

OPTS={
    'mode':'uniform','mixedStyle':'short',
    'relaxedNanpaLinjanParsing':True,'relaxedNanpaLinjanRendering':True,
    'nanpaColonParsing':True,'nanpaColonRendering':True,
    'enableHexParsing':True,'enableBinaryParsing':True,
}

class SmokeTests(unittest.TestCase):
    def test_time_head(self):
        r=NanpaParser.parseNumber('12:30',OPTS)
        self.assertEqual(r['semanticKind'],'time')
        self.assertEqual(r['tpWords'][0],'tenpo')

    def test_yearless_date(self):
        r=NanpaParser.parseNumber('--02-29',OPTS)
        self.assertTrue(r['isDate'])
        self.assertEqual(r['displayValue'],'--02-29')
        self.assertEqual(r['tpWords'][0],'suno')

    def test_grouped_number_has_no_telephone_type(self):
        r=NanpaParser.parseNumber('+1-234-555-6789',OPTS)
        self.assertIsNotNone(r)
        self.assertIsNone(r['semanticKind'])
        self.assertIsNone(r['semanticStartGlyph'])
        self.assertEqual(r['tpWords'][0],'nanpa')
        self.assertNotIn('isTelephone',r)

    def test_suno_day(self):
        r=NanpaParser.parseNumber('Suno Wan',OPTS)
        self.assertEqual(r['semanticStartGlyph'],'suno')
        self.assertFalse(r['isDate'])
        self.assertEqual(r['displayValue'],'1')

    def test_toki_explicit(self):
        r=NanpaParser.parseNumber('Toki Newan Ene Tusenan Ene Lululun Ene Numupijon',OPTS)
        self.assertEqual(r['semanticStartGlyph'],'toki')
        self.assertEqual(r['tpWords'][0],'toki')
        self.assertNotIn('isTelephone',r)

    def test_hex_binary_closers(self):
        h=NanpaParser.parseNumber('#A5',OPTS)
        b=NanpaParser.parseNumber('0b10101',OPTS)
        self.assertEqual((h['tpWords'][0],h['tpWords'][-1]),('nasa','nasa'))
        self.assertEqual((b['tpWords'][0],b['tpWords'][-1]),('noka','noka'))

if __name__=='__main__': unittest.main()
