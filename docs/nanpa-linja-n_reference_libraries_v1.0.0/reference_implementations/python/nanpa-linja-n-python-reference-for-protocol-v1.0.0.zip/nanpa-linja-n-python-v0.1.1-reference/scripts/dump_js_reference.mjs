#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
const [referenceArg, corpusArg, outputArg] = process.argv.slice(2);
if (!referenceArg || !corpusArg || !outputArg) {
  console.error('Usage: node dump_js_reference.mjs <reference-js> <corpus-json> <output-json>');
  process.exit(2);
}
const mod = await import(pathToFileURL(path.resolve(referenceArg)));
const parser = mod.NanpaParser ?? mod.default?.NanpaParser ?? mod.SitelenRenderer?.NanpaParser;
if (!parser) throw new Error('Reference module does not export NanpaParser.');
const corpus = JSON.parse(fs.readFileSync(path.resolve(corpusArg), 'utf8'));
const out = { parserCases: {}, otherCases: {} };
for (const t of corpus.parserCases ?? []) out.parserCases[t.id] = parser[t.api ?? 'parseNumber'](t.input, t.options ?? {});
for (const t of [...(corpus.rendererCases ?? []), ...(corpus.apiCases ?? [])]) out.otherCases[t.id] = parser[t.api](t.input, t.options ?? {});
fs.writeFileSync(path.resolve(outputArg), JSON.stringify(out));
