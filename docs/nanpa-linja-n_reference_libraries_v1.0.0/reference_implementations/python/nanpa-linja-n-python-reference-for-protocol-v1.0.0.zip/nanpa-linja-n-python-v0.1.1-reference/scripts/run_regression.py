#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from nanpa_linja_n import NanpaParser

CORPUS=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'tests'/'nanpa-linja-n-regression-v1.0.2.json'
corpus=json.loads(CORPUS.read_text())
failures=[]; checks=0

def fail(i,m,a,e): failures.append((i,m,a,e))
def equal(a,b): return a==b
def contains_subsequence(h,n):
    if not isinstance(h,list) or not isinstance(n,list): return False
    return any(h[i:i+len(n)]==n for i in range(len(h)-len(n)+1))
def result_type(r):
    if isinstance(r,list):
        if all(isinstance(v,int) and not isinstance(v,bool) for v in r): return 'array<int>'
        if all(isinstance(v,str) for v in r): return 'array<string>'
        return 'array'
    if r is None:return 'null'
    if isinstance(r,str): return 'string'
    if isinstance(r,bool): return 'boolean'
    if isinstance(r,dict): return 'object'
    return type(r).__name__

def assert_result(i,r,spec):
    global checks
    for k,e in (spec or {}).items():
        if k in {'result','notes','equivalentToInput','equivalentValue','numericDomain'}: continue
        checks += 1
        if k=='accepted':
            a=r is not None
        elif k=='requiredFields':
            a=[x for x in (e or []) if r is None or x not in r]; e=[]
        elif k=='absentFields':
            a=[x for x in (e or []) if r is not None and x in r]; e=[]
        elif k=='properNameStartsWith':
            a=r.get('properName') if isinstance(r,dict) else None
            if not isinstance(a,str) or not a.startswith(e): fail(i,k,a,e)
            continue
        elif k=='tpWordsFirst': a=(r.get('tpWords') or [None])[0] if isinstance(r,dict) else None
        elif k=='tpWordsLast': a=(r.get('tpWords') or [None])[-1] if isinstance(r,dict) else None
        elif k=='tpWordsContainsSubsequence': a=contains_subsequence(r.get('tpWords') if isinstance(r,dict) else None,e); e=True
        elif k=='codepointsFirstInner': a=(r.get('innerCodepoints') or [None])[0] if isinstance(r,dict) else None
        elif k=='codepointsLastInner': a=(r.get('innerCodepoints') or [None])[-1] if isinstance(r,dict) else None
        elif k=='cartoucheStart': a=(r.get('codepoints') or [None])[0] if isinstance(r,dict) else None
        elif k=='cartoucheEnd': a=(r.get('codepoints') or [None])[-1] if isinstance(r,dict) else None
        elif k=='resultType': a=result_type(r)
        elif k=='nonEmpty': a=(len(r)>0 if isinstance(r,(str,list)) else bool(r))
        elif k=='exact': a=r
        else: a=r.get(k) if isinstance(r,dict) else None
        if not equal(a,e): fail(i,k,a,e)

for test in corpus.get('parserCases',[]):
    api=test.get('api','parseNumber'); fn=getattr(NanpaParser,api,None)
    if not callable(fn): checks+=1; fail(test['id'],f'missing API {api}',type(fn).__name__,'function'); continue
    try:r=fn(test['input'],test.get('options',{}))
    except Exception as exc: checks+=1; fail(test['id'],'API threw',repr(exc),'no throw'); continue
    accept=test.get('assert',{}).get('result')=='accept'; checks+=1
    if (r is not None)!=accept: fail(test['id'],'accept/reject','accept' if r is not None else 'reject',test.get('assert',{}).get('result')); continue
    if r is not None: assert_result(test['id'],r,test.get('assert',{}))

for test in corpus.get('rendererCases',[])+corpus.get('apiCases',[]):
    fn=getattr(NanpaParser,test['api'],None); checks+=1
    if not callable(fn): fail(test['id'],f"missing API {test['api']}",type(fn).__name__,'function'); continue
    try:r=fn(test['input'],test.get('options',{}))
    except Exception as exc: fail(test['id'],'API threw',repr(exc),'no throw'); continue
    assert_result(test['id'],r,test.get('assert',{}))

for group in corpus.get('equivalenceGroups',[]):
    api=group.get('api','parseNumber'); fn=getattr(NanpaParser,api,None)
    if not callable(fn): checks+=1; fail(group['id'],f'missing API {api}',type(fn).__name__,'function'); continue
    options=group.get('options',{})
    parsed=[(inp,fn(inp,options)) for inp in group['members']]
    base=parsed[0]
    for field in group.get('compare',[]):
        expected=base[1].get(field) if isinstance(base[1],dict) else None
        for inp,r in parsed[1:]:
            checks+=1; actual=r.get(field) if isinstance(r,dict) else None
            if not equal(actual,expected): fail(group['id'],f'{field}: {base[0]} vs {inp}',actual,expected)

print(f'nanpa-linja-n regression checks: {checks}')
print(f'failures: {len(failures)}')
for i,m,a,e in failures[:120]:
    print(f'\n[{i}] {m}\n  actual:   {json.dumps(a,ensure_ascii=False)}\n  expected: {json.dumps(e,ensure_ascii=False)}',file=sys.stderr)
if len(failures)>120: print(f'\n... {len(failures)-120} more failure(s)',file=sys.stderr)
sys.exit(1 if failures else 0)
