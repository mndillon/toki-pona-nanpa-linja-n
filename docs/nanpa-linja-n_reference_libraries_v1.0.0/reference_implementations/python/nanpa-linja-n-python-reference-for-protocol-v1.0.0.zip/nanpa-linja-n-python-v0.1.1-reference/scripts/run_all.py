#!/usr/bin/env python3
from __future__ import annotations
import subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
commands=[
    [sys.executable, str(ROOT/'scripts/run_regression.py')],
    [sys.executable, '-m', 'unittest', 'discover', '-s', str(ROOT/'tests'), '-p', 'test_*.py'],
]
manifest=ROOT/'fonts/preloaded-font-pairs.manifest.json'
if manifest.exists():
    commands.append([sys.executable, str(ROOT/'scripts/run_font_regression.py')])
else:
    print(f'font regression: SKIP ({manifest.relative_to(ROOT)} not found)')
for cmd in commands:
    print('+', ' '.join(map(str,cmd)), flush=True)
    result=subprocess.run(cmd,cwd=ROOT)
    if result.returncode:
        raise SystemExit(result.returncode)
print('ALL CONFIGURED PYTHON TESTS PASS')
