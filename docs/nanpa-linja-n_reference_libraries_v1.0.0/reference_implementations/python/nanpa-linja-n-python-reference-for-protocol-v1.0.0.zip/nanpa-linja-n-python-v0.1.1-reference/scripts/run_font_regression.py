#!/usr/bin/env python3
from __future__ import annotations
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from nanpa_linja_n.font_regression import main
raise SystemExit(main(["--root", str(ROOT), "--test-goldens", *sys.argv[1:]]))
