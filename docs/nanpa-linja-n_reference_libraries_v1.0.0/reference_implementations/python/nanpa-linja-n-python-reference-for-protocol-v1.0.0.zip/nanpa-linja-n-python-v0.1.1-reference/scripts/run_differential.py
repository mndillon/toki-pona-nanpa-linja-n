#!/usr/bin/env python3
from __future__ import annotations
import json, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from nanpa_linja_n import NanpaParser
if len(sys.argv)<2:
    print('Usage: python scripts/run_differential.py <canonical-reference.js> [corpus.json]', file=sys.stderr); raise SystemExit(2)
reference=Path(sys.argv[1]).resolve()
corpus_path=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else ROOT/'tests'/'nanpa-linja-n-regression-v1.0.2.json'
corpus=json.loads(corpus_path.read_text())
with tempfile.TemporaryDirectory() as td:
    dump=Path(td)/'js.json'
    subprocess.run(['node',str(ROOT/'scripts'/'dump_js_reference.mjs'),str(reference),str(corpus_path),str(dump)],check=True)
    js=json.loads(dump.read_text())
mis=[]; calls=0
for t in corpus.get('parserCases',[]):
    calls+=1
    py=getattr(NanpaParser,t.get('api','parseNumber'))(t['input'],t.get('options',{})); ref=js['parserCases'][t['id']]
    if py!=ref: mis.append((t['id'],py,ref))
for t in corpus.get('rendererCases',[])+corpus.get('apiCases',[]):
    calls+=1
    py=getattr(NanpaParser,t['api'])(t['input'],t.get('options',{})); ref=js['otherCases'][t['id']]
    if py!=ref: mis.append((t['id'],py,ref))
print(f'differential API invocations: {calls}')
print(f'mismatches: {len(mis)}')
for i,py,ref in mis[:50]:
    print(f'\n[{i}]\nPY: {json.dumps(py,ensure_ascii=False)}\nJS: {json.dumps(ref,ensure_ascii=False)}',file=sys.stderr)
raise SystemExit(1 if mis else 0)
