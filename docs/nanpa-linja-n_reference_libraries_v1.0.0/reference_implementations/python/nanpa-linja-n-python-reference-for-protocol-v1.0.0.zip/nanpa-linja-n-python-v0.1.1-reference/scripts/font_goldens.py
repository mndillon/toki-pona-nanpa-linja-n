#!/usr/bin/env python3
from __future__ import annotations
import argparse, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from nanpa_linja_n.font_regression import update_goldens, extend_goldens, test_goldens
p=argparse.ArgumentParser(); p.add_argument('--update', action='store_true'); p.add_argument('--extend', action='store_true'); a=p.parse_args()
if a.update and a.extend:
    p.error('--update and --extend are mutually exclusive')
raise SystemExit(update_goldens(ROOT) if a.update else extend_goldens(ROOT) if a.extend else test_goldens(ROOT))
