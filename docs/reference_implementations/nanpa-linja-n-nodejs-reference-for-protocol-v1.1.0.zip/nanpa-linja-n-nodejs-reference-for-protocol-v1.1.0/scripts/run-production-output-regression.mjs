#!/usr/bin/env node
import { NanpaLinjaN, SitelenRenderer } from '../src/node.js';

const failures=[]; let checks=0;
function check(cond,msg){checks++;if(!cond)failures.push(msg)}
function pngHeader(bytes){return bytes?.length>=8&&bytes[0]===137&&bytes[1]===80&&bytes[2]===78&&bytes[3]===71}
const TALLY=0xF199E;
const n=await NanpaLinjaN.create();
try{
 const fonts=n.listFonts(); check(fonts.length===8,`expected 8 production fonts, got ${fonts.length}`);
 for(const f of fonts){
  const built=await n.buildRenderPlan('[jan pona,,]',{font:f.key,fontSize:56,paddingPx:18});
  const run=built.plan.lines.flatMap(l=>l.runs).find(r=>r.kind==='cartouche');
  check(!!run,`${f.key}: ordinary cartouche run missing`);
  const manual=Array.isArray(run?.manualTallies)&&run.manualTallies.some(v=>Number(v)>0);
  if(manual){
   check(!run.renderFullCps.includes(TALLY),`${f.key}: manual tally font leaked U+F199E into render run`);
   check(run.manualTallies[1]===2,`${f.key}: expected two manual tallies on owner glyph 1`);
   const group=run.manualTallyLayout?.groups?.[0];
   const owner=run.audioGlyphLayout?.[1];
   check(group?.count===2,`${f.key}: manual tally layout missing two-stroke group`);
   if(group&&owner){
    const groupCenter=(group.bounds.left+group.bounds.right)/2;
    const ownerCenter=owner.x+owner.width/2;
    check(Math.abs(groupCenter-ownerCenter)<0.02,`${f.key}: tally group not centered on owner glyph (${groupCenter} vs ${ownerCenter})`);
   } else check(false,`${f.key}: owner glyph layout missing`);
  }else{
   check(run?.renderFullCps?.filter(cp=>cp===TALLY).length===2,`${f.key}: UCSUR tally font did not keep two U+F199E marks`);
  }
  const png=await n.renderToPng('[jan pona,,]',{font:f.key,fontSize:56,paddingPx:18});
  check(pngHeader(png.bytes),`${f.key}: ordinary-cartouche PNG invalid`);
  check(png.canvas.width>0&&png.canvas.height>0,`${f.key}: ordinary-cartouche canvas empty`);
  const numeric=await n.renderToPng('123.45',{font:f.key,fontSize:56,paddingPx:18,parser:{abbreviateNumericCartouches:false}});
  check(pngHeader(numeric.bytes),`${f.key}: numeric PNG invalid`);
  const abbrev=await n.renderToPng('123.45',{font:f.key,fontSize:56,paddingPx:18,parser:{abbreviateNumericCartouches:true}});
  check(pngHeader(abbrev.bytes),`${f.key}: abbreviated numeric PNG invalid`);
 }

 const proper=await n.buildRenderPlan('Jan',{font:'nasinNanpa'});
 const properRun=proper.plan.lines.flatMap(l=>l.runs).find(r=>r.kind==='cartouche');
 check(!!properRun,'automatic proper-name cartouche missing');
 check(properRun?.cps?.length===3,'automatic proper-name cartouche should contain one glyph per source letter');

 const imageSrc='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAIAAAD91JpzAAAAFElEQVR4nGP8z/D/PwMDAwMjI2MAAA8ABQUB/A1Q1KcAAAAASUVORK5CYII=';
 const imagePlan=await n.buildRenderPlan(`jan img(src='${imageSrc}',w=20,h=10,transparent=false) pona`,{font:'nasinNanpa'});
 check(imagePlan.plan.lines.flatMap(l=>l.runs).some(r=>r.imageAlt!==undefined&&r.kind==='cartouche'&&r.widthPx===20&&r.heightPx===10),'inline image segment did not render at requested size');

 const mixed='mi toki e ni: [jan pona,,] 123.45 "Hello"';
 const mixedPng=await n.renderToPng(mixed,{font:'linjaSike',paint:{halo:{enabled:true,color:'#ffffff',widthPx:4}}});
 check(pngHeader(mixedPng.bytes),'mixed-content PNG invalid');
 const svg=await n.renderToSvg(mixed,{font:'nasinNanpa'});
 check(svg.blob.type.startsWith('image/svg+xml')&&svg.svg.includes('<svg'),'SVG export invalid');
 check((svg.svg.match(/<path\b/g)||[]).length>0,'SVG export did not contain vector path geometry');
 check(!/<image\b/i.test(svg.svg),'SVG export contains raster <image> fallback');
 check(!/data:image\//i.test(svg.svg),'SVG export contains data:image raster fallback');
 const pdf=await n.renderToPdf(mixed,{font:'nasinNanpa'});
 check(new TextDecoder().decode(pdf.bytes.slice(0,8)).startsWith('%PDF-1.'),'PDF export invalid');
 const pdfText=Buffer.from(pdf.bytes).toString('latin1');
 check(!/\/Subtype\s*\/Image\b/.test(pdfText),'PDF export contains raster Image XObject');

 const direct=await n.renderer.renderTextToNewCanvas({input:'[jan pona,,]',layout:{fontPx:56,paddingPx:18},fonts:(await n.buildRenderPlan('[jan pona,,]',{font:'nasinNanpa'})).config.fonts,parser:{mode:'sitelen-pona-ascii-extended',cartoucheCommaTallyMarks:true,cartoucheTallyMode:'manual'}});
 check(direct?.canvas?.width>0&&direct?.canvas?.height>0,'advanced renderTextToNewCanvas failed');
 const ucsur=await n.renderer.renderUcsurToNewCanvas({lines:[[0xF1911,0xF1954]],layout:{fontPx:56,paddingPx:18},fonts:(await n.buildRenderPlan('jan pona',{font:'nasinNanpa'})).config.fonts});
 check(ucsur?.canvas?.width>0&&ucsur?.canvas?.height>0,'advanced renderUcsurToNewCanvas failed');
 const onePlan=await n.buildRenderPlan('[jan pona]',{font:'nasinNanpa'}); const oneRun=onePlan.plan.lines[0].runs[0];
 const oneCanvas=await n.renderer.renderRunToNewCanvas({run:oneRun,supersampleScale:2,downsample:true});
 check(oneCanvas?.width>0&&oneCanvas?.height>0,'advanced renderRunToNewCanvas failed');

 const adapterId='node-regression-identity';
 SitelenRenderer.registerRenderAdapter(adapterId,({canonicalCps})=>({renderCps:canonicalCps.slice()}));
 check(SitelenRenderer.hasRenderAdapter(adapterId),'custom render-adapter registration failed');
 check(SitelenRenderer.unregisterRenderAdapter(adapterId)===true,'custom render-adapter removal failed');
 check(!SitelenRenderer.hasRenderAdapter(adapterId),'custom render adapter remained registered');
} finally { await n.destroy(); }
console.log(`production output checks: ${checks}`);console.log(`failures: ${failures.length}`);if(failures.length){for(const f of failures)console.error(`FAIL ${f}`);process.exit(1)}console.log('PASS');
