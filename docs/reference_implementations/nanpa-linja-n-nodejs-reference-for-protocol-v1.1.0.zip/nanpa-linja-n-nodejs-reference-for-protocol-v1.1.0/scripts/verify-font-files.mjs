import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import {
  PRODUCTION_MANIFEST_REL,
  loadProductionManifest,
  productionPairFaces,
  productionSupportFonts,
  readProductionEntry,
  regressionOptionsForPair
} from './lib/production-assets.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const loaded = await loadProductionManifest(root);
if (!loaded) {
  console.log(`font files: SKIP (${PRODUCTION_MANIFEST_REL} not found)`);
  process.exit(0);
}
const { manifest, archive } = loaded;
if (!manifest.pairs.length) {
  console.error('FAIL manifest: pairs is empty');
  process.exit(1);
}

const u16 = (b, o) => b.readUInt16BE(o);
const u32 = (b, o) => b.readUInt32BE(o);
const tag = (b, o) => b.toString('ascii', o, o + 4);
function tables(b) {
  let base = 0;
  if (tag(b, 0) === 'ttcf') base = u32(b, 12);
  const n = u16(b, base + 4);
  const m = new Map();
  for (let i = 0; i < n; i++) {
    const o = base + 12 + i * 16;
    m.set(tag(b, o), { off: u32(b, o + 8), len: u32(b, o + 12) });
  }
  return m;
}
function cmapHas(b, cp) {
  const t = tables(b).get('cmap');
  if (!t) return false;
  const n = u16(b, t.off + 2), subs = [];
  for (let i = 0; i < n; i++) {
    const r = t.off + 4 + i * 8, so = t.off + u32(b, r + 4), fmt = u16(b, so);
    if (fmt === 12 || fmt === 13) subs.push({ fmt, so, score: 100 });
    else if (fmt === 4) subs.push({ fmt, so, score: 50 });
  }
  subs.sort((a, b) => b.score - a.score);
  for (const s of subs) {
    if (s.fmt === 12 || s.fmt === 13) {
      const groups = u32(b, s.so + 12); let lo = 0, hi = groups - 1;
      while (lo <= hi) {
        const mid = (lo + hi) >> 1, o = s.so + 16 + mid * 12;
        const a = u32(b, o), z = u32(b, o + 4), g = u32(b, o + 8);
        if (cp < a) hi = mid - 1;
        else if (cp > z) lo = mid + 1;
        else return (s.fmt === 13 ? g : g + cp - a) > 0;
      }
    } else if (s.fmt === 4 && cp <= 0xffff) {
      const seg = u16(b, s.so + 6) / 2;
      const end = s.so + 14, start = end + seg * 2 + 2, delta = start + seg * 2, range = delta + seg * 2;
      for (let i = 0; i < seg; i++) {
        const e = u16(b, end + i * 2), a = u16(b, start + i * 2);
        if (cp < a || cp > e) continue;
        const d = b.readInt16BE(delta + i * 2), ro = u16(b, range + i * 2);
        if (ro === 0) return ((cp + d) & 0xffff) > 0;
        const addr = range + i * 2 + ro + (cp - a) * 2;
        if (addr + 2 > b.length) return false;
        const gid = u16(b, addr);
        return gid > 0 && ((gid + d) & 0xffff) > 0;
      }
    }
  }
  return false;
}

function adapterIdForPair(pair) {
  const id = String(pair?.renderAdapterId || 'identity').trim();
  return id || 'identity';
}

const LEGACY_ASCII_ADAPTERS = new Set(['linja-pona-legacy-v1', 'linja-sike-legacy-v1']);
const TOKI_PONA_ASCII_ALPHABET = 'aeijklmnopstuw';
function legacyAdapterRequiredCodepoints(adapterId) {
  if (!LEGACY_ASCII_ADAPTERS.has(String(adapterId || ''))) return null;
  // The renderer converts canonical numeric/cartouche UCSUR into the legacy
  // fonts' native ASCII ligature syntax: [ _word _word ... ] plus colon.
  // Requiring the canonical UCSUR cmap for these fonts is therefore incorrect.
  return new Set(Array.from(TOKI_PONA_ASCII_ALPHABET + '[]_:').map(ch => ch.codePointAt(0)));
}

function gsubTags(b) {
  const t = tables(b).get('GSUB');
  if (!t) return new Set();
  const fl = t.off + u16(b, t.off + 6), n = u16(b, fl), out = new Set();
  for (let i = 0; i < n; i++) out.add(tag(b, fl + 2 + i * 6));
  return out;
}

const renderer = await import(pathToFileURL(path.join(root, 'reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js')).href);
const corpus = JSON.parse(await fs.readFile(path.join(root, 'fixtures/nanpa-linja-n-regression-v1.0.2.json'), 'utf8'));
const cps = new Set([0xF1990, 0xF1991, 0xF199D]);
for (const tc of corpus.parserCases || []) {
  if (tc.assert?.result !== 'accept' || typeof tc.input !== 'string') continue;
  for (const fn of ['parseNumber', 'parseIdentifier']) {
    try {
      const r = renderer.NanpaParser[fn](tc.input, tc.options || {});
      for (const k of ['ucsurCodepoints', 'abbreviatedUcsurCodepoints', 'innerCodepoints', 'codepoints']) {
        for (const cp of r?.[k] || []) if (Number.isFinite(Number(cp))) cps.add(Number(cp));
      }
    } catch {}
  }
}

let fail = 0, files = 0, pairs = 0;
const seenKeys = new Set();
for (const pair of manifest.pairs) {
  const key = String(pair?.fontKey || '').trim();
  if (!key) { console.error('FAIL manifest pair: missing fontKey'); fail++; continue; }
  if (seenKeys.has(key)) { console.error(`FAIL manifest: duplicate fontKey ${key}`); fail++; continue; }
  seenKeys.add(key); pairs++;
  for (const required of ['rev', 'baseUrl', 'companionUrl', 'baseFamily', 'companionFamily']) {
    if (!String(pair?.[required] || '').trim()) { console.error(`FAIL ${key}: missing ${required}`); fail++; }
  }
  const opts = regressionOptionsForPair(pair);
  const faces = productionPairFaces(archive, pair);
  for (const face of faces) {
    if (!face.exists) {
      console.error(`FAIL ${key}/${face.role}: ZIP entry not found for ${face.entryName || face.filename || '(missing filename)'}`);
      fail++; continue;
    }
    files++;
    const b = await readProductionEntry(archive, face.entryName);
    const h = crypto.createHash('sha256').update(b).digest('hex');
    if (face.sha256 && h.toLowerCase() !== String(face.sha256).toLowerCase()) {
      console.error(`FAIL sha256 ${key}/${face.role} ${face.family}: ${h} != ${face.sha256}`); fail++;
    } else {
      console.log(`PASS sha256 ${key}/${face.role} ${face.family}: ${h}${face.sha256 ? '' : ' (recorded; manifest has no hash)'}`);
    }
    if (face.role === 'companion' && opts.checkNumericCoverage) {
      const adapterId = adapterIdForPair(pair);
      const nativeCps = legacyAdapterRequiredCodepoints(adapterId);
      const requiredCps = new Set(nativeCps || cps);
      if (pair?.settings?.cartoucheVulgarFractions === true) {
        for (const cp of [0x00BC, 0x2153, 0x00BD, 0x2154, 0x00BE]) requiredCps.add(cp);
      }
      let miss;
      try { miss = [...requiredCps].filter(cp => !cmapHas(b, cp)); }
      catch (error) { console.error(`FAIL cmap ${key}/${face.family}: ${error?.message || error}`); fail++; continue; }
      if (miss.length) {
        const kind = nativeCps ? `adapter-native (${adapterId})` : 'canonical numeric/render';
        console.error(`FAIL cmap ${key}/${face.family}: missing ${miss.length} ${kind} codepoints: ` + miss.slice(0, 30).map(cp => 'U+' + cp.toString(16).toUpperCase()).join(', ')); fail++;
      } else if (nativeCps) {
        console.log(`PASS cmap-native ${key}/${face.family}: ${requiredCps.size} legacy adapter input codepoints (${adapterId}); canonical UCSUR cmap intentionally not required`);
      } else {
        console.log(`PASS cmap ${key}/${face.family}: ${cps.size} required numeric/render codepoints`);
      }
      const tags = gsubTags(b);
      for (const ft of opts.requiredOpenTypeFeatures) {
        if (!tags.has(ft)) { console.error(`FAIL GSUB ${key}/${face.family}: missing ${ft}`); fail++; }
        else console.log(`PASS GSUB ${key}/${face.family}: ${ft}`);
      }
    }
  }
}

const supportFonts = productionSupportFonts(archive, manifest);
for (const face of supportFonts) {
  if (!face.role || !face.filename) { console.error('FAIL support font: missing role or filename'); fail++; continue; }
  if (!face.exists) { console.error(`FAIL support font ${face.role}: ZIP entry not found for ${face.entryName}`); fail++; continue; }
  files++;
  const b = await readProductionEntry(archive, face.entryName);
  const h = crypto.createHash('sha256').update(b).digest('hex');
  console.log(`PASS support font ${face.role} ${face.family || ''}: ${face.entryName} sha256=${h}`);
}

console.log(`font manifest: ${pairs} pair(s), ${files} referenced font file(s), ${cps.size} required numeric/render codepoints`);
if (fail) { console.error(`font files: ${fail} failure(s)`); process.exitCode = 1; }
else console.log('font files: PASS');
