#!/usr/bin/env node
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { openZipBytes } from '../src/font-zip.js';
import { SitelenRenderer, NanpaParser, DEFAULT_PARSER_CONFIG } from '../src/node.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const profile = JSON.parse(fs.readFileSync(path.join(root, 'protocol/conformance/parser-renderer-profile-v1.1.0.json'), 'utf8'));
const sourcePath = path.join(root, 'reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js');
const source = fs.readFileSync(sourcePath, 'utf8');
const fontZipBytes = fs.readFileSync(path.join(root, 'resources/fonts.zip'));
const zip = openZipBytes(fontZipBytes);
const manifestBytes = Buffer.from(await zip.bytesFor('fonts/preloaded-font-pairs.manifest.json'));
const manifest = JSON.parse(manifestBytes.toString('utf8'));
const sha256 = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
let checks = 0;
const check = (condition, message) => { assert.ok(condition, message); checks++; };
const same = (a,b) => JSON.stringify(a) === JSON.stringify(b);

check(profile.profileVersion === '1.1.0', 'profileVersion');
check(sha256(fs.readFileSync(sourcePath)) === profile.canonicalJavaScript.sha256, 'canonical JavaScript hash');
check(sha256(manifestBytes) === profile.productionManifest.sha256, 'production manifest hash');
check(manifest.schema === profile.productionManifest.schema, 'production manifest schema');
check(manifest.pairs.length === profile.productionManifest.fontPairCount, 'production font pair count');

const expectedNanpaOps = [
  'parseNumber','encodeDecimal','decimalToUcsurCodepoints','properNameToUcsurCodepoints','splitCapsToProperName','capsToUniqueCode','decodeCaps','ucsurCodepointsToTpWords','codepointsToWords','tpWordsToText','parseTpWordsToCodepoints','tpWordsToUcsurCodepoints','codepointsToHex','codepointsToHexWithCartouche','parseHexCodepoints','withCartoucheMarkers','stripCartoucheMarkers','isValidCaps','isValidProperName','isValidTimeOrDate','isValidTime','isValidDate','tokenizeCaps','capsTokensToTpWords','capsToWords','capsToCodepoints','parseIdentifier','normalizeVulgarFraction','normalizeTpWord','getSmallCodepointsSet','getQuarterCodepointsSet','getOneThirdCodepointsSet','getTwoThirdsCodepointsSet','getHalfCodepointsSet','isAllowedTpUcsurCodepoint'
].sort();
check(same(Object.keys(NanpaParser).sort(), expectedNanpaOps), 'NanpaParser 35-operation surface');
const expectedStatic = ['create','registerRenderAdapter','unregisterRenderAdapter','hasRenderAdapter','getDefaultRenderAdapterId','NanpaParser'].sort();
check(same(Object.keys(SitelenRenderer).sort(), expectedStatic), 'SitelenRenderer static surface');
check(SitelenRenderer.getDefaultRenderAdapterId() === 'identity', 'default render adapter');
for (const id of profile.renderAdapters.builtIn) check(SitelenRenderer.hasRenderAdapter(id) === true, `built-in render adapter ${id}`);

const defaults = profile.defaults;
const facadeDefaults = {
  numericMode: DEFAULT_PARSER_CONFIG.numericMode,
  relaxedNanpaLinjanParsing: DEFAULT_PARSER_CONFIG.relaxedNanpaLinjanParsing,
  relaxedNanpaLinjanRendering: DEFAULT_PARSER_CONFIG.relaxedNanpaLinjanRendering,
  nanpaColonParsingEffective: DEFAULT_PARSER_CONFIG.nanpaColonParsing,
  nanpaColonRendering: DEFAULT_PARSER_CONFIG.nanpaColonRendering,
  abbreviateNumericCartouches: DEFAULT_PARSER_CONFIG.abbreviateNumericCartouches,
  preserveNumericCartoucheBreaksInAbbreviation: DEFAULT_PARSER_CONFIG.preserveNumericCartoucheBreaksInAbbreviation,
  breakLinesAtFullStops: DEFAULT_PARSER_CONFIG.breakLinesAtFullStops,
  interpretDoubleQuotesAsTeTo: DEFAULT_PARSER_CONFIG.interpretDoubleQuotesAsTeTo,
  numericCartoucheStartGlyph: DEFAULT_PARSER_CONFIG.numericCartoucheStartGlyph,
  enableHexParsing: DEFAULT_PARSER_CONFIG.enableHexParsing,
  enableBinaryParsing: DEFAULT_PARSER_CONFIG.enableBinaryParsing,
  enableBinaryRendering: DEFAULT_PARSER_CONFIG.enableBinaryRendering,
  nasinNanpaPona: DEFAULT_PARSER_CONFIG.nasinNanpaPona,
};
for (const [key, value] of Object.entries(facadeDefaults)) check(same(value, defaults[key]), `facade default ${key}`);

const staticNeedles = [
  'let __abbreviateNumericCartouches = true;',
  'let __relaxedNanpaLinjanParsing = true;',
  'let __relaxedNanpaLinjanRendering = true;',
  'let __nanpaColonParsing = true;',
  'let __nanpaColonRendering = true;',
  'let __enableHexParsing = false;',
  'let __enableBinaryParsing = false;',
  'let __enableBinaryRendering = false;',
  'let __nasinNanpaPona = false;',
  'let __cartoucheVulgarFractions = false;',
  'let __emulateLegacyCartoucheScaling = false;',
  'breakLinesAtFullStops: false',
  'const CARTOUCHE_SCALE_STYLISTIC_FEATURES_ENABLED = false;',
  "const STANDARD_SITELEN_PONA_ASCII_CORE_MODE = 'standard-sitelen-pona-ascii-core';",
  "const SITELEN_PONA_ASCII_EXTENDED_MODE = 'sitelen-pona-ascii-extended';",
];
for (const needle of staticNeedles) check(source.includes(needle), `source invariant ${needle}`);

function pick(r) {
  if (r == null) return null;
  return {
    caps:r.caps ?? null, kind:r.kind ?? 'decimal', numberBase:r.numberBase ?? 10,
    properName:r.properName ?? null, uniqueCode:r.uniqueCode ?? null, displayValue:r.displayValue ?? null,
    semanticKind:r.semanticKind ?? null, semanticStartGlyph:r.semanticStartGlyph ?? null,
    isDate:!!r.isDate, isTime:!!r.isTime, numericMode:r.numericMode ?? null,
    tpWords:Array.isArray(r.tpWords) ? r.tpWords : null,
    abbreviatedWords:Array.isArray(r.abbreviatedWords) ? r.abbreviatedWords : null,
  };
}
for (const c of profile.nanpaParserSmokeCases) {
  let got = null, error = null;
  try { got = pick(NanpaParser.parseNumber(c.input, c.options || {})); } catch (e) { error = e.message; }
  check(error === c.error && same(got, c.result), `NanpaParser smoke case ${c.id}`);
}

const pairModes = [...new Set(manifest.pairs.map(p => p.parserMode))].sort();
check(same(pairModes, [...profile.productionManifest.parserModes].sort()), 'manifest parser modes');
const pairAdapters = [...new Set(manifest.pairs.map(p => p.renderAdapterId).filter(Boolean))].sort();
check(same(pairAdapters, [...profile.productionManifest.renderAdapterIds].sort()), 'manifest adapter IDs');
for (const pair of manifest.pairs) {
  check(pair.settings?.cartoucheVulgarFractions === true, `${pair.fontKey} cartoucheVulgarFractions`);
  check(pair.settings?.emulateLegacyCartoucheScaling === false, `${pair.fontKey} emulateLegacyCartoucheScaling`);
}

check(sha256(fontZipBytes) === '08d0409e0b180a6b90a0617fe557fd3e59a08dd26781d907ed5d772a9fefcae1', 'supplied fonts.zip bytes');
check(!zip.has('fonts/nanpa-linja-n-nasin-nanpa-liberation-sans-literal.ttf'), 'supplied archive intentionally lacks compatibility alias filename');
check(zip.has('fonts/LiberationSans-Regular.ttf'), 'supplied archive contains LiberationSans-Regular.ttf donor');
const nodePlatformSource = fs.readFileSync(path.join(root, 'src/node-platform.js'), 'utf8');
check(nodePlatformSource.includes("'nanpa-linja-n-nasin-nanpa-liberation-sans-literal.ttf': 'LiberationSans-Regular.ttf'"), 'Node platform declares documented literal-font compatibility alias');

console.log(`Node.js protocol v1.1.0 integrated profile regression: ${checks} checks PASS`);
console.log(`NanpaParser profile smoke cases: ${profile.nanpaParserSmokeCases.length}/${profile.nanpaParserSmokeCases.length} PASS`);
console.log(`Production font pairs: ${manifest.pairs.length}/${manifest.pairs.length} profile invariants PASS`);
