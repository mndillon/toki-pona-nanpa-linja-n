#!/usr/bin/env node
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const doc=JSON.parse(fs.readFileSync(path.join(root,'RELEASE-MANIFEST.json'),'utf8'));
let failures=0;
for(const item of doc.files||[]){
  const p=path.join(root,item.file);
  if(!fs.existsSync(p)){console.error(`FAIL missing ${item.file}`);failures++;continue;}
  const b=fs.readFileSync(p); const h=crypto.createHash('sha256').update(b).digest('hex');
  if(h!==item.sha256||b.length!==item.bytes){console.error(`FAIL ${item.file} ${h} ${b.length}`);failures++;}
}
console.log(`release manifest: ${(doc.files||[]).length} file(s), ${failures} failure(s)`);
if(failures)process.exit(1); console.log('PASS');
