# Node.js Protocol v1.1.0 conformance

## Conformance model

The Node.js reference is qualified against four independent layers:

1. the unchanged frozen Core-v1 regression corpus;
2. the Protocol v1.1.0 integrated parser/renderer profile;
3. the canonical JavaScript v1.1 semantic renderer corpora;
4. production behavior parity against a Chromium oracle generated from the completed JavaScript v1.1.0 reference.

All configured suites must pass for the release qualification reported by `npm test`.

## Canonical-source relationship

These files are SHA-256 pinned in `fixtures/reference-hashes.json`:

```text
reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js
reference/sitelen-font-pair-controller.js
reference/sitelen-vector-exporter.js
src/advanced-browser-core.js
src/node-facade.js
src/node-platform.js
src/font-zip.js
resources/fonts.zip
```

The renderer, parser, font adapters and vector exporter are the canonical JavaScript implementation. Node-specific behavior is confined to the platform/resource layer.

## Frozen Core-v1 corpus

`fixtures/nanpa-linja-n-regression-v1.0.2.json` remains unchanged historical Core evidence. Acceptance: **1030 checks, zero failures**.

## Protocol v1.1.0 profile

The machine-readable profile is:

```text
protocol/conformance/parser-renderer-profile-v1.1.0.json
```

Acceptance currently includes **79 checks**, **16/16** `NanpaParser` smoke cases and **8/8** production font-pair profile invariants. It pins the canonical JavaScript source and production manifest hashes and verifies v1.1 defaults, render adapters, parser modes, supplied font ZIP bytes and the Node literal-font compatibility alias.

## Canonical renderer corpora

```text
conformance/canonical-syntax-v1.0.1-phase1/cases.json
conformance/full-renderer-canonical-v1.1.0/cases.json
```

Acceptance:

- canonical syntax: **28/28**;
- production font-adapter cases: **5/5**;
- full canonical renderer: **254/254**.

## Production font acceptance

The current manifest contains eight production pairs. Qualification verifies referenced font bytes, required cmap coverage, current render-adapter contracts and vulgar-fraction cartouche scale codepoints. Legacy automatic `ss12`/`ss13`/`ss14` features are not a v1.1 requirement.

The exact supplied `resources/fonts.zip` is retained. The manifest-requested nasin-nanpa literal filename is resolved at runtime to the supplied byte-identical Liberation Sans donor file; the supplied ZIP is not modified.

## Chromium-to-Node production parity

Cases are defined by `fixtures/nodejs-browser-parity-cases.json`. The corresponding oracle, `fixtures/nodejs-browser-parity-v1.json`, is generated independently from the completed JavaScript v1.1.0 reference in Chromium.

Acceptance is **64/64 cases**, **449 semantic checks**, **257 geometry groups**, zero failures. Semantic data is compared exactly. Geometry uses a 2.1 px tolerance because Chromium Canvas and Skia font metrics can differ slightly despite equivalent semantic layout.

## Output formats

Production regression covers Canvas, PNG, SVG and PDF. SVG must contain vector path geometry and must not contain `<image>` or `data:image` raster fallback for the tested generated content. PDF must not contain a raster `/Subtype /Image` XObject for the tested generated content.

## Consolidated runner

`npm test` is non-fail-fast: all **11** configured suites are attempted and their stdout/stderr and exit status are collected. The report is written to:

```text
test-output/nodejs-regression-report.txt
```
