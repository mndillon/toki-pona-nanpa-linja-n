# Testing the Node.js reference

## Full qualification

```bash
npm install
npm test
```

Node.js 20 or newer is required. The test runner attempts every suite even after a failure and writes `test-output/nodejs-regression-report.txt`.

## Individual suites

```bash
npm run verify:references
npm run verify:fonts
npm run test:protocol
npm run test:profile
npm run test:platform
npm run test:core
npm run test:ast
npm run test:canonical-syntax
npm run test:canonical-renderer
npm run test:output
npm run test:parity
```

`test:protocol` is the frozen Core-v1 corpus. `test:profile` is the Protocol v1.1.0 integrated profile. `test:parity` compares Node against the frozen Chromium oracle generated from the current JavaScript v1.1.0 reference.

## Visual audits

```bash
npm run visual:numeric
npm run visual:cartouches
```

Generated files are written under `test-output/` and are not release inputs.
