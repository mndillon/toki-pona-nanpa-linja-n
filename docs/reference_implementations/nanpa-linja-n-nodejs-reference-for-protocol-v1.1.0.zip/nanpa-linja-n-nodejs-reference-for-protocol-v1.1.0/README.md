# nanpa-linja-n Node.js reference implementation — Protocol v1.1.0

This package is the **Node.js reference implementation for nanpa-linja-n Protocol v1.1.0**.

It runs the canonical JavaScript v1.1.0 parser/renderer, font-pair controller and vector exporter under Node.js using `skia-canvas` 3.0.8. Protocol/cartouche semantics are not reimplemented in a Node-specific parser: the canonical JavaScript sources are bundled and SHA-256 pinned, while `src/node-platform.js` supplies the browser-compatible platform services needed by those sources.

## Requirements

- Node.js 20 or newer
- npm
- a platform supported by `skia-canvas` 3.0.8

Install the declared dependency, then run the qualification suite:

```bash
npm install
npm test
```

The consolidated runner is non-fail-fast and writes `test-output/nodejs-regression-report.txt`.

## Protocol v1.1.0 defaults

The public facade now follows the v1.1.0 integrated parser/renderer profile:

- parser mode: `sitelen-pona-ascii-extended`
- numeric mode: `uniform`
- relaxed parsing: enabled
- relaxed rendering: enabled
- nanpa-format parsing/rendering: enabled
- abbreviated numeric cartouches: enabled
- preserve abbreviated internal break marker: disabled
- line splitting at full stops: disabled
- interpret double quotes as `te`/`to`: disabled
- hexadecimal parsing: disabled unless explicitly enabled
- binary parsing/rendering: disabled unless explicitly enabled
- `nasinNanpaPona`: disabled unless explicitly enabled

The standard ASCII core mode remains available as `standard-sitelen-pona-ascii-core`.

## Basic API

```js
import { NanpaLinjaN, parseNumber } from './src/node.js';

const nanpa = await NanpaLinjaN.create();

const parsed = await nanpa.parse('toki&pona 123 zz pi(telo lete) te tomo to');
console.log(nanpa.astToText(parsed.ast, { numericOutput: 'properName' }));
console.log(parseNumber('123'));

const png = await nanpa.renderToPng('123.45', {
  font: 'linjaPona',
  fontSize: 56,
});

const svg = await nanpa.renderToSvg('123.45', { font: 'nasinNanpa' });
const pdf = await nanpa.renderToPdf('123.45', { font: 'nasinNanpa' });

await nanpa.destroy();
```

`parseNumber()` is available as a named export, on `NanpaParser`, and on a created facade instance. `astToText()` supports `source`, `properName`, `#~`, and `cartouche`; `cartouche` is abbreviated by default in v1.1.0 and can be made full with `parser.abbreviateNumericCartouches: false`. `nasinNanpaPona: true` requests ordinary Toki Pona numeric wording where applicable.

Hexadecimal and binary are opt-in:

```js
await nanpa.renderToPng('#ABCDEF', {
  parser: { enableHexParsing: true },
});

await nanpa.renderToPdf('0b10101', {
  parser: {
    enableBinaryParsing: true,
    enableBinaryRendering: true,
  },
});
```

## Font resources and render adapters

`resources/fonts.zip` is the exact supplied production archive for this release. Its SHA-256 is:

```text
08d0409e0b180a6b90a0617fe557fd3e59a08dd26781d907ed5d772a9fefcae1
```

The production manifest contains eight font pairs. The current renderer uses the v1.1 font render-adapter layer for fonts whose native OpenType input differs from canonical Common Sitelen Pona. Built-in adapters are:

- `identity`
- `linja-pona-legacy-v1`
- `linja-sike-legacy-v1`
- `nasin-sitelen-pu-mono-v1`
- `linja-lipamanka-v1`

All current production pairs opt into `cartoucheVulgarFractions: true` and disable `emulateLegacyCartoucheScaling`. The v1.1 renderer therefore does not depend on automatic `ss12`/`ss13`/`ss14` selection for cartouche scaling.

The supplied archive's nasin-nanpa manifest asks for `nanpa-linja-n-nasin-nanpa-liberation-sans-literal.ttf`, while the supplied bytes contain `LiberationSans-Regular.ttf`. The Node platform resolves that requested runtime name to the supplied Liberation Sans bytes. `resources/fonts.zip` itself remains byte-for-byte unchanged.

## Advanced API

```js
import {
  SitelenRenderer,
  NanpaParser,
  SitelenVectorExporter,
  createSitelenFontPairController,
} from './src/node-advanced.js';
```

The current renderer exposes the v1.1 render-adapter API (`registerRenderAdapter`, `unregisterRenderAdapter`, `hasRenderAdapter`, `getDefaultRenderAdapterId`) and render plans preserve both canonical and font-render codepoint information where applicable.

## Qualification layers

`npm test` currently runs **11 suites**:

1. canonical/reference and Node wrapper SHA-256 integrity;
2. production font/archive and cmap checks;
3. frozen Core-v1 regression corpus — **1030 checks**;
4. Protocol v1.1.0 integrated profile — **79 checks**, including **16/16** `NanpaParser` smoke cases and **8/8** font-pair invariants;
5. Node platform compatibility;
6. Node renderer core — **115 checks**;
7. `astToText` / `parseNumber` — **26** pure checks plus **15** Node integration checks;
8. canonical syntax — **28/28**, plus **5/5** render-adapter cases;
9. canonical full renderer — **254/254**;
10. production output — **77 checks**, including PNG, SVG, PDF and explicit vector-only SVG/PDF assertions;
11. Chromium v1.1 browser-to-Node parity — **64/64** cases, **449** semantic checks and **257** geometry groups at 2.1 px tolerance.

The Chromium parity oracle in `fixtures/nodejs-browser-parity-v1.json` was regenerated from the completed JavaScript Protocol v1.1.0 reference in Chromium, rather than from Node output.

## Vector-output requirement

The production-output regression requires generated SVG to contain vector `<path>` geometry and rejects `<image>` or `data:image` raster fallback. The tested PDF output is rejected if it contains a raster `/Subtype /Image` XObject. PNG remains raster by definition.

## Canonical semantic corpora

```text
conformance/canonical-syntax-v1.0.1-phase1/cases.json
conformance/full-renderer-canonical-v1.1.0/cases.json
```

The frozen Core-v1 fixture remains historical/frozen evidence and is not rewritten to manufacture a v1.1 result. Protocol v1.1 functionality is qualified separately by `protocol/conformance/parser-renderer-profile-v1.1.0.json` and the current canonical renderer corpus.

## External font directory

To test an unpacked copy of the production fonts:

```bash
export NANPA_FONT_DIR="/absolute/path/to/fonts"
npm test
```

If the directory includes `preloaded-font-pairs.manifest.json`, it is used; otherwise the bundled manifest is used and its font filenames are resolved against `NANPA_FONT_DIR`.

## Generated output

Test/audit artifacts are written under `test-output/`. `node_modules/` and generated test output are not part of the release ZIP.
