# Node.js reference — Protocol v1.1.0 release notes

This release upgrades the Node.js reference from its Protocol v1.0 baseline to the Protocol v1.1.0 integrated parser/renderer profile.

## Functional changes

- synchronized the canonical renderer/parser, font controller and vector exporter with the completed JavaScript v1.1.0 reference;
- updated facade defaults to v1.1.0, including abbreviated numeric cartouches by default and opt-in hexadecimal/binary parsing;
- aligned `parseNumber()` and `astToText()` behavior with the current JavaScript API;
- retained `nasinNanpaPona` facade serialization behavior;
- added current font render adapters and canonical-to-render mapping behavior;
- replaced production font resources with the exact supplied `fonts.zip`;
- added Node runtime handling for the manifest-requested nasin-nanpa literal filename without modifying the supplied ZIP;
- removed the v1.1 qualification dependency on automatic `ss12`/`ss13`/`ss14` scaling;
- updated canonical full-renderer conformance to the v1.1.0 corpus;
- regenerated browser parity expectations independently from the completed JavaScript v1.1.0 reference in Chromium;
- strengthened SVG/PDF tests to reject raster fallback in tested generated cartouche content.

## Regression status

The release is qualified only when all 11 suites in `npm test` pass. See `CONFORMANCE.md`, `TESTING.md`, and `test-output/nodejs-regression-report.txt`.
