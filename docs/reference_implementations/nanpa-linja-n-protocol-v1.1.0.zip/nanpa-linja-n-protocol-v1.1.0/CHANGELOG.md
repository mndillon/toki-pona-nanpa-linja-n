# Protocol changelog

## v1.1.0 — 2026-09-25

- Added the normative **Parser-Renderer-Profile-v1.1** aligned to the supplied current JavaScript parser/renderer (`fdeb3e3bfd46b9f86650fd411a2d1dfb2515580aa258aa8c11a002913631418c`).
- Standardized integrated-profile defaults: uniform numeric mode; relaxed parsing/rendering; nanpa-format parsing/rendering; abbreviated numeric cartouches; physical-line preservation; ordinary double-quote handling; hex/binary disabled unless opted in.
- Recorded `standard-sitelen-pona-ascii-core`, `sitelen-pona-ascii-extended`, and `sitelen-seli-kiwen` parser-mode behavior, including current compound operators `&`, `-`, and `+` where permitted.
- Preserved the explicit raw `U+...` input extension and documented its render-adapter bypass behavior.
- Added the render-adapter registry contract and current built-in production adapter IDs.
- Updated the production font-pair profile to the supplied schema-2 manifest (SHA-256 `50b8a4b6cab0c27f2061f94e404a2af992cbf95c8097c58caa5e6b2dc4625f09`), including current adapter settings, manual tally modes, vulgar-fraction cartouche scaling, current font revisions, and synthetic corner-bracket declarations.
- Removed legacy `ss12`/`ss13`/`ss14` as v1.1 production requirements. Current scaling uses inline vulgar-fraction controls where enabled; legacy automatic stylistic-set switching is disabled.
- Updated the 16 logical production rendering cases to remove stylistic-set assumptions and to make hex/binary opt-in flags explicit.
- Retained the v1.0.2 Core-v1 conformance corpus byte-for-byte and retained the 35 Core operations.
- Reclassified the old 128 JavaScript SVG artifacts and old canonical/full-renderer corpora as **historical v1.0.1 evidence**, not current v1.1 visual certification.
- Added 16 current-source `NanpaParser` smoke vectors for v1.1 profile defaults and numeric namespace behavior.

## v1.0.1 — 2026-09-21

- Pinned the then-current JavaScript reference package and updated reference hashes/qualification metadata.
- Expanded the Core regression corpus to 320 parser cases / 1030 checks with internal-whitespace clarification vectors.
- Documented the then-current package facade while preserving the frozen 35-operation Core-v1 map.

## v1.0.0 — 2026-09-14

Initial frozen Protocol v1 release.
