# nanpa-linja-n Protocol v1.1.0

This directory is the frozen **nanpa-linja-n Protocol v1.1.0** release dated **2026-09-25**.

Protocol v1.1.0 keeps the frozen Core-v1 numeric semantics from v1.0.1 and adds a normative **integrated parser/renderer profile** matching the supplied current JavaScript parser/renderer. It also updates the production font profile to the supplied schema-2 manifest.

Start with `SPEC.md`, then `PARSER-RENDERER-PROFILE.md`, `CONFORMANCE.md`, `RENDERING-PROFILE.md`, `API.md`, and `VERSIONING.md`.

## Headline v1.1 additions

- Default integrated-profile behavior is **uniform numeric mode**, **relaxed parsing**, **relaxed rendering**, **nanpa-format parsing/rendering**, and **abbreviated numeric cartouches** unless explicitly overridden.
- Numeric cartouche abbreviation can still be disabled explicitly; abbreviated internal-break preservation remains opt-in and defaults false.
- Standard text modes are documented: `standard-sitelen-pona-ascii-core`, `sitelen-pona-ascii-extended`, and `sitelen-seli-kiwen`.
- Compound operators `&`, `-`, and `+` are part of current compound parsing where the selected mode permits them.
- `interpretDoubleQuotesAsTeTo` remains opt-in; ordinary double quotes are not silently reinterpreted by default.
- Renderer line splitting at full stops is opt-in; physical input lines are preserved by default.
- Hexadecimal (`#...`) and binary (`0b...`) parsing remain opt-in namespaces with fixed `nasa...nasa` and `noka...noka` boundaries.
- Render adapters are now part of the integrated profile, including the production adapters for linja pona, linja sike, nasin sitelen pu mono, and linja lipamanka.
- Current production font scaling uses inline vulgar-fraction scale controls where enabled. Legacy automatic `ss12`/`ss13`/`ss14` selection is **not** a v1.1 requirement.
- The production font-pair manifest is updated to the supplied schema-2 manifest and current font revisions.

## Compatibility boundary

The existing `conformance/nanpa-linja-n-regression-v1.0.2.json` corpus remains byte-for-byte Core-v1 authority. Protocol v1.1.0 does not silently replace any frozen Core-v1 expected result.

New integrated parser/renderer behavior is specified by `conformance/parser-renderer-profile-v1.1.0.json` and `PARSER-RENDERER-PROFILE.md`.

## Current JavaScript authority

Canonical parser/renderer source hash:

`fdeb3e3bfd46b9f86650fd411a2d1dfb2515580aa258aa8c11a002913631418c`

See `references/current-javascript-source.json`.

## Visual evidence status

The 128 JavaScript SVG artifacts retained under `references/` are **historical v1.0.1 evidence**. They are not relabeled as current v1.1.0 visual certification, because the current external font binaries and a newly generated v1.1.0 golden set were not supplied as part of this protocol update.
