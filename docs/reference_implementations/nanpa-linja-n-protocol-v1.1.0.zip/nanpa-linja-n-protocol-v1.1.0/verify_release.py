#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, shutil, subprocess, sys

root = Path(__file__).resolve().parent

def sha(p: Path):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def fail(*msg):
    print('FAIL', *msg)
    raise SystemExit(1)

manifest = json.loads((root/'release-manifest.json').read_text())
if manifest.get('protocolVersion') != '1.1.0' or manifest.get('status') != 'final':
    fail('release manifest identity')

# Frozen-file inventory.
seen=set()
for item in manifest.get('bundledFiles', []):
    rel=item.get('path')
    if not rel or rel in seen: fail('invalid/duplicate manifest path', rel)
    seen.add(rel)
    p=root/rel
    if not p.is_file(): fail('missing bundled file', rel)
    got=sha(p)
    if got != item.get('sha256') or p.stat().st_size != item.get('size'):
        fail('bundled file hash/size mismatch', rel, got, item.get('sha256'))

# Ensure every regular file except release-manifest itself is frozen.
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name != 'release-manifest.json'}
if actual != seen:
    fail('release manifest file-set mismatch', 'missing-from-manifest='+str(sorted(actual-seen)), 'stale='+str(sorted(seen-actual)))

proto=json.loads((root/'protocol.json').read_text())
if proto.get('protocol') != 'nanpa-linja-n' or proto.get('protocolVersion') != '1.1.0' or proto.get('status') != 'final':
    fail('protocol identity')

# Core-v1 remains byte-identical to the frozen v1.0.2 corpus hash.
core_path=root/proto['core']['conformanceCorpus']
core=json.loads(core_path.read_text())
core_sha=sha(core_path)
EXPECTED_CORE_SHA='e4baf51251861c114f5314fc2af05eb44e1b5dbcbdebdcd2678c868f5dbf306a'
if core_sha != EXPECTED_CORE_SHA or core_sha != proto['core']['conformanceCorpusSha256']:
    fail('Core-v1 corpus identity', core_sha)
if len(core.get('parserCases',[])) != 320 or proto['core'].get('parserCases') != 320:
    fail('Core parser case count')
if proto['core'].get('conformanceChecks') != 1030:
    fail('Core conformance check count')
if len(proto['core'].get('publicOperations',[])) != 35 or len(set(proto['core']['publicOperations'])) != 35:
    fail('Core operation count')

# Preserve key whitespace/yearless-date compatibility vectors.
cases={x.get('id'):x for x in core.get('parserCases',[])}
for cid in ['invalid-decimal-internal-space','invalid-decimal-space-before-point','invalid-percent-space','invalid-scientific-space','invalid-fraction-space','invalid-date-internal-space','invalid-time-internal-space']:
    if cases.get(cid,{}).get('assert',{}).get('result') != 'reject': fail('missing/redefined whitespace rejection', cid)
for cid in ['proper-name-spaces-remain-valid','cartouche-spaces-remain-valid']:
    if cases.get(cid,{}).get('assert',{}).get('result') != 'accept': fail('missing/redefined whitespace positive control', cid)

# v1.1 integrated profile identity and bundled canonical source.
profile_path=root/proto['parserRendererProfile']['normativeProfile']
profile=json.loads(profile_path.read_text())
profile_sha=sha(profile_path)
if profile.get('profileVersion') != '1.1.0' or profile_sha != proto['parserRendererProfile']['normativeProfileSha256']:
    fail('parser/renderer profile identity')
source_meta=json.loads((root/'references/current-javascript-source.json').read_text())
source_path=root/source_meta['bundledPath']
source_sha=sha(source_path)
if source_sha != proto['parserRendererProfile']['canonicalRendererSha256'] or source_sha != source_meta['sha256']:
    fail('canonical JavaScript source hash')
if source_meta.get('nanpaParserOperationCount') != 35:
    fail('source metadata operation count')

# Required v1.1 defaults.
defs=profile.get('defaults',{})
expected_defaults={
    'numericMode':'uniform',
    'relaxedNanpaLinjanParsing':True,
    'relaxedNanpaLinjanRendering':True,
    'nanpaColonParsingEffective':True,
    'nanpaColonRendering':True,
    'abbreviateNumericCartouches':True,
    'preserveNumericCartoucheBreaksInAbbreviation':False,
    'breakLinesAtFullStops':False,
    'interpretDoubleQuotesAsTeTo':False,
    'enableHexParsing':False,
    'enableBinaryParsing':False,
    'enableBinaryRendering':False,
    'nasinNanpaPona':False,
    'defaultRenderAdapterId':'identity'
}
for k,v in expected_defaults.items():
    if defs.get(k) != v: fail('default mismatch', k, defs.get(k), v)

# Production font profile.
font_path=root/proto['renderingProfile']['fontPairsManifest']
fonts=json.loads(font_path.read_text())
font_sha=sha(font_path)
if font_sha != proto['renderingProfile']['fontPairsManifestSha256']:
    fail('production font manifest hash')
if fonts.get('schema') != 2 or len(fonts.get('pairs',[])) != 8:
    fail('production font manifest schema/count')
keys=[p.get('fontKey') for p in fonts['pairs']]
if len(set(keys)) != len(keys): fail('duplicate fontKey')
required_adapters={'linja-pona-legacy-v1','linja-sike-legacy-v1','nasin-sitelen-pu-mono-v1','linja-lipamanka-v1'}
manifest_adapters={p.get('renderAdapterId') for p in fonts['pairs'] if p.get('renderAdapterId')}
if manifest_adapters != required_adapters:
    fail('production adapter inventory', manifest_adapters)
for p in fonts['pairs']:
    if p.get('parserMode') != 'sitelen-pona-ascii-extended': fail('unexpected production parser mode', p.get('fontKey'))
    settings=p.get('settings',{})
    if settings.get('cartoucheVulgarFractions') is not True: fail('cartoucheVulgarFractions must be true', p.get('fontKey'))
    if settings.get('emulateLegacyCartoucheScaling') is not False: fail('legacy scale emulation must be false', p.get('fontKey'))
if proto['renderingProfile'].get('requiredLegacyStylisticSetFeatures') != []:
    fail('legacy stylistic sets must not be required')
if proto['renderingProfile'].get('legacyAutomaticStylisticSetSelectionEnabled') is not False:
    fail('legacy automatic stylistic-set selection must be false')

# Logical rendering inventory.
golden=json.loads((root/proto['renderingProfile']['logicalGoldenCases']).read_text())
if golden.get('schemaVersion') != '1.1.0' or len(golden.get('cases',[])) != 16:
    fail('logical golden case inventory')
ids=[c.get('id') for c in golden['cases']]
if len(set(ids)) != 16: fail('duplicate golden case id')
if any('ss12' in x or 'ss13' in x or 'ss14' in x for x in ids):
    fail('v1.1 logical case id retains stylistic-set dependency')
hex_cases=[c for c in golden['cases'] if c['id'].startswith('hex-')]
bin_cases=[c for c in golden['cases'] if c['id'].startswith('binary-')]
if not hex_cases or any(c.get('parserOptions',{}).get('enableHexParsing') is not True for c in hex_cases):
    fail('hex visual cases must opt in')
if not bin_cases or any(c.get('parserOptions',{}).get('enableBinaryParsing') is not True for c in bin_cases):
    fail('binary visual cases must opt in')

# Current source smoke inventory is embedded in the normative profile.
smoke=profile.get('nanpaParserSmokeCases',[])
if len(smoke) != 16 or len({c.get('id') for c in smoke}) != 16:
    fail('NanpaParser smoke inventory')

# Historical evidence must not be described as current certification in machine-readable release metadata.
refs=json.loads((root/'references/reference-implementations.json').read_text())
if refs.get('historicalV101Evidence',{}).get('status','').lower().find('historical') < 0:
    fail('historical evidence status')
if proto['renderingProfile'].get('currentJavascriptApprovedVisualArtifactsBundled') != 0:
    fail('current visual qualification incorrectly claimed')

print(f"PASS {len(manifest['bundledFiles'])} frozen bundled files")
print('PASS Core-v1 corpus retained:', core_sha)
print('PASS Parser-Renderer-Profile-v1.1:', profile_sha)
print('PASS canonical JavaScript:', source_sha)
print('PASS production font manifest:', font_sha)
print('PASS 16 logical rendering cases; no legacy ss12/ss13/ss14 requirement')

# Optional executable JavaScript validation when Node is available.
node=shutil.which('node')
if node:
    cp=subprocess.run([node, str(root/'conformance/verify-current-javascript.mjs')], cwd=root, text=True, capture_output=True)
    if cp.returncode != 0:
        sys.stdout.write(cp.stdout); sys.stderr.write(cp.stderr); fail('JavaScript profile smoke verifier')
    # Suppress the source's always-on debug banner; keep PASS lines.
    for line in cp.stdout.splitlines():
        if line.startswith('PASS '): print(line)
else:
    print('SKIP executable JavaScript smoke verifier (node not found)')
