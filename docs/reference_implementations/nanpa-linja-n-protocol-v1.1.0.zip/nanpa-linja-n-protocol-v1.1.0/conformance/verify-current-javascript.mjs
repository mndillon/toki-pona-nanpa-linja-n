import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const srcPath = path.join(root, 'references', 'canonical', 'renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js');
const importPath = path.join(root, 'references', 'canonical', 'renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.mjs');
const source = fs.readFileSync(srcPath, 'utf8');
fs.writeFileSync(importPath, source);
let mod;
try {
  mod = await import(pathToFileURL(importPath).href + `?v=${Date.now()}`);
} finally {
  try { fs.unlinkSync(importPath); } catch {}
}
const { NanpaParser, SitelenRenderer } = mod;
const profile = JSON.parse(fs.readFileSync(path.join(here, 'parser-renderer-profile-v1.1.0.json'), 'utf8'));

function fail(msg) { console.error('FAIL', msg); process.exit(1); }
function same(a,b) { return JSON.stringify(a) === JSON.stringify(b); }

const expectedNanpaOps = [
  'parseNumber','encodeDecimal','decimalToUcsurCodepoints','properNameToUcsurCodepoints','splitCapsToProperName','capsToUniqueCode','decodeCaps','ucsurCodepointsToTpWords','codepointsToWords','tpWordsToText','parseTpWordsToCodepoints','tpWordsToUcsurCodepoints','codepointsToHex','codepointsToHexWithCartouche','parseHexCodepoints','withCartoucheMarkers','stripCartoucheMarkers','isValidCaps','isValidProperName','isValidTimeOrDate','isValidTime','isValidDate','tokenizeCaps','capsTokensToTpWords','capsToWords','capsToCodepoints','parseIdentifier','normalizeVulgarFraction','normalizeTpWord','getSmallCodepointsSet','getQuarterCodepointsSet','getOneThirdCodepointsSet','getTwoThirdsCodepointsSet','getHalfCodepointsSet','isAllowedTpUcsurCodepoint'
].sort();
if (!NanpaParser || !same(Object.keys(NanpaParser).sort(), expectedNanpaOps)) fail('NanpaParser 35-operation surface mismatch');
const expectedStatic=['create','registerRenderAdapter','unregisterRenderAdapter','hasRenderAdapter','getDefaultRenderAdapterId','NanpaParser'].sort();
if (!SitelenRenderer || !same(Object.keys(SitelenRenderer).sort(), expectedStatic)) fail('SitelenRenderer static surface mismatch');
if (SitelenRenderer.getDefaultRenderAdapterId() !== 'identity') fail('default render adapter is not identity');

const staticNeedles = [
  'let __abbreviateNumericCartouches = true;',
  'let __relaxedNanpaLinjanParsing = true;',
  'let __relaxedNanpaLinjanRendering = true;',
  'let __nanpaColonParsing = true;',
  'let __nanpaColonRendering = true;',
  'let __enableHexParsing = false;',
  'let __enableBinaryParsing = false;',
  'let __enableBinaryRendering = false;',
  'let __nasinNanpaPona = false;',
  'let __cartoucheVulgarFractions = false;',
  'let __emulateLegacyCartoucheScaling = false;',
  'breakLinesAtFullStops: false',
  'const CARTOUCHE_SCALE_STYLISTIC_FEATURES_ENABLED = false;',
  "const STANDARD_SITELEN_PONA_ASCII_CORE_MODE = 'standard-sitelen-pona-ascii-core';",
  "const SITELEN_PONA_ASCII_EXTENDED_MODE = 'sitelen-pona-ascii-extended';",
  "__fontRenderAdapters.set('linja-pona-legacy-v1'",
  "__fontRenderAdapters.set('linja-sike-legacy-v1'",
  "__fontRenderAdapters.set('nasin-sitelen-pu-mono-v1'",
  "__fontRenderAdapters.set('linja-lipamanka-v1'"
];
for (const needle of staticNeedles) if (!source.includes(needle)) fail(`missing source invariant: ${needle}`);

function pick(r) {
  if (r == null) return null;
  return {
    caps:r.caps ?? null,
    kind:r.kind ?? 'decimal',
    numberBase:r.numberBase ?? 10,
    properName:r.properName ?? null,
    uniqueCode:r.uniqueCode ?? null,
    displayValue:r.displayValue ?? null,
    semanticKind:r.semanticKind ?? null,
    semanticStartGlyph:r.semanticStartGlyph ?? null,
    isDate:!!r.isDate,
    isTime:!!r.isTime,
    numericMode:r.numericMode ?? null,
    tpWords:Array.isArray(r.tpWords) ? r.tpWords : null,
    abbreviatedWords:Array.isArray(r.abbreviatedWords) ? r.abbreviatedWords : null
  };
}
for (const c of profile.nanpaParserSmokeCases) {
  let got=null, error=null;
  try { got=pick(NanpaParser.parseNumber(c.input,c.options||{})); } catch(e) { error=e.message; }
  if (error !== c.error || !same(got,c.result)) fail(`smoke case mismatch: ${c.id}`);
}
console.log(`PASS current JavaScript profile: ${profile.nanpaParserSmokeCases.length} NanpaParser smoke cases`);
console.log('PASS NanpaParser 35-operation API surface');
console.log('PASS SitelenRenderer static/render-adapter source invariants');
