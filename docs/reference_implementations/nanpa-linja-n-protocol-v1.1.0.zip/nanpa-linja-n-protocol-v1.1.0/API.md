# API surfaces — Protocol v1.1.0

## Core-v1 language-neutral operation map

The following 35 operation names remain frozen for language-neutral bindings:

- `parseNumber`
- `encodeDecimal`
- `decimalToUcsurCodepoints`
- `properNameToUcsurCodepoints`
- `splitCapsToProperName`
- `capsToUniqueCode`
- `decodeCaps`
- `ucsurCodepointsToTpWords`
- `codepointsToWords`
- `tpWordsToText`
- `parseTpWordsToCodepoints`
- `tpWordsToUcsurCodepoints`
- `codepointsToHex`
- `codepointsToHexWithCartouche`
- `parseHexCodepoints`
- `withCartoucheMarkers`
- `stripCartoucheMarkers`
- `isValidCaps`
- `isValidProperName`
- `isValidTimeOrDate`
- `isValidTime`
- `isValidDate`
- `tokenizeCaps`
- `capsTokensToTpWords`
- `capsToWords`
- `capsToCodepoints`
- `parseIdentifier`
- `normalizeVulgarFraction`
- `normalizeTpWord`
- `getSmallCodepointsSet`
- `getQuarterCodepointsSet`
- `getOneThirdCodepointsSet`
- `getTwoThirdsCodepointsSet`
- `getHalfCodepointsSet`
- `isAllowedTpUcsurCodepoint`

## Current canonical JavaScript module

Named exports:

- `SitelenRenderer`
- `NanpaParser`

The default export is `SitelenRenderer`.

### `SitelenRenderer` static surface

- `create(config?)`
- `registerRenderAdapter(id, adapter)`
- `unregisterRenderAdapter(id)`
- `hasRenderAdapter(id)`
- `getDefaultRenderAdapterId()`
- `NanpaParser`

The default render-adapter ID is `identity`.

### Renderer instance surface

`await SitelenRenderer.create(config?)` returns an instance exposing:

- `parseInput({ input, parser? })`
- `buildRenderPlan({ input?, ast?, layout?, paint?, parser?, fonts? })`
- `renderRunToNewCanvas({ run, supersampleScale?, downsample? })`
- `renderTextToNewCanvas(options?)`
- `renderTextToCanvas(options?)`
- `renderUcsurToNewCanvas(options?)`
- `renderUcsurToCanvas(options?)`

The render-plan API separates canonical semantic codepoints from font-adapted render codepoints and records adapter/mapping metadata where applicable.

## Default-option contract

The integrated-profile defaults are normative and are listed in `PARSER-RENDERER-PROFILE.md` and `conformance/parser-renderer-profile-v1.1.0.json`.

The Core-v1 operation map remains language-neutral. Canvas-specific renderer methods are part of the integrated JavaScript reference API, not additional Core-v1 numeric operations.
