# Integrated Parser/Renderer Profile v1.1

This profile specifies the public document-parser and renderer behavior added to Protocol v1.1.0. It is layered on the unchanged Core-v1 numeric contract.

## Defaults

When the caller provides no contradictory option, the profile uses:

- `numericMode: uniform`
- `relaxedNanpaLinjanParsing: true`
- `relaxedNanpaLinjanRendering: true`
- effective nanpa-format parsing: true
- `nanpaColonRendering: true`
- `abbreviateNumericCartouches: true`
- `preserveNumericCartoucheBreaksInAbbreviation: false`
- `breakLinesAtFullStops: false`
- `interpretDoubleQuotesAsTeTo: false`
- `enableHexParsing: false`
- `enableBinaryParsing: false`
- `enableBinaryRendering: false`
- `nasinNanpaPona: false`
- default font render adapter: `identity`

The machine-readable source of these requirements is `conformance/parser-renderer-profile-v1.1.0.json`.

## Standard Sitelen Pona ASCII core

`standard-sitelen-pona-ascii-core` accepts the profile's standard core constructions:

- `pi(words)` for long pi;
- `word-word` for stacking;
- `word+word` for scaling/nesting;
- `word&word` for generic/font-defined ZWJ composition;
- `|` for ideographic/full-width space;
- ordinary `[ ... ]` cartouches.

Compound chains are accepted. Convenience textual aliases and legacy long-pi aliases are not preprocessed in this mode. The project intentionally retains explicit `U+...` raw-codepoint input as an extension.

## Extended ASCII mode

`sitelen-pona-ascii-extended` retains the modern compound operators `&`, `-`, and `+` and also accepts compatibility long-pi/cartouche aliases required by current supported fonts. These aliases are compatibility syntax, not a replacement for canonical UCSUR semantics.

## sitelen seli kiwen mode

`sitelen-seli-kiwen` supports generic forward extended glyphs `head(words)`, reverse forms `{words} head`, and bidirectional forms `{left words} head(right words)`, together with compound operators.

## Text aliases

Outside `standard-sitelen-pona-ascii-core`, the convenience aliases recorded by the machine-readable profile may be expanded before parsing. These include aliases for cartouche boundaries, joiners, long-glyph boundaries, corner brackets, middle dot, colon, tally, and ideographic space.

## Raw Unicode

Explicit `U+...` sequences are parsed as raw codepoints. Horizontal whitespace between consecutive valid `U+...` escapes belongs to the source syntax and is omitted from the emitted codepoint run. Raw UCSUR runs bypass font-specific render adapters by default.

## Font render adapters

The default adapter is `identity`. Current built-in adapters are:

- `linja-pona-legacy-v1`
- `linja-sike-legacy-v1`
- `nasin-sitelen-pu-mono-v1`
- `linja-lipamanka-v1`

Adapters translate canonical codepoints only at render time. Parser semantics remain font-independent. The render plan exposes canonical and rendered codepoint streams and mapping metadata.

Legacy linja pona/linja sike corner brackets may be synthesized by the renderer for U+300C/U+300D as recorded in the production manifest.

## Render plan metadata

Where applicable, the current render plan records canonical codepoints, rendered codepoints, canonical-to-render spans, requested/effective adapter IDs, long-glyph presentation, and per-glyph audio geometry. Consumers must use canonical fields for semantic interpretation and rendered fields for font-specific drawing.

## Cartouche scaling

The canonical v1.1 renderer does not automatically switch `ss12`/`ss13`/`ss14`. Production fonts opt into inline cartouche scale controls using the vulgar fractions `¼`, `⅓`, `½`, `⅔`, and `¾` where supported. This keeps scaling behavior independent of legacy stylistic-set features.
