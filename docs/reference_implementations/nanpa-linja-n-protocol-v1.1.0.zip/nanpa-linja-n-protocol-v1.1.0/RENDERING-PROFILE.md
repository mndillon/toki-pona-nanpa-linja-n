# Production Rendering Profile v1.1

This profile is layered on Core-v1 and the integrated Parser/Renderer Profile v1.1. It does not redefine numeric values.

## Normative profile inputs

- `rendering/production-font-pairs.manifest.json`: schema-2 production font pairs and adapter metadata.
- `rendering/font-golden-cases-v1.1.0.json`: sixteen logical full/abbreviated rendering cases.

Production manifest SHA-256: `50b8a4b6cab0c27f2061f94e404a2af992cbf95c8097c58caa5e6b2dc4625f09`.

## Font-pair contract

The manifest is authoritative for each pair's:

- parser mode;
- base/companion families and filenames;
- optional render adapter and adapter settings;
- comma/tally rendering mode;
- inline vulgar-fraction cartouche behavior;
- optional legacy-scale emulation;
- literal-cartouche family and clipping rules;
- support metadata and licensing references.

All current supplied pairs use `sitelen-pona-ascii-extended` as their parser mode.

## Render adapters

The supplied production manifest uses the built-in adapter IDs `linja-pona-legacy-v1`, `linja-sike-legacy-v1`, `nasin-sitelen-pu-mono-v1`, and `linja-lipamanka-v1` where translation is required. Other pairs use the identity path.

Legacy linja pona and linja sike use renderer-synthetic U+300C/U+300D corner brackets as recorded by the manifest.

## Cartouche scaling

Current production entries opt into `cartoucheVulgarFractions: true` and set `emulateLegacyCartoucheScaling: false`.

The canonical renderer's automatic legacy stylistic-set selection is disabled. Therefore `ss12`, `ss13`, and `ss14` are **not required** by Production-Font-Profile-v1.1.

The recognized inline scale controls are `¼`, `⅓`, `½`, `⅔`, and `¾`. Font size alone does not imply a stylistic-set feature.

## Logical visual cases

The 16 logical cases cover decimal, date, time, `toki`-started decimal numeric, hexadecimal, binary, and size-specific decimal output in explicit full and abbreviated modes.

With 8 production pairs, a complete implementation-specific visual matrix would contain 128 artifacts.

## Visual baseline status

No current v1.1 SVG/PNG/PDF golden artifact set was supplied with this update. The previously bundled 128 JavaScript SVG artifacts are retained only as historical v1.0.1 evidence.

Cross-renderer output bytes are not protocol values. Current certification requires implementation-specific approval against a v1.1 baseline; it must not be inferred from historical artifacts.
