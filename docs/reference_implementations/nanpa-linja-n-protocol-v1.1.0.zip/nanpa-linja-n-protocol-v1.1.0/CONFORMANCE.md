# Conformance classes — Protocol v1.1.0

## Core-v1

Required: independently pass the frozen language-neutral `conformance/nanpa-linja-n-regression-v1.0.2.json` corpus. Protocol v1.1.0 preserves this corpus byte-for-byte from v1.0.1.

The corpus has 320 parser cases, 15 renderer/public-output cases, 9 auxiliary API cases, 8 equivalence groups, and 1030 checks in the historical JavaScript Core runner.

## Binding-v1

Required: expose or document a one-to-one mapping for all 35 Core-v1 operations and their required result contracts.

## Parser-Renderer-Profile-v1.1

Required in addition to Core-v1:

- implement the default-option contract in `conformance/parser-renderer-profile-v1.1.0.json`;
- implement the named parser-mode behavior claimed by the binding;
- preserve canonical-vs-rendered codepoint separation when font adapters are used;
- use `identity` as the default adapter;
- preserve fixed decimal/hex/binary namespace boundaries;
- preserve the no-internal-whitespace digit rule;
- use abbreviated numeric cartouche display by default unless explicitly disabled.

The supplied canonical JavaScript source SHA-256 is `fdeb3e3bfd46b9f86650fd411a2d1dfb2515580aa258aa8c11a002913631418c`. The v1.1 profile includes 16 source-validated `NanpaParser` smoke cases.

## Production-Font-Profile-v1.1

Required: use the exact schema-2 `rendering/production-font-pairs.manifest.json` semantics for the production font pair being claimed, including its parser mode, render-adapter ID/settings, tally mode, cartouche scaling settings, literal-cartouche family, and support metadata.

The current manifest has 8 production font pairs and SHA-256 `50b8a4b6cab0c27f2061f94e404a2af992cbf95c8097c58caa5e6b2dc4625f09`.

Protocol v1.1 does **not** require `ss12`, `ss13`, or `ss14`. Inline vulgar-fraction cartouche controls are the current production path where enabled.

## Visual-Regression-Certified-v1.1

A renderer/font combination may claim current visual certification only against a newly approved v1.1 baseline for `rendering/font-golden-cases-v1.1.0.json`.

The protocol bundle does not contain such a newly generated current baseline. The retained 128 SVG artifacts are historical v1.0.1 evidence and must not be represented as current v1.1 certification.

## Validation performed for this release

- canonical JavaScript SHA-256 pinned;
- public `NanpaParser` operation count verified as 35;
- current `SitelenRenderer` static surface verified;
- 16/16 pure `NanpaParser` smoke cases passed against the supplied source;
- Core-v1 corpus identity preserved;
- production manifest JSON and adapter/settings inventory validated;
- 16 logical v1.1 rendering cases validated structurally;
- release-manifest hashes regenerated and checked.

A product may claim only the conformance classes it actually runs.
