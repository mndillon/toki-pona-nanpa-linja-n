# Versioning and freeze policy

Protocol versions use semantic versioning.

- **MAJOR**: a change to already-frozen Core semantics that can alter acceptance/rejection, canonical caps/proper name, semantic classification, namespace boundary, required output fields, or required default semantics of an existing normative profile.
- **MINOR**: a backward-compatible protocol extension, including a new optional/named conformance profile, additional parser mode, renderer capability, adapter contract, or production profile that leaves the frozen older Core contract available unchanged.
- **PATCH**: documentation, metadata, schema, evidence, or additional vectors that do not change any normative behavior.

Reference implementations are versioned independently from the protocol.

## Change procedure

1. State the proposed behavior in prose and machine-readable form.
2. Add or update external conformance/profile vectors.
3. Validate the supplied reference implementation(s) against the proposed scope.
4. Select the semantic-version bump according to the affected normative surface.
5. Regenerate the release manifest and SHA-256 inventory.
6. Freeze the release.

No implementation becomes an oracle merely because it is newer; a release must explicitly promote behavior into a normative protocol/profile contract.

## Protocol v1.1.0 classification

Protocol v1.1.0 is a **MINOR** release because it preserves the v1.0.1 Core-v1 numeric contract and its frozen v1.0.2 corpus, while adding a new normative integrated parser/renderer profile and Production-Font-Profile-v1.1.

The integrated profile defines defaults that were not previously part of the frozen Core-v1 language-neutral operation contract: relaxed parsing/rendering, nanpa-format parsing/rendering, uniform numeric mode, abbreviated numeric-cartouche display, physical-line preservation, quote interpretation opt-in, and optional hexadecimal/binary parsing.

An implementation claiming only Core-v1 may continue to implement the older frozen operation contract. An implementation claiming Parser-Renderer-Profile-v1.1 must implement the v1.1 profile defaults and mode behavior.
