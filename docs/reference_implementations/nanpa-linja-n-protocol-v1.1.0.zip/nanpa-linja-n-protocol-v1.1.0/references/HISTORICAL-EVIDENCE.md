# Historical v1.0.1 evidence retained in Protocol v1.1.0

The following files are retained for traceability only and do **not** constitute current Protocol v1.1.0 parser/renderer or visual certification:

- `javascript-canonical-syntax-v1.0.1.json`
- `javascript-full-renderer-canonical-v1.0.1.json`
- `javascript-goldens.sha256.json`
- `javascript-svg-golden-cases.json`
- `javascript-svg-goldens.manifest.json`
- `javascript-suite-reference-hashes.json`

Those records describe the previously pinned v1.0.1 JavaScript/package/font baseline, including legacy artifact names containing `ss12` and `ss13`.

Protocol v1.1.0 instead pins `references/canonical/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js` for the integrated parser/renderer profile and uses the current schema-2 production font manifest. A fresh v1.1 visual baseline is intentionally not claimed by this bundle.
