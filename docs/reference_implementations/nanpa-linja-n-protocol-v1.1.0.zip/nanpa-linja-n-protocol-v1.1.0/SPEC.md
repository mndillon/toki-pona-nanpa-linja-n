# nanpa-linja-n Protocol v1.1.0

Status: **final**  
Release baseline: **2026-09-25**

## 1. Normative authority

Core numeric semantics remain defined by:

- `SPEC.md`
- `protocol.json`
- `conformance/nanpa-linja-n-regression-v1.0.2.json`
- `conformance/nanpa-linja-n-regression.schema.json`

Protocol v1.1.0 additionally defines an integrated parser/renderer profile through:

- `PARSER-RENDERER-PROFILE.md`
- `conformance/parser-renderer-profile-v1.1.0.json`
- `RENDERING-PROFILE.md`
- `rendering/production-font-pairs.manifest.json`
- `rendering/font-golden-cases-v1.1.0.json`

The supplied canonical JavaScript parser/renderer is reference authority for the v1.1 integrated profile and is pinned by SHA-256 `fdeb3e3bfd46b9f86650fd411a2d1dfb2515580aa258aa8c11a002913631418c`. Source code is not itself a substitute for the normative prose and machine-readable profile.

## 2. Core-v1 compatibility

The Core-v1 35-operation language-neutral map and the v1.0.2 regression corpus remain unchanged. Existing Core-v1 implementations do not become non-conforming merely because they do not expose the new integrated text-renderer profile.

## 3. Decimal digit systems

Strict syllables: `0 NI, 1 WE, 2 TE, 3 SE, 4 NA, 5 LE, 6 NU, 7 ME, 8 PE, 9 JE`.

Relaxed syllables: `0 NI, 1 WA, 2 TU, 3 SE, 4 NA, 5 LU, 6 NU, 7 MU, 8 PI, 9 JO`.

In the v1.1 integrated profile, relaxed parsing and relaxed rendering default to **true**. Explicit false values request strict behavior.

## 4. Numeric mode and nanpa format defaults

The integrated profile defaults `numericMode` to **uniform** unless `traditional` is explicitly selected.

`nanpaColonRendering` defaults true. Effective nanpa-colon parsing is therefore also true unless the caller explicitly disables rendering and parsing. Ordinary decimal output consequently uses the nanpa-format head syntax by default.

## 5. Numeric cartouche display default

The integrated renderer defaults `abbreviateNumericCartouches` to **true**. A caller may explicitly set it false for full numeric cartouches.

`preserveNumericCartoucheBreaksInAbbreviation` defaults false. When enabled, a full internal break may be represented by visible `e` in the abbreviated cartouche.

This display default belongs to the v1.1 integrated profile; it does not rewrite the frozen Core-v1 conversion vectors.

## 6. Numeric namespaces and boundaries

- Decimal numeric cartouches may start with `nanpa`, `tenpo`, `suno`, or `toki` and close with `nanpa`.
- Hexadecimal opens/closes with `nasa` only.
- Binary opens/closes with `noka` only.
- A source/default `Toki`/`toki` start remains a decimal number; it is not a separate telephone datatype.
- A single-number `Suno` form 1..31 remains numeric rather than a date object.

Starting-glyph precedence remains: explicit caller override; source-provided/default start; date/time semantic default; ordinary `nanpa` default.

## 7. Date and time semantics

Recognized dates and times use `semanticKind` values `date` and `time` and default to `suno`/`tenpo` heads respectively while retaining `nanpa` as the decimal closer.

Yearless date input requires the leading marker form `--MM-DD` (or the other yearless form already frozen by the Core corpus). Bare `MM-DD`, such as `02-29`, is **not** a yearless-date input and may be interpreted by another numeric grammar.

The detailed compatibility cases for date/time ranges and fall-through remain those frozen by the Core-v1 corpus.

## 8. Digit-based whitespace

Internal whitespace terminates digit-based numeric syntax. `12 34` is not one decimal number; `1 1/2` is not a mixed fraction. The compact mixed-fraction form is `1+1/2`.

This does not prohibit spaces inside numeric proper names or numeric cartouches and does not prohibit a document parser from recognizing multiple whitespace-separated numbers.

## 9. Hexadecimal and binary

Hexadecimal parsing is opt-in with `enableHexParsing`. Its canonical prefix syntax starts with `#`; the namespace has fixed `nasa...nasa` boundaries.

Binary parsing is opt-in with `enableBinaryParsing` (or implied by binary rendering where the implementation exposes that configuration). Prefix syntax uses lowercase `0b`; uppercase `0B` is not part of the current canonical prefix grammar. The namespace has fixed `noka...noka` boundaries.

Decimal start-glyph overrides do not alter fixed hexadecimal or binary namespace boundaries.

## 10. Text parser modes

Protocol v1.1 defines the named modes in `PARSER-RENDERER-PROFILE.md`:

- `standard-sitelen-pona-ascii-core`
- `sitelen-pona-ascii-extended`
- `sitelen-seli-kiwen`

The standard core mode does not apply convenience text-alias preprocessing. The extended modes may recognize additional long-glyph/legacy aliases as specified by the profile.

## 11. Quotation and line splitting

`interpretDoubleQuotesAsTeTo` defaults false. Quotation marks therefore retain ordinary quote handling unless interpretation is explicitly requested.

`breakLinesAtFullStops` defaults false. The integrated parser preserves physical input lines by default. When enabled, sentence full stops can split rendered lines, excluding numeric decimal points and protected bracket/quote/parenthesis contexts.

## 12. Rendering adapters

The integrated renderer uses an `identity` adapter by default and supports a render-adapter registry. The current built-in production adapter IDs are listed by `protocol.json` and the production manifest.

Canonical codepoints remain parser-level semantics. A font adapter may translate those codepoints to a font-specific render sequence while retaining canonical-to-render span metadata. Raw UCSUR input and literal runs bypass font adaptation by default unless explicitly configured otherwise.

If an adapter fails or returns an invalid sequence, the current profile falls back to the identity sequence rather than corrupting the canonical semantic stream.

## 13. Cartouche scaling and tallies

Current production fonts use per-font `cartoucheVulgarFractions` where supported. The scale-control characters are `¼`, `⅓`, `½`, `⅔`, and `¾`.

Legacy automatic stylistic-set switching (`ss12`, `ss13`, `ss14`) is disabled in the canonical v1.1 renderer and is **not** a Protocol v1.1 font-conformance requirement. `emulateLegacyCartoucheScaling` remains an explicit migration option but is false for the supplied production manifest.

Tally behavior is font/profile-specific (`ucsur`, literal comma, or renderer-manual) and is recorded in the production manifest.

## 14. Public operations and integrated API

The 35 Core-v1 `NanpaParser` operation names remain frozen. Protocol v1.1 additionally records the `SitelenRenderer` static API and renderer-instance methods in `API.md`.

## 15. Conformance

A `Core-v1` claim requires the frozen v1.0.2 corpus. A `Parser-Renderer-Profile-v1.1` claim additionally requires the profile invariants and default behavior in `conformance/parser-renderer-profile-v1.1.0.json`. A production font-profile claim also requires the supplied schema-2 production manifest.

Current visual certification is separate; historical v1.0.1 SVG evidence cannot be relabeled as a current v1.1.0 visual baseline.
