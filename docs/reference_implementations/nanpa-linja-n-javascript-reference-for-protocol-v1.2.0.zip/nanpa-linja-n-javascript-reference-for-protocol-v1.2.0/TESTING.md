# JavaScript reference qualification — Protocol v1.2.0

The JavaScript reference uses executable regression/conformance tests. `npm test` is non-fail-fast: it runs every configured suite, reports each stage independently, and writes `test-output/javascript-regression-report.txt`.

## Qualification matrix

1. **Reference hashes** — verifies the pinned v1.2 canonical parser/renderer and retained reference modules.
2. **Fixture validation** — validates machine-readable fixture structure, including the runtime font-resource profile.
3. **Conformance validation** — validates the carried-forward syntax/full-renderer data plus the normative v1.2 parser profile and 24-case parser/renderer corpus.
4. **API surface** — checks facade and advanced exports plus required instance methods.
5. **Frozen Core-v1 protocol regression** — reruns the complete Core numeric corpus unchanged: 1,030 checks.
6. **Protocol v1.2 integrated profile** — checks v1.2 defaults, exact canonical JavaScript hash, the 35-operation `NanpaParser` surface, 16 profile smoke cases, render-adapter availability, runtime font-resource identity, and production pair invariants.
7. **Protocol v1.2 parser/renderer regressions** — executes the 24 normative cases in Chromium: 10 full-stop, 12 direct-CSP/UCSUR, and 2 quote-escape cases.
8. **`astToText` / `parseNumber` regression** — checks source/proper-name/`#~`/full/abbreviated serialization and `nasinNanpaPona` facade behavior.
9. **Browser core/facade/vector regression** — exercises the browser facade, raster PNG output, SVG/PDF vector export, parser flags, render plans, font adapters, and image-neutral parsing.
10. **Canonical syntax + adapters** — checks 28 standard/extended syntax cases and 5 legacy font-adapter cases.
11. **Canonical full renderer** — checks 254 renderer cases against the v1.2 canonical source. The former v1.1 middle-dot alias expectation is updated only where it conflicts with v1.2 full-stop semantics.
12. **Asset inspection** — checks bundled runtime asset presence and metadata.
13. **Font files / OpenType coverage** — verifies production font files and required cmap coverage, including inline vulgar-fraction cartouche scale controls for opted-in pairs.
14. **Browser production fonts** — loads every production font pair through the real `FontFace`/controller path and exercises pair-specific renderer settings/adapters.
15. **SVG production goldens** — compares 128 production SVG artifacts and verifies real vector path output with no embedded raster fallback.

## Commands

```bash
npm test
npm run verify:references
npm run validate:fixtures
npm run validate:conformance
npm run test:api
npm run test:protocol
npm run test:profile
npm run test:parser-v1.2
npm run test:ast
npm run test:browser
npm run test:canonical-syntax
npm run test:canonical-full
npm run test:assets
npm run test:fonts
npm run test:svg
```

## v1.2 parser regression contract

`protocol/conformance/parser-renderer-regression-v1.2.0.json` is language-neutral. The JavaScript runner compares:

- AST `normalizedInput`, source-line text, segment kinds/values, `canonicalSourceText`, and `sourceEncoding` where present;
- ordered non-gap element kinds;
- flattened canonical codepoints;
- literal text payloads;
- cartouche classification (`ordinary`, `literal`, `number`);
- semantic equivalence to `equivalentCanonicalInput` where the corpus supplies one.

## Regression boundary

The v1.2 migration must not change the frozen 35-operation Core API, numeric syllables, numeric/date/time namespace semantics, digit-whitespace rules, abbreviation defaults, render-adapter IDs/contracts, vulgar-fraction production scaling behavior, or vector-output requirements except where the v1.2 canonical JavaScript itself explicitly differs.

## Vector-output requirement

For generated numeric-cartouche content:

- SVG must remain true vector output. The tests require path geometry and reject `<image>` and `data:image` raster fallback.
- PDF must remain resolution-independent vector content; browser regression rejects raster Image XObjects for generated output.
- PNG is intentionally raster and is validated by file signature and successful rendering.

## Font-resource requirement

`resources/fonts.zip` is the exact font archive supplied for the new reference implementations (SHA-256 `50c0375469508e806d2a6bb1ce555fa81adb72f73a497ddf7d26e4150671b209`). `assets/fonts/` is its runtime extraction. The current runtime manifest hash is `d8021c7e83d33b776a1e68c70d6adea11956ae88e5fff1baf67926dd1d6833f6`.

The protocol's frozen Production-Font-Profile-v1.1 manifest remains included under `protocol/rendering/` as protocol evidence; the JavaScript package does not roll its newer supplied runtime assets back to that older physical resource revision.

## Golden updates

Production SVG goldens must only be regenerated deliberately:

```bash
npm run goldens:update
```

For this v1.2 release the 128 SVG files did **not** change; only `goldens/svg-manifest.json` was updated to accept the supplied runtime manifest revision.
