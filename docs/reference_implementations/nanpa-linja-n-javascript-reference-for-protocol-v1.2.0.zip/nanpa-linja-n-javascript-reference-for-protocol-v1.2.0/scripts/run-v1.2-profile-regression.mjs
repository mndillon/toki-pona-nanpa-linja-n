#!/usr/bin/env node
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { SitelenRenderer, NanpaParser } from '../reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js';
import { DEFAULT_PARSER_CONFIG } from '../src/nanpa-linja-n.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const profile = JSON.parse(fs.readFileSync(path.join(root, 'protocol/conformance/parser-renderer-profile-v1.2.0.json'), 'utf8'));
const regression = JSON.parse(fs.readFileSync(path.join(root, 'protocol/conformance/parser-renderer-regression-v1.2.0.json'), 'utf8'));
const resourceProfile = JSON.parse(fs.readFileSync(path.join(root, 'fixtures/font-resource-profile-v1.2.0.json'), 'utf8'));
const sourcePath = path.join(root, 'reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js');
const source = fs.readFileSync(sourcePath, 'utf8');
const manifestPath = path.join(root, 'assets/fonts/preloaded-font-pairs.manifest.json');
const manifestBytes = fs.readFileSync(manifestPath);
const manifest = JSON.parse(manifestBytes.toString('utf8'));
const sha256 = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
let checks = 0;
const check = (condition, message) => { assert.ok(condition, message); checks++; };
const same = (a,b) => JSON.stringify(a) === JSON.stringify(b);

check(profile.profileVersion === '1.2.0', 'profileVersion');
check(sha256(fs.readFileSync(sourcePath)) === profile.canonicalJavaScript.sha256, 'canonical JavaScript hash');
check(regression.protocolVersion === '1.2.0', 'regression version');
check(regression.caseCount === 24 && regression.cases.length === 24, 'v1.2 regression case count');
check(sha256(fs.readFileSync(path.join(root, profile.normativeRegressionCorpus.path.replace(/^conformance\//, 'protocol/conformance/')))) === profile.normativeRegressionCorpus.sha256, 'v1.2 regression corpus hash');

// The Protocol v1.2 profile records its frozen production manifest. This JavaScript
// reference release deliberately uses the separately supplied current font bundle.
// Preserve the protocol's behavioral font contract while validating the runtime
// resource revision by its own release fixture instead of rolling it back.
check(manifest.schema === profile.productionManifest.schema, 'runtime production manifest schema');
check(manifest.pairs.length === profile.productionManifest.fontPairCount, 'runtime production font pair count');
check(sha256(manifestBytes) === resourceProfile.runtimeManifest.sha256, 'runtime production manifest resource hash');
check(sha256(fs.readFileSync(path.join(root, resourceProfile.suppliedFontsZip.path))) === resourceProfile.suppliedFontsZip.sha256, 'supplied fonts.zip resource hash');

const expectedNanpaOps = [
  'parseNumber','encodeDecimal','decimalToUcsurCodepoints','properNameToUcsurCodepoints','splitCapsToProperName','capsToUniqueCode','decodeCaps','ucsurCodepointsToTpWords','codepointsToWords','tpWordsToText','parseTpWordsToCodepoints','tpWordsToUcsurCodepoints','codepointsToHex','codepointsToHexWithCartouche','parseHexCodepoints','withCartoucheMarkers','stripCartoucheMarkers','isValidCaps','isValidProperName','isValidTimeOrDate','isValidTime','isValidDate','tokenizeCaps','capsTokensToTpWords','capsToWords','capsToCodepoints','parseIdentifier','normalizeVulgarFraction','normalizeTpWord','getSmallCodepointsSet','getQuarterCodepointsSet','getOneThirdCodepointsSet','getTwoThirdsCodepointsSet','getHalfCodepointsSet','isAllowedTpUcsurCodepoint'
].sort();
check(same(Object.keys(NanpaParser).sort(), expectedNanpaOps), 'NanpaParser 35-operation surface');
const expectedStatic = ['create','registerRenderAdapter','unregisterRenderAdapter','hasRenderAdapter','getDefaultRenderAdapterId','NanpaParser'].sort();
check(same(Object.keys(SitelenRenderer).sort(), expectedStatic), 'SitelenRenderer static surface');
check(SitelenRenderer.getDefaultRenderAdapterId() === 'identity', 'default render adapter');
for (const id of profile.renderAdapters.builtIn) check(SitelenRenderer.hasRenderAdapter(id) === true, `built-in render adapter ${id}`);

const defaults = profile.defaults;
const facadeDefaults = {
  numericMode: DEFAULT_PARSER_CONFIG.numericMode,
  relaxedNanpaLinjanParsing: DEFAULT_PARSER_CONFIG.relaxedNanpaLinjanParsing,
  relaxedNanpaLinjanRendering: DEFAULT_PARSER_CONFIG.relaxedNanpaLinjanRendering,
  nanpaColonParsingEffective: DEFAULT_PARSER_CONFIG.nanpaColonParsing,
  nanpaColonRendering: DEFAULT_PARSER_CONFIG.nanpaColonRendering,
  abbreviateNumericCartouches: DEFAULT_PARSER_CONFIG.abbreviateNumericCartouches,
  preserveNumericCartoucheBreaksInAbbreviation: DEFAULT_PARSER_CONFIG.preserveNumericCartoucheBreaksInAbbreviation,
  breakLinesAtFullStops: DEFAULT_PARSER_CONFIG.breakLinesAtFullStops,
  interpretDoubleQuotesAsTeTo: DEFAULT_PARSER_CONFIG.interpretDoubleQuotesAsTeTo,
  numericCartoucheStartGlyph: DEFAULT_PARSER_CONFIG.numericCartoucheStartGlyph,
  enableHexParsing: DEFAULT_PARSER_CONFIG.enableHexParsing,
  enableBinaryParsing: DEFAULT_PARSER_CONFIG.enableBinaryParsing,
  enableBinaryRendering: DEFAULT_PARSER_CONFIG.enableBinaryRendering,
  nasinNanpaPona: DEFAULT_PARSER_CONFIG.nasinNanpaPona,
};
for (const [key, value] of Object.entries(facadeDefaults)) check(same(value, defaults[key]), `facade default ${key}`);

const staticNeedles = [
  'let __abbreviateNumericCartouches = true;',
  'let __relaxedNanpaLinjanParsing = true;',
  'let __relaxedNanpaLinjanRendering = true;',
  'let __nanpaColonParsing = true;',
  'let __nanpaColonRendering = true;',
  'let __enableHexParsing = false;',
  'let __enableBinaryParsing = false;',
  'let __enableBinaryRendering = false;',
  'let __nasinNanpaPona = false;',
  'let __cartoucheVulgarFractions = false;',
  'let __emulateLegacyCartoucheScaling = false;',
  'breakLinesAtFullStops: false',
  'const CARTOUCHE_SCALE_STYLISTIC_FEATURES_ENABLED = false;',
  "const STANDARD_SITELEN_PONA_ASCII_CORE_MODE = 'standard-sitelen-pona-ascii-core';",
  "const SITELEN_PONA_ASCII_EXTENDED_MODE = 'sitelen-pona-ascii-extended';",
  "__fontRenderAdapters.set('linja-pona-legacy-v1'",
  "__fontRenderAdapters.set('linja-sike-legacy-v1'",
  "__fontRenderAdapters.set('nasin-sitelen-pu-mono-v1'",
  "__fontRenderAdapters.set('linja-lipamanka-v1'",
  'function isBackslashEscapedAt(text, index)',
  'const CSP_INPUT_TRIGGER_RE = /[\\u200D\\u3000\\u300C\\u300D',
  'function canonicalizeCspUnicodeInputLine(input, parser = {})',
  "sourceEncoding: 'mixed-csp-unicode'",
  'const tokenRe = /\\.|[^\\s.'
];
for (const needle of staticNeedles) check(source.includes(needle), `source invariant ${needle}`);

function pick(r) {
  if (r == null) return null;
  return {
    caps:r.caps ?? null, kind:r.kind ?? 'decimal', numberBase:r.numberBase ?? 10,
    properName:r.properName ?? null, uniqueCode:r.uniqueCode ?? null, displayValue:r.displayValue ?? null,
    semanticKind:r.semanticKind ?? null, semanticStartGlyph:r.semanticStartGlyph ?? null,
    isDate:!!r.isDate, isTime:!!r.isTime, numericMode:r.numericMode ?? null,
    tpWords:Array.isArray(r.tpWords) ? r.tpWords : null,
    abbreviatedWords:Array.isArray(r.abbreviatedWords) ? r.abbreviatedWords : null,
  };
}
for (const c of profile.nanpaParserSmokeCases) {
  let got = null, error = null;
  try { got = pick(NanpaParser.parseNumber(c.input, c.options || {})); } catch (e) { error = e.message; }
  check(error === c.error && same(got, c.result), `NanpaParser smoke case ${c.id}`);
}

const pairModes = [...new Set(manifest.pairs.map(p => p.parserMode))].sort();
check(same(pairModes, [...profile.productionManifest.parserModes].sort()), 'runtime manifest parser modes');
const pairAdapters = [...new Set(manifest.pairs.map(p => p.renderAdapterId).filter(Boolean))].sort();
check(same(pairAdapters, [...profile.productionManifest.renderAdapterIds].sort()), 'runtime manifest adapter IDs');
for (const pair of manifest.pairs) {
  check(pair.settings?.cartoucheVulgarFractions === true, `${pair.fontKey} cartoucheVulgarFractions`);
  check(pair.settings?.emulateLegacyCartoucheScaling === false, `${pair.fontKey} emulateLegacyCartoucheScaling`);
}

check(fs.existsSync(path.join(root, 'assets/fonts/nanpa-linja-n-nasin-nanpa-sans-source-input-unchanged.ttf')), 'new source-input-unchanged font resource exists');
const nasinNanpaPair = manifest.pairs.find(p => p.fontKey === 'nasinNanpa');
const basePath = path.join(root, 'assets/fonts', nasinNanpaPair.baseFilename);
const literalPath = path.join(root, 'assets/fonts', nasinNanpaPair.literalCartoucheFilename);
check(fs.existsSync(basePath), 'nasinNanpa runtime base font exists');
check(fs.existsSync(literalPath), 'nasinNanpa runtime literal font exists');

console.log(`JavaScript protocol v1.2.0 integrated profile regression: ${checks} checks PASS`);
console.log(`NanpaParser profile smoke cases: ${profile.nanpaParserSmokeCases.length}/${profile.nanpaParserSmokeCases.length} PASS`);
console.log(`Parser/renderer v1.2 corpus inventory: ${regression.caseCount}/${regression.caseCount} cases present`);
console.log(`Production font pairs: ${manifest.pairs.length}/${manifest.pairs.length} behavioral invariants PASS`);
console.log(`Runtime font manifest resource revision: ${resourceProfile.runtimeManifest.sha256}`);
