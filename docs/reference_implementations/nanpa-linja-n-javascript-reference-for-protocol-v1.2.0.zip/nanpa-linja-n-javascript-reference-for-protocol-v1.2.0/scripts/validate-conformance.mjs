#!/usr/bin/env node
import fs from 'node:fs/promises';
import crypto from 'node:crypto';

const syntaxPath='conformance/canonical-syntax-v1.0.1-phase1/cases.json';
const fullPath='conformance/full-renderer-canonical-v1.2.0/cases.json';
const profilePath='protocol/conformance/parser-renderer-profile-v1.2.0.json';
const v12RegressionPath='protocol/conformance/parser-renderer-regression-v1.2.0.json';
const referencePath='reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js';
const syntax=JSON.parse(await fs.readFile(syntaxPath,'utf8'));
const full=JSON.parse(await fs.readFile(fullPath,'utf8'));
const profile=JSON.parse(await fs.readFile(profilePath,'utf8'));
const v12=JSON.parse(await fs.readFile(v12RegressionPath,'utf8'));
const hash=crypto.createHash('sha256').update(await fs.readFile(referencePath)).digest('hex');
const failures=[];
const requireCheck=(ok,msg)=>{if(!ok)failures.push(msg);};
requireCheck(Array.isArray(syntax.cases)&&syntax.cases.length===28,`canonical syntax case count: ${syntax.cases?.length} != 28`);
requireCheck(Array.isArray(syntax.fontAdapterCases)&&syntax.fontAdapterCases.length===5,`font adapter case count: ${syntax.fontAdapterCases?.length} != 5`);
requireCheck(syntax.authority?.sha256===hash,`canonical syntax authority hash ${syntax.authority?.sha256} != ${hash}`);
requireCheck(Array.isArray(full.cases)&&full.cases.length===254,`canonical full case count: ${full.cases?.length} != 254`);
requireCheck(full.caseCount===254,`canonical full declared caseCount: ${full.caseCount} != 254`);
requireCheck(full.authority?.sha256===hash,`canonical full authority hash ${full.authority?.sha256} != ${hash}`);
requireCheck(new Set((syntax.cases||[]).map(x=>x.id)).size===syntax.cases.length,'duplicate canonical syntax ids');
requireCheck(new Set((syntax.fontAdapterCases||[]).map(x=>x.id)).size===syntax.fontAdapterCases.length,'duplicate adapter ids');
requireCheck(new Set((full.cases||[]).map(x=>x.id)).size===full.cases.length,'duplicate canonical full ids');
requireCheck(profile.profileVersion==='1.2.0',`parser-renderer profile version: ${profile.profileVersion} != 1.2.0`);
requireCheck(profile.canonicalJavaScript?.sha256===hash,`v1.2 profile canonical JavaScript hash ${profile.canonicalJavaScript?.sha256} != ${hash}`);
requireCheck(v12.protocolVersion==='1.2.0',`v1.2 regression version: ${v12.protocolVersion} != 1.2.0`);
requireCheck(v12.caseCount===24 && Array.isArray(v12.cases) && v12.cases.length===24,`v1.2 parser/renderer case count: ${v12.cases?.length} != 24`);
requireCheck(new Set((v12.cases||[]).map(x=>x.id)).size===v12.cases.length,'duplicate v1.2 parser/renderer ids');
if(failures.length){for(const f of failures)console.error(`FAIL ${f}`);process.exit(1);}
console.log(`conformance validation: PASS (28 syntax + 5 adapters + 254 carried-forward full-renderer + 24 v1.2 parser/renderer; authority ${hash})`);
