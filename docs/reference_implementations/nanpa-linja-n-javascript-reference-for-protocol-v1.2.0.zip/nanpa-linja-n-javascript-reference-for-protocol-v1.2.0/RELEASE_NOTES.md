# JavaScript reference release — Protocol v1.2.0

This package upgrades the JavaScript reference implementation from Protocol v1.1.0 to **nanpa-linja-n Protocol v1.2.0** using the supplied current parser/renderer as the canonical behavioral baseline and the supplied `fonts.zip` as the runtime font-resource input.

## v1.2 behavior added

- Ordinary ASCII `.` is tokenized as sitelen pona punctuation U+F199C even when adjacent to words, while literal text/cartouches retain U+002E and numeric decimals retain decimal semantics.
- Directly pasted recognized Common Sitelen Pona/UCSUR input is canonicalized to normal parser syntax and reparsed semantically, with original `sourceText` retained and normalized metadata exposed as `canonicalSourceText` / `sourceEncoding: "mixed-csp-unicode"`.
- Explicit textual `U+...` input and dedicated raw UCSUR render APIs remain raw and bypass the new document-input canonicalizer.
- Closing-quote detection now uses consecutive-backslash parity: odd escapes, even closes.
- The normative 24-case v1.2 parser/renderer regression corpus is included and executable from the JavaScript package.

## Font resources

The runtime resource bundle is the newly supplied archive:

- `resources/fonts.zip` SHA-256: `50c0375469508e806d2a6bb1ce555fa81adb72f73a497ddf7d26e4150671b209`
- runtime manifest SHA-256: `d8021c7e83d33b776a1e68c70d6adea11956ae88e5fff1baf67926dd1d6833f6`

The archive adds `nanpa-linja-n-nasin-nanpa-sans-source-input-unchanged.ttf` and updates manifest revision metadata/NOTICE material. Existing production font faces used by the eight runtime pairs remain byte-identical to the v1.1 package, so the approved 128 SVG files remain unchanged.

## Qualification result

The release is qualified with 15 non-fail-fast suites. Key gates include:

- frozen Core numeric regression: 1,030 checks, 0 failures;
- v1.2 integrated profile: 91 checks, 16/16 `NanpaParser` smoke cases, 8/8 production pair behavioral invariants;
- v1.2 parser/renderer corpus: 24/24 cases, 61 browser checks;
- API surface: 32 checks;
- `astToText`: 26 checks;
- browser core/facade/vector: 145 checks;
- canonical syntax: 28/28 cases plus 5/5 adapter cases;
- canonical full renderer: 254/254 cases;
- production SVG goldens: 128/128 artifacts.

SVG/PDF tests continue to reject raster fallback for generated vector cartouche output.

## Compatibility

The frozen Core-v1 corpus, existing facade/API surface, font-controller behavior, render adapters, vector exporter, numeric defaults, and production visual baseline remain compatibility gates. The only carried-forward full-renderer oracle changed for v1.2 is the middle-dot/full-stop case that intentionally disagreed with the new canonical parser.

See `CHANGELOG.md`, `CHANGED_FILES.txt`, and `protocol/MIGRATION-v1.1-to-v1.2.md` for details.
