# nanpa-linja-n JavaScript reference for Protocol v1.2.0

This package is the JavaScript reference implementation for **nanpa-linja-n Protocol v1.2.0**. It preserves the frozen Core-v1 numeric semantics and all compatible v1.1 renderer/font/export behavior, while adopting the v1.2 parser changes for ordinary full stops, directly pasted Common Sitelen Pona/UCSUR input, and quote-escape parity.

## Protocol and canonical source

- Protocol target: `1.2.0`
- Canonical parser/renderer: `reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js`
- Canonical parser/renderer SHA-256: `6bfcb77e5177eec4d923bbd24d60dbac211e574b62e128e6dbfc07f8e859d220`
- Normative profile: `protocol/PARSER-RENDERER-PROFILE.md`
- Machine-readable profile: `protocol/conformance/parser-renderer-profile-v1.2.0.json`
- Normative v1.2 parser regression corpus: `protocol/conformance/parser-renderer-regression-v1.2.0.json`
- Migration checklist: `protocol/MIGRATION-v1.1-to-v1.2.md`
- Frozen Core-v1 corpus remains regression-tested and is not rewritten by this release.

## v1.2 default behavior

The v1.1 defaults are retained unchanged:

- parser mode: `sitelen-pona-ascii-extended`
- numeric mode: `uniform`
- relaxed nanpa-linja-n parsing: `true`
- relaxed nanpa-linja-n rendering: `true`
- nanpa-format parsing/rendering: `true`
- abbreviated numeric/date/time cartouches: `true`
- preserve internal numeric cartouche breaks in abbreviation: `false`
- break physical input lines at full stops: `false`
- interpret double quotes as `te` / `to`: `false`
- hexadecimal parsing: `false`
- binary parsing/rendering: `false`
- `nasinNanpaPona`: `false`
- render adapter: `identity`, unless selected by the active production font pair.

Hexadecimal and binary syntax therefore still require explicit opt-in parser options.

## v1.2 parser changes

### Ordinary full stop

ASCII `.` is now an ordinary sitelen pona punctuation token and maps to U+F199C even when adjacent to words:

- `toki . pona` and `toki.pona` produce the same canonical sequence;
- `[toki.pona]` uses U+F199C inside an ordinary cartouche;
- `[""toki.pona]` has the same ordinary-cartouche punctuation semantics;
- `"toki.pona"` and `["toki.pona"]` preserve literal U+002E;
- recognized numeric syntax such as `1.25` retains decimal-point semantics.

`breakLinesAtFullStops` remains independent and defaults to `false`.

### Direct CSP/UCSUR document input

Directly pasted recognized Common Sitelen Pona/UCSUR text is normalized to canonical parser syntax and then parsed through the existing semantic path. The original source line remains available as `sourceText`; when normalization changes it, the AST line also carries `canonicalSourceText` and `sourceEncoding: "mixed-csp-unicode"`.

Important mappings include:

- ordinary UCSUR word glyphs → preferred Toki Pona word names;
- U+200D → `&`;
- U+F1990/U+F1991 → `[` / `]`;
- U+F1995/U+F1996 → `-` / `+`;
- U+F1997/U+F1998 → `(` / `)`;
- U+F199A/U+F199B → `{` / `}`;
- U+F199C/U+F199D/U+F199E → `.` / `:` / `,`;
- U+3000 → `zz`;
- U+300C/U+300D and U+F19B4/U+F19B5 → `te` / `to`;
- U+F1989/U+F198A/U+F198B/U+F198C → `ni<` / `ni^` / `ni>` / `sewi^`;
- deprecated long-pi controls U+F1993/U+F1994 → current `pi(...)` semantics.

Direct Unicode normalization is deliberately different from explicit textual `U+...` input. Explicit `U+...` remains the raw-codepoint extension and bypasses font adapters by default. Dedicated raw UCSUR rendering APIs likewise remain raw.

### Quote escape parity

A candidate closing quote is escaped only when immediately preceded by an odd number of consecutive backslashes. An even-length backslash run does not escape the quote. The same rule is used by quote segmentation and by protected quoted ranges during direct Unicode normalization.

## Public facade

```js
import NanpaLinjaN, {
  NanpaParser,
  SitelenRenderer,
  astToText,
  parseNumber,
} from './src/nanpa-linja-n.js';

const api = await NanpaLinjaN.create();

const parsed = await api.parse('toki.pona');
console.log(parsed.ast);

const numeric = await api.parse('123');
console.log(api.astToText(numeric.ast, { numericOutput: 'abbreviatedCartouche' }));
console.log(parseNumber('123'));

const png = await api.renderToPng('123');
await api.destroy();
```

The facade instance provides:

`listFonts`, `getFontInfo`, `parse`, `astToText`, `parseNumber`, `buildRenderPlan`, `render`, `renderToCanvas`, `renderToPng`, `renderToSvg`, `renderToPdf`, and `destroy`.

The named `parseNumber(input, options?)` export delegates to the canonical `NanpaParser.parseNumber`.

### `astToText`

Supported numeric output modes include:

- `source`
- `properName`
- `#~`
- `fullCartouche`
- `abbreviatedCartouche`

With no explicit numeric-output override, numeric cartouche output follows the retained abbreviated-cartouche default. `nnpPonaFormat` / `nasinNanpaPona` conversion remains available for eligible ordinary Arabic numeric input.

## Parser modes and syntax

The v1.2 profile exposes:

- `standard-sitelen-pona-ascii-core`
- `sitelen-pona-ascii-extended`
- `sitelen-seli-kiwen`

Compound operators include `&` (ZWJ), `-` (stacking), and `+` (scaling/nesting). Decimal-digit numeric constructs terminate at whitespace. Yearless dates require `--MM-DD`; bare `MM-DD` is not a yearless-date input form. Double-quote interpretation as `te`/`to` remains opt-in, and `zz` remains the ideographic-space alias.

## Production fonts and render adapters

`assets/fonts/preloaded-font-pairs.manifest.json` is the current runtime schema-2 eight-pair manifest supplied for this reference release. Built-in renderer adapters remain:

- `linja-pona-legacy-v1`
- `linja-sike-legacy-v1`
- `nasin-sitelen-pu-mono-v1`
- `linja-lipamanka-v1`

The parser remains canonical/font-independent. Adapters translate canonical Common Sitelen Pona code points to the selected font's input contract at render time and retain canonical-to-render span metadata.

The active font pair's manifest `settings` are propagated into `fonts.settings`; this is required for per-font tally behavior, literal-cartouche clipping, long-pi tuning, and inline cartouche scaling.

### Supplied `fonts.zip`

`resources/fonts.zip` is preserved byte-for-byte from the font resource archive supplied for the v1.2 reference implementations:

- SHA-256: `50c0375469508e806d2a6bb1ce555fa81adb72f73a497ddf7d26e4150671b209`
- runtime manifest SHA-256: `d8021c7e83d33b776a1e68c70d6adea11956ae88e5fff1baf67926dd1d6833f6`

`assets/fonts/` is the extracted runtime copy. The archive also includes `nanpa-linja-n-nasin-nanpa-sans-source-input-unchanged.ttf`; it is retained even though the current runtime manifest does not select it as one of the eight production pair faces.

The normative Protocol v1.2 profile retains its frozen Production-Font-Profile-v1.1 manifest. This package does **not** roll the already-updated JavaScript resource set backward to that older physical asset revision. The implementation validates the runtime bundle separately in `fixtures/font-resource-profile-v1.2.0.json`; the logical pair count, parser modes, adapter IDs, and renderer settings remain compatible.

### Cartouche scaling

Automatic legacy `ss12`, `ss13`, or `ss14` selection remains disabled. Current production pairs use inline vulgar-fraction scale-control characters where enabled by `cartoucheVulgarFractions`:

- `¼` U+00BC
- `⅓` U+2153
- `½` U+00BD
- `⅔` U+2154
- `¾` U+00BE

## Vector exports

`renderToSvg` and `renderToPdf` use the production vector exporter when the bundled WASM/vector assets are available. The regression suite verifies that generated SVG numeric-cartouche output contains vector paths and no `<image>`/`data:image` raster fallback. PDF regression rejects raster `/Subtype /Image` XObjects for generated cartouche content.

PNG output is raster by design.

## Tests

Run the complete qualification suite:

```bash
npm test
```

The runner is non-fail-fast: all configured suites run and a consolidated report is written to `test-output/javascript-regression-report.txt`.

Important individual commands include:

```bash
npm run test:profile
npm run test:parser-v1.2
npm run test:protocol
npm run test:ast
npm run test:api
npm run test:browser
npm run test:canonical-syntax
npm run test:canonical-full
npm run test:fonts
npm run test:svg
```

See `TESTING.md` for the qualification matrix and `CHANGELOG.md` for the v1.2.0 changes.

## Package layout

- `src/` — stable JavaScript facade
- `reference/` — canonical renderer plus retained font controller and vector exporter
- `protocol/` — Protocol v1.2.0 specification/profile material used by this reference
- `conformance/` — frozen Core and carried-forward/full-renderer conformance data
- `assets/fonts/` — extracted runtime font resources and current manifest
- `resources/fonts.zip` — exact supplied font archive
- `fixtures/` — API/vector/reference/resource fixtures
- `goldens/` — production SVG golden outputs
- `harness/` — browser regression harness
- `scripts/` — executable validation/regression tooling
- `test-output/` — consolidated test report

## Release discipline

This v1.2.0 package is a controlled parser-profile update. Existing Core, numeric, font-adapter, vector-export, and production visual behavior is retained unless the supplied v1.2 canonical JavaScript explicitly changes it. The new parser behavior is covered by the 24-case normative v1.2 corpus, while all prior regression suites remain active as compatibility gates.
