# Changelog

## 1.2.0 — 2026-09-28

- Updated the JavaScript reference target from Protocol v1.1.0 to Protocol v1.2.0.
- Replaced the canonical parser/renderer with the supplied v1.2 JavaScript baseline and pinned SHA-256 `6bfcb77e5177eec4d923bbd24d60dbac211e574b62e128e6dbfc07f8e859d220`.
- Added ordinary full-stop parsing: U+002E maps to canonical U+F199C in ordinary text/cartouches, including adjacent forms such as `toki.pona`; literal U+002E and numeric decimal points retain their existing meanings.
- Added direct recognized Common Sitelen Pona/UCSUR document-input normalization, including word glyphs, cartouche/long controls, joiners, punctuation, ideographic space, corner brackets, ni/sewi alternates, te/to PUA forms, and deprecated long-pi normalization.
- Preserved explicit textual `U+...` and dedicated raw UCSUR rendering paths as raw input rather than routing them through the new canonicalizer.
- Updated quote parsing/protected-range detection to consecutive-backslash parity.
- Added the 24-case normative Parser-Renderer-Profile-v1.2 regression suite: 10 full-stop, 12 direct-CSP/UCSUR, and 2 quote-escape cases.
- Kept the 35-operation Core API, 1,030 frozen Core checks, parser defaults, numeric behavior, font adapters, vector exporter, and v1.1-compatible renderer behavior unchanged outside the v1.2 deltas.
- Updated the carried-forward 254-case full-renderer corpus only for the intentional v1.2 middle-dot/full-stop behavior and repinned it to the v1.2 canonical source.
- Replaced `resources/fonts.zip` and `assets/fonts/` with the newly supplied resource archive; added `nanpa-linja-n-nasin-nanpa-sans-source-input-unchanged.ttf` and updated runtime manifest/NOTICE metadata.
- Kept all 128 approved SVG outputs unchanged; only the SVG golden manifest's production-manifest hash changed for the supplied resource revision.
- Added an implementation resource-profile fixture so the newer runtime font bundle is validated separately from the protocol's frozen Production-Font-Profile-v1.1 evidence.

## 1.1.0 — 2026-09-25

- Updated the reference target to nanpa-linja-n Protocol v1.1.0.
- Replaced the canonical parser/renderer with the supplied v1.1 JavaScript baseline and pinned its SHA-256.
- Aligned default behavior with the v1.1 integrated profile: abbreviated numeric cartouches, relaxed parse/render, nanpa-format parse/render enabled; hexadecimal and binary recognition remain opt-in.
- Preserved the frozen Core-v1 numeric regression corpus as a compatibility gate.
- Added the v1.1 parser/renderer profile and executable profile regression suite.
- Propagated per-font manifest settings into renderer configuration and enabled current built-in render adapters.
- Replaced production font resources with the supplied fonts archive and current schema-2 eight-pair manifest.
- Disabled automatic legacy `ss12`/`ss13`/`ss14` cartouche scaling; current production pairs use inline vulgar-fraction scale controls where configured.
- Updated `astToText`/`parseNumber` facade behavior for the v1.1 abbreviated-cartouche default while retaining `nasinNanpaPona` facade conversion.
- Added side-effect-free numeric AST enrichment so parsing does not attempt to load `img(...)` resources.
- Updated the canonical full renderer corpus and regenerated 128 production SVG goldens for the v1.1 font/rendering profile.
- Strengthened SVG/PDF vector-output regression checks to reject raster fallback for generated cartouche content.

## 2026-09-20 — digit-based numeric whitespace baseline

- Internal whitespace is no longer accepted inside digit-based decimal, fraction, scientific, percent, date, or time input. Whitespace terminates the numeric token.
- `parseNumber()` requires one complete numeric expression (apart from outer whitespace), so `parseNumber("12 34")` returns `null`.
- Full document parsing continues to recognize `12` and `34` independently in `12 34`.
- Proper-name numeric input and numeric-cartouche input retain their intentional word-separating spaces.
- Replaced the obsolete `1 1/2` mixed-fraction regression with the valid `1+1/2` form.

## v0.1.9

- added a high-level browser developer facade at `src/nanpa-linja-n.js`
- added `renderToCanvas`, `renderToPng`, `renderToSvg`, `renderToPdf`, `parse`, and `buildRenderPlan` convenience methods
- exported the facade from the package root and added `./advanced` low-level re-exports
- added browser regression coverage for the new facade, including canvas, PNG, SVG, PDF, and legacy-adapter checks

# v0.1.8

- Requires exactly 8 full + 8 abbreviated SVG cases.
- Requires every abbreviated `-abbr` case to have a matching full case.
- Requires artifact count = production font-pair count × 16.
- Current expected total: 128 SVG artifacts (64 full + 64 abbreviated).
- A 64-artifact SVG run is now a hard failure rather than a false PASS.

## 0.1.7

- Expand the production SVG golden matrix from 8 to 16 cases per vector-enabled font pair: every existing case now has a matching `-abbr` case with `abbreviateNumericCartouches: true`.
- Preserve numeric cartouche breaks in abbreviated golden cases with `preserveNumericCartoucheBreaksInAbbreviation: true`.
- Apply the abbreviation flags per golden case instead of reusing one full-cartouche parser configuration for all SVG exports.
- Add a runtime regression guard for every abbreviated case: build the corresponding full render plan and require the abbreviated cartouche to be present, different from the full cartouche, and shorter.
- With the current eight production font pairs, the approved SVG baseline grows from 64 to 128 artifacts.
- Existing full-cartouche golden IDs and cases are retained unchanged; no parser, renderer, font-controller, vector-exporter, font, or production-manifest behavior is modified.

## 0.1.6

- Fix real vector-WASM initialization in the embedded browser harness.
- The browser runner now embeds `sitelen_vector_wasm_bg.wasm` as bytes, imports the wasm-bindgen JS wrapper, calls its default initializer with those bytes, and only then permits `healthcheck()` / vector export calls.
- This fixes the prior `TypeError: Cannot read properties of undefined (reading '__wbindgen_free')` produced when `healthcheck()` was called before wasm-bindgen initialization.
- The same initialized Blob-module URL remains the URL supplied to `SitelenVectorExporter`; repeated `default()` calls are safe because the generated wrapper returns the already initialized WASM instance.
- Fix the browser-font canvas probe to use the renderer's documented `{ canvas, ast, linesElements }` return object from `renderTextToNewCanvas()` instead of incorrectly treating that wrapper as a bare canvas.
- No parser, renderer, font-controller, vector-exporter, production manifest, font, or expected-output behavior changed.

## 0.1.5

- Correct legacy adapter font-conformance handling and add browser render-adapter probes.

## 2026-09-19 — full JavaScript qualification / non-fail-fast runner

- Kept the canonical JavaScript parser/renderer/font-controller/vector-exporter runtime unchanged.
- Confirmed `astToText` is implemented as a named export and `NanpaLinjaN` instance method.
- Added a dedicated 9-check pure `astToText` regression suite.
- Added explicit execution of the frozen 1,017-check protocol corpus; previously that corpus was used for font coverage derivation but was not executed by the top-level test run.
- Added the current 28-case canonical syntax corpus, 5 production font-adapter cases and 254-case canonical full-renderer semantic corpus.
- Added conformance authority/hash validation and public API-surface checks.
- Reworked the top-level runner so it never stops at the first suite failure. It runs every configured suite, records stdout/stderr, prints a final PASS/FAIL matrix and writes `test-output/javascript-regression-report.txt`.
- Full qualification result at release preparation: 13/13 configured suites PASS, 0 failures.
