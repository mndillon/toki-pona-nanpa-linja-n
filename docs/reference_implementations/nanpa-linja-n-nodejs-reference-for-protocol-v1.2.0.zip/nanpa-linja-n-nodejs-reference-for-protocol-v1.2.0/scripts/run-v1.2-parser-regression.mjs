#!/usr/bin/env node
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// Keep the canonical renderer's always-on diagnostic instrumentation out of
// the conformance report; warnings/errors remain visible.
const originalLog = console.log;
const originalTable = console.table;
console.log = () => {};
console.table = () => {};
const { SitelenRenderer } = await import('../src/node.js');

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const corpusPath = path.join(root, 'protocol/conformance/parser-renderer-regression-v1.2.0.json');
const data = JSON.parse(await fs.readFile(corpusPath, 'utf8'));
if (data.protocolVersion !== '1.2.0' || data.caseCount !== 24 || data.cases?.length !== 24) {
  throw new Error(`Invalid Protocol v1.2 regression corpus inventory: ${data.protocolVersion} ${data.caseCount}/${data.cases?.length ?? 0}`);
}

const equal = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const cpLabel = cp => 'U+' + Number(cp).toString(16).toUpperCase().padStart(4, '0');
function cleanAst(ast) {
  const lines = [];
  for (const line of ast?.lines || []) {
    const item = {
      sourceText: line?.sourceText ?? '',
      segments: (line?.children || []).map(s => ({ kind: s?.kind ?? null, value: s?.value ?? null })),
    };
    if (Object.prototype.hasOwnProperty.call(line || {}, 'canonicalSourceText')) item.canonicalSourceText = line.canonicalSourceText;
    if (Object.prototype.hasOwnProperty.call(line || {}, 'sourceEncoding')) item.sourceEncoding = line.sourceEncoding;
    lines.push(item);
  }
  return { normalizedInput: ast?.normalizedInput ?? '', lineCount: lines.length, lines };
}
function semanticSummary(lines) {
  const result = [];
  for (const els of lines || []) {
    const canonicalCodepoints = [], literalTexts = [], cartoucheClasses = [], elementKinds = [];
    for (const e of els || []) {
      if (e?.type === 'gap') continue;
      elementKinds.push(e?.type ?? null);
      if (e?.type === 'text') literalTexts.push(e?.text ?? '');
      if (e?.type === 'cartouche') cartoucheClasses.push(e?.isLiteralCartouche ? 'literal' : (e?.fontRole === 'number' ? 'number' : 'ordinary'));
      const arr = Array.isArray(e?.canonicalCps) ? e.canonicalCps : (Array.isArray(e?.cps) ? e.cps : (e?.cp != null ? [e.cp] : null));
      if (arr?.length) canonicalCodepoints.push(...arr.map(cpLabel));
    }
    result.push({ elementKinds, canonicalCodepoints, literalTexts, cartoucheClasses });
  }
  return result;
}

const failures = [];
let passed = 0;
const renderer = await SitelenRenderer.create({});
try {
  for (const tc of data.cases || []) {
    const errors = [];
    try {
      const parser = tc.parserOptions || {};
      const parsed = await renderer.parseInput({ input: tc.input, parser });
      const plan = await renderer.buildRenderPlan({ input: tc.input, parser, layout: { fontPx: 32 } });
      const gotAst = cleanAst(parsed.ast);
      const gotSemantic = semanticSummary(plan.linesElements || []);
      if (!equal(gotAst, tc.expected?.ast)) errors.push(`ast ${JSON.stringify(gotAst)}`);
      if (!equal(gotSemantic, tc.expected?.semantic)) errors.push(`semantic ${JSON.stringify(gotSemantic)}`);
      if (tc.expected && Object.prototype.hasOwnProperty.call(tc.expected, 'equivalentCanonicalInput')) {
        const eq = await renderer.buildRenderPlan({ input: tc.expected.equivalentCanonicalInput, parser, layout: { fontPx: 32 } });
        const eqSemantic = semanticSummary(eq.linesElements || []);
        if (!equal(eqSemantic, gotSemantic)) errors.push(`equivalentCanonicalInput ${JSON.stringify(eqSemantic)}`);
      }
    } catch (error) {
      errors.push(String(error?.stack || error));
    }
    if (errors.length) failures.push({ id: tc.id, errors }); else passed++;
  }
} finally {
  console.log = originalLog;
  console.table = originalTable;
}

originalLog(`Node.js Protocol v1.2 parser/renderer regression: ${passed}/${data.cases.length} PASS`);
if (failures.length) {
  originalLog(`FAILED CASES (${failures.length}):`);
  for (const item of failures) originalLog(`[${item.id}] ${item.errors.join('; ')}`);
  process.exit(1);
}
