# Node.js reference — Protocol v1.2.0 release notes

This release updates the Node.js reference from Protocol v1.1.0 to Protocol v1.2.0. The migration is intentionally limited to behavior required by the v1.2 canonical JavaScript implementation and the supplied current font resources.

## Functional changes

- replaced the pinned canonical renderer/parser with the supplied JavaScript Protocol v1.2.0 authority;
- ordinary ASCII `.` now maps to U+F199C in ordinary text/cartouches while decimal and literal contexts retain their established semantics;
- directly pasted recognized CSP/UCSUR document input now normalizes through the ordinary parser while preserving original source and `canonicalSourceText` / `sourceEncoding` metadata where applicable;
- explicit textual `U+...` input and dedicated raw-UCSUR APIs remain raw;
- quote closing now uses odd/even consecutive-backslash parity;
- added the normative 24-case v1.2 parser/renderer regression corpus and native Node conformance runner;
- updated the canonical full-renderer corpus to v1.2.0;
- replaced `resources/fonts.zip` with the exact supplied current archive.

## Deliberately unchanged

The Node facade, Node platform adapter, ZIP reader, canonical font-pair controller, canonical vector exporter, advanced browser core, vector WASM, 35-operation Core API, numeric defaults and render-adapter contracts remain unchanged from v1.1.0.

The existing 64-case Chromium parity oracle is retained unchanged because all of its cases still pass under v1.2; v1.2-only parser behavior is qualified by the new normative corpus.

## Regression status

The release is qualified only when all 12 suites in `npm test` pass. See `CONFORMANCE.md`, `TESTING.md`, and `test-output/nodejs-regression-report.txt`.
