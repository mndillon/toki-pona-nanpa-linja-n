# nanpa-linja-n Node.js reference implementation — Protocol v1.2.0

This package is the **Node.js reference implementation for nanpa-linja-n Protocol v1.2.0**.

It runs the canonical JavaScript v1.2.0 parser/renderer, font-pair controller and vector exporter under Node.js using `skia-canvas` 3.0.8. Protocol/cartouche semantics are not reimplemented in a Node-specific parser: the canonical JavaScript sources are bundled and SHA-256 pinned, while `src/node-platform.js` supplies the browser-compatible platform services needed by those sources.

## Requirements

- Node.js 20 or newer
- npm
- a platform supported by `skia-canvas` 3.0.8

Install the declared dependency, then run the qualification suite:

```bash
npm install
npm test
```

The consolidated runner is non-fail-fast and writes `test-output/nodejs-regression-report.txt`.

## Protocol v1.2.0 defaults

The public facade follows the v1.2.0 integrated parser/renderer profile. The v1.1 defaults remain unchanged:

- parser mode: `sitelen-pona-ascii-extended`
- numeric mode: `uniform`
- relaxed parsing: enabled
- relaxed rendering: enabled
- nanpa-format parsing/rendering: enabled
- abbreviated numeric cartouches: enabled
- preserve abbreviated internal break marker: disabled
- line splitting at full stops: disabled
- interpret double quotes as `te`/`to`: disabled
- hexadecimal parsing: disabled unless explicitly enabled
- binary parsing/rendering: disabled unless explicitly enabled
- `nasinNanpaPona`: disabled unless explicitly enabled

The standard ASCII core mode remains available as `standard-sitelen-pona-ascii-core`.

The v1.2 parser adds three protocol-level behaviors without changing those defaults: ordinary ASCII full stop maps to the sitelen pona middle dot outside literal contexts, directly pasted recognized CSP/UCSUR input is normalized through the ordinary parser while preserving original source metadata, and quote closing uses odd/even consecutive-backslash parity. Explicit textual `U+...` input and dedicated raw-UCSUR rendering APIs remain raw.


## Basic API

```js
import { NanpaLinjaN, parseNumber } from './src/node.js';

const nanpa = await NanpaLinjaN.create();

const parsed = await nanpa.parse('toki&pona 123 zz pi(telo lete) te tomo to');
console.log(nanpa.astToText(parsed.ast, { numericOutput: 'properName' }));
console.log(parseNumber('123'));

const png = await nanpa.renderToPng('123.45', {
  font: 'linjaPona',
  fontSize: 56,
});

const svg = await nanpa.renderToSvg('123.45', { font: 'nasinNanpa' });
const pdf = await nanpa.renderToPdf('123.45', { font: 'nasinNanpa' });

await nanpa.destroy();
```

`parseNumber()` is available as a named export, on `NanpaParser`, and on a created facade instance. `astToText()` supports `source`, `properName`, `#~`, and `cartouche`; `cartouche` is abbreviated by default in v1.2.0 and can be made full with `parser.abbreviateNumericCartouches: false`. `nasinNanpaPona: true` requests ordinary Toki Pona numeric wording where applicable.

Hexadecimal and binary are opt-in:

```js
await nanpa.renderToPng('#ABCDEF', {
  parser: { enableHexParsing: true },
});

await nanpa.renderToPdf('0b10101', {
  parser: {
    enableBinaryParsing: true,
    enableBinaryRendering: true,
  },
});
```

## Font resources and render adapters

`resources/fonts.zip` is the exact supplied production archive for this release. Its SHA-256 is:

```text
50c0375469508e806d2a6bb1ce555fa81adb72f73a497ddf7d26e4150671b209
```

The production manifest contains eight font pairs. The current renderer retains the established font render-adapter layer for fonts whose native OpenType input differs from canonical Common Sitelen Pona. Built-in adapters are:

- `identity`
- `linja-pona-legacy-v1`
- `linja-sike-legacy-v1`
- `nasin-sitelen-pu-mono-v1`
- `linja-lipamanka-v1`

All current production pairs opt into `cartoucheVulgarFractions: true` and disable `emulateLegacyCartoucheScaling`. The v1.2 renderer therefore does not depend on automatic `ss12`/`ss13`/`ss14` selection for cartouche scaling.

The current packaged production filenames are manifest-driven. In particular, `nasinNanpa` now uses `nanpa-linja-n-nasin-nanpa-sans-punctuation-mapping-fixed-ascii-vulgar-cartouche-only.ttf` for its base/companion role and `nanpa-linja-n-nasin-nanpa-sans-literal.ttf` for literal cartouches. The complete current set is:

| `fontKey` | Base/companion file | Literal-cartouche file |
| --- | --- | --- |
| `nasinNanpa` | `nanpa-linja-n-nasin-nanpa-sans-punctuation-mapping-fixed-ascii-vulgar-cartouche-only.ttf` | `nanpa-linja-n-nasin-nanpa-sans-literal.ttf` |
| `sitelenSeliKiwen` | `sitelenselikiwenjuniko-latin-ligatures-compatible-punctuation-mapping-fixed-ascii-vulgar-cartouche-only-state-continuity-fixed.ttf` | `(reuses base face)` |
| `fairfaxHd` | `FairfaxHD-compatible-punctuation-mapping-fixed.ttf` | `(reuses base face)` |
| `fairfaxPonaHd` | `FairfaxPonaHD-compatible-punctuation-mapping-fixed-ascii-fraction-cartouche-aliases.ttf` | `(reuses base face)` |
| `linjaPona` | `linja-pona-n-epiku-majuna-fixed-corrected.otf` | `nanpa-linja-n-nasin-nanpa-sans-literal.ttf` |
| `linjaSike` | `linja-sike-5-epiku-fixed.otf` | `nanpa-linja-n-nasin-nanpa-sans-literal.ttf` |
| `nasinSitelenPuMono` | `NasinSitelenPuMono-majuna-fixed.otf` | `nanpa-linja-n-nasin-nanpa-sans-literal.ttf` |
| `linjaLipamanka` | `linjalipamanka-epiku-fixed.otf` | `nanpa-linja-n-nasin-nanpa-sans-literal.ttf` |

Applications should continue selecting the logical `fontKey`; the manifest is authoritative for physical filenames.

The supplied v1.2 archive also contains `nanpa-linja-n-nasin-nanpa-sans-source-input-unchanged.ttf` as an additional current resource; it does not alter the active eight-pair manifest contract.

## Advanced API

```js
import {
  SitelenRenderer,
  NanpaParser,
  SitelenVectorExporter,
  createSitelenFontPairController,
} from './src/node-advanced.js';
```

The current renderer exposes the established render-adapter API (`registerRenderAdapter`, `unregisterRenderAdapter`, `hasRenderAdapter`, `getDefaultRenderAdapterId`) and render plans preserve both canonical and font-render codepoint information where applicable.

## Qualification layers

`npm test` currently runs **12 suites**:

1. canonical/reference and Node wrapper SHA-256 integrity;
2. production font/archive and cmap checks;
3. frozen Core-v1 regression corpus — **1030 checks**;
4. Protocol v1.2.0 integrated profile — **91 checks**, including **16/16** `NanpaParser` smoke cases and **8/8** font-pair invariants;
5. Protocol v1.2 parser/renderer regression — **24/24** cases: 10 full-stop, 12 direct CSP/UCSUR, 2 quote-escape;
6. Node platform compatibility;
7. Node renderer core — **115 checks**;
8. `astToText` / `parseNumber` — **26** pure checks plus **15** Node integration checks;
9. canonical syntax — **28/28**, plus **5/5** render-adapter cases;
10. canonical full renderer — **254/254**;
11. production output — **77 checks**, including PNG, SVG, PDF and explicit vector-only SVG/PDF assertions;
12. frozen Chromium browser-to-Node parity — **64/64** cases, **449** semantic checks and **257** geometry groups at 2.1 px tolerance.

The existing Chromium parity oracle in `fixtures/nodejs-browser-parity-v1.json` is retained byte-for-byte from v1.1 because all 64 parity cases remain unchanged under v1.2; the new v1.2 semantics are qualified independently by the 24-case normative parser/renderer corpus.

## Vector-output requirement

The production-output regression requires generated SVG to contain vector `<path>` geometry and rejects `<image>` or `data:image` raster fallback. The tested PDF output is rejected if it contains a raster `/Subtype /Image` XObject. PNG remains raster by definition.

## Canonical semantic corpora

```text
conformance/canonical-syntax-v1.0.1-phase1/cases.json
conformance/full-renderer-canonical-v1.2.0/cases.json
```

The frozen Core-v1 fixture remains historical/frozen evidence and is not rewritten. Protocol v1.2 behavior is qualified separately by `protocol/conformance/parser-renderer-profile-v1.2.0.json`, `protocol/conformance/parser-renderer-regression-v1.2.0.json`, and the current canonical renderer corpus.

## External font directory

To test an unpacked copy of the production fonts:

```bash
export NANPA_FONT_DIR="/absolute/path/to/fonts"
npm test
```

If the directory includes `preloaded-font-pairs.manifest.json`, it is used; otherwise the bundled manifest is used and its font filenames are resolved against `NANPA_FONT_DIR`.

## Generated output

Test/audit artifacts are written under `test-output/`. `node_modules/` and generated test output are not part of the release ZIP.
