# Node.js Protocol v1.2.0 conformance

## Conformance model

The Node.js reference is qualified against five layers:

1. the unchanged frozen Core-v1 regression corpus;
2. the Protocol v1.2.0 integrated parser/renderer profile;
3. the normative 24-case Protocol v1.2 parser/renderer regression corpus;
4. the canonical JavaScript v1.2 semantic renderer corpora;
5. the existing production browser-to-Node parity oracle, retained because its 64 cases are unchanged by v1.2.

All configured suites must pass for the release qualification reported by `npm test`.

## Canonical-source relationship

These files are SHA-256 pinned in `fixtures/reference-hashes.json`:

```text
reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js
reference/sitelen-font-pair-controller.js
reference/sitelen-vector-exporter.js
src/advanced-browser-core.js
src/node-facade.js
src/node-platform.js
src/font-zip.js
resources/fonts.zip
```

Only the canonical renderer/parser and supplied font archive changed for Protocol v1.2.0. The Node facade, Node platform adapter, font controller, vector exporter, advanced browser core and ZIP reader remain byte-identical to v1.1.0 because the v1.2 migration does not require changes to them.

## Frozen Core-v1 corpus

`fixtures/nanpa-linja-n-regression-v1.0.2.json` remains unchanged historical Core evidence. Acceptance: **1030 checks, zero failures**.

## Protocol v1.2.0 profile and parser corpus

Machine-readable inputs:

```text
protocol/conformance/parser-renderer-profile-v1.2.0.json
protocol/conformance/parser-renderer-regression-v1.2.0.json
protocol/conformance/parser-renderer-regression-v1.2.0.schema.json
```

Acceptance includes **91 integrated-profile checks**, **16/16** `NanpaParser` smoke cases, **8/8** production font-pair invariants, and **24/24** normative v1.2 parser cases:

- 10 full-stop cases;
- 12 direct CSP/UCSUR input cases;
- 2 quote/backslash-escape cases.

The v1.2 migration preserves Core-v1 numeric semantics, parser defaults, render-adapter contracts and raw `U+...` behavior.

## Canonical renderer corpora

```text
conformance/canonical-syntax-v1.0.1-phase1/cases.json
conformance/full-renderer-canonical-v1.2.0/cases.json
```

Acceptance:

- canonical syntax: **28/28**;
- production font-adapter cases: **5/5**;
- full canonical renderer: **254/254**.

## Production font acceptance

`resources/fonts.zip` is the exact user-supplied v1.2 archive, SHA-256 `50c0375469508e806d2a6bb1ce555fa81adb72f73a497ddf7d26e4150671b209`. The runtime manifest still defines eight production pairs. Qualification verifies referenced bytes, required cmap coverage, current render-adapter contracts and vulgar-fraction cartouche scale codepoints. The additional source-input-unchanged font is present as a resource without changing the active eight-pair contract.

## Chromium-to-Node production parity

Cases are defined by `fixtures/nodejs-browser-parity-cases.json`. `fixtures/nodejs-browser-parity-v1.json` is the independently generated Chromium v1.1 oracle retained byte-for-byte. All **64/64** cases continue to pass under v1.2, with **449 semantic checks** and **257 geometry groups** at 2.1 px tolerance. New v1.2-only semantics are covered by the separate 24-case normative corpus rather than by rewriting this historical parity fixture.

## Output formats

Production regression covers Canvas, PNG, SVG and PDF. SVG must contain vector path geometry and must not contain `<image>` or `data:image` raster fallback for the tested generated content. PDF must not contain a raster `/Subtype /Image` XObject for the tested generated content.

## Consolidated runner

`npm test` is non-fail-fast: all **12** configured suites are attempted and their stdout/stderr and exit status are collected. The report is written to:

```text
test-output/nodejs-regression-report.txt
```
