# Testing the Node.js reference

## Full qualification

```bash
npm install
npm test
```

Node.js 20 or newer is required. The runner is non-fail-fast and writes `test-output/nodejs-regression-report.txt`.

## Individual suites

```bash
npm run verify:references
npm run verify:fonts
npm run test:protocol
npm run test:profile
npm run test:parser-v1.2
npm run test:platform
npm run test:core
npm run test:ast
npm run test:canonical-syntax
npm run test:canonical-renderer
npm run test:output
npm run test:parity
```

`test:protocol` is the unchanged frozen Core-v1 corpus. `test:profile` verifies the Protocol v1.2.0 integrated profile. `test:parser-v1.2` executes the 24 normative v1.2 parser/renderer cases. `test:parity` retains the historical 64-case Chromium v1.1 oracle as a regression boundary; those cases remain unchanged under v1.2.

## Visual audits

```bash
npm run visual:numeric
npm run visual:cartouches
```

Generated files are written under `test-output/` and are not release inputs.
