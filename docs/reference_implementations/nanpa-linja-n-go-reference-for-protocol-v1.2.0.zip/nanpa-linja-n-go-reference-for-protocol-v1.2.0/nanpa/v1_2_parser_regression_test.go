package nanpa

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
)

type v12RegressionSegment struct {
	Kind  string `json:"kind"`
	Value string `json:"value"`
}

type v12RegressionLine struct {
	SourceText          string                 `json:"sourceText"`
	Segments            []v12RegressionSegment `json:"segments"`
	CanonicalSourceText *string                `json:"canonicalSourceText"`
	SourceEncoding      *string                `json:"sourceEncoding"`
}

type v12RegressionSemantic struct {
	ElementKinds        []string `json:"elementKinds"`
	CanonicalCodepoints []string `json:"canonicalCodepoints"`
	LiteralTexts        []string `json:"literalTexts"`
	CartoucheClasses    []string `json:"cartoucheClasses"`
}

type v12RegressionCase struct {
	ID            string                 `json:"id"`
	Category      string                 `json:"category"`
	Input         string                 `json:"input"`
	ParserOptions map[string]interface{} `json:"parserOptions"`
	Expected      struct {
		AST struct {
			NormalizedInput string              `json:"normalizedInput"`
			LineCount       int                 `json:"lineCount"`
			Lines           []v12RegressionLine `json:"lines"`
		} `json:"ast"`
		Semantic                 []v12RegressionSemantic `json:"semantic"`
		EquivalentCanonicalInput string                  `json:"equivalentCanonicalInput"`
	} `json:"expected"`
}

type v12RegressionCorpus struct {
	ProtocolVersion string              `json:"protocolVersion"`
	CaseCount       int                 `json:"caseCount"`
	Cases           []v12RegressionCase `json:"cases"`
}

func v12Options(m map[string]interface{}) FullRenderOptions {
	o := DefaultFullRenderOptions()
	o.Parser.Mode = stringJSON(m, "mode", o.Parser.Mode)
	o.Parser.RendererMode = o.Parser.Mode
	o.Parser.NumericMode = stringJSON(m, "numericMode", o.Parser.NumericMode)
	o.Parser.RelaxedNanpaLinjanParsing = boolJSON(m, "relaxedNanpaLinjanParsing", o.Parser.RelaxedNanpaLinjanParsing)
	o.Parser.RelaxedNanpaLinjanRendering = boolJSON(m, "relaxedNanpaLinjanRendering", o.Parser.RelaxedNanpaLinjanRendering)
	o.Parser.NanpaColonParsing = boolJSON(m, "nanpaColonParsing", o.Parser.NanpaColonParsing)
	o.Parser.NanpaColonRendering = boolJSON(m, "nanpaColonRendering", o.Parser.NanpaColonRendering)
	o.Parser.AbbreviateNumericCartouches = boolJSON(m, "abbreviateNumericCartouches", o.Parser.AbbreviateNumericCartouches)
	o.Parser.PreserveNumericCartoucheBreaks = boolJSON(m, "preserveNumericCartoucheBreaksInAbbreviation", o.Parser.PreserveNumericCartoucheBreaks)
	o.Parser.BreakLinesAtFullStops = boolJSON(m, "breakLinesAtFullStops", o.Parser.BreakLinesAtFullStops)
	o.Parser.InterpretDoubleQuotesAsTeTo = boolJSON(m, "interpretDoubleQuotesAsTeTo", o.Parser.InterpretDoubleQuotesAsTeTo)
	o.Parser.EnableHexParsing = boolJSON(m, "enableHexParsing", o.Parser.EnableHexParsing)
	o.Parser.EnableBinaryParsing = boolJSON(m, "enableBinaryParsing", o.Parser.EnableBinaryParsing)
	o.Parser.EnableBinaryRendering = boolJSON(m, "enableBinaryRendering", o.Parser.EnableBinaryRendering)
	o.Parser.NasinNanpaPona = boolJSON(m, "nasinNanpaPona", o.Parser.NasinNanpaPona)
	return o
}

func v12SemanticSummary(plan FullRenderPlan) []v12RegressionSemantic {
	out := make([]v12RegressionSemantic, len(plan.Lines))
	for i, line := range plan.Lines {
		s := v12RegressionSemantic{ElementKinds: []string{}, CanonicalCodepoints: []string{}, LiteralTexts: []string{}, CartoucheClasses: []string{}}
		for _, run := range line.Runs {
			s.ElementKinds = append(s.ElementKinds, run.Kind)
			if run.Kind == "text" {
				s.LiteralTexts = append(s.LiteralTexts, run.RenderText)
			} else {
				for _, cp := range run.CanonicalCodepoints {
					s.CanonicalCodepoints = append(s.CanonicalCodepoints, fmt.Sprintf("U+%04X", cp))
				}
			}
			if run.Kind == "cartouche" {
				class := "ordinary"
				if run.NumericCartouche {
					class = "number"
				} else {
					trimmed := strings.TrimSpace(run.SourceText)
					if strings.HasPrefix(trimmed, `"`) && !strings.HasPrefix(trimmed, `""`) {
						class = "literal"
					}
				}
				s.CartoucheClasses = append(s.CartoucheClasses, class)
			}
		}
		out[i] = s
	}
	return out
}

func TestProtocolV12ParserRendererRegression(t *testing.T) {
	if !fullNativeAvailable() {
		t.Skip("full native renderer requires Linux+cgo")
	}
	raw, err := os.ReadFile(filepath.Join("..", "protocol", "conformance", "parser-renderer-regression-v1.2.0.json"))
	if err != nil {
		t.Fatal(err)
	}
	var corpus v12RegressionCorpus
	if err := json.Unmarshal(raw, &corpus); err != nil {
		t.Fatal(err)
	}
	if corpus.ProtocolVersion != "1.2.0" || corpus.CaseCount != 24 || len(corpus.Cases) != 24 {
		t.Fatalf("unexpected v1.2 corpus metadata: version=%q count=%d cases=%d", corpus.ProtocolVersion, corpus.CaseCount, len(corpus.Cases))
	}
	n, err := CreateNanpaLinjaN()
	if err != nil {
		t.Fatal(err)
	}
	defer n.Close()

	for _, tc := range corpus.Cases {
		tc := tc
		t.Run(tc.ID, func(t *testing.T) {
			o := v12Options(tc.ParserOptions)
			plan, err := n.BuildFullRenderPlan(tc.Input, o)
			if err != nil {
				t.Fatal(err)
			}
			ast := plan.AST
			if ast.NormalizedInput != tc.Expected.AST.NormalizedInput || len(ast.Lines) != tc.Expected.AST.LineCount {
				t.Fatalf("AST header got normalized=%q lines=%d want normalized=%q lines=%d", ast.NormalizedInput, len(ast.Lines), tc.Expected.AST.NormalizedInput, tc.Expected.AST.LineCount)
			}
			for i, want := range tc.Expected.AST.Lines {
				got := ast.Lines[i]
				if got.SourceText != want.SourceText {
					t.Errorf("line %d sourceText=%q want %q", i, got.SourceText, want.SourceText)
				}
				if want.CanonicalSourceText == nil {
					if got.CanonicalSourceText != "" || got.SourceEncoding != "" {
						t.Errorf("line %d unexpected canonical metadata: %q %q", i, got.CanonicalSourceText, got.SourceEncoding)
					}
				} else if got.CanonicalSourceText != *want.CanonicalSourceText || want.SourceEncoding == nil || got.SourceEncoding != *want.SourceEncoding {
					t.Errorf("line %d canonical metadata=%q/%q want=%q/%v", i, got.CanonicalSourceText, got.SourceEncoding, *want.CanonicalSourceText, want.SourceEncoding)
				}
				if len(got.Children) != len(want.Segments) {
					t.Fatalf("line %d segments=%d want=%d", i, len(got.Children), len(want.Segments))
				}
				for j, ws := range want.Segments {
					if got.Children[j].Kind != ws.Kind || got.Children[j].Value != ws.Value {
						t.Errorf("line %d segment %d=%q/%q want=%q/%q", i, j, got.Children[j].Kind, got.Children[j].Value, ws.Kind, ws.Value)
					}
				}
			}
			summary := v12SemanticSummary(plan)
			if !reflect.DeepEqual(summary, tc.Expected.Semantic) {
				t.Errorf("semantic\n got=%#v\nwant=%#v", summary, tc.Expected.Semantic)
			}
			if tc.Expected.EquivalentCanonicalInput != "" {
				eq, err := n.BuildFullRenderPlan(tc.Expected.EquivalentCanonicalInput, o)
				if err != nil {
					t.Fatal(err)
				}
				if !reflect.DeepEqual(summary, v12SemanticSummary(eq)) {
					t.Errorf("semantic differs from equivalent canonical input %q", tc.Expected.EquivalentCanonicalInput)
				}
			}
		})
	}
}
