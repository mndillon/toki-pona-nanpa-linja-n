# Testing — Go Protocol v1.2.0 reference

## Build validation

From the repository root:

```bash
go build ./...
go test ./... -run '^$' -count=1
```

The second command compiles the Go test packages without executing the regression tests.

## Protocol v1.2 parser/renderer regression

To run the normative 24-case v1.2 corpus:

```bash
go test ./nanpa -run '^TestProtocolV12ParserRendererRegression$' -count=1
```

The corpus covers full-stop parsing, protected full stops, direct CSP/UCSUR input normalization, and quote/backslash escaping.

## Full regression

When full qualification is desired:

```bash
bash tools/run_go_regression.sh
```

This release package was built with build-level validation only; the full regression suite was intentionally not executed during packaging.

The v1.2 parser/renderer profile is `protocol/conformance/parser-renderer-profile-v1.2.0.json`, and the canonical full-renderer corpus is `conformance/full-renderer-canonical-v1.2.0/cases.json`. Production-Font-Profile-v1.1 remains unchanged.
