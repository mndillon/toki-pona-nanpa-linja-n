# nanpa-linja-n Go reference — Protocol v1.2.0

This release updates the native Go reference from Protocol v1.1.0 to Protocol v1.2.0 while retaining frozen Core-v1 numeric semantics and Production-Font-Profile-v1.1 behavior.

Parser-Renderer-Profile-v1.2 adds ordinary ASCII full-stop mapping to the canonical sitelen pona middle dot, optional sentence splitting via `breakLinesAtFullStops` with quote/cartouche/long-pi/brace/decimal protection, direct CSP/UCSUR document-input normalization with canonical-source metadata, odd/even backslash quote escaping, and the v1.2 force-ordinary cartouche behavior.

The supplied v1.2 `fonts.zip` and canonical JavaScript authority are bundled exactly. The normative 24-case v1.2 parser/renderer corpus and 254-case v1.2 full-renderer corpus are included for downstream qualification.

This build was packaged with build-level validation only, per project instruction; the full regression suite is available to downstream testers but was not run as part of this packaging step.
