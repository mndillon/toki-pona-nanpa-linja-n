# Release notes — Dart reference v1.1.0

This release upgrades the native Dart reference to the nanpa-linja-n **Protocol v1.1.0** parser/renderer and production-font profiles while retaining the seven hash-pinned Core-v1 implementation files unchanged.

## Main changes

- reference package version and target protocol set to 1.1.0;
- new public v1.1 parser wrapper with hexadecimal/binary opt-in defaults;
- full-document parser defaults aligned with v1.1;
- `astToText()` no longer depends on noncanonical decimal `parseNumber()` convenience fields;
- current canonical JavaScript and Protocol-v1.1 profile bundled as qualification authorities;
- exact current `fonts.zip` and eight-font production manifest installed;
- actual embedded native family names updated for the current font builds;
- current five production render adapters implemented;
- legacy automatic `ss12` / `ss13` / `ss14` production selection removed;
- Unicode `¼`, `⅓`, `½`, `⅔`, `¾` cartouche scale controls implemented;
- approved ordinary-cartouche ASCII aliases `1/4`, `1/3`, `1/2`, `2/3`, `3/4` implemented;
- outside-cartouche U+002C comma preserved as an ordinary word-font run;
- current 128-case production render-plan oracle installed;
- current 254-case canonical full-renderer corpus installed;
- Protocol-v1.1 16-case parser-smoke and vector-output gate added;
- examples updated so hex/binary are explicitly enabled;
- release/static validation and consolidated non-fail-fast runtime runner updated.

## Qualification status

External Dart 3.13.3 qualification has been run three times during this upgrade. The second run passed **18/19** suites: every functional/runtime/rendering suite passed, with only one `dart analyze` warning remaining. An attempted analyzer cleanup in the next packaged build incorrectly removed a required nullable guard in `lib/src/full_document.dart`; that third run therefore failed compilation and caused the Dart-dependent suites to fail before execution.

This archive restores the required nullable guard and removes the four analyzer warnings reported in that third run (`full_renderer.dart` unused import/unused declarations and the unnecessary non-null assertion in `api_surface_check.dart`). Frozen Core files remain unchanged.

Because this build environment does not contain a Dart SDK, the exact corrected archive still requires one all-suite rerun on a Dart-enabled system before being described as 19/19 runtime-qualified.

Run:

```bash
./tools/run_dart_regression.sh
```

Expected final summary:

```text
configured suites: 19
passed suites:     19
failed suites:      0
```
