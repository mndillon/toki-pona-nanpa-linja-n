import 'package:nanpa_linja_n/nanpa_linja_n.dart';

void main() {
  for (final input in <String>['123.45', '12:30', '2026-09-13']) {
    final result = parseNumber(input);
    print('$input -> ${result?.properName}');
    print(result?.tpWords);
  }

  final hexOptions = defaultPublicParseOptions.copyWith(enableHexParsing: true);
  final hex = parseNumber('#ABCDEF', hexOptions);
  print('#ABCDEF -> ${hex?.properName}');

  final binaryOptions = defaultPublicParseOptions.copyWith(enableBinaryParsing: true);
  final binary = parseNumber('0b10101', binaryOptions);
  print('0b10101 -> ${binary?.properName}');
}
