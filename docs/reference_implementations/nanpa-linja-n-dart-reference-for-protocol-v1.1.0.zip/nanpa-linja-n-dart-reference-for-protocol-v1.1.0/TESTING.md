# Testing the Dart v1.1.0 reference

## Requirements

- Dart SDK 3.3+
- Python 3 for static/release verification helpers
- Linux native rendering libraries: Pango/PangoCairo, Cairo, Fontconfig, GObject

No third-party Dart packages are required by the reference itself.

## Complete qualification

From the package root:

```bash
./tools/run_dart_regression.sh
```

The runner is non-fail-fast. It records every configured group in:

```text
test-output/dart-regression-report.txt
```

The configured groups are:

1. environment / Dart SDK
2. current v1.1 conformance authority
3. frozen Core-v1 source integrity
4. production assets
5. Protocol-v1.1 release integrity
6. static source audit
7. `dart pub get`
8. Dart compiler entry points
9. `dart analyze`
10. API surface
11. frozen Core-v1 regression
12. logical renderer smoke
13. production render-plan conformance
14. production PNG/SVG/PDF rendering
15. `astToText` / `parseNumber`
16. special-glyph and low-level rerender parity
17. canonical syntax and production adapters
18. canonical full renderer
19. Protocol-v1.1 profile and vector output

A release-quality runtime result requires **all configured groups to pass**.

## Static/source validation

This can be run even without Dart:

```bash
./tools/run_static_validation.sh
```

It validates the current authority hashes, frozen Core source hashes, production assets and manifests, the bundled protocol release and source-policy invariants. It does not execute Dart and is not a substitute for the complete regression.

## Individual Dart commands

```bash
dart pub get
./tools/check_dart_compilation.sh
dart analyze
dart run tools/api_surface_check.dart
dart run tools/run_dart_regression.dart
dart run tools/renderer_smoke.dart
dart run tools/facade_plan_conformance.dart
dart run tools/facade_rendering.dart
dart run tools/ast_to_text_regression.dart
dart run tools/special_glyph_regression.dart
dart run tools/canonical_syntax_regression.dart
dart run tools/canonical_full_renderer_regression.dart
dart run tools/v1_1_profile_regression.dart
```

## Important expected coverage

The complete suite is configured to exercise:

```text
frozen Core corpus                    1030 checks
Core API operation inventory          35
Protocol-v1.1 parser smoke cases      16
production fonts                      8
production render-plan oracle         128 cases
canonical syntax                      28 cases
production adapters                   5 cases
canonical full renderer               254 cases
```

The native production renderer also exercises all eight production fonts and PNG/SVG/PDF output.

## Vector-output requirement

`tools/v1_1_profile_regression.dart` requires numeric SVG output to contain vector `<path>` geometry and rejects `<image>` / `data:image` raster fallback. It also rejects a raster `/Subtype /Image` XObject in the generated numeric PDF.

PNG output is expected to be raster.

## Visual audits

After the functional suite succeeds, optional visual exports are available:

```bash
./tools/export_visual_pngs.sh
./tools/export_cartouche_audit.sh
```

Outputs are written under `test-output/`.

## Release integrity

```bash
python3 verify_release.py
```

This checks every shipped file recorded in `RELEASE-MANIFEST.json`.

## Fresh-extraction test

For the strongest local test, extract the distributed ZIP into a clean temporary directory and run:

```bash
python3 verify_release.py
./tools/run_static_validation.sh
./tools/run_dart_regression.sh
```

Do not regenerate or replace the bundled conformance/golden authorities merely to make a failing implementation pass. Fix the implementation or test harness instead.
