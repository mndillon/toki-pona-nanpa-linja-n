import 'dart:io';
import 'package:nanpa_linja_n/nanpa_linja_n.dart';

void main() {
  final nanpa = NanpaLinjaN.create();

  final png = nanpa.renderToPng('12:30', font: 'linjaPona');
  File('time-linja-pona.png').writeAsBytesSync(png);

  final svg = nanpa.renderToSvg('123.45');
  File('decimal.svg').writeAsBytesSync(svg);

  final pdf = nanpa.renderToPdf(
    '#ABCDEF',
    parserOptions: defaultPublicParseOptions.copyWith(enableHexParsing: true),
  );
  File('hex.pdf').writeAsBytesSync(pdf);
}
