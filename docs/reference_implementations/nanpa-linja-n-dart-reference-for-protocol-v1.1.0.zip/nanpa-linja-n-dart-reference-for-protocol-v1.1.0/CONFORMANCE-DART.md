# Dart v1.1.0 conformance status

## Target

```text
Reference implementation:       1.1.0
Target protocol:                 1.1.0
Frozen Core compatibility:      Core-v1 / corpus v1.0.2
Frozen Core checks:              1030
Frozen Core operations:          35
Parser/renderer smoke cases:     16
Production font pairs:           8
Production render-plan cases:    128
Canonical syntax cases:          28
Production adapter cases:        5
Canonical full-renderer cases:   254
```

## Architecture

This is an independent Dart implementation. It does not execute the canonical JavaScript at runtime. Pure Dart implements the numeric parser/logical renderer and document model. Production raster/vector output uses Dart FFI with Pango/PangoCairo, Cairo, Fontconfig and GObject.

The canonical JavaScript is bundled as a qualification authority only.

## Frozen Core

The seven files pinned by `validation/core-before.sha256` are retained byte-for-byte:

```text
lib/src/constants.dart
lib/src/encoding.dart
lib/src/model.dart
lib/src/options.dart
lib/src/parser.dart
lib/src/api.dart
lib/src/renderer.dart
```

This preserves the historical Core-v1 implementation while the high-level public facade supplies Protocol-v1.1 defaults and normalization.

Because `lib/src/options.dart` is frozen, its low-level `ParseOptions()` constructor retains historical defaults. New v1.1 callers should use the package-level public `parseNumber(...)`, `NanpaLinjaN`, `FullParserOptions`, or explicit options.

## Protocol-v1.1 behavior implemented

The production/full facade implements the v1.1 defaults and profile rules, including:

- uniform numeric mode;
- relaxed numeric parsing and rendering enabled;
- Nanpa-format parsing and rendering enabled;
- abbreviated numeric cartouches enabled by default;
- abbreviation-break preservation disabled by default;
- hexadecimal and binary opt-in;
- no default numeric cartouche start override;
- no default nasin-nanpa-pona conversion;
- whitespace terminates ordinary decimal-digit numeric constructs;
- current yearless date semantics;
- `&` compound/ZJW operator parity;
- current outside-cartouche comma behavior;
- current production render adapters;
- inline vulgar-fraction cartouche scaling;
- no active `ss12`, `ss13` or `ss14` production selection;
- current eight-font production manifest;
- vector-only numeric SVG/PDF qualification.

## Public `parseNumber()` versus serializer representations

For ordinary decimal/date/time input, the public v1.1 `parseNumber()` result follows the canonical result shape and does not require Python/Dart-specific convenience fields for every alternate textual representation.

`astToText()` and the renderer derive requested forms such as:

```text
properName
#~
full cartouche
abbreviated cartouche
nasin nanpa pona
```

Hexadecimal and binary result structures may contain their canonical abbreviated fields because the canonical v1.1 branches expose those fields directly.

## Production fonts

`resources/fonts.zip` is preserved byte-for-byte. The production manifest contains eight font pairs and five adapter IDs. All pairs opt into inline cartouche vulgar-fraction scaling and disable legacy cartouche-scaling emulation.

The manifest-requested compatibility filename:

```text
fonts/nanpa-linja-n-nasin-nanpa-liberation-sans-literal.ttf
```

is resolved at materialization time to the byte-identical supplied `fonts/LiberationSans-Regular.ttf`; the source archive itself is not modified.

## Static/source qualification completed in the build environment

The following checks were executed successfully while preparing this v1.1.0 archive:

```text
current v1.1 authority/hash validation          PASS
frozen Core source integrity                    7/7 PASS
production assets/font/profile validation       PASS
Protocol v1.1 release verification              PASS
static Dart source/policy audit                 PASS
shell syntax checks                              PASS
Python validation-script compilation            PASS
```

The static checks pin the exact canonical JavaScript, parser/renderer profile, production font manifest, `fonts.zip`, frozen Core corpus, current corpus sizes and production font-family metadata.

## Runtime qualification not executed in the build environment

The build environment did not contain the Dart executable. Consequently the following must **not** be represented as having passed there:

```text
dart pub get
dart compilation
dart analyze
Dart API-surface runtime checks
frozen Core Dart regression execution
production render-plan Dart execution
native Pango/Cairo Dart rendering
astToText/parseNumber Dart runtime regression
canonical syntax Dart runtime regression
canonical full renderer Dart runtime regression
Protocol v1.1 Dart parser smoke regression
SVG/PDF vector-output Dart runtime regression
```

Run `./tools/run_dart_regression.sh` on a Dart-enabled system. The runner attempts every configured suite and fails the overall run if any suite fails.

## Qualification criterion

This archive should be considered **source/static-qualified but Dart-runtime-unverified in the build environment** until the complete regression runner reports zero failed suites on a supported Dart/native-rendering system.
