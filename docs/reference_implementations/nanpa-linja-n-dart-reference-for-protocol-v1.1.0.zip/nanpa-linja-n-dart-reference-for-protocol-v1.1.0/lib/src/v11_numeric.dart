import 'constants.dart';
import 'renderer.dart';

/// Protocol v1.1 normalization layered above the frozen Core-v1 renderer.
///
/// Core-v1 expands the mixed-fraction markers NOKO/NONO into their historical
/// full word sequences.  The v1.1 abbreviated surface collapses those sequences
/// to `kin` and `o o` respectively.  Keep that policy here so Core source files
/// remain byte-for-byte frozen.
List<String> normalizeV11AbbreviatedWords(Iterable<String> words) {
  final input = List<String>.from(words);
  final out = <String>[];
  var i = 0;

  bool has(List<String> needle) {
    if (i + needle.length > input.length) return false;
    for (var j = 0; j < needle.length; j++) {
      if (input[i + j] != needle[j]) return false;
    }
    return true;
  }

  while (i < input.length) {
    // NONONO -> o o o. Test the longer marker before NONO.
    if (has(const <String>['nena', 'o', 'nena', 'o', 'nena', 'o'])) {
      out.addAll(const <String>['o', 'o', 'o']);
      i += 6;
      continue;
    }
    // NOKO (mixed-fraction delimiter) -> kin.
    if (has(const <String>['nena', 'open', 'kin', 'open'])) {
      out.add('kin');
      i += 4;
      continue;
    }
    // NONO (fraction delimiter) -> o o.
    if (has(const <String>['nena', 'o', 'nena', 'o'])) {
      out.addAll(const <String>['o', 'o']);
      i += 4;
      continue;
    }
    out.add(input[i++]);
  }
  return out;
}

/// Applies the v1.1 abbreviated-word normalization to a frozen Core render
/// result while preserving its parsed/full representation.
RenderResult normalizeV11RenderResult(RenderResult rendered) {
  final abbreviated = rendered.abbreviatedWords;
  if (abbreviated == null || abbreviated.isEmpty) return rendered;

  final normalized = normalizeV11AbbreviatedWords(abbreviated);
  var changed = normalized.length != abbreviated.length;
  if (!changed) {
    for (var i = 0; i < normalized.length; i++) {
      if (normalized[i] != abbreviated[i]) {
        changed = true;
        break;
      }
    }
  }
  if (!changed) return rendered;

  final inner = <int>[];
  for (final word in normalized) {
    final cp = allWordCodepoints[word] ?? wordCodepoints[word];
    if (cp == null) return rendered;
    inner.add(cp);
  }
  final codepoints = <int>[cartoucheStart, ...inner, cartoucheEnd];
  final useAbbreviated = rendered.abbreviated;
  final activeWords = useAbbreviated
      ? normalized
      : List<String>.from(rendered.activeWords);
  final activeInner = useAbbreviated
      ? inner
      : List<int>.from(rendered.activeInnerCodepoints);
  final activeCodepoints = useAbbreviated
      ? codepoints
      : List<int>.from(rendered.activeCodepoints);

  return RenderResult(
    parsed: rendered.parsed,
    fullWords: rendered.fullWords,
    fullInnerCodepoints: rendered.fullInnerCodepoints,
    fullCodepoints: rendered.fullCodepoints,
    abbreviatedWords: List<String>.unmodifiable(normalized),
    abbreviatedInnerCodepoints: List<int>.unmodifiable(inner),
    abbreviatedCodepoints: List<int>.unmodifiable(codepoints),
    abbreviated: rendered.abbreviated,
    activeWords: List<String>.unmodifiable(activeWords),
    activeInnerCodepoints: List<int>.unmodifiable(activeInner),
    activeCodepoints: List<int>.unmodifiable(activeCodepoints),
    unicodeText: String.fromCharCodes(activeCodepoints),
  );
}
