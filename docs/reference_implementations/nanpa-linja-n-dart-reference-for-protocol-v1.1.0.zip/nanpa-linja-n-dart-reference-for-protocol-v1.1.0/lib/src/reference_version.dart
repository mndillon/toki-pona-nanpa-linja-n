/// Version of this Dart reference implementation release.
const referenceImplementationVersion = '1.1.0';

/// Protocol/profile release targeted by the production facade.
const targetProtocolVersion = '1.1.0';
