import 'dart:math' as math;

import 'constants.dart';
import 'full_types.dart';
import 'production_font_registry.dart';
import 'production_font_adapters.dart' show vulgarScaleMarkers, asciiScaleAliases;

class AdaptedOrdinary {
  final String text;
  final List<List<int>> canonicalSpans;
  const AdaptedOrdinary(this.text, this.canonicalSpans);
}

class OrdinaryCartouche {
  final List<int> inner;
  final List<int> manualTallies;
  final String tallyMode;
  final List<int> scaleMarkers;
  const OrdinaryCartouche(
    this.inner,
    this.manualTallies,
    this.tallyMode, [
    this.scaleMarkers = const <int>[],
  ]);
  bool get hasManualTallies => manualTallies.any((n) => n > 0);
}


double _settingFloat(Map<String, dynamic> values, String key, double fallback) {
  final value = values[key];
  if (value is num) return value.toDouble();
  if (value is String) return double.tryParse(value) ?? fallback;
  return fallback;
}

String _settingString(
  Map<String, dynamic> values,
  String key,
  String fallback,
) {
  final value = '${values[key] ?? ''}'.trim();
  return value.isEmpty ? fallback : value;
}

String? _legacyOrdinaryWord(int cp, String kind) {
  switch (cp) {
    case middleDotCodepoint:
      return '.';
    case colonCodepoint:
      return ':';
    case 0x3000:
      return kind == 'linja-lipamanka' ? 'zz' : '  ';
    case 0xF1989:
      return kind == 'linja-lipamanka' ? 'ni<' : 'ni';
    case 0xF198A:
      return (kind == 'linja-sike' || kind == 'linja-lipamanka')
          ? 'ni^'
          : 'ni';
    case 0xF198B:
      return (kind == 'linja-sike' || kind == 'linja-lipamanka')
          ? 'ni>'
          : 'ni';
    case 0xF198C:
      return kind == 'linja-sike' ? 'sewi1' : 'sewi';
    case openQuoteCodepoint:
      if (kind == 'linja-lipamanka') return 'te';
      break;
    case closeQuoteCodepoint:
      if (kind == 'linja-lipamanka') return 'to';
      break;
  }
  final word = allCodepointWords[cp];
  if (word == null) return null;
  if (kind == 'linja-pona' &&
      <int>{0xF19A2, 0xF19A4, 0xF19A5, 0xF19A6}.contains(cp)) {
    return null;
  }
  if (kind == 'linja-lipamanka' &&
      (<int>{0xF19A4, 0xF19A5, 0xF19A6}.contains(cp) || cp > 0xF19A3)) {
    return null;
  }
  return word;
}

AdaptedOrdinary _adaptOrdinaryCartoucheBase(
  ProductionFontInfo font,
  List<int> inner,
) {
  final full = <int>[cartoucheStart, ...inner, cartoucheEnd];
  final adapterId = font.renderAdapterId.trim().isEmpty
      ? 'identity'
      : font.renderAdapterId.trim();

  AdaptedOrdinary identity() {
    final text = StringBuffer();
    final spans = <List<int>>[];
    var index = 0;
    for (final cp in full) {
      final start = index;
      text.writeCharCode(cp);
      index++;
      spans.add(<int>[start, index]);
    }
    return AdaptedOrdinary(text.toString(), spans);
  }

  if (adapterId == 'linja-pona-legacy-v1' ||
      adapterId == 'linja-sike-legacy-v1') {
    final kind = adapterId.startsWith('linja-sike')
        ? 'linja-sike'
        : 'linja-pona';
    final spans = List<List<int>>.generate(
      full.length,
      (_) => <int>[0, 0],
      growable: false,
    );
    final out = StringBuffer('[');
    spans[0] = <int>[0, 1];
    final limit = math.max(1, full.length - 1);
    var i = 1;
    while (i < limit) {
      if (_fullControlOnly(full[i])) {
        final at = out.toString().runes.length;
        spans[i] = <int>[at, at];
        i++;
        continue;
      }
      final cellStart = i;
      final cell = <int>[full[i++]];
      while (i + 1 < limit && _fullJoiner(full[i])) {
        cell
          ..add(full[i])
          ..add(full[i + 1]);
        i += 2;
      }
      final start = out.toString().runes.length;
      out.write('_');
      var j = 0;
      while (j < cell.length) {
        out.write(_fullLegacyWord(cell[j], kind, font));
        j++;
        if (j < cell.length) {
          out.write('-');
          j++;
        }
      }
      final stop = out.toString().runes.length;
      for (var k = cellStart; k < i; k++) spans[k] = <int>[start, stop];
    }
    final lastStart = out.toString().runes.length;
    out.write(']');
    if (full.length > 1) spans[full.length - 1] = <int>[lastStart, out.toString().runes.length];
    return AdaptedOrdinary(out.toString(), spans);
  }

  if (adapterId == 'nasin-sitelen-pu-mono-v1') {
    final replacement = font.renderAdapterSettings['unsupportedReplacementCodepoint']
            is num
        ? (font.renderAdapterSettings['unsupportedReplacementCodepoint'] as num)
            .round()
        : 0xFFFD;
    final values = <int>[];
    for (final cp in full) {
      values.add(_puMonoMap(cp) ?? replacement);
    }
    final text = StringBuffer();
    final spans = <List<int>>[];
    var index = 0;
    for (final cp in values) {
      final start = index;
      text.writeCharCode(cp);
      index++;
      spans.add(<int>[start, index]);
    }
    return AdaptedOrdinary(text.toString(), spans);
  }

  if (adapterId == 'linja-lipamanka-v1') {
    final deterministicAlternates =
        font.renderAdapterSettings['deterministicAlternates'] != false;
    final jakiCp = allWordCodepoints['jaki'];
    final koCp = allWordCodepoints['ko'];
    bool needsLegacy(int cp) =>
        cp == middleDotCodepoint ||
        cp == colonCodepoint ||
        cp == tallyCodepoint ||
        cp == 0xF1989 || cp == 0xF198A || cp == 0xF198B || cp == 0xF198C ||
        cp == openQuoteCodepoint || cp == closeQuoteCodepoint || cp == 0x3000 ||
        cp == 0xF19A4 || cp == 0xF19A5 || cp == 0xF19A6 || cp > 0xF19A3 ||
        (deterministicAlternates && (cp == jakiCp || cp == koCp));
    if (!full.any(needsLegacy)) return identity();
    final spans = List<List<int>>.generate(
      full.length,
      (_) => <int>[0, 0],
      growable: false,
    );
    final out = StringBuffer('[');
    spans[0] = <int>[0, 1];
    for (var i = 1; i < full.length - 1; i++) {
      if (i > 1) out.write(' ');
      final start = out.toString().runes.length;
      out.write(_legacyOrdinaryWord(full[i], 'linja-lipamanka') ?? '�');
      spans[i] = <int>[start, out.toString().runes.length];
    }
    final start = out.toString().runes.length;
    out.write(']');
    spans[full.length - 1] = <int>[start, out.toString().runes.length];
    return AdaptedOrdinary(out.toString(), spans);
  }

  return identity();
}


AdaptedOrdinary _applyOrdinaryScaleMarkers(
  AdaptedOrdinary adapted,
  List<int> markers,
) {
  if (markers.isEmpty) return adapted;
  final insertions = <({int pos, int owner, int marker})>[];
  for (var innerIndex = 0; innerIndex < markers.length; innerIndex++) {
    final marker = markers[innerIndex];
    if (!vulgarScaleMarkers.contains(marker)) continue;
    final canonicalIndex = innerIndex + 1;
    if (canonicalIndex >= adapted.canonicalSpans.length) continue;
    insertions.add((
      pos: adapted.canonicalSpans[canonicalIndex][1],
      owner: canonicalIndex,
      marker: marker,
    ));
  }
  if (insertions.isEmpty) return adapted;
  insertions.sort((a, b) {
    final byPos = a.pos.compareTo(b.pos);
    return byPos != 0 ? byPos : a.owner.compareTo(b.owner);
  });

  final runes = adapted.text.runes.toList(growable: false);
  final byPos = <int, List<({int pos, int owner, int marker})>>{};
  for (final insertion in insertions) {
    byPos.putIfAbsent(insertion.pos, () => <({int pos, int owner, int marker})>[])
        .add(insertion);
  }
  final out = <int>[];
  for (var pos = 0; pos <= runes.length; pos++) {
    for (final insertion in byPos[pos] ?? const <({int pos, int owner, int marker})>[]) {
      out.add(insertion.marker);
    }
    if (pos < runes.length) out.add(runes[pos]);
  }

  int before(int pos) => insertions.where((i) => i.pos < pos).length;
  int atOrBefore(int pos) => insertions.where((i) => i.pos <= pos).length;
  final spans = <List<int>>[];
  for (var ci = 0; ci < adapted.canonicalSpans.length; ci++) {
    final span = adapted.canonicalSpans[ci];
    final own = insertions.where((i) => i.owner == ci && i.pos == span[1]).length;
    final start = span[0] + atOrBefore(span[0]);
    var end = span[1] + before(span[1]) + own;
    if (end < start) end = start;
    spans.add(<int>[start, end]);
  }
  return AdaptedOrdinary(
    String.fromCharCodes(out),
    List<List<int>>.unmodifiable(spans),
  );
}

AdaptedOrdinary adaptOrdinaryCartouche(
  ProductionFontInfo font,
  List<int> inner, [
  List<int> scaleMarkers = const <int>[],
]) =>
    _applyOrdinaryScaleMarkers(
      _adaptOrdinaryCartoucheBase(font, inner),
      scaleMarkers,
    );

bool _fullControlOnly(int cp) =>
    cp == 0xF1992 ||
    cp == 0xF1993 ||
    cp == 0xF1994 ||
    cp == 0xF1997 ||
    cp == 0xF1998 ||
    cp == 0xF1999 ||
    cp == 0xF199A ||
    cp == 0xF199B;

bool _fullJoiner(int cp) =>
    cp == 0x200D || cp == 0xF1995 || cp == 0xF1996;

class _FullCell {
  final List<int> cps;
  final bool controlOnly;
  const _FullCell(this.cps, this.controlOnly);
}

List<_FullCell> _splitFullCells(
  List<int> cps, [
  int start = 0,
  int? end,
]) {
  final stop = end ?? cps.length;
  final out = <_FullCell>[];
  var i = start;
  while (i < stop) {
    final cp = cps[i];
    if (_fullControlOnly(cp)) {
      out.add(_FullCell(<int>[cp], true));
      i++;
      continue;
    }
    final cell = <int>[cp];
    i++;
    while (i + 1 < stop && _fullJoiner(cps[i])) {
      cell
        ..add(cps[i])
        ..add(cps[i + 1]);
      i += 2;
    }
    out.add(_FullCell(List<int>.unmodifiable(cell), false));
  }
  return out;
}

String _fullLegacyWord(
  int cp,
  String kind,
  ProductionFontInfo font,
) {
  if ((cp == openQuoteCodepoint || cp == closeQuoteCodepoint) &&
      '${font.renderAdapterSettings['cornerBracketMode'] ?? ''}'
              .toLowerCase() ==
          'synthetic') {
    return String.fromCharCode(cp);
  }
  return _legacyOrdinaryWord(cp, kind) ?? '�';
}

String _appendLegacyCell(
  _FullCell cell,
  String kind,
  ProductionFontInfo font,
) {
  if (cell.controlOnly || cell.cps.isEmpty) return '';
  final out = StringBuffer();
  var i = 0;
  while (i < cell.cps.length) {
    out.write(_fullLegacyWord(cell.cps[i], kind, font));
    i++;
    if (i < cell.cps.length) {
      final joiner = cell.cps[i];
      var op = '-';
      if (kind == 'linja-lipamanka') {
        if (joiner == 0xF1995) {
          op = '+';
        } else if (joiner == 0xF1996) {
          op = '-';
        } else {
          final configured =
              '${font.renderAdapterSettings['genericCompoundOperator'] ?? '-'}';
          op = configured.isEmpty ? '-' : configured.substring(0, 1);
        }
      }
      out.write(op);
      i++;
    }
  }
  return out.toString();
}

List<int>? _currentLong(List<int> cps) {
  final start = cps.indexOf(0xF1997);
  if (start <= 0) return null;
  final end = cps.indexOf(0xF1998, start + 1);
  if (end < 0) return null;
  return <int>[start - 1, start, end];
}

bool _hasReverseLong(List<int> cps) =>
    cps.any((cp) => cp == 0xF199A || cp == 0xF199B);

List<int> _textCodepoints(String text) => text.runes.toList(growable: false);

List<int> _adaptLegacyFullWordRun(
  ProductionFontInfo font,
  List<int> cps,
  String kind,
) {
  final long = _currentLong(cps);
  final pi = allWordCodepoints['pi'];
  if (long != null &&
      !_hasReverseLong(cps) &&
      pi != null &&
      cps[long[0]] == pi) {
    final usable = _splitFullCells(cps, long[1] + 1, long[2])
        .where((cell) => !cell.controlOnly)
        .toList(growable: false);
    var maxCells = 3;
    final configured = font.renderAdapterSettings['maxLongPiCells'];
    if (configured is num && configured.toInt() > 0) {
      maxCells = configured.toInt();
    }
    if (usable.isNotEmpty && usable.length <= maxCells) {
      final out = StringBuffer('pi');
      if (kind == 'linja-pona') {
        out.write(List<String>.filled(usable.length, '+').join());
        for (var i = 0; i < usable.length; i++) {
          if (i > 0) out.write(' ');
          out.write(_appendLegacyCell(usable[i], kind, font));
        }
      } else {
        out.write('+');
        for (final cell in usable) {
          out
            ..write('__')
            ..write(_appendLegacyCell(cell, kind, font));
        }
      }
      return _textCodepoints(out.toString());
    }
  }

  final out = StringBuffer();
  for (final cell in _splitFullCells(cps)) {
    out.write(_appendLegacyCell(cell, kind, font));
  }
  return _textCodepoints(out.toString());
}

int? _puMonoMap(int cp) {
  if (cp == 0xF1989 || cp == 0xF198A || cp == 0xF198B) return 0xF1941;
  if (cp == 0xF198C) return 0xF195A;
  if (cp == middleDotCodepoint) return '.'.codeUnitAt(0);
  if (cp == colonCodepoint) return ':'.codeUnitAt(0);
  if ((cp >= 0xF1900 && cp <= 0xF1988) ||
      (cp >= 0xF19A0 && cp <= 0xF19A3) ||
      cp == cartoucheStart ||
      cp == cartoucheEnd ||
      cp == 0x3000 ||
      cp == openQuoteCodepoint ||
      cp == closeQuoteCodepoint) {
    return cp;
  }
  return null;
}

List<int> _adaptPuMonoFullWordRun(
  ProductionFontInfo font,
  List<int> cps,
) {
  final replacement = font.renderAdapterSettings['unsupportedReplacementCodepoint']
          is num
      ? (font.renderAdapterSettings['unsupportedReplacementCodepoint'] as num)
          .toInt()
      : 0xFFFD;
  final out = <int>[];
  for (final cp in cps) {
    if (_fullJoiner(cp) || _fullControlOnly(cp)) continue;
    out.add(_puMonoMap(cp) ?? replacement);
  }
  return List<int>.unmodifiable(out);
}

bool _lipamankaFullNeedsTranslation(
  List<int> cps,
  ProductionFontInfo font,
) {
  final deterministicAlternates =
      font.renderAdapterSettings['deterministicAlternates'] != false;
  final jakiCp = allWordCodepoints['jaki'];
  final koCp = allWordCodepoints['ko'];
  for (final cp in cps) {
    if (_fullJoiner(cp) ||
        cp == middleDotCodepoint ||
        cp == colonCodepoint ||
        cp == tallyCodepoint ||
        cp == 0xF1989 ||
        cp == 0xF198A ||
        cp == 0xF198B ||
        cp == 0xF198C ||
        cp == openQuoteCodepoint ||
        cp == closeQuoteCodepoint ||
        cp == 0x3000 ||
        cp >= 0xF19A4 ||
        (deterministicAlternates && (cp == jakiCp || cp == koCp))) {
      return true;
    }
  }
  if (_hasReverseLong(cps)) return true;
  final long = _currentLong(cps);
  if (long != null) {
    final pi = allWordCodepoints['pi'];
    final lon = allWordCodepoints['lon'];
    return cps[long[0]] != pi && cps[long[0]] != lon;
  }
  return false;
}

List<int> _adaptLipamankaFullWordRun(
  ProductionFontInfo font,
  List<int> cps,
) {
  if (!_lipamankaFullNeedsTranslation(cps, font)) {
    return List<int>.unmodifiable(cps);
  }
  final long = _currentLong(cps);
  final pi = allWordCodepoints['pi'];
  final lon = allWordCodepoints['lon'];
  if (long != null &&
      !_hasReverseLong(cps) &&
      (cps[long[0]] == pi || cps[long[0]] == lon)) {
    final out = StringBuffer(
      _fullLegacyWord(cps[long[0]], 'linja-lipamanka', font),
    )..write('(');
    var first = true;
    for (final cell in _splitFullCells(cps, long[1] + 1, long[2])) {
      if (cell.controlOnly) continue;
      if (!first) out.write(' ');
      first = false;
      out.write(_appendLegacyCell(cell, 'linja-lipamanka', font));
    }
    out.write(')');
    return _textCodepoints(out.toString());
  }

  final out = StringBuffer();
  for (final cell in _splitFullCells(cps)) {
    out.write(_appendLegacyCell(cell, 'linja-lipamanka', font));
  }
  return _textCodepoints(out.toString());
}

/// Canonical production-font adaptation for ordinary word/glyph runs.
List<int> adaptFullWordRun(
  ProductionFontInfo font,
  List<int> codepoints,
) {
  final cps = List<int>.from(codepoints);
  switch (font.renderAdapterId) {
    case 'linja-pona-legacy-v1':
      return _adaptLegacyFullWordRun(font, cps, 'linja-pona');
    case 'linja-sike-legacy-v1':
      return _adaptLegacyFullWordRun(font, cps, 'linja-sike');
    case 'nasin-sitelen-pu-mono-v1':
      return _adaptPuMonoFullWordRun(font, cps);
    case 'linja-lipamanka-v1':
      return _adaptLipamankaFullWordRun(font, cps);
    default:
      return List<int>.unmodifiable(cps);
  }
}

OrdinaryCartouche? parseOrdinaryCartoucheBody(
  String body,
  ProductionFontInfo font,
  FullParserOptions options,
) {
  final source = body.trim();
  if (source.isEmpty) return null;
  var mode = options.cartoucheTallyMode.trim().toLowerCase();
  if (mode.isEmpty) {
    mode = _settingString(font.settings, 'cartoucheTallyMode', 'ucsur')
        .toLowerCase();
  }
  if (!<String>{'manual', 'comma', 'ucsur'}.contains(mode)) mode = 'ucsur';

  final vulgar = font.settings['cartoucheVulgarFractions'] == true;
  final cps = <int>[];
  final tallies = <int>[];
  final scales = <int>[];
  final current = StringBuffer();
  var lastScalable = -1;
  var tallyStarted = false;

  void push(int cp, bool scalable) {
    cps.add(cp);
    tallies.add(0);
    scales.add(0);
    if (scalable) {
      lastScalable = cps.length - 1;
      tallyStarted = false;
    } else {
      lastScalable = -1;
    }
  }

  bool flush() {
    final token = current.toString().trim().toLowerCase();
    current.clear();
    if (token.isEmpty) return true;
    final cp = allWordCodepoints[token];
    if (cp == null) return false;
    if (cp == tallyCodepoint && mode == 'manual') {
      if (tallies.isNotEmpty) {
        tallies[tallies.length - 1] = math.min(8, tallies.last + 1).toInt();
      }
      lastScalable = -1;
      tallyStarted = true;
      return true;
    }
    push(cp, true);
    return true;
  }

  final runes = source.runes.toList(growable: false);
  var i = 0;
  while (i < runes.length) {
    final cp = runes[i];
    final ch = String.fromCharCode(cp);
    if (RegExp(r'\s').hasMatch(ch)) {
      if (!flush()) return null;
      i++;
      continue;
    }

    if (vulgar && vulgarScaleMarkers.contains(cp)) {
      if (!flush() ||
          lastScalable < 0 ||
          tallyStarted ||
          scales[lastScalable] != 0) {
        return null;
      }
      scales[lastScalable] = cp;
      i++;
      continue;
    }

    var alias = 0;
    if (vulgar && i + 3 <= runes.length) {
      final candidate = String.fromCharCodes(runes.sublist(i, i + 3));
      final marker = asciiScaleAliases[candidate];
      if (marker != null) {
        var nextBad = false;
        if (i + 3 < runes.length) {
          final next = runes[i + 3];
          nextBad = (next >= 0x30 && next <= 0x39) || next == 0x2F;
        }
        if (!nextBad) alias = marker;
      }
    }
    if (alias != 0) {
      final had = current.toString().trim().isNotEmpty;
      if (had && !flush()) return null;
      if (lastScalable >= 0) {
        if (tallyStarted || scales[lastScalable] != 0) return null;
        scales[lastScalable] = alias;
        i += 3;
        continue;
      }
    }

    if (ch == '.' || ch == '·' || ch == ':') {
      if (!flush()) return null;
      push(ch == ':' ? colonCodepoint : middleDotCodepoint, true);
      i++;
      continue;
    }

    if (ch == ',') {
      if (!flush()) return null;
      tallyStarted = true;
      lastScalable = -1;
      if (!options.effectiveCommaTallyMarks) {
        i++;
        continue;
      }
      switch (mode) {
        case 'manual':
          if (tallies.isNotEmpty) {
            tallies[tallies.length - 1] =
                math.min(8, tallies.last + 1).toInt();
          }
          break;
        case 'comma':
          push(','.codeUnitAt(0), false);
          break;
        default:
          push(tallyCodepoint, false);
          break;
      }
      i++;
      continue;
    }

    current.write(ch);
    i++;
  }
  if (!flush() || cps.isEmpty) return null;
  return OrdinaryCartouche(
    List<int>.unmodifiable(cps),
    List<int>.unmodifiable(tallies),
    mode,
    List<int>.unmodifiable(scales),
  );
}

final RegExp _lettersOnly = RegExp(r'^[A-Za-z]+$');

List<int>? properNameCodepoints(String word) {
  if (!_lettersOnly.hasMatch(word)) return null;
  const allowed = 'aeijklmnostpuw';
  final lower = word.toLowerCase();
  for (final cp in lower.runes) {
    if (!allowed.contains(String.fromCharCode(cp))) return null;
  }
  final keys = allWordCodepoints.keys
      .where((w) => RegExp(r'^[a-z]+$').hasMatch(w))
      .toList(growable: false)
    ..sort();
  final bucket = <String, int>{};
  for (final key in keys) {
    bucket.putIfAbsent(key[0], () => allWordCodepoints[key]!);
  }
  final out = <int>[];
  for (var i = 0; i < lower.length; i++) {
    final cp = bucket[lower[i]];
    if (cp == null) return null;
    out.add(cp);
  }
  return out;
}

List<String> nasinNanpaPonaWords(String digits) {
  final number = int.tryParse(digits);
  if (number == null || number < 0) return const <String>[];
  final out = <String>[];
  void encode(int value) {
    if (value == 0) {
      out.add('ala');
      return;
    }
    var x = value;
    if (x >= 100) {
      final q = x ~/ 100;
      final r = x % 100;
      encode(q);
      out.add('ali');
      if (r > 0) encode(r);
      return;
    }
    while (x >= 20) {
      out.add('mute');
      x -= 20;
    }
    if (x >= 5) {
      out.add('luka');
      x -= 5;
    }
    while (x >= 2) {
      out.add('tu');
      x -= 2;
    }
    if (x > 0) out.add('wan');
  }
  encode(number);
  return out;
}

double manualTallyLift(
  ProductionFontInfo font,
  FullParserOptions options,
  double fontSize,
) {
  final maxPx = options.manualTallySmallFontMaxPx ??
      _settingFloat(font.settings, 'manualTallySmallFontMaxPx', 12);
  final lift = options.manualTallySmallFontLiftPx ??
      _settingFloat(font.settings, 'manualTallySmallFontLiftPx', 0);
  return fontSize <= maxPx ? math.max(0, lift) : 0;
}

List<String> fullOpenTypeFeaturesFor(double fontSize) {
  // Protocol v1.1 uses inline vulgar-fraction controls for cartouche scaling.
  // Legacy ss12/ss13/ss14 selection is intentionally disabled.
  return const <String>[];
}

bool allRunesUcsur(String text) {
  if (text.isEmpty) return false;
  for (final cp in text.runes) {
    if (!((cp >= 0xF1900 && cp <= 0xF19FF) ||
        cp == openQuoteCodepoint ||
        cp == closeQuoteCodepoint)) {
      return false;
    }
  }
  return true;
}

String sanitizeRendererWord(String value) => value
    .toLowerCase()
    .replaceAll(RegExp(r'[^a-z0-9<>\^\.]'), '');
