import 'dart:convert';
import 'dart:typed_data';

import 'full_types.dart';
import 'renderer.dart' as numeric_renderer;
import 'v11_numeric.dart';
import 'nasin_nanpa_pona.dart';

const List<List<String>> _fullAliases = <List<String>>[
  <String>["'cartouche-start'", '['],
  <String>["'cartouche-end'", ']'],
  <String>["'zw-joiner'", '&'],
  <String>["'stack-joiner'", '-'],
  <String>["'nesting-joiner'", '+'],
  <String>["'ideographic-space'", ' zz '],
  <String>["'long-start'", '('],
  <String>["'long-end'", ')'],
  <String>["'left-bracket'", ' te '],
  <String>["'right-bracket'", ' to '],
  <String>["'middle-dot'", '.'],
  <String>["'colon'", ':'],
  <String>["'tally'", ','],
];

String _normalizeDocument(String input, FullParserOptions options) {
  var out = input;
  if (options.effectiveRendererMode != 'standard-sitelen-pona-ascii-core') {
    for (final alias in _fullAliases) {
      out = out.replaceAll(alias[0], alias[1]);
    }
  }
  return out.replaceAll('\r\n', '\n').replaceAll('\r', '\n');
}

bool _isDigitCodeUnit(int c) => c >= 0x30 && c <= 0x39;
bool _isSpaceCodeUnit(int c) =>
    c == 0x20 || c == 0x09 || c == 0x0A || c == 0x0D;

bool _sentenceStop(String text, int index) {
  final prev = index > 0 ? text.codeUnitAt(index - 1) : 0;
  final next = index + 1 < text.length ? text.codeUnitAt(index + 1) : 0;
  final numeric = _isDigitCodeUnit(next) &&
      (_isDigitCodeUnit(prev) ||
          index == 0 ||
          _isSpaceCodeUnit(prev) ||
          '+-(,:='.codeUnits.contains(prev));
  return !numeric;
}

List<String> _splitFullStops(String line) {
  final out = <String>[];
  var start = 0;
  var square = 0;
  var paren = 0;
  var brace = 0;
  String? quote;
  var i = 0;
  while (i < line.length) {
    final ch = line[i];
    if (quote != null) {
      if (ch == r'\') {
        i += 2;
        continue;
      }
      final close = (quote == '“' && (ch == '”' || ch == '"')) ||
          (quote == '"' && (ch == '"' || ch == '”'));
      if (close) quote = null;
      i++;
      continue;
    }
    if (ch == '"' || ch == '“') {
      quote = ch;
      i++;
      continue;
    }
    switch (ch) {
      case '[':
        square++;
        break;
      case ']':
        if (square > 0) square--;
        break;
      case '(':
        paren++;
        break;
      case ')':
        if (paren > 0) paren--;
        break;
      case '{':
        brace++;
        break;
      case '}':
        if (brace > 0) brace--;
        break;
      case '.':
        if (square == 0 &&
            paren == 0 &&
            brace == 0 &&
            _sentenceStop(line, i)) {
          var end = i + 1;
          while (end < line.length &&
              line[end] == '.' &&
              _sentenceStop(line, end)) {
            end++;
          }
          final piece = line.substring(start, end);
          if (piece.trim().isNotEmpty) out.add(piece);
          start = end;
          i = end;
          continue;
        }
        break;
    }
    i++;
  }
  final tail = line.substring(start);
  if (tail.trim().isNotEmpty || out.isEmpty) out.add(tail);
  return out;
}

List<String> _splitArgs(String input) {
  final out = <String>[];
  final current = StringBuffer();
  String? quote;
  var escaped = false;
  var depth = 0;
  for (var i = 0; i < input.length; i++) {
    final ch = input[i];
    if (escaped) {
      current.write(ch);
      escaped = false;
      continue;
    }
    if (ch == r'\') {
      current.write(ch);
      escaped = true;
      continue;
    }
    if (quote != null) {
      current.write(ch);
      if (ch == quote) quote = null;
      continue;
    }
    if (ch == "'" || ch == '"') {
      quote = ch;
      current.write(ch);
      continue;
    }
    if (ch == '(') {
      depth++;
      current.write(ch);
      continue;
    }
    if (ch == ')' && depth > 0) {
      depth--;
      current.write(ch);
      continue;
    }
    if (ch == ',' && depth == 0) {
      out.add(current.toString().trim());
      current.clear();
      continue;
    }
    current.write(ch);
  }
  out.add(current.toString().trim());
  return out;
}

String _stripQuotes(String value) {
  final s = value.trim();
  if (s.length >= 2 &&
      ((s.startsWith("'") && s.endsWith("'")) ||
          (s.startsWith('"') && s.endsWith('"')))) {
    return s.substring(1, s.length - 1);
  }
  return s;
}

ImageDescriptor _parseImageArgs(String arg) {
  var src = '';
  var width = '';
  var height = '';
  var alt = '';
  var vAlign = 'baseline';
  var wriggle = 8.0;
  var transparent = true;
  for (final part in _splitArgs(arg)) {
    if (part.isEmpty) continue;
    final at = part.indexOf('=');
    if (at < 0) continue;
    final key = part.substring(0, at).trim().toLowerCase();
    final value = _stripQuotes(part.substring(at + 1));
    switch (key) {
      case 'src':
        src = value;
        break;
      case 'w':
      case 'width':
        width = value;
        break;
      case 'h':
      case 'height':
        height = value;
        break;
      case 'alt':
        alt = value;
        break;
      case 'valign':
        vAlign = value;
        break;
      case 'wriggle':
        wriggle = double.tryParse(value) ?? wriggle;
        break;
      case 'transparent':
        final v = value.toLowerCase();
        transparent = !(v == 'false' || v == '0' || v == 'no');
        break;
    }
  }
  return ImageDescriptor(
    src: src,
    width: width,
    height: height,
    alt: alt,
    vAlign: vAlign,
    wriggle: wriggle,
    transparent: transparent,
  );
}

List<DocumentSegment> _segments(String line) {
  final out = <DocumentSegment>[];
  var i = 0;
  var start = 0;

  void pushText(int a, int b) {
    if (b > a) {
      out.add(DocumentSegment(
        kind: 'text',
        value: line.substring(a, b),
        sourceStart: a,
        sourceEnd: b,
      ));
    }
  }

  while (i < line.length) {
    final ch = line[i];
    if (ch == '[') {
      final end = line.indexOf(']', i + 1);
      if (end < 0) break;
      pushText(start, i);
      out.add(DocumentSegment(
        kind: 'bracket',
        value: line.substring(i + 1, end),
        sourceStart: i,
        sourceEnd: end + 1,
      ));
      i = end + 1;
      start = i;
      continue;
    }
    if (ch == '"') {
      var j = i + 1;
      var found = -1;
      while (j < line.length) {
        if (line[j] == '"' && (j == 0 || line[j - 1] != r'\')) {
          found = j;
          break;
        }
        j++;
      }
      if (found < 0) break;
      pushText(start, i);
      out.add(DocumentSegment(
        kind: 'quote',
        value: line.substring(i + 1, found),
        openQuote: '"',
        closeQuote: '"',
        sourceStart: i,
        sourceEnd: found + 1,
      ));
      i = found + 1;
      start = i;
      continue;
    }
    if (ch == '“') {
      var j = i + 1;
      var found = -1;
      var closeQuote = '”';
      while (j < line.length) {
        if (line[j] == '”' || line[j] == '"') {
          found = j;
          closeQuote = line[j];
          break;
        }
        j++;
      }
      if (found < 0) break;
      pushText(start, i);
      out.add(DocumentSegment(
        kind: 'quote',
        value: line.substring(i + 1, found),
        openQuote: '“',
        closeQuote: closeQuote,
        sourceStart: i,
        sourceEnd: found + 1,
      ));
      i = found + 1;
      start = i;
      continue;
    }
    if (line.startsWith('img(', i)) {
      var j = i + 4;
      var depth = 1;
      String? quote;
      var escaped = false;
      while (j < line.length) {
        final c = line[j];
        if (escaped) {
          escaped = false;
          j++;
          continue;
        }
        if (c == r'\') {
          escaped = true;
          j++;
          continue;
        }
        if (quote != null) {
          if (c == quote) quote = null;
          j++;
          continue;
        }
        if (c == "'" || c == '"') {
          quote = c;
          j++;
          continue;
        }
        if (c == '(') {
          depth++;
        } else if (c == ')') {
          depth--;
          if (depth == 0) break;
        }
        j++;
      }
      if (j >= line.length) break;
      pushText(start, i);
      out.add(DocumentSegment(
        kind: 'image',
        image: _parseImageArgs(line.substring(i + 4, j)),
        sourceStart: i,
        sourceEnd: j + 1,
      ));
      i = j + 1;
      start = i;
      continue;
    }
    i++;
  }
  pushText(start, line.length);
  return out;
}

DocumentAst parseFullDocument(String input, FullParserOptions options) {
  final normalized = _normalizeDocument(input, options);
  final lines = <DocumentLine>[];
  final sourceLines = normalized.split('\n');
  for (var sourceLineIndex = 0;
      sourceLineIndex < sourceLines.length;
      sourceLineIndex++) {
    final source = sourceLines[sourceLineIndex];
    final rendered = options.breakLinesAtFullStops
        ? _splitFullStops(source)
        : <String>[source];
    for (var sentenceIndex = 0;
        sentenceIndex < rendered.length;
        sentenceIndex++) {
      final text = rendered[sentenceIndex];
      lines.add(DocumentLine(
        index: lines.length,
        sourceLineIndex: sourceLineIndex,
        sentenceIndexInSourceLine: sentenceIndex,
        sourceText: text,
        children: _segments(text),
      ));
    }
  }
  return DocumentAst(
    normalizedInput: normalized,
    breakLinesAtFullStops: options.breakLinesAtFullStops,
    parserOptions: options,
    lines: List<DocumentLine>.unmodifiable(lines),
  );
}

String _quoteImageArgument(String value) {
  if (!value.contains("'")) return "'${value}'";
  if (!value.contains('"')) return '"${value}"';
  final escaped = value.replaceAll(r'\', r'\\').replaceAll('"', r'\"');
  return '"$escaped"';
}

String _imageDescriptorToText(ImageDescriptor image) {
  final args = <String>[];
  if (image.src.isNotEmpty) args.add('src=${_quoteImageArgument(image.src)}');
  if (image.width.isNotEmpty) args.add('w=${_quoteImageArgument(image.width)}');
  if (image.height.isNotEmpty) args.add('h=${_quoteImageArgument(image.height)}');
  args.add('alt=${_quoteImageArgument(image.alt)}');
  if (image.vAlign.isNotEmpty && image.vAlign != 'baseline') {
    args.add('valign=${_quoteImageArgument(image.vAlign)}');
  }
  if (image.wriggle != 8) args.add('wriggle=${image.wriggle}');
  if (!image.transparent) args.add('transparent=false');
  return 'img(${args.join(',')})';
}

String _documentSegmentToText(DocumentSegment segment) {
  switch (segment.kind) {
    case 'text':
      return segment.value;
    case 'bracket':
      return '[${segment.value}]';
    case 'quote':
      final openQuote = segment.openQuote.isEmpty ? '"' : segment.openQuote;
      final closeQuote = segment.closeQuote.isEmpty
          ? (openQuote == '“' ? '”' : '"')
          : segment.closeQuote;
      return '$openQuote${segment.value}$closeQuote';
    case 'image':
      final image = segment.image;
      if (image == null) {
        throw ArgumentError('image AST segment requires an ImageDescriptor.');
      }
      return _imageDescriptorToText(image);
    case 'rawUcsur':
      final out = <String>[];
      for (final cp in segment.codepoints) {
        if (cp < 0 || cp > 0x10FFFF || (cp >= 0xD800 && cp <= 0xDFFF)) {
          throw ArgumentError('rawUcsur AST segment contains an invalid Unicode scalar: $cp');
        }
        out.add('U+${cp.toRadixString(16).toUpperCase().padLeft(4, '0')}');
      }
      return out.join(' ');
    default:
      throw ArgumentError('Unsupported AST segment kind: ${segment.kind}');
  }
}

/// Converts a document AST returned by [parseFullDocument] or the high-level
/// `NanpaLinjaN.parseInput()` facade back into valid nanpa-linja-n source text.
///
/// With the default `numericOutput: "source"`, current AST content is serialized
/// exactly as before. When numeric span metadata is present, `properName`, `#~`,
/// and `cartouche` request canonical numeric re-serialization through the existing
/// numeric parser/renderer. Unsupported representations preserve the exact source.
String _numericOutputMode(FullRenderOptions? options) {
  final mode = (options?.numericOutput ?? 'source').trim();
  if (!const <String>{'source', 'properName', '#~', 'cartouche'}.contains(mode)) {
    throw ArgumentError('Unsupported numericOutput mode: $mode');
  }
  return mode;
}

String _numericSourceToText(
  String source,
  String mode,
  FullParserOptions parser,
) {
  if (mode == 'source') return source;
  final coreRendered = numeric_renderer.renderNumber(source, parser.numericOptions());
  if (coreRendered == null) return source;
  final rendered = normalizeV11RenderResult(coreRendered);
  final parsed = rendered.parsed;

  if (parser.nasinNanpaPona) {
    final words = tryPlainDecimalToNasinNanpaPonaWords(parsed.displayValue);
    if (words != null && words.isNotEmpty) return words.join(' ');
  }

  switch (mode) {
    case 'properName':
      return parsed.properName.isNotEmpty ? parsed.properName : source;
    case '#~':
      return parsed.uniqueCode.startsWith('#~') ? parsed.uniqueCode : source;
    case 'cartouche':
      final words = parser.abbreviateNumericCartouches
          ? rendered.abbreviatedWords
          : rendered.fullWords;
      return words != null && words.isNotEmpty
          ? '[${words.join(' ')}]'
          : source;
  }
  return source;
}

String _applyNumericStructures(
  String source,
  DocumentSegment segment,
  String mode,
  FullParserOptions parser,
) {
  if (mode == 'source' || segment.numericStructures.isEmpty) return source;
  final structures = List<NumericStructure>.from(segment.numericStructures)
    ..sort((a, b) {
      final byStart = a.index.compareTo(b.index);
      return byStart != 0 ? byStart : a.end.compareTo(b.end);
    });
  final out = StringBuffer();
  var position = 0;
  var replaced = false;
  for (final structure in structures) {
    if (structure.index < 0 ||
        structure.end <= structure.index ||
        structure.end > source.length ||
        structure.index < position) {
      continue;
    }
    // Numeric metadata is deliberately additive. If a caller edits the AST text
    // without rebuilding metadata, preserve the edit instead of rewriting it.
    if (source.substring(structure.index, structure.end) != structure.sourceText) {
      continue;
    }
    out.write(source.substring(position, structure.index));
    out.write(_numericSourceToText(structure.sourceText, mode, parser));
    position = structure.end;
    replaced = true;
  }
  if (!replaced) return source;
  out.write(source.substring(position));
  return out.toString();
}

String astToText(DocumentAst ast, [FullRenderOptions? options]) {
  final mode = _numericOutputMode(options);
  final parser = options?.parser ?? ast.parserOptions;
  final out = StringBuffer();
  int? previousSourceLineIndex;
  var havePrevious = false;

  for (var i = 0; i < ast.lines.length; i++) {
    final line = ast.lines[i];
    final currentSourceLineIndex =
        line.sourceLineIndex >= 0 ? line.sourceLineIndex : i;
    if (havePrevious && currentSourceLineIndex != previousSourceLineIndex) {
      out.write('\n');
    }
    for (final segment in line.children) {
      final source = _documentSegmentToText(segment);
      out.write(_applyNumericStructures(source, segment, mode, parser));
    }
    havePrevious = true;
    previousSourceLineIndex = currentSourceLineIndex;
  }
  return out.toString();
}

final RegExp _rawUnicode = RegExp(
  r'^U\+([0-9A-Fa-f]{4,6})$',
  caseSensitive: false,
);

List<int>? parseRawUnicodeSequence(String text) {
  final tokens = text.trim().split(RegExp(r'\s+'));
  if (tokens.isEmpty || (tokens.length == 1 && tokens.first.isEmpty)) return null;
  final out = <int>[];
  for (final token in tokens) {
    final m = _rawUnicode.firstMatch(token);
    if (m == null) return null;
    final value = int.tryParse(m.group(1)!, radix: 16);
    if (value == null || value > 0x10FFFF) return null;
    out.add(value);
  }
  return out;
}

Uint8List? decodeDataImage(String src) {
  if (!src.startsWith('data:image/')) return null;
  final comma = src.indexOf(',');
  if (comma < 0) return null;
  final meta = src.substring(0, comma);
  final data = src.substring(comma + 1);
  try {
    if (meta.contains(';base64')) return base64Decode(data);
    return Uint8List.fromList(utf8.encode(Uri.decodeComponent(data)));
  } catch (_) {
    return null;
  }
}
