import 'constants.dart';

const int _colonCodepoint = 0xF199D;
const int _middleDotCodepoint = 0xF199C;
const int _tallyCodepoint = 0xF199E;
const int _openQuoteCodepoint = 0x300C;
const int _closeQuoteCodepoint = 0x300D;

const int vulgarScaleQuarter = 0x00BC; // ¼
const int vulgarScaleThird = 0x2153; // ⅓
const int vulgarScaleHalf = 0x00BD; // ½
const int vulgarScaleTwoThirds = 0x2154; // ⅔
const int vulgarScaleThreeQuarters = 0x00BE; // ¾

const Set<int> vulgarScaleMarkers = <int>{
  vulgarScaleQuarter,
  vulgarScaleThird,
  vulgarScaleHalf,
  vulgarScaleTwoThirds,
  vulgarScaleThreeQuarters,
};

const Map<String, int> asciiScaleAliases = <String, int>{
  '1/4': vulgarScaleQuarter,
  '1/3': vulgarScaleThird,
  '1/2': vulgarScaleHalf,
  '2/3': vulgarScaleTwoThirds,
  '3/4': vulgarScaleThreeQuarters,
};

const Set<String> _legacyAsciiAdapters = <String>{
  'linja-pona-legacy-v1',
  'linja-sike-legacy-v1',
};

bool _settingBool(Map<String, dynamic> values, String key, bool fallback) {
  final value = values[key];
  return value is bool ? value : fallback;
}

bool vulgarScalingEnabled(Map<String, dynamic> settings) =>
    _settingBool(settings, 'cartoucheVulgarFractions', false) ||
    _settingBool(settings, 'emulateLegacyCartoucheScaling', false);

int numericCartoucheScaleMarker(List<int> cps, int index) {
  if (index <= 0 || index >= cps.length - 1) return 0;
  final cp = cps[index];
  final first = 1;
  final last = cps.length - 2;
  final halfHeads = <int>{
    allWordCodepoints['nanpa']!,
    allWordCodepoints['nasa']!,
    allWordCodepoints['noka']!,
    allWordCodepoints['tenpo']!,
    allWordCodepoints['suno']!,
    allWordCodepoints['toki']!,
  };
  final halfClosers = <int>{
    allWordCodepoints['nanpa']!,
    allWordCodepoints['nasa']!,
    allWordCodepoints['noka']!,
  };
  if (index == first && halfHeads.contains(cp)) return vulgarScaleHalf;
  if (index == first + 1 &&
      cp == _colonCodepoint &&
      halfHeads.contains(cps[first])) {
    return vulgarScaleHalf;
  }
  if (index == last && halfClosers.contains(cp)) return vulgarScaleHalf;

  // Explicit-positive leading en in [head : nena en ...] or [head en ...].
  if (cp == allWordCodepoints['en'] && cps.length >= 4 && halfHeads.contains(cps[first])) {
    if (index == first + 1 ||
        (index == first + 2 && cps[first + 1] == _colonCodepoint) ||
        (index == first + 3 &&
            cps[first + 2] == allWordCodepoints['nena'] &&
            (cps[first + 1] == allWordCodepoints['e'] ||
                cps[first + 1] == _colonCodepoint))) {
      return vulgarScaleTwoThirds;
    }
  }

  final word = allCodepointWords[cp];
  if (word != null &&
      word.isNotEmpty &&
      (word.startsWith('e') || word.startsWith('n')) &&
      RegExp(r'^[a-z]+$').hasMatch(word)) {
    return vulgarScaleQuarter;
  }
  if (<int>{
    allWordCodepoints['ala']!,
    allWordCodepoints['ike']!,
    allWordCodepoints['uta']!,
    allWordCodepoints['open']!,
  }.contains(cp)) {
    return vulgarScaleQuarter;
  }
  if (<int>{
    allWordCodepoints['kasi']!,
    allWordCodepoints['kule']!,
  }.contains(cp)) {
    return vulgarScaleThird;
  }
  if (cp == allWordCodepoints['kala']) return vulgarScaleHalf;
  if (<int>{
    allWordCodepoints['ona']!,
    allWordCodepoints['o']!,
    allWordCodepoints['kulupu']!,
    allWordCodepoints['kipisi']!,
    allWordCodepoints['kin']!,
  }.contains(cp)) {
    return vulgarScaleTwoThirds;
  }
  return 0;
}

class AdaptedProductionRun {
  final String text;
  final String adapterId;
  final List<int> canonicalCodepoints;
  final bool legacyAscii;

  const AdaptedProductionRun({
    required this.text,
    required this.adapterId,
    required this.canonicalCodepoints,
    required this.legacyAscii,
  });
}

void _appendScaleMarker(
  StringBuffer out,
  List<int> cps,
  int index,
  bool enabled,
) {
  if (!enabled) return;
  final marker = numericCartoucheScaleMarker(cps, index);
  if (marker != 0) out.writeCharCode(marker);
}

String _directProductionCartouche(List<int> cps, bool scale) {
  final out = StringBuffer();
  for (var i = 0; i < cps.length; i++) {
    out.writeCharCode(cps[i]);
    if (i > 0 && i < cps.length - 1) {
      _appendScaleMarker(out, cps, i, scale);
    }
  }
  return out.toString();
}

String _legacyProductionCartouche(
  List<int> cps,
  String adapterId,
  bool scale,
) {
  if (cps.length < 2 || cps.first != cartoucheStart || cps.last != cartoucheEnd) {
    throw ArgumentError('$adapterId requires a complete canonical cartouche');
  }
  final out = StringBuffer('[');
  for (var i = 1; i < cps.length - 1; i++) {
    final cp = cps[i];
    out.write('_');
    if (cp == _colonCodepoint) {
      out.write(':');
    } else {
      final word = allCodepointWords[cp];
      if (word == null) {
        throw StateError(
          '$adapterId has no legacy numeric encoding for '
          'U+${cp.toRadixString(16).toUpperCase().padLeft(4, '0')}',
        );
      }
      out.write(word);
    }
    _appendScaleMarker(out, cps, i, scale);
  }
  out.write(']');
  return out.toString();
}

String _nasinPuProductionCartouche(List<int> cps, bool scale) {
  final out = StringBuffer();
  for (var i = 0; i < cps.length; i++) {
    final cp = cps[i];
    switch (cp) {
      case 0xF1989:
      case 0xF198A:
      case 0xF198B:
        out.writeCharCode(allWordCodepoints['ni']!);
        break;
      case 0xF198C:
        out.writeCharCode(allWordCodepoints['sewi']!);
        break;
      case _colonCodepoint:
        out.write(':');
        break;
      case _middleDotCodepoint:
        out.write('.');
        break;
      default:
        out.writeCharCode(cp);
        break;
    }
    if (i > 0 && i < cps.length - 1) {
      _appendScaleMarker(out, cps, i, scale);
    }
  }
  return out.toString();
}

bool _lipamankaNeedsTranslation(
  List<int> cps,
  Map<String, dynamic> settings,
) {
  final deterministic = _settingBool(settings, 'deterministicAlternates', true);
  final jaki = allWordCodepoints['jaki'];
  final ko = allWordCodepoints['ko'];
  for (final cp in cps) {
    if (<int>{
      _colonCodepoint,
      _middleDotCodepoint,
      _tallyCodepoint,
      0xF1989,
      0xF198A,
      0xF198B,
      0xF198C,
      _openQuoteCodepoint,
      _closeQuoteCodepoint,
      0x3000,
    }.contains(cp)) {
      return true;
    }
    if (cp == 0xF19A5 || (cp > 0xF19A3 && cp != 0xF19A4 && cp != 0xF19A6)) {
      return true;
    }
    if (deterministic && (cp == jaki || cp == ko)) return true;
  }
  return false;
}

String _lipamankaProductionCartouche(
  List<int> cps,
  Map<String, dynamic> settings,
  bool scale,
) {
  if (!_lipamankaNeedsTranslation(cps, settings) ||
      cps.length < 2 ||
      cps.first != cartoucheStart ||
      cps.last != cartoucheEnd) {
    return _directProductionCartouche(cps, scale);
  }
  final out = StringBuffer('[');
  for (var i = 1; i < cps.length - 1; i++) {
    if (i > 1) out.write(' ');
    final cp = cps[i];
    switch (cp) {
      case _colonCodepoint:
        out.write(':');
        break;
      case _middleDotCodepoint:
        out.write('.');
        break;
      case 0xF1989:
      case 0xF198A:
      case 0xF198B:
        out.write('ni');
        break;
      case 0xF198C:
        out.write('sewi');
        break;
      default:
        out.write(allCodepointWords[cp] ?? '�');
        break;
    }
    _appendScaleMarker(out, cps, i, scale);
  }
  out.write(']');
  return out.toString();
}

AdaptedProductionRun adaptProductionNumericCartouche(
  Iterable<int> codepoints,
  String renderAdapterId, [
  Map<String, dynamic> renderAdapterSettings = const <String, dynamic>{},
  Map<String, dynamic> fontSettings = const <String, dynamic>{},
]) {
  final cps = List<int>.unmodifiable(codepoints.map((e) => e.toInt()));
  final adapterId = renderAdapterId.trim().isEmpty ? 'identity' : renderAdapterId.trim();
  final scale = vulgarScalingEnabled(fontSettings);
  late final String text;
  var legacyAscii = false;
  if (_legacyAsciiAdapters.contains(adapterId)) {
    text = _legacyProductionCartouche(cps, adapterId, scale);
    legacyAscii = true;
  } else if (adapterId == 'nasin-sitelen-pu-mono-v1') {
    text = _nasinPuProductionCartouche(cps, scale);
  } else if (adapterId == 'linja-lipamanka-v1') {
    text = _lipamankaProductionCartouche(cps, renderAdapterSettings, scale);
  } else {
    text = _directProductionCartouche(cps, scale);
  }
  return AdaptedProductionRun(
    text: text,
    adapterId: adapterId,
    canonicalCodepoints: cps,
    legacyAscii: legacyAscii,
  );
}

List<int> renderCodepointsWithoutScaleMarkers(String text) => <int>[
      for (final cp in text.runes)
        if (!vulgarScaleMarkers.contains(cp)) cp,
    ];

List<String> productionOpenTypeFeaturesForSize(int fontSize) {
  // Protocol v1.1 carries cartouche scaling in the text stream via inline
  // vulgar-fraction controls. ss12/ss13/ss14 are never selected automatically.
  return const <String>['calt', 'liga', 'ccmp'];
}
