import 'options.dart';

enum NumberKind { hex, binary }

class NumericPart {
  final String kind;
  final String? digits;
  final String? char;
  const NumericPart.digits(this.digits) : kind = 'digits', char = null;
  const NumericPart.delimiter(this.char) : kind = 'delimiter', digits = null;
  Map<String, dynamic> toJson() => kind == 'digits'
      ? {'kind': kind, 'digits': digits}
      : {'kind': kind, 'char': char};
}

class ParseResult {
  String input;
  String? caps;
  String properName;
  String uniqueCode;
  List<int> ucsurCodepoints;
  String hexCodepoints;
  String hexWithCartouche;
  List<String> tpWords;
  List<String> words;
  String displayValue;
  bool isTime;
  bool isDate;
  bool isTimeLike;
  List<int> innerCodepoints;
  List<int> codepoints;
  String numericMode;
  SemanticKind? semanticKind;
  DecimalStartGlyph? semanticStartGlyph;
  NumberKind? kind;
  int? numberBase;
  bool isHex;
  bool isBinary;
  String? hexDigits;
  String? binaryDigits;
  List<NumericPart>? hexParts;
  List<NumericPart>? binaryParts;
  List<int>? abbreviatedUcsurCodepoints;
  List<String>? abbreviatedWords;
  List<String>? nasinNanpaPonaWords;

  ParseResult({
    required this.input,
    required this.caps,
    required this.properName,
    required this.uniqueCode,
    required this.ucsurCodepoints,
    required this.hexCodepoints,
    required this.hexWithCartouche,
    required this.tpWords,
    required this.words,
    required this.displayValue,
    required this.isTime,
    required this.isDate,
    required this.isTimeLike,
    required this.innerCodepoints,
    required this.codepoints,
    required this.numericMode,
    this.semanticKind,
    this.semanticStartGlyph,
    this.kind,
    this.numberBase,
    this.isHex = false,
    this.isBinary = false,
    this.hexDigits,
    this.binaryDigits,
    this.hexParts,
    this.binaryParts,
    this.abbreviatedUcsurCodepoints,
    this.abbreviatedWords,
    this.nasinNanpaPonaWords,
  });

  Map<String, dynamic> toJson() {
    final out = <String, dynamic>{
      'input': input,
      'caps': caps,
      'properName': properName,
      'uniqueCode': uniqueCode,
      'ucsurCodepoints': ucsurCodepoints,
      'hexCodepoints': hexCodepoints,
      'hexWithCartouche': hexWithCartouche,
      'tpWords': tpWords,
      'words': words,
      'displayValue': displayValue,
      'isTime': isTime,
      'isDate': isDate,
      'isTimeLike': isTimeLike,
      'innerCodepoints': innerCodepoints,
      'codepoints': codepoints,
      'numericMode': numericMode,
    };
    if (kind == null) {
      out['semanticKind'] = semanticKind?.name;
      out['semanticStartGlyph'] = semanticStartGlyph?.name;
    }
    if (kind != null) out['kind'] = kind!.name;
    if (numberBase != null) out['numberBase'] = numberBase;
    if (isHex) out['isHex'] = true;
    if (isBinary) out['isBinary'] = true;
    if (hexDigits != null) out['hexDigits'] = hexDigits;
    if (binaryDigits != null) out['binaryDigits'] = binaryDigits;
    if (hexParts != null) out['hexParts'] = hexParts!.map((e) => e.toJson()).toList();
    if (binaryParts != null) out['binaryParts'] = binaryParts!.map((e) => e.toJson()).toList();
    if (abbreviatedUcsurCodepoints != null) out['abbreviatedUcsurCodepoints'] = abbreviatedUcsurCodepoints;
    if (abbreviatedWords != null) out['abbreviatedWords'] = abbreviatedWords;
    if (nasinNanpaPonaWords != null) out['nasinNanpaPonaWords'] = nasinNanpaPonaWords;
    return out;
  }
}

class CapsCodepointsResult {
  final List<int> innerCodepoints;
  final List<int> codepoints;
  final List<String> words;
  final String numericMode;
  final bool isTimeLike;
  const CapsCodepointsResult({required this.innerCodepoints, required this.codepoints, required this.words, required this.numericMode, required this.isTimeLike});
  Map<String, dynamic> toJson() => {
    'innerCodepoints': innerCodepoints,
    'codepoints': codepoints,
    'words': words,
    'numericMode': numericMode,
    'isTimeLike': isTimeLike,
  };
}

class IdentifierResult {
  final String input;
  final List<int> innerCodepoints;
  final List<int> codepoints;
  final List<String> words;
  final String numericMode;
  const IdentifierResult({required this.input, required this.innerCodepoints, required this.codepoints, required this.words, required this.numericMode});
  Map<String, dynamic> toJson() => {
    'input': input,
    'innerCodepoints': innerCodepoints,
    'codepoints': codepoints,
    'words': words,
    'numericMode': numericMode,
  };
}
