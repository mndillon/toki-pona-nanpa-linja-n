import 'dart:io';
import 'dart:typed_data';

import 'model.dart';
import 'full_document.dart' as full_document;
import 'full_renderer.dart';
import 'full_types.dart';
import 'native_production_renderer.dart';
import 'options.dart';
import 'parser.dart' as parser_api;
import 'production_font_adapters.dart';
import 'production_font_registry.dart';
import 'public_parser.dart' as public_parser_api;
import 'public_parser.dart' show defaultPublicParseOptions;
import 'renderer.dart';
import 'v11_numeric.dart';

const int defaultProductionFontSize = 56;
const int defaultProductionPadding = 4;

class ProductionRenderPlan {
  final Object? input;
  final ParseResult parsed;
  final ProductionFontInfo font;
  final List<int> canonicalCodepoints;
  final String renderText;
  final String renderAdapterId;
  final bool legacyAscii;
  final int fontSize;
  final int outerPadding;
  final List<String> openTypeFeatures;
  final bool abbreviated;
  final bool preserveNumericCartoucheBreaks;

  const ProductionRenderPlan({
    required this.input,
    required this.parsed,
    required this.font,
    required this.canonicalCodepoints,
    required this.renderText,
    required this.renderAdapterId,
    required this.legacyAscii,
    required this.fontSize,
    required this.outerPadding,
    required this.openTypeFeatures,
    required this.abbreviated,
    required this.preserveNumericCartoucheBreaks,
  });

  List<int> get renderCodepoints => List<int>.unmodifiable(
        renderCodepointsWithoutScaleMarkers(renderText),
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'input': input,
        'parsed': parsed.toJson(),
        'font': font.toJson(),
        'canonicalCodepoints': canonicalCodepoints,
        'renderText': renderText,
        'renderCodepoints': renderCodepoints,
        'renderAdapterId': renderAdapterId,
        'legacyAscii': legacyAscii,
        'fontSize': fontSize,
        'outerPadding': outerPadding,
        'openTypeFeatures': openTypeFeatures,
        'abbreviated': abbreviated,
        'preserveNumericCartoucheBreaks': preserveNumericCartoucheBreaks,
      };
}

class ProductionRenderResult {
  final Uint8List bytes;
  final int width;
  final int height;
  final ProductionOutputFormat format;
  final ProductionRenderPlan plan;

  const ProductionRenderResult({
    required this.bytes,
    required this.width,
    required this.height,
    required this.format,
    required this.plan,
  });

  String get fontKey => plan.font.key;
  String get renderAdapterId => plan.renderAdapterId;

  File save(String path) {
    final file = File(path).absolute;
    file.parent.createSync(recursive: true);
    file.writeAsBytesSync(bytes, flush: true);
    return file;
  }
}

/// High-level production facade for nanpa-linja-n.
///
/// Core-v1 parsing and logical rendering remain pure Dart. Graphical rendering
/// uses the platform Pango/HarfBuzz + Cairo + Fontconfig stack with the exact
/// eight production font pairs bundled in this package.
class NanpaLinjaN {
  final ProductionFontRegistry _fonts;
  final String _defaultFont;
  final int _defaultFontSize;
  final ParseOptions _defaultParserOptions;
  final Map<String, FullRenderAdapter> _fullAdapters = <String, FullRenderAdapter>{};
  late final DartFullRenderer _fullRenderer;

  NanpaLinjaN._({
    required ProductionFontRegistry fonts,
    required String defaultFont,
    required int defaultFontSize,
    required ParseOptions parserOptions,
  })  : _fonts = fonts,
        _defaultFont = fonts.normalizeKey(defaultFont),
        _defaultFontSize = defaultFontSize < 8 ? 8 : defaultFontSize,
        _defaultParserOptions = parserOptions {
    _fullRenderer = DartFullRenderer(_fonts, _fullAdapters);
  }

  factory NanpaLinjaN.create({
    String? assetRoot,
    String defaultFont = defaultProductionFontKey,
    int defaultFontSize = defaultProductionFontSize,
    ParseOptions parserOptions = defaultPublicParseOptions,
  }) =>
      NanpaLinjaN._(
        fonts: ProductionFontRegistry.load(assetRoot: assetRoot),
        defaultFont: defaultFont,
        defaultFontSize: defaultFontSize,
        parserOptions: parserOptions,
      );

  List<ProductionFontInfo> get fonts => listFonts();

  List<ProductionFontInfo> listFonts() =>
      List<ProductionFontInfo>.unmodifiable(_fonts.fonts);

  String normalizeFontKey(String? font) => _fonts.normalizeKey(font ?? _defaultFont);

  ProductionFontInfo getFontInfo(String font) => _fonts.get(font);

  ParseResult parse(
    Object? input, {
    ParseOptions? parserOptions,
  }) {
    final parsed = parser_api.parseNumber(
      input,
      parserOptions ?? _defaultParserOptions,
    );
    if (parsed == null) {
      throw FormatException('Not a valid nanpa-linja-n numeric input: $input');
    }
    return parsed;
  }

  /// Public Protocol-v1.1 numeric parser. Returns the canonical parsed-number
  /// result, or null when [input] is not a valid numeric form under the supplied
  /// parser options. Alternate textual forms are produced by [astToText].
  ParseResult? parseNumber(
    Object? input, {
    ParseOptions? parserOptions,
  }) =>
      public_parser_api.parseNumber(
        input,
        parserOptions ?? _defaultParserOptions,
      );

  ProductionRenderPlan buildRenderPlan(
    Object? input, {
    String? font,
    int? fontSize,
    bool abbreviate = true,
    bool preserveNumericCartoucheBreaks = false,
    int outerPadding = defaultProductionPadding,
    ParseOptions? parserOptions,
  }) {
    final pair = _fonts.get(font ?? _defaultFont);
    final baseOptions = parserOptions ?? _defaultParserOptions;
    final renderOptions = baseOptions.copyWith(
      abbreviateNumericCartouches: abbreviate,
      preserveNumericCartoucheBreaksInAbbreviation:
          preserveNumericCartoucheBreaks,
    );
    final coreLogical = renderNumber(input, renderOptions);
    final logical = coreLogical == null ? null : normalizeV11RenderResult(coreLogical);
    if (logical == null) {
      throw FormatException('Not a valid nanpa-linja-n numeric input: $input');
    }
    final adapted = adaptProductionNumericCartouche(
      logical.activeCodepoints,
      pair.renderAdapterId,
      pair.renderAdapterSettings,
      pair.settings,
    );
    final size = (fontSize ?? _defaultFontSize) < 8
        ? 8
        : (fontSize ?? _defaultFontSize);
    return ProductionRenderPlan(
      input: input,
      parsed: logical.parsed,
      font: pair,
      canonicalCodepoints:
          List<int>.unmodifiable(logical.activeCodepoints),
      renderText: adapted.text,
      renderAdapterId: adapted.adapterId,
      legacyAscii: adapted.legacyAscii,
      fontSize: size,
      outerPadding: outerPadding < 0 ? 0 : outerPadding,
      openTypeFeatures: productionOpenTypeFeaturesForSize(size),
      abbreviated: logical.abbreviated,
      preserveNumericCartoucheBreaks: preserveNumericCartoucheBreaks,
    );
  }

  ProductionRenderResult render(
    Object? input, {
    ProductionOutputFormat format = ProductionOutputFormat.png,
    String? font,
    int? fontSize,
    bool abbreviate = true,
    bool preserveNumericCartoucheBreaks = false,
    int outerPadding = defaultProductionPadding,
    ProductionRgba foreground = ProductionRgba.black,
    ProductionRgba background = ProductionRgba.transparent,
    ParseOptions? parserOptions,
  }) {
    final plan = buildRenderPlan(
      input,
      font: font,
      fontSize: fontSize,
      abbreviate: abbreviate,
      preserveNumericCartoucheBreaks: preserveNumericCartoucheBreaks,
      outerPadding: outerPadding,
      parserOptions: parserOptions,
    );
    final native = renderProductionTextNative(
      text: plan.renderText,
      family: plan.font.nativeCompanionFamily,
      fontPath: plan.font.companionPath,
      fontSize: plan.fontSize,
      features: plan.openTypeFeatures,
      padding: plan.outerPadding,
      format: format,
      foreground: foreground,
      background: background,
    );
    return ProductionRenderResult(
      bytes: native.bytes,
      width: native.width,
      height: native.height,
      format: native.format,
      plan: plan,
    );
  }

  Uint8List renderToPng(
    Object? input, {
    String? font,
    int? fontSize,
    bool abbreviate = true,
    bool preserveNumericCartoucheBreaks = false,
    int outerPadding = defaultProductionPadding,
    ProductionRgba foreground = ProductionRgba.black,
    ProductionRgba background = ProductionRgba.transparent,
    ParseOptions? parserOptions,
  }) =>
      render(
        input,
        format: ProductionOutputFormat.png,
        font: font,
        fontSize: fontSize,
        abbreviate: abbreviate,
        preserveNumericCartoucheBreaks: preserveNumericCartoucheBreaks,
        outerPadding: outerPadding,
        foreground: foreground,
        background: background,
        parserOptions: parserOptions,
      ).bytes;

  Uint8List renderToSvg(
    Object? input, {
    String? font,
    int? fontSize,
    bool abbreviate = true,
    bool preserveNumericCartoucheBreaks = false,
    int outerPadding = defaultProductionPadding,
    ProductionRgba foreground = ProductionRgba.black,
    ProductionRgba background = ProductionRgba.transparent,
    ParseOptions? parserOptions,
  }) =>
      render(
        input,
        format: ProductionOutputFormat.svg,
        font: font,
        fontSize: fontSize,
        abbreviate: abbreviate,
        preserveNumericCartoucheBreaks: preserveNumericCartoucheBreaks,
        outerPadding: outerPadding,
        foreground: foreground,
        background: background,
        parserOptions: parserOptions,
      ).bytes;

  Uint8List renderToPdf(
    Object? input, {
    String? font,
    int? fontSize,
    bool abbreviate = true,
    bool preserveNumericCartoucheBreaks = false,
    int outerPadding = defaultProductionPadding,
    ProductionRgba foreground = ProductionRgba.black,
    ProductionRgba background = ProductionRgba.transparent,
    ParseOptions? parserOptions,
  }) =>
      render(
        input,
        format: ProductionOutputFormat.pdf,
        font: font,
        fontSize: fontSize,
        abbreviate: abbreviate,
        preserveNumericCartoucheBreaks: preserveNumericCartoucheBreaks,
        outerPadding: outerPadding,
        foreground: foreground,
        background: background,
        parserOptions: parserOptions,
      ).bytes;

  // Full renderer profile API. These methods are additive; the frozen numeric
  // facade above remains unchanged and continues to use its original renderer.
  DocumentAst parseInput(
    String input, {
    FullRenderOptions options = const FullRenderOptions(),
  }) =>
      _fullRenderer.parseInput(input, options);

  /// Converts a full-document AST back into valid nanpa-linja-n source text.
  /// Numeric structures can be re-serialized through [FullRenderOptions.numericOutput].
  String astToText(
    DocumentAst ast, {
    FullRenderOptions options = const FullRenderOptions(),
  }) =>
      full_document.astToText(ast, options);

  FullRenderPlan buildFullRenderPlan(
    String input, {
    FullRenderOptions options = const FullRenderOptions(),
  }) =>
      _fullRenderer.buildRenderPlan(input, options);

  FullRenderResult renderFull(
    String input, {
    ProductionOutputFormat format = ProductionOutputFormat.png,
    FullRenderOptions options = const FullRenderOptions(),
  }) =>
      _fullRenderer.render(input, format: format, options: options);

  FullCanvasResult renderToCanvas(
    String input, {
    FullRenderOptions options = const FullRenderOptions(),
  }) =>
      _fullRenderer.renderToCanvas(input, options);

  Uint8List renderFullToPng(
    String input, {
    FullRenderOptions options = const FullRenderOptions(),
  }) =>
      _fullRenderer.renderToPng(input, options);

  Uint8List renderFullToSvg(
    String input, {
    FullRenderOptions options = const FullRenderOptions(),
  }) =>
      _fullRenderer.renderToSvg(input, options);

  Uint8List renderFullToPdf(
    String input, {
    FullRenderOptions options = const FullRenderOptions(),
  }) =>
      _fullRenderer.renderToPdf(input, options);

  FullCanvasResult renderRunToNewCanvas(
    FullRenderRun run, {
    FullRenderOptions options = const FullRenderOptions(),
  }) =>
      _fullRenderer.renderRunToNewCanvas(run, options);

  FullCanvasResult renderTextToNewCanvas(
    String text, {
    FullRenderOptions options = const FullRenderOptions(),
  }) =>
      _fullRenderer.renderTextToNewCanvas(text, options);

  FullCanvasResult renderTextToCanvas(
    String text, {
    FullRenderOptions options = const FullRenderOptions(),
  }) =>
      _fullRenderer.renderTextToCanvas(text, options);

  FullCanvasResult renderUcsurToNewCanvas(
    List<List<int>> lines, {
    FullRenderOptions options = const FullRenderOptions(),
  }) =>
      _fullRenderer.renderUcsurToNewCanvas(lines, options);

  FullCanvasResult renderUcsurToCanvas(
    List<List<int>> lines, {
    FullRenderOptions options = const FullRenderOptions(),
  }) =>
      _fullRenderer.renderUcsurToCanvas(lines, options);

  void registerRenderAdapter(String id, FullRenderAdapter adapter) =>
      _fullRenderer.registerRenderAdapter(id, adapter);

  FullRenderAdapter? getRenderAdapter(String id) =>
      _fullRenderer.getRenderAdapter(id);

  FullRenderAdapter? removeRenderAdapter(String id) =>
      _fullRenderer.removeRenderAdapter(id);

  VectorDocument toVectorDocument(
    String input, {
    FullRenderOptions options = const FullRenderOptions(),
  }) =>
      _fullRenderer.toVectorDocument(input, options);
}
