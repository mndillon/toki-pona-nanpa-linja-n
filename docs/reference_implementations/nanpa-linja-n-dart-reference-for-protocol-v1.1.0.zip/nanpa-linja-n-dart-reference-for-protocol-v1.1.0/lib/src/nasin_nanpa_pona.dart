List<String> _base100GroupWords(int group) {
  if (group < 0 || group > 99) return const <String>[];
  final out = <String>[];
  var value = group;
  while (value >= 20) {
    out.add('mute');
    value -= 20;
  }
  while (value >= 5) {
    out.add('luka');
    value -= 5;
  }
  while (value >= 2) {
    out.add('tu');
    value -= 2;
  }
  if (value == 1) out.add('wan');
  return out;
}

List<String>? _groupedDigitsWords(List<String> groups) {
  final out = <String>[];
  for (var i = 0; i < groups.length; i++) {
    final group = groups[i];
    if (group.isEmpty || group.length > 2 || !RegExp(r'^\d+$').hasMatch(group)) {
      return null;
    }
    final value = int.tryParse(group);
    if (value == null) return null;
    out.addAll(_base100GroupWords(value));
    if (i + 1 < groups.length) out.add('ale');
  }
  return out;
}

List<String> _splitBase100Right(String digits) {
  final out = <String>[];
  for (var end = digits.length; end > 0; end -= 2) {
    final start = end - 2 < 0 ? 0 : end - 2;
    out.insert(0, digits.substring(start, end));
  }
  return out;
}

List<String> _splitBase100Left(String digits) {
  var value = digits;
  if (value.length.isOdd) value += '0';
  return <String>[
    for (var i = 0; i < value.length; i += 2) value.substring(i, i + 2),
  ];
}

/// Returns ordinary nasin nanpa pona words for plain decimal values only.
///
/// This intentionally mirrors the canonical JavaScript conversion used by
/// numeric text output. Dates, times, fractions, percentages, scientific
/// notation, hexadecimal and binary return null and therefore fall back to the
/// requested nanpa-linja-n representation.
List<String>? tryPlainDecimalToNasinNanpaPonaWords(String value) {
  final raw = value.trim()
      .replaceAll('−', '-')
      .replaceAll('‒', '-')
      .replaceAll('–', '-')
      .replaceAll('—', '-');
  final m = RegExp(
    r'^(-)?(?:(0|[1-9][0-9]*|[1-9][0-9]{0,2}(?:,[0-9]{3})+)(?:\.([0-9]+))?|\.([0-9]+))$',
  ).firstMatch(raw);
  if (m == null) return null;
  final negative = (m.group(1) ?? '').isNotEmpty;
  final integerDigits = (m.group(2) ?? '0').replaceAll(',', '');
  var fractionDigits = m.group(3) ?? m.group(4) ?? '';
  fractionDigits = fractionDigits.replaceFirst(RegExp(r'0+$'), '');
  if (integerDigits == '0' && fractionDigits.isEmpty) {
    return const <String>['ala'];
  }

  final integerWords = integerDigits == '0'
      ? <String>['ala']
      : _groupedDigitsWords(_splitBase100Right(integerDigits));
  if (integerWords == null) return null;
  final out = <String>[];
  if (negative) out.add('weka');
  out.addAll(integerWords);
  if (fractionDigits.isNotEmpty) {
    final fractional = _groupedDigitsWords(_splitBase100Left(fractionDigits));
    if (fractional == null) return null;
    out
      ..add('ala')
      ..addAll(fractional);
  }
  return out;
}
