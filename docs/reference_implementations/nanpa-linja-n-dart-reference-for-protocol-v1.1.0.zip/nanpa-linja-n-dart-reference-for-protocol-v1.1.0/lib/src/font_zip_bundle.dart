import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

const String productionFontManifestEntry =
    'fonts/preloaded-font-pairs.manifest.json';

class _ZipEntry {
  final String name;
  final int method;
  final int compressedSize;
  final int uncompressedSize;
  final int localHeaderOffset;

  const _ZipEntry({
    required this.name,
    required this.method,
    required this.compressedSize,
    required this.uncompressedSize,
    required this.localHeaderOffset,
  });
}

/// Minimal ZIP reader for the bundled production font archive.
///
/// It deliberately supports only the two methods used by the canonical bundle:
/// stored (0) and deflate (8).  The implementation uses only Dart SDK libraries;
/// no package, CDN, or system unzip command is required.
class ProductionFontZipBundle {
  final File file;
  final Uint8List _bytes;
  final Map<String, _ZipEntry> _entries;

  ProductionFontZipBundle._(this.file, this._bytes, this._entries);

  factory ProductionFontZipBundle.open(File source) {
    final file = source.absolute;
    if (!file.existsSync()) {
      throw FileSystemException(
        'nanpa-linja-n production font bundle was not found',
        file.path,
      );
    }
    final bytes = file.readAsBytesSync();
    return ProductionFontZipBundle._(
      file,
      bytes,
      _parseCentralDirectory(bytes),
    );
  }

  bool contains(String name) => _entries.containsKey(_normalize(name));

  Uint8List read(String name) {
    final normalized = _normalize(name);
    final entry = _entries[normalized];
    if (entry == null) {
      throw FileSystemException(
        'Production font ZIP entry was not found',
        '${file.path}!/$normalized',
      );
    }
    final data = ByteData.sublistView(_bytes);
    final offset = entry.localHeaderOffset;
    if (_u32(data, offset) != 0x04034b50) {
      throw FormatException('Invalid ZIP local header for $normalized');
    }
    final nameLength = _u16(data, offset + 26);
    final extraLength = _u16(data, offset + 28);
    final start = offset + 30 + nameLength + extraLength;
    final end = start + entry.compressedSize;
    if (start < 0 || end > _bytes.length) {
      throw FormatException('Truncated ZIP entry: $normalized');
    }
    final compressed = Uint8List.sublistView(_bytes, start, end);
    late final List<int> decoded;
    switch (entry.method) {
      case 0:
        decoded = compressed;
        break;
      case 8:
        decoded = ZLibDecoder(raw: true).convert(compressed);
        break;
      default:
        throw UnsupportedError(
          'Unsupported ZIP compression method ${entry.method} for $normalized',
        );
    }
    if (decoded.length != entry.uncompressedSize) {
      throw FormatException(
        'ZIP entry size mismatch for $normalized: '
        '${decoded.length} != ${entry.uncompressedSize}',
      );
    }
    return Uint8List.fromList(decoded);
  }

  String readText(String name) => utf8.decode(read(name));

  /// Materialize selected entries for native Pango/Fontconfig, which requires
  /// filesystem paths.  The canonical source remains [file].
  Directory materialize(Iterable<String> names) {
    final stat = file.statSync();
    final identity = _fnv1a64(
      '${file.path}\n${stat.size}\n${stat.modified.millisecondsSinceEpoch}',
    );
    final root = Directory(
      '${Directory.systemTemp.path}${Platform.pathSeparator}'
      'nanpa_linja_n_dart_fonts_$identity',
    );
    root.createSync(recursive: true);

    for (final rawName in names) {
      final name = _normalize(rawName);
      if (!name.startsWith('fonts/') || name.endsWith('/')) {
        throw FormatException('Invalid production font ZIP entry path: $name');
      }
      final relative = name.substring('fonts/'.length);
      if (relative.isEmpty || relative.contains('../') || relative.contains('..\\')) {
        throw FormatException('Unsafe production font ZIP entry path: $name');
      }
      final target = File(
        '${root.path}${Platform.pathSeparator}'
        '${relative.replaceAll('/', Platform.pathSeparator)}',
      );
      const literalAlias =
          'fonts/nanpa-linja-n-nasin-nanpa-liberation-sans-literal.ttf';
      const literalDonor = 'fonts/LiberationSans-Regular.ttf';
      final sourceName = name == literalAlias && !_entries.containsKey(name)
          ? literalDonor
          : name;
      final entry = _entries[sourceName];
      if (entry == null) {
        throw FileSystemException(
          'Production font ZIP entry was not found',
          '${file.path}!/$name',
        );
      }
      if (!target.existsSync() || target.lengthSync() != entry.uncompressedSize) {
        target.parent.createSync(recursive: true);
        // v1.1 keeps fonts.zip byte-for-byte identical to the supplied archive.
        // The production manifest's literal-cartouche compatibility filename is
        // materialized as a byte-identical copy of bundled Liberation Sans.
        target.writeAsBytesSync(read(sourceName), flush: true);
      }
    }
    return root;
  }

  static String _normalize(String value) =>
      value.replaceAll('\\', '/').replaceFirst(RegExp(r'^/+'), '');

  static Map<String, _ZipEntry> _parseCentralDirectory(Uint8List bytes) {
    final data = ByteData.sublistView(bytes);
    final min = bytes.length > 0xffff + 22 ? bytes.length - (0xffff + 22) : 0;
    var eocd = -1;
    for (var i = bytes.length - 22; i >= min; i--) {
      if (_u32(data, i) == 0x06054b50) {
        eocd = i;
        break;
      }
    }
    if (eocd < 0) throw const FormatException('ZIP end-of-central-directory not found');

    final entryCount = _u16(data, eocd + 10);
    final centralSize = _u32(data, eocd + 12);
    final centralOffset = _u32(data, eocd + 16);
    if (centralOffset + centralSize > bytes.length) {
      throw const FormatException('Truncated ZIP central directory');
    }

    final out = <String, _ZipEntry>{};
    var cursor = centralOffset;
    for (var i = 0; i < entryCount; i++) {
      if (cursor + 46 > bytes.length || _u32(data, cursor) != 0x02014b50) {
        throw const FormatException('Invalid ZIP central-directory entry');
      }
      final flags = _u16(data, cursor + 8);
      if ((flags & 0x1) != 0) {
        throw UnsupportedError('Encrypted font ZIP entries are not supported');
      }
      final method = _u16(data, cursor + 10);
      final compressedSize = _u32(data, cursor + 20);
      final uncompressedSize = _u32(data, cursor + 24);
      final nameLength = _u16(data, cursor + 28);
      final extraLength = _u16(data, cursor + 30);
      final commentLength = _u16(data, cursor + 32);
      final localOffset = _u32(data, cursor + 42);
      final nameStart = cursor + 46;
      final nameEnd = nameStart + nameLength;
      if (nameEnd > bytes.length) {
        throw const FormatException('Truncated ZIP entry name');
      }
      final name = utf8.decode(bytes.sublist(nameStart, nameEnd));
      out[_normalize(name)] = _ZipEntry(
        name: _normalize(name),
        method: method,
        compressedSize: compressedSize,
        uncompressedSize: uncompressedSize,
        localHeaderOffset: localOffset,
      );
      cursor = nameEnd + extraLength + commentLength;
    }
    return out;
  }

  static int _u16(ByteData data, int offset) =>
      data.getUint16(offset, Endian.little);
  static int _u32(ByteData data, int offset) =>
      data.getUint32(offset, Endian.little);

  static String _fnv1a64(String value) {
    var hash = 0xcbf29ce484222325;
    for (final byte in utf8.encode(value)) {
      hash ^= byte;
      hash = (hash * 0x100000001b3) & 0xffffffffffffffff;
    }
    return hash.toRadixString(16).padLeft(16, '0');
  }
}
