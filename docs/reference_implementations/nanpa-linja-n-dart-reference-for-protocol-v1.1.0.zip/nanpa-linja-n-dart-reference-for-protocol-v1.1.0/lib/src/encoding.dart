import 'constants.dart';
import 'options.dart';

String _repeat(String s,int n)=>List.filled(n,s).join();

String _digitSyllable(int d, ParseOptions o) =>
    (o.relaxedNanpaLinjanRendering ? relaxedDigits : strictDigits)[d];

String? _encodeDigits(String digits, ParseOptions o) {
  if (digits.isEmpty || !RegExp(r'^\d+$').hasMatch(digits)) return null;
  final b=StringBuffer();
  for (final r in digits.runes) {
    b.write(_digitSyllable(r-48,o));
  }
  return b.toString();
}

String? _encodeFractionDigits(String digits, ParseOptions o) {
  if (digits.isEmpty || !RegExp(r'^\d+$').hasMatch(digits)) return null;
  final groups=<String>[];
  for (var i=0;i<digits.length;i+=3) {
    final e=(i+3<digits.length)?i+3:digits.length;
    final x=_encodeDigits(digits.substring(i,e),o);
    if (x==null) return null;
    groups.add(x);
  }
  return groups.join('NENE');
}

String? _encodeIntegerGroups(String value, ParseOptions o) {
  final groups=value.split(',');
  if (groups.isEmpty || groups.any((g)=>g.isEmpty || !RegExp(r'^\d+$').hasMatch(g))) return null;
  var trailing=0;
  for (var i=groups.length-1;i>=0 && groups[i]=='000';i--) trailing++;
  if (trailing>0 && trailing<groups.length) {
    final sig=groups.length-trailing;
    final b=StringBuffer();
    for (var i=0;i<sig;i++) {
      if (i>0) b.write('NEKE');
      final x=_encodeDigits(groups[i],o); if(x==null)return null; b.write(x);
    }
    b.write('NE');
    for(var i=0;i<trailing;i++) b.write('KE');
    return b.toString();
  }
  final out=<String>[];
  for(final g in groups){final x=_encodeDigits(g,o);if(x==null)return null;out.add(x);}
  return out.join('NEKE');
}

String? _encodeUnsignedBasic(String value, ParseOptions o) {
  final dot=value.indexOf('.');
  if(dot>=0){
    if(value.indexOf('.',dot+1)>=0)return null;
    final left=value.substring(0,dot), right=value.substring(dot+1);
    if(right.isEmpty)return null;
    final a=_encodeIntegerGroups(left.isEmpty?'0':left,o), b=_encodeFractionDigits(right,o);
    if(a==null||b==null)return null;
    return '${a}NONE$b';
  }
  return _encodeIntegerGroups(value,o);
}

int? magnitudePower(String c){switch(c.toUpperCase()){case'K':return 1;case'M':return 2;case'B':return 3;case'T':return 4;}return null;}

/// Canonical nanpa caps encoding. Returns null for malformed values.
String? encodeDecimalCaps(Object? value,[ParseOptions options=const ParseOptions()]) {
  if(value==null)return null;
  final raw='$value'.trim(); if(raw.isEmpty)return null;
  // Current JavaScript baseline: outer whitespace is ignored, but any
  // whitespace inside a digit-based numeric expression terminates the token.
  if(RegExp(r'\s').hasMatch(raw))return null;
  var body=raw; var prefix='';
  if(body.startsWith('+')){prefix='NS';body=body.substring(1);if(body.startsWith('+')||body.isEmpty)return null;}
  else if(body.startsWith('-')){prefix='NO';while(body.startsWith('-'))body=body.substring(1);if(body.isEmpty)return null;}

  if(body.isNotEmpty){
    final power=magnitudePower(body.substring(body.length-1));
    if(power!=null){
      final base=body.substring(0,body.length-1);if(base.isEmpty)return null;
      final e=_encodeUnsignedBasic(base,options);if(e==null)return null;
      return 'NE$prefix$e' 'NE${_repeat('KE',power)}N';
    }
  }
  if(body.endsWith('%')){
    final e=_encodeUnsignedBasic(body.substring(0,body.length-1),options);if(e==null)return null;
    return 'NE$prefix${e}OKN';
  }
  final slash=body.indexOf('/');
  if(slash>=0){
    if(body.indexOf('/',slash+1)>=0)return null;
    final a=_encodeUnsignedBasic(body.substring(0,slash),options), b=_encodeUnsignedBasic(body.substring(slash+1),options);
    if(a==null||b==null)return null;
    return 'NE$prefix${a}NONO${b}N';
  }
  final sci=body.indexOf(RegExp(r'[eE]'));
  if(sci>=0){
    final mantissa=body.substring(0,sci);var exponent=body.substring(sci+1);if(exponent.isEmpty)return null;
    var ep='';if(exponent.startsWith('-')){ep='NO';exponent=exponent.substring(1);}else if(exponent.startsWith('+')){exponent=exponent.substring(1);}if(exponent.isEmpty)return null;
    final a=_encodeUnsignedBasic(mantissa,options),b=_encodeDigits(exponent,options);if(a==null||b==null)return null;
    return 'NE$prefix${a}NEKO$ep${b}N';
  }
  final e=_encodeUnsignedBasic(body,options);if(e==null)return null;
  return 'NE$prefix${e}N';
}
