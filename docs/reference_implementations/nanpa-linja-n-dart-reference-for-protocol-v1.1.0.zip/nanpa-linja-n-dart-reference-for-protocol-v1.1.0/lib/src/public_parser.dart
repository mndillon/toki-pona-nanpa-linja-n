import 'model.dart';
import 'options.dart';
import 'parser.dart' as core_parser;

/// Protocol-v1.1 public parser defaults layered over the frozen Core-v1 parser.
///
/// Hexadecimal and binary recognition are opt-in. Relaxed parsing/rendering,
/// Nanpa-format syntax, and abbreviated numeric-cartouche preference are on by
/// default. The returned [ParseResult] is the canonical parser result; decimal,
/// date, and time results do not gain Dart-only convenience fields.
const ParseOptions defaultPublicParseOptions = ParseOptions(
  enableBinaryParsing: false,
  enableHexParsing: false,
  nanpaColonParsing: true,
  nanpaColonRendering: true,
  relaxedNanpaLinjanParsing: true,
  relaxedNanpaLinjanRendering: true,
  abbreviateNumericCartouches: true,
  preserveNumericCartoucheBreaksInAbbreviation: false,
  nasinNanpaPona: false,
);

ParseResult? parseNumber(
  Object? input, [
  ParseOptions options = defaultPublicParseOptions,
]) =>
    core_parser.parseNumber(input, options);
