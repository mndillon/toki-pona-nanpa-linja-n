#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
python3 tools/check_current_conformance.py
python3 tools/check_core_source_integrity.py
python3 tools/check_production_assets.py
python3 protocol/verify_release.py
python3 tools/static_source_audit.py
