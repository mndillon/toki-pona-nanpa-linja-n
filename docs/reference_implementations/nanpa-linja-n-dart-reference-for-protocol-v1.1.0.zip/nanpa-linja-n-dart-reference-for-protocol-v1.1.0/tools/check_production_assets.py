#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, struct, sys, zipfile

EXPECTED_BUNDLE_SHA256 = '08d0409e0b180a6b90a0617fe557fd3e59a08dd26781d907ed5d772a9fefcae1'
EXPECTED_MANIFEST_SHA256 = '50b8a4b6cab0c27f2061f94e404a2af992cbf95c8097c58caa5e6b2dc4625f09'
LITERAL_ALIAS = 'nanpa-linja-n-nasin-nanpa-liberation-sans-literal.ttf'
LITERAL_SOURCE = 'LiberationSans-Regular.ttf'
EXPECTED_NATIVE_FAMILIES = {
    'nasinNanpa': 'nanpa-linja-n-nasin-nanpa-liberation-sans-vulgar-fit-tally-colon-middledotfix-compatible',
    'sitelenSeliKiwen': 'sitelen seli kiwen juniko-latin-ligatures-compatible',
    'fairfaxHd': 'Fairfax HD-compatible',
    'fairfaxPonaHd': 'Fairfax Pona HD-compatible',
    'linjaPona': 'linja pona 4.9-compatible',
    'linjaSike': 'linja sike 5-cartouche-fix-compatible',
    'nasinSitelenPuMono': 'nasin-sitelen-pu mono-compatible',
    'linjaLipamanka': 'linja lipamanka-cartouche-fix-compatible',
}
EXPECTED_ADAPTERS = {
    'identity', 'linja-pona-legacy-v1', 'linja-sike-legacy-v1',
    'nasin-sitelen-pu-mono-v1', 'linja-lipamanka-v1',
}

def _embedded_family(data: bytes) -> str:
    if len(data) < 12: raise ValueError('truncated SFNT')
    num_tables = struct.unpack_from('>H', data, 4)[0]
    name_off = None
    for i in range(num_tables):
        off=12+i*16
        tag,_,table_off,_=struct.unpack_from('>4sIII',data,off)
        if tag == b'name': name_off=table_off; break
    if name_off is None: raise ValueError('missing name table')
    _,count,string_offset=struct.unpack_from('>HHH',data,name_off)
    records=[]
    for i in range(count):
        roff=name_off+6+i*12
        platform,_,language,name_id,length,offset=struct.unpack_from('>HHHHHH',data,roff)
        if name_id not in (1,16): continue
        raw=data[name_off+string_offset+offset:name_off+string_offset+offset+length]
        try:
            text=raw.decode('utf-16-be') if platform in (0,3) else raw.decode('mac_roman')
        except UnicodeDecodeError: continue
        if text:
            priority=(0 if name_id==16 else 10)+(0 if platform in (0,3) else 2)+(0 if language in (0,0x0409) else 1)
            records.append((priority,text))
    if not records: raise ValueError('no family name record')
    return sorted(records)[0][1]

root=Path(__file__).resolve().parent.parent
bundle=root/'resources/fonts.zip'
repo_manifest=root/'rendering/production-font-pairs.manifest.json'
errors=[]
if not bundle.is_file(): errors.append('missing resources/fonts.zip')
if not repo_manifest.is_file(): errors.append('missing rendering/production-font-pairs.manifest.json')
if bundle.is_file() and hashlib.sha256(bundle.read_bytes()).hexdigest()!=EXPECTED_BUNDLE_SHA256:
    errors.append('fonts.zip SHA-256 mismatch')
if repo_manifest.is_file() and hashlib.sha256(repo_manifest.read_bytes()).hexdigest()!=EXPECTED_MANIFEST_SHA256:
    errors.append('production manifest SHA-256 mismatch')

if bundle.is_file():
  with zipfile.ZipFile(bundle) as zf:
    names=set(zf.namelist())
    entry='fonts/preloaded-font-pairs.manifest.json'
    if entry not in names:
      errors.append('fonts.zip missing preloaded-font-pairs.manifest.json'); manifest={'pairs':[]}
    else:
      raw=zf.read(entry); manifest=json.loads(raw)
      if hashlib.sha256(raw).hexdigest()!=EXPECTED_MANIFEST_SHA256:
        errors.append('fonts.zip embedded manifest SHA-256 mismatch')
      if repo_manifest.is_file() and raw!=repo_manifest.read_bytes():
        errors.append('repo production manifest differs byte-for-byte from fonts.zip manifest')
    pairs=manifest.get('pairs',[])
    if len(pairs)!=8: errors.append(f'production pair count {len(pairs)} != 8')
    adapters=set()
    manual=0; ucsur=0
    for pair in pairs:
      key=pair.get('fontKey'); adapters.add(pair.get('renderAdapterId') or 'identity')
      if pair.get('parserMode')!='sitelen-pona-ascii-extended': errors.append(f'{key}: parserMode mismatch')
      settings=pair.get('settings') or {}
      if settings.get('cartoucheVulgarFractions') is not True: errors.append(f'{key}: cartoucheVulgarFractions not true')
      if settings.get('emulateLegacyCartoucheScaling') is not False: errors.append(f'{key}: emulateLegacyCartoucheScaling not false')
      mode=settings.get('cartoucheTallyMode')
      manual += mode=='manual'; ucsur += mode=='ucsur'
      for field in ('baseFilename','companionFilename'):
        fn=pair.get(field); ze='fonts/'+str(fn)
        if ze not in names: errors.append(f'{key}: missing {field} {fn}')
      literal=pair.get('literalCartoucheFilename')
      if literal:
        ze='fonts/'+literal
        if ze not in names:
          if literal!=LITERAL_ALIAS or 'fonts/'+LITERAL_SOURCE not in names:
            errors.append(f'{key}: missing literal cartouche file {literal}')
      try:
        fam=_embedded_family(zf.read('fonts/'+pair['companionFilename']))
        if fam!=EXPECTED_NATIVE_FAMILIES.get(key):
          errors.append(f'{key}: embedded family {fam!r} != {EXPECTED_NATIVE_FAMILIES.get(key)!r}')
      except Exception as exc: errors.append(f'{key}: embedded family check failed: {exc}')
    if adapters!=EXPECTED_ADAPTERS: errors.append(f'adapter inventory {sorted(adapters)} != {sorted(EXPECTED_ADAPTERS)}')
    if (manual,ucsur)!=(4,4): errors.append(f'tally-mode split manual/ucsur = {manual}/{ucsur}, expected 4/4')

plans=json.loads((root/'rendering/facade-render-plan-goldens-v1.1.0.json').read_text())
cases=plans.get('cases',[])
plan_count=sum(len((c.get('perFont') or {})) for c in cases)
if len(cases)!=16 or plan_count!=128: errors.append(f'render plan oracle = {len(cases)} logical/{plan_count} font plans, expected 16/128')
for c in cases:
  if any(x in {'ss12','ss13','ss14'} for x in c.get('openTypeFeatures',[])):
    errors.append(f"{c.get('id')}: legacy ss12/ss13/ss14 still active")

# Pin the hard-coded families used by the FFI paths to the actual supplied fonts.
for source in (root/'lib/src/production_font_registry.dart',root/'lib/src/full_renderer.dart'):
  text=source.read_text()
  for key,family in EXPECTED_NATIVE_FAMILIES.items():
    if family not in text: errors.append(f'{source.name}: missing native family pin for {key}: {family!r}')

if errors:
  print('Dart production asset validation FAIL')
  for e in errors: print(' -',e)
  sys.exit(1)
print('Dart production assets: PASS')
print('  fonts.zip exact SHA-256 PASS')
print('  manifest exact SHA-256 PASS; 8/8 pairs; adapters 5/5; tally modes 4 manual + 4 UCSUR')
print('  embedded native family names 8/8 PASS')
print('  literal compatibility alias resolved from byte-identical LiberationSans-Regular.ttf at runtime')
print('  render-plan oracle: 16 logical cases x 8 fonts = 128')
