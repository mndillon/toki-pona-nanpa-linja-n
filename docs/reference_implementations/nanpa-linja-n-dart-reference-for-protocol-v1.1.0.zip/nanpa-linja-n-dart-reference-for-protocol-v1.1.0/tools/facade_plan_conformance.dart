import 'dart:convert';
import 'dart:io';

import 'package:nanpa_linja_n/nanpa_linja_n.dart';

bool _same(Object? a, Object? b) => jsonEncode(a) == jsonEncode(b);

ParseOptions _parserOptionsForCase(Map<String, dynamic> c) {
  var options = defaultPublicParseOptions;
  final input = '${c['input'] ?? ''}';
  if (input.startsWith('#') && !input.startsWith('#~')) {
    options = options.copyWith(enableHexParsing: true);
  }
  if (input.toLowerCase().startsWith('0b')) {
    options = options.copyWith(enableBinaryParsing: true);
  }
  return options;
}

void main() {
  final root = File.fromUri(Platform.script).parent.parent;
  final fixture = File(
    '${root.path}${Platform.pathSeparator}rendering${Platform.pathSeparator}'
    'facade-render-plan-goldens-v1.1.0.json',
  );
  final decoded = jsonDecode(fixture.readAsStringSync()) as Map<String, dynamic>;
  final cases = (decoded['cases'] as List).cast<Map>();
  final nanpa = NanpaLinjaN.create();
  final failures = <String>[];
  var passed = 0;

  for (final raw in cases) {
    final c = Map<String, dynamic>.from(raw);
    final perFont = Map<String, dynamic>.from(c['perFont'] as Map);
    for (final fontEntry in perFont.entries) {
      final fontKey = fontEntry.key;
      final expected = Map<String, dynamic>.from(fontEntry.value as Map);
      final plan = nanpa.buildRenderPlan(
        c['input'],
        font: fontKey,
        fontSize: (c['fontPx'] as num).round(),
        abbreviate: c['abbreviate'] == true,
        preserveNumericCartoucheBreaks:
            c['preserveNumericCartoucheBreaks'] == true,
        parserOptions: _parserOptionsForCase(c),
      );
      final id = '${fontKey}__${c['id']}';
      final ok = plan.renderAdapterId == expected['renderAdapterId'] &&
          plan.legacyAscii == (expected['legacyAdapter'] == true) &&
          plan.renderText == expected['renderText'] &&
          _same(plan.canonicalCodepoints, c['canonicalCodepoints']) &&
          _same(plan.renderCodepoints, expected['renderCodepoints']) &&
          _same(plan.openTypeFeatures, c['openTypeFeatures']);
      if (ok) {
        passed++;
      } else {
        failures.add(
          '$id mismatch: adapter=${plan.renderAdapterId} '
          'legacy=${plan.legacyAscii} features=${plan.openTypeFeatures} '
          'canonical=${plan.canonicalCodepoints} render=${plan.renderCodepoints} '
          'renderText=${jsonEncode(plan.renderText)}',
        );
      }
    }
  }

  if (failures.isNotEmpty) {
    stderr.writeln('Dart production render-plan conformance failures:');
    for (final failure in failures) {
      stderr.writeln('  $failure');
    }
    exitCode = 1;
    return;
  }
  print('Dart production render-plan conformance: $passed/128 PASS');
}
