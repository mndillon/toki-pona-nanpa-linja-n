import 'dart:convert';
import 'dart:io';

import 'package:nanpa_linja_n/nanpa_linja_n.dart';

const expectedChecks = 1030;

Map<String, dynamic> _object(dynamic value) =>
    value is Map<String, dynamic> ? value : <String, dynamic>{};

Object? _jsonValue(Object? value) {
  if (value is ParseResult) return value.toJson();
  if (value is CapsCodepointsResult) return value.toJson();
  if (value is IdentifierResult) return value.toJson();
  if (value is RenderResult) return value.toJson();
  if (value is Set<int>) return value.toList()..sort();
  return value;
}

Object? _parseValue(Object? input, Map<String, dynamic> options) {
  if (input is! String) return null;
  return parseNumber(input, ParseOptions.fromJson(options))?.toJson();
}

Object? _dispatch(String api, Object? input, Map<String, dynamic> options) {
  final parseOptions = ParseOptions.fromJson(options);
  switch (api) {
    case 'parseNumber':
      return _parseValue(input, options);
    case 'encodeDecimal':
      return encodeDecimal(input, parseOptions);
    case 'decimalToUcsurCodepoints':
      return decimalToUcsurCodepoints(input, parseOptions);
    case 'properNameToUcsurCodepoints':
      return properNameToUcsurCodepoints(input, parseOptions);
    case 'splitCapsToProperName':
      return splitCapsToProperName(
        '$input',
        SplitCapsOptions.fromJson(options),
      );
    case 'capsToUniqueCode':
      return capsToUniqueCode('$input', parseOptions);
    case 'decodeCaps':
      return decodeCaps('$input', parseOptions);
    case 'ucsurCodepointsToTpWords':
      return ucsurCodepointsToTpWords((input as List).cast<int>());
    case 'codepointsToWords':
      return codepointsToWords((input as List).cast<int>());
    case 'tpWordsToText':
      return tpWordsToText((input as List).cast<String>());
    case 'parseTpWordsToCodepoints':
      return parseTpWordsToCodepoints(input);
    case 'tpWordsToUcsurCodepoints':
      return tpWordsToUcsurCodepoints((input as List).cast<String>());
    case 'codepointsToHex':
      return codepointsToHex((input as List).cast<int>());
    case 'codepointsToHexWithCartouche':
      return codepointsToHexWithCartouche((input as List).cast<int>());
    case 'parseHexCodepoints':
      return parseHexCodepoints(input);
    case 'withCartoucheMarkers':
      return withCartoucheMarkers((input as List).cast<int>());
    case 'stripCartoucheMarkers':
      return stripCartoucheMarkers((input as List).cast<int>());
    case 'isValidCaps':
      return isValidCaps(input, parseOptions);
    case 'isValidProperName':
      return isValidProperName(input, parseOptions);
    case 'isValidTimeOrDate':
      return isValidTimeOrDate(input, parseOptions);
    case 'isValidTime':
      return isValidTime(input, parseOptions);
    case 'isValidDate':
      return isValidDate(input, parseOptions);
    case 'tokenizeCaps':
      return tokenizeCaps('$input', parseOptions);
    case 'capsTokensToTpWords':
      return capsTokensToTpWords((input as List).cast<String>(), parseOptions);
    case 'capsToWords':
      return capsToWords('$input', parseOptions);
    case 'capsToCodepoints':
      return capsToCodepoints('$input', parseOptions)?.toJson();
    case 'parseIdentifier':
      return parseIdentifier(input, parseOptions)?.toJson();
    case 'normalizeVulgarFraction':
      return normalizeVulgarFraction('$input');
    case 'normalizeTpWord':
      return normalizeTpWord(input);
    case 'getSmallCodepointsSet':
      return getSmallCodepointsSet().toList()..sort();
    case 'getQuarterCodepointsSet':
      return getQuarterCodepointsSet().toList()..sort();
    case 'getOneThirdCodepointsSet':
      return getOneThirdCodepointsSet().toList()..sort();
    case 'getTwoThirdsCodepointsSet':
      return getTwoThirdsCodepointsSet().toList()..sort();
    case 'getHalfCodepointsSet':
      return getHalfCodepointsSet().toList()..sort();
    case 'isAllowedTpUcsurCodepoint':
      return isAllowedTpUcsurCodepoint(input);
    default:
      throw UnsupportedError('Unsupported API: $api');
  }
}

bool _deepEquals(Object? a, Object? b) => jsonEncode(a) == jsonEncode(b);

bool _containsSubsequence(Object? haystack, Object? needle) {
  if (haystack is! List || needle is! List) return false;
  if (needle.isEmpty) return true;
  if (needle.length > haystack.length) return false;
  for (var i = 0; i <= haystack.length - needle.length; i++) {
    var equal = true;
    for (var j = 0; j < needle.length; j++) {
      if (!_deepEquals(haystack[i + j], needle[j])) {
        equal = false;
        break;
      }
    }
    if (equal) return true;
  }
  return false;
}

String _resultType(Object? value) {
  if (value == null) return 'null';
  if (value is String) return 'string';
  if (value is bool) return 'boolean';
  if (value is num) return 'number';
  if (value is Map) return 'object';
  if (value is List) {
    if (value.every((item) => item is int)) return 'array<int>';
    if (value.every((item) => item is String)) return 'array<string>';
    return 'array';
  }
  return value.runtimeType.toString();
}

bool _nonEmpty(Object? value) {
  if (value is String) return value.isNotEmpty;
  if (value is List) return value.isNotEmpty;
  if (value is Map) return value.isNotEmpty;
  if (value is bool) return value;
  if (value is num) return true;
  return false;
}

Object? _field(Object? result, String key) {
  if (result is Map<String, dynamic>) return result[key];
  if (result is Map) return result[key];
  return null;
}

void _assertResult(
  String id,
  Object? result,
  Map<String, dynamic> spec,
  List<String> failures,
  List<int> checkCounter,
) {
  for (final entry in spec.entries) {
    final key = entry.key;
    if (const <String>{
      'result',
      'notes',
      'equivalentToInput',
      'equivalentValue',
      'numericDomain',
    }.contains(key)) {
      continue;
    }
    checkCounter[0]++;
    var expected = entry.value;
    Object? actual;

    switch (key) {
      case 'accepted':
        actual = result != null;
        break;
      case 'requiredFields':
        final object = result is Map ? result : const <Object?, Object?>{};
        actual = <String>[
          for (final field in (expected as List))
            if (!object.containsKey(field)) '$field',
        ];
        expected = <String>[];
        break;
      case 'absentFields':
        final object = result is Map ? result : const <Object?, Object?>{};
        actual = <String>[
          for (final field in (expected as List))
            if (object.containsKey(field)) '$field',
        ];
        expected = <String>[];
        break;
      case 'properNameStartsWith':
        final name = '${_field(result, 'properName') ?? ''}';
        if (!name.startsWith('$expected')) {
          failures.add('[$id] properNameStartsWith: actual=$name expected prefix=$expected');
        }
        continue;
      case 'tpWordsFirst':
        final words = _field(result, 'tpWords');
        actual = words is List && words.isNotEmpty ? words.first : null;
        break;
      case 'tpWordsLast':
        final words = _field(result, 'tpWords');
        actual = words is List && words.isNotEmpty ? words.last : null;
        break;
      case 'tpWordsContainsSubsequence':
        actual = _containsSubsequence(_field(result, 'tpWords'), expected);
        expected = true;
        break;
      case 'codepointsFirstInner':
        final cps = _field(result, 'innerCodepoints');
        actual = cps is List && cps.isNotEmpty ? cps.first : null;
        break;
      case 'codepointsLastInner':
        final cps = _field(result, 'innerCodepoints');
        actual = cps is List && cps.isNotEmpty ? cps.last : null;
        break;
      case 'cartoucheStart':
        final cps = _field(result, 'codepoints');
        actual = cps is List && cps.isNotEmpty ? cps.first : null;
        break;
      case 'cartoucheEnd':
        final cps = _field(result, 'codepoints');
        actual = cps is List && cps.isNotEmpty ? cps.last : null;
        break;
      case 'resultType':
        actual = _resultType(result);
        break;
      case 'nonEmpty':
        actual = _nonEmpty(result);
        break;
      case 'exact':
        actual = result;
        break;
      default:
        actual = _field(result, key);
        break;
    }

    if (!_deepEquals(actual, expected)) {
      failures.add(
        '[$id] $key: actual=${jsonEncode(actual)} expected=${jsonEncode(expected)}',
      );
    }
  }
}

Future<void> main() async {
  final root = File.fromUri(Platform.script).parent.parent;
  final corpusFile = File(
    '${root.path}/conformance/nanpa-linja-n-regression-v1.0.2.json',
  );
  final corpus = jsonDecode(await corpusFile.readAsString()) as Map<String, dynamic>;
  final failures = <String>[];
  final checks = <int>[0];

  var parserPass = 0;
  for (final raw in corpus['parserCases'] as List) {
    final test = raw as Map<String, dynamic>;
    final id = test['id'] as String;
    final api = (test['api'] ?? 'parseNumber') as String;
    if (api != 'parseNumber') {
      checks[0]++;
      failures.add('[$id] unsupported parser API $api');
      continue;
    }
    final options = _object(test['options']);
    final result = _parseValue(test['input'], options);
    final spec = test['assert'] as Map<String, dynamic>;
    final accept = spec['result'] == 'accept';
    checks[0]++;
    if ((result != null) != accept) {
      failures.add('[$id] accept/reject: actual=${result == null ? 'reject' : 'accept'} expected=${spec['result']}');
      continue;
    }
    if (result != null) {
      final before = failures.length;
      _assertResult(id, result, spec, failures, checks);
      if (failures.length == before) parserPass++;
    } else if (!accept) {
      parserPass++;
    }
  }

  var rendererPass = 0;
  for (final raw in corpus['rendererCases'] as List) {
    final test = raw as Map<String, dynamic>;
    final id = test['id'] as String;
    final options = _object(test['options']);
    checks[0]++;
    try {
      final result = _jsonValue(_dispatch(test['api'] as String, test['input'], options));
      final before = failures.length;
      _assertResult(id, result, test['assert'] as Map<String, dynamic>, failures, checks);
      if (failures.length == before) rendererPass++;
    } catch (error) {
      failures.add('[$id] API failed: $error');
    }
  }

  var apiPass = 0;
  for (final raw in corpus['apiCases'] as List) {
    final test = raw as Map<String, dynamic>;
    final id = test['id'] as String;
    final options = _object(test['options']);
    checks[0]++;
    try {
      final result = _jsonValue(_dispatch(test['api'] as String, test['input'], options));
      final before = failures.length;
      _assertResult(id, result, test['assert'] as Map<String, dynamic>, failures, checks);
      if (failures.length == before) apiPass++;
    } catch (error) {
      failures.add('[$id] API failed: $error');
    }
  }

  var equivalenceComparisons = 0;
  var equivalenceFailuresBefore = failures.length;
  for (final raw in corpus['equivalenceGroups'] as List) {
    final group = raw as Map<String, dynamic>;
    final id = group['id'] as String;
    final api = (group['api'] ?? 'parseNumber') as String;
    if (api != 'parseNumber') {
      checks[0]++;
      failures.add('[$id] unsupported equivalence API $api');
      continue;
    }
    final options = _object(group['options']);
    final members = group['members'] as List;
    final compare = group['compare'] as List;
    final base = _parseValue(members.first, options);
    for (final fieldRaw in compare) {
      final field = fieldRaw as String;
      final expected = _field(base, field);
      for (final input in members.skip(1)) {
        final actual = _field(_parseValue(input, options), field);
        checks[0]++;
        equivalenceComparisons++;
        if (!_deepEquals(actual, expected)) {
          failures.add('[$id] $field: base=${jsonEncode(members.first)} member=${jsonEncode(input)} actual=${jsonEncode(actual)} expected=${jsonEncode(expected)}');
        }
      }
    }
  }

  stdout.writeln('nanpa-linja-n Dart reference conformance');
  stdout.writeln('========================================');
  stdout.writeln('parser conformance: $parserPass/${(corpus['parserCases'] as List).length} PASS');
  stdout.writeln('renderer conformance: $rendererPass/${(corpus['rendererCases'] as List).length} PASS');
  stdout.writeln('API conformance: $apiPass/${(corpus['apiCases'] as List).length} PASS');
  stdout.writeln('equivalence comparisons: $equivalenceComparisons (${failures.length == equivalenceFailuresBefore ? 'PASS' : 'FAIL'})');
  stdout.writeln('frozen protocol checks: ${checks[0]}');
  stdout.writeln('failures: ${failures.length}');

  if (checks[0] != expectedChecks) {
    failures.add('Frozen check count changed: ${checks[0]} != $expectedChecks');
  }
  if (failures.isNotEmpty) {
    for (final failure in failures) {
      stderr.writeln(failure);
    }
    exitCode = 1;
  } else {
    stdout.writeln('ALL CONFIGURED DART REFERENCE TESTS PASS');
  }
}
