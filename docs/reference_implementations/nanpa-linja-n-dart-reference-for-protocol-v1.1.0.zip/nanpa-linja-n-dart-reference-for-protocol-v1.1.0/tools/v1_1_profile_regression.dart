import 'dart:convert';
import 'dart:io';

import 'package:nanpa_linja_n/nanpa_linja_n.dart';

Never _fail(String message) => throw StateError(message);

void _check(bool condition, String message) {
  if (!condition) _fail(message);
}

DecimalStartGlyph? _startGlyph(Object? value) {
  switch ('$value') {
    case 'nanpa':
      return DecimalStartGlyph.nanpa;
    case 'tenpo':
      return DecimalStartGlyph.tenpo;
    case 'suno':
      return DecimalStartGlyph.suno;
    case 'toki':
      return DecimalStartGlyph.toki;
  }
  return null;
}

NumericMode? _numericMode(Object? value) {
  switch ('$value') {
    case 'traditional':
      return NumericMode.traditional;
    case 'uniform':
      return NumericMode.uniform;
  }
  return null;
}

ParseOptions _smokeOptions(Map<String, dynamic> raw) {
  const base = ParseOptions(
    enableBinaryParsing: false,
    enableHexParsing: false,
    mode: NumericMode.uniform,
    numericMode: NumericMode.uniform,
    nanpaColonParsing: true,
    nanpaColonRendering: true,
    relaxedNanpaLinjanParsing: true,
    relaxedNanpaLinjanRendering: true,
    abbreviateNumericCartouches: true,
    preserveNumericCartoucheBreaksInAbbreviation: false,
    nasinNanpaPona: false,
  );
  return base.copyWith(
    enableBinaryParsing: raw['enableBinaryParsing'] is bool
        ? raw['enableBinaryParsing'] as bool
        : null,
    enableHexParsing:
        raw['enableHexParsing'] is bool ? raw['enableHexParsing'] as bool : null,
    mode: _numericMode(raw['mode']),
    numericMode: _numericMode(raw['numericMode']),
    nanpaColonParsing: raw['nanpaColonParsing'] is bool
        ? raw['nanpaColonParsing'] as bool
        : null,
    nanpaColonRendering: raw['nanpaColonRendering'] is bool
        ? raw['nanpaColonRendering'] as bool
        : null,
    relaxedNanpaLinjanParsing: raw['relaxedNanpaLinjanParsing'] is bool
        ? raw['relaxedNanpaLinjanParsing'] as bool
        : null,
    relaxedNanpaLinjanRendering: raw['relaxedNanpaLinjanRendering'] is bool
        ? raw['relaxedNanpaLinjanRendering'] as bool
        : null,
    abbreviateNumericCartouches: raw['abbreviateNumericCartouches'] is bool
        ? raw['abbreviateNumericCartouches'] as bool
        : null,
    preserveNumericCartoucheBreaksInAbbreviation:
        raw['preserveNumericCartoucheBreaksInAbbreviation'] is bool
            ? raw['preserveNumericCartoucheBreaksInAbbreviation'] as bool
            : null,
    numericCartoucheStartGlyph: _startGlyph(raw['numericCartoucheStartGlyph']),
    clearNumericCartoucheStartGlyph:
        raw.containsKey('numericCartoucheStartGlyph') &&
            raw['numericCartoucheStartGlyph'] == null,
    nasinNanpaPona:
        raw['nasinNanpaPona'] is bool ? raw['nasinNanpaPona'] as bool : null,
  );
}

bool _same(Object? a, Object? b) => jsonEncode(a) == jsonEncode(b);

Object? _semanticName(Object? value) {
  if (value == null) return null;
  if (value is SemanticKind) return value.name;
  if (value is DecimalStartGlyph) return value.name;
  return '$value';
}

void _checkSmokeResult(
  String id,
  ParseResult got,
  Map<String, dynamic> want,
) {
  final kind = got.kind?.name ?? 'decimal';
  final base = got.numberBase ?? 10;
  final gotAbbr = (kind == 'hex' || kind == 'binary')
      ? got.abbreviatedWords
      : null;
  final checks = <String, List<Object?>>{
    'caps': <Object?>[got.caps, want['caps']],
    'kind': <Object?>[kind, want['kind']],
    'numberBase': <Object?>[base, want['numberBase']],
    'properName': <Object?>[got.properName, want['properName']],
    'uniqueCode': <Object?>[got.uniqueCode, want['uniqueCode']],
    'displayValue': <Object?>[got.displayValue, want['displayValue']],
    'semanticKind': <Object?>[_semanticName(got.semanticKind), want['semanticKind']],
    'semanticStartGlyph': <Object?>[
      _semanticName(got.semanticStartGlyph),
      want['semanticStartGlyph'],
    ],
    'isDate': <Object?>[got.isDate, want['isDate']],
    'isTime': <Object?>[got.isTime, want['isTime']],
    'numericMode': <Object?>[got.numericMode, want['numericMode']],
    'tpWords': <Object?>[got.tpWords, want['tpWords']],
    'abbreviatedWords': <Object?>[gotAbbr, want['abbreviatedWords']],
  };
  for (final entry in checks.entries) {
    if (!_same(entry.value[0], entry.value[1])) {
      _fail(
        '$id ${entry.key}: got=${jsonEncode(entry.value[0])} '
        'want=${jsonEncode(entry.value[1])}',
      );
    }
  }
}

void main() {
  final root = File.fromUri(Platform.script).parent.parent;
  final profile = jsonDecode(
    File('${root.path}/conformance/parser-renderer-profile-v1.1.0.json')
        .readAsStringSync(),
  ) as Map<String, dynamic>;

  _check(profile['profileVersion'] == '1.1.0', 'profileVersion is not 1.1.0');
  _check(referenceImplementationVersion == '1.1.0',
      'referenceImplementationVersion is $referenceImplementationVersion');
  _check(targetProtocolVersion == '1.1.0',
      'targetProtocolVersion is $targetProtocolVersion');

  final fullDefaults = const FullParserOptions();
  _check(fullDefaults.numericMode == 'uniform', 'full default numericMode');
  _check(fullDefaults.relaxedNanpaLinjanParsing, 'full default relaxed parsing');
  _check(fullDefaults.relaxedNanpaLinjanRendering, 'full default relaxed rendering');
  _check(fullDefaults.nanpaColonParsing, 'full default nanpa parse');
  _check(fullDefaults.nanpaColonRendering, 'full default nanpa render');
  _check(fullDefaults.abbreviateNumericCartouches, 'full default abbreviation');
  _check(!fullDefaults.preserveNumericCartoucheBreaks, 'full default preserve breaks');
  _check(!fullDefaults.enableHexParsing, 'full default hex must be off');
  _check(!fullDefaults.enableBinaryParsing, 'full default binary parse must be off');
  _check(!fullDefaults.enableBinaryRendering, 'full default binary render must be off');
  _check(!fullDefaults.nasinNanpaPona, 'full default NNP must be off');
  _check(fullDefaults.numericCartoucheStartGlyph == null, 'full default start glyph');
  _check(!fullDefaults.breakLinesAtFullStops, 'full default breakLinesAtFullStops');
  _check(!fullDefaults.interpretDoubleQuotesAsTeTo, 'full default quote interpretation');

  final nanpa = NanpaLinjaN.create();
  final fonts = nanpa.listFonts();
  _check(fonts.length == 8, 'production font count ${fonts.length} != 8');
  final adapters = <String>{};
  for (final font in fonts) {
    _check(
      font.parserMode == 'sitelen-pona-ascii-extended',
      '${font.key} parser mode ${font.parserMode}',
    );
    _check(
      font.settings['cartoucheVulgarFractions'] == true,
      '${font.key} cartoucheVulgarFractions',
    );
    _check(
      font.settings['emulateLegacyCartoucheScaling'] == false,
      '${font.key} emulateLegacyCartoucheScaling',
    );
    adapters.add(font.renderAdapterId);
  }
  _check(
    _same(adapters.toList()..sort(), <String>[
      'identity',
      'linja-lipamanka-v1',
      'linja-pona-legacy-v1',
      'linja-sike-legacy-v1',
      'nasin-sitelen-pu-mono-v1',
    ]),
    'production adapter inventory $adapters',
  );

  final cases = (profile['nanpaParserSmokeCases'] as List)
      .cast<Map>()
      .map((e) => Map<String, dynamic>.from(e))
      .toList(growable: false);
  _check(cases.length == 16, 'smoke case count ${cases.length} != 16');
  var passed = 0;
  for (final c in cases) {
    final id = '${c['id']}';
    final options = _smokeOptions(
      Map<String, dynamic>.from((c['options'] as Map?) ?? const {}),
    );
    final got = nanpa.parseNumber('${c['input']}', parserOptions: options);
    final wantRaw = c['result'];
    if (wantRaw == null) {
      _check(got == null, '$id unexpectedly parsed: ${got?.toJson()}');
    } else {
      _check(got != null, '$id unexpectedly returned null');
      _checkSmokeResult(id, got!, Map<String, dynamic>.from(wantRaw as Map));
    }
    passed++;
  }

  // Explicit ordinary-cartouche scale controls, including approved ASCII aliases.
  final scalePlan = nanpa.buildFullRenderPlan(
    '[jan½ pona] [jan1/2 pona] [jan 1/3 pona] 123.45',
    options: const FullRenderOptions(
      font: 'nasinNanpa',
      parser: FullParserOptions(abbreviateNumericCartouches: false),
    ),
  );
  final joined = scalePlan.lines
      .expand((line) => line.runs)
      .map((run) => run.renderText)
      .join('\n');
  for (final marker in const <String>['½', '⅓', '¼', '⅔']) {
    _check(joined.contains(marker), 'render plan missing scale marker $marker');
  }

  final svg = nanpa.renderFullToSvg(
    '123.45',
    options: const FullRenderOptions(
      font: 'nasinNanpa',
      parser: FullParserOptions(abbreviateNumericCartouches: false),
    ),
  );
  final svgText = utf8.decode(svg);
  _check(svgText.contains('<path'), 'numeric SVG has no vector <path>');
  _check(!svgText.contains('<image'), 'numeric SVG contains <image>');
  _check(!svgText.contains('data:image'), 'numeric SVG contains data:image fallback');

  final pdf = nanpa.renderFullToPdf(
    '123.45',
    options: const FullRenderOptions(
      font: 'nasinNanpa',
      parser: FullParserOptions(abbreviateNumericCartouches: false),
    ),
  );
  final pdfLatin1 = latin1.decode(pdf, allowInvalid: true);
  _check(!pdfLatin1.contains('/Subtype /Image'), 'numeric PDF contains raster Image XObject');

  print('Dart Protocol v1.1 profile: $passed/16 parser smoke cases PASS; '
      '8/8 production fonts; inline scaling PASS; vector SVG/PDF PASS');
}
