import 'dart:convert';
import 'dart:io';
import 'package:nanpa_linja_n/nanpa_linja_n.dart';

List<dynamic> listOf(Object? v)=>v is List?v:const <dynamic>[];
Map<String,dynamic> mapOf(Object? v)=>v is Map?Map<String,dynamic>.from(v):<String,dynamic>{};
List<int> ints(Object? v)=>listOf(v).map((x)=>(x as num).toInt()).toList(growable:false);
bool b(Object? v)=>v==true;
String s(Object? v)=>v==null?'':'$v';
List<FullRenderRun> flatten(FullRenderPlan p)=>p.lines.expand((l)=>l.runs).toList(growable:false);
List<int> fullCps(FullRenderRun r)=>(r.fontRole=='cartouche'||r.fontRole=='number'||r.numericCartouche)?<int>[0xF1990,...r.canonicalCodepoints,0xF1991]:const <int>[];
void fail(List<String> e,String id,String what,Object? got,Object? want)=>e.add('$id: $what got=$got want=$want');

void compareAst(List<String> e,String id,DocumentAst g,Map<String,dynamic> w){
  if(s(w['type'])!='document') fail(e,id,'AST.type','document',w['type']);
  if(g.normalizedInput!=s(w['normalizedInput'])) fail(e,id,'AST.normalizedInput',g.normalizedInput,w['normalizedInput']);
  final wl=listOf(w['lines']); if(g.lines.length!=wl.length){fail(e,id,'AST.lines.size',g.lines.length,wl.length);return;}
  for(var i=0;i<wl.length;i++){
    final gl=g.lines[i],x=mapOf(wl[i]);
    if(gl.index!=(x['index'] as num).toInt()) fail(e,id,'AST.line[$i].index',gl.index,x['index']);
    if(gl.sourceLineIndex!=(x['sourceLineIndex'] as num).toInt()) fail(e,id,'AST.line[$i].sourceLineIndex',gl.sourceLineIndex,x['sourceLineIndex']);
    if(gl.sentenceIndexInSourceLine!=(x['sentenceIndexInSourceLine'] as num).toInt()) fail(e,id,'AST.line[$i].sentence',gl.sentenceIndexInSourceLine,x['sentenceIndexInSourceLine']);
    if(gl.sourceText!=s(x['sourceText'])) fail(e,id,'AST.line[$i].sourceText',gl.sourceText,x['sourceText']);
    final wc=listOf(x['children']); if(gl.children.length!=wc.length){fail(e,id,'AST.line[$i].children.size',gl.children.length,wc.length);continue;}
    for(var j=0;j<wc.length;j++){
      final gs=gl.children[j],ws=mapOf(wc[j]); if(gs.kind!=s(ws['kind'])) fail(e,id,'AST child kind',gs.kind,ws['kind']);
      if(ws['value']!=null && gs.value!=s(ws['value'])) fail(e,id,'AST child value',gs.value,ws['value']);
      if(ws['openQuote']!=null && gs.openQuote!=s(ws['openQuote'])) fail(e,id,'AST openQuote',gs.openQuote,ws['openQuote']);
      if(ws['closeQuote']!=null && gs.closeQuote!=s(ws['closeQuote'])) fail(e,id,'AST closeQuote',gs.closeQuote,ws['closeQuote']);
      if(ws['image'] is Map){final wi=mapOf(ws['image']),gi=gs.image;if(gi==null)fail(e,id,'AST image',null,wi);else{
        if(gi.src!=s(wi['src']))fail(e,id,'AST image.src',gi.src,wi['src']); if(gi.width!=s(wi['w']))fail(e,id,'AST image.w',gi.width,wi['w']); if(gi.height!=s(wi['h']))fail(e,id,'AST image.h',gi.height,wi['h']); if(gi.alt!=s(wi['alt']))fail(e,id,'AST image.alt',gi.alt,wi['alt']); if(gi.vAlign!=s(wi['valign']))fail(e,id,'AST image.valign',gi.vAlign,wi['valign']);
      }}
    }
  }
}

void main(){
  final root=jsonDecode(File('conformance/full-renderer-canonical-v1.1.0/cases.json').readAsStringSync()) as Map<String,dynamic>;
  final cases=listOf(root['cases']); if((root['caseCount'] as num).toInt()!=cases.length) throw StateError('canonical corpus caseCount mismatch');
  final errors=<String>[];var pass=0;final n=NanpaLinjaN.create();
  for(final co in cases){final c=mapOf(co),oracle=mapOf(c['oracle']),id=s(c['id']);final before=errors.length;
    if(!b(oracle['ok'])){fail(errors,id,'oracle.ok',false,true);continue;}
    try{
      final opts=FullRenderOptions.fromMap(<String,dynamic>{'font':s(c['font']),'parser':mapOf(c['parser'])});
      final plan=n.buildFullRenderPlan(s(c['input']),options:opts);
      if(b(c['compareAst']))compareAst(errors,id,plan.ast,mapOf(oracle['ast']));
      final gr=flatten(plan),wr=listOf(oracle['runs']); if(gr.length!=wr.length){fail(errors,id,'run count',gr.length,wr.length);continue;}
      final random=b(c['randomCps']);
      for(var i=0;i<wr.length;i++){
        final g=gr[i],w=mapOf(wr[i]),p='run[$i] ';
        if(g.kind!=s(w['kind']))fail(errors,id,'${p}kind',g.kind,w['kind']); if(g.renderMode!=s(w['renderMode']))fail(errors,id,'${p}renderMode',g.renderMode,w['renderMode']); if(g.fontRole!=s(w['fontRole']))fail(errors,id,'${p}fontRole',g.fontRole,w['fontRole']); if(g.sourceText!=s(w['sourceText']))fail(errors,id,'${p}sourceText',g.sourceText,w['sourceText']); if(g.sourceKind!=s(w['sourceKind']))fail(errors,id,'${p}sourceKind',g.sourceKind,w['sourceKind']);
        if(!random && g.canonicalCodepoints.toString()!=ints(w['canonicalCps']).toString())fail(errors,id,'${p}canonicalCps',g.canonicalCodepoints,ints(w['canonicalCps'])); final wf=ints(w['canonicalFullCps']); if(!random&&wf.isNotEmpty&&fullCps(g).toString()!=wf.toString())fail(errors,id,'${p}canonicalFullCps',fullCps(g),wf); if(!random&&g.renderCodepoints.toString()!=ints(w['renderCps']).toString())fail(errors,id,'${p}renderCps',g.renderCodepoints,ints(w['renderCps']));
        if(g.renderAdapterId!=s(w['renderAdapterId']))fail(errors,id,'${p}renderAdapterId',g.renderAdapterId,w['renderAdapterId']); if(g.quoted!=b(w['isQuoted']))fail(errors,id,'${p}isQuoted',g.quoted,w['isQuoted']); if(g.interpretedQuote!=b(w['interpretedQuote']))fail(errors,id,'${p}interpretedQuote',g.interpretedQuote,w['interpretedQuote']); if(g.unrecognized!=b(w['isUnrecognized']))fail(errors,id,'${p}isUnrecognized',g.unrecognized,w['isUnrecognized']); if(g.manualTallies.toString()!=ints(w['manualTallies']).toString())fail(errors,id,'${p}manualTallies',g.manualTallies,ints(w['manualTallies'])); if(g.numericCartouche!=b(w['isNumericCartouche']))fail(errors,id,'${p}numericCartouche',g.numericCartouche,w['isNumericCartouche']); if(w['imageAlt']!=null&&g.imageAlt!=s(w['imageAlt']))fail(errors,id,'${p}imageAlt',g.imageAlt,w['imageAlt']); if(w['encodedText']!=null&&g.renderText!=s(w['encodedText']))fail(errors,id,'${p}encodedText',g.renderText,w['encodedText']);
      }
    }catch(e,st){errors.add('$id: build/compare threw $e\n$st');}
    if(errors.length==before)pass++;
  }
  print('Dart canonical full-renderer semantic corpus: $pass/${cases.length} ${errors.isEmpty?'PASS':'FAIL'}');
  if(errors.isNotEmpty){stderr.writeln('--- canonical full-renderer failures (${errors.length}) ---');for(final e in errors)stderr.writeln(e);exitCode=1;}
}
