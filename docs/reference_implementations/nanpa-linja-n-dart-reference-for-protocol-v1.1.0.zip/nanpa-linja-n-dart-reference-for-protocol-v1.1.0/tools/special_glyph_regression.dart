import 'package:nanpa_linja_n/nanpa_linja_n.dart';

void main() {
  final nanpa = NanpaLinjaN.create();
  final failures = <String>[];
  var checks = 0;

  void check(bool condition, String name) {
    checks++;
    if (condition) {
      print('PASS special glyph $name');
    } else {
      failures.add(name);
      print('FAIL special glyph $name');
    }
  }

  const fonts = <String>[
    'nasinNanpa',
    'sitelenSeliKiwen',
    'fairfaxHd',
    'fairfaxPonaHd',
    'linjaPona',
    'linjaSike',
    'nasinSitelenPuMono',
    'linjaLipamanka',
  ];

  for (final font in fonts) {
    final options = FullRenderOptions(font: font, fontSize: 56);
    final plan = nanpa.buildFullRenderPlan('te zz to', options: options);
    final te = plan.runs.where((r) => r.sourceText == 'te').toList();
    final zz = plan.runs.where((r) => r.sourceText == 'zz').toList();
    final to = plan.runs.where((r) => r.sourceText == 'to').toList();
    check(te.length == 1, '$font te recognized once');
    check(to.length == 1, '$font to recognized once');
    check(zz.length == 1, '$font zz recognized once');
    if (te.length == 1) {
      check(
        te.first.canonicalCodepoints.length == 1 &&
            te.first.canonicalCodepoints.first == openQuoteCodepoint &&
            !te.first.renderCodepoints.contains(0xFFFD) &&
            !te.first.renderText.contains('\uFFFD'),
        '$font te remains canonical and never replacement/tofu',
      );
    }
    if (to.length == 1) {
      check(
        to.first.canonicalCodepoints.length == 1 &&
            to.first.canonicalCodepoints.first == closeQuoteCodepoint &&
            !to.first.renderCodepoints.contains(0xFFFD) &&
            !to.first.renderText.contains('\uFFFD'),
        '$font to remains canonical and never replacement/tofu',
      );
    }
    if (zz.length == 1) {
      check(
        zz.first.renderText == String.fromCharCode(0x3000) &&
            (zz.first.widthPx - 56).abs() < .001,
        '$font zz is blank one-em cell',
      );
    }
    if (font == 'linjaPona' || font == 'linjaSike') {
      if (te.length == 1) {
        check(
          te.first.renderMode == 'synthetic-corner-bracket',
          '$font te uses synthetic opening corner',
        );
      }
      if (to.length == 1) {
        check(
          to.first.renderMode == 'synthetic-corner-bracket',
          '$font to uses synthetic closing corner',
        );
      }
      final png = nanpa.renderFullToPng('te tomo to', options: options);
      check(
        png.length >= 8 &&
            png[0] == 0x89 &&
            png[1] == 0x50 &&
            png[2] == 0x4e &&
            png[3] == 0x47,
        '$font synthetic bracket PNG',
      );
    }
  }

  final lipamanka = nanpa.buildFullRenderPlan(
    'jaki ko [jaki ko]',
    options: const FullRenderOptions(font: 'linjaLipamanka'),
  );
  final jaki = lipamanka.runs.where((r) => r.sourceText == 'jaki').toList();
  final ko = lipamanka.runs.where((r) => r.sourceText == 'ko').toList();
  final cartouche = lipamanka.runs.where((r) => r.fontRole == 'cartouche').toList();
  check(
    jaki.isNotEmpty && jaki.first.renderText == 'jaki',
    'linjaLipamanka jaki deterministic Latin adapter',
  );
  check(
    ko.isNotEmpty && ko.first.renderText == 'ko',
    'linjaLipamanka ko deterministic Latin adapter',
  );
  check(
    cartouche.isNotEmpty && cartouche.first.renderText == '[jaki ko]',
    'linjaLipamanka cartouche deterministic alternates',
  );

  final rawPlan = nanpa.buildFullRenderPlan(
    'U+300C U+300D',
    options: const FullRenderOptions(font: 'linjaPona', paddingPx: 0),
  );
  final rawRuns = rawPlan.runs
      .where((r) =>
          r.sourceText.contains('U+300C') || r.sourceText.contains('U+300D'))
      .toList();
  check(
    rawRuns.isNotEmpty &&
        rawRuns.every((r) => r.renderMode != 'synthetic-corner-bracket'),
    'raw U+300C/U+300D bypass synthetic adaptation',
  );
  if (rawRuns.isNotEmpty) {
    final canvas = nanpa.renderRunToNewCanvas(
      rawRuns.first,
      options: const FullRenderOptions(
        font: 'linjaPona', paddingPx: 0, includePlan: true),
    );
    check(
      canvas.plan != null &&
          canvas.plan!.runs.length == 1 &&
          canvas.plan!.runs.first.renderMode == rawRuns.first.renderMode &&
          canvas.plan!.runs.first.fontRole == rawRuns.first.fontRole,
      'renderRunToNewCanvas preserves existing raw run semantics',
    );
  }

  final unknownPlan = nanpa.buildFullRenderPlan(
    'notaword',
    options: const FullRenderOptions(
      paddingPx: 0,
      parser: FullParserOptions(showUnknownText: true),
    ),
  );
  final unknown = unknownPlan.runs.where((r) => r.unrecognized).toList();
  check(unknown.length == 1, 'unknown literal run available for rerender');
  if (unknown.length == 1) {
    final canvas = nanpa.renderRunToNewCanvas(
      unknown.first,
      options: const FullRenderOptions(
        paddingPx: 0,
        includePlan: true,
        parser: FullParserOptions(showUnknownText: true),
      ),
    );
    check(
      canvas.plan != null &&
          canvas.plan!.runs.first.unrecognized &&
          canvas.plan!.runs.first.fontRole == unknown.first.fontRole,
      'renderRunToNewCanvas preserves literal/unknown font role',
    );
  }

  for (final source in const <String>['[jan pona]', '123']) {
    final plan = nanpa.buildFullRenderPlan(
      source,
      options: const FullRenderOptions(font: 'linjaPona', paddingPx: 0),
    );
    check(plan.runs.isNotEmpty, '$source run available for rerender');
    if (plan.runs.isNotEmpty) {
      final run = plan.runs.first;
      final canvas = nanpa.renderRunToNewCanvas(
        run,
        options: const FullRenderOptions(
          font: 'linjaPona', paddingPx: 0, includePlan: true),
      );
      check(
        canvas.width == run.widthPx.ceil() &&
            canvas.height == run.heightPx.ceil() &&
            canvas.plan != null &&
            canvas.plan!.runs.length == 1 &&
            canvas.plan!.runs.first.fontRole == run.fontRole &&
            canvas.plan!.runs.first.renderText == run.renderText,
        'renderRunToNewCanvas preserves measured $source run semantics',
      );
    }
  }

  if (failures.isNotEmpty) {
    throw StateError(
      'Dart special-glyph regression: ${checks - failures.length}/$checks PASS, '
      '${failures.length} failure(s): ${failures.join(', ')}',
    );
  }
  print('Dart special-glyph regression: $checks/$checks PASS');
}
