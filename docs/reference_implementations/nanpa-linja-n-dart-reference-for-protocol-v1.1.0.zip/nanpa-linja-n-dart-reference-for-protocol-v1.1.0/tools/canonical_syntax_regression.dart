import 'dart:convert';
import 'dart:io';
import 'package:nanpa_linja_n/nanpa_linja_n.dart';

List<dynamic> listOf(Object? value) => value is List ? value : const <dynamic>[];
Map<String,dynamic> mapOf(Object? value) => value is Map ? Map<String,dynamic>.from(value) : <String,dynamic>{};
List<int> cps(Object? value) => listOf(value).map((v) {
  if (v is num) return v.toInt();
  final s = '$v';
  return s.startsWith('U+') ? int.parse(s.substring(2), radix:16) : int.parse(s);
}).toList(growable:false);
String cpString(Object? value) {
  final s = value == null ? '' : '$value';
  return s.startsWith('U+') ? String.fromCharCode(int.parse(s.substring(2),radix:16)) : s;
}
List<FullRenderRun> flatten(FullRenderPlan p) => p.lines.expand((l)=>l.runs).toList(growable:false);

void main() {
  final root = jsonDecode(File('conformance/canonical-syntax-v1.0.1-phase1/cases.json').readAsStringSync()) as Map<String,dynamic>;
  final failures=<String>[];
  var passed=0, adapterPassed=0;
  final nanpa=NanpaLinjaN.create();
  for (final raw in listOf(root['cases'])) {
    final c=mapOf(raw), id='${c['id']}', input='${c['input']}', mode='${c['rendererMode']}';
    final before=failures.length;
    final opts=FullRenderOptions(parser: FullParserOptions(rendererMode:mode, mode:mode));
    try {
      final plan=nanpa.buildFullRenderPlan(input, options:opts), rs=flatten(plan);
      if (c.containsKey('expectedNormalizedInput') && plan.ast.normalizedInput != '${c['expectedNormalizedInput']}') {
        failures.add('$id normalizedInput got=${plan.ast.normalizedInput} want=${c['expectedNormalizedInput']}');
      }
      if (c.containsKey('expectedRuns')) {
        final er=listOf(c['expectedRuns']);
        if (rs.length!=er.length) failures.add('$id run count got=${rs.length} want=${er.length}');
        for (var i=0;i<rs.length && i<er.length;i++) {
          final want=cps(er[i]); if (rs[i].canonicalCodepoints.toString()!=want.toString()) failures.add('$id run[$i] canonical=${rs[i].canonicalCodepoints} want=$want');
        }
      } else {
        if (rs.length!=1) failures.add('$id expected one run, got ${rs.length}');
        else {
          final r=rs.first,want=cps(c['expectedCanonicalCodepoints']);
          if (r.canonicalCodepoints.toString()!=want.toString()) failures.add('$id canonical=${r.canonicalCodepoints} want=$want');
          if (c.containsKey('expectedSourceText') && r.sourceText!='${c['expectedSourceText']}') failures.add('$id sourceText=${r.sourceText} want=${c['expectedSourceText']}');
          if (c.containsKey('expectedFontRole') && r.fontRole!='${c['expectedFontRole']}') failures.add('$id fontRole=${r.fontRole} want=${c['expectedFontRole']}');
          if (c.containsKey('expectedRenderText')) { final w=cpString(c['expectedRenderText']); if(r.renderText!=w) failures.add('$id renderText=${r.renderText} want=$w'); }
        }
      }
    } catch (e,st) { failures.add('$id threw $e\n$st'); }
    if (failures.length==before) passed++;
  }
  for (final raw in listOf(root['fontAdapterCases'])) {
    final c=mapOf(raw),id='${c['id']}'; final before=failures.length;
    try {
      final opts=FullRenderOptions(font:'${c['font']}');
      final rs=flatten(nanpa.buildFullRenderPlan('${c['input']}', options:opts));
      if(rs.length!=1) failures.add('$id expected one run, got ${rs.length}');
      else {
        final r=rs.first;
        if(c.containsKey('expectedRenderText') && r.renderText!='${c['expectedRenderText']}') failures.add('$id renderText=${r.renderText} want=${c['expectedRenderText']}');
        if(c.containsKey('expectedRenderCodepoints')) { final w=cps(c['expectedRenderCodepoints']); if(r.renderCodepoints.toString()!=w.toString()) failures.add('$id renderCps=${r.renderCodepoints} want=$w'); }
        if(c['mustDifferFromCanonicalCodepoints']==true && r.renderCodepoints.toString()==r.canonicalCodepoints.toString()) failures.add('$id renderCodepoints unexpectedly equal canonicalCodepoints');
      }
    } catch(e,st){ failures.add('$id threw $e\n$st'); }
    if(failures.length==before) adapterPassed++;
  }
  final total=listOf(root['cases']).length, at=listOf(root['fontAdapterCases']).length;
  print('Dart canonical syntax: $passed/$total ${passed==total?'PASS':'FAIL'}');
  print('Dart canonical production font adapters: $adapterPassed/$at ${adapterPassed==at?'PASS':'FAIL'}');
  if(failures.isNotEmpty){ for(final f in failures) stderr.writeln('FAIL $f'); exitCode=1; }
}
