import 'package:nanpa_linja_n/nanpa_linja_n.dart';

void expect(bool condition, String name, List<String> failures) {
  if (!condition) failures.add(name);
}

DocumentAst replaceSegment(
  DocumentAst ast,
  bool Function(DocumentSegment segment) matches,
  DocumentSegment Function(DocumentSegment segment) replace,
) {
  var changed = false;
  final lines = <DocumentLine>[];
  for (final line in ast.lines) {
    final children = <DocumentSegment>[];
    for (final segment in line.children) {
      if (!changed && matches(segment)) {
        children.add(replace(segment));
        changed = true;
      } else {
        children.add(segment);
      }
    }
    lines.add(DocumentLine(
      index: line.index,
      sourceLineIndex: line.sourceLineIndex,
      sentenceIndexInSourceLine: line.sentenceIndexInSourceLine,
      sourceText: line.sourceText,
      children: List<DocumentSegment>.unmodifiable(children),
    ));
  }
  if (!changed) throw StateError('Requested AST segment was not found.');
  return DocumentAst(
    normalizedInput: ast.normalizedInput,
    breakLinesAtFullStops: ast.breakLinesAtFullStops,
    parserOptions: ast.parserOptions,
    lines: List<DocumentLine>.unmodifiable(lines),
  );
}

DocumentSegment copySegment(
  DocumentSegment segment, {
  String? kind,
  String? value,
  ImageDescriptor? image,
  bool clearImage = false,
  List<int>? codepoints,
  String? openQuote,
  String? closeQuote,
  List<NumericStructure>? numericStructures,
}) =>
    DocumentSegment(
      kind: kind ?? segment.kind,
      value: value ?? segment.value,
      image: clearImage ? null : (image ?? segment.image),
      codepoints: codepoints ?? segment.codepoints,
      openQuote: openQuote ?? segment.openQuote,
      closeQuote: closeQuote ?? segment.closeQuote,
      sourceStart: segment.sourceStart,
      sourceEnd: segment.sourceEnd,
      numericStructures: numericStructures ?? segment.numericStructures,
    );

bool sameImage(ImageDescriptor a, ImageDescriptor b) =>
    a.src == b.src &&
    a.width == b.width &&
    a.height == b.height &&
    a.alt == b.alt &&
    a.vAlign == b.vAlign &&
    a.wriggle == b.wriggle &&
    a.transparent == b.transparent;


DocumentAst numericAst(
  String value,
  List<NumericStructure> structures, {
  FullParserOptions parser = const FullParserOptions(),
}) =>
    DocumentAst(
      normalizedInput: value,
      breakLinesAtFullStops: false,
      parserOptions: parser,
      lines: <DocumentLine>[
        DocumentLine(
          index: 0,
          sourceLineIndex: 0,
          sentenceIndexInSourceLine: 0,
          sourceText: value,
          children: <DocumentSegment>[
            DocumentSegment(
              kind: 'text',
              value: value,
              sourceStart: 0,
              sourceEnd: value.length,
              numericStructures: structures,
            ),
          ],
        ),
      ],
    );

void main() {
  final failures = <String>[];
  var checks = 0;

  void check(bool condition, String name) {
    checks++;
    expect(condition, name, failures);
  }

  const parser = FullParserOptions();

  // 1. Exact stored whitespace, blank lines, brackets, and straight quotes.
  const exactSource = 'jan   pona\t[ jan  pona,, ]\n\n"toki pona"';
  final exactAst = parseFullDocument(exactSource, parser);
  check(astToText(exactAst) == exactSource, 'exact whitespace/blank-line/quote round-trip');

  // 2. Curly quote delimiters are retained.
  const curlySource = 'jan “toki pona”';
  check(
    astToText(parseFullDocument(curlySource, parser)) == curlySource,
    'curly quote delimiter round-trip',
  );

  // 3. Sentence-split AST lines from one physical line are rejoined without a newline.
  const splitSource = 'jan. pona.\nmi.';
  final splitAst = parseFullDocument(
    splitSource,
    const FullParserOptions(breakLinesAtFullStops: true),
  );
  check(astToText(splitAst) == splitSource, 'breakLinesAtFullStops physical-line reconstruction');

  // 4. Edited bracket/cartouche content is serialized from current AST values.
  final bracketAst = parseFullDocument('jan [pona]', parser);
  final editedBracket = replaceSegment(
    bracketAst,
    (segment) => segment.kind == 'bracket',
    (segment) => copySegment(segment, value: 'suno'),
  );
  check(astToText(editedBracket) == 'jan [suno]', 'edited bracket serialization');

  // 5. Edited ordinary text is serialized from current AST values.
  final textAst = parseFullDocument('jan [pona]', parser);
  final editedText = replaceSegment(
    textAst,
    (segment) => segment.kind == 'text' && segment.value.startsWith('jan'),
    (segment) => copySegment(segment, value: 'meli '),
  );
  check(astToText(editedText) == 'meli [pona]', 'edited text serialization');

  // 6. Edited quote value and delimiters are respected.
  final quoteAst = parseFullDocument('jan "pona"', parser);
  final editedQuote = replaceSegment(
    quoteAst,
    (segment) => segment.kind == 'quote',
    (segment) => copySegment(
      segment,
      value: 'suno',
      openQuote: '“',
      closeQuote: '”',
    ),
  );
  check(astToText(editedQuote) == 'jan “suno”', 'edited quote serialization');

  // 7. img(...) lexical formatting is canonicalized, but descriptor semantics round-trip.
  const imageSource = "img(src='x.png', w='20',h=\"30\", alt='pic', valign='middle', wriggle=4, transparent=false)";
  final imageAst = parseFullDocument(imageSource, parser);
  final imageText = astToText(imageAst);
  final imageRoundTrip = parseFullDocument(imageText, parser);
  final firstImage = imageAst.lines.first.children.first.image;
  final secondImage = imageRoundTrip.lines.first.children.first.image;
  check(
    firstImage != null && secondImage != null && sameImage(firstImage, secondImage),
    'image semantic round-trip',
  );

  // 8. Unknown AST segment kinds fail instead of silently losing content.
  var rejectedUnknown = false;
  try {
    astToText(DocumentAst(
      normalizedInput: '',
      breakLinesAtFullStops: false,
      lines: const <DocumentLine>[
        DocumentLine(
          index: 0,
          sourceLineIndex: 0,
          sentenceIndexInSourceLine: 0,
          sourceText: '',
          children: <DocumentSegment>[
            DocumentSegment(kind: 'unknown', sourceStart: 0, sourceEnd: 0),
          ],
        ),
      ],
    ));
  } on ArgumentError {
    rejectedUnknown = true;
  }
  check(rejectedUnknown, 'unsupported segment rejection');


  // 9. Raw UCSUR AST segments serialize to canonical U+ notation.
  final rawAst = DocumentAst(
    normalizedInput: '',
    breakLinesAtFullStops: false,
    lines: const <DocumentLine>[
      DocumentLine(
        index: 0,
        sourceLineIndex: 0,
        sentenceIndexInSourceLine: 0,
        sourceText: '',
        children: <DocumentSegment>[
          DocumentSegment(
            kind: 'rawUcsur',
            codepoints: <int>[0xF1900, 0x300C],
            sourceStart: 0,
            sourceEnd: 0,
          ),
        ],
      ),
    ],
  );
  check(astToText(rawAst) == 'U+F1900 U+300C', 'raw UCSUR serialization');

  // 10. Invalid Unicode scalars in raw UCSUR AST segments are rejected.
  var rejectedRaw = false;
  try {
    astToText(DocumentAst(
      normalizedInput: '',
      breakLinesAtFullStops: false,
      lines: const <DocumentLine>[
        DocumentLine(
          index: 0,
          sourceLineIndex: 0,
          sentenceIndexInSourceLine: 0,
          sourceText: '',
          children: <DocumentSegment>[
            DocumentSegment(
              kind: 'rawUcsur',
              codepoints: <int>[0xD800],
              sourceStart: 0,
              sourceEnd: 0,
            ),
          ],
        ),
      ],
    ));
  } on ArgumentError {
    rejectedRaw = true;
  }
  check(rejectedRaw, 'invalid raw UCSUR rejection');

  // 11. Public parseNumber exposes the canonical v1.1 numeric result.
  final publicNumber = parseNumber('123');
  check(
    publicNumber != null &&
        publicNumber.properName == 'Nanpa Watusen' &&
        publicNumber.uniqueCode == '#~WTS' &&
        publicNumber.abbreviatedWords == null &&
        publicNumber.nasinNanpaPonaWords == null,
    'public parseNumber canonical decimal result',
  );
  check(parseNumber('#ABC') == null, 'public parseNumber hex default opt-in');
  check(parseNumber('0b1010') == null, 'public parseNumber binary default opt-in');

  final one = numericAst(
    'mi jo e 123',
    const <NumericStructure>[
      NumericStructure(index: 8, end: 11, sourceText: '123'),
    ],
  );
  check(
    astToText(one, const FullRenderOptions(numericOutput: 'source')) ==
        'mi jo e 123',
    'numericOutput source',
  );
  check(
    astToText(one, const FullRenderOptions(numericOutput: 'properName')) ==
        'mi jo e Nanpa Watusen',
    'numericOutput properName',
  );
  check(
    astToText(one, const FullRenderOptions(numericOutput: '#~')) ==
        'mi jo e #~WTS',
    'numericOutput #~',
  );

  final unavailable = numericAst(
    '#ABC 0b1010',
    const <NumericStructure>[
      NumericStructure(index: 0, end: 4, sourceText: '#ABC'),
      NumericStructure(index: 5, end: 11, sourceText: '0b1010'),
    ],
  );
  check(
    astToText(unavailable, const FullRenderOptions(numericOutput: '#~')) ==
        '#ABC 0b1010',
    '#~ unavailable fallback preserves source',
  );

  final bare123 = numericAst(
    '123',
    const <NumericStructure>[
      NumericStructure(index: 0, end: 3, sourceText: '123'),
    ],
  );
  check(
    astToText(
          bare123,
          const FullRenderOptions(
            numericOutput: 'cartouche',
            parser: FullParserOptions(abbreviateNumericCartouches: false),
          ),
        ) ==
        '[nanpa : wan ala tu uta seli e nanpa]',
    'full numeric cartouche',
  );
  check(
    astToText(
          bare123,
          const FullRenderOptions(
            numericOutput: 'cartouche',
            parser: FullParserOptions(abbreviateNumericCartouches: true),
          ),
        ) ==
        '[nanpa : wan tu seli nanpa]',
    'abbreviated numeric cartouche',
  );
  check(
    astToText(
          bare123,
          const FullRenderOptions(
            numericOutput: 'cartouche',
            parser: FullParserOptions(nasinNanpaPona: true),
          ),
        ) ==
        'wan ale mute tu wan',
    'nasin nanpa pona cartouche precedence',
  );
  check(
    astToText(
          bare123,
          const FullRenderOptions(
            numericOutput: '#~',
            parser: FullParserOptions(nasinNanpaPona: true),
          ),
        ) ==
        'wan ale mute tu wan',
    'nasin nanpa pona #~ precedence',
  );

  final mixedFraction = numericAst(
    '1+1/2',
    const <NumericStructure>[
      NumericStructure(index: 0, end: 5, sourceText: '1+1/2'),
    ],
  );
  check(
    astToText(
          mixedFraction,
          const FullRenderOptions(
            numericOutput: 'cartouche',
            parser: FullParserOptions(
              abbreviateNumericCartouches: true,
              preserveNumericCartoucheBreaks: true,
            ),
          ),
        ) ==
        '[nanpa : wan kin wan o o tu nanpa]',
    'valid mixed fraction keeps semantic kin delimiter',
  );
  check(
    parseNumber('1 1/2') == null,
    'spaced mixed fraction is not a valid numeric input',
  );
  check(
    parseNumber('1 e8') == null && parseNumber('1 /2') == null,
    'digit-based scientific/fraction internal whitespace is rejected',
  );
  check(
    parseNumber(
          'Nanpa Wan Eke Tusenan Eke Lunumun',
          const ParseOptions(nanpaColonParsing: true),
        ) !=
        null,
    'numeric proper-name spaces remain valid',
  );
  check(
    parseNumber(
          '[nanpa : wan tu seli nanpa]',
          const ParseOptions(nanpaColonParsing: true),
        ) !=
        null,
    'numeric cartouche spaces remain valid',
  );

  final multiple = numericAst(
    'a 123 b 45 c',
    const <NumericStructure>[
      NumericStructure(index: 2, end: 5, sourceText: '123'),
      NumericStructure(index: 8, end: 10, sourceText: '45'),
    ],
  );
  check(
    astToText(multiple, const FullRenderOptions(numericOutput: '#~')) ==
        'a #~WTS b #~AL c',
    'multiple numeric structures',
  );

  final stale = numericAst(
    '124',
    const <NumericStructure>[
      NumericStructure(index: 0, end: 3, sourceText: '123'),
    ],
  );
  check(
    astToText(stale, const FullRenderOptions(numericOutput: 'properName')) ==
        '124',
    'stale numeric metadata protection',
  );

  var rejectedNumericOutput = false;
  try {
    astToText(
      bare123,
      const FullRenderOptions(numericOutput: 'abbreviation'),
    );
  } on ArgumentError {
    rejectedNumericOutput = true;
  }
  check(rejectedNumericOutput, 'unsupported numericOutput rejection');

  if (failures.isNotEmpty) {
    for (final failure in failures) {
      print('FAIL $failure');
    }
    throw StateError('Dart astToText regression: ${checks - failures.length}/$checks PASS, ${failures.length} failure(s)');
  }

  print('Dart astToText regression: $checks/$checks PASS');

  // Native/full-renderer integration: edited AST -> text -> normal PNG renderer.
  final nanpa = NanpaLinjaN.create();
  final facadeAst = nanpa.parseInput('jan [pona]');
  final facadeEdited = replaceSegment(
    facadeAst,
    (segment) => segment.kind == 'bracket',
    (segment) => copySegment(segment, value: 'suno'),
  );
  final facadeText = nanpa.astToText(facadeEdited);
  final parsedNumeric = nanpa.parseInput('a 123 b 45 c');
  final structures = parsedNumeric.lines
      .expand((line) => line.children)
      .expand((segment) => segment.numericStructures)
      .toList(growable: false);
  if (structures.length != 2) {
    throw StateError(
      'Dart parseInput numeric structure integration failed: ${structures.length}',
    );
  }
  final facadeHash = nanpa.astToText(
    parsedNumeric,
    options: const FullRenderOptions(numericOutput: '#~'),
  );
  if (facadeHash != 'a #~WTS b #~AL c') {
    throw StateError('Dart facade astToText numeric output failed: $facadeHash');
  }
  final instanceNumber = nanpa.parseNumber('123');
  if (instanceNumber == null ||
      instanceNumber.abbreviatedWords != null ||
      instanceNumber.nasinNanpaPonaWords != null) {
    throw StateError('Dart facade parseNumber v1.1 result shape failed');
  }
  final facadeAbbreviated = nanpa.astToText(
    parsedNumeric,
    options: const FullRenderOptions(
      numericOutput: 'cartouche',
      parser: FullParserOptions(abbreviateNumericCartouches: true),
    ),
  );
  if (!facadeAbbreviated.contains('[nanpa : wan tu seli nanpa]')) {
    throw StateError('Dart facade astToText abbreviation failed: $facadeAbbreviated');
  }
  final png = nanpa.renderFullToPng(facadeText);
  final pngOk = png.length >= 8 &&
      png[0] == 0x89 &&
      png[1] == 0x50 &&
      png[2] == 0x4E &&
      png[3] == 0x47;
  if (!pngOk) throw StateError('Dart astToText render integration failed');
  print('Dart astToText parse/render integration: PASS');
}
