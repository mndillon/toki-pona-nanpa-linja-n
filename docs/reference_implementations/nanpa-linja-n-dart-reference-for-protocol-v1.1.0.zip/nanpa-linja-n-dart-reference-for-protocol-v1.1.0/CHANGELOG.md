# Changelog

## 1.1.0 — 2026-09-25

- Target nanpa-linja-n Protocol v1.1.0.
- Retain seven frozen Core-v1 implementation files unchanged.
- Add public v1.1 parser defaults; hex and binary are opt-in.
- Align full-document defaults with the v1.1 parser/renderer profile.
- Align ordinary decimal/date/time `parseNumber()` public result usage with the canonical v1.1 shape.
- Derive alternate serializer representations in `astToText()` rather than requiring decimal convenience fields.
- Replace production font/profile assets with the current eight-font v1.1 set.
- Update native companion family names to the actual supplied font metadata.
- Implement the current five production render adapters.
- Remove active legacy `ss12`/`ss13`/`ss14` scale selection.
- Add inline vulgar-fraction cartouche scale controls and approved ASCII aliases.
- Update outside-cartouche comma behavior.
- Replace stale render-plan/full-renderer authorities with current v1.1 data.
- Add current v1.1 parser-smoke and vector SVG/PDF qualification tests.
- Add release/static validation and refreshed documentation.

## Historical

Earlier package revisions targeted Protocol v1.0.0 / Core-v1 and established the native Dart FFI production-rendering architecture retained by this release.
