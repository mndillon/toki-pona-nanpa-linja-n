import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadProductionManifest, productionPairFaces, fileExists, PRODUCTION_MANIFEST_REL, VECTOR_WASM_JS_REL, VECTOR_WASM_BG_REL } from './lib/production-assets.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const loaded=await loadProductionManifest(root);
if(!loaded){ console.error(`MISSING ${PRODUCTION_MANIFEST_REL}`); process.exit(1); }
console.log(`manifest: ${PRODUCTION_MANIFEST_REL}`);
console.log(`schema: ${loaded.manifest.schema ?? '(unspecified)'}`);
console.log(`pairs: ${loaded.manifest.pairs.length}`);
let missing=0;
for(const pair of loaded.manifest.pairs){
  const faces=await productionPairFaces(root,loaded.manifestPath,pair);
  console.log(`\n${pair.fontKey}: ${pair.label || ''}`);
  for(const face of faces){const ok=face.filePath && await fileExists(face.filePath); console.log(`  ${ok?'OK':'MISSING'} ${face.role}: ${face.filePath || face.url || face.filename || ''}`); if(!ok)missing++;}
}
for(const rel of [VECTOR_WASM_JS_REL,VECTOR_WASM_BG_REL]){ const p=path.join(root,rel); const ok=await fileExists(p); console.log(`\n${ok?'OK':'MISSING'} ${rel}`); if(!ok)missing++; }
if(missing){console.error(`\nasset inspection: ${missing} missing file(s)`);process.exitCode=1;}else console.log('\nasset inspection: PASS');
