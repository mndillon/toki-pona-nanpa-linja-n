import {browserCandidates} from './lib/chromium-dump.mjs';

const candidates = browserCandidates();
if (!candidates.length) {
  console.error('No Chromium-family browser was discovered.');
  console.error('Checked environment variables, PATH names, common Linux paths, and Flatpak app IDs.');
  console.error('If you know the executable path, run: NANPA_CHROMIUM=/path/to/browser npm run test:browser');
  process.exitCode = 1;
} else {
  console.log('Browser candidates, in selection order:');
  for (const [i, c] of candidates.entries()) {
    const command = [c.command, ...(c.prefixArgs || [])].join(' ');
    console.log(`${i === 0 ? '*' : ' '} ${command}`);
    console.log(`    source: ${c.source}`);
  }
}
