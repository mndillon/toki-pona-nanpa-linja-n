#!/usr/bin/env node
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { runEmbeddedHarness } from './lib/chromium-dump.mjs';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const requested=process.argv[2]||'canonical-full';
if(!['canonical-syntax','canonical-full'].includes(requested)){
  console.error(`usage: ${process.argv[1]} canonical-syntax|canonical-full`);
  process.exit(2);
}
const timeoutMs=requested==='canonical-full'?300000:180000;
const {result:r,browser}=await runEmbeddedHarness({rootDir:root,mode:requested,timeoutMs,launchTimeoutMs:30000});
console.log(`browser: ${browser.source}`);
console.log(`browser ${r.mode}: ${r.checks} checks, ${r.failures.length} failures`);
for(const n of r.notes||[])console.log(`NOTE: ${n}`);
for(const f of r.failures||[])console.error(`[${f.id}] ${f.field}\n  actual: ${JSON.stringify(f.actual)}\n  expected: ${JSON.stringify(f.expected)}`);
if(r.status!=='PASS')process.exitCode=1;
