#!/usr/bin/env node
import assert from 'node:assert/strict';
import * as facade from '../src/nanpa-linja-n.js';
import * as advanced from '../src/advanced.js';

const requiredFacadeExports=['NanpaLinjaN','astToText','parseNumber','NanpaParser','SitelenRenderer','SitelenVectorExporter','createSitelenFontPairController','TEXT_FONT_OPTION_SITELEN','default'];
const requiredAdvancedExports=['NanpaParser','SitelenRenderer','SitelenVectorExporter','createSitelenFontPairController','TEXT_FONT_OPTION_SITELEN','TEXT_FONT_OPTION_NANPA_LINJA_N'];
const requiredMethods=['listFonts','getFontInfo','parse','astToText','parseNumber','buildRenderPlan','render','renderToCanvas','renderToPng','renderToSvg','renderToPdf','destroy'];
let checks=0;
for(const name of requiredFacadeExports){checks++;assert.ok(name in facade,`missing facade export ${name}`);}
for(const name of requiredAdvancedExports){checks++;assert.ok(name in advanced,`missing advanced export ${name}`);}
checks++;assert.equal(facade.default,facade.NanpaLinjaN,'default export must be NanpaLinjaN');
for(const name of requiredMethods){checks++;assert.equal(typeof facade.NanpaLinjaN.prototype[name],'function',`missing NanpaLinjaN.prototype.${name}`);}
checks++;assert.equal(typeof facade.astToText,'function','astToText named export missing');
checks++;assert.equal(typeof facade.parseNumber,'function','parseNumber named export missing');
checks++;assert.equal(typeof facade.NanpaParser.parseNumber,'function','NanpaParser.parseNumber missing');
checks++;assert.equal(typeof facade.NanpaLinjaN.prototype.astToText,'function','astToText instance method missing');
console.log(`JavaScript API surface: ${checks} checks PASS`);
