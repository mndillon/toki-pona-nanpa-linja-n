#!/usr/bin/env node
import {spawnSync} from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
process.chdir(root);
const reportDir=path.resolve('test-output');
fs.mkdirSync(reportDir,{recursive:true});
const reportPath=path.join(reportDir,'javascript-regression-report.txt');
const hasAssets=fs.existsSync(path.resolve('assets/fonts/preloaded-font-pairs.manifest.json'));

const steps=[
  ['reference hashes','node',['scripts/verify-reference-hashes.mjs']],
  ['fixture validation','node',['scripts/validate-fixtures.mjs']],
  ['conformance validation','node',['scripts/validate-conformance.mjs']],
  ['API surface','node',['scripts/run-api-surface-regression.mjs']],
  ['frozen protocol regression','node',['scripts/run-protocol-regression.mjs']],
  ['protocol v1.1 integrated profile','node',['scripts/run-v1.1-profile-regression.mjs']],
  ['astToText regression','node',['scripts/run-ast-to-text-regression.mjs']],
  ['browser core/facade/vector mock','node',['scripts/run-browser-regression.mjs']],
  ['canonical syntax + adapters','node',['scripts/run-canonical-browser-regression.mjs','canonical-syntax']],
  ['canonical full renderer','node',['scripts/run-canonical-browser-regression.mjs','canonical-full']],
];
if(hasAssets)steps.push(
  ['asset inspection','node',['scripts/inspect-assets.mjs']],
  ['font files/OpenType coverage','node',['scripts/verify-font-files.mjs']],
  ['browser production fonts','node',['scripts/run-browser-regression.mjs','--fonts']],
  ['SVG production goldens','node',['scripts/svg-goldens.mjs']],
); else steps.push(['production assets','skip',[]]);

const started=new Date();
const report=[];
report.push('nanpa-linja-n JavaScript consolidated regression report');
report.push(`started: ${started.toISOString()}`);
report.push(`node: ${process.version}`);
report.push(`platform: ${process.platform} ${process.arch}`);
report.push('');
let failed=0,passed=0,skipped=0;
const summary=[];

for(const [name,kind,args] of steps){
  process.stdout.write(`\n=== ${name} ===\n`);
  if(kind==='skip'){
    const line='SKIP: production font manifest not present; asset-dependent stages not run.';
    console.log(line); report.push(`=== ${name} ===`,line,''); summary.push([name,'SKIP']); skipped++; continue;
  }
  const r=spawnSync(process.execPath,args,{encoding:'utf8',maxBuffer:64*1024*1024,timeout:900000,env:process.env});
  const out=String(r.stdout||''),err=String(r.stderr||'');
  if(out)process.stdout.write(out);
  if(err)process.stderr.write(err);
  let status;
  if(r.error){status='FAIL';failed++;console.error(`${name}: FAIL (${r.error.message})`);}
  else if(r.status!==0){status='FAIL';failed++;console.error(`${name}: FAIL (exit ${r.status})`);}
  else {status='PASS';passed++;}
  summary.push([name,status]);
  report.push(`=== ${name} ===`,`command: ${process.execPath} ${args.join(' ')}`,`status: ${status}${r.status==null?'':` (exit ${r.status})`}`,out.trimEnd());
  if(err.trim())report.push('--- stderr ---',err.trimEnd());
  if(r.error)report.push('--- spawn error ---',String(r.error.stack||r.error));
  report.push('');
}

report.push('=== CONSOLIDATED SUMMARY ===');
for(const [name,status] of summary)report.push(`${status}: ${name}`);
report.push(`configured suites: ${steps.length}`);
report.push(`passed suites: ${passed}`);
report.push(`failed suites: ${failed}`);
report.push(`skipped suites: ${skipped}`);
report.push(failed?'OVERALL: FAIL':'OVERALL: PASS');
report.push(`finished: ${new Date().toISOString()}`);
fs.writeFileSync(reportPath,report.join('\n')+'\n');

console.log('\n=== CONSOLIDATED SUMMARY ===');
for(const [name,status] of summary)console.log(`${status}: ${name}`);
console.log(`configured suites: ${steps.length}`);
console.log(`passed suites: ${passed}`);
console.log(`failed suites: ${failed}`);
console.log(`skipped suites: ${skipped}`);
console.log(`report: ${path.relative(root,reportPath)}`);
if(failed){console.error('ONE OR MORE JAVASCRIPT TEST SUITES FAILED');process.exitCode=1;}
else console.log('ALL CONFIGURED JAVASCRIPT TESTS PASS');
