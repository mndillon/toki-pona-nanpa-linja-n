import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { runEmbeddedHarness } from './lib/chromium-dump.mjs';
import { PRODUCTION_MANIFEST_REL, loadProductionManifest, VECTOR_WASM_JS_REL, VECTOR_WASM_BG_REL, fileExists } from './lib/production-assets.mjs';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const update=process.argv.includes('--update');
const loaded=await loadProductionManifest(root);
if(!loaded){console.log(`SVG goldens: SKIP (${PRODUCTION_MANIFEST_REL} not found)`);process.exit(0);}
const vectorJs=path.join(root,VECTOR_WASM_JS_REL), vectorBg=path.join(root,VECTOR_WASM_BG_REL);
if(!(await fileExists(vectorJs)) || !(await fileExists(vectorBg))){console.log('SVG goldens: SKIP (production vector WASM files not found)');process.exit(0);}
const manifestText=await fs.readFile(loaded.manifestPath,'utf8');
const goldenCasesDoc=JSON.parse(await fs.readFile(path.join(root,'fixtures/svg-golden-cases.json'),'utf8'));
const goldenCases=Array.isArray(goldenCasesDoc?.cases)?goldenCasesDoc.cases:[];
const fullCases=goldenCases.filter(c=>c?.abbreviateNumericCartouches!==true);
const abbreviatedCases=goldenCases.filter(c=>c?.abbreviateNumericCartouches===true);
const REQUIRED_CASES_PER_MODE=8;
if(fullCases.length!==REQUIRED_CASES_PER_MODE || abbreviatedCases.length!==REQUIRED_CASES_PER_MODE){
  throw new Error(`SVG golden fixture must contain exactly ${REQUIRED_CASES_PER_MODE} full and ${REQUIRED_CASES_PER_MODE} abbreviated cases; found ${fullCases.length} full and ${abbreviatedCases.length} abbreviated.`);
}
const fullIds=new Set(fullCases.map(c=>String(c.id||'')));
for(const tc of abbreviatedCases){
  const id=String(tc.id||'');
  if(!id.endsWith('-abbr')) throw new Error(`Abbreviated SVG golden case id must end with -abbr: ${id}`);
  const base=id.slice(0,-5);
  if(!fullIds.has(base)) throw new Error(`Abbreviated SVG golden case ${id} has no matching full case ${base}.`);
}
const expectedArtifactCount=(loaded.manifest?.pairs?.length||0)*goldenCases.length;
const productionManifestSha256=crypto.createHash('sha256').update(manifestText).digest('hex');
const goldenManifestPath=path.join(root,'goldens/svg-manifest.json');
let existingManifest=null;try{existingManifest=JSON.parse(await fs.readFile(goldenManifestPath,'utf8'));}catch{}
if(!update && (!existingManifest?.files || Object.keys(existingManifest.files).length===0)){
  console.log('SVG goldens: SKIP (no approved baseline yet; run `npm run goldens:update` after reviewing the production font/vector asset tests)');
  process.exit(0);
}
const {result:r}=await runEmbeddedHarness({rootDir:root,mode:'svg-goldens',timeoutMs:600000,launchTimeoutMs:30000});
const artifactCount=Object.keys(r.artifacts||{}).length;
if(r.status==='PASS' && artifactCount!==expectedArtifactCount){
  throw new Error(`SVG golden harness returned ${artifactCount} artifacts; expected ${expectedArtifactCount} (${loaded.manifest.pairs.length} font pairs × ${goldenCases.length} cases).`);
}
if(r.status!=='PASS'){
  for(const f of r.failures||[]) console.error(`[${f.id}] ${f.field}: ${JSON.stringify(f.actual)} != ${JSON.stringify(f.expected)}`);
  process.exitCode=1;
}else{
  let fail=0;const manifest={schemaVersion:'1.1.0',productionManifestSha256,files:{}};
  await fs.mkdir(path.join(root,'goldens/svg'),{recursive:true});
  for(const[id,svg]of Object.entries(r.artifacts||{})){
    const safe=id.replace(/[^A-Za-z0-9._-]+/g,'_');
    const file=path.join(root,'goldens/svg',`${safe}.svg`),hash=crypto.createHash('sha256').update(svg).digest('hex');
    manifest.files[id]={file:`goldens/svg/${safe}.svg`,sha256:hash};
    if(update){await fs.writeFile(file,svg);console.log(`UPDATED ${id} ${hash}`);}
    else{
      const rec=existingManifest?.files?.[id];
      if(!rec){console.error(`FAIL ${id}: golden missing (run npm run goldens:update only after deliberate review)`);fail++;continue;}
      try{const old=await fs.readFile(path.join(root,rec.file),'utf8');const oh=crypto.createHash('sha256').update(old).digest('hex');if(old!==svg){console.error(`FAIL ${id}: ${oh} -> ${hash}`);fail++;}else console.log(`PASS ${id} ${hash}`);}catch{console.error(`FAIL ${id}: golden file missing: ${rec.file}`);fail++;}
    }
  }
  if(!update){
    for(const id of Object.keys(existingManifest?.files||{})) if(!(id in manifest.files)){console.error(`FAIL stale golden entry: ${id}`);fail++;}
    if(existingManifest?.productionManifestSha256 && existingManifest.productionManifestSha256!==productionManifestSha256){console.error(`FAIL production manifest changed: ${existingManifest.productionManifestSha256} -> ${productionManifestSha256}; review and deliberately refresh goldens`);fail++;}
  }
  if(update)await fs.writeFile(goldenManifestPath,JSON.stringify(manifest,null,2)+'\n');
  const actualCount=Object.keys(manifest.files).length;
  if(actualCount!==expectedArtifactCount){
    console.error(`FAIL SVG golden artifact count: ${actualCount}; expected ${expectedArtifactCount} (${loaded.manifest.pairs.length} font pairs × ${goldenCases.length} cases)`);
    fail++;
  }
  if(fail)process.exitCode=1; else console.log(`SVG goldens: ${actualCount} artifact(s) PASS (${fullCases.length * loaded.manifest.pairs.length} full + ${abbreviatedCases.length * loaded.manifest.pairs.length} abbreviated)`);
}
