#!/usr/bin/env node
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const files=['renderer-browser-cases.json','font-controller-cases.json','vector-export-cases.json','svg-golden-cases.json','reference-hashes.json'];
const supported=new Set(['1.0.0','1.1.0']);
let count=0;
for(const n of files){
  const o=JSON.parse(await fs.readFile(path.join(root,'fixtures',n),'utf8'));
  if(!supported.has(o.schemaVersion)) throw new Error(`${n}: unsupported schemaVersion ${JSON.stringify(o.schemaVersion)}`);
  count++;
}
console.log(`fixture validation: PASS (${count} files; schema 1.0.0/1.1.0)`);
