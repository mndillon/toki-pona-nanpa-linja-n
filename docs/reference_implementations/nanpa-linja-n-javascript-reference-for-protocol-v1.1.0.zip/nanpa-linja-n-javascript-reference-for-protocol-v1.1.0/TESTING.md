# JavaScript reference qualification — Protocol v1.1.0

The JavaScript reference uses executable regression/conformance tests. `npm test` is non-fail-fast: it runs every configured suite, reports each stage independently, and writes `test-output/javascript-regression-report.txt`.

## Qualification matrix

1. **Reference hashes** — verifies the pinned canonical parser/renderer and adapted reference modules.
2. **Fixture validation** — validates machine-readable fixture structure and expected invariants.
3. **Conformance validation** — validates the protocol/conformance data shipped in the package.
4. **API surface** — checks facade and advanced exports plus required instance methods.
5. **Frozen Core-v1 protocol regression** — reruns the complete pre-v1.1 numeric corpus unchanged.
6. **Protocol v1.1 integrated profile** — checks v1.1 defaults, exact canonical JavaScript hash, the 35-operation `NanpaParser` surface, 16 profile smoke cases, production manifest invariants, render-adapter availability, and supplied font archive identity.
7. **`astToText` / `parseNumber` regression** — checks source/proper-name/`#~`/full/abbreviated serialization and `nasinNanpaPona` facade behavior.
8. **Browser core/facade/vector regression** — exercises the actual browser facade, raster PNG output, SVG/PDF vector export, parser flags, render plans, font adapters, and image-neutral parsing.
9. **Canonical syntax + adapters** — checks standard/extended syntax and legacy font adapter translations.
10. **Canonical full renderer** — checks the full v1.1 renderer corpus in a real browser.
11. **Asset inspection** — checks bundled runtime asset presence and metadata.
12. **Font files / OpenType coverage** — verifies production font hashes/files and required cmap coverage, including inline vulgar-fraction cartouche scale controls for opted-in pairs. Automatic `ss12`/`ss13`/`ss14` is not a v1.1 requirement.
13. **Browser production fonts** — loads every production font pair through the real `FontFace`/controller path and exercises pair-specific renderer settings/adapters.
14. **SVG production goldens** — compares 128 current production SVG artifacts and verifies real vector path output with no embedded raster fallback.

## Commands

```bash
npm test
npm run verify:references
npm run validate:fixtures
npm run validate:conformance
npm run test:api
npm run test:protocol
npm run test:profile
npm run test:ast
npm run test:browser
npm run test:canonical-syntax
npm run test:canonical-full
npm run test:assets
npm run test:fonts
npm run test:svg
```

## Vector-output requirement

For generated numeric-cartouche content:

- SVG must remain true vector output. The tests require path geometry and reject `<image>` and `data:image` raster fallback.
- PDF must remain resolution-independent vector content; the browser regression rejects raster Image XObjects for generated output.
- PNG is intentionally raster and is validated by file signature and successful rendering.

## Font-resource requirement

`resources/fonts.zip` is the exact supplied v1.1 archive. `assets/fonts/` is the runtime extraction used by browser tests. The manifest-requested nasin-nanpa literal filename is provided there as a byte-identical compatibility copy of supplied `LiberationSans-Regular.ttf`; this does not alter the supplied archive or normative manifest.

## Golden updates

Production SVG goldens must only be regenerated deliberately:

```bash
npm run goldens:update
```

After any deliberate update, run `npm test` and inspect the changed `goldens/svg-manifest.json` and generated SVG files. Unreferenced historical SVG artifacts should not be included in a release package.
