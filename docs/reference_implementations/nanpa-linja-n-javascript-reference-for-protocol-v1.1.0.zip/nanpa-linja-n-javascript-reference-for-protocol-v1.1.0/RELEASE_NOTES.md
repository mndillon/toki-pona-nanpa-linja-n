# JavaScript reference release — Protocol v1.1.0

This package upgrades the JavaScript reference implementation to nanpa-linja-n Protocol v1.1.0 using the supplied current parser/renderer as the canonical behavioral baseline and the supplied `fonts.zip` as the font-resource input.

## Qualification result

`npm test` runs 14 suites without fail-fast behavior. The release build passed all 14 suites with 0 failures and 0 skips. The consolidated report is `test-output/javascript-regression-report.txt`.

Key verified totals include:

- frozen Core numeric regression: 1030 checks, 0 failures;
- v1.1 integrated profile: 78 checks plus 16/16 `NanpaParser` profile smoke cases and 8/8 font-pair invariants;
- API surface: 32 checks;
- `astToText`: 26 checks;
- browser core/facade/export: 145 checks;
- canonical syntax: 28/28 cases plus 5/5 adapter cases;
- canonical full renderer: 254/254 cases;
- production SVG goldens: 128/128 current artifacts.

SVG/PDF tests explicitly reject raster fallback for generated vector cartouche output.

## Compatibility

The frozen Core-v1 corpus remains a compatibility gate. Protocol-v1.1 behavior is layered through the integrated parser/renderer profile and current production font profile rather than rewriting the historical Core corpus.

See `CHANGELOG.md` and `CHANGED_FILES.txt` for implementation details.
