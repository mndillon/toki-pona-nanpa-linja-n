# nanpa-linja-n JavaScript reference for Protocol v1.1.0

This package is the JavaScript reference implementation for **nanpa-linja-n Protocol v1.1.0**. It preserves the frozen Core-v1 numeric semantics and adds the v1.1 integrated parser/renderer profile, current production font adapters, current font-pair resources, and raster/vector export paths.

## Protocol and canonical source

- Protocol target: `1.1.0`
- Canonical parser/renderer: `reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js`
- Canonical parser/renderer SHA-256: `fdeb3e3bfd46b9f86650fd411a2d1dfb2515580aa258aa8c11a002913631418c`
- Normative profile: `protocol/PARSER-RENDERER-PROFILE.md`
- Machine-readable profile: `protocol/conformance/parser-renderer-profile-v1.1.0.json`
- Frozen Core-v1 corpus remains regression-tested and is not rewritten by this release.

## v1.1 default behavior

Unless explicitly overridden, the facade uses:

- parser mode: `sitelen-pona-ascii-extended`
- numeric mode: `uniform`
- relaxed nanpa-linja-n parsing: `true`
- relaxed nanpa-linja-n rendering: `true`
- nanpa-format parsing/rendering: `true`
- abbreviated numeric/date/time cartouches: `true`
- preserve internal numeric cartouche breaks in abbreviation: `false`
- break physical input lines at full stops: `false`
- interpret double quotes as `te` / `to`: `false`
- hexadecimal parsing: `false`
- binary parsing/rendering: `false`
- `nasinNanpaPona`: `false`
- render adapter: `identity`, unless selected by the active production font pair.

Hexadecimal and binary syntax therefore require explicit opt-in parser options.

## Public facade

```js
import NanpaLinjaN, {
  NanpaParser,
  SitelenRenderer,
  astToText,
  parseNumber,
} from './src/nanpa-linja-n.js';

const api = await NanpaLinjaN.create();

const ast = await api.parse('123');
console.log(api.astToText(ast, { numericOutput: 'abbreviatedCartouche' }));

console.log(parseNumber('123'));

const png = await api.renderToPng('123');
await api.destroy();
```

The facade instance provides:

`listFonts`, `getFontInfo`, `parse`, `astToText`, `parseNumber`, `buildRenderPlan`, `render`, `renderToCanvas`, `renderToPng`, `renderToSvg`, `renderToPdf`, and `destroy`.

The named `parseNumber(input, options?)` export delegates to the canonical `NanpaParser.parseNumber`. For ordinary decimal/date/time results, the canonical v1.1 parser does not require an `abbreviatedWords` field; abbreviated serialization is produced by `astToText`/renderer logic when requested or by default cartouche output.

### `astToText`

Supported numeric output modes include:

- `source`
- `properName`
- `#~`
- `fullCartouche`
- `abbreviatedCartouche`

With no explicit numeric-output override, numeric cartouche output follows the v1.1 abbreviated-cartouche default. `nnpPonaFormat` / `nasinNanpaPona` conversion remains available through the facade for eligible ordinary Arabic numeric input.

## Parser modes and syntax

The v1.1 profile exposes:

- `standard-sitelen-pona-ascii-core`
- `sitelen-pona-ascii-extended`
- `sitelen-seli-kiwen`

Compound operators include `&` (ZWJ), `-` (stacking), and `+` (scaling/nesting). Decimal-digit numeric constructs terminate at whitespace. Yearless dates require the `--MM-DD` input form; bare `MM-DD` is not a yearless-date input form. Double-quote interpretation as `te`/`to` is opt-in, and `zz` remains the ideographic/non-breaking-space alias rather than quote syntax.

## Production fonts and render adapters

`assets/fonts/preloaded-font-pairs.manifest.json` is the current schema-2 production font-pair manifest. It defines eight font pairs and their parser modes, renderer settings, and adapter selection.

Built-in renderer adapters include:

- `linja-pona-legacy-v1`
- `linja-sike-legacy-v1`
- `nasin-sitelen-pu-mono-v1`
- `linja-lipamanka-v1`

The parser remains canonical/font-independent. Adapters translate canonical Common Sitelen Pona code points to the selected font's input contract at render time and retain canonical-to-render span metadata.

The active font pair's manifest `settings` are propagated into `fonts.settings`; this is required for per-font tally behavior, literal-cartouche clipping, long-pi tuning, and v1.1 cartouche scaling.

### Cartouche scaling

Protocol v1.1 does **not** require automatic `ss12`, `ss13`, or `ss14` selection. The current production pairs use inline vulgar-fraction scale-control characters where enabled by `cartoucheVulgarFractions`:

- `¼` U+00BC
- `⅓` U+2153
- `½` U+00BD
- `⅔` U+2154
- `¾` U+00BE

The historical stylistic-set code remains in the canonical renderer only as a deliberately disabled compatibility path.

### Supplied `fonts.zip`

`resources/fonts.zip` is preserved byte-for-byte from the supplied v1.1 font resource archive.

The supplied manifest refers to `nanpa-linja-n-nasin-nanpa-liberation-sans-literal.ttf`, while the supplied archive contains `LiberationSans-Regular.ttf`. To keep both the exact supplied archive and the exact normative manifest intact, the extracted runtime asset tree contains a compatibility copy at the manifest filename. It is byte-identical to the supplied `LiberationSans-Regular.ttf` (SHA-256 `76d04c18ea243f426b7de1f3ad208e927008f961dc5945e5aad352d0dfde8ee8`).

## Vector exports

`renderToSvg` and `renderToPdf` use the production vector exporter when the bundled WASM/vector assets are available. The regression suite explicitly verifies that generated SVG numeric-cartouche output contains vector paths and no `<image>`/`data:image` raster fallback. PDF regression rejects raster `/Subtype /Image` XObjects for generated cartouche content.

PNG output is raster by design.

## Tests

Run the complete qualification suite:

```bash
npm test
```

The runner is non-fail-fast: all configured suites run and a consolidated report is written to `test-output/javascript-regression-report.txt`.

Individual commands include:

```bash
npm run test:profile
npm run test:protocol
npm run test:ast
npm run test:api
npm run test:browser
npm run test:canonical-syntax
npm run test:canonical-full
npm run test:fonts
npm run test:svg
```

See `TESTING.md` for the qualification matrix and `CHANGELOG.md` for v1.1.0 changes.

## Package layout

- `src/` — stable JavaScript facade
- `reference/` — canonical renderer plus font controller and vector exporter
- `protocol/` — Protocol v1.1.0 profile material used by this reference
- `conformance/` — frozen Core and integrated renderer conformance data
- `assets/fonts/` — extracted production font resources and manifest
- `resources/fonts.zip` — exact supplied font archive
- `fixtures/` — API/vector/reference fixtures
- `goldens/` — production SVG golden outputs
- `harness/` — browser regression harness
- `scripts/` — executable validation/regression tooling
- `test-output/` — consolidated test report

## Release discipline

This v1.1.0 package is a controlled parity update. Protocol-facing defaults and integrated renderer/font functionality changed where required by Protocol v1.1.0; the frozen Core-v1 numeric regression corpus remains a compatibility gate.
