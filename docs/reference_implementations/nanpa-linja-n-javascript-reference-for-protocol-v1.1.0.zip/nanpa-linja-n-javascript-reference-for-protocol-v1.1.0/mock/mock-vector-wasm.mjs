export const calls = [];
export function resetCalls() { calls.length = 0; }
export default async function init() { return true; }
export function vectorize_run(_fontBytes, request = {}) {
  const cps = Array.isArray(request.cps) ? request.cps : [];
  const textLen = String(request.text || '').length;
  const count = Math.max(1, cps.length || textLen || 1);
  const px = Math.max(8, Number(request.fontPx || 56));
  const x = Number(request.xPx || 0);
  const baseline = Number(request.baselineYPx || px);
  const width = Math.max(px * 0.6, count * px * 0.34);
  const height = px * 0.82;
  const y = baseline - height;
  const d = `M${x} ${y} L${x + width} ${y} L${x + width} ${baseline} L${x} ${baseline} Z`;
  const path = {
    d,
    commands:[
      {cmd:'M',x,y},{cmd:'L',x:x+width,y},{cmd:'L',x:x+width,y:baseline},{cmd:'L',x,y:baseline},{cmd:'Z'}
    ],
    fill: request.fill || '#111111',
    bounds:{minX:x,minY:y,maxX:x+width,maxY:baseline}
  };
  calls.push(JSON.parse(JSON.stringify(request)));
  return {ok:true,glyphCount:count,advancePx:width,bounds:path.bounds,paths:[path],warnings:[]};
}
export const vectorizeRun = vectorize_run;
