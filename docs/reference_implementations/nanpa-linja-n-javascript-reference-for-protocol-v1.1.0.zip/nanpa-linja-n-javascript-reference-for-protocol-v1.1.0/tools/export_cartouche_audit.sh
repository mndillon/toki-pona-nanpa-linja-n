#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; OUT="${1:-$ROOT/test-output/cartouche-audit}"
: "${NANPA_FONT_DIR:?export NANPA_FONT_DIR=/path/to/fonts}"
NANPA_VISUAL_PROJECT_ROOT="$ROOT" NANPA_VISUAL_OUT="$OUT" NANPA_VISUAL_MODE=ordinary NANPA_VISUAL_FACADE_PATH=/src/nanpa-linja-n.js NANPA_VISUAL_MANIFEST_PATH=assets/fonts/preloaded-font-pairs.manifest.json node "$ROOT/tools/browser_visual_export.mjs"
python3 "$ROOT/tools/make_cartouche_contacts.py" "$OUT"
echo "JavaScript ordinary-cartouche audit: 40 PNG file(s) expected in $OUT"
