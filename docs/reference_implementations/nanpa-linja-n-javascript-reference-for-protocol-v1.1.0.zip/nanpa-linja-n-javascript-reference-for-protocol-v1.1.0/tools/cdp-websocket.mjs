import net from 'node:net';
import crypto from 'node:crypto';

function makeFrame(opcode, payload = Buffer.alloc(0)) {
  const body = Buffer.isBuffer(payload) ? payload : Buffer.from(payload);
  const mask = crypto.randomBytes(4);
  let header;
  if (body.length <= 125) {
    header = Buffer.alloc(2);
    header[0] = 0x80 | opcode;
    header[1] = 0x80 | body.length;
  } else if (body.length <= 0xffff) {
    header = Buffer.alloc(4);
    header[0] = 0x80 | opcode;
    header[1] = 0x80 | 126;
    header.writeUInt16BE(body.length, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = 0x80 | opcode;
    header[1] = 0x80 | 127;
    header.writeBigUInt64BE(BigInt(body.length), 2);
  }
  const masked = Buffer.alloc(body.length);
  for (let i = 0; i < body.length; i++) masked[i] = body[i] ^ mask[i % 4];
  return Buffer.concat([header, mask, masked]);
}

export class SimpleWebSocket {
  constructor(url) {
    this.url = new URL(url);
    if (this.url.protocol !== 'ws:') throw new Error(`Only ws:// URLs are supported: ${url}`);
    this.socket = null;
    this.buffer = Buffer.alloc(0);
    this.fragmentOpcode = null;
    this.fragments = [];
    this.messageHandlers = new Set();
    this.closeHandlers = new Set();
  }

  onMessage(fn) { this.messageHandlers.add(fn); return () => this.messageHandlers.delete(fn); }
  onClose(fn) { this.closeHandlers.add(fn); return () => this.closeHandlers.delete(fn); }

  async connect({timeoutMs = 10000} = {}) {
    const host = this.url.hostname;
    const port = Number(this.url.port || 80);
    const key = crypto.randomBytes(16).toString('base64');
    const expectedAccept = crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
    const path = `${this.url.pathname}${this.url.search}` || '/';
    this.socket = net.createConnection({host, port});
    this.socket.setNoDelay(true);

    await new Promise((resolve, reject) => {
      let headerBuf = Buffer.alloc(0);
      const timer = setTimeout(() => reject(new Error(`WebSocket handshake timed out: ${this.url.href}`)), timeoutMs);
      const fail = (err) => { clearTimeout(timer); reject(err); };
      this.socket.once('error', fail);
      this.socket.once('connect', () => {
        const request = [
          `GET ${path} HTTP/1.1`,
          `Host: ${host}:${port}`,
          'Upgrade: websocket',
          'Connection: Upgrade',
          `Sec-WebSocket-Key: ${key}`,
          'Sec-WebSocket-Version: 13',
          '\r\n'
        ].join('\r\n');
        this.socket.write(request);
      });
      const onData = (chunk) => {
        headerBuf = Buffer.concat([headerBuf, chunk]);
        const end = headerBuf.indexOf('\r\n\r\n');
        if (end < 0) return;
        this.socket.off('data', onData);
        const head = headerBuf.subarray(0, end).toString('utf8');
        const leftover = headerBuf.subarray(end + 4);
        const status = head.split(/\r\n/, 1)[0] || '';
        if (!/\s101\s/.test(status)) return fail(new Error(`WebSocket handshake failed: ${status}\n${head}`));
        const accept = /\r\nSec-WebSocket-Accept:\s*([^\r\n]+)/i.exec(`\r\n${head}`)?.[1]?.trim();
        if (accept && accept !== expectedAccept) return fail(new Error('WebSocket handshake returned an invalid Sec-WebSocket-Accept.'));
        clearTimeout(timer);
        this.socket.off('error', fail);
        this.socket.on('data', data => this.#consume(data));
        this.socket.on('close', () => { for (const fn of this.closeHandlers) { try { fn(); } catch {} } });
        this.socket.on('error', () => {});
        if (leftover.length) this.#consume(leftover);
        resolve();
      };
      this.socket.on('data', onData);
    });
    return this;
  }

  sendText(text) {
    if (!this.socket || this.socket.destroyed) throw new Error('WebSocket is not connected.');
    this.socket.write(makeFrame(0x1, Buffer.from(String(text), 'utf8')));
  }

  close() {
    if (!this.socket || this.socket.destroyed) return;
    try { this.socket.write(makeFrame(0x8)); } catch {}
    try { this.socket.end(); } catch {}
  }

  destroy() {
    if (!this.socket) return;
    try { this.socket.destroy(); } catch {}
    this.socket = null;
    this.buffer = Buffer.alloc(0);
    this.fragmentOpcode = null;
    this.fragments = [];
  }

  #consume(chunk) {
    this.buffer = Buffer.concat([this.buffer, chunk]);
    while (true) {
      if (this.buffer.length < 2) return;
      const b0 = this.buffer[0], b1 = this.buffer[1];
      const fin = !!(b0 & 0x80), opcode = b0 & 0x0f, masked = !!(b1 & 0x80);
      let len = b1 & 0x7f, off = 2;
      if (len === 126) {
        if (this.buffer.length < 4) return;
        len = this.buffer.readUInt16BE(2); off = 4;
      } else if (len === 127) {
        if (this.buffer.length < 10) return;
        const big = this.buffer.readBigUInt64BE(2);
        if (big > BigInt(Number.MAX_SAFE_INTEGER)) throw new Error('WebSocket frame too large.');
        len = Number(big); off = 10;
      }
      const maskLen = masked ? 4 : 0;
      if (this.buffer.length < off + maskLen + len) return;
      let mask = null;
      if (masked) { mask = this.buffer.subarray(off, off + 4); off += 4; }
      let payload = Buffer.from(this.buffer.subarray(off, off + len));
      this.buffer = this.buffer.subarray(off + len);
      if (masked && mask) for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i % 4];

      if (opcode === 0x8) { try { this.socket.end(); } catch {} return; }
      if (opcode === 0x9) { try { this.socket.write(makeFrame(0xA, payload)); } catch {} continue; }
      if (opcode === 0xA) continue;

      if (opcode === 0x1 || opcode === 0x2) {
        if (fin) this.#emitMessage(payload, opcode);
        else { this.fragmentOpcode = opcode; this.fragments = [payload]; }
        continue;
      }
      if (opcode === 0x0 && this.fragmentOpcode != null) {
        this.fragments.push(payload);
        if (fin) {
          const all = Buffer.concat(this.fragments);
          const firstOpcode = this.fragmentOpcode;
          this.fragmentOpcode = null; this.fragments = [];
          this.#emitMessage(all, firstOpcode);
        }
      }
    }
  }

  #emitMessage(payload, opcode) {
    if (opcode !== 0x1) return;
    const text = payload.toString('utf8');
    for (const fn of this.messageHandlers) { try { fn(text); } catch {} }
  }
}

export class CdpConnection {
  constructor(ws) {
    this.ws = ws;
    this.nextId = 1;
    this.pending = new Map();
    this.events = [];
    this.eventHandlers = new Map();
    ws.onMessage(text => this.#onMessage(text));
    ws.onClose(() => {
      for (const {reject} of this.pending.values()) reject(new Error('CDP WebSocket closed.'));
      this.pending.clear();
    });
  }

  on(method, fn) {
    if (!this.eventHandlers.has(method)) this.eventHandlers.set(method, new Set());
    this.eventHandlers.get(method).add(fn);
    return () => this.eventHandlers.get(method)?.delete(fn);
  }

  async send(method, params = {}, {timeoutMs = 15000} = {}) {
    const id = this.nextId++;
    const message = JSON.stringify({id, method, params});
    const promise = new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`CDP command timed out: ${method}`));
      }, timeoutMs);
      this.pending.set(id, {
        resolve: value => { clearTimeout(timer); resolve(value); },
        reject: error => { clearTimeout(timer); reject(error); }
      });
    });
    this.ws.sendText(message);
    return promise;
  }

  #onMessage(text) {
    let msg;
    try { msg = JSON.parse(text); } catch { return; }
    if (msg.id != null) {
      const pending = this.pending.get(msg.id);
      if (!pending) return;
      this.pending.delete(msg.id);
      if (msg.error) pending.reject(new Error(`CDP ${msg.error.code}: ${msg.error.message}`));
      else pending.resolve(msg.result || {});
      return;
    }
    if (msg.method) {
      this.events.push(msg);
      if (this.events.length > 1000) this.events.shift();
      for (const fn of this.eventHandlers.get(msg.method) || []) {
        try { fn(msg.params || {}, msg); } catch {}
      }
    }
  }
}
