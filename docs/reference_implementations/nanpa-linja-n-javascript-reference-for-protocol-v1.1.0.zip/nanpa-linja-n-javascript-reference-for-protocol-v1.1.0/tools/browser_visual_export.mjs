#!/usr/bin/env node
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { runEmbeddedHarness } from '../scripts/lib/chromium-dump.mjs';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const fontDir=path.resolve(process.env.NANPA_FONT_DIR||'');
const outDir=path.resolve(process.env.NANPA_VISUAL_OUT||path.join(root,'test-output'));
const mode=process.env.NANPA_VISUAL_MODE||'numeric';
if(!process.env.NANPA_FONT_DIR)throw new Error('NANPA_FONT_DIR is required');
if(!['numeric','ordinary'].includes(mode))throw new Error(`unknown visual mode ${mode}`);
const manifest=JSON.parse(await fsp.readFile(path.join(root,'assets/fonts/preloaded-font-pairs.manifest.json'),'utf8'));
for(const p of manifest.pairs||[])for(const field of ['baseFilename','companionFilename','literalCartoucheFilename']){const fn=p[field];if(fn&&!fs.existsSync(path.join(fontDir,fn)))throw new Error(`missing font: ${path.join(fontDir,fn)}`)}
const tmp=path.join(os.tmpdir(),`nanpa-js-visual-${process.pid}-${crypto.randomBytes(4).toString('hex')}`);
await fsp.mkdir(path.join(tmp,'assets/fonts'),{recursive:true});await fsp.mkdir(path.join(tmp,'harness'),{recursive:true});
for(const name of ['reference','src','mock','fixtures'])await fsp.symlink(path.join(root,name),path.join(tmp,name),'dir');
await fsp.mkdir(path.join(tmp,'assets'),{recursive:true});await fsp.symlink(path.join(root,'assets/wasm'),path.join(tmp,'assets/wasm'),'dir');
await fsp.copyFile(path.join(root,'assets/fonts/preloaded-font-pairs.manifest.json'),path.join(tmp,'assets/fonts/preloaded-font-pairs.manifest.json'));
for(const p of manifest.pairs||[])for(const field of ['baseFilename','companionFilename','literalCartoucheFilename']){const fn=p[field];if(fn){const dst=path.join(tmp,'assets/fonts',fn);if(!fs.existsSync(dst))await fsp.symlink(path.join(fontDir,fn),dst)}}
const harness=`
const files={}; const toB64=bytes=>{let s='';for(let i=0;i<bytes.length;i+=0x8000)s+=String.fromCharCode(...bytes.subarray(i,i+0x8000));return btoa(s)};
const n=await NanpaLinjaN.create(); const fonts=n.listFonts();
if(${JSON.stringify(mode)}==='numeric'){
 for(const f of fonts){let r=await n.renderToPng('123.45',{font:f.key,fontSize:56,paddingPx:18,parser:{abbreviateNumericCartouches:false}});files[f.key+'-full.png']=toB64(r.bytes);r=await n.renderToPng('123.45',{font:f.key,fontSize:56,paddingPx:18,parser:{abbreviateNumericCartouches:true}});files[f.key+'-abbreviated.png']=toB64(r.bytes)}
}else{
 const vars=[['ordinary-cartouche','[jan pona]',false],['ordinary-cartouche-halo-red','[jan pona]',true],['ordinary-cartouche-tallies','[jan pona,,]',false],['ordinary-cartouche-tallies-halo-red','[jan pona,,]',true]];
 for(const f of fonts)for(const [id,input,halo] of vars){const paint=halo?{halo:{enabled:true,color:'#D91E18',widthPx:6}}:{};const r=await n.renderToPng(input,{font:f.key,fontSize:56,paddingPx:18,paint});files[f.key+'--'+id+'.png']=toB64(r.bytes)}
}
await n.destroy();
const result={status:'PASS',mode:${JSON.stringify(mode)},checks:Object.keys(files).length,failures:[],notes:[],files};
document.documentElement.dataset.nanpaStatus='PASS';document.querySelector('#human').textContent='PASS';document.querySelector('#nanpa-result-b64').textContent=btoa(unescape(encodeURIComponent(JSON.stringify(result))));
`;
await fsp.writeFile(path.join(tmp,'harness/browser-harness.mjs'),harness);
try{
 const {result}=await runEmbeddedHarness({rootDir:tmp,mode,timeoutMs:180000,launchTimeoutMs:30000});
 if(result.status!=='PASS')throw new Error(`browser visual export failed: ${JSON.stringify(result.failures||[])}`);
 await fsp.mkdir(outDir,{recursive:true});
 for(const [name,b64] of Object.entries(result.files||{})){if(path.basename(name)!==name)throw new Error(`unsafe output filename ${name}`);await fsp.writeFile(path.join(outDir,name),Buffer.from(b64,'base64'))}
 console.log(`${mode} browser export: ${Object.keys(result.files||{}).length} PNG file(s) written to ${outDir}`);
}finally{await fsp.rm(tmp,{recursive:true,force:true}).catch(()=>{})}
