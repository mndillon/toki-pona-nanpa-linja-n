import { SitelenRenderer } from '../reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js';
import { createSitelenFontPairController } from '../reference/sitelen-font-pair-controller.js';
import { SitelenVectorExporter } from '../reference/sitelen-vector-exporter.js';
import { NanpaLinjaN } from '../src/nanpa-linja-n.js';

const CP = { CART_START:0xF1990, CART_END:0xF1991 };
const params = new URLSearchParams(location.search);
const mode = params.get('mode') || 'core';
const human = document.querySelector('#human');
const resultEl = document.querySelector('#nanpa-result-b64');
const stage = document.querySelector('#stage');
const failures=[]; let checks=0; const notes=[];
function equal(a,b){return JSON.stringify(a)===JSON.stringify(b)}
function check(ok,id,field,actual,expected){checks++; if(!ok) failures.push({id,field,actual,expected});}
function cpLabel(v){ return Number.isFinite(Number(v)) ? `U+${Number(v).toString(16).toUpperCase().padStart(4,'0')}` : null; }
function flattenRuns(plan){return (plan?.lines||[]).flatMap(l=>l.runs||[]).filter(Boolean)}
function cartoucheRuns(plan){return flattenRuns(plan).filter(r=>String(r.kind||'').toLowerCase()==='cartouche' || String(r?._element?.type||'').toLowerCase()==='cartouche')}
function canonicalFull(run){ return run.canonicalFullCps || run?._element?.canonicalFullCps || null; }
function innerCps(run){
  let a=run.canonicalCps || run.cps || run?._element?.canonicalCps || run?._element?.cps || null;
  if(!Array.isArray(a)){ const f=canonicalFull(run); if(Array.isArray(f)) a=f.slice(1,-1); }
  if(Array.isArray(a) && a[0]===CP.CART_START && a[a.length-1]===CP.CART_END) a=a.slice(1,-1);
  return Array.isArray(a)?a.map(Number):[];
}
function merge(base,extra){ const out=structuredClone(base||{}); for(const [k,v] of Object.entries(extra||{})){ if(v && typeof v==='object' && !Array.isArray(v) && out[k] && typeof out[k]==='object' && !Array.isArray(out[k])) out[k]=merge(out[k],v); else out[k]=structuredClone(v); } return out; }
async function loadJson(url){ const r=await fetch(url,{cache:'no-store'}); if(!r.ok) throw new Error(`${url}: ${r.status}`); return r.json(); }

async function runRendererCases(){
  const fx=await loadJson('../fixtures/renderer-browser-cases.json');
  const renderer=await SitelenRenderer.create(fx.defaultConfig);
  for(const tc of fx.cases){
    let plan;
    try { plan=await renderer.buildRenderPlan({input:tc.input,...(tc.config||{})}); }
    catch(e){ failures.push({id:tc.id,field:'exception',actual:e?.stack||String(e),expected:'no exception'}); continue; }
    const runs=flattenRuns(plan); const carts=cartoucheRuns(plan); const ex=tc.expect||{};
    if(ex.cartoucheCount!=null) check(carts.length===ex.cartoucheCount,tc.id,'cartoucheCount',carts.length,ex.cartoucheCount);
    if(ex.minimumDrawableRuns!=null) check(runs.filter(r=>r.kind!=='gap').length>=ex.minimumDrawableRuns,tc.id,'minimumDrawableRuns',runs.length,`>=${ex.minimumDrawableRuns}`);
    if(ex.firstCartouche){
      const r=carts[0]; check(!!r,tc.id,'firstCartouche.present',!!r,true); if(!r) continue;
      const e=ex.firstCartouche; const inner=innerCps(r); const full=canonicalFull(r)||[];
      for(const key of ['fontRole','isNumericCartouche','isHexCartouche','isBinaryCartouche','numericBase']) if(e[key]!==undefined) check(equal(r[key]??r?._element?.[key],e[key]),tc.id,`firstCartouche.${key}`,r[key]??r?._element?.[key],e[key]);
      if(e.openerCp) check(cpLabel(inner[0])===e.openerCp,tc.id,'firstCartouche.openerCp',cpLabel(inner[0]),e.openerCp);
      if(e.closerCp) check(cpLabel(inner.at(-1))===e.closerCp,tc.id,'firstCartouche.closerCp',cpLabel(inner.at(-1)),e.closerCp);
      if(e.fullStartCp) check(cpLabel(full[0])===e.fullStartCp,tc.id,'firstCartouche.fullStartCp',cpLabel(full[0]),e.fullStartCp);
      if(e.fullEndCp) check(cpLabel(full.at(-1))===e.fullEndCp,tc.id,'firstCartouche.fullEndCp',cpLabel(full.at(-1)),e.fullEndCp);
    }
    if(ex.abbreviated){ const r=carts[0]; const src=r?.audioSourceCps||r?._element?.audioSourceCps; const shown=innerCps(r); check(Array.isArray(src)&&shown.length<=src.length,tc.id,'abbreviated.length',shown.length,Array.isArray(src)?`<=${src.length}`:'audioSourceCps array'); }
  }
}

async function runControllerCases(){
  const fx=await loadJson('../fixtures/font-controller-cases.json');
  const script=document.createElement('select'), text=document.createElement('select'); document.body.append(script,text);
  const p=fx.mockPreset; const c=createSitelenFontPairController({registry:{[p.key]:p},scriptSelect:script,textFontSelect:text,defaultPresetKey:p.key,defaultTextFontOption:'Arial',storageKeyPrefix:'nanpaRegression'});
  await c.ready;
  const roles=c.buildFontRoles({preset:p,textFontOptionKey:'Arial'});
  for(const [k,v] of Object.entries(fx.expect.roles)) check(roles[k]===v,'font-controller',`roles.${k}`,roles[k],v);
  const rc=c.buildRendererConfig({preset:p,baseConfig:{}});
  for(const [k,v] of Object.entries(fx.expect.parser)) check(rc.parser[k]===v,'font-controller',`parser.${k}`,rc.parser[k],v);
  check(rc.fonts.renderAdapterId===fx.expect.defaultRenderAdapterId,'font-controller','renderAdapterId',rc.fonts.renderAdapterId,fx.expect.defaultRenderAdapterId);
  c.destroy(); script.remove(); text.remove();
}

function mockFontController(){ const blob=new Blob([new TextEncoder().encode('mock font bytes')],{type:'application/octet-stream'}); const preset={key:'mock-vector',textFamily:'MockVector',cartoucheFamily:'MockVector',faces:[]}; return {getActivePreset:()=>preset,resolvePresetRecord:async()=>({pairRecord:{baseFamily:'MockVector',companionFamily:'MockVector',baseBlob:blob,companionBlob:blob}})}; }
async function runVectorMockCases(){
  const fx=await loadJson('../fixtures/vector-export-cases.json');
  const parser={mode:'uniform',numericMode:'uniform',relaxedNanpaLinjanParsing:true,relaxedNanpaLinjanRendering:true,nanpaColonParsing:true,nanpaColonRendering:true,enableHexParsing:true,enableBinaryParsing:true};
  const renderer=await SitelenRenderer.create({parser,fonts:{roles:{word:'MockVector',text:'MockVector',cartouche:'MockVector',number:'MockVector',date:'MockVector',time:'MockVector',literal:'MockVector',literalCartouche:'MockVector'}}});
  const exporter=await SitelenVectorExporter.create({renderer,fontController:mockFontController(),wasmModuleUrl:new URL('../mock/mock-vector-wasm.mjs',import.meta.url).href});
  const mock=await import('../mock/mock-vector-wasm.mjs');
  for(const tc of fx.cases){
    mock.resetCalls();
    const cfg={layout:{fontPx:tc.fontPx},parser,fonts:{roles:{word:'MockVector',text:'MockVector',cartouche:'MockVector',number:'MockVector',date:'MockVector',time:'MockVector',literal:'MockVector',literalCartouche:'MockVector'}}};
    const blob=await exporter.exportTextToSvgBlob({input:tc.input,config:cfg,paddingPx:4}); const svg=await blob.text();
    if(tc.expect?.svg){ check(String(blob.type||'').toLowerCase().startsWith('image/svg+xml'),'vector:'+tc.id,'blob.type',blob.type,'image/svg+xml[; parameters allowed]'); check(svg.includes('<svg'),'vector:'+tc.id,'svg tag',svg.includes('<svg'),true); const paths=(svg.match(/<path\b/g)||[]).length; check(paths>=tc.expect.minimumPaths,'vector:'+tc.id,'pathCount',paths,`>=${tc.expect.minimumPaths}`); }
    if(tc.expectOpenTypeFeatures){ const features=mock.calls.filter(c=>Array.isArray(c.openTypeFeatures)).flatMap(c=>c.openTypeFeatures); const uniq=[...new Set(features)]; check(equal(uniq,tc.expectOpenTypeFeatures),'vector:'+tc.id,'openTypeFeatures',uniq,tc.expectOpenTypeFeatures); }
  }
  const pdf=await exporter.exportTextToPdfBlob({input:'123.45',config:{layout:{fontPx:56},parser,fonts:{roles:{word:'MockVector',text:'MockVector',cartouche:'MockVector',number:'MockVector',date:'MockVector',time:'MockVector',literal:'MockVector',literalCartouche:'MockVector'}}}}); const head=await pdf.slice(0,8).text(); check(pdf.type==='application/pdf','vector:pdf','blob.type',pdf.type,'application/pdf'); check(head.startsWith('%PDF-1.'),'vector:pdf','header',head,'%PDF-1.x');
}

function productionManifest(){ return globalThis.__NANPA_PRODUCTION_MANIFEST__ || null; }
function productionAssetMeta(){ return Array.isArray(globalThis.__NANPA_FONT_ASSETS_META__) ? globalThis.__NANPA_FONT_ASSETS_META__ : []; }
function productionAssetUrls(){ return globalThis.__NANPA_FONT_ASSET_URLS__ || {}; }
function pairRegressionOptions(pair){ const r=(pair?.regression&&typeof pair.regression==='object')?pair.regression:{}; return {browser:r.browser!==false,vector:r.vector!==false}; }
const LEGACY_ASCII_ADAPTERS=new Set(['linja-pona-legacy-v1','linja-sike-legacy-v1']);
function runRenderFullCps(run){ const candidates=[run?.renderFullCps,run?._element?.renderFullCps,run?.renderCps,run?._element?.renderCps]; for(const v of candidates) if(Array.isArray(v)&&v.length) return v.map(Number); return []; }
function presetRegistryFromProduction(manifest){
  const r={}; const meta=productionAssetMeta(); const urls=productionAssetUrls();
  for(const pair of manifest?.pairs||[]){
    const key=String(pair?.fontKey||'').trim(); if(!key) continue;
    const faces=meta.filter(a=>a.pairKey===key).map(a=>({family:a.family,url:urls[a.id],format:a.format,sample:a.sample||undefined})).filter(f=>f.family&&f.url);
    r[key]={
      key,
      label:pair.label||key,
      textFamily:pair.baseFamily||pair.textFamily||key,
      cartoucheFamily:pair.companionFamily||pair.cartoucheFamily||`${key}-nanpa-linja-n`,
      literalCartoucheFamily:pair.literalCartoucheFamily||pair.literalCartoucheFontFamily||pair.baseFamily||pair.textFamily||key,
      parserMode:pair.parserMode||'sitelen-pona-ascii-extended',
      renderAdapterId:pair.renderAdapterId||'identity',
      renderAdapterSettings:{...(pair.renderAdapterSettings||{})},
      settings:{...(pair.settings||{})},
      faces,
      __pairRecord:{...pair}
    };
  }
  return r;
}
async function runAssetFontTests(){
  const manifest=productionManifest(); if(!manifest?.pairs?.length){ notes.push('production font manifest/assets not embedded: asset browser tests skipped'); return; }
  if(!globalThis.__NANPA_REAL_VECTOR_WASM_MODULE__){ check(false,'vector-wasm','module','missing','loaded production vector WASM module'); }
  else if(typeof globalThis.__NANPA_REAL_VECTOR_WASM_MODULE__.healthcheck==='function'){
    const health=String(globalThis.__NANPA_REAL_VECTOR_WASM_MODULE__.healthcheck());
    check(health.length>0,'vector-wasm','healthcheck',health,'non-empty');
  }
  const registry=presetRegistryFromProduction(manifest); const keys=Object.keys(registry); if(!keys.length){notes.push('production manifest has no usable font pairs');return;}
  const script=document.createElement('select'), text=document.createElement('select'); document.body.append(script,text);
  const c=createSitelenFontPairController({registry,scriptSelect:script,textFontSelect:text,defaultPresetKey:keys[0],defaultTextFontOption:'__active_text_family__',storageKeyPrefix:'nanpaAssetRegression'}); await c.ready;
  for(const key of keys){
    const pair=(manifest.pairs||[]).find(p=>p.fontKey===key)||{}; if(!pairRegressionOptions(pair).browser) continue;
    c.setActivePreset(key,{persist:false}); await c.waitForConfiguredFonts(56); const p=c.getActivePreset();
    for(const f of p.faces||[]){
      const sample=f.sample||String.fromCodePoint(0xF196C,0xF1954,0xF1990)+' Hello';
      const loaded=await document.fonts.load(`56px "${f.family}"`,sample);
      check(loaded.length>0,`font-assets:${key}`,`load:${f.family}`,loaded.length,'>0');
    }
    // Protocol v1.1.0 disables automatic ss12/ss13/ss14 family aliases.
    check(!(p.faces||[]).some(face=>/--nanpa-cartouche-ss1[234]$/.test(String(face.family||''))),`font-assets:${key}`,'no legacy stylistic-set aliases',(p.faces||[]).map(face=>face.family),'no ss12/ss13/ss14 alias families');
    const parser={mode:p.parserMode||'sitelen-pona-ascii-extended',numericMode:'uniform',relaxedNanpaLinjanParsing:true,relaxedNanpaLinjanRendering:true,nanpaColonParsing:true,nanpaColonRendering:true,enableHexParsing:true,enableBinaryParsing:true};
    const renderer=await SitelenRenderer.create(c.buildRendererConfig({preset:p,baseConfig:{layout:{fontPx:56},parser}}));
    const probeInput='2026-09-13';
    const probePlan=await renderer.buildRenderPlan({input:probeInput});
    const probeCartouche=cartoucheRuns(probePlan)[0]||null;
    check(!!probeCartouche,`font-assets:${key}`,'adapter probe cartouche',!!probeCartouche,true);
    if(probeCartouche){
      const configuredAdapter=String(pair.renderAdapterId||'identity').trim()||'identity';
      const expectedAdapter=(configuredAdapter==='identity' && pair.settings?.cartoucheVulgarFractions===true)
        ? 'identity-inline-cartouche-scale-v1'
        : configuredAdapter;
      const actualAdapter=String(probeCartouche.renderAdapterId||probeCartouche?._element?.renderAdapterId||'identity');
      check(actualAdapter===expectedAdapter,`font-assets:${key}`,'renderAdapterId',actualAdapter,expectedAdapter);
      const rendered=runRenderFullCps(probeCartouche);
      check(rendered.length>0,`font-assets:${key}`,'adapter render codepoints',rendered.length,'>0');
      check(!rendered.includes(0xFFFD),`font-assets:${key}`,'adapter replacement glyph',rendered.includes(0xFFFD),false);
      if(LEGACY_ASCII_ADAPTERS.has(configuredAdapter)){
        const canonical=canonicalFull(probeCartouche)||[];
        const scaleMarkers=new Set([0x00BC,0x2153,0x00BD,0x2154,0x00BE]);
        check(rendered.every(cp=>(cp>=0x20&&cp<=0x7E)||scaleMarkers.has(cp)),`font-assets:${key}`,'legacy adapter font-facing input',rendered.map(cpLabel),'printable ASCII plus inline cartouche scale markers');
        check(!equal(rendered,canonical),`font-assets:${key}`,'legacy adapter translated canonical sequence',rendered.map(cpLabel),'different from canonicalFullCps');
      }
    }
    const renderedCanvas=await renderer.renderTextToNewCanvas({input:probeInput});
    const canvas=renderedCanvas?.canvas || renderedCanvas;
    check(!!canvas&&Number(canvas.width)>0&&Number(canvas.height)>0,`font-assets:${key}`,'canvas dimensions',canvas?{w:canvas.width,h:canvas.height}:null,'>0');
    const ctx=canvas?.getContext?.('2d')||null; let ink=0; if(ctx){ const d=ctx.getImageData(0,0,canvas.width,canvas.height).data; for(let i=3;i<d.length;i+=4) if(d[i]){ink++;if(ink>32)break;} }
    check(ink>0,`font-assets:${key}`,'canvas nonblank',ink,'>0');
  }
  c.destroy(); script.remove(); text.remove();
}


async function runFacadeCases(){
  let facadeStage='create';
  try {
  const facade=await NanpaLinjaN.create({storageKeyPrefix:'nanpaFacadeRegression'});
  const fonts=facade.listFonts();
  const manifest=productionManifest();
  const expectedFonts=Array.isArray(manifest?.pairs)?manifest.pairs.length:8;
  check(Array.isArray(fonts),'facade','fonts.array',Array.isArray(fonts),true);
  check(fonts.length===expectedFonts,'facade','fonts.length',fonts.length,expectedFonts);
  check(fonts.some(f=>f.key==='linjaPona'),'facade','fonts.contains.linjaPona',fonts.map(f=>f.key), 'contains linjaPona');
  check(facade.getFontInfo('linja-pona')?.key==='linjaPona','facade','font alias resolution',facade.getFontInfo('linja-pona')?.key,'linjaPona');

  const astRoundTripSource='jan   pona [ jan  pona,, ]\n\n“toki pona”';
  facadeStage='parse-roundtrip';
  const astRoundTripParsed=await facade.parse(astRoundTripSource);
  const astRoundTripText=facade.astToText(astRoundTripParsed.ast);
  check(astRoundTripText===astRoundTripSource,'facade','astToText.roundTrip',astRoundTripText,astRoundTripSource);

  const numericSource='123 #ABC 0b1010';
  facadeStage='parse-numeric-default';
  const numericParsed=await facade.parse(numericSource);
  const numericStructures=(numericParsed.ast.lines||[]).flatMap(line=>line.children||[]).flatMap(seg=>seg.numericStructures||[]);
  check(numericStructures.length===1,'facade','astToText.numericStructures.defaultCount',numericStructures.length,1);
  check(facade.astToText(numericParsed.ast,{numericOutput:'source'})===numericSource,'facade','astToText.numeric.source',facade.astToText(numericParsed.ast,{numericOutput:'source'}),numericSource);
  check(facade.astToText(numericParsed.ast,{numericOutput:'#~'})==='#~WTS #ABC 0b1010','facade','astToText.numeric.hashTilde',facade.astToText(numericParsed.ast,{numericOutput:'#~'}),'#~WTS #ABC 0b1010');

  facadeStage='parse-numeric-optin';
  const numericOptInParsed=await facade.parse(numericSource,{parser:{enableHexParsing:true,enableBinaryParsing:true}});
  const numericOptInStructures=(numericOptInParsed.ast.lines||[]).flatMap(line=>line.children||[]).flatMap(seg=>seg.numericStructures||[]);
  check(numericOptInStructures.length===3,'facade','astToText.numericStructures.optInCount',numericOptInStructures.length,3);

  facadeStage='parse-decimal';
  const decimalParsed=await facade.parse('123');
  check(facade.astToText(decimalParsed.ast,{numericOutput:'properName'})==='Nanpa Watusen','facade','astToText.numeric.properName',facade.astToText(decimalParsed.ast,{numericOutput:'properName'}),'Nanpa Watusen');
  check(facade.astToText(decimalParsed.ast,{numericOutput:'cartouche'})==='[nanpa : wan tu seli nanpa]','facade','astToText.numeric.cartouche.defaultAbbreviated',facade.astToText(decimalParsed.ast,{numericOutput:'cartouche'}),'[nanpa : wan tu seli nanpa]');
  check(facade.astToText(decimalParsed.ast,{numericOutput:'cartouche',parser:{abbreviateNumericCartouches:false}})==='[nanpa : wan ala tu uta seli e nanpa]','facade','astToText.numeric.cartouche.fullExplicit',facade.astToText(decimalParsed.ast,{numericOutput:'cartouche',parser:{abbreviateNumericCartouches:false}}),'[nanpa : wan ala tu uta seli e nanpa]');
  check(facade.astToText(decimalParsed.ast,{numericOutput:'cartouche',parser:{abbreviateNumericCartouches:true}})==='[nanpa : wan tu seli nanpa]','facade','astToText.numeric.cartouche.abbreviated',facade.astToText(decimalParsed.ast,{numericOutput:'cartouche',parser:{abbreviateNumericCartouches:true}}),'[nanpa : wan tu seli nanpa]');
  check(facade.astToText(decimalParsed.ast,{numericOutput:'cartouche',parser:{nasinNanpaPona:true}})==='wan ale mute tu wan','facade','astToText.numeric.nasinNanpaPona',facade.astToText(decimalParsed.ast,{numericOutput:'cartouche',parser:{nasinNanpaPona:true}}),'wan ale mute tu wan');

  facadeStage='parse-cartouche';
  const cartoucheParsed=await facade.parse('[nanpa : wan ala tu uta seli e nanpa]');
  check(facade.astToText(cartoucheParsed.ast,{numericOutput:'properName'})==='Nanpa Watusen','facade','astToText.numeric.cartoucheToProperName',facade.astToText(cartoucheParsed.ast,{numericOutput:'properName'}),'Nanpa Watusen');
  check(facade.astToText(cartoucheParsed.ast,{numericOutput:'cartouche',parser:{nasinNanpaPona:true}})==='wan ale mute tu wan','facade','astToText.numeric.cartoucheToNasinNanpaPona',facade.astToText(cartoucheParsed.ast,{numericOutput:'cartouche',parser:{nasinNanpaPona:true}}),'wan ale mute tu wan');

  const publicParsedNumber=facade.parseNumber('123');
  check(publicParsedNumber?.displayValue==='123','facade','parseNumber.displayValue',publicParsedNumber?.displayValue,'123');
  check(publicParsedNumber?.properName==='Nanpa Watusen','facade','parseNumber.properName',publicParsedNumber?.properName,'Nanpa Watusen');

  const spacedCompleteNumber=facade.parseNumber('12 34');
  check(spacedCompleteNumber===null,'facade','parseNumber.internalWhitespace',spacedCompleteNumber,null);

  const spacedTextParsed=await facade.parse('12 34');
  const spacedTextStructures=(spacedTextParsed.ast.lines||[]).flatMap(line=>line.children||[]).flatMap(seg=>seg.numericStructures||[]);
  check(spacedTextStructures.length===2,'facade','parse.tokenBoundary.count',spacedTextStructures.length,2);
  check(spacedTextStructures.map(item=>item.sourceText).join('|')==='12|34','facade','parse.tokenBoundary.sources',spacedTextStructures.map(item=>item.sourceText).join('|'),'12|34');

  const spacedProperName=facade.parseNumber('Nanpa Wan Eke Tusenan Eke Lunumun');
  check(spacedProperName?.displayValue==='1,234,567','facade','parseNumber.properNameSpaces',spacedProperName?.displayValue,'1,234,567');

  const spacedCartouche=facade.parseNumber('[nanpa : wan tu seli nanpa]',{abbreviateNumericCartouches:true});
  check(spacedCartouche?.displayValue==='123','facade','parseNumber.cartoucheSpaces',spacedCartouche?.displayValue,'123');

  const editedAst=structuredClone(astRoundTripParsed.ast);
  const editedBracket=editedAst.lines.flatMap(line=>line.children||[]).find(seg=>seg.kind==='bracket');
  check(!!editedBracket,'facade','astToText.edit.bracket.present',!!editedBracket,true);
  if(editedBracket) editedBracket.value=' jan  suno,, ';
  const editedText=facade.astToText(editedAst);
  const expectedEditedText='jan   pona [ jan  suno,, ]\n\n“toki pona”';
  check(editedText===expectedEditedText,'facade','astToText.edit.bracket',editedText,expectedEditedText);
  facadeStage='render-edited-canvas';
  const editedCanvas=await facade.renderToCanvas(editedText,{font:'linjaPona'});
  check(Number(editedCanvas.width)>0&&Number(editedCanvas.height)>0,'facade','astToText.edit.renderable',editedCanvas?{w:editedCanvas.width,h:editedCanvas.height}:null,'>0');

  const sentenceSplitSource='jan li pona. ona   li pona.';
  facadeStage='parse-sentence-split';
  const sentenceSplitParsed=await facade.parse(sentenceSplitSource,{parser:{breakLinesAtFullStops:true}});
  check(sentenceSplitParsed.ast.lines.length===2,'facade','astToText.sentenceSplit.lineCount',sentenceSplitParsed.ast.lines.length,2);
  check(facade.astToText(sentenceSplitParsed.ast)===sentenceSplitSource,'facade','astToText.sentenceSplit.roundTrip',facade.astToText(sentenceSplitParsed.ast),sentenceSplitSource);

  const imageSource="jan img(src='x.png', w=20, alt='x') pona";
  facadeStage='parse-image';
  const imageParsed=await facade.parse(imageSource);
  const imageText=facade.astToText(imageParsed.ast);
  facadeStage='reparse-image';
  const imageReparsed=await facade.parse(imageText);
  const imageBefore=imageParsed.ast.lines.flatMap(line=>line.children||[]).find(seg=>seg.kind==='image')?.value||null;
  const imageAfter=imageReparsed.ast.lines.flatMap(line=>line.children||[]).find(seg=>seg.kind==='image')?.value||null;
  check(equal(imageAfter,imageBefore),'facade','astToText.image.semanticRoundTrip',imageAfter,imageBefore);

  const rawUcsurText=facade.astToText({type:'document',lines:[{type:'line',sourceLineIndex:0,children:[{kind:'rawUcsur',cps:[0xF1900,0xF1901]}]}]});
  check(rawUcsurText==='U+F1900 U+F1901','facade','astToText.rawUcsur',rawUcsurText,'U+F1900 U+F1901');

  facadeStage='render-default';
  const canvasResult=await facade.render('12:30');
  check(canvasResult.kind==='canvas','facade','render.default.kind',canvasResult.kind,'canvas');
  check(canvasResult.fontKey==='nasinNanpa','facade','render.default.fontKey',canvasResult.fontKey,'nasinNanpa');
  check(Number(canvasResult.width)>0&&Number(canvasResult.height)>0,'facade','render.default.canvas',canvasResult?{w:canvasResult.width,h:canvasResult.height}:null,'>0');
  check(!!canvasResult.plan,'facade','render.default.plan',!!canvasResult.plan,true);

  facadeStage='linja-pona-plan';
  const lpPlan=await facade.buildRenderPlan('2026-09-13',{font:'linjaPona'});
  const lpCart=cartoucheRuns(lpPlan.plan)[0]||null;
  check(!!lpCart,'facade','linjaPona.plan.cartouche',!!lpCart,true);
  if(lpCart){
    const adapter=String(lpCart.renderAdapterId||lpCart?._element?.renderAdapterId||'identity');
    const rendered=runRenderFullCps(lpCart);
    check(adapter==='linja-pona-legacy-v1','facade','linjaPona.adapter',adapter,'linja-pona-legacy-v1');
    check(rendered.length>0,'facade','linjaPona.rendered.length',rendered.length,'>0');
    const allowedInlineScaleMarkers=new Set([0x00BC,0x2153,0x00BD,0x2154,0x00BE]);
    check(rendered.every(cp=>(cp>=0x20&&cp<=0x7E)||allowedInlineScaleMarkers.has(cp)),'facade','linjaPona.rendered.fontFacingInput',rendered.map(cpLabel),'printable ASCII plus v1.1 inline cartouche scale markers');
  }

  facadeStage='png-export';
  let pngResult; try { pngResult=await facade.renderToPng('123.45',{font:'fairfaxHd'}); } catch(e) { throw new Error('facade PNG export: '+String(e)); }
  const pngHead=Array.from(pngResult.bytes.slice(0,8));
  check(pngResult.kind==='png','facade','png.kind',pngResult.kind,'png');
  check(pngResult.blob.type==='image/png','facade','png.type',pngResult.blob.type,'image/png');
  check(equal(pngHead,[137,80,78,71,13,10,26,10]),'facade','png.signature',pngHead,[137,80,78,71,13,10,26,10]);

  if(globalThis.__NANPA_REAL_VECTOR_WASM_URL__){
    facadeStage='svg-export';
    let svgResult; try { svgResult=await facade.renderToSvg('#ABCDEF',{font:'linjaSike',parser:{enableHexParsing:true}}); } catch(e) { throw new Error('facade SVG export: '+String(e)); }
    check(svgResult.kind==='svg','facade','svg.kind',svgResult.kind,'svg');
    check(String(svgResult.blob.type||'').toLowerCase().startsWith('image/svg+xml'),'facade','svg.type',svgResult.blob.type,'image/svg+xml[; parameters allowed]');
    check(svgResult.svg.includes('<svg'),'facade','svg.payload',svgResult.svg.includes('<svg'),true);
    check(/<path\b/i.test(svgResult.svg),'facade','svg.vectorPaths',/<path\b/i.test(svgResult.svg),true);
    check(!/<image\b/i.test(svgResult.svg),'facade','svg.noRasterImageElement',/<image\b/i.test(svgResult.svg),false);
    check(!/data:image\//i.test(svgResult.svg),'facade','svg.noEmbeddedRasterData',/data:image\//i.test(svgResult.svg),false);

    facadeStage='pdf-export';
    let pdfResult; try { pdfResult=await facade.renderToPdf('0b10101',{font:'nasinNanpa',parser:{enableBinaryParsing:true,enableBinaryRendering:true}}); } catch(e) { throw new Error('facade PDF export: '+String(e)); }
    const pdfHead=new TextDecoder().decode(pdfResult.bytes.slice(0,8));
    check(pdfResult.kind==='pdf','facade','pdf.kind',pdfResult.kind,'pdf');
    check(pdfResult.blob.type==='application/pdf','facade','pdf.type',pdfResult.blob.type,'application/pdf');
    check(pdfHead.startsWith('%PDF-1.'),'facade','pdf.header',pdfHead,'%PDF-1.x');
    const pdfAscii=new TextDecoder('latin1').decode(pdfResult.bytes);
    check(!/\/Subtype\s*\/Image\b/.test(pdfAscii),'facade','pdf.noRasterImageXObject',/\/Subtype\s*\/Image\b/.test(pdfAscii),false);
  } else {
    notes.push('facade SVG/PDF tests skipped: production vector WASM not embedded');
  }

  facadeStage='destroy';
  await facade.destroy();
  } catch(e) { throw new Error(`facade stage ${facadeStage}: ${e?.stack||String(e)}`); }
}

async function runRealVectorGoldens(){
  const manifest=productionManifest();
  if(!manifest?.pairs?.length || !globalThis.__NANPA_REAL_VECTOR_WASM_URL__){ notes.push('production font/vector assets not embedded: SVG golden generation skipped'); return {}; }
  if(globalThis.__NANPA_REAL_VECTOR_WASM_MODULE__?.healthcheck){
    const health=String(globalThis.__NANPA_REAL_VECTOR_WASM_MODULE__.healthcheck());
    check(health.length>0,'vector-wasm','healthcheck',health,'non-empty');
  }
  const registry=presetRegistryFromProduction(manifest); const fx=await loadJson('../fixtures/svg-golden-cases.json'); const output={};
  for(const key of Object.keys(registry)){
    const pair=(manifest.pairs||[]).find(p=>p.fontKey===key)||{}; if(!pairRegressionOptions(pair).vector) continue;
    const fc=createSitelenFontPairController({registry,defaultPresetKey:key,storageKeyPrefix:`nanpaGolden-${key}`}); await fc.ready; fc.setActivePreset(key,{persist:false}); await fc.waitForConfiguredFonts(56); const preset=fc.getActivePreset();
    const parser={mode:preset.parserMode||'sitelen-pona-ascii-extended',numericMode:'uniform',relaxedNanpaLinjanParsing:true,relaxedNanpaLinjanRendering:true,nanpaColonParsing:true,nanpaColonRendering:true,enableHexParsing:true,enableBinaryParsing:true};
    const renderer=await SitelenRenderer.create(fc.buildRendererConfig({preset,baseConfig:{parser}}));
    const exporter=await SitelenVectorExporter.create({renderer,fontController:fc,wasmModuleUrl:globalThis.__NANPA_REAL_VECTOR_WASM_URL__});
    for(const tc of fx.cases){
      const config=fc.buildRendererConfig({preset,baseConfig:{layout:{fontPx:tc.fontPx},parser}});
      const blob=await exporter.exportTextToSvgBlob({input:tc.input,config,paddingPx:8});
      const svg=(await blob.text()).replace(/\r\n/g,'\n').trim()+'\n';
      const vectorId=`svg-vector:${key}--${tc.id}`;
      check(/<path\b/i.test(svg),vectorId,'containsPath',/<path\b/i.test(svg),true);
      check(!/<image\b/i.test(svg),vectorId,'noRasterImageElement',/<image\b/i.test(svg),false);
      check(!/data:image\//i.test(svg),vectorId,'noEmbeddedRasterData',/data:image\//i.test(svg),false);
      output[`${key}--${tc.id}`]=svg;
    }
    fc.destroy();
  }
  return output;
}


async function runCanonicalSyntaxCases(){
  const data=await loadJson('../conformance/canonical-syntax-v1.0.1-phase1/cases.json');
  const renderer=await SitelenRenderer.create({});
  const adapters={linjaPona:'linja-pona-legacy-v1',linjaSike:'linja-sike-legacy-v1'};
  const cps=(values)=>(values||[]).map(v=>typeof v==='string'&&/^U\+/i.test(v)?Number.parseInt(v.slice(2),16):Number(v));
  let casePass=0,adapterPass=0;
  for(const tc of data.cases||[]){
    const before=failures.length;
    try{
      const plan=await renderer.buildRenderPlan({input:tc.input,parser:{mode:tc.rendererMode}});
      const runs=flattenRuns(plan);
      if('expectedNormalizedInput' in tc) check(plan.ast?.normalizedInput===tc.expectedNormalizedInput,`canonical-syntax:${tc.id}`,'normalizedInput',plan.ast?.normalizedInput,tc.expectedNormalizedInput);
      if(tc.expectedRuns){
        const got=runs.map(r=>r.canonicalCps||[]), want=tc.expectedRuns.map(cps);
        check(equal(got,want),`canonical-syntax:${tc.id}`,'runs.canonicalCps',got,want);
      } else {
        check(runs.length===1,`canonical-syntax:${tc.id}`,'runCount',runs.length,1);
        if(runs.length===1){
          const r=runs[0],want=cps(tc.expectedCanonicalCodepoints);
          check(equal(r.canonicalCps||[],want),`canonical-syntax:${tc.id}`,'canonicalCps',r.canonicalCps||[],want);
          if('expectedSourceText' in tc) check((r.sourceText??'')===tc.expectedSourceText,`canonical-syntax:${tc.id}`,'sourceText',r.sourceText??'',tc.expectedSourceText);
          if('expectedFontRole' in tc) check(r.fontRole===tc.expectedFontRole,`canonical-syntax:${tc.id}`,'fontRole',r.fontRole,tc.expectedFontRole);
          if('expectedRenderText' in tc){
            const wantText=/^U\+/i.test(String(tc.expectedRenderText))?String.fromCodePoint(...cps([tc.expectedRenderText])):tc.expectedRenderText;
            check((r.encodedText??'')===wantText,`canonical-syntax:${tc.id}`,'encodedText',r.encodedText??'',wantText);
          }
        }
      }
    }catch(e){failures.push({id:`canonical-syntax:${tc.id}`,field:'exception',actual:e?.stack||String(e),expected:'no exception'});}
    if(failures.length===before)casePass++;
  }
  for(const tc of data.fontAdapterCases||[]){
    const before=failures.length;
    try{
      const plan=await renderer.buildRenderPlan({input:tc.input,parser:{mode:'sitelen-pona-ascii-extended'},fonts:{renderAdapterId:adapters[tc.font]||'identity'}});
      const runs=flattenRuns(plan);
      check(runs.length===1,`canonical-adapter:${tc.id}`,'runCount',runs.length,1);
      if(runs.length===1){
        const r=runs[0];
        const renderText=r.renderCps?String.fromCodePoint(...r.renderCps):(r.encodedText??'');
        if('expectedRenderText' in tc)check(renderText===tc.expectedRenderText,`canonical-adapter:${tc.id}`,'renderText',renderText,tc.expectedRenderText);
        if('expectedRenderCodepoints' in tc)check(equal(r.renderCps||[],cps(tc.expectedRenderCodepoints)),`canonical-adapter:${tc.id}`,'renderCps',r.renderCps||[],cps(tc.expectedRenderCodepoints));
        if(tc.mustDifferFromCanonicalCodepoints)check(!equal(r.renderCps||[],r.canonicalCps||[]),`canonical-adapter:${tc.id}`,'differsFromCanonical',r.renderCps||[],'different from canonicalCps');
      }
    }catch(e){failures.push({id:`canonical-adapter:${tc.id}`,field:'exception',actual:e?.stack||String(e),expected:'no exception'});}
    if(failures.length===before)adapterPass++;
  }
  notes.push(`canonical syntax: ${casePass}/${data.cases?.length||0} cases PASS; font adapters: ${adapterPass}/${data.fontAdapterCases?.length||0} PASS`);
}

function canonicalCompareAst(actual,expected){
  const errors=[];
  if(!actual||typeof actual!=='object')return ['AST missing'];
  if(actual.type!==expected?.type)errors.push(`type got ${JSON.stringify(actual.type)} want ${JSON.stringify(expected?.type)}`);
  if(actual.normalizedInput!==expected?.normalizedInput)errors.push(`normalizedInput got ${JSON.stringify(actual.normalizedInput)} want ${JSON.stringify(expected?.normalizedInput)}`);
  const al=Array.isArray(actual.lines)?actual.lines:[],el=Array.isArray(expected?.lines)?expected.lines:[];
  if(al.length!==el.length)return [...errors,`line count got ${al.length} want ${el.length}`];
  for(let i=0;i<al.length;i++){
    for(const key of ['index','sourceLineIndex','sentenceIndexInSourceLine','sourceText'])if(al[i]?.[key]!==el[i]?.[key])errors.push(`line[${i}] ${key} got ${JSON.stringify(al[i]?.[key])} want ${JSON.stringify(el[i]?.[key])}`);
    const ac=Array.isArray(al[i]?.children)?al[i].children:[],ec=Array.isArray(el[i]?.children)?el[i].children:[];
    if(ac.length!==ec.length){errors.push(`line[${i}] child count got ${ac.length} want ${ec.length}`);continue;}
    for(let j=0;j<ac.length;j++){
      for(const key of ['kind','openQuote','closeQuote']){const av=ac[j]?.[key]??null,ev=ec[j]?.[key]??null;if(av!==ev)errors.push(`line[${i}] child[${j}] ${key} got ${JSON.stringify(av)} want ${JSON.stringify(ev)}`);}
      const actualValue=ac[j]?.kind==='image'?null:(ac[j]?.value??null),expectedValue=ec[j]?.value??null;
      if(actualValue!==expectedValue)errors.push(`line[${i}] child[${j}] value got ${JSON.stringify(actualValue)} want ${JSON.stringify(expectedValue)}`);
      const ai=ac[j]?.image??ac[j]?.value,ei=ec[j]?.image;
      if(ei!=null){
        if(!ai||typeof ai!=='object'){errors.push(`line[${i}] child[${j}] missing image`);continue;}
        for(const key of ['src','w','h','alt','valign','wriggle','transparent'])if((ai?.[key]??null)!==(ei?.[key]??null))errors.push(`line[${i}] child[${j}] image.${key} got ${JSON.stringify(ai?.[key]??null)} want ${JSON.stringify(ei?.[key]??null)}`);
      }
    }
  }
  return errors;
}
function canonicalCompareRun(actual,expected,randomCps){
  const errors=[];
  const pairs=[
    ['kind',actual?.kind,expected?.kind],['renderMode',actual?.renderMode,expected?.renderMode],['fontRole',actual?.fontRole,expected?.fontRole],
    ['sourceText',actual?.sourceText??'',expected?.sourceText??''],['sourceKind',actual?.sourceKind??'',expected?.sourceKind??''],
    ['renderAdapterId',actual?.renderAdapterId??'',expected?.renderAdapterId??''],['requestedRenderAdapterId',actual?.requestedRenderAdapterId??'',expected?.requestedRenderAdapterId??''],
    ['isQuoted',Boolean(actual?.isQuoted),Boolean(expected?.isQuoted)],['interpretedQuote',Boolean(actual?.interpretedQuote),Boolean(expected?.interpretedQuote)],
    ['isUnrecognized',Boolean(actual?.isUnrecognized),Boolean(expected?.isUnrecognized)],['manualTallies',actual?.manualTallies??null,expected?.manualTallies??null],
    ['isNumericCartouche',Boolean(actual?._element?.isNumericCartouche),Boolean(expected?.isNumericCartouche)],['isLiteralCartouche',Boolean(actual?._element?.isLiteralCartouche),Boolean(expected?.isLiteralCartouche)],
    ['imageAlt',actual?.imageAlt??null,expected?.imageAlt??null],['encodedText',actual?.encodedText??null,expected?.encodedText??null],
  ];
  if(!randomCps)pairs.push(['canonicalCps',actual?.canonicalCps||[],expected?.canonicalCps||[]],['canonicalFullCps',actual?.canonicalFullCps||[],expected?.canonicalFullCps||[]],['renderCps',actual?.renderCps||[],expected?.renderCps||[]]);
  for(const [key,av,ev] of pairs)if(!equal(av,ev))errors.push(`${key}: got ${JSON.stringify(av)} want ${JSON.stringify(ev)}`);
  return errors;
}
async function runCanonicalFullRendererCases(){
  const data=await loadJson('../conformance/full-renderer-canonical-v1.1.0/cases.json');
  const adapters={nasinNanpa:'identity',sitelenSeliKiwen:'identity',fairfaxHd:'identity',fairfaxPonaHd:'identity',linjaPona:'linja-pona-legacy-v1',linjaSike:'linja-sike-legacy-v1',nasinSitelenPuMono:'nasin-sitelen-pu-mono-v1',linjaLipamanka:'linja-lipamanka-v1'};
  check(data.caseCount===data.cases?.length,'canonical-full','declaredCaseCount',data.caseCount,data.cases?.length);
  const renderer=await SitelenRenderer.create({});
  let passed=0;
  for(const tc of data.cases||[]){
    const before=failures.length;
    try{
      if(!tc.oracle?.ok){failures.push({id:`canonical-full:${tc.id}`,field:'oracle',actual:tc.oracle?.error,expected:'ok'});}
      else{
        const plan=await renderer.buildRenderPlan({input:tc.input,parser:tc.parser,fonts:{renderAdapterId:adapters[tc.font]||'identity'}});
        if(tc.compareAst)for(const msg of canonicalCompareAst(plan.ast,tc.oracle.ast))failures.push({id:`canonical-full:${tc.id}`,field:'AST',actual:msg,expected:'match oracle'});
        const ar=flattenRuns(plan),er=Array.isArray(tc.oracle.runs)?tc.oracle.runs:[];
        if(ar.length!==er.length)failures.push({id:`canonical-full:${tc.id}`,field:'runCount',actual:ar.length,expected:er.length});
        else for(let i=0;i<ar.length;i++)for(const msg of canonicalCompareRun(ar[i],er[i],Boolean(tc.randomCps)))failures.push({id:`canonical-full:${tc.id}`,field:`run[${i}]`,actual:msg,expected:'match oracle'});
      }
    }catch(e){failures.push({id:`canonical-full:${tc.id}`,field:'exception',actual:e?.stack||String(e),expected:'no exception'});}
    checks++;
    if(failures.length===before)passed++;
  }
  notes.push(`canonical full renderer: ${passed}/${data.cases?.length||0} cases PASS`);
}

async function main(){
  let currentStage='startup';
  try {
    if(mode==='core' || mode==='all'){ currentStage='renderer-cases'; await runRendererCases(); currentStage='font-controller-cases'; await runControllerCases(); currentStage='vector-mock-cases'; await runVectorMockCases(); currentStage='facade-cases'; await runFacadeCases(); }
    if(mode==='canonical-syntax' || mode==='all'){ currentStage='canonical-syntax'; await runCanonicalSyntaxCases(); }
    if(mode==='canonical-full' || mode==='all'){ currentStage='canonical-full'; await runCanonicalFullRendererCases(); }
    if(mode==='fonts' || mode==='all'){ currentStage='asset-fonts'; await runAssetFontTests(); }
    let artifacts={}; if(mode==='svg-goldens'){ currentStage='svg-goldens'; artifacts=await runRealVectorGoldens(); }
    const result={status:failures.length?'FAIL':'PASS',mode,checks,failures,notes,artifacts};
    human.textContent=`${result.status}: ${checks} checks, ${failures.length} failures\n`+failures.map(f=>`${f.id} ${f.field}: ${JSON.stringify(f.actual)} != ${JSON.stringify(f.expected)}`).join('\n')+(notes.length?'\n'+notes.join('\n'):'');
    resultEl.textContent=btoa(unescape(encodeURIComponent(JSON.stringify(result)))); document.documentElement.dataset.nanpaStatus=result.status; document.title=`nanpa ${result.status}`;
  } catch(e){ const result={status:'ERROR',mode,checks,failures:[...failures,{id:`harness:${currentStage}`,field:'exception',actual:e?.stack||String(e),expected:'no exception'}],notes,artifacts:{}}; human.textContent=result.failures.at(-1).actual; resultEl.textContent=btoa(unescape(encodeURIComponent(JSON.stringify(result)))); document.documentElement.dataset.nanpaStatus='ERROR'; document.title='nanpa ERROR'; }
}
await main();
