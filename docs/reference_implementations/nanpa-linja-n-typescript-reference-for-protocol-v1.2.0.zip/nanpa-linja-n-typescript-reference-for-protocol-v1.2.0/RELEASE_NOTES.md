# Release notes — TypeScript reference for Protocol v1.2.0

This release updates the TypeScript Protocol-v1.1.0 reference to the Protocol-v1.2.0 parser/renderer behavior while preserving the existing API and unrelated implementation work.

Changes required by v1.2:

- canonical JavaScript parser/renderer updated to the supplied v1.2 authority;
- ordinary ASCII full stop now follows v1.2 middle-dot semantics without affecting decimal or literal full stops;
- directly pasted recognized CSP/UCSUR document input is normalized through the existing parser and retains original/canonical AST source metadata;
- quote closing now uses odd/even consecutive-backslash parity;
- `DocumentAstLine` types `canonicalSourceText` and `sourceEncoding`;
- the 24-case v1.2 parser/renderer corpus is included and executed by the TypeScript qualification runner;
- canonical full-renderer expectation updated only for the required middle-dot behavior;
- supplied current `fonts.zip` replaces the v1.1 resource bundle and is unpacked exactly under `runtime/assets/fonts/`.

Unchanged by this migration:

- 35-operation `NanpaParser` Core surface and numeric semantics;
- public TypeScript method signatures and package entry points;
- font controller;
- vector exporter;
- advanced runtime module;
- vector WASM;
- render-adapter IDs/contracts and vector-quality requirements.
