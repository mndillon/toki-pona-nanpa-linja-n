#!/usr/bin/env node
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { runInBrowserWithCanonicalRenderer } from './lib/browser-renderer-harness.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const corpusPath = path.join(root, 'protocol/conformance/parser-renderer-regression-v1.2.0.json');
const dataText = await fs.readFile(corpusPath, 'utf8');
const data = JSON.parse(dataText);
if (data.protocolVersion !== '1.2.0' || data.caseCount !== 24 || data.cases?.length !== 24) {
  throw new Error(`Invalid Protocol v1.2 regression corpus inventory: ${data.protocolVersion} ${data.caseCount}/${data.cases?.length ?? 0}`);
}
const payload = Buffer.from(dataText, 'utf8').toString('base64');
const result = await runInBrowserWithCanonicalRenderer(root, `(async()=>{
  const data=JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(${JSON.stringify(payload)}),c=>c.charCodeAt(0))));
  const failures=[]; let passed=0;
  const equal=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
  const cpLabel=cp=>'U+'+Number(cp).toString(16).toUpperCase().padStart(4,'0');
  function cleanAst(ast){
    const lines=[];
    for(const line of ast?.lines||[]){
      const item={sourceText:line?.sourceText??'',segments:(line?.children||[]).map(s=>({kind:s?.kind??null,value:s?.value??null}))};
      if(Object.prototype.hasOwnProperty.call(line||{},'canonicalSourceText')) item.canonicalSourceText=line.canonicalSourceText;
      if(Object.prototype.hasOwnProperty.call(line||{},'sourceEncoding')) item.sourceEncoding=line.sourceEncoding;
      lines.push(item);
    }
    return {normalizedInput:ast?.normalizedInput??'',lineCount:lines.length,lines};
  }
  function semanticSummary(lines){
    const result=[];
    for(const els of lines||[]){
      const canonicalCodepoints=[],literalTexts=[],cartoucheClasses=[],elementKinds=[];
      for(const e of els||[]){
        if(e?.type==='gap') continue;
        elementKinds.push(e?.type??null);
        if(e?.type==='text') literalTexts.push(e?.text??'');
        if(e?.type==='cartouche') cartoucheClasses.push(e?.isLiteralCartouche?'literal':(e?.fontRole==='number'?'number':'ordinary'));
        const arr=Array.isArray(e?.canonicalCps)?e.canonicalCps:(Array.isArray(e?.cps)?e.cps:(e?.cp!=null?[e.cp]:null));
        if(arr?.length) canonicalCodepoints.push(...arr.map(cpLabel));
      }
      result.push({elementKinds,canonicalCodepoints,literalTexts,cartoucheClasses});
    }
    return result;
  }
  for(const tc of data.cases||[]){
    const errors=[];
    try{
      const parser=tc.parserOptions||{};
      const renderer=await globalThis.SitelenRenderer.create({parser});
      const parsed=await renderer.parseInput({input:tc.input,parser});
      const plan=await renderer.buildRenderPlan({input:tc.input,parser,layout:{fontPx:32}});
      const gotAst=cleanAst(parsed.ast);
      const gotSemantic=semanticSummary(plan.linesElements||[]);
      if(!equal(gotAst,tc.expected?.ast)) errors.push('ast '+JSON.stringify(gotAst));
      if(!equal(gotSemantic,tc.expected?.semantic)) errors.push('semantic '+JSON.stringify(gotSemantic));
      if(tc.expected&&Object.prototype.hasOwnProperty.call(tc.expected,'equivalentCanonicalInput')){
        const eq=await renderer.buildRenderPlan({input:tc.expected.equivalentCanonicalInput,parser,layout:{fontPx:32}});
        const eqSemantic=semanticSummary(eq.linesElements||[]);
        if(!equal(eqSemantic,gotSemantic)) errors.push('equivalentCanonicalInput '+JSON.stringify(eqSemantic));
      }
    }catch(e){errors.push(String(e?.stack||e));}
    if(errors.length) failures.push({id:tc.id,errors}); else passed++;
  }
  return {passed,total:data.cases.length,failures};
})()`, { timeoutMs: 240000 });

console.log(`TypeScript Protocol v1.2 parser/renderer regression: ${result.passed}/${result.total} PASS`);
if (result.failures?.length) {
  console.error(`FAILED CASES (${result.failures.length}):`);
  for (const item of result.failures) console.error(`[${item.id}] ${item.errors.join('; ')}`);
  process.exit(1);
}
