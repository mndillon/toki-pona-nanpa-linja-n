# nanpa-linja-n TypeScript reference implementation — Protocol v1.2.0

Version: **1.2.0**  
Protocol target: **nanpa-linja-n Protocol v1.2.0**  
Runtime requirement: **Node.js 20+** for the supplied qualification tooling.

This package is the strongly typed TypeScript facade over the exact canonical JavaScript parser/renderer used by the Protocol v1.2.0 JavaScript reference implementation. TypeScript supplies declarations, typed wrappers, runtime validation, package entry points, and TypeScript-specific conformance tests; parser/rendering semantics remain implemented by the bundled canonical JavaScript.

## Protocol v1.2.0 behavior

The v1.1 defaults and Core-v1 numeric semantics are unchanged. The bundled default parser configuration remains:

```ts
{
  mode: "sitelen-pona-ascii-extended",
  numericMode: "uniform",
  relaxedNanpaLinjanParsing: true,
  relaxedNanpaLinjanRendering: true,
  nanpaColonParsing: true,
  nanpaColonRendering: true,
  abbreviateNumericCartouches: true,
  preserveNumericCartoucheBreaksInAbbreviation: false,
  breakLinesAtFullStops: false,
  interpretDoubleQuotesAsTeTo: false,
  numericCartoucheStartGlyph: null,
  enableHexParsing: false,
  enableBinaryParsing: false,
  enableBinaryRendering: false,
  nasinNanpaPona: false
}
```

Protocol v1.2 adds three parser behaviors to the v1.1 surface:

- ordinary ASCII full stop `.` is tokenized as sitelen pona middle dot U+F199C, including when adjacent to words and inside ordinary cartouches; literal quotes/cartouches retain literal U+002E and recognized decimals such as `1.25` remain numeric;
- recognized directly pasted Common Sitelen Pona/UCSUR document input is canonicalized into the existing parser syntax before normal parsing, while the original source is retained and affected AST lines expose `canonicalSourceText` plus `sourceEncoding: "mixed-csp-unicode"`;
- quote closing uses consecutive-backslash parity: an odd run of backslashes escapes a quote and an even run allows it to close.

Explicit textual `U+...` input and dedicated raw-UCSUR rendering paths remain raw and do not use the new document-input canonicalizer.

The typed facade continues to expose:

- the frozen 35-operation `NanpaParser` API;
- `parseNumber()` and `astToText()` numeric transformations;
- `numericOutput: "source" | "properName" | "#~" | "cartouche"`;
- abbreviated numeric cartouches by default, with explicit full-cartouche output available;
- strict digit-token whitespace boundaries;
- standard and extended sitelen pona ASCII parser modes;
- `&`, `-`, and `+` compound operators;
- optional quote interpretation through `interpretDoubleQuotesAsTeTo`;
- opt-in hexadecimal and binary parsing/rendering;
- date/time semantic openers and numeric-cartouche start-glyph control;
- public font render adapters with canonical-to-render mappings;
- per-font vulgar-fraction cartouche scaling;
- PNG raster export plus vector SVG/PDF export.

The legacy automatic `ss12`/`ss13`/`ss14` cartouche-scaling route remains inactive.

## Main TypeScript API

```ts
import {
  NanpaLinjaN,
  NanpaParser,
  astToText,
  parseNumber,
  type NanpaParserOptions,
  type FontRenderAdapter,
} from "nanpa-linja-n-typescript";

const parsedNumber = parseNumber("123");
console.log(parsedNumber?.properName); // Nanpa Watusen

const nanpa = await NanpaLinjaN.create();
const parsed = await nanpa.parse("toki&pona 123");

console.log(nanpa.astToText(parsed.ast, {
  numericOutput: "properName",
}));

const png = await nanpa.renderToPng("123", {
  font: "linjaPona",
  fontSize: 56,
});

await nanpa.destroy();
```

### Direct CSP/UCSUR input metadata

`DocumentAstLine` now types the v1.2 metadata emitted when recognized direct CSP/UCSUR input is canonicalized:

```ts
const parsed = await nanpa.parse("󱤴󱤖󱥡󱤧󱥬‍󱥔");
const line = parsed.ast.lines[0];

console.log(line.sourceText);          // original UCSUR input
console.log(line.canonicalSourceText); // "mi kama sona li toki&pona"
console.log(line.sourceEncoding);      // "mixed-csp-unicode"
```

### `parseNumber()` and `astToText()`

The numeric API and defaults are unchanged from v1.1:

```ts
parseNumber("123");
parseNumber("#ABC", { enableHexParsing: true });
parseNumber("0b10101", {
  enableBinaryParsing: true,
  enableBinaryRendering: true,
});
```

Hexadecimal and binary recognition remain **off by default**. The default `numericOutput: "cartouche"` serialization remains abbreviated.

## Render adapters

The built-in adapter IDs are unchanged:

- `identity`
- `linja-pona-legacy-v1`
- `linja-sike-legacy-v1`
- `nasin-sitelen-pu-mono-v1`
- `linja-lipamanka-v1`

The font controller and vector exporter are retained byte-for-byte from v1.1 because Protocol v1.2 does not change their contracts.

## Production fonts

The exact supplied `fonts.zip` is preserved at:

```text
resources/fonts.zip
```

SHA-256:

```text
50c0375469508e806d2a6bb1ce555fa81adb72f73a497ddf7d26e4150671b209
```

The runtime consumes an exact unpacked copy under `runtime/assets/fonts/`, including the new source-input font resource:

```text
nanpa-linja-n-nasin-nanpa-sans-source-input-unchanged.ttf
```

The runtime production manifest SHA-256 is:

```text
d8021c7e83d33b776a1e68c70d6adea11956ae88e5fff1baf67926dd1d6833f6
```

It contains the same eight production font-pair keys and the same parser-mode/render-adapter contract required by Protocol v1.2.

## Package entry points

```text
nanpa-linja-n-typescript
nanpa-linja-n-typescript/runtime
nanpa-linja-n-typescript/advanced
nanpa-linja-n-typescript/reference/renderer
nanpa-linja-n-typescript/reference/font-controller
nanpa-linja-n-typescript/reference/vector-exporter
```

## Build and test

```bash
npm test
```

The consolidated runner executes all configured suites and writes:

```text
test-output/typescript-regression-report.txt
```

Useful individual commands:

```bash
npm run build
npm run typecheck
npm run test:types
npm run verify:runtime
npm run test:exports
npm run test:unit
npm run test:ast
npm run test:profile
npm run test:parser-v1.2
npm run test:fonts
npm run test:protocol
npm run test:canonical-syntax
npm run test:canonical-renderer
npm run test:browser
```

The v1.2 parser suite contains **24 cases**: 10 full-stop, 12 direct-CSP/UCSUR, and 2 quote-escape cases.

## Vector-output requirement

The browser qualification checks that generated numeric SVG contains vector `<path>` output with no `<image>`/`data:image` raster fallback. Generated PDF is checked for a `%PDF-1.x` signature and absence of `/Subtype /Image` raster Image XObjects in the tested output.

## Canonical bundled hashes

```text
canonical renderer:
6bfcb77e5177eec4d923bbd24d60dbac211e574b62e128e6dbfc07f8e859d220

JavaScript facade:
58c3c24f5d1963b08678778f10421616b369159d4bbbbf6f44e0308e9a35f8fe

font controller:
7829a6d174126cd5df67448cf6b47219c13121c965674e65fd237c7c2d8c42c0

vector exporter:
601ceafe5ce0f7b8919b23e027e636e3f7b5a0121b24fb9aeb7d6eea8c0d3b39

runtime production manifest:
d8021c7e83d33b776a1e68c70d6adea11956ae88e5fff1baf67926dd1d6833f6

fonts.zip:
50c0375469508e806d2a6bb1ce555fa81adb72f73a497ddf7d26e4150671b209
```

## Protocol documents

The package includes the v1.2 protocol/profile material used for qualification:

```text
protocol/protocol.json
protocol/SPEC.md
protocol/MIGRATION-v1.1-to-v1.2.md
protocol/conformance/parser-renderer-profile-v1.2.0.json
protocol/conformance/parser-renderer-regression-v1.2.0.json
protocol/conformance/parser-renderer-regression-v1.2.0.schema.json
```
