# Testing the TypeScript Protocol v1.2.0 reference

## Full qualification

```bash
npm test
```

The runner attempts all suites even if an earlier suite fails. The consolidated report is:

```text
test-output/typescript-regression-report.txt
```

## Individual suites

```bash
npm run build
npm run typecheck
npm run test:types
npm run verify:runtime
npm run test:exports
npm run test:unit
npm run test:ast
npm run test:profile
npm run test:parser-v1.2
npm run test:fonts
npm run test:protocol
npm run test:canonical-syntax
npm run test:canonical-renderer
npm run test:browser
```

`test:parser-v1.2` runs the 24-case Protocol-v1.2 corpus: 10 full-stop cases, 12 direct CSP/UCSUR cases, and 2 quote-escape cases.

`test:browser` requires Chromium/Chrome discoverable by the supplied browser helper. It exercises the compiled TypeScript facade with real font loading, canvas/PNG output, production render adapters, SVG/PDF vector export, AST editing/serialization, `parseNumber`, and end-to-end v1.2 full-stop/direct-UCSUR/literal-full-stop smoke checks.

For release verification, test the actual packaged ZIP from a fresh extraction rather than relying only on the working tree.
