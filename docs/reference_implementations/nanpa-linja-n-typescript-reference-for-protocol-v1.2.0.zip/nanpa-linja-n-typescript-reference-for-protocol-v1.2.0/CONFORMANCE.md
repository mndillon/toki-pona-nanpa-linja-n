# TypeScript conformance — nanpa-linja-n Protocol v1.2.0

The TypeScript reference is a typed facade over the exact canonical JavaScript v1.2.0 behavioral implementation. Conformance therefore verifies both the pinned JavaScript runtime and the TypeScript declarations/wrappers around it.

## Qualification command

```bash
npm test
```

The consolidated runner is non-fail-fast and writes `test-output/typescript-regression-report.txt`.

## Qualified result

The v1.2 release qualification completes with **13/13 suites passing**:

1. TypeScript build — PASS.
2. Bundled canonical JavaScript runtime/resource integrity — PASS.
3. TypeScript declaration/type surface — PASS.
4. Typed wrapper export identity/parity — PASS.
5. Typed facade unit tests — PASS.
6. `astToText` regression — **26/26 PASS**.
7. Protocol v1.2.0 integrated profile — **91 checks PASS**, including **16/16 NanpaParser smoke cases**, **24/24 regression-corpus inventory**, and **8/8 font-pair behavioral invariants**.
8. Protocol v1.2 parser/renderer regression — **24/24 PASS**.
9. Production font resources — **8/8 pairs PASS**, **25 runtime font byte checks PASS**.
10. Frozen Core-v1 parser/API regression — **1030 checks PASS**.
11. Canonical syntax — **28/28 PASS**; font-adapter cases — **5/5 PASS**.
12. Canonical full-renderer semantic corpus — **254/254 PASS**.
13. Real browser production facade/output regression — PASS, including **19/19 integration checks**.

## v1.2-specific conformance

The new 24-case corpus verifies:

- ASCII full-stop → canonical U+F199C in ordinary text and ordinary cartouches;
- decimal precedence and literal full-stop preservation;
- direct CSP/UCSUR word, joiner, cartouche, punctuation, spacing, corner, alternate-glyph, and long-glyph normalization;
- original-source preservation with `canonicalSourceText` and `sourceEncoding: "mixed-csp-unicode"`;
- unrecognized trigger-range no-op behavior;
- odd/even consecutive-backslash quote-closing parity.

The TypeScript `DocumentAstLine` declaration explicitly types the two new AST metadata fields.

## Regression boundary

The migration retains:

- the frozen 35-operation Core-v1 `NanpaParser` surface;
- numeric syllables and number semantics;
- digit-whitespace rules;
- numeric-cartouche defaults;
- render-adapter IDs/contracts;
- font controller and vector exporter behavior;
- SVG/PDF vector-output requirements.

The canonical full-renderer corpus changes only the expected middle-dot behavior required by v1.2.

## Current pinned hashes

```text
runtime/src/nanpa-linja-n.js
58c3c24f5d1963b08678778f10421616b369159d4bbbbf6f44e0308e9a35f8fe

runtime/reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js
6bfcb77e5177eec4d923bbd24d60dbac211e574b62e128e6dbfc07f8e859d220

runtime/reference/sitelen-font-pair-controller.js
7829a6d174126cd5df67448cf6b47219c13121c965674e65fd237c7c2d8c42c0

runtime/reference/sitelen-vector-exporter.js
601ceafe5ce0f7b8919b23e027e636e3f7b5a0121b24fb9aeb7d6eea8c0d3b39

runtime/assets/fonts/preloaded-font-pairs.manifest.json
d8021c7e83d33b776a1e68c70d6adea11956ae88e5fff1baf67926dd1d6833f6

resources/fonts.zip
50c0375469508e806d2a6bb1ce555fa81adb72f73a497ddf7d26e4150671b209
```
