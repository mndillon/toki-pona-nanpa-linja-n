#!/usr/bin/env python3
"""Offline Protocol-v1.2 source/asset validation for the Rust reference."""
import hashlib,json,pathlib,sys,zipfile,re
ROOT=pathlib.Path(__file__).resolve().parents[1]
FAIL=[]; CHECKS=0
def check(ok,msg):
 global CHECKS; CHECKS+=1
 print(('PASS' if ok else 'FAIL'),msg)
 if not ok: FAIL.append(msg)
# Frozen Core source hashes.
core=json.loads((ROOT/'fixtures/core-v1-source-sha256.json').read_text())['files']
for rel,expected in core.items():
 p=ROOT/rel; actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
 check(actual==expected,f'Core source unchanged {rel}')
# Current authorities.
auth={
 'reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js':'6bfcb77e5177eec4d923bbd24d60dbac211e574b62e128e6dbfc07f8e859d220',
 'resources/fonts.zip':'50c0375469508e806d2a6bb1ce555fa81adb72f73a497ddf7d26e4150671b209',
 'conformance/parser-renderer-profile-v1.2.0.json':'62d96529a5d857d6e146afc29433caf8709e9e28803e95d37ff3085468080a0f',
 'fixtures/production-font-pairs.manifest-v1.1.0.json':'d8021c7e83d33b776a1e68c70d6adea11956ae88e5fff1baf67926dd1d6833f6',
}
for rel,expected in auth.items():
 p=ROOT/rel; actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
 check(actual==expected,f'current authority SHA-256 {rel}')
# Font bundle / production manifest.
with zipfile.ZipFile(ROOT/'resources/fonts.zip') as zf:
 names=set(zf.namelist()); raw=zf.read('fonts/preloaded-font-pairs.manifest.json'); manifest=json.loads(raw)
 check(hashlib.sha256(raw).hexdigest()==auth['fixtures/production-font-pairs.manifest-v1.1.0.json'],'embedded production font manifest SHA-256')
 pairs=manifest.get('pairs') or []
 check(len(pairs)==8,'production font manifest has 8 pairs')
 adapters=[]
 for p in pairs:
  adapters.append(p.get('renderAdapterId') or 'identity')
  check(p.get('settings',{}).get('cartoucheVulgarFractions') is True,f"{p.get('fontKey')}: inline vulgar scaling enabled")
  check(p.get('settings',{}).get('emulateLegacyCartoucheScaling') is False,f"{p.get('fontKey')}: legacy scaling disabled")
  for k in ('baseFilename','companionFilename'):
   check('fonts/'+p[k] in names,f"{p.get('fontKey')}: {k} present")
 check(set(adapters)=={'identity','linja-pona-legacy-v1','linja-sike-legacy-v1','nasin-sitelen-pu-mono-v1','linja-lipamanka-v1'},'five production adapter IDs')
# v1.1 fixtures.
for rel,key,want in [
 ('fixtures/font-golden-cases-v1.1.0.json','cases',16),
 ('fixtures/render-facade-plan-goldens-v1.1.0.json','cases',16),
 ('conformance/full-renderer-canonical-v1.2.0/cases.json','cases',254),
 ('conformance/parser-renderer-regression-v1.2.0.json','cases',24),
]:
 d=json.loads((ROOT/rel).read_text());check(len(d.get(key,[]))==want,f'{rel}: {want} cases')
# Production source invariants.
src='\n'.join((ROOT/'src'/n).read_text() for n in ('facade.rs','font_adapters.rs','full_adapter.rs','full_renderer.rs','full_types.rs','public_parser.rs','v11_numeric.rs'))
check('ss12' not in src and 'ss13' not in src and 'ss14' not in src,'no active ss12/ss13/ss14 production feature strings')
check('ttf-parser = "=0.25.1"' in (ROOT/'Cargo.toml').read_text(),'ttf-parser pinned for vector outlines')
check('/Subtype /Image' not in (ROOT/'src/full_renderer.rs').read_text(),'Rust PDF source has no raster Image XObject')
check('vector_pdf(&self.prepare_full(input,options)?)' in (ROOT/'src/full_renderer.rs').read_text(),'render_full_to_pdf routes to vector PDF')
check('svg_text_paths(&g.text' in (ROOT/'src/full_renderer.rs').read_text(),'numeric SVG emits shaped glyph outline paths')
check('normalize_v11_abbreviated_words' in (ROOT/'src/full_document.rs').read_text(),'astToText uses v1.1 abbreviated normalization')
check('full-renderer-canonical-v1.2.0/cases.json' in (ROOT/'tests/canonical_full_renderer.rs').read_text(),'canonical full-renderer test targets v1.2 corpus')
check('parser-renderer-regression-v1.2.0.json' in (ROOT/'tests/v1_2_parser.rs').read_text(),'v1.2 parser regression test targets normative corpus')
check('canonical_source_text: Option<String>' in (ROOT/'src/full_types.rs').read_text(),'AST exposes canonical source metadata')
check('source_encoding: Option<String>' in (ROOT/'src/full_types.rs').read_text(),'AST exposes source encoding metadata')
check('canonicalize_csp_unicode_input_line' in (ROOT/'src/full_document.rs').read_text(),'direct CSP/UCSUR canonicalization is wired')
check('is_backslash_escaped_at' in (ROOT/'src/full_document.rs').read_text(),'quote-close parity helper is wired')
check("else if c==','{Some(',' as u32)}" in (ROOT/'src/full_renderer.rs').read_text(),'outside-cartouche ASCII comma is preserved')
check("if c==','{logical.run.kind=\"run\".into();}" in (ROOT/'src/full_renderer.rs').read_text(),'outside-cartouche ASCII comma uses canonical run kind')
check('fonts/nanpa-linja-n-nasin-nanpa-sans-literal.ttf' in names,'current literal-cartouche font is bundled')
check('scale_markers: Vec<u32>' in (ROOT/'src/full_adapter.rs').read_text(),'ordinary cartouche carries scale-marker ownership')
for alias in ('"1/4"','"1/3"','"1/2"','"2/3"','"3/4"'):
 check(alias in (ROOT/'src/full_adapter.rs').read_text(),f'ordinary cartouche supports ASCII scale alias {alias}')
print(f'\nsource/asset validation: {CHECKS-len(FAIL)}/{CHECKS} PASS; failures: {len(FAIL)}')
if FAIL: sys.exit(1)
