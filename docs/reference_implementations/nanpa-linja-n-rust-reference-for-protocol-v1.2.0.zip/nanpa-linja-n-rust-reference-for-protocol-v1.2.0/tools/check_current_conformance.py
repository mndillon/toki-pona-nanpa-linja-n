#!/usr/bin/env python3
import hashlib,json,pathlib,sys
root=pathlib.Path(__file__).resolve().parents[1]
renderer=root/'reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js'
expected='6bfcb77e5177eec4d923bbd24d60dbac211e574b62e128e6dbfc07f8e859d220'
errors=[]
sha=hashlib.sha256(renderer.read_bytes()).hexdigest() if renderer.exists() else None
if sha!=expected: errors.append(f'renderer authority hash got={sha} want={expected}')
checks=[
 ('conformance/canonical-syntax-v1.0.1-phase1/cases.json','cases',28),
 ('conformance/canonical-syntax-v1.0.1-phase1/cases.json','fontAdapterCases',5),
 ('conformance/full-renderer-canonical-v1.2.0/cases.json','cases',254),
 ('conformance/parser-renderer-profile-v1.2.0.json','nanpaParserSmokeCases',16),
 ('conformance/parser-renderer-regression-v1.2.0.json','cases',24),
]
for rel,key,n in checks:
 p=root/rel
 try:d=json.loads(p.read_text())
 except Exception as e: errors.append(f'{rel}: {e}');continue
 got=len(d.get(key,[]))
 if got!=n: errors.append(f'{rel}:{key} got={got} want={n}')
 for auth in (d.get('authority'), d):
  if isinstance(auth,dict):
   h=auth.get('canonicalJavaScriptSha256') or auth.get('sha256') or auth.get('rendererSha256')
   if h and len(str(h))==64 and rel.startswith('conformance/') and 'renderer' in str(auth).lower() and h!=expected:
    errors.append(f'{rel}: authority sha got={h} want={expected}')
    break
if errors:
 print('Rust current v1.2 conformance authority: FAIL')
 for e in errors: print('FAIL',e)
 sys.exit(1)
print('Rust current v1.2 conformance authority: PASS')
print('renderer sha256:',sha)
print('canonical syntax: 28; adapters: 5; canonical full renderer: 254; NanpaParser smoke: 16; v1.2 parser cases: 24')
