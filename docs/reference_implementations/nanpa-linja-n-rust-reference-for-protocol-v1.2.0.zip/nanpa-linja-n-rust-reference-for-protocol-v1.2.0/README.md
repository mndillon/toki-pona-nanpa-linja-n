# nanpa-linja-n Rust reference for Protocol v1.2.0

Native Rust reference implementation of **nanpa-linja-n Protocol v1.2.0**. The frozen Core-v1 parser/API sources remain hash-pinned; Protocol-v1.2 document parsing and rendering behavior are layered above Core.

## Requirements

- a current stable Rust toolchain (`rustc` and `cargo`)
- no external font directory: `resources/fonts.zip` is bundled

## Test

```bash
./tools/run_rust_regression.sh
```

The runner is non-fail-fast and writes:

```text
test-output/rust-regression-report.txt
```

It checks the frozen Core corpus, current JavaScript-derived conformance authority, Rust compilation/tests, AST serialization, canonical syntax/adapters, the 254-case full-renderer corpus, the 128-case production-font matrix, and the Protocol-v1.2 parser/profile/vector-output gates.

## Protocol-v1.2 defaults

The public facade defaults to uniform relaxed nanpa-linja-n parsing/rendering, Nanpa colon parsing/rendering enabled, abbreviated numeric cartouches enabled, abbreviation-break preservation disabled, and hexadecimal/binary parsing disabled unless explicitly enabled.

The frozen `ParseOptions::default()` remains available for Core-v1 conformance. Use the v1.2 facade defaults for application-facing behavior:

```rust
use nanpa_linja_n_rust::facade::{NanpaLinjaN, RenderOptions};

let nanpa = NanpaLinjaN::create()?;
let number = nanpa.parse_number("123").expect("number");
let png = nanpa.render_to_png("123.45", &RenderOptions::default())?;
```

For hexadecimal/binary input, opt in explicitly through parser options.

## Protocol v1.2 parser additions

Protocol v1.2 adds ordinary `.` → U+F199C middle-dot tokenization with numeric/literal protection, optional full-stop line splitting with quote/cartouche/long-pi/brace/decimal protection, direct CSP/UCSUR document-input normalization with `canonical_source_text` / `source_encoding` metadata, odd/even backslash quote escaping, and force-ordinary cartouches beginning with an empty quote pair.
## `parseNumber` and `astToText`

Protocol v1.2 keeps parsing and serialization alternatives separate. Ordinary decimal/date/time `parse_number()` results do not expose serializer-only `abbreviated_words` or `nasin_nanpa_pona_words`; use `ast_to_text_with_options()` to request source, proper-name, `#~`, full-cartouche, abbreviated-cartouche, or nasin-nanpa-pona output.

Mixed fractions preserve the v1.1 semantic delimiter in abbreviated output, e.g. `1+1/2` serializes as:

```text
[nanpa : wan kin wan o o tu nanpa]
```

Whitespace terminates decimal-digit numeric constructs: `8 1/2` is two numbers, while `8+1/2` is one mixed fraction.

## Production fonts and cartouche scaling

The package contains the eight production font pairs from the retained Production-Font-Profile-v1.1 manifest. Production adapters are applied internally.

### Current production font files

`resources/fonts.zip` is authoritative. The current manifest resolves the eight production font keys to these base/companion files:

| `fontKey` | Base/companion file |
| --- | --- |
| `nasinNanpa` | `nanpa-linja-n-nasin-nanpa-sans-punctuation-mapping-fixed-ascii-vulgar-cartouche-only.ttf` |
| `sitelenSeliKiwen` | `sitelenselikiwenjuniko-latin-ligatures-compatible-punctuation-mapping-fixed-ascii-vulgar-cartouche-only-state-continuity-fixed.ttf` |
| `fairfaxHd` | `FairfaxHD-compatible-punctuation-mapping-fixed.ttf` |
| `fairfaxPonaHd` | `FairfaxPonaHD-compatible-punctuation-mapping-fixed-ascii-fraction-cartouche-aliases.ttf` |
| `linjaPona` | `linja-pona-n-epiku-majuna-fixed-corrected.otf` |
| `linjaSike` | `linja-sike-5-epiku-fixed.otf` |
| `nasinSitelenPuMono` | `NasinSitelenPuMono-majuna-fixed.otf` |
| `linjaLipamanka` | `linjalipamanka-epiku-fixed.otf` |

The current literal-cartouche file is `nanpa-linja-n-nasin-nanpa-sans-literal.ttf`. Support fonts remain bundled inside the same archive.

Current cartouche scaling uses inline postfix controls:

```text
¼  ⅓  ½  ⅔  ¾
```

Ordinary cartouches also accept the approved ASCII aliases `1/4`, `1/3`, `1/2`, `2/3`, and `3/4`. Legacy automatic `ss12`/`ss13`/`ss14` switching is not used.

## Vector output

PNG is raster by definition. Numeric/cartouche SVG output includes shaped vector glyph paths and does not require a raster image fallback. PDF text/cartouche output is produced from shaped font outlines and contains no generated `/Subtype /Image` XObject. Embedded user image runs are deliberately rejected by the vector-PDF path rather than silently rasterizing the document.

## Full-document example

```rust
use nanpa_linja_n_rust::facade::NanpaLinjaN;
use nanpa_linja_n_rust::FullRenderOptions;

let nanpa = NanpaLinjaN::create()?;
let options = FullRenderOptions::default();
let ast = nanpa.parse_input("toki&pona 123 zz pi(telo lete) te tomo to", &options);
let text = nanpa.ast_to_text_with_options(&ast, &options)?;
let png = nanpa.render_full_to_png(&text, &options)?;
let svg = nanpa.render_full_to_svg(&text, &options)?;
let pdf = nanpa.render_full_to_pdf(&text, &options)?;
```

## Release verification

```bash
python3 verify_release.py
python3 tools/check_current_conformance.py
python3 tools/validate_rendering_source.py
```

`verify_release.py` verifies every shipped file against `RELEASE-MANIFEST.json`.
