mod support;

use nanpa_linja_n_rust::facade::NanpaLinjaN;
use nanpa_linja_n_rust::{FullRenderLinePlan, FullRenderOptions};
use serde_json::Value;
use std::fs;

fn cp(text: &str) -> u32 {
    let raw = text.strip_prefix("U+").expect("U+ codepoint");
    u32::from_str_radix(raw, 16).expect("hex codepoint")
}

fn strings(value: Option<&Value>) -> Vec<String> {
    value
        .and_then(Value::as_array)
        .map(|items| items.iter().filter_map(Value::as_str).map(str::to_string).collect())
        .unwrap_or_default()
}

fn codepoints(value: Option<&Value>) -> Vec<u32> {
    value
        .and_then(Value::as_array)
        .map(|items| items.iter().filter_map(Value::as_str).map(cp).collect())
        .unwrap_or_default()
}

fn semantic(line: &FullRenderLinePlan) -> (Vec<String>, Vec<u32>, Vec<String>, Vec<String>) {
    let kinds = line.runs.iter().map(|run| run.kind.clone()).collect::<Vec<_>>();
    let mut cps = Vec::new();
    let mut literals = Vec::new();
    let mut cartouches = Vec::new();
    for run in &line.runs {
        cps.extend(run.canonical_codepoints.iter().copied());
        if run.kind == "text" { literals.push(run.render_text.clone()); }
        if run.kind == "cartouche" {
            cartouches.push(if run.literal_cartouche {
                "literal".to_string()
            } else if run.numeric_cartouche {
                "number".to_string()
            } else {
                "ordinary".to_string()
            });
        }
    }
    (kinds, cps, literals, cartouches)
}

#[test]
fn protocol_v1_2_parser_renderer_regression() {
    let root: Value = serde_json::from_str(
        &fs::read_to_string("conformance/parser-renderer-regression-v1.2.0.json").unwrap(),
    )
    .unwrap();
    let cases = support::array(&root["cases"]);
    assert_eq!(cases.len(), 24);
    let nanpa = NanpaLinjaN::create().expect("facade");
    let mut errors = Vec::new();
    let mut passed = 0usize;

    for case in cases {
        let id = case["id"].as_str().unwrap();
        let before = errors.len();
        let input = case["input"].as_str().unwrap();
        let mut options = FullRenderOptions::default();
        options.parser = support::apply_parser(options.parser, &case["parserOptions"]);

        match nanpa.build_full_render_plan(input, &options) {
            Ok(plan) => {
                let expected_ast = &case["expected"]["ast"];
                if let Some(want) = expected_ast.get("normalizedInput").and_then(Value::as_str) {
                    if plan.ast.normalized_input != want {
                        errors.push(format!("{id}: normalizedInput got={:?} want={want:?}", plan.ast.normalized_input));
                    }
                }
                if let Some(want) = expected_ast.get("lineCount").and_then(Value::as_u64) {
                    if plan.ast.lines.len() != want as usize {
                        errors.push(format!("{id}: lineCount got={} want={want}", plan.ast.lines.len()));
                    }
                }
                if let Some(want_lines) = expected_ast.get("lines").and_then(Value::as_array) {
                    if plan.ast.lines.len() == want_lines.len() {
                        for (index, (got, want)) in plan.ast.lines.iter().zip(want_lines).enumerate() {
                            if let Some(v) = want.get("sourceText").and_then(Value::as_str) {
                                if got.source_text != v { errors.push(format!("{id}: AST line[{index}] sourceText got={:?} want={v:?}", got.source_text)); }
                            }
                            if let Some(v) = want.get("canonicalSourceText").and_then(Value::as_str) {
                                if got.canonical_source_text.as_deref() != Some(v) { errors.push(format!("{id}: AST line[{index}] canonicalSourceText got={:?} want={v:?}", got.canonical_source_text)); }
                            } else if got.canonical_source_text.is_some() {
                                errors.push(format!("{id}: AST line[{index}] unexpected canonicalSourceText={:?}", got.canonical_source_text));
                            }
                            if let Some(v) = want.get("sourceEncoding").and_then(Value::as_str) {
                                if got.source_encoding.as_deref() != Some(v) { errors.push(format!("{id}: AST line[{index}] sourceEncoding got={:?} want={v:?}", got.source_encoding)); }
                            } else if got.source_encoding.is_some() {
                                errors.push(format!("{id}: AST line[{index}] unexpected sourceEncoding={:?}", got.source_encoding));
                            }
                            if let Some(want_segments) = want.get("segments").and_then(Value::as_array) {
                                if got.children.len() != want_segments.len() {
                                    errors.push(format!("{id}: AST line[{index}] segment count got={} want={}", got.children.len(), want_segments.len()));
                                } else {
                                    for (seg_index, (got_seg, want_seg)) in got.children.iter().zip(want_segments).enumerate() {
                                        if let Some(v) = want_seg.get("kind").and_then(Value::as_str) {
                                            if got_seg.kind != v { errors.push(format!("{id}: AST segment[{index},{seg_index}] kind got={} want={v}", got_seg.kind)); }
                                        }
                                        if let Some(v) = want_seg.get("value").and_then(Value::as_str) {
                                            if got_seg.value != v { errors.push(format!("{id}: AST segment[{index},{seg_index}] value got={:?} want={v:?}", got_seg.value)); }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if let Some(want_semantic) = case["expected"]["semantic"].as_array() {
                    if plan.lines.len() != want_semantic.len() {
                        errors.push(format!("{id}: semantic line count got={} want={}", plan.lines.len(), want_semantic.len()));
                    } else {
                        for (index, (got_line, want)) in plan.lines.iter().zip(want_semantic).enumerate() {
                            let (got_kinds, got_cps, got_literals, got_cartouches) = semantic(got_line);
                            let want_kinds = strings(want.get("elementKinds"));
                            let want_cps = codepoints(want.get("canonicalCodepoints"));
                            let want_literals = strings(want.get("literalTexts"));
                            let want_cartouches = strings(want.get("cartoucheClasses"));
                            if got_kinds != want_kinds { errors.push(format!("{id}: semantic[{index}] kinds got={got_kinds:?} want={want_kinds:?}")); }
                            if got_cps != want_cps { errors.push(format!("{id}: semantic[{index}] cps got={got_cps:?} want={want_cps:?}")); }
                            if got_literals != want_literals { errors.push(format!("{id}: semantic[{index}] literals got={got_literals:?} want={want_literals:?}")); }
                            if got_cartouches != want_cartouches { errors.push(format!("{id}: semantic[{index}] cartouches got={got_cartouches:?} want={want_cartouches:?}")); }
                        }
                    }
                }
            }
            Err(error) => errors.push(format!("{id}: build threw {error}")),
        }
        if errors.len() == before { passed += 1; }
    }

    println!("Rust Protocol v1.2 parser/renderer regression: {passed}/{} {}", cases.len(), if errors.is_empty() { "PASS" } else { "FAIL" });
    if !errors.is_empty() {
        panic!("Protocol v1.2 parser failures ({}):\n{}", errors.len(), errors.join("\n"));
    }
}
