use crate::api::codepoint_to_word;
use crate::full_types::{DocumentAst, DocumentLine, DocumentSegment, FullParserOptions, FullRenderOptions, ImageDescriptor};

const FULL_ALIASES: [(&str, &str); 13] = [
    ("'cartouche-start'", "["), ("'cartouche-end'", "]"), ("'zw-joiner'", "&"),
    ("'stack-joiner'", "-"), ("'nesting-joiner'", "+"), ("'ideographic-space'", " zz "),
    ("'long-start'", "("), ("'long-end'", ")"), ("'left-bracket'", " te "),
    ("'right-bracket'", " to "), ("'middle-dot'", "."), ("'colon'", ":"), ("'tally'", ","),
];

fn normalize_document(input: &str, options: &FullParserOptions) -> String {
    let mut out = input.to_string();
    if options.effective_renderer_mode() != "standard-sitelen-pona-ascii-core" {
        for (a, b) in FULL_ALIASES { out = out.replace(a, b); }
    }
    out.replace("\r\n", "\n").replace('\r', "\n")
}

fn is_backslash_escaped_at(text: &str, index: usize) -> bool {
    let bytes = text.as_bytes();
    let mut i = index.min(bytes.len());
    let mut count = 0usize;
    while i > 0 && bytes[i - 1] == b'\\' { count += 1; i -= 1; }
    count % 2 == 1
}


fn sentence_stop(bytes: &[u8], i: usize) -> bool {
    let prev = if i > 0 { bytes[i-1] } else { 0 };
    let next = if i+1 < bytes.len() { bytes[i+1] } else { 0 };
    let next_digit = next.is_ascii_digit();
    let prev_ok = prev.is_ascii_digit() || i == 0 || prev.is_ascii_whitespace() || b"+-(,:=".contains(&prev);
    !(next_digit && prev_ok)
}

fn split_full_stops(line: &str) -> Vec<String> {
    let bytes = line.as_bytes();
    let mut out = Vec::new();
    let mut start = 0usize;
    let mut square = 0i32; let mut paren = 0i32; let mut brace = 0i32;
    let mut quote: Option<char> = None;
    let mut i = 0usize;
    while i < line.len() {
        let ch = line[i..].chars().next().unwrap();
        let clen = ch.len_utf8();
        if let Some(q) = quote {
            let close = (q == '“' && (ch == '”' || ch == '"')) || (q == '"' && (ch == '"' || ch == '”'));
            if close && !is_backslash_escaped_at(line, i) { quote = None; }
            i += clen; continue;
        }
        if ch == '"' || ch == '“' { quote = Some(ch); i += clen; continue; }
        match ch {
            '[' => square += 1,
            ']' => if square > 0 { square -= 1 },
            '(' => paren += 1,
            ')' => if paren > 0 { paren -= 1 },
            '{' => brace += 1,
            '}' => if brace > 0 { brace -= 1 },
            '.' if square == 0 && paren == 0 && brace == 0 && sentence_stop(bytes, i) => {
                let mut end = i + 1;
                while end < line.len() && line.as_bytes()[end] == b'.' && sentence_stop(bytes, end) { end += 1; }
                let piece = &line[start..end];
                if !piece.trim().is_empty() { out.push(piece.to_string()); }
                start = end; i = end; continue;
            }
            _ => {}
        }
        i += clen;
    }
    let tail = &line[start..];
    if !tail.trim().is_empty() || out.is_empty() { out.push(tail.to_string()); }
    out
}

#[derive(Debug, Clone)]
struct CspToken { kind: &'static str, text: String }

fn csp_word_for_codepoint(cp: u32) -> Option<String> {
    match cp {
        0xF1989 => return Some("ni<".into()),
        0xF198A => return Some("ni^".into()),
        0xF198B => return Some("ni>".into()),
        0xF198C => return Some("sewi^".into()),
        0x300C | 0xF19B4 => return Some("te".into()),
        0x300D | 0xF19B5 => return Some("to".into()),
        0x3000 => return Some("zz".into()),
        _ => {}
    }
    if matches!(cp, 0xF1990..=0xF199E) { return None; }
    codepoint_to_word(cp).map(str::to_string)
}

fn csp_token_for_codepoint(cp: u32) -> Option<CspToken> {
    if let Some(word) = csp_word_for_codepoint(cp) { return Some(CspToken { kind: "word", text: word }); }
    let (kind, text) = match cp {
        0xF1990 => ("cartoucheStart", "["), 0xF1991 => ("cartoucheEnd", "]"), 0xF1992 => ("ignorableControl", ""),
        0xF1993 => ("deprecatedLongPiStart", ""), 0xF1994 => ("deprecatedLongPiExtension", ""),
        0xF1995 => ("joiner", "-"), 0xF1996 => ("joiner", "+"), 0xF1997 => ("longStart", "("), 0xF1998 => ("longEnd", ")"),
        0xF1999 => ("ignorableControl", ""), 0xF199A => ("reverseStart", "{"), 0xF199B => ("reverseEnd", "}"),
        0xF199C => ("middleDot", "."), 0xF199D => ("colon", ":"), 0xF199E => ("tally", ","), 0x200D => ("joiner", "&"),
        _ => return None,
    };
    Some(CspToken { kind, text: text.into() })
}

fn has_potential_csp_unicode_input(text: &str) -> bool {
    text.chars().any(|ch| { let cp = ch as u32; matches!(cp, 0x200D | 0x3000 | 0x300C | 0x300D) || (0xF1900..=0xF19FF).contains(&cp) })
}
fn contains_recognized_csp_unicode_input(text: &str) -> bool {
    has_potential_csp_unicode_input(text) && text.chars().any(|ch| csp_token_for_codepoint(ch as u32).is_some())
}
fn csp_token_needs_word_separator(left: Option<&CspToken>, right: &CspToken) -> bool {
    let Some(left) = left else { return false; };
    matches!((left.kind, right.kind), ("word","word") | ("longEnd","word") | ("cartoucheEnd","word") | ("middleDot","word") | ("tally","word"))
}
fn serialize_csp_unicode_token_run(tokens: &[CspToken]) -> String {
    let filtered: Vec<&CspToken> = tokens.iter().filter(|t| t.kind != "ignorableControl").collect();
    if filtered.is_empty() { return String::new(); }
    if filtered[0].kind == "deprecatedLongPiStart" {
        let mut inner=String::new(); let mut prev=None;
        for token in filtered.into_iter().skip(1).filter(|t| t.kind != "deprecatedLongPiExtension") {
            if csp_token_needs_word_separator(prev, token) { inner.push(' '); }
            inner.push_str(&token.text); prev=Some(token);
        }
        return format!("pi({inner})");
    }
    let mut out=String::new(); let mut prev=None;
    for token in filtered {
        if token.kind == "deprecatedLongPiExtension" { if !out.is_empty()&&!out.ends_with(' '){out.push(' ');} prev=None; continue; }
        if token.kind == "colon" { if !out.is_empty()&&!out.ends_with(' ')&&!out.ends_with('['){out.push(' ');} out.push(':'); prev=Some(token); continue; }
        if prev.is_some_and(|p:&CspToken|p.kind=="colon") { if !out.is_empty()&&!out.ends_with(' '){out.push(' ');} }
        else if csp_token_needs_word_separator(prev,token) && !out.is_empty()&&!out.ends_with(' ') { out.push(' '); }
        out.push_str(&token.text); prev=Some(token);
    }
    out
}
fn boundary_word_char(ch:char)->bool{ch.is_ascii_alphanumeric()||matches!(ch,'_'|'^'|'<'|'>')}
fn csp_boundary_needs_space(left:&str,right:&str)->bool{left.chars().last().zip(right.chars().next()).is_some_and(|(l,r)|boundary_word_char(l)&&boundary_word_char(r))}
fn protected_quoted_end(text:&str,start:usize)->Option<usize>{
    let open=text[start..].chars().next()?; if open!='"'&&open!='“'{return None;} let mut j=start+open.len_utf8();
    while j<text.len(){let ch=text[j..].chars().next()?;let close=(open=='“'&&(ch=='”'||ch=='"'))||(open=='"'&&(ch=='"'||ch=='”'));if close&&!is_backslash_escaped_at(text,j){return Some(j+ch.len_utf8());}j+=ch.len_utf8();}None
}
fn protected_img_end(text:&str,start:usize)->Option<usize>{
    if !text[start..].starts_with("img("){return None;}let mut j=start+4;let mut depth=1i32;let mut quote=None;let mut escaped=false;
    while j<text.len(){let ch=text[j..].chars().next()?;let n=ch.len_utf8();if escaped{escaped=false;j+=n;continue;}if ch=='\\'{escaped=true;j+=n;continue;}if let Some(q)=quote{if ch==q{quote=None;}j+=n;continue;}if ch=='"'||ch=='\''{quote=Some(ch);j+=n;continue;}if ch=='(' {depth+=1;}else if ch==')'{depth-=1;if depth==0{return Some(j+n);}}j+=n;}None
}
fn canonicalize_csp_unicode_input_line(source:&str,options:&FullParserOptions)->(bool,String){
    if source.is_empty()||!contains_recognized_csp_unicode_input(source){return(false,source.into());}
    let mut pieces:Vec<(bool,String)>=Vec::new();let mut i=0usize;
    while i<source.len(){let ch=source[i..].chars().next().unwrap();
        if !options.interpret_double_quotes_as_te_to&&(ch=='"'||ch=='“'){if let Some(end)=protected_quoted_end(source,i){pieces.push((false,source[i..end].into()));i=end;continue;}}
        if source[i..].starts_with("img("){if let Some(end)=protected_img_end(source,i){pieces.push((false,source[i..end].into()));i=end;continue;}}
        if csp_token_for_codepoint(ch as u32).is_none(){let end=i+ch.len_utf8();if let Some((false,raw))=pieces.last_mut(){raw.push_str(&source[i..end]);}else{pieces.push((false,source[i..end].into()));}i=end;continue;}
        let mut tokens=Vec::new();let mut j=i;while j<source.len(){let c=source[j..].chars().next().unwrap();let Some(t)=csp_token_for_codepoint(c as u32)else{break;};tokens.push(t);j+=c.len_utf8();}
        let converted=serialize_csp_unicode_token_run(&tokens);if !converted.is_empty(){pieces.push((true,converted));}i=j;
    }
    let mut out=String::new();for idx in 0..pieces.len(){if idx>0{let (pk,pt)=&pieces[idx-1];let (k,t)=&pieces[idx];if pk!=k&&csp_boundary_needs_space(pt,t)&&!out.ends_with(' '){out.push(' ');}}out.push_str(&pieces[idx].1);}let changed=out!=source;(changed,out)
}

fn split_args(input: &str) -> Vec<String> {
    let mut out = Vec::new(); let mut current = String::new(); let mut quote: Option<char> = None; let mut escaped=false; let mut depth=0i32;
    for ch in input.chars() {
        if escaped { current.push(ch); escaped=false; continue; }
        if ch == '\\' { current.push(ch); escaped=true; continue; }
        if let Some(q)=quote { current.push(ch); if ch==q { quote=None; } continue; }
        if ch=='\'' || ch=='"' { quote=Some(ch); current.push(ch); continue; }
        if ch=='(' { depth+=1; current.push(ch); continue; }
        if ch==')' && depth>0 { depth-=1; current.push(ch); continue; }
        if ch==',' && depth==0 { out.push(current.trim().to_string()); current.clear(); continue; }
        current.push(ch);
    }
    out.push(current.trim().to_string()); out
}
fn strip_quotes(value:&str)->String { let s=value.trim(); if s.len()>=2 && ((s.starts_with('\'')&&s.ends_with('\''))||(s.starts_with('"')&&s.ends_with('"'))) { s[1..s.len()-1].to_string() } else { s.to_string() } }
fn parse_image_args(arg:&str)->ImageDescriptor {
    let mut d=ImageDescriptor{v_align:"baseline".into(),wriggle:8.0,transparent:true,..ImageDescriptor::default()};
    for part in split_args(arg) { if part.is_empty(){continue;} let Some(at)=part.find('=') else {continue}; let k=part[..at].trim().to_ascii_lowercase(); let v=strip_quotes(&part[at+1..]); match k.as_str(){"src"=>d.src=v,"w"|"width"=>d.width=v,"h"|"height"=>d.height=v,"alt"=>d.alt=v,"valign"=>d.v_align=v,"wriggle"=>d.wriggle=v.parse().unwrap_or(d.wriggle),"transparent"=>{let x=v.to_ascii_lowercase();d.transparent=!(x=="false"||x=="0"||x=="no");},_=>{}} }
    d
}

fn segments(line:&str)->Vec<DocumentSegment> {
    let mut out=Vec::new(); let mut i=0usize; let mut start=0usize;
    let push_text=|out:&mut Vec<DocumentSegment>,a:usize,b:usize| { if b>a { out.push(DocumentSegment{kind:"text".into(),value:line[a..b].to_string(),source_start:a,source_end:b,..DocumentSegment::default()}); } };
    while i<line.len() {
        if line[i..].starts_with('[') { if let Some(rel)=line[i+1..].find(']') { let end=i+1+rel; push_text(&mut out,start,i); out.push(DocumentSegment{kind:"bracket".into(),value:line[i+1..end].to_string(),source_start:i,source_end:end+1,..DocumentSegment::default()}); i=end+1; start=i; continue; } else {break;} }
        if line[i..].starts_with('"') { let mut j=i+1; let mut found=None; while j<line.len(){ let ch=line[j..].chars().next().unwrap(); if ch=='"' && !is_backslash_escaped_at(line,j){found=Some(j);break;} j+=ch.len_utf8(); } if let Some(end)=found { push_text(&mut out,start,i); out.push(DocumentSegment{kind:"quote".into(),value:line[i+1..end].to_string(),open_quote:"\"".into(),close_quote:"\"".into(),source_start:i,source_end:end+1,..DocumentSegment::default()}); i=end+1;start=i;continue;} else {break;} }
        if line[i..].starts_with('“') { let open_len='“'.len_utf8(); let mut j=i+open_len; let mut found=None; let mut close_len='”'.len_utf8(); while j<line.len(){ if line[j..].starts_with('”')&&!is_backslash_escaped_at(line,j){found=Some(j);close_len='”'.len_utf8();break;} if line[j..].starts_with('"')&&!is_backslash_escaped_at(line,j){found=Some(j);close_len=1;break;} j+=line[j..].chars().next().unwrap().len_utf8(); } if let Some(end)=found { push_text(&mut out,start,i); out.push(DocumentSegment{kind:"quote".into(),value:line[i+open_len..end].to_string(),open_quote:"“".into(),close_quote:line[end..end+close_len].to_string(),source_start:i,source_end:end+close_len,..DocumentSegment::default()}); i=end+close_len;start=i;continue;} else {break;} }
        if line[i..].starts_with("img(") { let mut j=i+4; let mut depth=1i32; let mut quote:Option<char>=None; let mut escaped=false; while j<line.len(){ let ch=line[j..].chars().next().unwrap(); let clen=ch.len_utf8(); if escaped{escaped=false;j+=clen;continue;} if ch=='\\'{escaped=true;j+=clen;continue;} if let Some(q)=quote {if ch==q{quote=None;}j+=clen;continue;} if ch=='\''||ch=='"'{quote=Some(ch);j+=clen;continue;} if ch=='(' {depth+=1;} else if ch==')'{depth-=1;if depth==0{break;}} j+=clen; } if j>=line.len(){break;} push_text(&mut out,start,i); let img=parse_image_args(&line[i+4..j]); let end=j+1; out.push(DocumentSegment{kind:"image".into(),image:Some(img),source_start:i,source_end:end,..DocumentSegment::default()}); i=end;start=i;continue; }
        i+=line[i..].chars().next().unwrap().len_utf8();
    }
    push_text(&mut out,start,line.len()); out
}

pub fn parse_full_document(input:&str, options:&FullParserOptions)->DocumentAst {
    let normalized=normalize_document(input,options); let mut lines=Vec::new();
    for (source_line_index,source) in normalized.split('\n').enumerate(){
        let rendered=if options.break_lines_at_full_stops{split_full_stops(source)}else{vec![source.to_string()]};
        for (sentence_index,source_text) in rendered.into_iter().enumerate(){
            let (changed,canonical)=if has_potential_csp_unicode_input(&source_text){canonicalize_csp_unicode_input_line(&source_text,options)}else{(false,source_text.clone())};
            let parsed_text=if changed{canonical.as_str()}else{source_text.as_str()};
            let children=segments(parsed_text);
            let idx=lines.len();
            lines.push(DocumentLine{index:idx,source_line_index,sentence_index_in_source_line:sentence_index,source_text:source_text.clone(),canonical_source_text:if changed{Some(canonical)}else{None},source_encoding:if changed{Some("mixed-csp-unicode".into())}else{None},children});
        }
    }
    DocumentAst{kind:"document".into(),normalized_input:normalized,break_lines_at_full_stops:options.break_lines_at_full_stops,parser_options:options.clone(),lines}
}


fn quote_image_argument(value:&str)->String {
    if !value.contains('\'') { return format!("'{value}'"); }
    if !value.contains('"') { return format!("\"{value}\""); }
    let escaped=value.replace('\\',"\\\\").replace('"',"\\\"");
    format!("\"{escaped}\"")
}

fn image_descriptor_to_text(image:Option<&ImageDescriptor>)->String {
    let Some(d)=image else { return "img()".into(); };
    let mut args=Vec::<String>::new();
    if !d.src.is_empty(){args.push(format!("src={}",quote_image_argument(&d.src)));}
    if !d.width.is_empty(){args.push(format!("w={}",quote_image_argument(&d.width)));}
    if !d.height.is_empty(){args.push(format!("h={}",quote_image_argument(&d.height)));}
    if !d.alt.is_empty(){args.push(format!("alt={}",quote_image_argument(&d.alt)));}
    if !d.v_align.is_empty()&&d.v_align!="baseline"{args.push(format!("valign={}",quote_image_argument(&d.v_align)));}
    if d.wriggle!=8.0{args.push(format!("wriggle={}",d.wriggle));}
    if !d.transparent{args.push("transparent=false".into());}
    format!("img({})",args.join(","))
}

fn document_segment_to_text(segment:&DocumentSegment)->Result<String,String> {
    match segment.kind.as_str() {
        "text"=>Ok(segment.value.clone()),
        "bracket"=>Ok(format!("[{}]",segment.value)),
        "quote"=>{
            let open=if segment.open_quote.is_empty(){"\""}else{&segment.open_quote};
            let default_close=if open=="“"{"”"}else{"\""};
            let close=if segment.close_quote.is_empty(){default_close}else{&segment.close_quote};
            Ok(format!("{}{}{}",open,segment.value,close))
        }
        "image"=>Ok(image_descriptor_to_text(segment.image.as_ref())),
        "rawUcsur"=>{
            let mut parts=Vec::with_capacity(segment.codepoints.len());
            for cp in &segment.codepoints {
                if *cp>0x10FFFF || (0xD800..=0xDFFF).contains(cp) { return Err(format!("invalid rawUcsur code point: {cp}")); }
                parts.push(format!("U+{cp:04X}"));
            }
            Ok(parts.join(" "))
        }
        other=>Err(format!("unsupported AST segment kind {other:?}")),
    }
}

fn numeric_output_mode(options:&FullRenderOptions)->Result<&str,String>{
    let mode=options.numeric_output.trim();
    let mode=if mode.is_empty(){"source"}else{mode};
    if matches!(mode,"source"|"properName"|"#~"|"cartouche"){Ok(mode)}else{Err(format!("unsupported numericOutput mode: {mode}"))}
}

fn numeric_source_to_text(source:&str,mode:&str,parser:&FullParserOptions)->String{
    if mode=="source"{return source.to_string();}
    let options=parser.numeric_options();
    let Some(parsed)=crate::parser::parse_number(source,&options).map(crate::v11_numeric::normalize_v11_yearless_date_result) else{return source.to_string();};
    if parser.nasin_nanpa_pona {
        if let Some(words)=parsed.nasin_nanpa_pona_words.as_ref().filter(|words|!words.is_empty()){return words.join(" ");}
    }
    match mode {
        "properName" if !parsed.proper_name.is_empty()=>parsed.proper_name,
        "#~" if parsed.unique_code.starts_with("#~")=>parsed.unique_code,
        "cartouche"=>{
            let words = if parser.abbreviate_numeric_cartouches {
                let base = parsed.abbreviated_words.as_ref().unwrap_or(&parsed.tp_words);
                crate::v11_numeric::normalize_v11_abbreviated_words(base.iter().map(String::as_str))
            } else {
                parsed.tp_words.clone()
            };
            if words.is_empty(){source.to_string()}else{format!("[{}]",words.join(" "))}
        }
        _=>source.to_string(),
    }
}

fn apply_numeric_structures(source:&str,segment:&DocumentSegment,mode:&str,parser:&FullParserOptions)->String{
    if mode=="source"||segment.numeric_structures.is_empty(){return source.to_string();}
    let mut structures=segment.numeric_structures.clone();
    structures.sort_by_key(|item|(item.index,item.end));
    let mut out=String::new();let mut position=0usize;let mut replaced=false;
    for item in structures {
        if item.end<=item.index||item.end>source.len()||item.index<position||!source.is_char_boundary(item.index)||!source.is_char_boundary(item.end){continue;}
        if item.source_text.len()!=item.end-item.index||&source[item.index..item.end]!=item.source_text{continue;}
        out.push_str(&source[position..item.index]);
        out.push_str(&numeric_source_to_text(&item.source_text,mode,parser));
        position=item.end;replaced=true;
    }
    if !replaced{return source.to_string();}
    out.push_str(&source[position..]);out
}

/// Convert a full-document AST back into valid nanpa-linja-n source text.
/// Source-preserving serialization remains the default. Use
/// [`ast_to_text_with_options`] to request proper-name, #~, cartouche, or
/// nasin-nanpa-pona numeric re-serialization.
pub fn ast_to_text(ast:&DocumentAst)->Result<String,String>{
    let mut options=FullRenderOptions::default();
    options.parser=ast.parser_options.clone();
    ast_to_text_with_options(ast,&options)
}

pub fn ast_to_text_with_options(ast:&DocumentAst,options:&FullRenderOptions)->Result<String,String>{
    if !ast.kind.is_empty()&&ast.kind!="document"{return Err("astToText expects a document AST".into());}
    let mode=numeric_output_mode(options)?;
    let mut out=String::new();let mut previous_source_line_index:Option<usize>=None;
    for line in &ast.lines {
        if let Some(previous)=previous_source_line_index {if line.source_line_index!=previous{out.push('\n');}}
        for segment in &line.children {
            let source=document_segment_to_text(segment)?;
            out.push_str(&apply_numeric_structures(&source,segment,mode,&options.parser));
        }
        previous_source_line_index=Some(line.source_line_index);
    }
    Ok(out)
}

/// Cross-language source-preserving spelling of [`ast_to_text`].
#[allow(non_snake_case)]
pub fn astToText(ast:&DocumentAst)->Result<String,String>{ast_to_text(ast)}
/// Cross-language options-aware spelling matching the current JavaScript baseline.
#[allow(non_snake_case)]
pub fn astToTextWithOptions(ast:&DocumentAst,options:&FullRenderOptions)->Result<String,String>{ast_to_text_with_options(ast,options)}

pub fn parse_raw_unicode_sequence(text:&str)->Option<Vec<u32>> {
    let toks:Vec<&str>=text.trim().split_whitespace().collect(); if toks.is_empty(){return None;} let mut out=Vec::new(); for t in toks{ let raw=t.strip_prefix("U+").or_else(||t.strip_prefix("u+"))?; if !(4..=6).contains(&raw.len()){return None;} let v=u32::from_str_radix(raw,16).ok()?; if v>0x10FFFF{return None;} out.push(v);} Some(out)
}

pub fn decode_data_image(src:&str)->Option<Vec<u8>> {
    if !src.starts_with("data:image/"){return None;} let comma=src.find(',')?; let meta=&src[..comma]; let data=&src[comma+1..]; if meta.contains(";base64") { decode_base64(data) } else { Some(percent_decode(data)) }
}
fn percent_decode(s:&str)->Vec<u8>{ let b=s.as_bytes(); let mut out=Vec::new(); let mut i=0; while i<b.len(){ if b[i]==b'%' && i+2<b.len(){ if let Ok(v)=u8::from_str_radix(&s[i+1..i+3],16){out.push(v);i+=3;continue;} } if b[i]==b'+'{out.push(b' ');}else{out.push(b[i]);} i+=1;} out }
fn decode_base64(s:&str)->Option<Vec<u8>> { fn val(c:u8)->Option<u8>{match c{b'A'..=b'Z'=>Some(c-b'A'),b'a'..=b'z'=>Some(c-b'a'+26),b'0'..=b'9'=>Some(c-b'0'+52),b'+'=>Some(62),b'/'=>Some(63),_=>None}} let clean:Vec<u8>=s.bytes().filter(|c|!c.is_ascii_whitespace()).collect(); if clean.len()%4!=0{return None;} let mut out=Vec::new(); for chunk in clean.chunks(4){ let a=val(chunk[0])? as u32;let b=val(chunk[1])? as u32;let c=if chunk[2]==b'='{0}else{val(chunk[2])? as u32};let d=if chunk[3]==b'='{0}else{val(chunk[3])? as u32};let n=(a<<18)|(b<<12)|(c<<6)|d;out.push((n>>16) as u8);if chunk[2]!=b'='{out.push((n>>8) as u8);}if chunk[3]!=b'='{out.push(n as u8);} } Some(out) }
