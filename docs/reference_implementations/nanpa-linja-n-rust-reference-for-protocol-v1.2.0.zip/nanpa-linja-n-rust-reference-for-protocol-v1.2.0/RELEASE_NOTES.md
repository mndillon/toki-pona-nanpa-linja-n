# Rust reference — Protocol v1.2.0

- Targets nanpa-linja-n Protocol v1.2.0 while retaining frozen Core-v1 source hashes and Production-Font-Profile-v1.1 behavior.
- Adds ordinary ASCII full-stop to U+F199C parsing, including adjacent `toki.pona`, with numeric and literal protection.
- Keeps `breakLinesAtFullStops` independent and protected inside quotes, cartouches, long-pi parentheses, braces, and decimal numbers.
- Adds direct CSP/UCSUR document-input normalization with original source retention and `canonical_source_text` / `source_encoding` metadata.
- Adds odd/even consecutive-backslash quote-close parity.
- Adds force-ordinary cartouches beginning with an empty quote pair.
- Installs the Protocol-v1.2 canonical JavaScript, 24-case parser/renderer corpus, 254-case full-renderer corpus, and the supplied `fonts.zip`.
- Frozen Core numeric semantics and public numeric defaults are unchanged.
- Full regression was not run during this build at the user's request; the package includes focused v1.2 tests for local qualification.


## Sentence-break correction

- Corrects numeric precedence when a decimal token is immediately followed by sentence punctuation. `12.5.` is now rendered as one numeric cartouche for `12.5` followed by the ordinary full-stop middle dot, matching the Protocol-v1.2 canonical full-renderer corpus.
- Adds the exact `document.sentence-breaks` vector to the targeted Rust regression test.
- No frozen Core numeric source is changed.
