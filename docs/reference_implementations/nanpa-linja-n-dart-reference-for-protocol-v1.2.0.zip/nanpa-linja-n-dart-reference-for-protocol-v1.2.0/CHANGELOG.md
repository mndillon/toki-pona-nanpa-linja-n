# Changelog


## 1.2.0 — 2026-09-29

- Target nanpa-linja-n Protocol v1.2.0.
- Add ordinary full-stop to middle-dot document parsing with numeric/literal protection.
- Add protected `breakLinesAtFullStops` behavior.
- Add direct recognized CSP/UCSUR input normalization and canonical-source metadata.
- Use odd/even backslash parity for quote escaping.
- Add force-ordinary leading-`""` cartouches.
- Bundle the v1.2 parser/renderer profile, 24-case parser corpus and 254-case full-renderer corpus.
- Replace the production font archive with the supplied `fonts.zip` while retaining Production-Font-Profile-v1.1 semantics.
- Frozen Core-v1 numeric implementation remains unchanged.

## 1.1.0 — 2026-09-25

- Target nanpa-linja-n Protocol v1.1.0.
- Retain seven frozen Core-v1 implementation files unchanged.
- Add public v1.1 parser defaults; hex and binary are opt-in.
- Align full-document defaults with the v1.1 parser/renderer profile.
- Align ordinary decimal/date/time `parseNumber()` public result usage with the canonical v1.1 shape.
- Derive alternate serializer representations in `astToText()` rather than requiring decimal convenience fields.
- Replace production font/profile assets with the current eight-font v1.1 set.
- Update native companion family names to the actual supplied font metadata.
- Implement the current five production render adapters.
- Remove active legacy `ss12`/`ss13`/`ss14` scale selection.
- Add inline vulgar-fraction cartouche scale controls and approved ASCII aliases.
- Update outside-cartouche comma behavior.
- Replace stale render-plan/full-renderer authorities with current v1.1 data.
- Add current v1.1 parser-smoke and vector SVG/PDF qualification tests.
- Add release/static validation and refreshed documentation.

## Historical

Earlier package revisions targeted Protocol v1.0.0 / Core-v1 and established the native Dart FFI production-rendering architecture retained by this release.
