# Dart v1.2.0 conformance status

## Target

```text
Reference implementation:       1.2.0
Target protocol:                 1.2.0
Frozen Core compatibility:      Core-v1 / corpus v1.0.2
Frozen Core checks:              1030
Frozen Core operations:          35
Parser/renderer smoke cases:     16
Protocol v1.2 parser cases:      24
Production font pairs:           8
Production render-plan cases:    128
Canonical syntax cases:          28
Production adapter cases:        5
Canonical full-renderer cases:   254
```

## Architecture

This remains an independent native Dart implementation. It does not execute the canonical JavaScript at runtime. Core numeric parsing/logical rendering is Dart-native; production PNG/SVG/PDF rendering uses the existing Dart FFI Pango/Cairo/Fontconfig/GObject backend.

The canonical JavaScript is bundled only as a conformance authority.

## Protocol v1.2 delta

The Dart document parser/renderer now implements the v1.2 document-input rules: ordinary full-stop to U+F199C after numeric precedence, protected `breakLinesAtFullStops`, direct recognized CSP/UCSUR normalization with canonical-source metadata, odd/even backslash quote escaping, and force-ordinary `""` cartouches. Explicit textual `U+...` remains the raw-codepoint path.

The seven frozen Core implementation files remain hash-pinned and unchanged. Protocol v1.2 also retains Production-Font-Profile-v1.1 while this package uses the exact supplied `resources/fonts.zip` and its embedded eight-pair runtime manifest.

## Validation boundary for this build

The preparation environment does not contain a Dart SDK. Therefore no Dart compilation, analyzer run, FFI rendering, or runtime regression suite is claimed here. The following non-Dart validation is performed before packaging:

```text
current v1.2 authority/hash validation
frozen Core source integrity
supplied production assets/fonts.zip validation
Protocol-v1.2 frozen release verification
Dart source structural/static audit
release-manifest verification
ZIP integrity
```

On a machine with Dart >= 3.3, run `./tools/run_dart_regression.sh` for the complete qualification. The runner includes `tools/v1_2_parser_regression.dart` for the normative 24-case v1.2 corpus and `tools/v1_2_profile_regression.dart` for the v1.2 profile/vector gate.
