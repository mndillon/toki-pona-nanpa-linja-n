# Testing the Dart v1.2.0 reference

## Full qualification

Requirements: Dart SDK 3.3+ and the native Linux Pango/PangoCairo, Cairo, Fontconfig and GObject libraries used by the production renderer.

Run:

```bash
./tools/run_dart_regression.sh
```

The runner is non-fail-fast and writes `test-output/dart-regression-report.txt`. It attempts these groups:

1. environment
2. current v1.2 conformance authority
3. Core-v1 source integrity
4. production assets
5. Protocol-v1.2 release integrity
6. static source audit
7. `dart pub get`
8. Dart compiler entry points
9. Dart analyzer
10. API surface
11. frozen Core-v1 regression
12. logical renderer smoke
13. production render-plan conformance
14. production PNG/SVG/PDF rendering
15. `astToText` / `parseNumber`
16. special glyphs and low-level rerender parity
17. canonical syntax and production adapters
18. canonical full renderer
19. Protocol v1.2 parser/renderer regression — 24 cases
20. Protocol v1.2 profile and vector output

## Focused Protocol v1.2 checks

```bash
dart run tools/v1_2_parser_regression.dart
dart run tools/v1_2_profile_regression.dart
```

The parser runner covers 10 full-stop cases, 12 direct CSP/UCSUR cases and 2 quote/backslash cases. Full-stop line breaking remains protected inside literal/quoted input, cartouches, long-pi/parentheses, braces and decimal numbers.

## Static-only validation

If Dart is unavailable:

```bash
./tools/run_static_validation.sh
```

This verifies current authority hashes, frozen-Core integrity, the exact supplied font bundle/manifest, Protocol release integrity and source-policy/structural invariants. It is not a substitute for Dart compilation or runtime qualification.

## Canonical corpus sizes

```text
Frozen Core-v1 checks                 1030
Protocol-v1.2 parser/renderer cases     24
NanpaParser smoke cases                 16
Canonical syntax cases                  28
Production adapter cases                 5
Canonical full-renderer cases          254
Production render plans                128
Production font pairs                    8
```
