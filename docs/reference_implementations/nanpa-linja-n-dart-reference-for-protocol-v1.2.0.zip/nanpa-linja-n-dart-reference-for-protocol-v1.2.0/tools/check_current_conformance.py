#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, sys

root = Path(__file__).resolve().parent.parent
expected = {
    'canonical_js': '6bfcb77e5177eec4d923bbd24d60dbac211e574b62e128e6dbfc07f8e859d220',
    'profile': '62d96529a5d857d6e146afc29433caf8709e9e28803e95d37ff3085468080a0f',
    'parser_regression': 'f926ed22ee2788bad6061e7f8df78a577b4ef03f75f348d9739225bbe3e10c89',
    'runtime_manifest': 'd8021c7e83d33b776a1e68c70d6adea11956ae88e5fff1baf67926dd1d6833f6',
    'protocol_manifest': '50b8a4b6cab0c27f2061f94e404a2af992cbf95c8097c58caa5e6b2dc4625f09',
    'core': 'e4baf51251861c114f5314fc2af05eb44e1b5dbcbdebdcd2678c868f5dbf306a',
}

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

checks = [
    ('canonical JavaScript', root/'reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js', expected['canonical_js']),
    ('v1.2 parser/renderer profile', root/'conformance/parser-renderer-profile-v1.2.0.json', expected['profile']),
    ('v1.2 parser/renderer regression corpus', root/'conformance/parser-renderer-regression-v1.2.0.json', expected['parser_regression']),
    ('runtime production font manifest', root/'rendering/production-font-pairs.manifest.json', expected['runtime_manifest']),
    ('Protocol-v1.2 production font manifest', root/'protocol/rendering/production-font-pairs.manifest.json', expected['protocol_manifest']),
    ('frozen Core corpus', root/'conformance/nanpa-linja-n-regression-v1.0.2.json', expected['core']),
]
errors=[]
for label,path,want in checks:
    if not path.is_file():
        errors.append(f'missing {label}: {path.relative_to(root)}')
        continue
    got=sha(path)
    if got != want:
        errors.append(f'{label} SHA-256 {got} != {want}')

profile=json.loads((root/'conformance/parser-renderer-profile-v1.2.0.json').read_text())
if profile.get('profileVersion') != '1.2.0': errors.append('profileVersion is not 1.2.0')
if len(profile.get('nanpaParserSmokeCases',[])) != 16: errors.append('NanpaParser smoke case count is not 16')
canonical=profile.get('canonicalJavaScript') or {}
if canonical.get('sha256') != expected['canonical_js']:
    errors.append('profile canonical JavaScript SHA-256 is not current v1.2 authority')

parser=json.loads((root/'conformance/parser-renderer-regression-v1.2.0.json').read_text())
if parser.get('protocolVersion') != '1.2.0': errors.append('parser regression protocolVersion is not 1.2.0')
if len(parser.get('cases',[])) != 24 or parser.get('caseCount') not in (None,24):
    errors.append('Protocol v1.2 parser regression case count is not 24')
if parser.get('canonicalJavaScriptSha256') != expected['canonical_js']:
    errors.append('Protocol v1.2 parser regression authority is not current JavaScript')

syntax=json.loads((root/'conformance/canonical-syntax-v1.0.1-phase1/cases.json').read_text())
if len(syntax.get('cases',[])) != 28: errors.append('canonical syntax case count is not 28')
if len(syntax.get('fontAdapterCases',[])) != 5: errors.append('canonical adapter case count is not 5')
if syntax.get('authority',{}).get('sha256') != expected['canonical_js']:
    errors.append('canonical syntax authority is not current v1.2 JavaScript')

full=json.loads((root/'conformance/full-renderer-canonical-v1.2.0/cases.json').read_text())
if len(full.get('cases',[])) != 254 or full.get('caseCount') not in (None,254):
    errors.append('full renderer v1.2 case count is not 254')
if full.get('authority',{}).get('sha256') != expected['canonical_js']:
    errors.append('full renderer authority is not current v1.2 JavaScript')

core=json.loads((root/'conformance/nanpa-linja-n-regression-v1.0.2.json').read_text())
if (len(core.get('parserCases',[])),len(core.get('rendererCases',[])),len(core.get('apiCases',[])),len(core.get('equivalenceGroups',[]))) != (320,15,9,8):
    errors.append('frozen Core corpus family counts differ from 320/15/9/8')

protocol=json.loads((root/'protocol/protocol.json').read_text())
version = protocol.get('version') or protocol.get('protocolVersion')
if version != '1.2.0': errors.append(f'protocol version is {version!r}, expected 1.2.0')

if errors:
    print('Current v1.2 conformance authority: FAIL')
    for e in errors: print(' -',e)
    sys.exit(1)
print('Current v1.2 conformance authority: PASS')
print('  canonical JS SHA-256:', expected['canonical_js'])
print('  Core-v1 corpus: 320 parser / 15 renderer / 9 API / 8 equivalence groups; 1030 checks')
print('  v1.2 profile: 16 NanpaParser smoke cases')
print('  v1.2 parser/renderer regression: 24 cases')
print('  canonical syntax: 28 cases + 5 adapter cases')
print('  canonical full renderer: 254 cases')
