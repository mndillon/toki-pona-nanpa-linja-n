import 'dart:convert';
import 'dart:io';

import 'package:nanpa_linja_n/nanpa_linja_n.dart';

List<dynamic> _list(Object? value) => value is List ? value : const <dynamic>[];
Map<String, dynamic> _map(Object? value) =>
    value is Map ? Map<String, dynamic>.from(value) : <String, dynamic>{};

String _cp(int value) => 'U+${value.toRadixString(16).toUpperCase().padLeft(4, '0')}';

bool _same(Object? a, Object? b) => jsonEncode(a) == jsonEncode(b);

String _cartoucheClass(FullRenderRun run) {
  if (run.numericCartouche) return 'number';
  if (run.sourceText.startsWith('"') && !run.sourceText.startsWith('""')) {
    return 'literal';
  }
  return 'ordinary';
}

Map<String, dynamic> _semanticLine(FullRenderLinePlan line) {
  final runs = line.runs;
  return <String, dynamic>{
    'elementKinds': runs.map((r) => r.kind).toList(growable: false),
    'canonicalCodepoints': <String>[
      for (final run in runs)
        for (final cp in run.canonicalCodepoints) _cp(cp),
    ],
    'literalTexts': <String>[
      for (final run in runs)
        if (run.kind == 'text') run.renderText,
    ],
    'cartoucheClasses': <String>[
      for (final run in runs)
        if (run.kind == 'cartouche') _cartoucheClass(run),
    ],
  };
}

void _compareAst(
  String id,
  DocumentAst got,
  Map<String, dynamic> want,
  List<String> failures,
) {
  if (got.normalizedInput != '${want['normalizedInput'] ?? ''}') {
    failures.add('$id AST.normalizedInput got=${jsonEncode(got.normalizedInput)} '
        'want=${jsonEncode(want['normalizedInput'])}');
  }
  final wantLines = _list(want['lines']);
  final wantCount = (want['lineCount'] as num?)?.toInt() ?? wantLines.length;
  if (got.lines.length != wantCount) {
    failures.add('$id AST.lineCount got=${got.lines.length} want=$wantCount');
    return;
  }
  for (var i = 0; i < got.lines.length && i < wantLines.length; i++) {
    final line = got.lines[i];
    final expected = _map(wantLines[i]);
    if (line.sourceText != '${expected['sourceText'] ?? ''}') {
      failures.add('$id AST.line[$i].sourceText got=${jsonEncode(line.sourceText)} '
          'want=${jsonEncode(expected['sourceText'])}');
    }
    final wantCanonical = expected['canonicalSourceText'];
    if (wantCanonical != null && line.canonicalSourceText != '$wantCanonical') {
      failures.add('$id AST.line[$i].canonicalSourceText '
          'got=${jsonEncode(line.canonicalSourceText)} want=${jsonEncode(wantCanonical)}');
    }
    if (wantCanonical == null && line.canonicalSourceText.isNotEmpty) {
      failures.add('$id AST.line[$i].canonicalSourceText unexpectedly '
          '${jsonEncode(line.canonicalSourceText)}');
    }
    final wantEncoding = expected['sourceEncoding'];
    if (wantEncoding != null && line.sourceEncoding != '$wantEncoding') {
      failures.add('$id AST.line[$i].sourceEncoding '
          'got=${jsonEncode(line.sourceEncoding)} want=${jsonEncode(wantEncoding)}');
    }
    if (wantEncoding == null && line.sourceEncoding.isNotEmpty) {
      failures.add('$id AST.line[$i].sourceEncoding unexpectedly '
          '${jsonEncode(line.sourceEncoding)}');
    }
    final wantSegments = _list(expected['segments']);
    if (line.children.length != wantSegments.length) {
      failures.add('$id AST.line[$i].segments.length '
          'got=${line.children.length} want=${wantSegments.length}');
      continue;
    }
    for (var j = 0; j < line.children.length; j++) {
      final segment = line.children[j];
      final expectedSegment = _map(wantSegments[j]);
      if (segment.kind != '${expectedSegment['kind']}') {
        failures.add('$id AST.line[$i].segment[$j].kind '
            'got=${segment.kind} want=${expectedSegment['kind']}');
      }
      if (expectedSegment.containsKey('value') &&
          segment.value != '${expectedSegment['value']}') {
        failures.add('$id AST.line[$i].segment[$j].value '
            'got=${jsonEncode(segment.value)} '
            'want=${jsonEncode(expectedSegment['value'])}');
      }
    }
  }
}

void main() {
  final root = File.fromUri(Platform.script).parent.parent;
  final corpus = jsonDecode(
    File('${root.path}/conformance/parser-renderer-regression-v1.2.0.json')
        .readAsStringSync(),
  ) as Map<String, dynamic>;
  final cases = _list(corpus['cases']);
  if (cases.length != 24 || (corpus['caseCount'] as num?)?.toInt() != 24) {
    throw StateError('Protocol v1.2 parser corpus must contain 24 cases');
  }

  final failures = <String>[];
  var passed = 0;
  final nanpa = NanpaLinjaN.create();

  for (final rawCase in cases) {
    final c = _map(rawCase);
    final id = '${c['id']}';
    final before = failures.length;
    try {
      final parser = _map(c['parserOptions']);
      final options = FullRenderOptions.fromMap(<String, dynamic>{
        'font': 'nasinNanpa',
        'parser': parser,
      });
      final plan = nanpa.buildFullRenderPlan('${c['input']}', options: options);
      final expected = _map(c['expected']);
      _compareAst(id, plan.ast, _map(expected['ast']), failures);

      final wantSemantic = _list(expected['semantic']);
      if (plan.lines.length != wantSemantic.length) {
        failures.add('$id semantic line count got=${plan.lines.length} '
            'want=${wantSemantic.length}');
      } else {
        for (var i = 0; i < plan.lines.length; i++) {
          final got = _semanticLine(plan.lines[i]);
          final want = _map(wantSemantic[i]);
          for (final key in const <String>[
            'elementKinds',
            'canonicalCodepoints',
            'literalTexts',
            'cartoucheClasses',
          ]) {
            if (!_same(got[key], want[key])) {
              failures.add('$id semantic[$i].$key '
                  'got=${jsonEncode(got[key])} want=${jsonEncode(want[key])}');
            }
          }
        }
      }
    } catch (error, stack) {
      failures.add('$id threw $error\n$stack');
    }
    if (failures.length == before) passed++;
  }

  print('Dart Protocol v1.2 parser/renderer regression: '
      '$passed/${cases.length} ${failures.isEmpty ? 'PASS' : 'FAIL'}');
  if (failures.isNotEmpty) {
    for (final failure in failures) {
      stderr.writeln('FAIL $failure');
    }
    exitCode = 1;
  }
}
