#!/usr/bin/env python3
from pathlib import Path
import re, sys
root=Path(__file__).resolve().parent.parent
errors=[]
# v1.2 production/full renderer sources must not actively select legacy ss12/13/14.
active=[root/'lib/src/production_font_adapters.dart',root/'lib/src/full_adapter.dart',root/'lib/src/full_renderer.dart']
for p in active:
    text=p.read_text()
    # Comments mentioning their intentional removal are allowed; string literals selecting them are not.
    for m in re.finditer(r"['\"]ss1[234]['\"]",text):
        errors.append(f'{p.relative_to(root)} active legacy stylistic-set string at offset {m.start()}')
# Required v1.2 code paths.
requirements={
 'lib/src/public_parser.dart':['enableBinaryParsing: false','enableHexParsing: false','abbreviateNumericCartouches: true'],
 'lib/src/full_types.dart':['this.enableBinaryParsing = false','this.enableBinaryRendering = false','this.enableHexParsing = false','this.abbreviateNumericCartouches = true'],
 'lib/src/production_font_adapters.dart':['vulgarScaleQuarter','numericCartoucheScaleMarker','renderCodepointsWithoutScaleMarkers'],
 'lib/src/full_adapter.dart':['asciiScaleAliases','scaleMarkers','adaptOrdinaryCartouche'],
 'lib/src/reference_version.dart':["referenceImplementationVersion = '1.2.0'","targetProtocolVersion = '1.2.0'"],
 'lib/src/full_document.dart':['canonicalSourceText','mixed-csp-unicode','_isBackslashEscapedAt','_canonicalizeCspUnicodeInputLine'],
 "lib/src/full_renderer.dart":['Protocol v1.2','forceOrdinary',"token.contains('.')"],
}
for rel,needles in requirements.items():
    text=(root/rel).read_text()
    for needle in needles:
        if needle not in text: errors.append(f'{rel} missing {needle!r}')
# Catch obvious delimiter damage using Pygments' Dart lexer. This is still
# only a structural audit; the Dart compiler remains the qualification authority.
try:
    from pygments import lex
    from pygments.lexers import DartLexer
    from pygments.token import Comment, String
    pairs = {')': '(', ']': '[', '}': '{'}
    for p in list((root/'lib').rglob('*.dart')) + list((root/'tools').glob('*.dart')):
        stack=[]
        for token_type, value in lex(p.read_text(), DartLexer()):
            if token_type in Comment or token_type in String:
                continue
            for ch in value:
                if ch in '([{': stack.append(ch)
                elif ch in ')]}':
                    if not stack or stack.pop() != pairs[ch]:
                        errors.append(f'{p.relative_to(root)} has structurally unbalanced delimiters')
                        stack=[]
                        break
        if stack:
            errors.append(f'{p.relative_to(root)} has structurally unbalanced delimiters')
except Exception as exc:
    errors.append(f'Pygments Dart structural audit failed: {exc}')
if errors:
    print('Dart static source audit: FAIL')
    for e in errors: print(' -',e)
    sys.exit(1)
print('Dart static source audit: PASS')
print('  v1.2 defaults/direct-CSP/full-stop/quote-parity paths present')
print('  no active ss12/ss13/ss14 feature string in production/full renderer sources')
print('  Dart source delimiters/quotes structurally balanced (compiler still required for qualification)')
