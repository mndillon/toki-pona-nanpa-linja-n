# Release notes — Dart reference v1.2.0

This release updates the native Dart reference from nanpa-linja-n Protocol v1.1.0 to **Protocol v1.2.0** while retaining the frozen Core-v1 numeric implementation and Production-Font-Profile-v1.1 behavior.

## Protocol v1.2 changes

- ordinary ASCII full stop maps to CSP middle dot U+F199C after numeric precedence;
- `breakLinesAtFullStops` respects quoted/literal input, cartouches, parentheses/long-pi, braces and decimals;
- direct recognized CSP/UCSUR document input is normalized to canonical textual parser input;
- normalized lines expose `canonicalSourceText` and `sourceEncoding`;
- quote closing uses odd/even consecutive-backslash parity;
- leading `""` forces an ordinary cartouche;
- canonical v1.2 parser/renderer, 24-case parser corpus and 254-case full-renderer corpus are bundled;
- `resources/fonts.zip` is the exact supplied archive for this release.

## Validation scope

Per the requested reduced build workflow, the full regression suite was not run while producing this archive. In addition, the build environment has no Dart SDK. Static authority/Core/font/protocol/source checks and package/archive integrity are performed; Dart compilation/analyzer/runtime tests must be run externally with `./tools/run_dart_regression.sh`.
