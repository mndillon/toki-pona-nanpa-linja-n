import 'dart:convert';
import 'dart:typed_data';

import 'constants.dart';
import 'full_types.dart';
import 'renderer.dart' as numeric_renderer;
import 'v11_numeric.dart';
import 'nasin_nanpa_pona.dart';

const List<List<String>> _fullAliases = <List<String>>[
  <String>["'cartouche-start'", '['],
  <String>["'cartouche-end'", ']'],
  <String>["'zw-joiner'", '&'],
  <String>["'stack-joiner'", '-'],
  <String>["'nesting-joiner'", '+'],
  <String>["'ideographic-space'", ' zz '],
  <String>["'long-start'", '('],
  <String>["'long-end'", ')'],
  <String>["'left-bracket'", ' te '],
  <String>["'right-bracket'", ' to '],
  <String>["'middle-dot'", '.'],
  <String>["'colon'", ':'],
  <String>["'tally'", ','],
];

String _normalizeDocument(String input, FullParserOptions options) {
  var out = input;
  if (options.effectiveRendererMode != 'standard-sitelen-pona-ascii-core') {
    for (final alias in _fullAliases) {
      out = out.replaceAll(alias[0], alias[1]);
    }
  }
  return out.replaceAll('\r\n', '\n').replaceAll('\r', '\n');
}

bool _isDigitCodeUnit(int c) => c >= 0x30 && c <= 0x39;
bool _isSpaceCodeUnit(int c) =>
    c == 0x20 || c == 0x09 || c == 0x0A || c == 0x0D;

bool _sentenceStop(String text, int index) {
  if (index < 0 || index >= text.length || text[index] != '.') return false;
  final prev = index > 0 ? text.codeUnitAt(index - 1) : 0;
  final next = index + 1 < text.length ? text.codeUnitAt(index + 1) : 0;
  final numeric = _isDigitCodeUnit(next) &&
      (_isDigitCodeUnit(prev) ||
          index == 0 ||
          _isSpaceCodeUnit(prev) ||
          '+-(,:='.codeUnits.contains(prev));
  return !numeric;
}

bool _isBackslashEscapedAt(String text, int index) {
  var count = 0;
  for (var i = index - 1; i >= 0 && text[i] == r'\'; i--) {
    count++;
  }
  return count.isOdd;
}

List<String> _splitFullStops(String line) {
  final out = <String>[];
  var start = 0;
  var square = 0;
  var paren = 0;
  var brace = 0;
  String? quoteOpen;
  var i = 0;
  while (i < line.length) {
    if (quoteOpen != null) {
      final ch = line[i];
      final close = (quoteOpen == '“' && (ch == '”' || ch == '"')) ||
          (quoteOpen == '"' && (ch == '"' || ch == '”'));
      if (close && !_isBackslashEscapedAt(line, i)) {
        quoteOpen = null;
      }
      i++;
      continue;
    }
    final ch = line[i];
    if (ch == '"' || ch == '“') {
      quoteOpen = ch;
      i++;
      continue;
    }
    switch (ch) {
      case '[':
        square++;
        i++;
        continue;
      case ']':
        if (square > 0) square--;
        i++;
        continue;
      case '(':
        paren++;
        i++;
        continue;
      case ')':
        if (paren > 0) paren--;
        i++;
        continue;
      case '{':
        brace++;
        i++;
        continue;
      case '}':
        if (brace > 0) brace--;
        i++;
        continue;
      case '.':
        if (square == 0 && paren == 0 && brace == 0 && _sentenceStop(line, i)) {
          var stop = i + 1;
          while (stop < line.length &&
              line[stop] == '.' &&
              _sentenceStop(line, stop)) {
            stop++;
          }
          out.add(line.substring(start, stop));
          start = stop;
          i = stop;
          continue;
        }
        break;
    }
    i++;
  }
  final tail = line.substring(start);
  if (tail.trim().isNotEmpty || out.isEmpty) out.add(tail);
  return out;
}

class _CspInputToken {
  final String kind;
  final String text;
  const _CspInputToken(this.kind, [this.text = '']);
}

String? _cspInputWordForCodepoint(int cp) {
  switch (cp) {
    case 0xF1989:
      return 'ni<';
    case 0xF198A:
      return 'ni^';
    case 0xF198B:
      return 'ni>';
    case 0xF198C:
      return 'sewi^';
    case 0xF19B4:
    case 0x300C:
      return 'te';
    case 0xF19B5:
    case 0x300D:
      return 'to';
    case 0x3000:
      return 'zz';
  }
  if ((cp >= 0xF1900 && cp <= 0xF1988) ||
      (cp >= 0xF19A0 && cp <= 0xF19A6)) {
    return allCodepointWords[cp];
  }
  return null;
}

_CspInputToken? _cspInputTokenForCodepoint(int cp) {
  final word = _cspInputWordForCodepoint(cp);
  if (word != null) return _CspInputToken('word', word);
  switch (cp) {
    case 0xF1990:
      return const _CspInputToken('cartoucheStart', '[');
    case 0xF1991:
      return const _CspInputToken('cartoucheEnd', ']');
    case 0xF1992:
      return const _CspInputToken('ignorableControl');
    case 0xF1993:
      return const _CspInputToken('deprecatedLongPiStart');
    case 0xF1994:
      return const _CspInputToken('deprecatedLongPiExtension');
    case 0xF1995:
      return const _CspInputToken('joiner', '-');
    case 0xF1996:
      return const _CspInputToken('joiner', '+');
    case 0xF1997:
      return const _CspInputToken('longStart', '(');
    case 0xF1998:
      return const _CspInputToken('longEnd', ')');
    case 0xF1999:
      return const _CspInputToken('ignorableControl');
    case 0xF199A:
      return const _CspInputToken('reverseStart', '{');
    case 0xF199B:
      return const _CspInputToken('reverseEnd', '}');
    case 0xF199C:
      return const _CspInputToken('middleDot', '.');
    case 0xF199D:
      return const _CspInputToken('colon', ':');
    case 0xF199E:
      return const _CspInputToken('tally', ',');
    case 0x200D:
      return const _CspInputToken('joiner', '&');
  }
  return null;
}

bool _containsRecognizedCspUnicodeInput(String text) {
  for (final cp in text.runes) {
    if (cp != 0x200D &&
        cp != 0x3000 &&
        cp != 0x300C &&
        cp != 0x300D &&
        !(cp >= 0xF1900 && cp <= 0xF19FF)) {
      continue;
    }
    if (_cspInputTokenForCodepoint(cp) != null) return true;
  }
  return false;
}

bool _cspTokenNeedsWordSeparator(_CspInputToken? left, _CspInputToken? right) {
  if (left == null || right == null) return false;
  if (left.kind == 'word' && right.kind == 'word') return true;
  if (<String>{'longEnd', 'cartoucheEnd', 'middleDot', 'tally'}.contains(left.kind)) {
    return right.kind == 'word';
  }
  return false;
}

String _serializeCspUnicodeTokenRun(List<_CspInputToken> tokens) {
  final filtered = tokens.where((t) => t.kind != 'ignorableControl').toList(growable: false);
  if (filtered.isEmpty) return '';

  if (filtered.first.kind == 'deprecatedLongPiStart') {
    final out = StringBuffer();
    _CspInputToken? prev;
    for (final token in filtered.skip(1)) {
      if (token.kind == 'deprecatedLongPiExtension') continue;
      if (_cspTokenNeedsWordSeparator(prev, token)) out.write(' ');
      out.write(token.text);
      prev = token;
    }
    return 'pi(${out.toString()})';
  }

  final out = StringBuffer();
  _CspInputToken? prev;
  for (final token in filtered) {
    if (token.kind == 'deprecatedLongPiExtension') {
      if (out.isNotEmpty && !out.toString().endsWith(' ')) out.write(' ');
      prev = null;
      continue;
    }
    if (token.kind == 'colon') {
      final current = out.toString();
      if (out.isNotEmpty && !current.endsWith(' ') && !current.endsWith('[')) {
        out.write(' ');
      }
      out.write(':');
      prev = token;
      continue;
    }
    if (prev?.kind == 'colon') {
      if (out.isNotEmpty && !out.toString().endsWith(' ')) out.write(' ');
    } else if (_cspTokenNeedsWordSeparator(prev, token)) {
      if (out.isNotEmpty && !out.toString().endsWith(' ')) out.write(' ');
    }
    out.write(token.text);
    prev = token;
  }
  return out.toString();
}

bool _cspBoundaryNeedsSpace(String left, String right) {
  if (left.isEmpty || right.isEmpty) return false;
  final lr = left.runes.last;
  final rr = right.runes.first;
  bool wordLike(int r) =>
      (r >= 0x41 && r <= 0x5A) ||
      (r >= 0x61 && r <= 0x7A) ||
      (r >= 0x30 && r <= 0x39) ||
      '_^<>'.runes.contains(r);
  return wordLike(lr) && wordLike(rr);
}

int _findProtectedQuotedEndRunes(List<int> runes, int start) {
  if (start < 0 ||
      start >= runes.length ||
      (runes[start] != 0x22 && runes[start] != 0x201C)) {
    return -1;
  }
  final open = runes[start];
  for (var j = start + 1; j < runes.length; j++) {
    final ch = runes[j];
    final isClose = (open == 0x201C && (ch == 0x201D || ch == 0x22)) ||
        (open == 0x22 && (ch == 0x22 || ch == 0x201D));
    if (!isClose) continue;
    var count = 0;
    for (var k = j - 1; k >= 0 && runes[k] == 0x5C; k--) count++;
    if (count.isEven) return j + 1;
  }
  return -1;
}

int _findProtectedImgEndRunes(List<int> runes, int start) {
  const imgPrefix = <int>[0x69, 0x6D, 0x67, 0x28];
  if (start < 0 || start + imgPrefix.length > runes.length) return -1;
  for (var i = 0; i < imgPrefix.length; i++) {
    if (runes[start + i] != imgPrefix[i]) return -1;
  }
  var depth = 1;
  int? quote;
  var escaped = false;
  for (var j = start + 4; j < runes.length; j++) {
    final ch = runes[j];
    if (escaped) {
      escaped = false;
      continue;
    }
    if (ch == 0x5C) {
      escaped = true;
      continue;
    }
    if (quote != null) {
      if (ch == quote) quote = null;
      continue;
    }
    if (ch == 0x22 || ch == 0x27) {
      quote = ch;
      continue;
    }
    if (ch == 0x28) {
      depth++;
    } else if (ch == 0x29) {
      depth--;
      if (depth == 0) return j + 1;
    }
  }
  return -1;
}

({bool changed, String canonical}) _canonicalizeCspUnicodeInputLine(
  String source,
  FullParserOptions options,
) {
  if (source.isEmpty || !_containsRecognizedCspUnicodeInput(source)) {
    return (changed: false, canonical: source);
  }
  final pieces = <({String kind, String text})>[];
  final runes = source.runes.toList(growable: false);
  final interpretedQuotes = options.interpretDoubleQuotesAsTeTo;

  var i = 0;
  while (i < runes.length) {
    if (!interpretedQuotes && (runes[i] == 0x22 || runes[i] == 0x201C)) {
      final end = _findProtectedQuotedEndRunes(runes, i);
      if (end > i) {
        pieces.add((kind: 'raw', text: String.fromCharCodes(runes.sublist(i, end))));
        i = end;
        continue;
      }
    }
    final imgEnd = _findProtectedImgEndRunes(runes, i);
    if (imgEnd > i) {
      pieces.add((kind: 'raw', text: String.fromCharCodes(runes.sublist(i, imgEnd))));
      i = imgEnd;
      continue;
    }
    final first = _cspInputTokenForCodepoint(runes[i]);
    if (first == null) {
      pieces.add((kind: 'raw', text: String.fromCharCode(runes[i])));
      i++;
      continue;
    }
    final tokens = <_CspInputToken>[first];
    var j = i + 1;
    while (j < runes.length) {
      final token = _cspInputTokenForCodepoint(runes[j]);
      if (token == null) break;
      tokens.add(token);
      j++;
    }
    final converted = _serializeCspUnicodeTokenRun(tokens);
    if (converted.isNotEmpty) pieces.add((kind: 'converted', text: converted));
    i = j;
  }

  final out = StringBuffer();
  for (var n = 0; n < pieces.length; n++) {
    final piece = pieces[n];
    if (n > 0) {
      final prev = pieces[n - 1];
      if (prev.kind != piece.kind &&
          _cspBoundaryNeedsSpace(prev.text, piece.text) &&
          !out.toString().endsWith(' ')) {
        out.write(' ');
      }
    }
    out.write(piece.text);
  }
  final canonical = out.toString();
  return (changed: canonical != source, canonical: canonical);
}

List<String> _splitArgs(String input) {
  final out = <String>[];
  final current = StringBuffer();
  String? quote;
  var escaped = false;
  var depth = 0;
  for (var i = 0; i < input.length; i++) {
    final ch = input[i];
    if (escaped) {
      current.write(ch);
      escaped = false;
      continue;
    }
    if (ch == r'\') {
      current.write(ch);
      escaped = true;
      continue;
    }
    if (quote != null) {
      current.write(ch);
      if (ch == quote) quote = null;
      continue;
    }
    if (ch == "'" || ch == '"') {
      quote = ch;
      current.write(ch);
      continue;
    }
    if (ch == '(') {
      depth++;
      current.write(ch);
      continue;
    }
    if (ch == ')' && depth > 0) {
      depth--;
      current.write(ch);
      continue;
    }
    if (ch == ',' && depth == 0) {
      out.add(current.toString().trim());
      current.clear();
      continue;
    }
    current.write(ch);
  }
  out.add(current.toString().trim());
  return out;
}

String _stripQuotes(String value) {
  final s = value.trim();
  if (s.length >= 2 &&
      ((s.startsWith("'") && s.endsWith("'")) ||
          (s.startsWith('"') && s.endsWith('"')))) {
    return s.substring(1, s.length - 1);
  }
  return s;
}

ImageDescriptor _parseImageArgs(String arg) {
  var src = '';
  var width = '';
  var height = '';
  var alt = '';
  var vAlign = 'baseline';
  var wriggle = 8.0;
  var transparent = true;
  for (final part in _splitArgs(arg)) {
    if (part.isEmpty) continue;
    final at = part.indexOf('=');
    if (at < 0) continue;
    final key = part.substring(0, at).trim().toLowerCase();
    final value = _stripQuotes(part.substring(at + 1));
    switch (key) {
      case 'src':
        src = value;
        break;
      case 'w':
      case 'width':
        width = value;
        break;
      case 'h':
      case 'height':
        height = value;
        break;
      case 'alt':
        alt = value;
        break;
      case 'valign':
        vAlign = value;
        break;
      case 'wriggle':
        wriggle = double.tryParse(value) ?? wriggle;
        break;
      case 'transparent':
        final v = value.toLowerCase();
        transparent = !(v == 'false' || v == '0' || v == 'no');
        break;
    }
  }
  return ImageDescriptor(
    src: src,
    width: width,
    height: height,
    alt: alt,
    vAlign: vAlign,
    wriggle: wriggle,
    transparent: transparent,
  );
}

List<DocumentSegment> _segments(String line) {
  final out = <DocumentSegment>[];
  var i = 0;
  var start = 0;

  void pushText(int a, int b) {
    if (b > a) {
      out.add(DocumentSegment(
        kind: 'text',
        value: line.substring(a, b),
        sourceStart: a,
        sourceEnd: b,
      ));
    }
  }

  while (i < line.length) {
    final ch = line[i];
    if (ch == '[') {
      final end = line.indexOf(']', i + 1);
      if (end < 0) break;
      pushText(start, i);
      out.add(DocumentSegment(
        kind: 'bracket',
        value: line.substring(i + 1, end),
        sourceStart: i,
        sourceEnd: end + 1,
      ));
      i = end + 1;
      start = i;
      continue;
    }
    if (ch == '"') {
      var j = i + 1;
      var found = -1;
      while (j < line.length) {
        if (line[j] == '"' && !_isBackslashEscapedAt(line, j)) {
          found = j;
          break;
        }
        j++;
      }
      if (found < 0) break;
      pushText(start, i);
      out.add(DocumentSegment(
        kind: 'quote',
        value: line.substring(i + 1, found),
        openQuote: '"',
        closeQuote: '"',
        sourceStart: i,
        sourceEnd: found + 1,
      ));
      i = found + 1;
      start = i;
      continue;
    }
    if (ch == '“') {
      var j = i + 1;
      var found = -1;
      var closeQuote = '”';
      while (j < line.length) {
        if ((line[j] == '”' || line[j] == '"') && !_isBackslashEscapedAt(line, j)) {
          found = j;
          closeQuote = line[j];
          break;
        }
        j++;
      }
      if (found < 0) break;
      pushText(start, i);
      out.add(DocumentSegment(
        kind: 'quote',
        value: line.substring(i + 1, found),
        openQuote: '“',
        closeQuote: closeQuote,
        sourceStart: i,
        sourceEnd: found + 1,
      ));
      i = found + 1;
      start = i;
      continue;
    }
    if (line.startsWith('img(', i)) {
      var j = i + 4;
      var depth = 1;
      String? quote;
      var escaped = false;
      while (j < line.length) {
        final c = line[j];
        if (escaped) {
          escaped = false;
          j++;
          continue;
        }
        if (c == r'\') {
          escaped = true;
          j++;
          continue;
        }
        if (quote != null) {
          if (c == quote) quote = null;
          j++;
          continue;
        }
        if (c == "'" || c == '"') {
          quote = c;
          j++;
          continue;
        }
        if (c == '(') {
          depth++;
        } else if (c == ')') {
          depth--;
          if (depth == 0) break;
        }
        j++;
      }
      if (j >= line.length) break;
      pushText(start, i);
      out.add(DocumentSegment(
        kind: 'image',
        image: _parseImageArgs(line.substring(i + 4, j)),
        sourceStart: i,
        sourceEnd: j + 1,
      ));
      i = j + 1;
      start = i;
      continue;
    }
    i++;
  }
  pushText(start, line.length);
  return out;
}

DocumentAst parseFullDocument(String input, FullParserOptions options) {
  final normalized = _normalizeDocument(input, options);
  final lines = <DocumentLine>[];
  final sourceLines = normalized.split('\n');
  for (var sourceLineIndex = 0;
      sourceLineIndex < sourceLines.length;
      sourceLineIndex++) {
    final source = sourceLines[sourceLineIndex];
    final rendered = options.breakLinesAtFullStops
        ? _splitFullStops(source)
        : <String>[source];
    for (var sentenceIndex = 0;
        sentenceIndex < rendered.length;
        sentenceIndex++) {
      final sourceText = rendered[sentenceIndex];
      final canonicalized = _canonicalizeCspUnicodeInputLine(sourceText, options);
      final parsedSource = canonicalized.canonical;
      lines.add(DocumentLine(
        index: lines.length,
        sourceLineIndex: sourceLineIndex,
        sentenceIndexInSourceLine: sentenceIndex,
        sourceText: sourceText,
        canonicalSourceText: canonicalized.changed ? parsedSource : '',
        sourceEncoding: canonicalized.changed ? 'mixed-csp-unicode' : '',
        children: _segments(parsedSource),
      ));
    }
  }
  return DocumentAst(
    normalizedInput: normalized,
    breakLinesAtFullStops: options.breakLinesAtFullStops,
    parserOptions: options,
    lines: List<DocumentLine>.unmodifiable(lines),
  );
}

String _quoteImageArgument(String value) {
  if (!value.contains("'")) return "'${value}'";
  if (!value.contains('"')) return '"${value}"';
  final escaped = value.replaceAll(r'\', r'\\').replaceAll('"', r'\"');
  return '"$escaped"';
}

String _imageDescriptorToText(ImageDescriptor image) {
  final args = <String>[];
  if (image.src.isNotEmpty) args.add('src=${_quoteImageArgument(image.src)}');
  if (image.width.isNotEmpty) args.add('w=${_quoteImageArgument(image.width)}');
  if (image.height.isNotEmpty) args.add('h=${_quoteImageArgument(image.height)}');
  args.add('alt=${_quoteImageArgument(image.alt)}');
  if (image.vAlign.isNotEmpty && image.vAlign != 'baseline') {
    args.add('valign=${_quoteImageArgument(image.vAlign)}');
  }
  if (image.wriggle != 8) args.add('wriggle=${image.wriggle}');
  if (!image.transparent) args.add('transparent=false');
  return 'img(${args.join(',')})';
}

String _documentSegmentToText(DocumentSegment segment) {
  switch (segment.kind) {
    case 'text':
      return segment.value;
    case 'bracket':
      return '[${segment.value}]';
    case 'quote':
      final openQuote = segment.openQuote.isEmpty ? '"' : segment.openQuote;
      final closeQuote = segment.closeQuote.isEmpty
          ? (openQuote == '“' ? '”' : '"')
          : segment.closeQuote;
      return '$openQuote${segment.value}$closeQuote';
    case 'image':
      final image = segment.image;
      if (image == null) {
        throw ArgumentError('image AST segment requires an ImageDescriptor.');
      }
      return _imageDescriptorToText(image);
    case 'rawUcsur':
      final out = <String>[];
      for (final cp in segment.codepoints) {
        if (cp < 0 || cp > 0x10FFFF || (cp >= 0xD800 && cp <= 0xDFFF)) {
          throw ArgumentError('rawUcsur AST segment contains an invalid Unicode scalar: $cp');
        }
        out.add('U+${cp.toRadixString(16).toUpperCase().padLeft(4, '0')}');
      }
      return out.join(' ');
    default:
      throw ArgumentError('Unsupported AST segment kind: ${segment.kind}');
  }
}

/// Converts a document AST returned by [parseFullDocument] or the high-level
/// `NanpaLinjaN.parseInput()` facade back into valid nanpa-linja-n source text.
///
/// With the default `numericOutput: "source"`, current AST content is serialized
/// exactly as before. When numeric span metadata is present, `properName`, `#~`,
/// and `cartouche` request canonical numeric re-serialization through the existing
/// numeric parser/renderer. Unsupported representations preserve the exact source.
String _numericOutputMode(FullRenderOptions? options) {
  final mode = (options?.numericOutput ?? 'source').trim();
  if (!const <String>{'source', 'properName', '#~', 'cartouche'}.contains(mode)) {
    throw ArgumentError('Unsupported numericOutput mode: $mode');
  }
  return mode;
}

String _numericSourceToText(
  String source,
  String mode,
  FullParserOptions parser,
) {
  if (mode == 'source') return source;
  final coreRendered = numeric_renderer.renderNumber(source, parser.numericOptions());
  if (coreRendered == null) return source;
  final rendered = normalizeV11RenderResult(coreRendered);
  final parsed = rendered.parsed;

  if (parser.nasinNanpaPona) {
    final words = tryPlainDecimalToNasinNanpaPonaWords(parsed.displayValue);
    if (words != null && words.isNotEmpty) return words.join(' ');
  }

  switch (mode) {
    case 'properName':
      return parsed.properName.isNotEmpty ? parsed.properName : source;
    case '#~':
      return parsed.uniqueCode.startsWith('#~') ? parsed.uniqueCode : source;
    case 'cartouche':
      final words = parser.abbreviateNumericCartouches
          ? rendered.abbreviatedWords
          : rendered.fullWords;
      return words != null && words.isNotEmpty
          ? '[${words.join(' ')}]'
          : source;
  }
  return source;
}

String _applyNumericStructures(
  String source,
  DocumentSegment segment,
  String mode,
  FullParserOptions parser,
) {
  if (mode == 'source' || segment.numericStructures.isEmpty) return source;
  final structures = List<NumericStructure>.from(segment.numericStructures)
    ..sort((a, b) {
      final byStart = a.index.compareTo(b.index);
      return byStart != 0 ? byStart : a.end.compareTo(b.end);
    });
  final out = StringBuffer();
  var position = 0;
  var replaced = false;
  for (final structure in structures) {
    if (structure.index < 0 ||
        structure.end <= structure.index ||
        structure.end > source.length ||
        structure.index < position) {
      continue;
    }
    // Numeric metadata is deliberately additive. If a caller edits the AST text
    // without rebuilding metadata, preserve the edit instead of rewriting it.
    if (source.substring(structure.index, structure.end) != structure.sourceText) {
      continue;
    }
    out.write(source.substring(position, structure.index));
    out.write(_numericSourceToText(structure.sourceText, mode, parser));
    position = structure.end;
    replaced = true;
  }
  if (!replaced) return source;
  out.write(source.substring(position));
  return out.toString();
}

String astToText(DocumentAst ast, [FullRenderOptions? options]) {
  final mode = _numericOutputMode(options);
  final parser = options?.parser ?? ast.parserOptions;
  final out = StringBuffer();
  int? previousSourceLineIndex;
  var havePrevious = false;

  for (var i = 0; i < ast.lines.length; i++) {
    final line = ast.lines[i];
    final currentSourceLineIndex =
        line.sourceLineIndex >= 0 ? line.sourceLineIndex : i;
    if (havePrevious && currentSourceLineIndex != previousSourceLineIndex) {
      out.write('\n');
    }
    for (final segment in line.children) {
      final source = _documentSegmentToText(segment);
      out.write(_applyNumericStructures(source, segment, mode, parser));
    }
    havePrevious = true;
    previousSourceLineIndex = currentSourceLineIndex;
  }
  return out.toString();
}

final RegExp _rawUnicode = RegExp(
  r'^U\+([0-9A-Fa-f]{4,6})$',
  caseSensitive: false,
);

List<int>? parseRawUnicodeSequence(String text) {
  final tokens = text.trim().split(RegExp(r'\s+'));
  if (tokens.isEmpty || (tokens.length == 1 && tokens.first.isEmpty)) return null;
  final out = <int>[];
  for (final token in tokens) {
    final m = _rawUnicode.firstMatch(token);
    if (m == null) return null;
    final value = int.tryParse(m.group(1)!, radix: 16);
    if (value == null || value > 0x10FFFF) return null;
    out.add(value);
  }
  return out;
}

Uint8List? decodeDataImage(String src) {
  if (!src.startsWith('data:image/')) return null;
  final comma = src.indexOf(',');
  if (comma < 0) return null;
  final meta = src.substring(0, comma);
  final data = src.substring(comma + 1);
  try {
    if (meta.contains(';base64')) return base64Decode(data);
    return Uint8List.fromList(utf8.encode(Uri.decodeComponent(data)));
  } catch (_) {
    return null;
  }
}
