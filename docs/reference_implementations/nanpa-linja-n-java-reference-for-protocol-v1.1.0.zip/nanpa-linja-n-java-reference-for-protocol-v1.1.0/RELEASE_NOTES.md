# nanpa-linja-n Java reference — Protocol v1.1.0

This release upgrades the native Java 21 reference implementation to Protocol v1.1.0 while retaining the frozen Core-v1 conformance corpus.

Key v1.1 changes:

- public high-level defaults now match Parser-Renderer-Profile-v1.1;
- frozen Core-v1 API/conformance behavior remains intact;
- decimal public `parseNumber` results expose the canonical v1.1 shape while abbreviation/NNP transformations remain available through `astToText`;
- yearless `--MM-DD` public rendering normalizes the separator to `kasi`;
- whitespace terminates decimal numeric constructs;
- mixed-fraction abbreviation preserves semantic `kin`;
- current eight-font production manifest and exact `fonts.zip` are bundled;
- inline `¼`, `⅓`, `½`, `⅔`, `¾` cartouche scaling and approved ASCII aliases are supported;
- automatic legacy `ss12`/`ss13`/`ss14` scaling selection is disabled;
- outside-cartouche U+002C comma is preserved as the canonical ASCII word run;
- literal-cartouche compatibility alias resolves to the bundled Liberation Sans support font;
- SVG and PDF exports are vector; PDF release checks reject raster Image XObjects for generated numeric content.

Qualification: `./tools/run_java_regression.sh` passes 14/14 configured suites on OpenJDK 21.0.11.
