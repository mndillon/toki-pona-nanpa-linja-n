#!/usr/bin/env python3
import hashlib,json,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def sha(p):
 h=hashlib.sha256(); h.update(Path(p).read_bytes()); return h.hexdigest()

def check(ok,msg,errs):
 print(('PASS ' if ok else 'FAIL ')+msg)
 if not ok: errs.append(msg)

def main():
 e=[]
 checks={
  'reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js':'fdeb3e3bfd46b9f86650fd411a2d1dfb2515580aa258aa8c11a002913631418c',
  'resources/fonts.zip':'08d0409e0b180a6b90a0617fe557fd3e59a08dd26781d907ed5d772a9fefcae1',
  'conformance/parser-renderer-profile-v1.1.0.json':'009ecab501a57c1b64fd1ff1f9fac50b072aecb706a162970b1f17c0cc45338b',
  'rendering/production-font-pairs.manifest.json':'50b8a4b6cab0c27f2061f94e404a2af992cbf95c8097c58caa5e6b2dc4625f09',
 }
 for rel,want in checks.items():
  p=ROOT/rel; check(p.is_file() and sha(p)==want,f'authority SHA-256 {rel}',e)
 prof=json.loads((ROOT/'conformance/parser-renderer-profile-v1.1.0.json').read_text())
 check(len(prof.get('nanpaParserSmokeCases',[]))==16,'Parser-Renderer-Profile-v1.1 has 16 smoke cases',e)
 syn=json.loads((ROOT/'conformance/canonical-syntax-v1.0.1-phase1/cases.json').read_text())
 check(len(syn.get('cases',[]))==28,'canonical syntax has 28 cases',e)
 full=json.loads((ROOT/'conformance/full-renderer-canonical-v1.1.0/cases.json').read_text())
 check(len(full.get('cases',[]))==254,'canonical full renderer has 254 cases',e)
 plan=json.loads((ROOT/'fixtures/render-facade-plan-goldens-v1.1.0.json').read_text())
 cases=plan.get('cases') or plan.get('logicalCases') or []
 check(len(cases)==16,'render-plan fixture has 16 logical cases',e)
 man=json.loads((ROOT/'rendering/production-font-pairs.manifest.json').read_text())
 pairs=man.get('pairs') or man.get('fonts') or man.get('fontPairs') or []
 check(len(pairs)==8,'production manifest has 8 font pairs',e)
 main='\n'.join(p.read_text(errors='ignore') for p in (ROOT/'src/main/java').rglob('*.java'))
 check(not re.search(r'"ss1[234]"',main),'no active ss12/ss13/ss14 string literal in production Java',e)
 check('/Subtype /Image' not in (ROOT/'src/main/java/com/nanpalinjan/FullRenderer.java').read_text(),'FullRenderer source has no raster PDF Image XObject marker',e)
 check('1.1.0' in (ROOT/'pom.xml').read_text(),'Maven package version targets 1.1.0',e)
 total=12
 print(f'Java v1.1 release source/authority checks: {total-len(e)}/{total} PASS' + ('' if not e else f'; failures={len(e)}'))
 return 1 if e else 0
if __name__=='__main__': sys.exit(main())
