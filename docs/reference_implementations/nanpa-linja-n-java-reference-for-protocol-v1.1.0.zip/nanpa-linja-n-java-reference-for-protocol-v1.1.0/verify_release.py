#!/usr/bin/env python3
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
MANIFEST=ROOT/'RELEASE-MANIFEST.json'
EXCLUDED_DIRS={'target','test-output','__pycache__'}
EXCLUDED_FILES={'RELEASE-MANIFEST.json'}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()
def shipped():
 out=[]
 for p in ROOT.rglob('*'):
  if not p.is_file(): continue
  relp=p.relative_to(ROOT); rel=relp.as_posix()
  if set(relp.parts[:-1]) & EXCLUDED_DIRS: continue
  if p.name.endswith('.pyc') or rel in EXCLUDED_FILES: continue
  out.append(rel)
 return sorted(out)
def main():
 if not MANIFEST.is_file(): print('FAIL: RELEASE-MANIFEST.json missing'); return 1
 d=json.loads(MANIFEST.read_text()); exp=d.get('files') or {}; act=shipped()
 if act!=sorted(exp):
  print('FAIL release file-set mismatch')
  print(' missing-from-manifest:',sorted(set(act)-set(exp)))
  print(' stale-in-manifest:',sorted(set(exp)-set(act)))
  return 1
 bad=[]
 for rel in act:
  got=sha(ROOT/rel); want=exp[rel]
  if got!=want: bad.append((rel,want,got))
 if bad:
  print(f'FAIL {len(bad)} release file hash mismatch(es)')
  for x in bad[:20]: print(' ',*x)
  return 1
 print(f'PASS {len(act)}/{len(exp)} shipped files verified')
 print('PASS Java reference target: Protocol v1.1.0')
 print('QUALIFICATION:',d.get('qualificationStatus'))
 return 0
if __name__=='__main__': sys.exit(main())
