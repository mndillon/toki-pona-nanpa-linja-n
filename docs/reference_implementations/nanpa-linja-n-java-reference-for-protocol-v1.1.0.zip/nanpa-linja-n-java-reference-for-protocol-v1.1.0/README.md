# nanpa-linja-n Java reference implementation

Independent **Java 21** reference implementation for **nanpa-linja-n Protocol v1.1.0**. It preserves the frozen Core-v1 numeric API and implements the integrated v1.1 parser/renderer and production-font profile natively in Java.

Protocol v1.1.0 retains the frozen Core-v1 corpus and layers the normative Parser-Renderer-Profile-v1.1 plus Production-Font-Profile-v1.1 above it. Historical v1.0 candidate/reference material retained under `references/` or older conformance directories is evidence only and is not a v1.1 release gate. The Java implementation does **not** execute JavaScript, Node, a browser, Python, Go, Rust, Dart, or another reference implementation during normal rendering or regression.

## Scope

The Java implementation preserves the existing Core-v1 behavior and adds a Java-native production rendering layer:

- all 35 frozen Core-v1 operations;
- parser/conversion behavior for decimal, time, date, telephone, hexadecimal, binary, fractions, scientific notation, proper names, identifiers, CAPS and UCSUR;
- logical full and abbreviated cartouche rendering;
- production font-pair registry using the same eight-pair manifest as the JavaScript reference;
- font-key/label/family alias lookup;
- Java-native `BufferedImage` canvas equivalent;
- PNG raster output;
- SVG vector-path output;
- PDF vector-path output;
- production render-plan metadata including numeric cartouche role, opener/closer, numeric base, adapter id and size-profile feature selection;
- legacy `linjaPona` / `linjaSike` native ligature adaptation for numeric cartouches, including Java2D kerning required for joined cartouche rules;
- actual `ss12` / `ss13` OpenType single-substitution application from the pinned companion fonts;
- the 16-case full/abbreviated production matrix over all eight production pairs (128 render cases);
- ordinary cartouche rendering through the base sitelen font, including manifest-driven `manual` vs `ucsur` tally modes;
- JavaScript-compatible legacy ordinary-cartouche adapters for `linjaPona` and `linjaSike`;
- renderer-drawn manual tallies for `nasinNanpa`, `linjaPona`, `linjaSike`, `nasinSitelenPuMono`, and `linjaLipamanka`;
- halo rendering, including renderer-drawn tally halo backing;
- a 128-case geometry comparison against the supplied JavaScript reference running in headless Chromium (tolerance: +/-1 px);
- full document AST segmentation for text, bracket cartouches, quotes, inline images, physical lines, and optional full-stop line splitting;
- mixed ordinary text + ordinary cartouches + numeric cartouches + literal/interpreted quotes in one document;
- Standard Sitelen Pona ASCII Core, SPA Extended, and sitelen seli kiwen renderer modes covered by the full-renderer parity corpus;
- current JavaScript canonical syntax including `&` compounds, Core/extended long-glyph forms, `te`/`to`/`zz`, `ni01`–`ni04`, `sewi01`/`sewi02`, literal/ordinary/compound cartouches, and raw UCSUR spans;
- current full-renderer numeric scanning including leading `+`, percentages, vulgar and mixed vulgar fractions, embedded numeric spans, Toki Pona numeric phrases, proper-name numeric prefixes, glyph+numeric suffixes, and independent binary parsing/rendering flags;
- production whole-word adapters for `linjaPona`, `linjaSike`, `nasinSitelenPuMono`, and `linjaLipamanka`;
- raw `U+...` rendering, renderer aliases, unknown-text handling, and automatic standalone proper-name cartouches;
- multiline alignment and spacing controls, custom fill, halo, font-size layout, and inline images;
- low-level run/text/UCSUR rendering entry points and runtime render-adapter registration;
- a Java-native vector-document representation used by SVG/PDF-capable rendering;
- current JavaScript-derived canonical qualification: 28/28 syntax cases, 5/5 production font-adapter cases, 254/254 full-renderer semantic cases, and 346/346 mixed-feature interaction cases;
- 64/64 frozen canonical-browser semantic parity cases, 20/20 full-renderer operation checks, and 38/38 Full Renderer Profile feature areas.

The high-level facade intentionally mirrors the JavaScript facade at the platform-appropriate level. Browser-only machinery such as DOM `Canvas`, `FontFace`, IndexedDB and browser event/storage controllers is represented by Java-native equivalents rather than emulated browser APIs.

## v1.1.0 qualification status

The packaged non-fail-fast regression runner passes **14/14 configured suites** on OpenJDK 21.0.11. Current release gates cover the frozen 1030-check Core-v1 corpus, 35-operation Core API surface, 28 canonical syntax cases plus 5 production adapters, 254 canonical full-renderer cases, 128 production render-plan cases, 128 SVG vector cases, PNG/PDF production-font smoke across all 8 pairs, ordinary cartouche inline scaling/tally routing, and the 16-case Parser-Renderer-Profile-v1.1 smoke suite.

Public v1.1 defaults use uniform numeric mode, relaxed parsing/rendering, nanpa-format parsing/rendering, abbreviated numeric cartouches, no preserved abbreviation breaks, and hex/binary parsing disabled unless explicitly enabled. Current production scaling uses inline vulgar-fraction controls; automatic `ss12`/`ss13`/`ss14` selection is not used.

## Requirements

- JDK **21**
- all eight production **base + companion** font pairs named by `rendering/production-font-pairs.manifest.json` for full production-rendering qualification
- Maven 3.9+ is optional; the primary regression command uses only `javac` and `java`

The source archive contains one canonical production font source: `resources/fonts.zip`. The Java runtime reads its manifest and font binaries directly from that ZIP.

## Full regression

```bash
export NANPA_FONT_ZIP=/path/to/fonts.zip
./tools/run_java_regression.sh
```

The full runner is deliberately **non-fail-fast**. Every configured suite is attempted even when an earlier suite fails. Stdout/stderr and each suite exit code are collected into:

```text
test-output/java-regression-report.txt
```

Only after all suites have run does the launcher return a non-zero status if one or more suites failed. This behavior is regression-tested by injecting a deterministic canonical-syntax failure and confirming that all later suites still execute.

The script compiles into a temporary directory and removes all compiled classes on exit. It does not leave `.class`, `.jar`, or `target/` artifacts in the source tree. Full production qualification requires all eight production base+companion font pairs. If the fonts are missing, Core suites still run and font-dependent suites are recorded as failures instead of terminating the runner immediately.

The current qualification matrix includes:

- Java 21 environment and complete-source compilation;
- 35/35 Core-v1 public API smoke checks;
- `astToText` 8/8 source-preserving regression cases plus 1/1 render integration;
- 48/48 focused current-baseline checks for `parseNumber`, options-aware `astToText`, numeric whitespace boundaries, mixed fractions, nasin nanpa pona metadata, and `te`/`to` adapter routing;
- 320/320 parser, 15/15 renderer, and 9/9 auxiliary API corpus cases;
- 75/75 equivalence comparisons and **1,030/1,030** current frozen Core-v1 corpus checks;
- current JavaScript-derived canonical syntax: **28/28**;
- production font adapters: **5/5**;
- current JavaScript-derived full-renderer semantic corpus: **254/254**;
- mixed-feature JavaScript differential corpus: **346/346**, including 132 synthetic `te`/`to` geometry checks, 53 `zz` one-em advance checks, 811 no-replacement-glyph run checks, and 57 production PNG smoke cases;
- structural browser-renderer parity: 10/10;
- production render-plan and SVG matrices: 128/128 each;
- Chromium geometry parity: 128/128 within +/-1 px;
- OpenType `ss12`/`ss13` geometry: 32/32;
- PNG/PDF smoke across all 8 production font pairs;
- ordinary-cartouche/tally/halo routing and 32/32 Chromium ordinary-cartouche adapter cases;
- legacy Full Renderer Profile: 64/64 semantic cases, 20/20 operations, 9/9 vector cases, 38/38 feature areas, and 3040 assertions.

A successful run ends with:

```text
=== CONSOLIDATED SUMMARY ===
...
configured suites: 15
passed suites: 15
failed suites: 0
ALL CONFIGURED JAVA TESTS PASS
```

Core-only regression, when production font assets are intentionally unavailable:

```bash
./tools/run_java_core_regression.sh
```

The Core runner is also non-fail-fast and writes `test-output/java-core-regression-report.txt`.

## Ordinary-cartouche audit output

Generate the four ordinary-cartouche audit variants for every production font pair through the **actual production renderer**:

```bash
export NANPA_FONT_ZIP=/path/to/fonts.zip
./tools/export_cartouche_audit.sh
```

For each font this writes an ordinary cartouche, the same cartouche with a red halo, a tally-mark cartouche, a tally-mark cartouche with red halo, and a contact sheet. Manual-tally font pairs do not put U+F199E into the font run; the renderer draws those tally strokes below the owning glyph as defined by the JavaScript reference.

## Writing physical PNG samples

The regression suite validates PNG export in memory, but it does not write PNG files to disk.
To generate human-inspectable sample outputs for all 8 production font pairs, run:

```bash
export NANPA_FONT_ZIP=/path/to/fonts.zip
./tools/export_visual_pngs.sh
```

This writes 32 files under `test-output/` by default:

- `<font>-full.png`
- `<font>-full-white.png`
- `<font>-abbreviated.png`
- `<font>-abbreviated-white.png`

You can supply a custom output directory:

```bash
export NANPA_FONT_ZIP=/path/to/fonts.zip
./tools/export_visual_pngs.sh /path/to/output-directory
```

This export utility is optional and does not change the mandatory regression behavior.

For the complete production audit matrix (8 font pairs × 16 cases = 128 physical PNGs):

```bash
export NANPA_FONT_ZIP=/path/to/fonts.zip
./tools/export_visual_matrix.sh
```

The matrix includes full and abbreviated decimal/date/time/telephone/hex/binary cases plus the 18 px `ss12` and 29 px `ss13` cases.

## Maven

Core/API build:

```bash
mvn test
```

Maven uses the bundled `resources/fonts.zip` and automatically runs the production-rendering profile:

```bash
mvn test
```

Maven is a build/test wrapper, not a runtime dependency of the Java library.

## High-level Java facade

```java
import java.nio.file.Path;
import com.nanpalinjan.*;

try (NanpaLinjaN nanpa = NanpaLinjaN.create(Path.of("/path/to/fonts.zip"))) {
    CanvasRenderResult canvas = nanpa.renderToCanvas("[nanpa : tu wan nanpa]");
    PngRenderResult png = nanpa.renderToPng("2026-09-13",
        new RenderOptions().withFont("linjaPona"));
    SvgRenderResult svg = nanpa.renderToSvg("#ABCDEF",
        new RenderOptions().withFont("linjaSike"));
    PdfRenderResult pdf = nanpa.renderToPdf("0b10101");

    // Full document rendering: mixed sitelen pona, ordinary cartouche,
    // numeric cartouche and literal quote on one line.
    RenderPlan mixed = nanpa.buildRenderPlan(
        "mi toki e ni: [jan pona,,] 123.45 \"Hello\"",
        new RenderOptions().withFont("nasinNanpa")
    );

    // Parse a full document to an AST, edit one immutable record, convert the
    // edited AST back to source text, then use the normal render API.
    DocumentAst ast = nanpa.parseInput("jan   pona [ jan  pona,, ]");
    DocumentLine line = ast.lines().getFirst();
    java.util.List<DocumentSegment> children = new java.util.ArrayList<>(line.children());
    DocumentSegment old = children.get(1); // the bracket segment in this example
    children.set(1, DocumentSegment.bracket(" jan  suno,, ", old.sourceStart(), old.sourceEnd()));
    DocumentLine editedLine = new DocumentLine(
        line.index(), line.sourceLineIndex(), line.sentenceIndexInSourceLine(),
        line.sourceText(), children
    );
    DocumentAst editedAst = new DocumentAst(
        ast.type(), ast.normalizedInput(), ast.parserOptions(), java.util.List.of(editedLine)
    );
    String editedText = nanpa.astToText(editedAst);
    PngRenderResult editedPng = nanpa.renderToPng(
        editedText, new RenderOptions().withFont("linjaPona")
    );
}
```

### Editing a document AST and converting it back to text

`parseInput()` returns the full-document `DocumentAst`. `astToText(ast)` converts the AST's **current values** back into valid nanpa-linja-n source text. It is an optional editing/tooling API; the normal `renderTo...()` methods still accept source text directly and do not require a separate parse call.

Java records are immutable, so editing means constructing a replacement record (usually a `DocumentSegment`, then its containing `DocumentLine`, then the `DocumentAst`) as shown above.

The editable content fields are:

- `DocumentSegment.value()` for `kind == "text"` — ordinary text, including its spaces and tabs;
- `DocumentSegment.value()` for `kind == "bracket"` — the text inside `[...]`, including internal spaces and tally commas;
- `DocumentSegment.value()`, `openQuote()`, and `closeQuote()` for `kind == "quote"`;
- `DocumentSegment.image()` for `kind == "image"`; replace it with a new `ImageDescriptor` to change `src`, `w`, `h`, `alt`, `valign`, `wriggle`, or `transparent`.

`astToText()` preserves whitespace stored in text/bracket/quote segment values, blank physical lines, and quote delimiters. When `breakLinesAtFullStops` split one physical source line into several AST lines, `sourceLineIndex()` is used to put those pieces back on the same source line. `img(...)` expressions are emitted in a canonical valid form because the parser stores the image descriptor rather than the exact original punctuation/spacing of the expression.

Fields such as `sourceStart()`, `sourceEnd()`, `sourceLineIndex()`, `sentenceIndexInSourceLine()`, `sourceText()`, and `normalizedInput()` describe the original parse and normally should not be treated as editable semantic content. `astToText()` does not rely on `sourceStart()`/`sourceEnd()` when serializing edited segments.

A typical workflow is therefore:

```text
source text -> parseInput() -> DocumentAst -> replace/edit AST records
            -> astToText() -> edited source text -> renderToCanvas/Png/Svg/Pdf()
```

Facade methods:

- `NanpaLinjaN.create(...)`
- `listFonts()` / `fonts()`
- `getFontInfo(font)` / `normalizeFontKey(font)`
- `parse(input, options)` — frozen numeric Core parse operation
- `parseInput(input, options)` — full document AST parser
- `astToText(ast)` — serialize the current full-document AST values back to valid nanpa-linja-n text
- `buildRenderPlan(input, options)` — full document/run render plan
- `render(input, options)` with `canvas`, `png`, `svg`, or `pdf`
- `renderToCanvas(...)`
- `renderToImage(...)` (Java-native alias for the canvas equivalent)
- `renderToPng(...)`
- `renderToSvg(...)`
- `renderToPdf(...)`
- `renderRunToNewCanvas(...)`
- `renderTextToNewCanvas(...)` / `renderTextToCanvas(...)`
- `renderUcsurToNewCanvas(...)` / `renderUcsurToCanvas(...)`
- `registerRenderAdapter(...)` / `getRenderAdapter(...)` / `removeRenderAdapter(...)`
- `toVectorDocument(...)`
- `destroy()` / `close()`

`RenderOptions` provides `fontKey`, `fontSize`, `paddingPx`, parser options, output format and render-plan inclusion.

## Rendering model

Java2D performs the actual OpenType shaping. PNG is produced by `BufferedImage`/`ImageIO`. SVG and PDF are generated as vector paths from the shaped Java2D outline, so neither format depends on raster screenshots.

The Production Rendering Profile explicitly states that SVG and PNG bytes are not cross-renderer protocol values. Java therefore validates semantic/render structure and maintains Java-native output validity rather than comparing Java bytes with JavaScript bytes.

At 18 px the renderer selects `ss12`, at 19–29 px it selects `ss13`, and at 30 px and above it uses the default glyphs. Because Java2D does not expose CSS-style `font-feature-settings`, the Java implementation reads the pinned font's OpenType GSUB table and applies the `ss12`/`ss13` SingleSubst mappings to the shaped glyph stream. Ligatures and kerning remain Java2D-shaped. The resulting production geometry is checked against the actual JavaScript renderer in Chromium across all 128 matrix cases.

## Frozen inputs and diagnostic references

- `conformance/nanpa-linja-n-regression-v1.0.2.json`
- `rendering/production-font-pairs.manifest.json`
- `rendering/font-golden-cases-v1.1.0.json`
- `protocol/` — Protocol v1.1.0 documents
- `reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js` — pinned canonical renderer
- `reference/javascript/` — supplied JavaScript facade, font controller, vector exporter and relevant fixtures
- `references/javascript-browser-render-geometry-v1.json` — 128-case width/height oracle captured from the supplied JavaScript reference in headless Chromium with each case configuration applied
- `conformance/full-renderer-profile-v1.0.0-candidate/feature-manifest.json` — 38 language-neutral full-renderer feature requirements
- `conformance/full-renderer-profile-v1.0.0-candidate/conformance/render-parity-cases-v1.0.0.json` — 64 full-renderer semantic cases
- `conformance/full-renderer-profile-v1.0.0-candidate/references/canonical-browser-render-plan-v1.0.0.json` — frozen browser semantic oracle consumed by the native Java regression

Do not regenerate expected values from Java output. Protocol v1.1.0, the frozen Core-v1 corpus, Parser-Renderer-Profile-v1.1, the current production font manifest, and the canonical JavaScript-derived corpora remain external qualification targets. Historical v1.0 candidate fixtures retained in the archive are non-gating evidence only.
