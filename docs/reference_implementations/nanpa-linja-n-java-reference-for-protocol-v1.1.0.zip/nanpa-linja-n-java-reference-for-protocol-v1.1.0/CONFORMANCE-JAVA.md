
## Protocol v1.1 release gates

The release runner `./tools/run_java_regression.sh` is non-fail-fast and currently passes **14/14 configured suites** on OpenJDK 21.0.11. In addition to the frozen 1030 Core checks, it gates 28/28 canonical syntax cases, 5/5 production adapters, 254/254 canonical full-renderer cases, 128/128 current production render plans, 128/128 SVG vector renders, 8/8 production PNG smoke cases, 8/8 PDF vector smoke cases with no raster Image XObject, 4 manual + 4 UCSUR tally profiles, inline vulgar-fraction scaling across all eight production fonts, and 16/16 Parser-Renderer-Profile-v1.1 smoke cases.

# Java reference conformance

Targets:

- **nanpa-linja-n Protocol v1.1.0**, retaining the frozen Core-v1 conformance corpus v1.0.2;
- **Production Rendering Profile v1**;
- the current JavaScript-derived canonical syntax and full-renderer semantic corpora;
- **Parser-Renderer-Profile-v1.1** and the current production-font profile as the integrated release authority. Historical v1.0 candidate material is retained only as non-gating evidence.

The v1.1 full renderer is layered on the frozen Core-v1 numeric semantics. The integrated v1.1 work does not rewrite the frozen Core corpus.

## Mandatory full qualification

```bash
./tools/run_java_regression.sh
```

The runner compiles every shipped Java source with `javac --release 21` into a temporary directory and deletes that directory on exit. The Java implementation does not invoke JavaScript, Node, Chromium, Python, Go, Rust, Dart, or another language implementation at runtime. Browser/JavaScript-derived structures are consumed only as frozen conformance/oracle data.

### Non-fail-fast behavior

`run_java_regression.sh` intentionally runs every configured suite even if one or more suites fail. It captures stdout/stderr and the exit code of each suite and writes one report:

```text
test-output/java-regression-report.txt
```

After all suites finish, the runner exits 0 only when every suite passed. A deterministic injected-failure check was used during release qualification: the mixed-feature interaction corpus was temporarily made unavailable, and the structural, production rendering, cartouche, and legacy-profile suites all still ran before the final 13-pass/1-fail summary was emitted.

`tools/run_java_core_regression.sh` uses the same non-fail-fast strategy for Core-only qualification and writes `test-output/java-core-regression-report.txt`.

## Current qualification surface

The full runner has 15 suites and asserts:

1. Java 21 environment and source compilation;
2. 35/35 Core-v1 public API smoke checks;
3. `astToText`: 8/8 source-preserving cases plus 1/1 render integration;
4. 48/48 focused current-baseline `parseNumber` / options-aware `astToText` / numeric-whitespace / mixed-fraction / `te`/`to` routing checks;
5. 320/320 parser cases;
5. 15/15 frozen renderer/public-output cases;
6. 9/9 auxiliary API corpus cases;
7. 75/75 equivalence comparisons;
8. **1030/1030** frozen Core-v1 corpus checks, zero failures;
9. logical renderer and JavaScript-facade API smoke/parity;
10. current canonical syntax: **28/28**;
11. current production-font adapter cases: **5/5**;
12. current canonical full-renderer semantic corpus: **254/254**;
13. mixed-feature JavaScript differential corpus: **346/346**, with 132 synthetic `te`/`to` checks, 53 `zz` advance checks, 811 no-U+FFFD run checks, and 57 production PNG smoke cases;
14. 10/10 structural browser-renderer parity cases;
15. all eight production base+companion font pairs load through Java2D;
16. 8 production pairs × 16 cases = **128/128** production render plans;
17. **128/128** SVG vector outputs;
18. **128/128** Chromium geometry cases within +/-1 px;
19. all **32/32** `ss12`/`ss13` geometry cases;
20. PNG and PDF smoke across all 8 production pairs;
21. ordinary cartouche/tally/halo routing, including 5 manual-tally and 3 UCSUR-tally font pairs;
22. **32/32** frozen Chromium ordinary-cartouche adapter cases;
23. retained Full Renderer Profile browser semantics: **64/64**;
24. retained Full Renderer Profile public/structural operations: **20/20**;
25. retained Full Renderer Profile vector/OpenType cases: **9/9**;
26. retained Full Renderer Profile feature areas: **38/38**;
27. retained Full Renderer Profile assertions: **3040**.

The current 254-case semantic corpus specifically covers the syntax and option areas that older Java qualification did not fully exercise: `&` compounds, current/legacy long glyphs, `te`/`to`/`zz`, aliases, raw UCSUR, literal and ordinary cartouches, production word adapters, signed/percent/decimal/scientific/fraction/mixed-fraction scanning, vulgar fractions, embedded numeric spans, Toki Pona numeric phrases, date/time/telephone, hexadecimal/binary behavior, independent binary parsing/rendering options, abbreviation behavior, quotes, images, AST semantics, and render-run metadata.

The 346-case interaction corpus is generated from the current JavaScript reference and deliberately combines constructs that previously passed in isolation but could fail when adjacent. It includes ordered-pair and targeted combinations of `te`/`to`, `zz`, `&`/`+`/`-` compounds, long `pi(...)`, ordinary and literal cartouches, interpreted quoted text, aliases, raw UCSUR, and linja pona/linja sike production adapters. The exact user-reported mixed case `toki&pona 123 zz pi(telo lete) te tomo to` is pinned in this corpus.

## Frozen-Core preservation

The Java numeric Core now follows the frozen Core-v1 corpus baseline for digit-based whitespace boundaries: internal whitespace is a hard boundary, while legal spaces inside numeric proper names and typed numeric cartouches remain accepted. Full-renderer scanning preserves leading `+`, trailing `%`, Unicode vulgar fractions, and valid `1+1/2` mixed fractions before dispatching contiguous numeric tokens to the Core parser. The current conformance corpus is **1030/1030**.

## Output-equivalence policy

Protocol v1.1.0 does not require byte-identical PNG/SVG/PDF serialization between platform renderers. Semantic run structure, parser behavior, adapters, tally routing/ownership, valid output, font behavior and documented geometry invariants are the compatibility targets.

Numeric production geometry retains the existing +/-1 px Chromium oracle. The current 254-case full-renderer corpus compares exact observable semantic structure while Java2D raster/vector serialization is validated independently.

## Asset policy

Production font binaries are loaded only from the bundled `resources/fonts.zip`. Full qualification requires that ZIP; no exploded font directory is used.

If those assets are absent, the full non-fail-fast runner still performs its Core suites and explicitly records the font-dependent suites as failures. `./tools/run_java_core_regression.sh` is available when only Core-v1 qualification is intended; it is not a substitute for complete Java reference qualification.

## Language independence

The Java renderer, document parser, `astToText`, manual-tally renderer, raster output, vector output, contact-sheet exporter and regression implementation are Java. Shell files under `tools/` are launchers only. No other programming-language implementation is used to produce or post-process Java rendering output.
