package com.nanpalinjan;

import java.awt.*;
import java.awt.font.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.text.AttributedCharacterIterator;
import java.awt.font.TextAttribute;
import java.util.*;
import java.util.List;
import java.util.regex.*;
import javax.imageio.ImageIO;
import java.util.Base64;

/**
 * Full document renderer layered on the frozen numeric Core and the production
 * font renderer.  It ports the canonical JavaScript document segmentation and
 * mixed-run behavior into Java rather than delegating to another language.
 */
final class FullRenderer {
    private static final FontRenderContext FRC=new FontRenderContext(new AffineTransform(),true,true);
    private static final Map<String,String> GLYPH_INPUT_ALIASES=Map.of(
            "ni01","ni","ni02","ni>","ni03","ni^","ni04","ni<","sewi01","sewi","sewi02","sewi^",
            "ale","ali");
    private static final Pattern RAW_UNICODE_SCAN=Pattern.compile("(?i)U\\+[0-9a-f]{4,6}(?:[ \\t]+U\\+[0-9a-f]{4,6})*");
    private static final Pattern SSK_SPECIAL=Pattern.compile("(?:\\{([^{}]+)\\}\\s*)?([A-Za-z][A-Za-z0-9_^<>]*)\\(([^()]+)\\)|([A-Za-z][A-Za-z0-9_^<>]*(?:[&+-][A-Za-z][A-Za-z0-9_^<>]*)+)|\\{([^{}]+)\\}\\s*([A-Za-z][A-Za-z0-9_^<>]*)");
    private static final Pattern CORE_SPECIAL=Pattern.compile("(?i)pi\\(([^()]+)\\)|([A-Za-z][A-Za-z0-9_^<>]*(?:[&+-][A-Za-z][A-Za-z0-9_^<>]*)+)|(\\|)|(pi\\s+\\{[^{}]*\\})");
    private static final Pattern LEGACY_LONG_PI=Pattern.compile("(?i)pi\\+__[A-Za-z][A-Za-z0-9^<>]*(?:__[A-Za-z][A-Za-z0-9^<>]*){0,2}|pi(?:\\+\\+\\+|---)[ \\t]*[A-Za-z][A-Za-z0-9_^<>]*[ \\t]+[A-Za-z][A-Za-z0-9_^<>]*[ \\t]+[A-Za-z][A-Za-z0-9_^<>]*|pi(?:\\+\\+|--)[ \\t]*[A-Za-z][A-Za-z0-9_^<>]*[ \\t]+[A-Za-z][A-Za-z0-9_^<>]*|pi\\+[A-Za-z][A-Za-z0-9_^<>]*");
    private final ProductionRenderer production;
    private final Map<String,RenderAdapter> runtimeAdapters;

    FullRenderer(ProductionRenderer production,Map<String,RenderAdapter> runtimeAdapters){
        this.production=production;this.runtimeAdapters=runtimeAdapters;
    }

    DocumentAst parseInput(String input,RenderOptions options){
        ParseOptions parser=options==null?new ParseOptions():options.parser();
        return annotateNumericStructures(DocumentParser.parse(input,parser),parser);
    }

    private record Graphic(Shape foreground,Shape halo,Shape decoration,Color decorationColor,BufferedImage image,String imageHref,double width,double height,double baseline,List<TallyGroup> tallyGroups){}
    private record Logical(RenderRun run,Graphic graphic){}
    private record Placed(RenderRun run,Graphic graphic,double tx,double ty){}
    private record Prepared(DocumentAst ast,RenderPlan plan,List<Placed> placed,Area foreground,Area halo,Area decoration,List<Placed> images,Color fillColor,Color decorationColor){}

    RenderPlan buildPlan(String input,FontPairInfo pair,RenderOptions options) throws Exception{return prepare(input,pair,options).plan;}

    CanvasRenderResult renderCanvas(String input,FontPairInfo pair,RenderOptions options) throws Exception{
        Prepared d=prepare(input,pair,options);
        BufferedImage image=new BufferedImage(Math.max(1,d.plan.width()),Math.max(1,d.plan.height()),BufferedImage.TYPE_INT_ARGB);
        Graphics2D g=image.createGraphics();
        try{
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            if(options.haloEnabled()&&!d.halo.isEmpty()){g.setColor(color(options.haloColor(),Color.WHITE));g.fill(d.halo);}
            g.setColor(d.fillColor);g.fill(d.foreground);
            if(!d.decoration.isEmpty()){g.setColor(d.decorationColor);g.fill(d.decoration);}
            for(Placed p:d.images){if(p.graphic.image()!=null)g.drawImage(p.graphic.image(),(int)Math.round(p.tx),(int)Math.round(p.ty),null);}
        }finally{g.dispose();}
        return new CanvasRenderResult("canvas",input,image,image.getWidth(),image.getHeight(),options.includePlan()?d.plan:null,pair.key(),pair,options);
    }

    PngRenderResult renderPng(String input,FontPairInfo pair,RenderOptions options) throws Exception{
        CanvasRenderResult c=renderCanvas(input,pair,options);ByteArrayOutputStream out=new ByteArrayOutputStream();if(!ImageIO.write(c.canvas(),"png",out))throw new IOException("PNG ImageIO writer unavailable");byte[]b=out.toByteArray();byte[]sig={(byte)137,80,78,71,13,10,26,10};for(int i=0;i<sig.length;i++)if(b.length<=i||b[i]!=sig[i])throw new IOException("Invalid PNG signature");return new PngRenderResult("png",input,b,c,pair.key(),pair,options);
    }

    SvgRenderResult renderSvg(String input,FontPairInfo pair,RenderOptions options) throws Exception{
        Prepared d=prepare(input,pair,options);StringBuilder s=new StringBuilder();s.append("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"").append(d.plan.width()).append("\" height=\"").append(d.plan.height()).append("\" viewBox=\"0 0 ").append(d.plan.width()).append(' ').append(d.plan.height()).append("\">");
        if(options.haloEnabled()&&!d.halo.isEmpty())s.append("<path d=\"").append(ProductionRenderer.svgPath(d.halo)).append("\" fill=\"").append(options.haloColor()).append("\"/>");
        if(!d.foreground.isEmpty())s.append("<path d=\"").append(ProductionRenderer.svgPath(d.foreground)).append("\" fill=\"").append(options.paint().fillStyle()).append("\"/>");
        if(!d.decoration.isEmpty())s.append("<path d=\"").append(ProductionRenderer.svgPath(d.decoration)).append("\" fill=\"").append(hex(d.decorationColor)).append("\"/>");
        for(Placed p:d.images){String href=p.graphic.imageHref();if(href==null||href.isBlank())href=pngDataUrl(p.graphic.image());s.append("<image x=\"").append(n(p.tx)).append("\" y=\"").append(n(p.ty)).append("\" width=\"").append(n(p.graphic.width())).append("\" height=\"").append(n(p.graphic.height())).append("\" href=\"").append(xml(href)).append("\"/>");}
        s.append("</svg>");return new SvgRenderResult("svg",input,s.toString(),options.includePlan()?d.plan:null,pair.key(),pair,options);
    }

    PdfRenderResult renderPdf(String input,FontPairInfo pair,RenderOptions options) throws Exception{
        Prepared d=prepare(input,pair,options);Area f=new Area(d.foreground);f.add(new Area(d.decoration));for(Placed p:d.images)f.add(new Area(new Rectangle2D.Double(p.tx,p.ty,p.graphic.width(),p.graphic.height())));byte[]bytes=ProductionRenderer.vectorPdf(f,d.halo,d.plan.width(),d.plan.height(),options);return new PdfRenderResult("pdf",input,bytes,options.includePlan()?d.plan:null,pair.key(),pair,options);
    }

    VectorDocument vectorDocument(String input,FontPairInfo pair,RenderOptions options) throws Exception{
        Prepared d=prepare(input,pair,options);List<VectorElement> els=new ArrayList<>();if(options.haloEnabled()&&!d.halo.isEmpty())els.add(new VectorElement("halo",null,ProductionRenderer.svgPath(d.halo),options.haloColor(),null,0,0,d.plan.width(),d.plan.height()));
        for(Placed p:d.placed){if(p.graphic.image()!=null){els.add(new VectorElement("image",p.run.id(),null,null,p.graphic.imageHref(),p.tx,p.ty,p.graphic.width(),p.graphic.height()));continue;}Shape x=translate(p.graphic.foreground(),p.tx,p.ty);if(x!=null&&!x.getBounds2D().isEmpty())els.add(new VectorElement("path",p.run.id(),ProductionRenderer.svgPath(x),options.paint().fillStyle(),null,p.tx,p.ty,p.graphic.width(),p.graphic.height()));}
        return new VectorDocument(d.plan.width(),d.plan.height(),els,d.plan.diagnostics(),d.plan);
    }

    private Prepared prepare(String input,FontPairInfo pair,RenderOptions options) throws Exception{
        RenderOptions o=options==null?new RenderOptions():options;DocumentAst ast=parseInput(input,o);List<List<Logical>> logicalLines=new ArrayList<>();boolean anyAbbr=false;ParseResult firstParsed=null;
        for(DocumentLine line:ast.lines()){
            List<Logical> runs=new ArrayList<>();int sourceSeg=0;
            for(DocumentSegment seg:line.children()){
                switch(seg.kind()){
                    case "text" -> parseText(seg.value(),seg.sourceStart(),"text",sourceSeg,runs,pair,o);
                    case "bracket" -> parseBracket(seg.value(),seg.sourceStart(),"bracket",sourceSeg,runs,pair,o);
                    case "quote" -> parseQuote(seg,sourceSeg,runs,pair,o);
                    case "image" -> runs.add(imageRun(seg,sourceSeg,pair,o));
                }
                sourceSeg++;
            }
            for(Logical l:runs){if(l.run.numericCartouche()){RenderResult rr=V11Numeric.normalizeRenderResult(new NanpaRenderer().render(l.run.sourceText(),o.parser()),l.run.sourceText());if(rr!=null){anyAbbr|=rr.abbreviated;if(firstParsed==null)firstParsed=rr.parsed;}}}
            logicalLines.add(runs);
        }

        double lineGap=o.layout().lineGap(o.fontSize());double pad=o.paddingPx();double maxLineW=0;List<Double>lineWidths=new ArrayList<>(),lineAsc=new ArrayList<>(),lineDesc=new ArrayList<>();
        for(List<Logical> line:logicalLines){double x=0,asc=0,desc=0;boolean first=true;for(Logical l:line){if(!first)x+=gapBefore(l.run,o);first=false;x+=l.graphic.width();asc=Math.max(asc,l.graphic.baseline());desc=Math.max(desc,Math.max(0,l.graphic.height()-l.graphic.baseline()));}double h=Math.max(o.fontSize(),asc+desc);if(line.isEmpty()){asc=o.fontSize()*0.82;desc=h-asc;}lineWidths.add(x);lineAsc.add(asc);lineDesc.add(desc);maxLineW=Math.max(maxLineW,x);}
        int width=Math.max(1,(int)Math.ceil(maxLineW+2*pad));double totalH=2*pad;for(int i=0;i<logicalLines.size();i++){totalH+=Math.max(o.fontSize(),lineAsc.get(i)+lineDesc.get(i));if(i+1<logicalLines.size())totalH+=lineGap;}int height=Math.max(1,(int)Math.ceil(totalH));
        List<Placed> placed=new ArrayList<>(),images=new ArrayList<>();List<RenderRun> allRuns=new ArrayList<>();List<RenderLinePlan> linePlans=new ArrayList<>();Area foreground=new Area(),halo=new Area(),decoration=new Area();double y=pad;
        for(int li=0;li<logicalLines.size();li++){
            List<Logical> line=logicalLines.get(li);double lw=lineWidths.get(li),asc=lineAsc.get(li),desc=lineDesc.get(li),lh=Math.max(o.fontSize(),asc+desc);double x=pad+switch(o.layout().align()){case"center"->(maxLineW-lw)/2;case"right"->maxLineW-lw;default->0;};double lineStartX=x;List<RenderRun> lineRuns=new ArrayList<>();boolean first=true;int ri=0;
            for(Logical l:line){if(!first)x+=gapBefore(l.run,o);first=false;double ty=y+asc-l.graphic.baseline();double tx=x;Shape fg=translate(l.graphic.foreground(),tx,ty),hs=translate(l.graphic.halo(),tx,ty),ds=translate(l.graphic.decoration(),tx,ty);if(fg!=null)foreground.add(new Area(fg));if(hs!=null)halo.add(new Area(hs));if(ds!=null)decoration.add(new Area(ds));List<TallyGroup> groups=translateGroups(l.graphic.tallyGroups(),tx,ty);RenderRun r=new RenderRun("L"+li+"R"+ri,li,ri,l.run.kind(),l.run.renderMode(),l.run.fontRole(),l.run.numericCartouche(),l.run.hexCartouche(),l.run.binaryCartouche(),l.run.numericBase(),l.run.openerCodepoint(),l.run.closerCodepoint(),l.run.canonicalCodepoints(),l.run.renderCodepoints(),l.run.renderText(),l.run.renderAdapterId(),l.run.sourceText(),l.run.sourceKind(),l.run.sourceStart(),l.run.sourceEnd(),l.run.manualTallies(),groups,l.run.quoted(),l.run.interpretedQuote(),l.run.unrecognized(),l.run.imageAlt(),tx,ty,l.graphic.width(),l.graphic.height(),y+asc);Placed pl=new Placed(r,l.graphic,tx,ty);placed.add(pl);if(l.graphic.image()!=null)images.add(pl);allRuns.add(r);lineRuns.add(r);x+=l.graphic.width();ri++;}
            linePlans.add(new RenderLinePlan(li,ast.lines().get(li).sourceLineIndex(),ast.lines().get(li).sentenceIndexInSourceLine(),lineStartX,y,lw,lh,y+asc,asc,desc,lineRuns));y+=lh+(li+1<logicalLines.size()?lineGap:0);
        }
        List<RenderRun> publicRuns=allRuns;
        // Preserve the pre-full-renderer public-plan shape for a simple plain-text
        // input: historically buildRenderPlan("toki pona") exposed one top-level
        // text run.  Detailed word/glyph runs are now available in lines(), while
        // runs() retains that compatibility contract.
        if(ast.lines().size()==1&&ast.lines().getFirst().children().size()==1&&"text".equals(ast.lines().getFirst().children().getFirst().kind())
                &&!allRuns.isEmpty()&&allRuns.stream().noneMatch(r->r.numericCartouche()||"cartouche".equals(r.fontRole())||"image".equals(r.sourceKind()))){
            String rt=allRuns.stream().map(RenderRun::renderText).reduce("",String::concat);
            List<Integer> cc=new ArrayList<>();List<Integer> rc=new ArrayList<>();for(RenderRun r:allRuns){cc.addAll(r.canonicalCodepoints());rc.addAll(r.renderCodepoints());}
            RenderRun legacy=new RenderRun("",0,0,"text","text","text",false,false,false,0,null,null,cc,rc,rt,pair.renderAdapterId(),input,"text",0,input.length(),List.of(),List.of(),false,false,false,null,pad,pad,maxLineW,Math.max(o.fontSize(),lineAsc.getFirst()+lineDesc.getFirst()),pad+lineAsc.getFirst());
            publicRuns=List.of(legacy);
        }
        RenderPlan plan=new RenderPlan(input,pair.key(),pair,anyAbbr,width,height,ProductionRenderer.featuresFor(o.fontSize()),publicRuns,firstParsed,List.of(),ast,linePlans);return new Prepared(ast,plan,placed,foreground,halo,decoration,images,color(o.paint().fillStyle(),Color.BLACK),color(o.paint().unknownText().color(),Color.BLACK));
    }

    private double gapBefore(RenderRun run,RenderOptions o){return "cartouche".equals(run.fontRole())||run.numericCartouche()?o.layout().cartoucheLeadGap(o.fontSize()):o.layout().glyphGap(o.fontSize());}

    private void parseText(String text,int base,String kind,int segIndex,List<Logical> out,FontPairInfo pair,RenderOptions o) throws Exception{
        if(text==null||text.isBlank())return;
        Matcher m=RAW_UNICODE_SCAN.matcher(text);int pos=0;
        while(m.find()){
            if(m.start()>pos)parseTextNoRaw(text.substring(pos,m.start()),base+pos,kind,segIndex,out,pair,o);
            String raw=m.group();List<Integer>cps=DocumentParser.parseRawUnicodeSequence(raw);
            if(cps!=null)out.add(glyphRun(raw,cps,base+m.start(),base+m.end(),kind,false,false,pair,o));
            else parseTextNoRaw(raw,base+m.start(),kind,segIndex,out,pair,o);
            pos=m.end();
        }
        if(pos<text.length())parseTextNoRaw(text.substring(pos),base+pos,kind,segIndex,out,pair,o);
    }

    private void parseTextNoRaw(String text,int base,String kind,int segIndex,List<Logical>out,FontPairInfo pair,RenderOptions o) throws Exception{
        switch(o.parser().rendererMode()){
            case "standard-sitelen-pona-ascii-core" -> parseStandardCoreText(text,base,kind,segIndex,out,pair,o);
            case "sitelen-seli-kiwen" -> parseSskLikeText(text,base,kind,segIndex,out,pair,o);
            case "sitelen-pona-ascii-extended" -> parseExtendedText(text,base,kind,segIndex,out,pair,o);
            default -> parseTextBase(text,base,kind,segIndex,out,pair,o);
        }
    }

    private void parseExtendedText(String text,int base,String kind,int segIndex,List<Logical>out,FontPairInfo pair,RenderOptions o) throws Exception{
        Matcher m=LEGACY_LONG_PI.matcher(text);int pos=0;
        while(m.find()){
            if(m.start()>pos)parseSskLikeText(text.substring(pos,m.start()),base+pos,kind,segIndex,out,pair,o);
            String alias=m.group(),inner=legacyLongPiInner(alias);List<Integer>cps=inner==null?null:extendedGlyphCps("","pi",inner);
            if(cps!=null)out.add(glyphRun(alias,cps,base+m.start(),base+m.end(),kind,false,false,pair,o));
            else parseSskLikeText(alias,base+m.start(),kind,segIndex,out,pair,o);
            pos=m.end();
        }
        if(pos<text.length())parseSskLikeText(text.substring(pos),base+pos,kind,segIndex,out,pair,o);
    }

    private void parseSskLikeText(String text,int base,String kind,int segIndex,List<Logical>out,FontPairInfo pair,RenderOptions o) throws Exception{
        Matcher m=SSK_SPECIAL.matcher(text);int pos=0;
        while(m.find()){
            List<Integer>cps=null;
            if(m.group(2)!=null)cps=extendedGlyphCps(m.group(1),m.group(2),m.group(3));
            else if(m.group(4)!=null)cps=glyphExpressionCps(m.group(4));
            else if(m.group(5)!=null&&m.group(6)!=null)cps=extendedGlyphCps(m.group(5),m.group(6),"");
            if(cps==null)continue;
            if(m.start()>pos)parseTextBase(text.substring(pos,m.start()),base+pos,kind,segIndex,out,pair,o);
            out.add(glyphRun(m.group(),cps,base+m.start(),base+m.end(),kind,false,false,pair,o));pos=m.end();
        }
        if(pos<text.length())parseTextBase(text.substring(pos),base+pos,kind,segIndex,out,pair,o);
    }

    private void parseStandardCoreText(String text,int base,String kind,int segIndex,List<Logical>out,FontPairInfo pair,RenderOptions o) throws Exception{
        Matcher m=CORE_SPECIAL.matcher(text);int pos=0;
        while(m.find()){
            if(m.start()>pos)parseTextBase(text.substring(pos,m.start()),base+pos,kind,segIndex,out,pair,o);
            List<Integer>cps=null;
            if(m.group(1)!=null){List<Integer>inner=glyphWordsCps(m.group(1));if(inner!=null){cps=new ArrayList<>();cps.add(Constants.ALL_WORD_CODEPOINTS.get("pi"));cps.add(0xF1997);cps.addAll(inner);cps.add(0xF1998);}}
            else if(m.group(2)!=null)cps=glyphExpressionCps(m.group(2));
            else if("|".equals(m.group(3)))cps=List.of(0x3000);
            if(cps!=null){Logical l=glyphRun(m.group(),cps,base+m.start(),base+m.end(),kind,false,false,pair,o);if(cps.equals(List.of(0x3000)))l=forceKind(l,"run");out.add(l);}
            else parseTextBase(m.group(),base+m.start(),kind,segIndex,out,pair,o);
            pos=m.end();
        }
        if(pos<text.length())parseTextBase(text.substring(pos),base+pos,kind,segIndex,out,pair,o);
    }

    private void parseTextBase(String text,int base,String kind,int segIndex,List<Logical>out,FontPairInfo pair,RenderOptions o) throws Exception{
        if(text==null||text.isBlank())return;

        // Full Toki Pona numeric phrases are a renderer grammar layered on top
        // of the frozen Core parser. Claim an exact complete phrase first.
        RenderResult phrase=fullPhraseRender(text,o.parser(),false);
        if(phrase!=null){out.add(numericRun(text,phrase,base,base+text.length(),kind,pair,o));return;}

        // Proper-name numeric forms can occupy only a prefix of a longer text
        // segment (e.g. "Nasa Wan Tu Se"). Claim the longest valid prefix and
        // continue with the remaining text rather than tokenising everything.
        ProperHit ph=properNumericPrefix(text,o.parser());
        if(ph!=null){out.add(numericRun(text.substring(ph.start,ph.end),ph.render,base+ph.start,base+ph.end,kind,pair,o));if(ph.end<text.length())parseTextBase(text.substring(ph.end),base+ph.end,kind,segIndex,out,pair,o);return;}

        // Canonical disabled-binary fallback: 0b... ceases to be reserved as a
        // binary token and is observed as three decimal claims.
        if(!o.parser().enableBinaryParsing()&&!o.parser().enableBinaryRendering()){
            Matcher bm=Pattern.compile("^0b([01]+)$",Pattern.CASE_INSENSITIVE).matcher(text.trim());
            if(bm.matches()){
                int off=text.indexOf(text.trim()),ds=off+2;String digits=bm.group(1);
                RenderResult a=numericRender("0b",o.parser()),b=numericRender(digits.substring(0,1),o.parser());
                if(a!=null)out.add(numericRun("0b",a,base+off,base+off+2,kind,pair,o));
                if(b!=null)out.add(numericRun(digits.substring(0,1),b,base+ds,base+ds+1,kind,pair,o));
                if(digits.length()>1){RenderResult c=numericRender(digits.substring(1),o.parser());if(c!=null)out.add(numericRun(digits.substring(1),c,base+ds+1,base+ds+digits.length(),kind,pair,o));}
                return;
            }
        }

        Matcher m=Pattern.compile("[^\\s\\u2010\\u2011\\u2012\\u2013\\u2014\\u2212\\uFE63\\uFF0D]+").matcher(text);
        while(m.find()){
            String token=m.group();int start=base+m.start(),end=base+m.end();
            // Before punctuation trimming, give an exact numeric-looking token to
            // the frozen Core parser.  This is essential for leading +, trailing %,
            // and Unicode vulgar/mixed fractions: Core already understands them,
            // while the generic prose fallback must not silently discard those
            // characters.  Restrict this claim to tokens that contain a decimal
            // digit or a Unicode vulgar-fraction codepoint so ordinary glyph words
            // continue through the word grammar.
            boolean numericCandidate=token.codePoints().anyMatch(cp->Character.isDigit(cp)||(cp>=0x00BC&&cp<=0x00BE)||(cp>=0x2150&&cp<=0x215E));
            if(numericCandidate&&!(o.parser().nasinNanpaPona()&&token.matches("[+]?[0-9]+"))){RenderResult exact=numericRender(token,o.parser());if(exact!=null){out.add(numericRun(token,exact,start,end,kind,pair,o));continue;}}
            int a=0,b=token.length();boolean numericLike=token.matches(".*[0-9].*");
            while(a<b&&!fallbackCoreChar(token.charAt(a),numericLike)){emitPunct(String.valueOf(token.charAt(a)),start+a,kind,out,pair,o);a++;}
            while(b>a&&!fallbackCoreChar(token.charAt(b-1),numericLike))b--;
            while(b>a&&")]},.;:!?".indexOf(token.charAt(b-1))>=0)b--;
            String core=token.substring(a,b);
            if(!core.isEmpty()&&!Set.of("&","+","-").contains(core))emitCoreToken(core,start+a,start+b,kind,segIndex,out,pair,o);
            for(int i=b;i<token.length();i++)emitPunct(String.valueOf(token.charAt(i)),start+i,kind,out,pair,o);
        }
    }

    private record ProperHit(int start,int end,RenderResult render){}
    private ProperHit properNumericPrefix(String text,ParseOptions p){
        Matcher wm=Pattern.compile("[A-Za-z]+").matcher(text);List<int[]>pos=new ArrayList<>();List<String>w=new ArrayList<>();while(wm.find()){pos.add(new int[]{wm.start(),wm.end()});w.add(wm.group());}
        if(w.isEmpty())return null;
        for(int i=0;i<w.size();i++){
            String first=w.get(i);if(first.isEmpty()||!Character.isUpperCase(first.charAt(0)))continue;String low=first.toLowerCase(Locale.ROOT);boolean typed=p.nanpaColonParsing()||p.nanpaColonRendering();boolean plausible=low.startsWith("ne")||(p.enableHexParsing()&&low.startsWith("nasa"))||((p.enableBinaryParsing()||p.enableBinaryRendering())&&low.startsWith("noka"))||(typed&&(first.equals("Nanpa")||first.startsWith("Nanpa")||first.equals("Tenpo")||first.equals("Suno")||first.equals("Toki")));if(!plausible)continue;
            RenderResult best=null;int bestEnd=-1;
            for(int j=i;j<Math.min(w.size(),i+31);j++){
                if(j>i){if(!Character.isUpperCase(w.get(j).charAt(0))||!text.substring(pos.get(j-1)[1],pos.get(j)[0]).matches("[ \\t]*"))break;}
                String raw=text.substring(pos.get(i)[0],pos.get(j)[1]);RenderResult rr=numericRender(raw,p);if(rr!=null){best=rr;bestEnd=pos.get(j)[1];}
            }
            if(best!=null){if(first.equals("Toki")&&i+1<w.size()&&bestEnd<text.length()){int bi=-1;for(int j=i;j<w.size();j++)if(pos.get(j)[1]==bestEnd){bi=j;break;}if(bi>=0&&bi+1<w.size()&&Character.isUpperCase(w.get(bi+1).charAt(0))&&text.substring(pos.get(bi)[1],pos.get(bi+1)[0]).matches("[ \\t]*"))continue;}return new ProperHit(pos.get(i)[0],bestEnd,best);}
        }
        return null;
    }

    private static NumericStructure numericStructure(String source,int index,int end,ParseResult parsed,boolean whole){
        String k=parsed.kind!=null?parsed.kind:(parsed.semanticKind!=null?parsed.semanticKind.name():"number");
        return new NumericStructure(k,source,index,end,parsed.semanticKind==null?"":parsed.semanticKind.name(),parsed.semanticStartGlyph==null?"":parsed.semanticStartGlyph.name(),whole);
    }
    private static List<NumericStructure> scanNumericStructures(String text,ParseOptions p){
        List<NumericStructure>hits=new ArrayList<>();
        int properCursor=0;
        while(properCursor<text.length()){
            String rest=text.substring(properCursor);Matcher words=Pattern.compile("[A-Za-z]+").matcher(rest);List<int[]> spans=new ArrayList<>();List<String> ws=new ArrayList<>();while(words.find()){spans.add(new int[]{words.start(),words.end()});ws.add(words.group());}
            NumericStructure found=null;
            for(int i=0;i<ws.size()&&found==null;i++){
                String first=ws.get(i);if(first.isEmpty()||!Character.isUpperCase(first.charAt(0)))continue;String low=first.toLowerCase(Locale.ROOT);boolean typed=p.nanpaColonParsing()||p.nanpaColonRendering();boolean plausible=low.startsWith("ne")||(p.enableHexParsing()&&low.startsWith("nasa"))||((p.enableBinaryParsing()||p.enableBinaryRendering())&&low.startsWith("noka"))||(typed&&(first.equals("Nanpa")||first.startsWith("Nanpa")||first.equals("Tenpo")||first.equals("Suno")||first.equals("Toki")));if(!plausible)continue;
                ParseResult best=null;int bestEnd=-1;
                for(int j=i;j<Math.min(ws.size(),i+31);j++){if(j>i&&(!Character.isUpperCase(ws.get(j).charAt(0))||!rest.substring(spans.get(j-1)[1],spans.get(j)[0]).matches("[ \t]*")))break;String raw=rest.substring(spans.get(i)[0],spans.get(j)[1]);ParseResult pr=V11Numeric.normalizeForRendering(NanpaApi.parseNumber(raw,p),raw);if(pr!=null){best=pr;bestEnd=spans.get(j)[1];}}
                if(best!=null){int st=properCursor+spans.get(i)[0],en=properCursor+bestEnd;found=numericStructure(text.substring(st,en),st,en,best,false);}
            }
            if(found==null)break;hits.add(found);properCursor=Math.max(found.end(),properCursor+1);
        }
        Matcher token=Pattern.compile("\\S+").matcher(text);while(token.find()){int st=token.start(),en=token.end();while(en>st&&");!?}".indexOf(text.charAt(en-1))>=0)en--;if(en<=st)continue;String raw=text.substring(st,en);ParseResult pr=V11Numeric.normalizeForRendering(NanpaApi.parseNumber(raw,p),raw);if(pr!=null)hits.add(numericStructure(raw,st,en,pr,false));else if(raw.endsWith(".")&&raw.length()>1){String c=raw.substring(0,raw.length()-1);pr=V11Numeric.normalizeForRendering(NanpaApi.parseNumber(c,p),c);if(pr!=null)hits.add(numericStructure(c,st,en-1,pr,false));}}
        hits.sort(Comparator.comparingInt(NumericStructure::index).thenComparingInt(NumericStructure::end));List<NumericStructure>out=new ArrayList<>();int occupied=-1;for(NumericStructure h:hits){if(h.index()<occupied)continue;out.add(h);occupied=h.end();}return out;
    }
    private static DocumentAst annotateNumericStructures(DocumentAst ast,ParseOptions p){
        List<DocumentLine> lines=new ArrayList<>();for(DocumentLine line:ast.lines()){List<DocumentSegment>children=new ArrayList<>();for(DocumentSegment seg:line.children()){List<NumericStructure>ns=switch(seg.kind()){case "text"->scanNumericStructures(seg.value()==null?"":seg.value(),p);case "bracket"->{String src="["+(seg.value()==null?"":seg.value())+"]";ParseResult pr=V11Numeric.normalizeForRendering(NanpaApi.parseNumber(src,p),src);yield pr==null?List.of():List.of(numericStructure(src,0,src.length(),pr,true));}default->List.of();};children.add(ns.isEmpty()?seg:seg.withNumericStructures(ns));}lines.add(new DocumentLine(line.index(),line.sourceLineIndex(),line.sentenceIndexInSourceLine(),line.sourceText(),children));}return new DocumentAst(ast.type(),ast.normalizedInput(),ast.parserOptions(),lines);
    }

    private static boolean fallbackCoreChar(char c,boolean numericLike){if(Character.isLetterOrDigit(c))return true;if("#~^<>".indexOf(c)>=0)return true;return numericLike&&".,_-".indexOf(c)>=0;}
    private void emitPunct(String s,int start,String kind,List<Logical>out,FontPairInfo pair,RenderOptions o)throws Exception{
        if(",".equals(s)){
            out.add(forceKind(glyphRun(s,List.of((int)','),start,start+s.length(),kind,false,false,pair,o),"run"));
            return;
        }
        int cp=s.equals(":")?0xF199D:(s.equals(".")||s.equals("·")?0xF199C:0);
        if(cp!=0)out.add(glyphRun(s,List.of(cp),start,start+s.length(),kind,false,false,pair,o));
    }

    private void emitCoreToken(String core,int start,int end,String kind,int segIndex,List<Logical>out,FontPairInfo pair,RenderOptions o) throws Exception{
        List<Integer> direct=core.codePoints().boxed().toList();
        if(!direct.isEmpty()&&direct.stream().allMatch(FullRenderer::isDirectRenderCodepoint)){out.add(glyphRun(core,direct,start,end,kind,false,false,pair,o));return;}
        String rawKey=core.trim().toLowerCase(Locale.ROOT);String alias=GLYPH_INPUT_ALIASES.get(rawKey);if(alias!=null){Integer cp=fullGlyphCp(alias);if(cp!=null){out.add(glyphRun(core,List.of(cp),start,end,kind,false,false,pair,o));return;}}
        String key=normalizeFullGlyphKey(core);
        if("zz".equals(key)){out.add(literalRenderedRun("\u3000",core,start,end,kind,false,false,false,pair,o));return;}
        if("te".equals(key)||"to".equals(key)){out.add(glyphRun(core,List.of(fullGlyphCp(key)),start,end,kind,false,false,pair,o));return;}
        Matcher suffix=Pattern.compile("^([A-Za-z^<>]+)([0-9]+)$").matcher(core);
        if(suffix.matches()&&!GLYPH_INPUT_ALIASES.containsKey(core.toLowerCase(Locale.ROOT))&&fullGlyphCp(suffix.group(1))!=null){
            String g=suffix.group(1),digits=suffix.group(2);out.add(glyphRun(g,List.of(fullGlyphCp(g)),start,start+g.length(),kind,false,false,pair,o));RenderResult sr=numericRender(digits,o.parser());if(sr!=null)out.add(numericRun(digits,sr,start+g.length(),end,kind,pair,o));return;
        }
        RenderResult rr=numericRender(core,o.parser());
        if(rr!=null){if(o.parser().nasinNanpaPona()&&core.matches("[+]?[0-9]+")){for(String w:nnpWords(core.replace("+","")))out.add(glyphRun(core,List.of(nnpGlyphCp(w)),start,end,kind,false,false,pair,o));}else out.add(numericRun(core,rr,start,end,kind,pair,o));return;}
        if(o.parser().autoCartoucheStandaloneProperNames()&&!core.isEmpty()&&Character.isUpperCase(core.codePointAt(0))){List<Integer>cps=properNameCps(core);if(cps!=null&&!cps.isEmpty()){out.add(cartoucheRun(core,OrdinaryCartouche.of(cps,Collections.nCopies(cps.size(),0),"ucsur"),start,end,kind,pair,o));return;}}
        Integer cp=fullGlyphCp(key);if(cp!=null){
            if(",".equals(key)){
                // Outside cartouches U+002C remains an ordinary ASCII comma.
                // Canonical v1.1 represents it as a one-codepoint word run rather
                // than as a sitelen-pona glyph.
                out.add(forceKind(glyphRun(core,List.of((int)','),start,end,kind,false,false,pair,o),"run"));
            }else out.add(glyphRun(core,List.of(cp),start,end,kind,false,false,pair,o));
            return;
        }
        if(o.parser().showUnknownText()){String literal=core;int ls=start,le=end;if("standard-sitelen-pona-ascii-core".equals(o.parser().rendererMode())&&literal.length()>=2&&literal.startsWith("'")&&literal.endsWith("'")){literal=literal.substring(1,literal.length()-1);ls++;le--;}out.add(literalRun(literal,ls,le,kind,false,false,true,pair,o));}
    }

    private void parseBracket(String body,int sourceStart,String kind,int segIndex,List<Logical>out,FontPairInfo pair,RenderOptions o) throws Exception{
        String trimmed=body==null?"":body.trim();if(trimmed.isEmpty())return;
        if(trimmed.length()>=2&&trimmed.startsWith("\"")&&trimmed.endsWith("\"")){
            String literal=unescape(trimmed.substring(1,trimmed.length()-1));if(!literal.isEmpty()){List<Integer>inner=new ArrayList<>();int[]a=literal.codePoints().toArray();for(int i=0;i<a.length;i++){inner.add(a[i]);inner.add(0xF1992);}out.add(literalCartoucheRun(trimmed,OrdinaryCartouche.of(inner,Collections.nCopies(inner.size(),0),"ucsur"),sourceStart,sourceStart+body.length(),kind,pair,o));return;}
        }
        RenderResult rr=numericRender("["+trimmed+"]",o.parser());if(rr!=null){out.add(numericRun(trimmed,rr,sourceStart,sourceStart+body.length(),kind,pair,o));return;}
        rr=numericRender(trimmed,o.parser());if(rr!=null&&!rr.parsed.isHex&&!rr.parsed.isBinary){out.add(numericRun(trimmed,rr,sourceStart,sourceStart+body.length(),kind,pair,o));return;}
        RenderResult phrase=fullPhraseRender(trimmed,o.parser(),false);if(phrase!=null){out.add(numericRun(trimmed,phrase,sourceStart,sourceStart+body.length(),kind,pair,o));return;}
        if(o.parser().abbreviateNumericCartouches()){RenderResult abr=fullPhraseRender(trimmed,o.parser(),true);if(abr!=null){out.add(numericRun(trimmed,abr,sourceStart,sourceStart+body.length(),kind,pair,o));return;}}
        String ordinarySource=trimmed;if("sitelen-pona-ascii-extended".equals(o.parser().rendererMode())){String x=normalizeExtendedLegacyCartouche(trimmed);if(x!=null)ordinarySource=x;}
        if(!ordinarySource.matches(".*[,.:·()].*")){List<Integer>cps=glyphWordsCps(ordinarySource);if(cps!=null){out.add(cartoucheRun(trimmed,OrdinaryCartouche.of(cps,Collections.nCopies(cps.size(),0),"ucsur"),sourceStart,sourceStart+body.length(),kind,pair,o));return;}}
        OrdinaryCartouche oc=OrdinaryCartouche.parseBody(ordinarySource,pair,o.parser());if(oc!=null){out.add(cartoucheRun(trimmed,oc,sourceStart,sourceStart+body.length(),kind,pair,o));return;}
        List<Integer>fallback=lettersToFallbackGlyphCps(trimmed);if(!fallback.isEmpty())out.add(cartoucheRun(trimmed,OrdinaryCartouche.of(fallback,Collections.nCopies(fallback.size(),0),"ucsur"),sourceStart,sourceStart+body.length(),kind,pair,o));
    }

    private void parseQuote(DocumentSegment seg,int segIndex,List<Logical>out,FontPairInfo pair,RenderOptions o) throws Exception{
        String q=unescape(seg.value());if(o.parser().interpretDoubleQuotesAsTeTo()){
            out.add(glyphRun("te",List.of(0x300C),seg.sourceStart(),seg.sourceStart()+1,"interpretedQuote",false,true,pair,o));
            int before=out.size();parseText(q,seg.sourceStart()+1,"interpretedQuote",segIndex,out,pair,o);for(int i=before;i<out.size();i++)out.set(i,markInterpreted(out.get(i)));
            out.add(glyphRun("to",List.of(0x300D),Math.max(seg.sourceStart()+1,seg.sourceEnd()-1),seg.sourceEnd(),"interpretedQuote",false,true,pair,o));
        }else out.add(literalRenderedRun(q,seg.value(),seg.sourceStart(),seg.sourceEnd(),"quote",true,false,false,pair,o));
    }

    private Logical imageRun(DocumentSegment seg,int segIndex,FontPairInfo pair,RenderOptions o) throws Exception{
        ImageDescriptor d=seg.image();BufferedImage img=loadImage(d,o.fontSize());double baseline="center".equalsIgnoreCase(d.valign())?img.getHeight()*0.75:img.getHeight();RenderRun r=baseRun("cartouche","raster","cartouche",false,false,false,0,null,null,List.of(),List.of(),"",pair.renderAdapterId(),"","image",seg.sourceStart(),seg.sourceEnd(),List.of(),false,false,false,d.alt());return new Logical(r,new Graphic(null,null,null,Color.BLACK,img,d.src(),img.getWidth(),img.getHeight(),baseline,List.of()));
    }

    private Logical numericRun(String source,RenderResult rr,int start,int end,String sourceKind,FontPairInfo pair,RenderOptions o) throws Exception{
        RenderOptions ro=o.withPaddingPx(0).withIncludePlan(false);ProductionRenderer.Shaped s=production.shape(source,rr,pair,ro);ParseResult p=rr.parsed;Integer op=rr.activeInnerCodepoints.isEmpty()?null:rr.activeInnerCodepoints.getFirst(),cl=rr.activeInnerCodepoints.isEmpty()?null:rr.activeInnerCodepoints.getLast();int base=p.numberBase==null?10:p.numberBase;List<Integer>render=FontRenderAdapters.renderCodepointsWithoutScaleMarkers(s.text());RenderRun r=baseRun("cartouche","raster","number",true,p.isHex,p.isBinary,base,op,cl,rr.activeInnerCodepoints,render,s.text(),pair.renderAdapterId(),source,sourceKind,start,end,List.of(),false,false,false,null);return new Logical(r,graphic(s,List.of(),null,Color.BLACK));
    }

    private Logical literalCartoucheRun(String source,OrdinaryCartouche oc,int start,int end,String sourceKind,FontPairInfo pair,RenderOptions o)throws Exception{
        RenderOptions ro=o.withPaddingPx(0).withIncludePlan(false);ProductionRenderer.Shaped s=production.shapeLiteralCartouche(oc,pair,ro);List<Integer>full=new ArrayList<>();full.add(Constants.CARTOUCHE_START);full.addAll(oc.innerCodepoints);full.add(Constants.CARTOUCHE_END);String text=codepoints(full);RenderRun r=baseRun("cartouche","raster","cartouche",false,false,false,0,Constants.CARTOUCHE_START,Constants.CARTOUCHE_END,oc.innerCodepoints,full,text,"identity",source,sourceKind,start,end,List.of(),false,false,false,null);return new Logical(r,graphic(s,List.of(),null,Color.BLACK));
    }

    private Logical cartoucheRun(String source,OrdinaryCartouche oc,int start,int end,String sourceKind,FontPairInfo pair,RenderOptions o) throws Exception{
        RenderOptions ro=o.withPaddingPx(0).withIncludePlan(false);ProductionRenderer.Shaped s=production.shapeOrdinaryCartouche("["+source+"]",oc,pair,ro);FontRenderAdapters.Adapted a=FontRenderAdapters.adaptOrdinaryCartouche(pair,oc.innerCodepoints,oc.scaleMarkers);List<Integer>render=FontRenderAdapters.renderCodepointsWithoutScaleMarkers(a.text());List<TallyGroup>groups=production.manualTallyGroups(oc,pair,ro);List<Integer>canonical=oc.innerCodepoints;List<Integer>semanticTallies=oc.hasManualTallies()?oc.manualTallies:List.of();RenderRun r=baseRun("cartouche","raster","cartouche",false,false,false,0,Constants.CARTOUCHE_START,Constants.CARTOUCHE_END,canonical,render,s.text(),pair.renderAdapterId(),source,sourceKind,start,end,semanticTallies,false,false,false,null);return new Logical(r,graphic(s,groups,null,Color.BLACK));
    }

    private Logical glyphRun(String source,List<Integer>cps,int start,int end,String sourceKind,boolean quoted,boolean interpreted,FontPairInfo pair,RenderOptions o) throws Exception{
        boolean rawBypass=DocumentParser.parseRawUnicodeSequence(source.trim())!=null;List<Integer>render;
        if(rawBypass)render=List.copyOf(cps);else{RenderAdapter a=runtimeAdapters.get(pair.renderAdapterId());render=a==null?FontRenderAdapters.adaptFullWordRun(pair,cps):List.copyOf(a.adapt(cps,pair,o.fontSize()));}
        String text=codepoints(render);RenderOptions ro=o.withPaddingPx(0).withIncludePlan(false);boolean synthetic=cps.size()==1&&(cps.getFirst()==0x300C||cps.getFirst()==0x300D)&&"synthetic".equalsIgnoreCase(String.valueOf(pair.renderAdapterSettings().get("cornerBracketMode")));ProductionRenderer.Shaped s=synthetic?production.shapeSyntheticCornerBracket(cps.getFirst(),pair,ro):production.shape(text,null,pair,ro);String adapter=rawBypass?"identity":pair.renderAdapterId();String mode=synthetic?"synthetic-corner-bracket":"text";RenderRun r=baseRun(rawBypass||cps.size()>1||render.size()>1?"run":"glyph",mode,"word",false,false,false,0,null,null,cps,render,text,adapter,source,sourceKind,start,end,List.of(),quoted,interpreted,false,null);return new Logical(r,graphic(s,List.of(),null,Color.BLACK));
    }

    private Logical literalRun(String source,int start,int end,String sourceKind,boolean quoted,boolean interpreted,boolean unknown,FontPairInfo pair,RenderOptions o){return literalRenderedRun(source,source,start,end,sourceKind,quoted,interpreted,unknown,pair,o);}
    private Logical literalRenderedRun(String renderText,String source,int start,int end,String sourceKind,boolean quoted,boolean interpreted,boolean unknown,FontPairInfo pair,RenderOptions o){
        Font f=literalFont(o.fontSize());String shown=renderText.isEmpty()?" ":renderText;TextLayout tl=new TextLayout(shown,f,FRC);Shape raw=tl.getOutline(null);Rectangle2D b=raw.getBounds2D();double margin=unknown?o.paint().unknownText().paddingPx():0;
        // U+3000 (the `zz` helper) is an ideographic/em space.  Canvas
        // measureText() gives it advance even though it has no ink.  Java2D's
        // outline bounds are empty, so using only those bounds collapsed `zz`
        // to a 1 px run and silently removed the intended spacing.
        boolean whitespaceOnly=!renderText.isEmpty()&&renderText.codePoints().allMatch(Character::isWhitespace);
        double baseline,w,h;Shape fg;
        if(whitespaceOnly){
            double advance=renderText.codePoints().allMatch(cp->cp==0x3000)?o.fontSize():Math.max(1,tl.getAdvance());
            // Whitespace has advance but no ink; it must not increase the line
            // ascent/descent.  This mirrors Canvas measureText() for U+3000.
            baseline=0;w=Math.max(1,advance+2*margin);h=1;fg=new Area();
        }else{
            AffineTransform at=AffineTransform.getTranslateInstance(margin-b.getX(),margin-b.getY());fg=at.createTransformedShape(raw);baseline=at.getTranslateY();w=Math.max(1,b.getWidth()+2*margin);h=Math.max(1,b.getHeight()+2*margin);
        }
        Shape halo=o.haloEnabled()&&!fg.getBounds2D().isEmpty()?new BasicStroke(haloWidth(o),BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND).createStrokedShape(fg):null;Shape dec=null;Color dc=Color.BLACK;if(unknown){UnknownTextStyle us=o.paint().unknownText();Shape box=new Rectangle2D.Double(0,0,w,h);float[]dash=us.dash().isEmpty()?null:toDash(us.dash());BasicStroke st=dash==null?new BasicStroke(us.lineWidthPx()):new BasicStroke(us.lineWidthPx(),BasicStroke.CAP_BUTT,BasicStroke.JOIN_MITER,10,dash,0);dec=st.createStrokedShape(box);dc=color(us.color(),Color.BLACK);}String role=unknown&&(interpreted||"interpretedQuote".equals(sourceKind))?"unknown":"literal";RenderRun r=baseRun("text","raster",role,false,false,false,0,null,null,List.of(),List.of(),renderText,"identity",source,sourceKind,start,end,List.of(),quoted,interpreted,unknown,null);return new Logical(r,new Graphic(fg,halo,dec,dc,null,null,w,h,baseline,List.of()));
    }

    private static Logical forceKind(Logical l,String kind){RenderRun r=l.run();RenderRun x=new RenderRun(r.id(),r.lineIndex(),r.runIndex(),kind,r.renderMode(),r.fontRole(),r.numericCartouche(),r.hexCartouche(),r.binaryCartouche(),r.numericBase(),r.openerCodepoint(),r.closerCodepoint(),r.canonicalCodepoints(),r.renderCodepoints(),r.renderText(),r.renderAdapterId(),r.sourceText(),r.sourceKind(),r.sourceStart(),r.sourceEnd(),r.manualTallies(),r.tallyGroups(),r.quoted(),r.interpretedQuote(),r.unrecognized(),r.imageAlt(),r.xPx(),r.yPx(),r.widthPx(),r.heightPx(),r.baselineYPx());return new Logical(x,l.graphic());}
    private static Logical markInterpreted(Logical l){RenderRun r=l.run();RenderRun x=new RenderRun(r.id(),r.lineIndex(),r.runIndex(),r.kind(),r.renderMode(),r.fontRole(),r.numericCartouche(),r.hexCartouche(),r.binaryCartouche(),r.numericBase(),r.openerCodepoint(),r.closerCodepoint(),r.canonicalCodepoints(),r.renderCodepoints(),r.renderText(),r.renderAdapterId(),r.sourceText(),r.sourceKind(),r.sourceStart(),r.sourceEnd(),r.manualTallies(),r.tallyGroups(),r.quoted(),true,r.unrecognized(),r.imageAlt(),r.xPx(),r.yPx(),r.widthPx(),r.heightPx(),r.baselineYPx());return new Logical(x,l.graphic());}
    private RenderRun baseRun(String kind,String mode,String role,boolean numeric,boolean hex,boolean binary,int base,Integer op,Integer cl,List<Integer>canonical,List<Integer>render,String text,String adapter,String source,String sourceKind,int start,int end,List<Integer>tallies,boolean quoted,boolean interpreted,boolean unknown,String imageAlt){return new RenderRun("",0,0,kind,mode,role,numeric,hex,binary,base,op,cl,canonical,render,text,adapter,source,sourceKind,start,end,tallies,List.of(),quoted,interpreted,unknown,imageAlt,0,0,0,0,0);}
    private Graphic graphic(ProductionRenderer.Shaped s,List<TallyGroup>groups,Shape decoration,Color dc){double baseline=s.placement()==null?s.height()*0.8:s.placement().getTranslateY();return new Graphic(s.outline(),s.haloShape(),decoration,dc,null,null,s.width(),s.height(),baseline,groups);}

    private static Integer fullGlyphCp(String raw){String k=normalizeFullGlyphKey(raw);return switch(k){case "te"->0x300C;case "to"->0x300D;case "zz"->0x3000;case "ota"->0xF199C;default->Constants.ALL_WORD_CODEPOINTS.get(k);};}
    private static String normalizeFullGlyphKey(String raw){String k=raw==null?"":raw.trim().toLowerCase(Locale.ROOT);k=GLYPH_INPUT_ALIASES.getOrDefault(k,k);if(Set.of("·",".",":",",").contains(k))return k;return k.replaceAll("[^a-z0-9<>^.]+","");}
    private static List<Integer> glyphExpressionCps(String expression){String x=expression==null?"":expression.trim();if(x.isEmpty()||x.matches(".*\\s+.*"))return null;String[]words=x.split("[&+-]",-1);Matcher ops=Pattern.compile("[&+-]").matcher(x);List<String>o2=new ArrayList<>();while(ops.find())o2.add(ops.group());if(words.length!=o2.size()+1)return null;List<Integer>out=new ArrayList<>();for(int i=0;i<words.length;i++){if(words[i].isEmpty())return null;Integer cp=fullGlyphCp(words[i]);if(cp==null)return null;out.add(cp);if(i<o2.size())out.add(switch(o2.get(i)){case "&"->0x200D;case "-"->0xF1995;default->0xF1996;});}return out;}
    private static List<Integer> glyphWordsCps(String text){String t=text==null?"":text.trim();if(t.isEmpty())return null;List<Integer>out=new ArrayList<>();for(String f:t.split("\\s+")){List<Integer>c=glyphExpressionCps(f);if(c==null){Integer cp=fullGlyphCp(f);if(cp==null)return null;c=List.of(cp);}out.addAll(c);}return out;}
    private static List<Integer> extendedGlyphCps(String left,String head,String right){Integer h=fullGlyphCp(head);if(h==null)return null;List<Integer>out=new ArrayList<>();if(left!=null&&!left.trim().isEmpty()){List<Integer>x=glyphWordsCps(left);if(x==null||x.isEmpty())return null;out.add(0xF199A);out.addAll(x);out.add(0xF199B);}out.add(h);if(right!=null&&!right.trim().isEmpty()){List<Integer>x=glyphWordsCps(right);if(x==null||x.isEmpty())return null;out.add(0xF1997);out.addAll(x);out.add(0xF1998);}return out.size()>1?out:null;}
    private static String legacyLongPiInner(String source){String s=source.trim();String l=s.toLowerCase(Locale.ROOT);if(l.startsWith("pi+__")){String[]p=s.substring(5).split("__");if(p.length<1||p.length>3)return null;for(String x:p)if(fullGlyphCp(x)==null)return null;return String.join(" ",p);}Matcher m=Pattern.compile("(?i)^pi(\\+{1,3}|-{2,3})(.*)$").matcher(s);if(!m.matches())return null;int n=m.group(1).length();String[]w=m.group(2).trim().split("\\s+");if(w.length!=n)return null;for(String x:w)if(fullGlyphCp(x)==null)return null;return String.join(" ",w);}
    private static String normalizeExtendedLegacyCartouche(String body){String s=body.trim();if(!s.startsWith("_"))return null;List<String>w=new ArrayList<>();for(String p:s.split("_")){p=p.trim();if(p.isEmpty())continue;if(fullGlyphCp(p)==null)return null;w.add(p);}return w.isEmpty()?null:String.join(" ",w);}

    private static boolean isDirectRenderCodepoint(int cp){return (cp>=0xF1900&&cp<=0xF19FF)||cp==0x300C||cp==0x300D;}
    private static String normalizeWord(String s){return s==null?"":s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9<>^.]","");}
    private static boolean looksNumeric(String s){return s!=null&&s.matches(".*[0-9].*");}
    private static String codepoints(List<Integer>cps){StringBuilder b=new StringBuilder();for(int cp:cps)b.appendCodePoint(cp);return b.toString();}
    private static String unescape(String s){StringBuilder o=new StringBuilder();for(int i=0;i<s.length();i++){char c=s.charAt(i);if(c!='\\'||i+1>=s.length()){o.append(c);continue;}char n=s.charAt(++i);switch(n){case'\"'->o.append('\"');case'\\'->o.append('\\');case't'->o.append("    ");case'n'->o.append('\n');default->o.append(n);}}return o.toString();}

    private RenderResult numericRender(String source,ParseOptions p){ParseOptions q=(!p.enableBinaryParsing()&&p.enableBinaryRendering())?p.withEnableBinaryParsing(true):p;return V11Numeric.normalizeRenderResult(new NanpaRenderer().render(source,q),source);}

    private static RenderResult directRender(ParseResult p){List<String>w=p.tpWords==null?List.of():List.copyOf(p.tpWords);List<Integer>inner=List.copyOf(p.innerCodepoints),full=List.copyOf(p.codepoints);StringBuilder b=new StringBuilder();for(int cp:full)b.appendCodePoint(cp);return new RenderResult(p,w,inner,full,null,null,null,false,w,inner,full,b.toString());}

    private static ParseResult phraseResult(String source,List<String>words,ParseOptions p){List<Integer>cps=new ArrayList<>();for(String w:words){Integer cp=Constants.ALL_WORD_CODEPOINTS.get(w);if(cp==null)return null;cps.add(cp);}ParseResult r=new ParseResult();r.input=source;r.tpWords=List.copyOf(words);r.words=List.copyOf(words);r.ucsurCodepoints=List.copyOf(cps);r.innerCodepoints=List.copyOf(cps);r.codepoints=NanpaApi.withCartoucheMarkers(cps);r.numericMode=p.numericModeName();return r;}
    private static final Set<String> PHRASE_DIGITS=Set.of("ijo","wan","tu","seli","awen","luka","utala","mun","pipi","jo");
    private static RenderResult fullPhraseRender(String source,ParseOptions p,boolean abbreviatedOnly){
        String t=source.trim();if(t.isEmpty()||!t.matches("[a-z]+(?:\\s+[a-z]+)+"))return null;List<String>w=new ArrayList<>(Arrays.asList(t.split("\\s+")));if(w.size()<3||!w.getFirst().equals("nanpa")||!w.getLast().equals("nanpa"))return null;
        if(abbreviatedOnly){if(!p.abbreviateNumericCartouches())return null;boolean positive=w.size()>=4&&w.get(1).equals("en");boolean has=false;for(int i=0;i<w.size();i++){String x=w.get(i);if(!Constants.ALL_WORD_CODEPOINTS.containsKey(x))return null;boolean finalN=x.equals("nanpa")&&i==w.size()-1,marker=positive&&i==1&&x.equals("en");if(i>0&&!finalN&&!marker&&Set.of("nanpa","en","e","nena","open","ala","ike","uta").contains(x))return null;if(PHRASE_DIGITS.contains(x))has=true;}if(!has)return null;ParseResult r=phraseResult(t,w,p);return r==null?null:directRender(r);}
        String second=w.get(1);if(!Set.of("e","en","esun").contains(second))return null;
        // Bare `nanpa en <digits> nanpa` is reserved for the abbreviated grammar.
        if(second.equals("en")){boolean scaffold=false;for(String x:w.subList(2,w.size()-1))if(Set.of("nanpa","en","e","nena","open","ala","ike","uta").contains(x))scaffold=true;if(!scaffold)return null;}
        boolean has=false;for(int i=0;i<w.size();i++){String x=w.get(i);if(!Constants.ALL_WORD_CODEPOINTS.containsKey(x))return null;if(PHRASE_DIGITS.contains(x))has=true;if(i>0&&PHRASE_DIGITS.contains(w.get(i-1))&&PHRASE_DIGITS.contains(x))return null;}if(!has)return null;
        List<String>canon=new ArrayList<>(w);boolean positive=canon.size()>=5&&canon.get(0).equals("nanpa")&&canon.get(1).equals("e")&&canon.get(2).equals("nena")&&canon.get(3).equals("en");if(p.nanpaColonRendering()&&canon.size()>=3)canon.set(1,":");for(int i=2;i<canon.size()-1;i++)if(canon.get(i).equals("en")&&!(positive&&i==3))canon.set(i,"e");ParseResult r=phraseResult(t,canon,p);return r==null?null:directRender(r);
    }


    private static List<Integer> lettersToFallbackGlyphCps(String source){Set<String>banned=Set.of("ota","kolon","koma","te","to","zz");List<String>keys=Constants.ALL_WORD_CODEPOINTS.keySet().stream().filter(k->k.matches("[a-z]+")&&!banned.contains(k)).sorted().toList();Map<Character,Integer>bucket=new HashMap<>();for(String k:keys)bucket.putIfAbsent(k.charAt(0),Constants.ALL_WORD_CODEPOINTS.get(k));List<Integer>out=new ArrayList<>();for(char c:source.toLowerCase(Locale.ROOT).toCharArray())if(c>='a'&&c<='z'&&bucket.containsKey(c))out.add(bucket.get(c));return out;}

    private static List<Integer> properNameCps(String word){if(word==null||!word.matches("[A-Za-z]+")||!word.matches("(?i)[aeijklmnostpuw]+"))return null;Map<Character,Integer>bucket=new HashMap<>();Constants.ALL_WORD_CODEPOINTS.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(e->{String w=e.getKey();if(w.matches("[a-z]+")&&!w.isEmpty())bucket.putIfAbsent(w.charAt(0),e.getValue());});List<Integer>out=new ArrayList<>();for(char c:word.toLowerCase(Locale.ROOT).toCharArray()){Integer cp=bucket.get(c);if(cp==null)return null;out.add(cp);}return out;}

    private static List<String> nnpWords(String value){List<String>w=NanpaCore.tryPlainDecimalToNasinNanpaPonaWords(value);return w==null?List.of():w;}
    private static Integer nnpGlyphCp(String word){return Constants.ALL_WORD_CODEPOINTS.get("ale".equals(word)?"ali":word);}

    private BufferedImage loadImage(ImageDescriptor d,float fontPx) throws IOException{BufferedImage src=null;String href=d.src();if(href.startsWith("data:image/")){int comma=href.indexOf(',');if(comma>0){String meta=href.substring(0,comma),data=href.substring(comma+1);byte[]bytes=meta.contains(";base64")?Base64.getDecoder().decode(data):java.net.URLDecoder.decode(data,StandardCharsets.UTF_8).getBytes(StandardCharsets.ISO_8859_1);try{src=ImageIO.read(new ByteArrayInputStream(bytes));}catch(IOException ignored){src=null;}}}else if(!href.isBlank()){Path p=Path.of(href);if(Files.isRegularFile(p))try{src=ImageIO.read(p.toFile());}catch(IOException ignored){src=null;}}if(src==null)src=new BufferedImage(1,1,BufferedImage.TYPE_INT_ARGB);double w=parseSize(d.w(),fontPx),h=parseSize(d.h(),fontPx);if(Double.isNaN(w)&&Double.isNaN(h))h=fontPx;if(Double.isNaN(w))w=Math.max(1,h*src.getWidth()/Math.max(1.0,src.getHeight()));if(Double.isNaN(h))h=Math.max(1,w*src.getHeight()/Math.max(1.0,src.getWidth()));BufferedImage out=new BufferedImage(Math.max(1,(int)Math.round(w)),Math.max(1,(int)Math.round(h)),BufferedImage.TYPE_INT_ARGB);Graphics2D g=out.createGraphics();try{g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BILINEAR);g.drawImage(src,0,0,out.getWidth(),out.getHeight(),null);}finally{g.dispose();}if(d.transparent())keyTransparent(out,d.wriggle());return out;}
    private static void keyTransparent(BufferedImage im,double wiggle){int key=im.getRGB(0,0),kr=(key>>16)&255,kg=(key>>8)&255,kb=key&255,ka=(key>>>24)&255,w=(int)Math.max(0,wiggle);for(int y=0;y<im.getHeight();y++)for(int x=0;x<im.getWidth();x++){int c=im.getRGB(x,y),a=(c>>>24)&255,r=(c>>16)&255,g=(c>>8)&255,b=c&255;if(Math.abs(r-kr)<=w&&Math.abs(g-kg)<=w&&Math.abs(b-kb)<=w&&Math.abs(a-ka)<=Math.max(8,w))im.setRGB(x,y,c&0x00FFFFFF);}}
    private static double parseSize(String v,float base){if(v==null||v.isBlank())return Double.NaN;String s=v.trim().toLowerCase();try{if(s.endsWith("em"))return Double.parseDouble(s.substring(0,s.length()-2))*base;if(s.endsWith("px"))return Double.parseDouble(s.substring(0,s.length()-2));return Double.parseDouble(s);}catch(Exception e){return Double.NaN;}}

    private Font literalFont(float px){Font base=new Font("SansSerif",Font.PLAIN,Math.round(px));try{Font support=production.loadSupportFont("literalText");if(support!=null)base=support;}catch(Exception ignored){}return base.deriveFont(px);}
    private static float[]toDash(List<Float>x){float[]a=new float[x.size()];for(int i=0;i<a.length;i++)a[i]=Math.max(0.1f,x.get(i));return a;}
    private static float haloWidth(RenderOptions o){if(!o.haloEnabled())return 0;if(o.haloWidthPx()>0)return o.haloWidthPx();return Math.max(2f,Math.min(24f,Math.round(Math.max(8f,o.fontSize())*0.10f)));}
    private static Shape translate(Shape s,double x,double y){return s==null?null:AffineTransform.getTranslateInstance(x,y).createTransformedShape(s);}
    private static List<TallyGroup>translateGroups(List<TallyGroup>g,double x,double y){if(g==null||g.isEmpty())return List.of();List<TallyGroup>out=new ArrayList<>();for(TallyGroup t:g){List<Double>c=t.strokeCentersPx().stream().map(v->v+x).toList();out.add(new TallyGroup(t.ownerIndex(),t.count(),t.ownerLeftPx()+x,t.ownerRightPx()+x,t.centerXPx()+x,t.topYPx()+y,t.bottomYPx()+y,t.strokeWidthPx(),c));}return List.copyOf(out);}
    private static Color color(String h,Color d){try{return Color.decode(h);}catch(Exception e){return d;}}
    private static String hex(Color c){return String.format("#%02X%02X%02X",c.getRed(),c.getGreen(),c.getBlue());}
    private static String n(double v){if(Math.abs(v)<1e-6)v=0;return String.format(Locale.ROOT,"%.3f",v).replaceAll("0+$","").replaceAll("\\.$","");}
    private static String xml(String s){return s==null?"":s.replace("&","&amp;").replace("\"","&quot;").replace("<","&lt;").replace(">","&gt;");}
    private static String pngDataUrl(BufferedImage im){if(im==null)return "";try{ByteArrayOutputStream b=new ByteArrayOutputStream();ImageIO.write(im,"png",b);return "data:image/png;base64,"+Base64.getEncoder().encodeToString(b.toByteArray());}catch(Exception e){return "";}}
}
