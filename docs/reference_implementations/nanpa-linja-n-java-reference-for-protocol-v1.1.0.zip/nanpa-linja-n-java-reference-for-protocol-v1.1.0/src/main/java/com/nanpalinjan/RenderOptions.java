package com.nanpalinjan;

import java.util.Map;

/** High-level render configuration. Original constructors are retained for compatibility. */
public record RenderOptions(
        String format,
        String fontKey,
        float fontSize,
        int paddingPx,
        ParseOptions parser,
        boolean includePlan,
        boolean haloEnabled,
        String haloColor,
        float haloWidthPx,
        LayoutOptions layout,
        PaintOptions paint,
        String numericOutput) {
    public RenderOptions() { this("canvas", "nasinNanpa", 56f, 18, ParseOptions.publicDefaults(), true, false, "#FFFFFF", 0f,new LayoutOptions(),new PaintOptions(),"source"); }
    /** Compatibility constructor retained for the original six-field Java facade. */
    public RenderOptions(String format, String fontKey, float fontSize, int paddingPx, ParseOptions parser, boolean includePlan) {
        this(format,fontKey,fontSize,paddingPx,parser,includePlan,false,"#FFFFFF",0f,new LayoutOptions(),new PaintOptions(),"source");
    }
    /** Compatibility constructor retained for the pre-full-profile nine-field facade. */
    public RenderOptions(String format, String fontKey, float fontSize, int paddingPx, ParseOptions parser, boolean includePlan, boolean haloEnabled, String haloColor, float haloWidthPx) {
        this(format,fontKey,fontSize,paddingPx,parser,includePlan,haloEnabled,haloColor,haloWidthPx,new LayoutOptions(),new PaintOptions(),"source");
    }
    /** Compatibility constructor retained for the pre-numericOutput eleven-field facade. */
    public RenderOptions(String format,String fontKey,float fontSize,int paddingPx,ParseOptions parser,boolean includePlan,boolean haloEnabled,String haloColor,float haloWidthPx,LayoutOptions layout,PaintOptions paint){
        this(format,fontKey,fontSize,paddingPx,parser,includePlan,haloEnabled,haloColor,haloWidthPx,layout,paint,"source");
    }
    public RenderOptions {
        format = format == null || format.isBlank() ? "canvas" : format.toLowerCase();
        fontKey = fontKey == null || fontKey.isBlank() ? "nasinNanpa" : fontKey;
        fontSize = Float.isFinite(fontSize) && fontSize >= 8 ? fontSize : 56f;
        paddingPx = Math.max(0, paddingPx);
        parser = parser == null ? ParseOptions.publicDefaults() : parser;
        haloColor = PaintOptions.normalizeColor(haloColor,"#FFFFFF");
        haloWidthPx = Float.isFinite(haloWidthPx) && haloWidthPx >= 0 ? haloWidthPx : 0f;
        layout = layout == null ? new LayoutOptions() : layout;
        paint = paint == null ? new PaintOptions() : paint;
        numericOutput = numericOutput == null || numericOutput.isBlank() ? "source" : numericOutput;
    }
    @SuppressWarnings("unchecked")
    public static RenderOptions fromMap(Map<String,?>m){
        if(m==null)return new RenderOptions();
        Map<String,?> parser=m.get("parser") instanceof Map<?,?>x?(Map<String,?>)x:Map.of();
        Map<String,?> layout=m.get("layout") instanceof Map<?,?>x?(Map<String,?>)x:Map.of();
        Map<String,?> paint=m.get("paint") instanceof Map<?,?>x?(Map<String,?>)x:Map.of();
        Map<String,?> halo=paint.get("halo") instanceof Map<?,?>x?(Map<String,?>)x:Map.of();
        String font=String.valueOf(m.containsKey("font")?m.get("font"):"nasinNanpa");
        float fontSize=num(m.get("fontSize"), num(layout.get("fontPx"),56));
        int padding=Math.round(num(m.get("paddingPx"),num(layout.get("paddingPx"),18)));
        String numericOutput=String.valueOf(m.containsKey("numericOutput")?m.get("numericOutput"):"source");
        return new RenderOptions(String.valueOf(m.containsKey("format")?m.get("format"):"canvas"),font,fontSize,padding,ParseOptions.fromPublicMap(parser),bool(m.get("includePlan"),true),bool(halo.get("enabled"),false),String.valueOf(halo.containsKey("color")?halo.get("color"):"#FFFFFF"),num(halo.get("widthPx"),0),LayoutOptions.fromMap(layout),PaintOptions.fromMap(paint),numericOutput);
    }
    private static float num(Object v,float d){return v instanceof Number n?n.floatValue():d;}
    private static boolean bool(Object v,boolean d){return v instanceof Boolean b?b:v==null?d:Boolean.parseBoolean(String.valueOf(v));}

    private RenderOptions c(String fmt,String fk,float fs,int pad,ParseOptions p,boolean ip,boolean he,String hc,float hw,LayoutOptions l,PaintOptions pa,String no){return new RenderOptions(fmt,fk,fs,pad,p,ip,he,hc,hw,l,pa,no);}
    public RenderOptions withFormat(String v){ return c(v,fontKey,fontSize,paddingPx,parser,includePlan,haloEnabled,haloColor,haloWidthPx,layout,paint,numericOutput); }
    public RenderOptions withFont(String v){ return c(format,v,fontSize,paddingPx,parser,includePlan,haloEnabled,haloColor,haloWidthPx,layout,paint,numericOutput); }
    public RenderOptions withFontSize(float v){ return c(format,fontKey,v,paddingPx,parser,includePlan,haloEnabled,haloColor,haloWidthPx,layout,paint,numericOutput); }
    public RenderOptions withPaddingPx(int v){ return c(format,fontKey,fontSize,v,parser,includePlan,haloEnabled,haloColor,haloWidthPx,layout,paint,numericOutput); }
    public RenderOptions withParser(ParseOptions v){ return c(format,fontKey,fontSize,paddingPx,v,includePlan,haloEnabled,haloColor,haloWidthPx,layout,paint,numericOutput); }
    public RenderOptions withIncludePlan(boolean v){ return c(format,fontKey,fontSize,paddingPx,parser,v,haloEnabled,haloColor,haloWidthPx,layout,paint,numericOutput); }
    public RenderOptions withHalo(boolean enabled){ return c(format,fontKey,fontSize,paddingPx,parser,includePlan,enabled,haloColor,haloWidthPx,layout,paint,numericOutput); }
    public RenderOptions withHaloColor(String color){ return c(format,fontKey,fontSize,paddingPx,parser,includePlan,haloEnabled,color,haloWidthPx,layout,paint,numericOutput); }
    /** 0 means JavaScript-compatible automatic width (~10% of font size, clamped 2..24 px). */
    public RenderOptions withHaloWidthPx(float width){ return c(format,fontKey,fontSize,paddingPx,parser,includePlan,haloEnabled,haloColor,width,layout,paint,numericOutput); }
    public RenderOptions withLayout(LayoutOptions v){return c(format,fontKey,fontSize,paddingPx,parser,includePlan,haloEnabled,haloColor,haloWidthPx,v,paint,numericOutput);}
    public RenderOptions withPaint(PaintOptions v){return c(format,fontKey,fontSize,paddingPx,parser,includePlan,haloEnabled,haloColor,haloWidthPx,layout,v,numericOutput);}
    public RenderOptions withFillStyle(String v){return withPaint(new PaintOptions(v,paint.unknownText()));}
    public RenderOptions withNumericOutput(String v){return c(format,fontKey,fontSize,paddingPx,parser,includePlan,haloEnabled,haloColor,haloWidthPx,layout,paint,v);}
}
