package com.nanpalinjan;

import java.util.*;

/** Parsed ordinary (non-numeric, non-literal) cartouche content. */
final class OrdinaryCartouche {
    final List<Integer> innerCodepoints;
    final List<Integer> manualTallies;
    final String tallyMode;
    /** Per-inner-cell v1.1 inline vulgar-fraction scale marker, or 0. */
    final List<Integer> scaleMarkers;

    private OrdinaryCartouche(List<Integer> cps,List<Integer> tallies,String tallyMode,List<Integer> scales){
        this.innerCodepoints=List.copyOf(cps);
        this.manualTallies=List.copyOf(tallies);
        this.tallyMode=tallyMode;
        this.scaleMarkers=List.copyOf(scales);
    }

    static OrdinaryCartouche parse(String input, FontPairInfo pair){return parse(input,pair,ParseOptions.publicDefaults());}
    static OrdinaryCartouche parse(String input, FontPairInfo pair, ParseOptions parser){
        if(input==null)return null;String s=input.trim();if(s.length()<2||s.charAt(0)!='['||s.charAt(s.length()-1)!=']')return null;
        return parseBody(s.substring(1,s.length()-1),pair,parser);
    }

    static OrdinaryCartouche parseBody(String body,FontPairInfo pair,ParseOptions parser){
        if(body==null||body.isBlank())return null;ParseOptions p=parser==null?ParseOptions.publicDefaults():parser;
        boolean commaTallies=p.cartoucheCommaTallyMarks();
        String mode=p.cartoucheTallyMode();
        if(mode==null||mode.isBlank())mode=String.valueOf(pair.settings().getOrDefault("cartoucheTallyMode","ucsur")).trim().toLowerCase(Locale.ROOT);
        if(!Set.of("manual","comma","ucsur").contains(mode))mode="ucsur";
        final String tallyMode=mode;
        boolean vulgar=Boolean.TRUE.equals(pair.settings().get("cartoucheVulgarFractions"));
        List<Integer> cps=new ArrayList<>(),tallies=new ArrayList<>(),scales=new ArrayList<>();StringBuilder cur=new StringBuilder();
        final int[] lastScalable={-1}; final boolean[] tallyStarted={false};
        class Push {void add(int cp,boolean scalable){cps.add(cp);tallies.add(0);scales.add(0);if(scalable){lastScalable[0]=cps.size()-1;tallyStarted[0]=false;}else lastScalable[0]=-1;}}
        Push push=new Push();
        class Flush {boolean run(){if(cur.isEmpty())return true;String token=cur.toString().trim().toLowerCase(Locale.ROOT);cur.setLength(0);if(token.isEmpty())return true;Integer cp=Constants.ALL_WORD_CODEPOINTS.get(token);if(cp==null)return false;if(cp==0xF199E&&"manual".equals(tallyMode)){if(!cps.isEmpty())tallies.set(tallies.size()-1,Math.min(8,tallies.getLast()+1));lastScalable[0]=-1;tallyStarted[0]=true;return true;}push.add(cp,true);return true;}}
        Flush flush=new Flush();
        int[] runes=body.codePoints().toArray();
        for(int i=0;i<runes.length;){int cp=runes[i];
            if(Character.isWhitespace(cp)){if(!flush.run())return null;i++;continue;}
            if(vulgar&&FontRenderAdapters.isVulgarScaleMarker(cp)){
                if(!flush.run())return null;int idx=lastScalable[0];if(idx<0||tallyStarted[0]||scales.get(idx)!=0)return null;scales.set(idx,cp);i++;continue;
            }
            if(vulgar&&i+2<runes.length){String candidate=new String(runes,i,3);Integer scale=FontRenderAdapters.asciiScaleAlias(candidate);boolean nextBad=i+3<runes.length&&(Character.isDigit(runes[i+3])||runes[i+3]=='/');if(scale!=null&&!nextBad){if(!cur.toString().trim().isEmpty()&&!flush.run())return null;int idx=lastScalable[0];if(idx>=0&&!tallyStarted[0]&&scales.get(idx)==0){scales.set(idx,scale);i+=3;continue;}}}
            if(cp=='.'||cp==0x00B7||cp==':'){if(!flush.run())return null;push.add(cp==':'?0xF199D:0xF199C,true);i++;continue;}
            if(cp==','){if(!flush.run())return null;tallyStarted[0]=true;lastScalable[0]=-1;if(!commaTallies){i++;continue;}if("manual".equals(tallyMode)){if(!cps.isEmpty())tallies.set(tallies.size()-1,Math.min(8,tallies.getLast()+1));}else if("comma".equals(tallyMode)){push.add((int)',',false);}else{push.add(0xF199E,false);}i++;continue;}
            cur.appendCodePoint(cp);i++;
        }
        if(!flush.run()||cps.isEmpty())return null;return new OrdinaryCartouche(cps,tallies,tallyMode,scales);
    }

    static OrdinaryCartouche of(List<Integer> cps,List<Integer> tallies,String mode){return of(cps,tallies,mode,null);}
    static OrdinaryCartouche of(List<Integer> cps,List<Integer> tallies,String mode,List<Integer> scales){
        List<Integer> t=tallies==null?Collections.nCopies(cps.size(),0):tallies;
        List<Integer> s=scales==null?Collections.nCopies(cps.size(),0):scales;
        return new OrdinaryCartouche(cps,t,mode==null?"ucsur":mode,s);
    }

    boolean hasManualTallies(){return manualTallies.stream().anyMatch(n->n!=null&&n>0);}
}
