package com.nanpalinjan;

import java.util.*;

/** Protocol-v1.1 normalization layered above the frozen Core-v1 parser. */
final class V11Numeric {
    private V11Numeric() {}

    static ParseResult normalizeForRendering(ParseResult source, Object input) {
        if (source == null) return null;
        ParseResult r = copy(source);
        String text = input == null ? "" : String.valueOf(input).trim();
        if (r.isDate && text.matches("--\\d{2}-\\d{2}")) {
            Integer oldCp = Constants.ALL_WORD_CODEPOINTS.get("kulupu");
            Integer newCp = Constants.ALL_WORD_CODEPOINTS.get("kasi");
            r.tpWords = replaceWord(r.tpWords, "kulupu", "kasi");
            r.words = replaceWord(r.words, "kulupu", "kasi");
            r.abbreviatedWords = replaceWord(r.abbreviatedWords, "kulupu", "kasi");
            if (oldCp != null && newCp != null) {
                r.ucsurCodepoints = replaceCp(r.ucsurCodepoints, oldCp, newCp);
                r.innerCodepoints = replaceCp(r.innerCodepoints, oldCp, newCp);
                r.codepoints = replaceCp(r.codepoints, oldCp, newCp);
                r.abbreviatedUcsurCodepoints = replaceCp(r.abbreviatedUcsurCodepoints, oldCp, newCp);
            }
        }
        return r;
    }

    static ParseResult publicResult(ParseResult source, Object input) {
        ParseResult r = normalizeForRendering(source, input);
        if (r == null) return null;
        if (!r.isHex && !r.isBinary) {
            // Frozen Core-v1 decimal results predate the explicit kind/base fields.
            // The v1.1 public facade exposes the canonical decimal metadata without
            // changing the hash-pinned Core implementation.
            if (r.kind == null) r.kind = "decimal";
            if (r.numberBase == null) r.numberBase = 10;
            r.abbreviatedWords = null;
            r.abbreviatedUcsurCodepoints = null;
            r.nasinNanpaPonaWords = null;
        }
        return r;
    }

    static RenderResult normalizeRenderResult(RenderResult source, Object input) {
        if (source == null) return null;
        ParseResult p = normalizeForRendering(source.parsed, input);
        String text = input == null ? "" : String.valueOf(input).trim();
        boolean yearless = p != null && p.isDate && text.matches("--\\d{2}-\\d{2}");
        if (!yearless) return source;
        Integer oldCp = Constants.ALL_WORD_CODEPOINTS.get("kulupu");
        Integer newCp = Constants.ALL_WORD_CODEPOINTS.get("kasi");
        List<String> fw = replaceWord(source.fullWords, "kulupu", "kasi");
        List<String> aw = replaceWord(source.abbreviatedWords, "kulupu", "kasi");
        List<String> vw = replaceWord(source.activeWords, "kulupu", "kasi");
        List<Integer> fi=source.fullInnerCodepoints, fc=source.fullCodepoints,
                ai=source.abbreviatedInnerCodepoints, ac=source.abbreviatedCodepoints,
                vi=source.activeInnerCodepoints, vc=source.activeCodepoints;
        if (oldCp != null && newCp != null) {
            fi=replaceCp(fi,oldCp,newCp); fc=replaceCp(fc,oldCp,newCp);
            ai=replaceCp(ai,oldCp,newCp); ac=replaceCp(ac,oldCp,newCp);
            vi=replaceCp(vi,oldCp,newCp); vc=replaceCp(vc,oldCp,newCp);
        }
        StringBuilder u=new StringBuilder(); if(vc!=null)for(int cp:vc)u.appendCodePoint(cp);
        return new RenderResult(p,fw,fi,fc,aw,ai,ac,source.abbreviated,vw,vi,vc,u.toString());
    }

    private static List<String> replaceWord(List<String> values,String from,String to){
        if(values==null)return null;ArrayList<String> out=new ArrayList<>(values.size());
        for(String v:values)out.add(Objects.equals(v,from)?to:v);return List.copyOf(out);
    }
    private static List<Integer> replaceCp(List<Integer> values,int from,int to){
        if(values==null)return null;ArrayList<Integer> out=new ArrayList<>(values.size());
        for(Integer v:values)out.add(v!=null&&v==from?to:v);return List.copyOf(out);
    }

    private static ParseResult copy(ParseResult s){
        ParseResult r=new ParseResult();
        r.input=s.input;r.caps=s.caps;r.properName=s.properName;r.uniqueCode=s.uniqueCode;r.hexCodepoints=s.hexCodepoints;r.hexWithCartouche=s.hexWithCartouche;r.displayValue=s.displayValue;r.numericMode=s.numericMode;
        r.ucsurCodepoints=copyList(s.ucsurCodepoints);r.innerCodepoints=copyList(s.innerCodepoints);r.codepoints=copyList(s.codepoints);r.abbreviatedUcsurCodepoints=copyList(s.abbreviatedUcsurCodepoints);
        r.tpWords=copyList(s.tpWords);r.words=copyList(s.words);r.abbreviatedWords=copyList(s.abbreviatedWords);r.nasinNanpaPonaWords=copyList(s.nasinNanpaPonaWords);
        r.isTime=s.isTime;r.isDate=s.isDate;r.isTimeLike=s.isTimeLike;r.isHex=s.isHex;r.isBinary=s.isBinary;r.semanticKind=s.semanticKind;r.semanticStartGlyph=s.semanticStartGlyph;
        r.kind=s.kind;r.hexDigits=s.hexDigits;r.binaryDigits=s.binaryDigits;r.numberBase=s.numberBase;r.hexParts=copyList(s.hexParts);r.binaryParts=copyList(s.binaryParts);
        return r;
    }
    private static <T> List<T> copyList(List<T> v){return v==null?null:List.copyOf(v);}
}
