package com.nanpalinjan;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Normative Parser-Renderer-Profile-v1.1 qualification. */
public final class V11ProfileRegression {
    private static void check(boolean ok,String m){if(!ok)throw new IllegalStateException(m);}
    @SuppressWarnings("unchecked") private static Map<String,Object> map(Object v){return v instanceof Map<?,?>m?(Map<String,Object>)m:Map.of();}
    private static List<?> list(Object v){return v instanceof List<?>l?l:List.of();}
    private static String val(Object v){return v==null?null:String.valueOf(v);}
    private static Integer integer(Object v){return v==null?null:((Number)v).intValue();}
    private static String semantic(ParseOptions.SemanticKind v){return v==null?null:v.name();}
    private static String start(ParseOptions.DecimalStartGlyph v){return v==null?null:v.name();}
    private static void eq(Object got,Object want,String id,String field){if(!Objects.equals(got,want))throw new IllegalStateException(id+" "+field+" got="+got+" want="+want);}

    public static void main(String[]args)throws Exception{
        if(args.length<2)throw new IllegalArgumentException("usage: V11ProfileRegression <fonts.zip> <parser-renderer-profile-v1.1.0.json>");
        Path fonts=Path.of(args[0]),profile=Path.of(args[1]);Map<String,Object> root=map(MiniJson.parse(Files.readString(profile)));List<?> cases=list(root.get("nanpaParserSmokeCases"));check(cases.size()==16,"expected 16 NanpaParser smoke cases");
        ParseOptions d=ParseOptions.publicDefaults();check(!d.enableHexParsing()&&!d.enableBinaryParsing()&&!d.enableBinaryRendering(),"v1.1 hex/binary defaults off");check(d.abbreviateNumericCartouches(),"v1.1 abbreviation default on");check(!d.preserveNumericCartoucheBreaksInAbbreviation(),"v1.1 preserve-break default off");check(d.effectiveNumericMode()==ParseOptions.NumericMode.uniform,"uniform numeric default");check(d.relaxedNanpaLinjanParsing()&&d.relaxedNanpaLinjanRendering(),"relaxed defaults");check(d.nanpaColonParsing()&&d.nanpaColonRendering(),"nanpa colon defaults");check(!d.breakLinesAtFullStops()&&!d.interpretDoubleQuotesAsTeTo()&&!d.nasinNanpaPona(),"v1.1 remaining public defaults");
        int passed=0;
        try(NanpaLinjaN n=NanpaLinjaN.create(fonts)){
            for(Object o:cases){Map<String,Object> c=map(o);String id=val(c.get("id")),input=val(c.get("input"));ParseOptions po=ParseOptions.fromPublicMap(map(c.get("options")));ParseResult got=n.parseNumber(input,po);Object eraw=c.get("result");if(eraw==null){check(got==null,id+" expected null result");passed++;continue;}Map<String,Object> e=map(eraw);check(got!=null,id+" unexpectedly rejected");
                eq(got.caps,val(e.get("caps")),id,"caps");eq(got.kind,val(e.get("kind")),id,"kind");eq(got.numberBase,integer(e.get("numberBase")),id,"numberBase");eq(got.properName,val(e.get("properName")),id,"properName");eq(got.uniqueCode,val(e.get("uniqueCode")),id,"uniqueCode");eq(got.displayValue,val(e.get("displayValue")),id,"displayValue");eq(semantic(got.semanticKind),val(e.get("semanticKind")),id,"semanticKind");eq(start(got.semanticStartGlyph),val(e.get("semanticStartGlyph")),id,"semanticStartGlyph");eq(got.isDate,e.get("isDate"),id,"isDate");eq(got.isTime,e.get("isTime"),id,"isTime");eq(got.numericMode,val(e.get("numericMode")),id,"numericMode");eq(got.tpWords,e.get("tpWords"),id,"tpWords");eq(got.abbreviatedWords,e.get("abbreviatedWords"),id,"abbreviatedWords");passed++;
            }
            check(n.listFonts().size()==8,"eight production fonts");int manual=0,ucsur=0;for(FontPairInfo f:n.listFonts()){check(Boolean.TRUE.equals(f.settings().get("cartoucheVulgarFractions")),f.key()+" vulgar scaling enabled");check(Boolean.FALSE.equals(f.settings().get("emulateLegacyCartoucheScaling")),f.key()+" legacy scaling disabled");String mode=String.valueOf(f.settings().get("cartoucheTallyMode"));if("manual".equals(mode))manual++;if("ucsur".equals(mode))ucsur++;}check(manual==4&&ucsur==4,"current 4 manual + 4 UCSUR tally split");
            RenderPlan plan=n.buildRenderPlan("123",new RenderOptions());check(plan.openTypeFeatures().equals(List.of("calt","liga","ccmp")),"no legacy ss12/ss13/ss14 selection");
            SvgRenderResult svg=n.renderToSvg("123",new RenderOptions());check(svg.svg().contains("<path")&&!svg.svg().contains("<image")&&!svg.svg().contains("data:image"),"numeric SVG is vector");
            PdfRenderResult pdf=n.renderToPdf("123",new RenderOptions());String ps=new String(pdf.bytes(),StandardCharsets.ISO_8859_1);check(ps.startsWith("%PDF-1."),"PDF header");check(!ps.contains("/Subtype /Image"),"numeric PDF contains no raster Image XObject");
            RenderPlan scale=n.buildRenderPlan("[jan1/2 pona]",new RenderOptions().withFont("linjaPona"));RenderRun sr=scale.runs().getFirst();check(sr.renderText().codePoints().anyMatch(cp->cp==FontRenderAdapters.VULGAR_SCALE_HALF),"ordinary ASCII 1/2 scale alias");check(sr.renderCodepoints().stream().noneMatch(FontRenderAdapters::isVulgarScaleMarker),"scale marker render-only");
        }
        System.out.println("Java Protocol v1.1 parser smoke: "+passed+"/16 PASS");
        System.out.println("Java Protocol v1.1 defaults/fonts/inline scaling/vector output: PASS");
    }
}
