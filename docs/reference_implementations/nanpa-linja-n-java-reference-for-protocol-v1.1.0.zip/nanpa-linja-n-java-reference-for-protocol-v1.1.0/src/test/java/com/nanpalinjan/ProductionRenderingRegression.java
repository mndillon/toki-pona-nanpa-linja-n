package com.nanpalinjan;

import java.awt.image.BufferedImage;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Protocol-v1.1 production-font/render-plan qualification. */
public final class ProductionRenderingRegression {
    private static void check(boolean ok,String m){if(!ok)throw new IllegalStateException(m);}
    @SuppressWarnings("unchecked") private static Map<String,Object> map(Object x){return x instanceof Map<?,?> m?(Map<String,Object>)m:Map.of();}
    private static List<?> list(Object x){return x instanceof List<?> l?l:List.of();}
    private static List<Integer> ints(Object x){List<Integer>o=new ArrayList<>();for(Object v:list(x))o.add(((Number)v).intValue());return List.copyOf(o);}
    private static int ink(BufferedImage im){int n=0;for(int y=0;y<im.getHeight();y++)for(int x=0;x<im.getWidth();x++)if(((im.getRGB(x,y)>>>24)&255)!=0)n++;return n;}
    private static ParseOptions parserFor(Map<String,Object> c){
        ParseOptions p=ParseOptions.publicDefaults()
                .withAbbreviateNumericCartouches(Boolean.TRUE.equals(c.get("abbreviate")))
                .withPreserveNumericCartoucheBreaksInAbbreviation(!Boolean.FALSE.equals(c.get("preserveNumericCartoucheBreaks")));
        String id=String.valueOf(c.get("id"));
        if(id.startsWith("hex-"))p=p.withEnableHexParsing(true);
        if(id.startsWith("binary-"))p=p.withEnableBinaryParsing(true).withEnableBinaryRendering(true);
        return p;
    }
    private static List<Integer> fullCanonical(RenderRun r){List<Integer>o=new ArrayList<>();o.add(Constants.CARTOUCHE_START);o.addAll(r.canonicalCodepoints());o.add(Constants.CARTOUCHE_END);return List.copyOf(o);}

    public static void main(String[] args)throws Exception{
        if(args.length<2)throw new IllegalArgumentException("usage: ProductionRenderingRegression <fonts.zip> <render-plan-v1.1.json>");
        Path fontSource=Path.of(args[0]), fixture=Path.of(args[1]);
        ProductionFontBundle bundle=ProductionFontBundle.load(fontSource);
        Map<String,Object> root=map(MiniJson.parse(Files.readString(fixture)));
        List<?> cases=list(root.get("cases"));check(cases.size()==16,"v1.1 render-plan case count must be 16");
        int assetPass=0,plans=0,svgPass=0,pngPass=0,pdfPass=0;
        try(NanpaLinjaN n=NanpaLinjaN.create(fontSource)){
            check(n.listFonts().size()==8,"font pair count");
            for(FontPairInfo f:n.listFonts()){
                check(bundle.fontBytes(f.companionFilename()).length>1000,"missing font asset "+f.key());assetPass++;
                for(Object c0:cases){Map<String,Object> c=map(c0);String id=String.valueOf(c.get("id")),input=String.valueOf(c.get("input"));float px=((Number)c.get("fontPx")).floatValue();
                    RenderOptions o=new RenderOptions().withFont(f.key()).withFontSize(px).withParser(parserFor(c));
                    RenderPlan plan=n.buildRenderPlan(input,o);check(plan.cartoucheCount()==1,f.key()+"/"+id+" cartouche");check(plan.openTypeFeatures().equals(List.of("calt","liga","ccmp")),f.key()+"/"+id+" v1.1 feature set");
                    RenderRun r=plan.runs().getFirst();check(r.numericCartouche(),f.key()+"/"+id+" numeric run");
                    Map<String,Object> pf=map(map(c.get("perFont")).get(f.key()));check(!pf.isEmpty(),f.key()+"/"+id+" expected per-font entry");
                    check(Objects.equals(r.renderText(),String.valueOf(pf.get("renderText"))),f.key()+"/"+id+" renderText");
                    check(r.renderCodepoints().equals(ints(pf.get("renderCodepoints"))),f.key()+"/"+id+" renderCodepoints");
                    check(Objects.equals(r.renderAdapterId(),String.valueOf(pf.get("renderAdapterId"))),f.key()+"/"+id+" adapter");
                    check(fullCanonical(r).equals(ints(c.get("canonicalCodepoints"))),f.key()+"/"+id+" canonical codepoints");
                    SvgRenderResult svg=n.renderToSvg(input,o);check(svg.svg().contains("<path")&&!svg.svg().contains("data:image"),f.key()+"/"+id+" vector SVG");plans++;svgPass++;
                }
                RenderOptions base=new RenderOptions().withFont(f.key());CanvasRenderResult canvas=n.renderToCanvas("123.45",base);check(ink(canvas.canvas())>20,f.key()+" nonblank canvas");
                PngRenderResult png=n.renderToPng("123.45",base);check(png.bytes().length>100&&png.bytes()[0]==(byte)137&&png.bytes()[1]==80,f.key()+" png");pngPass++;
                PdfRenderResult pdf=n.renderToPdf("123.45",base);String ps=new String(pdf.bytes(),StandardCharsets.ISO_8859_1);check(ps.startsWith("%PDF-1."),f.key()+" PDF header");check(!ps.contains("/Subtype /Image"),f.key()+" PDF must be vector");pdfPass++;
            }
        }
        check(plans==128&&svgPass==128,"128 production matrix");
        System.out.println("Java production font assets: "+assetPass+"/8 loadable PASS");
        System.out.println("Java v1.1 render-plan matrix: "+plans+"/128 PASS");
        System.out.println("Java v1.1 SVG vector matrix: "+svgPass+"/128 PASS");
        System.out.println("Java production PNG font-pair smoke: "+pngPass+"/8 PASS");
        System.out.println("Java production PDF vector font-pair smoke: "+pdfPass+"/8 PASS");
    }
}
