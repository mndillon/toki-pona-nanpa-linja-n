package com.nanpalinjan;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public final class FacadeParityCheck {
    private static void check(boolean ok,String m){if(!ok)throw new IllegalStateException(m);}
    private static boolean png(byte[] b){byte[] s={(byte)137,80,78,71,13,10,26,10};if(b.length<s.length)return false;for(int i=0;i<s.length;i++)if(b[i]!=s[i])return false;return true;}
    public static void main(String[] args)throws Exception{
        Path fontDir=args.length>0?Path.of(args[0]):null;
        try(NanpaLinjaN n=fontDir==null?NanpaLinjaN.create():NanpaLinjaN.create(fontDir)){
            check(n.listFonts().size()==8,"expected eight production font pairs");
            check(n.fonts().size()==8,"fonts alias");
            check(n.getFontInfo("nasin nanpa predefined").key().equals("nasinNanpa"),"font label alias");
            check(n.normalizeFontKey("FairfaxHD predefined").equals("fairfaxHd"),"font family alias");
            FacadeParseResult p=n.parse("12:30");
            check(p.numericInput()&&p.numeric()!=null&&p.numeric().isTime,"parse numeric facade");
            check(!n.parse("toki pona").numericInput(),"parse ordinary text facade");
            if(fontDir!=null){
                RenderPlan plan=n.buildRenderPlan("123.45");
                check(plan.cartoucheCount()==1&&plan.runs().getFirst().numericCartouche(),"buildRenderPlan numeric cartouche");
                RenderPlan ordinaryPlan=n.buildRenderPlan("[jan pona,,]",new RenderOptions().withFont("linjaSike"));
                check(ordinaryPlan.cartoucheCount()==1&&!ordinaryPlan.runs().getFirst().numericCartouche()&&"cartouche".equals(ordinaryPlan.runs().getFirst().fontRole()),"buildRenderPlan ordinary cartouche");
                CanvasRenderResult haloCartouche=n.renderToCanvas("[jan pona,,]",new RenderOptions().withFont("linjaSike").withHalo(true).withHaloColor("#D91E18"));
                check(haloCartouche.width()>0&&haloCartouche.height()>0,"ordinary cartouche halo facade");
                CanvasRenderResult canvas=n.renderToCanvas("123.45");
                check(canvas.width()>0&&canvas.height()>0,"canvas dimensions");
                check(n.renderToImage("123.45",new RenderOptions()).width()==canvas.width(),"renderToImage alias");
                PngRenderResult png=n.renderToPng("123.45");
                check(png(png.bytes()),"PNG signature");
                check(!new RenderOptions().parser().enableHexParsing()&&!new RenderOptions().parser().enableBinaryParsing(),"v1.1 hex/binary defaults off");
                SvgRenderResult svg=n.renderToSvg("#ABCDEF",new RenderOptions().withParser(ParseOptions.publicDefaults().withEnableHexParsing(true)));
                check(svg.svg().contains("<svg")&&svg.svg().contains("<path"),"SVG payload");
                PdfRenderResult pdf=n.renderToPdf("0b10101",new RenderOptions().withParser(ParseOptions.publicDefaults().withEnableBinaryParsing(true).withEnableBinaryRendering(true)));
                check(new String(pdf.bytes(),0,8,StandardCharsets.ISO_8859_1).startsWith("%PDF-1."),"PDF header");
                check(n.render("123",new RenderOptions().withFormat("png")) instanceof PngRenderResult,"format dispatcher png");
                check(n.render("123",new RenderOptions().withFormat("svg")) instanceof SvgRenderResult,"format dispatcher svg");
                check(n.render("123",new RenderOptions().withFormat("pdf")) instanceof PdfRenderResult,"format dispatcher pdf");
                check(n.render("123",new RenderOptions().withFormat("canvas")) instanceof CanvasRenderResult,"format dispatcher canvas");
            }
        }
        System.out.println("JavaScript-facade parity API checks: PASS");
    }
}
