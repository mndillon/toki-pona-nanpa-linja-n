package com.nanpalinjan;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.nio.file.Path;
import java.util.*;

/** Current v1.1 ordinary-cartouche/tally/inline-scale regression. */
public final class OrdinaryCartoucheRegression {
    private static void check(boolean ok,String m){if(!ok)throw new IllegalStateException(m);}
    private static boolean containsCp(String s,int cp){return s.codePoints().anyMatch(x->x==cp);}
    private static int countNear(BufferedImage img, Color c){int n=0;for(int y=0;y<img.getHeight();y++)for(int x=0;x<img.getWidth();x++){int argb=img.getRGB(x,y);int a=(argb>>>24)&255;if(a<32)continue;int r=(argb>>>16)&255,g=(argb>>>8)&255,b=argb&255;if(Math.abs(r-c.getRed())+Math.abs(g-c.getGreen())+Math.abs(b-c.getBlue())<90)n++;}return n;}

    public static void main(String[]args)throws Exception{
        if(args.length<1)throw new IllegalArgumentException("usage: OrdinaryCartoucheRegression <fonts.zip>");
        Path fontDir=Path.of(args[0]);int fonts=0,manual=0,ucsur=0,halo=0,scale=0;
        try(NanpaLinjaN n=NanpaLinjaN.create(fontDir)){
            for(FontPairInfo f:n.listFonts()){
                fonts++;String mode=String.valueOf(f.settings().getOrDefault("cartoucheTallyMode","ucsur")).toLowerCase(Locale.ROOT);
                RenderOptions base=new RenderOptions().withFont(f.key()).withFontSize(56f).withPaddingPx(18);
                RenderPlan ordinary=n.buildRenderPlan("[jan pona]",base);check(ordinary.cartoucheCount()==1,f.key()+" ordinary cartoucheCount");RenderRun r0=ordinary.runs().getFirst();check("cartouche".equals(r0.fontRole())&&!r0.numericCartouche(),f.key()+" ordinary role");
                RenderPlan tally=n.buildRenderPlan("[jan pona,,]",base);String text=tally.runs().getFirst().renderText();
                if("manual".equals(mode)){check(!containsCp(text,0xF199E),f.key()+" manual mode leaked tally glyph");check(tally.height()>ordinary.height(),f.key()+" manual tally extends geometry");manual++;}
                else if("ucsur".equals(mode)){check(containsCp(text,0xF199E),f.key()+" UCSUR tally retained");ucsur++;}
                else throw new IllegalStateException(f.key()+" unexpected tally mode "+mode);

                RenderPlan scaled=n.buildRenderPlan("[jan1/2 pona]",base);RenderRun sr=scaled.runs().getFirst();check(containsCp(sr.renderText(),FontRenderAdapters.VULGAR_SCALE_HALF),f.key()+" ASCII 1/2 scale alias emits inline half marker");check(sr.renderCodepoints().stream().noneMatch(FontRenderAdapters::isVulgarScaleMarker),f.key()+" scale marker excluded from renderCodepoints");scale++;

                CanvasRenderResult haloResult=n.renderToCanvas("[jan pona,,]",base.withHalo(true).withHaloColor("#D91E18"));check(countNear(haloResult.canvas(),new Color(0xD91E18))>10,f.key()+" red halo pixels");check(countNear(haloResult.canvas(),Color.BLACK)>10,f.key()+" black foreground pixels");halo++;
            }
        }
        check(fonts==8,"font count");check(manual==4,"manual tally font count");check(ucsur==4,"UCSUR tally font count");
        System.out.println("Java ordinary cartouche routing: "+fonts+"/8 PASS");
        System.out.println("Java manual tally routing: "+manual+"/4 PASS");
        System.out.println("Java UCSUR tally routing: "+ucsur+"/4 PASS");
        System.out.println("Java ordinary inline scale controls: "+scale+"/8 PASS");
        System.out.println("Java ordinary cartouche halo rendering: "+halo+"/8 PASS");
    }
}
