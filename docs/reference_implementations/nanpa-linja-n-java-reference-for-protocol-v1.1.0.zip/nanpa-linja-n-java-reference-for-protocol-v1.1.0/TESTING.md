# Java v1.1.0 testing

Requirement: Java 21.

Run the complete non-fail-fast release suite from the package root:

```bash
./tools/run_java_regression.sh
```

The consolidated report is written to `test-output/java-regression-report.txt`.

The v1.1 release runner covers compilation, the frozen Core/API corpus, astToText integration, current public defaults, canonical syntax/adapters, the 254-case canonical full renderer, structural renderer parity, the 128-case production render-plan and SVG matrix, production PNG/PDF vector smoke, ordinary cartouche tally/inline scaling, and the 16-case Parser-Renderer-Profile-v1.1 suite.

The runner uses one temporary compiled class directory for the whole invocation, so Java sources are compiled once and reused by all configured suites.
