package nanpa

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"
)

type canonicalFullCorpus struct {
	Version   string `json:"version"`
	CaseCount int    `json:"caseCount"`
	Authority struct {
		Path   string `json:"path"`
		SHA256 string `json:"sha256"`
	} `json:"authority"`
	Cases []canonicalFullCase `json:"cases"`
}

type canonicalFullCase struct {
	ID         string                 `json:"id"`
	Input      string                 `json:"input"`
	Parser     map[string]interface{} `json:"parser"`
	Font       string                 `json:"font"`
	CompareAST bool                   `json:"compareAst"`
	RandomCps  bool                   `json:"randomCps"`
	Oracle     struct {
		OK    bool                   `json:"ok"`
		Error interface{}            `json:"error"`
		AST   canonicalExpectedAST   `json:"ast"`
		Runs  []canonicalExpectedRun `json:"runs"`
	} `json:"oracle"`
}

type canonicalExpectedImage struct {
	Src         string  `json:"src"`
	W           string  `json:"w"`
	H           string  `json:"h"`
	Alt         string  `json:"alt"`
	VAlign      string  `json:"valign"`
	Wriggle     float64 `json:"wriggle"`
	Transparent bool    `json:"transparent"`
}

type canonicalExpectedSegment struct {
	Kind       string                  `json:"kind"`
	Value      *string                 `json:"value"`
	OpenQuote  *string                 `json:"openQuote"`
	CloseQuote *string                 `json:"closeQuote"`
	Image      *canonicalExpectedImage `json:"image"`
}

type canonicalExpectedLine struct {
	Index                     int                        `json:"index"`
	SourceLineIndex           int                        `json:"sourceLineIndex"`
	SentenceIndexInSourceLine int                        `json:"sentenceIndexInSourceLine"`
	SourceText                string                     `json:"sourceText"`
	Children                  []canonicalExpectedSegment `json:"children"`
}

type canonicalExpectedAST struct {
	Type            string                  `json:"type"`
	NormalizedInput string                  `json:"normalizedInput"`
	Lines           []canonicalExpectedLine `json:"lines"`
}

type canonicalExpectedRun struct {
	Kind                     string  `json:"kind"`
	RenderMode               string  `json:"renderMode"`
	FontRole                 string  `json:"fontRole"`
	SourceText               string  `json:"sourceText"`
	SourceKind               string  `json:"sourceKind"`
	CanonicalCps             []int   `json:"canonicalCps"`
	CanonicalFullCps         []int   `json:"canonicalFullCps"`
	RenderCps                []int   `json:"renderCps"`
	RenderAdapterID          string  `json:"renderAdapterId"`
	RequestedRenderAdapterID string  `json:"requestedRenderAdapterId"`
	IsQuoted                 bool    `json:"isQuoted"`
	InterpretedQuote         bool    `json:"interpretedQuote"`
	IsUnrecognized           bool    `json:"isUnrecognized"`
	ManualTallies            []int   `json:"manualTallies"`
	IsNumericCartouche       bool    `json:"isNumericCartouche"`
	IsLiteralCartouche       bool    `json:"isLiteralCartouche"`
	ImageAlt                 *string `json:"imageAlt"`
	EncodedText              *string `json:"encodedText"`
}

func boolJSON(m map[string]interface{}, key string, fallback bool) bool {
	v, ok := m[key]
	if !ok || v == nil {
		return fallback
	}
	b, ok := v.(bool)
	if !ok {
		return fallback
	}
	return b
}
func stringJSON(m map[string]interface{}, key, fallback string) string {
	v, ok := m[key]
	if !ok || v == nil {
		return fallback
	}
	s, ok := v.(string)
	if !ok {
		return fallback
	}
	return s
}

func optionsFromCanonicalCase(c canonicalFullCase) FullRenderOptions {
	o := DefaultFullRenderOptions()
	o.Font = c.Font
	p := c.Parser
	o.Parser.Mode = stringJSON(p, "mode", o.Parser.Mode)
	o.Parser.RendererMode = o.Parser.Mode
	o.Parser.NumericMode = stringJSON(p, "numericMode", o.Parser.NumericMode)
	o.Parser.MixedStyle = stringJSON(p, "mixedStyle", o.Parser.MixedStyle)
	o.Parser.ShowUnknownText = boolJSON(p, "showUnknownText", o.Parser.ShowUnknownText)
	o.Parser.AbbreviateNumericCartouches = boolJSON(p, "abbreviateNumericCartouches", o.Parser.AbbreviateNumericCartouches)
	o.Parser.PreserveNumericCartoucheBreaks = boolJSON(p, "preserveNumericCartoucheBreaksInAbbreviation", o.Parser.PreserveNumericCartoucheBreaks)
	o.Parser.AutoCartoucheStandaloneProperNames = boolJSON(p, "autoCartoucheStandaloneProperNames", o.Parser.AutoCartoucheStandaloneProperNames)
	o.Parser.RelaxedNanpaLinjanParsing = boolJSON(p, "relaxedNanpaLinjanParsing", o.Parser.RelaxedNanpaLinjanParsing)
	o.Parser.RelaxedNanpaLinjanRendering = boolJSON(p, "relaxedNanpaLinjanRendering", o.Parser.RelaxedNanpaLinjanRendering)
	o.Parser.NanpaColonParsing = boolJSON(p, "nanpaColonParsing", o.Parser.NanpaColonParsing)
	o.Parser.NanpaColonRendering = boolJSON(p, "nanpaColonRendering", o.Parser.NanpaColonRendering)
	if v, ok := p["numericCartoucheStartGlyph"]; ok {
		if v == nil {
			o.Parser.NumericCartoucheStartGlyph = ""
		} else if s, ok := v.(string); ok {
			o.Parser.NumericCartoucheStartGlyph = s
		}
	}
	o.Parser.EnableHexParsing = boolJSON(p, "enableHexParsing", o.Parser.EnableHexParsing)
	o.Parser.EnableBinaryParsing = boolJSON(p, "enableBinaryParsing", o.Parser.EnableBinaryParsing)
	o.Parser.EnableBinaryRendering = boolJSON(p, "enableBinaryRendering", o.Parser.EnableBinaryRendering)
	o.Parser.NasinNanpaPona = boolJSON(p, "nasinNanpaPona", o.Parser.NasinNanpaPona)
	o.Parser.CartoucheCommaTallyMarks = boolJSON(p, "cartoucheCommaTallyMarks", o.Parser.CartoucheCommaTallyMarks)
	o.Parser.CartoucheTallyMode = stringJSON(p, "cartoucheTallyMode", o.Parser.CartoucheTallyMode)
	o.Parser.InterpretDoubleQuotesAsTeTo = boolJSON(p, "interpretDoubleQuotesAsTeTo", o.Parser.InterpretDoubleQuotesAsTeTo)
	o.Parser.BreakLinesAtFullStops = boolJSON(p, "breakLinesAtFullStops", o.Parser.BreakLinesAtFullStops)
	return o
}

func loadCanonicalFullCorpus(t *testing.T) canonicalFullCorpus {
	t.Helper()
	path := filepath.Join("..", "conformance", "full-renderer-canonical-v1.1.0", "cases.json")
	raw, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("read canonical full renderer corpus: %v", err)
	}
	var c canonicalFullCorpus
	if err := json.Unmarshal(raw, &c); err != nil {
		t.Fatalf("decode canonical full renderer corpus: %v", err)
	}
	if c.CaseCount != len(c.Cases) {
		t.Fatalf("canonical full renderer corpus count says %d, has %d", c.CaseCount, len(c.Cases))
	}
	authorityPath := filepath.Join("..", filepath.FromSlash(c.Authority.Path))
	js, err := os.ReadFile(authorityPath)
	if err != nil {
		t.Fatalf("read canonical JS authority: %v", err)
	}
	sum := sha256.Sum256(js)
	got := hex.EncodeToString(sum[:])
	if got != c.Authority.SHA256 {
		t.Fatalf("canonical JS authority hash mismatch: got %s want %s", got, c.Authority.SHA256)
	}
	return c
}

func compareCanonicalAST(t *testing.T, got DocumentAST, want canonicalExpectedAST) {
	t.Helper()
	if got.Type != want.Type {
		t.Errorf("AST type: got %q want %q", got.Type, want.Type)
	}
	if got.NormalizedInput != want.NormalizedInput {
		t.Errorf("AST normalizedInput: got %q want %q", got.NormalizedInput, want.NormalizedInput)
	}
	if len(got.Lines) != len(want.Lines) {
		t.Errorf("AST line count: got %d want %d", len(got.Lines), len(want.Lines))
		return
	}
	for i := range want.Lines {
		g, w := got.Lines[i], want.Lines[i]
		if g.Index != w.Index || g.SourceLineIndex != w.SourceLineIndex || g.SentenceIndexInSourceLine != w.SentenceIndexInSourceLine || g.SourceText != w.SourceText {
			t.Errorf("AST line[%d]: got index/source/sentence/text=%d/%d/%d/%q want %d/%d/%d/%q", i, g.Index, g.SourceLineIndex, g.SentenceIndexInSourceLine, g.SourceText, w.Index, w.SourceLineIndex, w.SentenceIndexInSourceLine, w.SourceText)
		}
		if len(g.Children) != len(w.Children) {
			t.Errorf("AST line[%d] child count: got %d want %d", i, len(g.Children), len(w.Children))
			continue
		}
		for j := range w.Children {
			gs, ws := g.Children[j], w.Children[j]
			if gs.Kind != ws.Kind {
				t.Errorf("AST line[%d] child[%d] kind: got %q want %q", i, j, gs.Kind, ws.Kind)
			}
			if ws.Value != nil && gs.Value != *ws.Value {
				t.Errorf("AST line[%d] child[%d] value: got %q want %q", i, j, gs.Value, *ws.Value)
			}
			if ws.OpenQuote != nil && gs.OpenQuote != *ws.OpenQuote {
				t.Errorf("AST line[%d] child[%d] openQuote: got %q want %q", i, j, gs.OpenQuote, *ws.OpenQuote)
			}
			if ws.CloseQuote != nil && gs.CloseQuote != *ws.CloseQuote {
				t.Errorf("AST line[%d] child[%d] closeQuote: got %q want %q", i, j, gs.CloseQuote, *ws.CloseQuote)
			}
			if ws.Image != nil {
				if gs.Image == nil {
					t.Errorf("AST line[%d] child[%d] missing image descriptor", i, j)
					continue
				}
				gi := gs.Image
				wi := ws.Image
				if gi.Src != wi.Src || gi.W != wi.W || gi.H != wi.H || gi.Alt != wi.Alt || gi.VAlign != wi.VAlign || gi.Wriggle != wi.Wriggle || gi.Transparent != wi.Transparent {
					t.Errorf("AST line[%d] child[%d] image: got %+v want %+v", i, j, *gi, *wi)
				}
			}
		}
	}
}

func goRunCanonicalFull(r FullRenderRun) []int {
	if r.FontRole == "cartouche" || r.FontRole == "number" || r.NumericCartouche {
		out := []int{CartoucheStart}
		out = append(out, r.CanonicalCodepoints...)
		out = append(out, CartoucheEnd)
		return out
	}
	return nil
}

func expectedAdapterForFont(font string) string {
	switch font {
	case "linjaPona":
		return "linja-pona-legacy-v1"
	case "linjaSike":
		return "linja-sike-legacy-v1"
	case "nasinSitelenPuMono":
		return "nasin-sitelen-pu-mono-v1"
	case "linjaLipamanka":
		return "linja-lipamanka-v1"
	default:
		return "identity"
	}
}

func equalIntSlice(a, b []int) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}

func compareCanonicalRun(t *testing.T, idx int, g FullRenderRun, w canonicalExpectedRun, font string, randomCps bool) {
	t.Helper()
	prefix := fmt.Sprintf("run[%d]", idx)
	if g.Kind != w.Kind {
		t.Errorf("%s kind: got %q want %q", prefix, g.Kind, w.Kind)
	}
	if g.RenderMode != w.RenderMode {
		t.Errorf("%s renderMode: got %q want %q", prefix, g.RenderMode, w.RenderMode)
	}
	if g.FontRole != w.FontRole {
		t.Errorf("%s fontRole: got %q want %q", prefix, g.FontRole, w.FontRole)
	}
	if g.SourceText != w.SourceText {
		t.Errorf("%s sourceText: got %q want %q", prefix, g.SourceText, w.SourceText)
	}
	if g.SourceKind != w.SourceKind {
		t.Errorf("%s sourceKind: got %q want %q", prefix, g.SourceKind, w.SourceKind)
	}
	if !randomCps && !equalIntSlice(g.CanonicalCodepoints, w.CanonicalCps) {
		t.Errorf("%s canonicalCps: got %v want %v", prefix, g.CanonicalCodepoints, w.CanonicalCps)
	}
	gf := goRunCanonicalFull(g)
	if !randomCps && len(w.CanonicalFullCps) > 0 && !equalIntSlice(gf, w.CanonicalFullCps) {
		t.Errorf("%s canonicalFullCps: got %v want %v", prefix, gf, w.CanonicalFullCps)
	}
	if !randomCps && !equalIntSlice(g.RenderCodepoints, w.RenderCps) {
		t.Errorf("%s renderCps: got %v want %v", prefix, g.RenderCodepoints, w.RenderCps)
	}
	// Explicit raw escapes and literal runs bypass adapters. Otherwise the Go
	// production font's configured adapter must match the canonical request.
	wantRequested := w.RequestedRenderAdapterID
	if wantRequested == "" {
		wantRequested = expectedAdapterForFont(font)
	}
	_ = wantRequested // requested adapter is not yet exposed separately by Go; render adapter is checked below.
	if g.RenderAdapterID != w.RenderAdapterID {
		t.Errorf("%s renderAdapterId: got %q want %q", prefix, g.RenderAdapterID, w.RenderAdapterID)
	}
	if g.Quoted != w.IsQuoted {
		t.Errorf("%s isQuoted: got %v want %v", prefix, g.Quoted, w.IsQuoted)
	}
	if g.InterpretedQuote != w.InterpretedQuote {
		t.Errorf("%s interpretedQuote: got %v want %v", prefix, g.InterpretedQuote, w.InterpretedQuote)
	}
	if g.Unrecognized != w.IsUnrecognized {
		t.Errorf("%s isUnrecognized: got %v want %v", prefix, g.Unrecognized, w.IsUnrecognized)
	}
	if !equalIntSlice(g.ManualTallies, w.ManualTallies) {
		t.Errorf("%s manualTallies: got %v want %v", prefix, g.ManualTallies, w.ManualTallies)
	}
	gotNumeric := g.NumericCartouche
	if gotNumeric != w.IsNumericCartouche {
		t.Errorf("%s numericCartouche: got %v want %v", prefix, gotNumeric, w.IsNumericCartouche)
	}
	if w.ImageAlt != nil && g.ImageAlt != *w.ImageAlt {
		t.Errorf("%s imageAlt: got %q want %q", prefix, g.ImageAlt, *w.ImageAlt)
	}
}

func TestCanonicalFullRendererSemanticCorpus(t *testing.T) {
	corpus := loadCanonicalFullCorpus(t)
	renderer, err := CreateNanpaLinjaN()
	if err != nil {
		t.Fatalf("CreateNanpaLinjaN: %v", err)
	}
	defer renderer.Close()
	passed := 0
	for _, c := range corpus.Cases {
		c := c
		if t.Run(c.ID, func(t *testing.T) {
			if !c.Oracle.OK {
				t.Errorf("canonical oracle generation failed: %v", c.Oracle.Error)
				return
			}
			o := optionsFromCanonicalCase(c)
			plan, err := renderer.BuildFullRenderPlan(c.Input, o)
			if err != nil {
				t.Errorf("BuildFullRenderPlan: %v", err)
				return
			}
			if c.CompareAST {
				compareCanonicalAST(t, plan.AST, c.Oracle.AST)
			}
			if len(plan.Runs) != len(c.Oracle.Runs) {
				t.Errorf("run count: got %d want %d\n got=%+v\nwant=%+v", len(plan.Runs), len(c.Oracle.Runs), plan.Runs, c.Oracle.Runs)
				return
			}
			for i := range c.Oracle.Runs {
				compareCanonicalRun(t, i, plan.Runs[i], c.Oracle.Runs[i], c.Font, c.RandomCps)
			}
		}) {
			passed++
		}
	}
	t.Logf("Go canonical full-renderer semantic corpus: %d/%d PASS", passed, len(corpus.Cases))
}
