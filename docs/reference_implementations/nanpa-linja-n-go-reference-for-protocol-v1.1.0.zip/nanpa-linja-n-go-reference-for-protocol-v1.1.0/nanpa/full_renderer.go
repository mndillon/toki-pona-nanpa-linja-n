package nanpa

import (
	"bytes"
	"encoding/hex"
	"fmt"
	"image"
	"image/draw"
	_ "image/gif"
	_ "image/jpeg"
	_ "image/png"
	"math"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"unicode"
	"unicode/utf8"

	productionassets "nanpa-linja-n.com/resources"
)

var nativeBaseFamilies = map[string]string{
	"nasinNanpa":         "nanpa-linja-n-nasin-nanpa-liberation-sans-vulgar-fit-tally-colon-middledotfix-compatible",
	"sitelenSeliKiwen":   "sitelen seli kiwen juniko-latin-ligatures-compatible",
	"fairfaxHd":          "Fairfax HD-compatible",
	"fairfaxPonaHd":      "Fairfax Pona HD-compatible",
	"linjaPona":          "linja pona 4.9-compatible",
	"linjaSike":          "linja sike 5-cartouche-fix-compatible",
	"nasinSitelenPuMono": "nasin-sitelen-pu mono-compatible",
	"linjaLipamanka":     "linja lipamanka-cartouche-fix-compatible",
}

var numericLikeRE = regexp.MustCompile(`[0-9]`)
var integerRE = regexp.MustCompile(`^\+?[0-9]+$`)
var compoundSplitRE = regexp.MustCompile(`([&+-])`)
var rawUnicodeScanRE = regexp.MustCompile(`(?i)U\+[0-9a-f]{4,6}(?:[ \t]+U\+[0-9a-f]{4,6})*`)
var sskSpecialRE = regexp.MustCompile(`(?:\{([^{}]+)\}\s*)?([A-Za-z][A-Za-z0-9_^<>]*)\(([^()]+)\)|([A-Za-z][A-Za-z0-9_^<>]*(?:[&+-][A-Za-z][A-Za-z0-9_^<>]*)+)|\{([^{}]+)\}\s*([A-Za-z][A-Za-z0-9_^<>]*)`)
var standardCoreSpecialRE = regexp.MustCompile(`(?i)pi\(([^()]+)\)|([A-Za-z][A-Za-z0-9_^<>]*(?:[&+-][A-Za-z][A-Za-z0-9_^<>]*)+)|(\|)|(pi\s+\{[^{}]*\})`)
var legacyLongPiRE = regexp.MustCompile(`(?i)pi\+__[A-Za-z][A-Za-z0-9^<>]*(?:__[A-Za-z][A-Za-z0-9^<>]*){0,2}|pi(?:\+\+\+|---)[ \t]*[A-Za-z][A-Za-z0-9_^<>]*[ \t]+[A-Za-z][A-Za-z0-9_^<>]*[ \t]+[A-Za-z][A-Za-z0-9_^<>]*|pi(?:\+\+|--)[ \t]*[A-Za-z][A-Za-z0-9_^<>]*[ \t]+[A-Za-z][A-Za-z0-9_^<>]*|pi\+[A-Za-z][A-Za-z0-9_^<>]*`)

var fullFontMaterializeMu sync.Mutex

type fullGraphic struct {
	Text, Family, FontPath  string
	Features                []string
	Width, Height, Baseline float64
	OriginX, OriginY        float64
	TallyGroups             []TallyGroup
	ImageBytes              []byte
	ImageHref               string
	UnknownDecoration       bool
}
type logicalFullRun struct {
	Run     FullRenderRun
	Graphic fullGraphic
}
type preparedFull struct {
	Plan   FullRenderPlan
	Placed []logicalFullRun
}

func parseHexColor(s string, def RGBA) RGBA {
	s = strings.TrimSpace(s)
	if strings.HasPrefix(s, "#") {
		h := s[1:]
		if len(h) == 3 {
			h = string([]byte{h[0], h[0], h[1], h[1], h[2], h[2]})
		}
		if len(h) == 6 {
			if b, e := hex.DecodeString(h); e == nil {
				return RGBA{b[0], b[1], b[2], 255}
			}
		}
	}
	return def
}
func normalizedFullOptions(o FullRenderOptions) FullRenderOptions {
	d := DefaultFullRenderOptions()
	if strings.TrimSpace(o.Font) == "" {
		o.Font = d.Font
	}
	if o.FontSize == 0 {
		o.FontSize = d.FontSize
	}
	if o.FontSize < 8 {
		o.FontSize = 8
	}
	if o.PaddingPx < 0 {
		o.PaddingPx = 0
	}
	if strings.TrimSpace(o.NumericOutput) == "" {
		o.NumericOutput = d.NumericOutput
	}
	if o.Parser.RendererMode == "" {
		o.Parser = d.Parser
	}
	if o.Layout.Align == "" {
		o.Layout = d.Layout
	}
	if o.Paint.FillStyle == "" {
		o.Paint = d.Paint
	}
	if o.Paint.UnknownText.Color == "" {
		o.Paint.UnknownText = d.Paint.UnknownText
	}
	if o.Paint.HaloColor == "" {
		o.Paint.HaloColor = d.Paint.HaloColor
	}
	return o
}

func (n *NanpaLinjaN) materializeFont(filename string) (string, error) {
	if filename == "" {
		return "", fmt.Errorf("empty font filename")
	}
	if n.closed {
		return "", fmt.Errorf("NanpaLinjaN facade is closed")
	}

	// Full-document rendering registers fonts with the process-wide Fontconfig
	// configuration.  A facade-local temporary file cannot be used here: once
	// that facade is closed Fontconfig may still retain the now-deleted path,
	// causing later renderer instances to resolve the same family through a
	// stale file.  Keep immutable embedded fonts at deterministic process-stable
	// paths instead.  The legacy numeric renderer intentionally retains its
	// existing facade-local materialisation path and is therefore unaffected.
	fullFontMaterializeMu.Lock()
	defer fullFontMaterializeMu.Unlock()

	b, err := productionassets.ReadFont(filename)
	if err != nil {
		return "", err
	}
	dir := filepath.Join(os.TempDir(), "nanpa-linja-n-go-full-fonts-v1")
	if err := os.MkdirAll(dir, 0700); err != nil {
		return "", err
	}
	path := filepath.Join(dir, filepath.Base(filename))
	if old, err := os.ReadFile(path); err == nil && bytes.Equal(old, b) {
		return path, nil
	}
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, b, 0600); err != nil {
		return "", err
	}
	if err := os.Rename(tmp, path); err != nil {
		_ = os.Remove(tmp)
		return "", err
	}
	return path, nil
}

func (n *NanpaLinjaN) RegisterRenderAdapter(id string, adapter RenderAdapter) {
	n.fullAdapterMu.Lock()
	defer n.fullAdapterMu.Unlock()
	if n.fullAdapters == nil {
		n.fullAdapters = map[string]RenderAdapter{}
	}
	n.fullAdapters[id] = adapter
}
func (n *NanpaLinjaN) GetRenderAdapter(id string) (RenderAdapter, bool) {
	n.fullAdapterMu.RLock()
	defer n.fullAdapterMu.RUnlock()
	a, ok := n.fullAdapters[id]
	return a, ok
}
func (n *NanpaLinjaN) RemoveRenderAdapter(id string) (RenderAdapter, bool) {
	n.fullAdapterMu.Lock()
	defer n.fullAdapterMu.Unlock()
	a, ok := n.fullAdapters[id]
	if ok {
		delete(n.fullAdapters, id)
	}
	return a, ok
}

func (n *NanpaLinjaN) ParseInput(input string, options ...FullRenderOptions) DocumentAST {
	o := DefaultFullRenderOptions()
	if len(options) > 0 {
		o = normalizedFullOptions(options[0])
	}
	ast := ParseDocument(input, o.Parser)
	for li := range ast.Lines {
		for si := range ast.Lines[li].Children {
			seg := &ast.Lines[li].Children[si]
			structures := []NumericStructure{}
			switch seg.Kind {
			case "text":
				for _, hit := range n.scanCanonicalNumericHits(seg.Value, o.Parser) {
					if hit.Start < 0 || hit.End <= hit.Start || hit.End > len(seg.Value) {
						continue
					}
					structure := NumericStructure{Kind: hit.Kind, Index: hit.Start, End: hit.End, SourceText: seg.Value[hit.Start:hit.End]}
					if structure.Kind == "" {
						structure.Kind = "number"
					}
					if hit.Parsed != nil {
						if hit.Parsed.Kind != nil && *hit.Parsed.Kind != "" {
							structure.Kind = *hit.Parsed.Kind
						}
						if hit.Parsed.SemanticKind != nil {
							structure.SemanticKind = *hit.Parsed.SemanticKind
						}
						if hit.Parsed.SemanticStartGlyph != nil {
							structure.SemanticStartGlyph = *hit.Parsed.SemanticStartGlyph
						}
					}
					structures = append(structures, structure)
				}
			case "bracket":
				source := "[" + seg.Value + "]"
				if parsed, ok := n.fullNumericParse(source, o.Parser); ok {
					kind := "number"
					if parsed.Kind != nil && *parsed.Kind != "" {
						kind = *parsed.Kind
					} else if parsed.SemanticKind != nil && *parsed.SemanticKind != "" {
						kind = *parsed.SemanticKind
					}
					structure := NumericStructure{Kind: kind, Index: 0, End: len(source), SourceText: source, WholeSegment: true}
					if parsed.SemanticKind != nil {
						structure.SemanticKind = *parsed.SemanticKind
					}
					if parsed.SemanticStartGlyph != nil {
						structure.SemanticStartGlyph = *parsed.SemanticStartGlyph
					}
					structures = append(structures, structure)
				}
			}
			if len(structures) > 0 {
				seg.NumericStructures = structures
			}
		}
	}
	return ast
}

// AstToText serializes a DocumentAST returned by ParseInput back to valid source text.
func (n *NanpaLinjaN) AstToText(ast DocumentAST, options ...FullRenderOptions) (string, error) {
	return AstToText(ast, options...)
}

func (n *NanpaLinjaN) numericFullParse(source string, p FullParserOptions) (*ParseResult, bool) {
	r, err := ParseNumber(source, p.numericOptions())
	if err != nil || r == nil {
		return nil, false
	}

	// Core-v1 is frozen and retains its historical positive-marker form for
	// colon-rendered numbers.  The canonical full renderer uses `en` for the
	// positive marker in [head : nena en ...].  Normalize that binding-only
	// representation here rather than modifying the frozen Core parser.
	patchPositiveMarker := func(in []int) []int {
		out := append([]int(nil), in...)
		start := 0
		if len(out) > 0 && out[0] == CartoucheStart {
			start = 1
		}
		if len(out) < start+4 {
			return out
		}
		head := out[start]
		isHead := head == wordToCP["nanpa"] || head == wordToCP["nasa"] || head == wordToCP["noka"] || head == wordToCP["tenpo"] || head == wordToCP["suno"] || head == wordToCP["toki"]
		if isHead && (out[start+1] == wordToCP["e"] || out[start+1] == ColonCodepoint) && out[start+2] == wordToCP["nena"] && out[start+3] == wordToCP["e"] {
			out[start+3] = wordToCP["en"]
		}
		return out
	}
	r.InnerCodepoints = patchPositiveMarker(r.InnerCodepoints)
	r.UcsurCodepoints = patchPositiveMarker(r.UcsurCodepoints)
	r.Codepoints = patchPositiveMarker(r.Codepoints)
	return r, true
}

func byteIndexForRuneIndex(s string, index int) int {
	if index <= 0 {
		return 0
	}
	n := 0
	i := 0
	for _, r := range s {
		if i >= index {
			break
		}
		n += utf8.RuneLen(r)
		i++
	}
	return n
}

func (n *NanpaLinjaN) measureGraphic(text, family, path string, size float64, features []string, pad int, bottomExtra float64) (fullGraphic, error) {
	m, err := nativeFullMeasure(text, family, path, size, features)
	if err != nil {
		return fullGraphic{}, err
	}
	w := float64(m.InkW + 2*pad)
	h := float64(m.InkH+2*pad) + bottomExtra
	return fullGraphic{Text: text, Family: family, FontPath: path, Features: append([]string(nil), features...), Width: math.Max(1, w), Height: math.Max(1, h), Baseline: m.Baseline - float64(m.InkY) + float64(pad), OriginX: float64(pad - m.InkX), OriginY: float64(pad - m.InkY)}, nil
}

// syntheticCornerBracketCodepoint mirrors the JavaScript baseline's
// renderer-synthetic-u300c-u300d adapter contract. It applies only to the two
// legacy adapter profiles whose manifest explicitly requests synthetic corner
// brackets. Raw U+ escapes and caller-registered adapter overrides remain exact
// and therefore bypass this profile-specific presentation rule.
func syntheticCornerBracketCodepoint(font ProductionFontInfo, canonical []int, rawBypass, customAdapter bool) (int, bool) {
	if rawBypass || customAdapter || len(canonical) != 1 {
		return 0, false
	}
	if font.RenderAdapterID != "linja-pona-legacy-v1" && font.RenderAdapterID != "linja-sike-legacy-v1" {
		return 0, false
	}
	if !strings.EqualFold(settingString(font.RenderAdapterSettings, "cornerBracketMode", ""), "synthetic") {
		return 0, false
	}
	cp := canonical[0]
	return cp, cp == OpenQuoteCodepoint || cp == CloseQuoteCodepoint
}

// syntheticCornerBracketGraphic uses the same geometry as
// measureSyntheticCornerBracket() in the JavaScript authority. Height is the
// bracket stroke box; Baseline can legitimately exceed Height for U+300C
// because the opening bracket is lifted above the text baseline.
func syntheticCornerBracketGraphic(fontPx float64, cp int) fullGraphic {
	px := math.Max(1, fontPx)
	w := math.Max(1, math.Ceil(px*0.36))
	h := math.Max(1, math.Ceil(px*0.76))
	lift := 0.0
	if cp == OpenQuoteCodepoint {
		lift = math.Max(4, px*0.18)
	}
	yTopFromBaseline := -(h * 0.82) - lift
	yBottomFromBaseline := yTopFromBaseline + h
	ascent := math.Max(0, -yTopFromBaseline)
	_ = math.Max(0, yBottomFromBaseline) // documents the JS descent calculation
	return fullGraphic{Width: w, Height: h, Baseline: ascent}
}

type syntheticCornerBracketGeometry struct {
	X1, Y1, X2, Y2, X3, Y3 float64
	StrokeWidth            float64
}

func syntheticCornerBracketGeometryFor(cp int, x, baseline, fontPx, widthPx, heightPx float64) (syntheticCornerBracketGeometry, bool) {
	if cp != OpenQuoteCodepoint && cp != CloseQuoteCodepoint {
		return syntheticCornerBracketGeometry{}, false
	}
	px := math.Max(1, fontPx)
	strokeW := math.Max(2.5, px*0.065)
	if px <= 12 {
		strokeW = math.Max(1.0, px*0.065)
	}
	runW := math.Max(widthPx, px*0.36)
	runH := math.Max(heightPx, px*0.76)
	pad := math.Max(0.5, strokeW*0.5)
	xLeft := x + pad
	xRight := x + runW - pad
	yTop := baseline - runH*0.82
	isRight := cp == CloseQuoteCodepoint
	if !isRight {
		yTop -= math.Max(4, px*0.18)
	}
	yBottom := yTop + runH
	arm := math.Max(px*0.26, math.Min(runW*0.82, px*0.48))
	if isRight {
		return syntheticCornerBracketGeometry{
			X1: xRight - arm + strokeW*0.5, Y1: yBottom - strokeW*0.5,
			X2: xRight - strokeW*0.5, Y2: yBottom - strokeW*0.5,
			X3: xRight - strokeW*0.5, Y3: yTop + strokeW*0.5,
			StrokeWidth: strokeW,
		}, true
	}
	return syntheticCornerBracketGeometry{
		X1: xLeft + strokeW*0.5, Y1: yBottom - strokeW*0.5,
		X2: xLeft + strokeW*0.5, Y2: yTop + strokeW*0.5,
		X3: xLeft + arm - strokeW*0.5, Y3: yTop + strokeW*0.5,
		StrokeWidth: strokeW,
	}, true
}

func (n *NanpaLinjaN) glyphLogical(source string, cps []int, start, end int, sourceKind string, font ProductionFontInfo, o FullRenderOptions, quoted, interpreted bool) (logicalFullRun, error) {
	canonical := append([]int(nil), cps...)
	render := append([]int(nil), canonical...)
	// Explicit U+... source escapes bypass production-font adapters in the
	// canonical renderer. Ordinary parsed glyphs use the font's built-in
	// adapter unless a caller has registered an override for that adapter ID.
	_, rawBypass := parseRawUnicodeSequence(strings.TrimSpace(source))
	customAdapter := false
	if !rawBypass {
		if a, ok := n.GetRenderAdapter(font.RenderAdapterID); ok {
			customAdapter = true
			render = a(render, font, o.FontSize)
		} else {
			render = adaptBuiltinFullWordRun(font, render)
		}
	}
	var b strings.Builder
	for _, cp := range render {
		if err := validateScalar(cp); err != nil {
			return logicalFullRun{}, err
		}
		b.WriteRune(rune(cp))
	}
	text := b.String()
	adapterID := font.RenderAdapterID
	if rawBypass {
		adapterID = "identity"
	}
	r := FullRenderRun{Kind: "glyph", RenderMode: "text", FontRole: "word", CanonicalCodepoints: canonical, RenderCodepoints: render, RenderText: text, RenderAdapterID: adapterID, SourceText: source, SourceKind: sourceKind, SourceStart: start, SourceEnd: end, Quoted: quoted, InterpretedQuote: interpreted}
	if cp, ok := syntheticCornerBracketCodepoint(font, canonical, rawBypass, customAdapter); ok {
		r.RenderMode = "synthetic-corner-bracket"
		return logicalFullRun{r, syntheticCornerBracketGraphic(o.FontSize, cp)}, nil
	}
	path, err := n.materializeFont(font.BaseFilename)
	if err != nil {
		return logicalFullRun{}, err
	}
	fam := nativeBaseFamilies[font.Key]
	g, err := n.measureGraphic(text, fam, path, o.FontSize, nil, 0, 0)
	if err != nil {
		return logicalFullRun{}, err
	}
	// Canonical raw U+ escapes are explicit run elements even when they contain
	// one scalar. Legacy adapters likewise return a run when one canonical glyph
	// expands to multiple render codepoints (e.g. "jan" in linja pona).
	if rawBypass || len(canonical) > 1 || len(render) > 1 {
		r.Kind = "run"
	}
	return logicalFullRun{r, g}, nil
}

func (n *NanpaLinjaN) literalRenderedLogical(renderText, source string, start, end int, sourceKind string, font ProductionFontInfo, o FullRenderOptions, quoted, interpreted, unknown bool) (logicalFullRun, error) {
	support, err := n.registry.supportFont("literalText")
	if err != nil {
		return logicalFullRun{}, err
	}
	path, err := n.materializeFont(support.Filename)
	if err != nil {
		return logicalFullRun{}, err
	}
	g, err := n.measureGraphic(renderText, support.Family, path, o.FontSize, nil, 0, 0)
	if err != nil {
		return logicalFullRun{}, err
	}
	if unknown {
		pad := math.Max(0, o.Paint.UnknownText.PaddingPx)
		g.Width += 2 * pad
		g.Height += 2 * pad
		g.Baseline += pad
		g.OriginX += pad
		g.OriginY += pad
		g.UnknownDecoration = true
	}
	role := "literal"
	if unknown && (interpreted || sourceKind == "interpretedQuote") {
		role = "unknown"
	}
	r := FullRenderRun{Kind: "text", RenderMode: "raster", FontRole: role, RenderText: renderText, RenderAdapterID: "identity", SourceText: source, SourceKind: sourceKind, SourceStart: start, SourceEnd: end, Quoted: quoted, InterpretedQuote: interpreted, Unrecognized: unknown}
	return logicalFullRun{r, g}, nil
}

func (n *NanpaLinjaN) literalLogical(source string, start, end int, sourceKind string, font ProductionFontInfo, o FullRenderOptions, quoted, interpreted, unknown bool) (logicalFullRun, error) {
	return n.literalRenderedLogical(source, source, start, end, sourceKind, font, o, quoted, interpreted, unknown)
}

func (n *NanpaLinjaN) numericLogical(source string, parsed *ParseResult, start, end int, sourceKind string, font ProductionFontInfo, o FullRenderOptions) (logicalFullRun, error) {
	full := productionCanonicalCodepoints(parsed)
	if o.Parser.AbbreviateNumericCartouches {
		ab, err := abbreviateProductionCartouche(full, o.Parser.PreserveNumericCartoucheBreaks)
		if err != nil {
			return logicalFullRun{}, err
		}
		full = ab
	}
	text, _, err := adaptProductionCartouche(full, font.RenderAdapterID, font.RenderAdapterSettings, font.Settings)
	if err != nil {
		return logicalFullRun{}, err
	}
	path, err := n.materializeFont(font.CompanionFilename)
	if err != nil {
		return logicalFullRun{}, err
	}
	features := openTypeFeaturesFor(o.FontSize)
	g, err := n.measureGraphic(text, font.NativeCompanionFamily, path, o.FontSize, features, 6, 0)
	if err != nil {
		return logicalFullRun{}, err
	}
	inner := full
	if len(full) >= 2 {
		inner = full[1 : len(full)-1]
	}
	base := 10
	if parsed.NumberBase != nil {
		base = *parsed.NumberBase
	}
	r := FullRenderRun{Kind: "cartouche", RenderMode: "raster", FontRole: "number", NumericCartouche: true, NumericBase: base, CanonicalCodepoints: append([]int(nil), inner...), RenderText: text, RenderCodepoints: renderCodepointsWithoutScaleMarkers(text), RenderAdapterID: font.RenderAdapterID, SourceText: source, SourceKind: sourceKind, SourceStart: start, SourceEnd: end}
	if parsed.IsHex != nil {
		r.HexCartouche = *parsed.IsHex
	}
	if parsed.IsBinary != nil {
		r.BinaryCartouche = *parsed.IsBinary
	}
	if len(inner) > 0 {
		r.OpenerCodepoint = intPtr(inner[0])
		r.CloserCodepoint = intPtr(inner[len(inner)-1])
	}
	return logicalFullRun{r, g}, nil
}
func runesToInts(s string) []int {
	out := []int{}
	for _, r := range s {
		out = append(out, int(r))
	}
	return out
}

func (n *NanpaLinjaN) cartoucheLogical(source string, oc ordinaryCartouche, start, end int, sourceKind string, font ProductionFontInfo, o FullRenderOptions) (logicalFullRun, error) {
	adapted := adaptOrdinary(font, oc.Inner)
	adapted = applyOrdinaryScaleMarkers(adapted, oc.ScaleMarkers)
	path, err := n.materializeFont(font.BaseFilename)
	if err != nil {
		return logicalFullRun{}, err
	}
	fam := nativeBaseFamilies[font.Key]
	extra := 0.0
	if oc.hasManualTallies() {
		extra = math.Ceil(o.FontSize * .34)
	}
	g, err := n.measureGraphic(adapted.Text, fam, path, o.FontSize, nil, 6, extra)
	if err != nil {
		return logicalFullRun{}, err
	}
	groups := []TallyGroup{}
	if oc.hasManualTallies() {
		bottom := float64(g.Height) - extra - 6
		lift := manualTallyLift(font, o.Parser, o.FontSize)
		top := bottom - lift
		bot := top + o.FontSize*.10
		stroke := math.Max(1.5, o.FontSize*.045)
		gap := o.FontSize * .075
		for i, count := range oc.ManualTallies {
			count = minInt(8, maxInt(0, count))
			if count == 0 {
				continue
			}
			span := adapted.CanonicalSpans[i+1]
			lx, err := nativeFullCaretX(adapted.Text, fam, path, o.FontSize, nil, byteIndexForRuneIndex(adapted.Text, span[0]))
			if err != nil {
				return logicalFullRun{}, err
			}
			rx, err := nativeFullCaretX(adapted.Text, fam, path, o.FontSize, nil, byteIndexForRuneIndex(adapted.Text, span[1]))
			if err != nil {
				return logicalFullRun{}, err
			}
			left := g.OriginX + lx
			right := g.OriginX + rx
			center := (left + right) / 2
			total := stroke
			if count > 1 {
				total = float64(count)*stroke + float64(count-1)*gap
			}
			first := center - total/2 + stroke/2
			centers := make([]float64, count)
			for k := 0; k < count; k++ {
				centers[k] = first + float64(k)*(stroke+gap)
			}
			groups = append(groups, TallyGroup{OwnerIndex: i, Count: count, OwnerLeftPx: left, OwnerRightPx: right, CenterXPx: center, TopYPx: top, BottomYPx: bot, StrokeWidthPx: stroke, StrokeCentersPx: centers})
		}
	}
	g.TallyGroups = groups
	manual := []int(nil)
	if oc.hasManualTallies() {
		manual = append([]int(nil), oc.ManualTallies...)
	}
	r := FullRenderRun{Kind: "cartouche", RenderMode: "raster", FontRole: "cartouche", OpenerCodepoint: intPtr(CartoucheStart), CloserCodepoint: intPtr(CartoucheEnd), CanonicalCodepoints: append([]int(nil), oc.Inner...), RenderCodepoints: runesToInts(adapted.Text), RenderText: adapted.Text, RenderAdapterID: font.RenderAdapterID, SourceText: source, SourceKind: sourceKind, SourceStart: start, SourceEnd: end, ManualTallies: manual}
	return logicalFullRun{r, g}, nil
}
func maxInt(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func parseSize(v string, base float64) float64 {
	v = strings.TrimSpace(strings.ToLower(v))
	if v == "" {
		return math.NaN()
	}
	mul := 1.0
	if strings.HasSuffix(v, "em") {
		mul = base
		v = strings.TrimSuffix(v, "em")
	} else if strings.HasSuffix(v, "px") {
		v = strings.TrimSuffix(v, "px")
	}
	f, e := strconv.ParseFloat(v, 64)
	if e != nil {
		return math.NaN()
	}
	return f * mul
}
func (n *NanpaLinjaN) imageLogical(seg DocumentSegment, font ProductionFontInfo, o FullRenderOptions) (logicalFullRun, error) {
	d := seg.Image
	if d == nil {
		d = &ImageDescriptor{VAlign: "baseline", Transparent: true}
	}
	var raw []byte
	var err error
	if strings.HasPrefix(d.Src, "data:image/") {
		raw, err = decodeDataImage(d.Src)
	} else if d.Src != "" {
		raw, err = os.ReadFile(d.Src)
	}
	if err != nil {
		raw = nil
	}
	w, h := math.NaN(), math.NaN()
	if len(raw) > 0 {
		if cfg, _, e := image.DecodeConfig(bytes.NewReader(raw)); e == nil {
			w = float64(cfg.Width)
			h = float64(cfg.Height)
		}
	}
	targetW, targetH := parseSize(d.W, o.FontSize), parseSize(d.H, o.FontSize)
	if math.IsNaN(targetW) && math.IsNaN(targetH) {
		targetH = o.FontSize
	}
	if math.IsNaN(targetW) {
		if math.IsNaN(w) || math.IsNaN(h) || h == 0 {
			targetW = targetH
		} else {
			targetW = targetH * w / h
		}
	}
	if math.IsNaN(targetH) {
		if math.IsNaN(w) || math.IsNaN(h) || w == 0 {
			targetH = targetW
		} else {
			targetH = targetW * h / w
		}
	}
	baseline := targetH
	if strings.EqualFold(d.VAlign, "center") {
		baseline = targetH * .75
	}
	r := FullRenderRun{Kind: "cartouche", RenderMode: "raster", FontRole: "cartouche", RenderAdapterID: font.RenderAdapterID, SourceKind: "image", SourceStart: seg.SourceStart, SourceEnd: seg.SourceEnd, ImageAlt: d.Alt}
	return logicalFullRun{r, fullGraphic{Width: math.Max(1, targetW), Height: math.Max(1, targetH), Baseline: baseline, ImageBytes: raw, ImageHref: d.Src}}, nil
}

var glyphInputAliases = map[string]string{
	"ni01": "ni", "ni02": "ni>", "ni03": "ni^", "ni04": "ni<",
	"sewi01": "sewi", "sewi02": "sewi^",
}

func fullGlyphCP(key string) (int, bool) {
	switch key {
	case "te":
		return 0x300C, true
	case "to":
		return 0x300D, true
	case "zz":
		return 0x3000, true
	default:
		cp, ok := wordToCP[key]
		return cp, ok
	}
}

func normalizeFullGlyphKey(raw string) string {
	key := strings.ToLower(strings.TrimSpace(raw))
	if alias, ok := glyphInputAliases[key]; ok {
		return alias
	}
	if key == "·" || key == "." || key == ":" || key == "," {
		return key
	}
	return sanitizeWord(key)
}

func glyphExpressionCps(expression string) ([]int, bool) {
	source := strings.TrimSpace(expression)
	if source == "" || strings.IndexFunc(source, unicode.IsSpace) >= 0 {
		return nil, false
	}
	parts := compoundSplitRE.Split(source, -1)
	ops := compoundSplitRE.FindAllString(source, -1)
	if len(parts) == 0 || len(parts) != len(ops)+1 {
		return nil, false
	}
	cps := make([]int, 0, len(parts)+len(ops))
	for i, part := range parts {
		if part == "" {
			return nil, false
		}
		cp, ok := fullGlyphCP(normalizeFullGlyphKey(part))
		if !ok {
			return nil, false
		}
		cps = append(cps, cp)
		if i < len(ops) {
			switch ops[i] {
			case "&":
				cps = append(cps, 0x200D)
			case "-":
				cps = append(cps, StackJoinerCodepoint)
			case "+":
				cps = append(cps, NestJoinerCodepoint)
			default:
				return nil, false
			}
		}
	}
	return cps, true
}

func glyphWordsCps(text string) ([]int, bool) {
	fields := strings.Fields(strings.TrimSpace(text))
	if len(fields) == 0 {
		return nil, false
	}
	var out []int
	for _, field := range fields {
		cps, ok := glyphExpressionCps(field)
		if !ok {
			key := normalizeFullGlyphKey(field)
			cp, yes := fullGlyphCP(key)
			if !yes {
				return nil, false
			}
			cps = []int{cp}
		}
		out = append(out, cps...)
	}
	return out, true
}

func extendedGlyphCps(left, head, right string) ([]int, bool) {
	headCp, ok := fullGlyphCP(normalizeFullGlyphKey(head))
	if !ok {
		return nil, false
	}
	var out []int
	if strings.TrimSpace(left) != "" {
		cps, ok := glyphWordsCps(left)
		if !ok || len(cps) == 0 {
			return nil, false
		}
		out = append(out, 0xF199A)
		out = append(out, cps...)
		out = append(out, 0xF199B)
	}
	out = append(out, headCp)
	if strings.TrimSpace(right) != "" {
		cps, ok := glyphWordsCps(right)
		if !ok || len(cps) == 0 {
			return nil, false
		}
		out = append(out, 0xF1997)
		out = append(out, cps...)
		out = append(out, 0xF1998)
	}
	if len(out) <= 1 {
		return nil, false
	}
	return out, true
}

func legacyLongPiInner(source string) (string, bool) {
	s := strings.TrimSpace(source)
	lower := strings.ToLower(s)
	if strings.HasPrefix(lower, "pi+__") {
		parts := strings.Split(s[5:], "__")
		if len(parts) < 1 || len(parts) > 3 {
			return "", false
		}
		for _, part := range parts {
			if _, ok := fullGlyphCP(normalizeFullGlyphKey(part)); !ok {
				return "", false
			}
		}
		return strings.Join(parts, " "), true
	}
	m := regexp.MustCompile(`(?i)^pi(\+{1,3}|-{2,3})(.*)$`).FindStringSubmatch(s)
	if m == nil {
		return "", false
	}
	expected := len(m[1])
	words := strings.Fields(strings.TrimSpace(m[2]))
	if len(words) != expected {
		return "", false
	}
	for _, word := range words {
		if _, ok := fullGlyphCP(normalizeFullGlyphKey(word)); !ok {
			return "", false
		}
	}
	return strings.Join(words, " "), true
}

func (n *NanpaLinjaN) emitCore(core string, start, end int, kind string, out *[]logicalFullRun, font ProductionFontInfo, o FullRenderOptions) error {
	if allRunesUcsur(core) {
		return n.appendGlyph(out, core, runesToInts(core), start, end, kind, font, o, false, false)
	}

	// Exact alternative-glyph aliases must win before numeric parsing.
	if alias, ok := glyphInputAliases[strings.ToLower(strings.TrimSpace(core))]; ok {
		cp, _ := fullGlyphCP(alias)
		return n.appendGlyph(out, core, []int{cp}, start, end, kind, font, o, false, false)
	}

	// te/to are literal corner-bracket code points. zz is an ideographic-space
	// cell rendered through the literal-font path, matching the canonical JS.
	key := normalizeFullGlyphKey(core)
	if key == "zz" {
		l, err := n.literalRenderedLogical("\u3000", core, start, end, kind, font, o, false, false, false)
		if err == nil {
			*out = append(*out, l)
		}
		return err
	}
	if key == "te" || key == "to" {
		cp, _ := fullGlyphCP(key)
		return n.appendGlyph(out, core, []int{cp}, start, end, kind, font, o, false, false)
	}

	if parsed, ok := n.numericFullParse(core, o.Parser); ok {
		if o.Parser.NasinNanpaPona && integerRE.MatchString(core) {
			for _, w := range nnpWords(strings.TrimPrefix(core, "+")) {
				if cp, ok := wordToCP[w]; ok {
					if err := n.appendGlyph(out, core, []int{cp}, start, end, kind, font, o, false, false); err != nil {
						return err
					}
				}
			}
			return nil
		}
		l, err := n.numericLogical(core, parsed, start, end, kind, font, o)
		if err != nil {
			return err
		}
		*out = append(*out, l)
		return nil
	}
	if o.Parser.AutoCartoucheStandaloneProperNames && core != "" {
		r, _ := utf8.DecodeRuneInString(core)
		if unicode.IsUpper(r) {
			if cps, ok := properNameCodepoints(core); ok {
				l, err := n.cartoucheLogical(core, ordinaryCartouche{Inner: cps, ManualTallies: make([]int, len(cps)), TallyMode: "ucsur"}, start, end, kind, font, o)
				if err != nil {
					return err
				}
				*out = append(*out, l)
				return nil
			}
		}
	}
	if cp, ok := fullGlyphCP(key); ok {
		// Protocol v1.1.0: outside cartouches U+002C remains an ordinary
		// word-font run. It is never interpreted as a tally mark here.
		if key == "," {
			l, err := n.glyphLogical(core, []int{cp}, start, end, kind, font, o, false, false)
			if err != nil {
				return err
			}
			l.Run.Kind = "run"
			*out = append(*out, l)
			return nil
		}
		return n.appendGlyph(out, core, []int{cp}, start, end, kind, font, o, false, false)
	}
	if o.Parser.ShowUnknownText {
		lit := core
		ls, le := start, end
		if effectiveRendererMode(o.Parser) == "standard-sitelen-pona-ascii-core" && len(lit) >= 2 && strings.HasPrefix(lit, "'") && strings.HasSuffix(lit, "'") {
			lit = lit[1 : len(lit)-1]
			ls++
			le--
		}
		l, err := n.literalLogical(lit, ls, le, kind, font, o, false, false, true)
		if err != nil {
			return err
		}
		*out = append(*out, l)
	}
	return nil
}

func (n *NanpaLinjaN) appendGlyph(out *[]logicalFullRun, source string, cps []int, start, end int, kind string, font ProductionFontInfo, o FullRenderOptions, quoted, interpreted bool) error {
	l, err := n.glyphLogical(source, cps, start, end, kind, font, o, quoted, interpreted)
	if err == nil {
		*out = append(*out, l)
	}
	return err
}

// renderTpWordsFallback is the ordinary-word fallback used after the canonical
// whole-segment numeric scanner has claimed all semantic numeric spans. It must
// not perform a second broad numeric scan of the complete segment.
func fullFallbackCoreChar(b byte, numericLike bool) bool {
	if (b >= 'A' && b <= 'Z') || (b >= 'a' && b <= 'z') || (b >= '0' && b <= '9') {
		return true
	}
	switch b {
	case '#', '~', '^', '<', '>':
		return true
	case '.', ',', '_', '-':
		return numericLike
	default:
		return false
	}
}

func splitFullFallbackToken(token string) (lead, core, trail string, coreStart, coreEnd int) {
	if token == "" {
		return "", "", "", 0, 0
	}
	numericLike := regexp.MustCompile(`[0-9]|^-?\.\d|^-?\d`).MatchString(token)
	a, b := 0, len(token)
	for a < b {
		if token[a] < 0x80 && fullFallbackCoreChar(token[a], numericLike) {
			break
		}
		_, size := utf8.DecodeRuneInString(token[a:])
		a += size
	}
	for b > a {
		_, size := utf8.DecodeLastRuneInString(token[:b])
		idx := b - size
		if size == 1 && fullFallbackCoreChar(token[idx], numericLike) {
			break
		}
		b = idx
	}
	// Canonical splitTokenPunct additionally removes ordinary trailing sentence
	// punctuation even when it is otherwise a numeric-core character.
	for b > a {
		c := token[b-1]
		if !strings.ContainsRune(")]}.,;:!?", rune(c)) {
			break
		}
		b--
	}
	return token[:a], token[a:b], token[b:], a, b
}

func (n *NanpaLinjaN) emitFallbackPunct(punct string, sourceStart int, kind string, out *[]logicalFullRun, font ProductionFontInfo, o FullRenderOptions) error {
	for off, r := range punct {
		cp := 0
		switch r {
		case '.', '·':
			cp = MiddleDotCodepoint
		case ':':
			cp = ColonCodepoint
		case ',':
			cp = int(r)
		}
		if cp == 0 {
			continue
		}
		sz := utf8.RuneLen(r)
		if r == ',' {
			// Protocol v1.1.0 keeps U+002C as an ordinary word-font run
			// outside cartouches; it is not a tally mark in this context.
			l, err := n.glyphLogical(string(r), []int{cp}, sourceStart+off, sourceStart+off+sz, kind, font, o, false, false)
			if err != nil {
				return err
			}
			l.Run.Kind = "run"
			*out = append(*out, l)
			continue
		}
		if err := n.appendGlyph(out, string(r), []int{cp}, sourceStart+off, sourceStart+off+sz, kind, font, o, false, false); err != nil {
			return err
		}
	}
	return nil
}

// renderTpWordsFallback mirrors the canonical renderer's ordinary token
// fallback after the whole-segment numeric scanner has claimed semantic
// numeric spans. Unicode dash/minus lookalikes are separators; ASCII '-' is
// retained inside a token so the mode-specific compound parsers can own it.
func (n *NanpaLinjaN) renderTpWordsFallback(text string, base int, kind string, out *[]logicalFullRun, font ProductionFontInfo, o FullRenderOptions) error {
	if text == "" || strings.TrimSpace(text) == "" {
		return nil
	}
	fields := regexp.MustCompile(`[^\s\x{2010}\x{2011}\x{2012}\x{2013}\x{2014}\x{2212}\x{FE63}\x{FF0D}]+`).FindAllStringIndex(text, -1)
	for _, loc := range fields {
		token := text[loc[0]:loc[1]]
		lead, core, trail, coreStart, coreEnd := splitFullFallbackToken(token)
		if err := n.emitFallbackPunct(lead, base+loc[0], kind, out, font, o); err != nil {
			return err
		}
		if core != "" {
			// A standalone compound operator is syntax punctuation, not unknown
			// literal text. This is how "toki & pona" remains two words.
			if core != "&" && core != "+" && core != "-" {
				if err := n.emitCore(core, base+loc[0]+coreStart, base+loc[0]+coreEnd, kind, out, font, o); err != nil {
					return err
				}
			}
		}
		if err := n.emitFallbackPunct(trail, base+loc[0]+coreEnd, kind, out, font, o); err != nil {
			return err
		}
	}
	return nil
}

func (n *NanpaLinjaN) parseTextBase(text string, base int, kind string, out *[]logicalFullRun, font ProductionFontInfo, o FullRenderOptions) error {
	if text == "" || strings.TrimSpace(text) == "" {
		return nil
	}
	hits := n.scanCanonicalNumericHits(text, o.Parser)
	if len(hits) == 0 {
		return n.renderTpWordsFallback(text, base, kind, out, font, o)
	}
	pos := 0
	for _, h := range hits {
		if h.Start > pos {
			if err := n.renderTpWordsFallback(text[pos:h.Start], base+pos, kind, out, font, o); err != nil {
				return err
			}
		}
		raw := text[h.Start:h.End]
		if o.Parser.NasinNanpaPona && integerRE.MatchString(raw) {
			for _, w := range nnpWords(strings.TrimPrefix(raw, "+")) {
				if cp, yes := wordToCP[w]; yes {
					if err := n.appendGlyph(out, raw, []int{cp}, base+h.Start, base+h.End, kind, font, o, false, false); err != nil {
						return err
					}
				}
			}
		} else if h.Parsed != nil {
			l, err := n.numericLogical(raw, h.Parsed, base+h.Start, base+h.End, kind, font, o)
			if err != nil {
				return err
			}
			*out = append(*out, l)
		}
		pos = h.End
	}
	if pos < len(text) {
		return n.renderTpWordsFallback(text[pos:], base+pos, kind, out, font, o)
	}
	return nil
}

func (n *NanpaLinjaN) parseSskLikeText(text string, base int, kind string, out *[]logicalFullRun, font ProductionFontInfo, o FullRenderOptions) error {
	matches := sskSpecialRE.FindAllStringSubmatchIndex(text, -1)
	pos := 0
	for _, m := range matches {
		start, end := m[0], m[1]
		match := text[start:end]
		var cps []int
		var ok bool
		group := func(i int) string {
			if i+1 >= len(m) || m[i] < 0 {
				return ""
			}
			return text[m[i]:m[i+1]]
		}
		if group(4) != "" { // head(right), optionally {left}
			cps, ok = extendedGlyphCps(group(2), group(4), group(6))
		} else if group(8) != "" {
			cps, ok = glyphExpressionCps(group(8))
		} else if group(10) != "" && group(12) != "" {
			cps, ok = extendedGlyphCps(group(10), group(12), "")
		}
		if !ok {
			continue
		}
		if start > pos {
			if err := n.parseTextBase(text[pos:start], base+pos, kind, out, font, o); err != nil {
				return err
			}
		}
		if err := n.appendGlyph(out, match, cps, base+start, base+end, kind, font, o, false, false); err != nil {
			return err
		}
		pos = end
	}
	if pos < len(text) {
		return n.parseTextBase(text[pos:], base+pos, kind, out, font, o)
	}
	return nil
}

func (n *NanpaLinjaN) parseExtendedText(text string, base int, kind string, out *[]logicalFullRun, font ProductionFontInfo, o FullRenderOptions) error {
	matches := legacyLongPiRE.FindAllStringIndex(text, -1)
	pos := 0
	for _, m := range matches {
		if m[0] > pos {
			if err := n.parseSskLikeText(text[pos:m[0]], base+pos, kind, out, font, o); err != nil {
				return err
			}
		}
		alias := text[m[0]:m[1]]
		if inner, ok := legacyLongPiInner(alias); ok {
			if cps, ok := extendedGlyphCps("", "pi", inner); ok {
				if err := n.appendGlyph(out, alias, cps, base+m[0], base+m[1], kind, font, o, false, false); err != nil {
					return err
				}
			} else if err := n.parseSskLikeText(alias, base+m[0], kind, out, font, o); err != nil {
				return err
			}
		} else if err := n.parseSskLikeText(alias, base+m[0], kind, out, font, o); err != nil {
			return err
		}
		pos = m[1]
	}
	if pos < len(text) {
		return n.parseSskLikeText(text[pos:], base+pos, kind, out, font, o)
	}
	return nil
}

func (n *NanpaLinjaN) parseStandardCoreText(text string, base int, kind string, out *[]logicalFullRun, font ProductionFontInfo, o FullRenderOptions) error {
	matches := standardCoreSpecialRE.FindAllStringSubmatchIndex(text, -1)
	pos := 0
	for _, m := range matches {
		start, end := m[0], m[1]
		match := text[start:end]
		group := func(i int) string {
			if i+1 >= len(m) || m[i] < 0 {
				return ""
			}
			return text[m[i]:m[i+1]]
		}
		var cps []int
		var ok bool
		switch {
		case group(2) != "": // pi(inner)
			if inner, yes := glyphWordsCps(group(2)); yes {
				cps = append([]int{wordToCP["pi"], 0xF1997}, inner...)
				cps = append(cps, 0xF1998)
				ok = true
			}
		case group(4) != "":
			cps, ok = glyphExpressionCps(group(4))
		case group(6) == "|":
			cps, ok = []int{0x3000}, true
		default:
			// pi { ... } is intentionally not legacy-long-pi syntax in core mode.
			ok = false
		}
		if start > pos {
			if err := n.parseTextBase(text[pos:start], base+pos, kind, out, font, o); err != nil {
				return err
			}
		}
		if !ok {
			// The canonical Standard Core tokenizer still consumes syntactic-looking
			// tokens whose glyph expression is invalid, then delegates just that
			// token to the ordinary bridge parser. This is important for quoted
			// alias names such as toki'zw-joiner'pona.
			if err := n.parseTextBase(match, base+start, kind, out, font, o); err != nil {
				return err
			}
			pos = end
			continue
		}
		if cps[0] == 0x3000 {
			l, err := n.glyphLogical(match, []int{0x3000}, base+start, base+end, kind, font, o, false, false)
			if err != nil {
				return err
			}
			l.Run.Kind = "run"
			*out = append(*out, l)
		} else if err := n.appendGlyph(out, match, cps, base+start, base+end, kind, font, o, false, false); err != nil {
			return err
		}
		pos = end
	}
	if pos < len(text) {
		return n.parseTextBase(text[pos:], base+pos, kind, out, font, o)
	}
	return nil
}

func (n *NanpaLinjaN) parseTextNoRaw(text string, base int, kind string, out *[]logicalFullRun, font ProductionFontInfo, o FullRenderOptions) error {
	switch effectiveRendererMode(o.Parser) {
	case "standard-sitelen-pona-ascii-core":
		return n.parseStandardCoreText(text, base, kind, out, font, o)
	case "sitelen-pona-ascii-extended":
		return n.parseExtendedText(text, base, kind, out, font, o)
	case "sitelen-seli-kiwen":
		return n.parseSskLikeText(text, base, kind, out, font, o)
	default:
		return n.parseTextBase(text, base, kind, out, font, o)
	}
}

func (n *NanpaLinjaN) parseText(text string, base int, kind string, out *[]logicalFullRun, font ProductionFontInfo, o FullRenderOptions) error {
	if text == "" || strings.TrimSpace(text) == "" {
		return nil
	}
	matches := rawUnicodeScanRE.FindAllStringIndex(text, -1)
	if len(matches) == 0 {
		return n.parseTextNoRaw(text, base, kind, out, font, o)
	}
	pos := 0
	for _, m := range matches {
		if m[0] > pos {
			if err := n.parseTextNoRaw(text[pos:m[0]], base+pos, kind, out, font, o); err != nil {
				return err
			}
		}
		rawText := text[m[0]:m[1]]
		if cps, ok := parseRawUnicodeSequence(rawText); ok {
			if err := n.appendGlyph(out, rawText, cps, base+m[0], base+m[1], kind, font, o, false, false); err != nil {
				return err
			}
		} else if err := n.parseTextNoRaw(rawText, base+m[0], kind, out, font, o); err != nil {
			return err
		}
		pos = m[1]
	}
	if pos < len(text) {
		return n.parseTextNoRaw(text[pos:], base+pos, kind, out, font, o)
	}
	return nil
}

func unescapeFullQuoted(raw string) string {
	s := raw
	s = strings.ReplaceAll(s, `\"`, `"`)
	s = strings.ReplaceAll(s, `\\`, `\`)
	s = strings.ReplaceAll(s, `\t`, "    ")
	s = strings.ReplaceAll(s, `\n`, "\n")
	return s
}

func normalizeExtendedLegacyCartouche(body string) (string, bool) {
	s := strings.TrimSpace(body)
	if !strings.HasPrefix(s, "_") {
		return "", false
	}
	parts := strings.Split(s, "_")
	var words []string
	for _, part := range parts {
		part = strings.TrimSpace(part)
		if part == "" {
			continue
		}
		if _, ok := fullGlyphCP(normalizeFullGlyphKey(part)); !ok {
			return "", false
		}
		words = append(words, part)
	}
	if len(words) == 0 {
		return "", false
	}
	return strings.Join(words, " "), true
}

func (n *NanpaLinjaN) parseBracket(body string, sourceStart int, out *[]logicalFullRun, font ProductionFontInfo, o FullRenderOptions) error {
	trim := strings.TrimSpace(body)
	if trim == "" {
		return nil
	}

	// Exact Latin-in-cartouche syntax: ["HELLO"].
	if len(trim) >= 2 && strings.HasPrefix(trim, `"`) && strings.HasSuffix(trim, `"`) {
		literal := unescapeFullQuoted(trim[1 : len(trim)-1])
		if literal != "" {
			inner := make([]int, 0, len([]rune(literal))*2)
			runes := []rune(literal)
			for i, r := range runes {
				inner = append(inner, int(r))
				if i < len(runes)-1 {
					inner = append(inner, 0xF1992)
				}
			}
			inner = append(inner, 0xF1992)
			l, err := n.cartoucheLogical(trim, ordinaryCartouche{Inner: inner, ManualTallies: make([]int, len(inner)), TallyMode: "ucsur"}, sourceStart, sourceStart+len(body), "bracket", font, o)
			if err != nil {
				return err
			}
			*out = append(*out, l)
			return nil
		}
	}

	// Bracket numeric precedence mirrors the canonical renderer. Typed/hex/
	// binary cartouche grammars are parsed with their surrounding brackets;
	// date/time/decimal/number-code forms are parsed from the inner source. Raw
	// #hex and 0b prefixes are *not* bracket syntax and must be allowed to fall
	// through to ordinary/random cartouche handling.
	if parsed, ok := n.numericFullParse("["+trim+"]", o.Parser); ok {
		l, err := n.numericLogical(trim, parsed, sourceStart, sourceStart+len(body), "bracket", font, o)
		if err != nil {
			return err
		}
		*out = append(*out, l)
		return nil
	}
	if parsed, ok := n.fullNumericParse(trim, o.Parser); ok {
		isHex := parsed.IsHex != nil && *parsed.IsHex
		isBinary := parsed.IsBinary != nil && *parsed.IsBinary
		if !isHex && !isBinary {
			l, err := n.numericLogical(trim, parsed, sourceStart, sourceStart+len(body), "bracket", font, o)
			if err != nil {
				return err
			}
			*out = append(*out, l)
			return nil
		}
	}

	// Strict full TP numeric phrases precede ordinary glyph cartouches.
	strictWords := strings.Fields(trim)
	strictClean := len(strictWords) > 0
	for _, w := range strictWords {
		if w != strings.ToLower(w) || regexp.MustCompile(`^[a-z]+$`).FindString(w) != w {
			strictClean = false
			break
		}
	}
	if strictClean {
		if parsed, ok := newPhraseParseResult(strictWords, o.Parser); ok {
			l, err := n.numericLogical(trim, parsed, sourceStart, sourceStart+len(body), "bracket", font, o)
			if err != nil {
				return err
			}
			*out = append(*out, l)
			return nil
		}
		if o.Parser.AbbreviateNumericCartouches {
			if parsed, ok := abbreviatedPhraseResult(strictWords, o.Parser); ok {
				// The source is already abbreviated; do not abbreviate its canonical
				// inner sequence a second time.
				copyOpts := o
				copyOpts.Parser.AbbreviateNumericCartouches = false
				l, err := n.numericLogical(trim, parsed, sourceStart, sourceStart+len(body), "bracket", font, copyOpts)
				if err != nil {
					return err
				}
				*out = append(*out, l)
				return nil
			}
		}
	}

	ordinarySource := trim
	if effectiveRendererMode(o.Parser) == "sitelen-pona-ascii-extended" {
		if normalized, ok := normalizeExtendedLegacyCartouche(body); ok {
			ordinarySource = normalized
		}
	}

	// Compound expressions inside ordinary cartouches use the same canonical
	// joiners as ordinary text.
	if cps, ok := glyphWordsCps(ordinarySource); ok && (strings.ContainsAny(ordinarySource, "&+-")) {
		l, err := n.cartoucheLogical(trim, ordinaryCartouche{Inner: cps, ManualTallies: make([]int, len(cps)), TallyMode: "ucsur"}, sourceStart, sourceStart+len(body), "bracket", font, o)
		if err != nil {
			return err
		}
		*out = append(*out, l)
		return nil
	}
	if oc, ok := parseOrdinaryBody(ordinarySource, font, o.Parser); ok {
		l, err := n.cartoucheLogical(trim, oc, sourceStart, sourceStart+len(body), "bracket", font, o)
		if err != nil {
			return err
		}
		*out = append(*out, l)
		return nil
	}
	// Canonical bracket parsing never falls back to unknown literal text. Its
	// final compatibility branch maps the Latin letters to random glyph buckets
	// and creates an ordinary cartouche when at least one bucket exists.
	if cps := lettersToFallbackGlyphCps(trim); len(cps) > 0 {
		l, err := n.cartoucheLogical(trim, ordinaryCartouche{Inner: cps, ManualTallies: make([]int, len(cps)), TallyMode: "ucsur"}, sourceStart, sourceStart+len(body), "bracket", font, o)
		if err != nil {
			return err
		}
		*out = append(*out, l)
	}
	return nil
}
func (n *NanpaLinjaN) parseQuote(seg DocumentSegment, out *[]logicalFullRun, font ProductionFontInfo, o FullRenderOptions) error {
	q := unescapeFullQuoted(seg.Value)
	if o.Parser.InterpretDoubleQuotesAsTeTo {
		if err := n.appendGlyph(out, "te", []int{OpenQuoteCodepoint}, seg.SourceStart, seg.SourceStart+1, "interpretedQuote", font, o, false, true); err != nil {
			return err
		}
		before := len(*out)
		if err := n.parseText(q, seg.SourceStart+1, "interpretedQuote", out, font, o); err != nil {
			return err
		}
		for i := before; i < len(*out); i++ {
			(*out)[i].Run.InterpretedQuote = true
		}
		return n.appendGlyph(out, "to", []int{CloseQuoteCodepoint}, maxInt(seg.SourceStart+1, seg.SourceEnd-1), seg.SourceEnd, "interpretedQuote", font, o, false, true)
	}
	l, err := n.literalRenderedLogical(q, seg.Value, seg.SourceStart, seg.SourceEnd, "quote", font, o, true, false, false)
	if err != nil {
		return err
	}
	*out = append(*out, l)
	return nil
}

func (n *NanpaLinjaN) prepareFull(input string, o FullRenderOptions) (preparedFull, error) {
	o = normalizedFullOptions(o)
	font, err := n.registry.Get(o.Font)
	if err != nil {
		return preparedFull{}, err
	}
	ast := ParseDocument(input, o.Parser)
	logicalLines := make([][]logicalFullRun, len(ast.Lines))
	var firstParsed *ParseResult
	anyAbbr := false
	for li, line := range ast.Lines {
		runs := []logicalFullRun{}
		for _, seg := range line.Children {
			switch seg.Kind {
			case "text":
				err = n.parseText(seg.Value, seg.SourceStart, "text", &runs, font, o)
			case "bracket":
				err = n.parseBracket(seg.Value, seg.SourceStart, &runs, font, o)
			case "quote":
				err = n.parseQuote(seg, &runs, font, o)
			case "image":
				var l logicalFullRun
				l, err = n.imageLogical(seg, font, o)
				if err == nil {
					runs = append(runs, l)
				}
			}
			if err != nil {
				return preparedFull{}, err
			}
		}
		for _, l := range runs {
			if l.Run.NumericCartouche && firstParsed == nil {
				if p, ok := n.numericFullParse(l.Run.SourceText, o.Parser); ok {
					firstParsed = p
				}
			}
			if l.Run.NumericCartouche && o.Parser.AbbreviateNumericCartouches {
				anyAbbr = true
			}
		}
		logicalLines[li] = runs
	}
	lineGap := o.Layout.lineGap(o.FontSize)
	pad := float64(o.PaddingPx)
	lineWidths := make([]float64, len(logicalLines))
	lineAsc := make([]float64, len(logicalLines))
	lineDesc := make([]float64, len(logicalLines))
	maxw := 0.0
	for i, line := range logicalLines {
		x, asc, desc := 0.0, 0.0, 0.0
		first := true
		for _, l := range line {
			if !first {
				if l.Run.FontRole == "cartouche" || l.Run.NumericCartouche {
					x += o.Layout.cartoucheLeadGap(o.FontSize)
				} else {
					x += o.Layout.glyphGap(o.FontSize)
				}
			}
			first = false
			x += l.Graphic.Width
			asc = math.Max(asc, l.Graphic.Baseline)
			desc = math.Max(desc, math.Max(0, l.Graphic.Height-l.Graphic.Baseline))
		}
		h := math.Max(o.FontSize, asc+desc)
		if len(line) == 0 {
			asc = o.FontSize * .82
			desc = h - asc
		}
		lineWidths[i] = x
		lineAsc[i] = asc
		lineDesc[i] = desc
		maxw = math.Max(maxw, x)
	}
	width := maxInt(1, int(math.Ceil(maxw+2*pad)))
	total := 2*pad + lineGap*float64(maxInt(0, len(logicalLines)-1))
	for i := range logicalLines {
		total += math.Max(o.FontSize, lineAsc[i]+lineDesc[i])
	}
	height := maxInt(1, int(math.Ceil(total)))
	allRuns := []FullRenderRun{}
	linePlans := []FullRenderLinePlan{}
	placed := []logicalFullRun{}
	y := pad
	for li, line := range logicalLines {
		lw, asc, desc := lineWidths[li], lineAsc[li], lineDesc[li]
		lh := math.Max(o.FontSize, asc+desc)
		x := pad
		switch strings.ToLower(o.Layout.Align) {
		case "center":
			x += (maxw - lw) / 2
		case "right":
			x += maxw - lw
		}
		lineStart := x
		lr := []FullRenderRun{}
		first := true
		for ri, l := range line {
			if !first {
				if l.Run.FontRole == "cartouche" || l.Run.NumericCartouche {
					x += o.Layout.cartoucheLeadGap(o.FontSize)
				} else {
					x += o.Layout.glyphGap(o.FontSize)
				}
			}
			first = false
			ty := y + asc - l.Graphic.Baseline
			tx := x
			r := l.Run
			r.ID = fmt.Sprintf("L%dR%d", li, ri)
			r.LineIndex = li
			r.RunIndex = ri
			r.XPx = tx
			r.YPx = ty
			r.WidthPx = l.Graphic.Width
			r.HeightPx = l.Graphic.Height
			r.BaselineYPx = y + asc
			if len(l.Graphic.TallyGroups) > 0 {
				r.TallyGroups = make([]TallyGroup, len(l.Graphic.TallyGroups))
				for gi, g := range l.Graphic.TallyGroups {
					ng := g
					ng.OwnerLeftPx += tx
					ng.OwnerRightPx += tx
					ng.CenterXPx += tx
					ng.TopYPx += ty
					ng.BottomYPx += ty
					ng.StrokeCentersPx = append([]float64(nil), g.StrokeCentersPx...)
					for k := range ng.StrokeCentersPx {
						ng.StrokeCentersPx[k] += tx
					}
					r.TallyGroups[gi] = ng
				}
			}
			pl := l
			pl.Run = r
			placed = append(placed, pl)
			allRuns = append(allRuns, r)
			lr = append(lr, r)
			x += l.Graphic.Width
		}
		linePlans = append(linePlans, FullRenderLinePlan{LineIndex: li, SourceLineIndex: ast.Lines[li].SourceLineIndex, SentenceIndexInSourceLine: ast.Lines[li].SentenceIndexInSourceLine, XPx: lineStart, YPx: y, WidthPx: lw, HeightPx: lh, BaselineYPx: y + asc, AscentPx: asc, DescentPx: desc, Runs: lr})
		y += lh
		if li+1 < len(logicalLines) {
			y += lineGap
		}
	}
	plan := FullRenderPlan{Input: input, FontKey: font.Key, Abbreviated: anyAbbr, Width: width, Height: height, OpenTypeFeatures: openTypeFeaturesFor(o.FontSize), Runs: allRuns, Parsed: firstParsed, AST: ast, Lines: linePlans}
	return preparedFull{plan, placed}, nil
}

func (n *NanpaLinjaN) BuildFullRenderPlan(input string, options ...FullRenderOptions) (FullRenderPlan, error) {
	o := DefaultFullRenderOptions()
	if len(options) > 0 {
		o = options[0]
	}
	p, err := n.prepareFull(input, o)
	return p.Plan, err
}

func (n *NanpaLinjaN) renderPreparedFull(prep preparedFull, o FullRenderOptions, format OutputFormat) ([]byte, error) {
	o = normalizedFullOptions(o)
	surf, err := newNativeFullSurface(prep.Plan.Width, prep.Plan.Height, format, Transparent)
	if err != nil {
		return nil, err
	}
	fg := parseHexColor(o.Paint.FillStyle, Black)
	hc := parseHexColor(o.Paint.HaloColor, RGBA{255, 255, 255, 255})
	hw := o.Paint.HaloWidthPx
	if hw <= 0 && o.Paint.HaloEnabled {
		hw = math.Max(2, math.Min(24, math.Round(math.Max(8, o.FontSize)*.10)))
	}
	tempImages := []string{}
	defer func() {
		for _, p := range tempImages {
			_ = os.Remove(p)
		}
	}()
	for _, l := range prep.Placed {
		r, g := l.Run, l.Graphic
		if len(g.ImageBytes) > 0 {
			f, e := os.CreateTemp("", "nanpa_full_img_*.png")
			if e != nil {
				return nil, e
			}
			if _, e = f.Write(g.ImageBytes); e != nil {
				_ = f.Close()
				return nil, e
			}
			_ = f.Close()
			tempImages = append(tempImages, f.Name())
			if e := surf.drawImage(f.Name(), r.XPx, r.YPx, g.Width, g.Height); e != nil {
				return nil, e
			}
			continue
		}
		// Manual tally halos follow the browser reference: one rounded backing per
		// tally group is painted before the cartouche/text foreground. The visible
		// tally strokes are then painted on top with butt caps and no per-line halo.
		if o.Paint.HaloEnabled && hw > 0 {
			padX := hw * .85
			padBottom := hw * .85
			radius := math.Max(1.25, math.Min(hw, o.FontSize*.045))
			for _, tg := range r.TallyGroups {
				if len(tg.StrokeCentersPx) == 0 {
					continue
				}
				left := tg.StrokeCentersPx[0] - tg.StrokeWidthPx/2
				right := tg.StrokeCentersPx[len(tg.StrokeCentersPx)-1] + tg.StrokeWidthPx/2
				x := left - padX
				y := tg.TopYPx
				w := (right - left) + padX*2
				h := math.Max(1, (tg.BottomYPx-tg.TopYPx)+padBottom)
				if e := surf.fillRoundedRect(x, y, w, h, radius, hc); e != nil {
					return nil, e
				}
			}
		}
		if r.RenderMode == "synthetic-corner-bracket" && len(r.CanonicalCodepoints) == 1 {
			if e := surf.drawSyntheticCornerBracket(r.CanonicalCodepoints[0], r.XPx, r.BaselineYPx, o.FontSize, r.WidthPx, r.HeightPx, fg, o.Paint.HaloEnabled, hc, hw); e != nil {
				return nil, e
			}
		} else if g.Text != "" {
			ox := r.XPx + g.OriginX
			oy := r.YPx + g.OriginY
			if e := surf.drawText(g.Text, g.Family, g.FontPath, o.FontSize, g.Features, ox, oy, fg, o.Paint.HaloEnabled, hc, hw); e != nil {
				return nil, e
			}
		}
		for _, tg := range r.TallyGroups {
			for _, cx := range tg.StrokeCentersPx {
				if e := surf.drawButtLine(cx, tg.TopYPx, cx, tg.BottomYPx, tg.StrokeWidthPx, fg); e != nil {
					return nil, e
				}
			}
		}
		if r.Unrecognized && g.UnknownDecoration {
			uc := parseHexColor(o.Paint.UnknownText.Color, Black)
			if e := surf.drawRect(r.XPx, r.YPx, g.Width, g.Height, math.Max(1, o.Paint.UnknownText.LineWidthPx), uc); e != nil {
				return nil, e
			}
		}
	}
	return surf.finish()
}
func (n *NanpaLinjaN) RenderFull(input string, format OutputFormat, options ...FullRenderOptions) (RenderResult, error) {
	o := DefaultFullRenderOptions()
	if len(options) > 0 {
		o = options[0]
	}
	prep, err := n.prepareFull(input, o)
	if err != nil {
		return RenderResult{}, err
	}
	b, err := n.renderPreparedFull(prep, o, format)
	if err != nil {
		return RenderResult{}, err
	}
	return RenderResult{Bytes: b, Width: prep.Plan.Width, Height: prep.Plan.Height, Format: format}, nil
}
func (n *NanpaLinjaN) RenderFullToPNG(input string, options ...FullRenderOptions) ([]byte, error) {
	r, e := n.RenderFull(input, OutputPNG, options...)
	return r.Bytes, e
}
func (n *NanpaLinjaN) RenderFullToSVG(input string, options ...FullRenderOptions) ([]byte, error) {
	r, e := n.RenderFull(input, OutputSVG, options...)
	return r.Bytes, e
}
func (n *NanpaLinjaN) RenderFullToPDF(input string, options ...FullRenderOptions) ([]byte, error) {
	r, e := n.RenderFull(input, OutputPDF, options...)
	return r.Bytes, e
}
func (n *NanpaLinjaN) RenderToCanvas(input string, options ...FullRenderOptions) (CanvasRenderResult, error) {
	o := DefaultFullRenderOptions()
	if len(options) > 0 {
		o = options[0]
	}
	prep, err := n.prepareFull(input, o)
	if err != nil {
		return CanvasRenderResult{}, err
	}
	b, err := n.renderPreparedFull(prep, o, OutputPNG)
	if err != nil {
		return CanvasRenderResult{}, err
	}
	im, _, err := image.Decode(bytes.NewReader(b))
	if err != nil {
		return CanvasRenderResult{}, err
	}
	var pp *FullRenderPlan
	if o.IncludePlan {
		p := prep.Plan
		pp = &p
	}
	return CanvasRenderResult{Image: im, Plan: pp, FontKey: prep.Plan.FontKey}, nil
}

func (n *NanpaLinjaN) ToVectorDocument(input string, options ...FullRenderOptions) (VectorDocument, error) {
	o := DefaultFullRenderOptions()
	if len(options) > 0 {
		o = options[0]
	}
	prep, err := n.prepareFull(input, o)
	if err != nil {
		return VectorDocument{}, err
	}
	els := []VectorElement{}
	for _, l := range prep.Placed {
		r, g := l.Run, l.Graphic
		if g.ImageHref != "" {
			els = append(els, VectorElement{Kind: "image", RunID: r.ID, Href: g.ImageHref, X: r.XPx, Y: r.YPx, Width: g.Width, Height: g.Height})
		} else if r.RenderMode == "synthetic-corner-bracket" && len(r.CanonicalCodepoints) == 1 {
			if sg, ok := syntheticCornerBracketGeometryFor(r.CanonicalCodepoints[0], r.XPx, r.BaselineYPx, o.FontSize, r.WidthPx, r.HeightPx); ok {
				path := fmt.Sprintf("M %.3f %.3f L %.3f %.3f L %.3f %.3f", sg.X1, sg.Y1, sg.X2, sg.Y2, sg.X3, sg.Y3)
				els = append(els, VectorElement{Kind: "path", RunID: r.ID, Path: path, Fill: o.Paint.FillStyle, X: r.XPx, Y: r.YPx, Width: r.WidthPx, Height: r.HeightPx})
			}
		} else if g.Text != "" {
			els = append(els, VectorElement{Kind: "text", RunID: r.ID, Text: g.Text, Fill: o.Paint.FillStyle, X: r.XPx + g.OriginX, Y: r.YPx + g.OriginY, Width: g.Width, Height: g.Height})
		}
		for _, tg := range r.TallyGroups {
			for _, cx := range tg.StrokeCentersPx {
				els = append(els, VectorElement{Kind: "path", RunID: r.ID, Path: fmt.Sprintf("M %.3f %.3f L %.3f %.3f", cx, tg.TopYPx, cx, tg.BottomYPx), Fill: o.Paint.FillStyle})
			}
		}
	}
	return VectorDocument{Width: prep.Plan.Width, Height: prep.Plan.Height, Elements: els, Diagnostics: prep.Plan.Diagnostics, Plan: prep.Plan}, nil
}

func (n *NanpaLinjaN) RenderRunToNewCanvas(run FullRenderRun, options ...FullRenderOptions) (CanvasRenderResult, error) {
	o := DefaultFullRenderOptions()
	if len(options) > 0 {
		o = options[0]
	}
	font, err := n.registry.Get(o.Font)
	if err != nil {
		return CanvasRenderResult{}, err
	}
	var g fullGraphic
	if run.RenderMode == "synthetic-corner-bracket" && len(run.CanonicalCodepoints) == 1 {
		g = syntheticCornerBracketGraphic(o.FontSize, run.CanonicalCodepoints[0])
	} else if run.RenderText != "" {
		var family, path string
		features := []string{}
		switch run.FontRole {
		case "number":
			family = font.NativeCompanionFamily
			path, err = n.materializeFont(font.CompanionFilename)
			features = openTypeFeaturesFor(o.FontSize)
		case "literal":
			support, supportErr := n.registry.supportFont("literalText")
			if supportErr != nil {
				return CanvasRenderResult{}, supportErr
			}
			family = support.Family
			path, err = n.materializeFont(support.Filename)
		default:
			family = nativeBaseFamilies[font.Key]
			path, err = n.materializeFont(font.BaseFilename)
		}
		if err != nil {
			return CanvasRenderResult{}, err
		}
		g, err = n.measureGraphic(run.RenderText, family, path, o.FontSize, features, 0, 0)
		if err != nil {
			return CanvasRenderResult{}, err
		}
		g.TallyGroups = append([]TallyGroup(nil), run.TallyGroups...)
	} else {
		return n.RenderToCanvas(run.SourceText, o)
	}
	rr := run
	rr.XPx = float64(o.PaddingPx)
	rr.YPx = float64(o.PaddingPx)
	rr.WidthPx = g.Width
	rr.HeightPx = g.Height
	prep := preparedFull{Plan: FullRenderPlan{FontKey: font.Key, Width: int(math.Ceil(g.Width + 2*float64(o.PaddingPx))), Height: int(math.Ceil(g.Height + 2*float64(o.PaddingPx))), Runs: []FullRenderRun{rr}}, Placed: []logicalFullRun{{Run: rr, Graphic: g}}}
	b, err := n.renderPreparedFull(prep, o, OutputPNG)
	if err != nil {
		return CanvasRenderResult{}, err
	}
	im, _, err := image.Decode(bytes.NewReader(b))
	return CanvasRenderResult{Image: im, FontKey: font.Key}, err
}
func (n *NanpaLinjaN) RenderTextToNewCanvas(text string, options ...FullRenderOptions) (CanvasRenderResult, error) {
	return n.RenderToCanvas(text, options...)
}
func (n *NanpaLinjaN) RenderTextToCanvas(target draw.Image, x, y int, text string, options ...FullRenderOptions) (draw.Image, error) {
	res, err := n.RenderToCanvas(text, options...)
	if err != nil {
		return target, err
	}
	draw.Draw(target, image.Rect(x, y, x+res.Width(), y+res.Height()), res.Image, res.Image.Bounds().Min, draw.Over)
	return target, nil
}
func ucsurSource(lines [][]int) string {
	ls := make([]string, len(lines))
	for i, line := range lines {
		parts := make([]string, len(line))
		for j, cp := range line {
			parts[j] = fmt.Sprintf("U+%04X", cp)
		}
		ls[i] = strings.Join(parts, " ")
	}
	return strings.Join(ls, "\n")
}
func (n *NanpaLinjaN) RenderUcsurToNewCanvas(lines [][]int, options ...FullRenderOptions) (CanvasRenderResult, error) {
	return n.RenderToCanvas(ucsurSource(lines), options...)
}
func (n *NanpaLinjaN) RenderUcsurToCanvas(target draw.Image, x, y int, lines [][]int, options ...FullRenderOptions) (draw.Image, error) {
	return n.RenderTextToCanvas(target, x, y, ucsurSource(lines), options...)
}
