package nanpa

import (
	"fmt"
	"strings"
)

const productionColon = 0xF199D

func appendScaleMarker(b *strings.Builder, codepoints []int, index int, enabled bool) {
	if !enabled {
		return
	}
	if marker := numericCartoucheScaleMarker(codepoints, index); marker != 0 {
		b.WriteRune(rune(marker))
	}
}

func directProductionCartouche(codepoints []int, scale bool) (string, error) {
	var b strings.Builder
	for i, cp := range codepoints {
		if cp < 0 || cp > 0x10FFFF {
			return "", fmt.Errorf("invalid Unicode scalar U+%X", cp)
		}
		b.WriteRune(rune(cp))
		if i > 0 && i < len(codepoints)-1 {
			appendScaleMarker(&b, codepoints, i, scale)
		}
	}
	return b.String(), nil
}

func legacyProductionCartouche(codepoints []int, adapterID string, scale bool) (string, error) {
	if len(codepoints) < 2 || codepoints[0] != CartoucheStart || codepoints[len(codepoints)-1] != CartoucheEnd {
		return "", fmt.Errorf("%s: numeric render input is not a complete canonical cartouche", adapterID)
	}
	var b strings.Builder
	b.WriteByte('[')
	for i, cp := range codepoints[1 : len(codepoints)-1] {
		index := i + 1
		b.WriteByte('_')
		if cp == productionColon {
			b.WriteByte(':')
		} else {
			word, ok := cpToWord[cp]
			if !ok {
				return "", fmt.Errorf("%s: no legacy numeric encoding for U+%04X", adapterID, cp)
			}
			b.WriteString(word)
		}
		appendScaleMarker(&b, codepoints, index, scale)
	}
	b.WriteByte(']')
	return b.String(), nil
}

func nasinPuProductionCartouche(codepoints []int, scale bool) (string, error) {
	var b strings.Builder
	for i, cp := range codepoints {
		switch cp {
		case 0xF1989, 0xF198A, 0xF198B:
			b.WriteRune(rune(wordToCP["ni"]))
		case 0xF198C:
			b.WriteRune(rune(wordToCP["sewi"]))
		case ColonCodepoint:
			b.WriteByte(':')
		case MiddleDotCodepoint:
			b.WriteByte('.')
		default:
			if cp < 0 || cp > 0x10FFFF {
				return "", fmt.Errorf("invalid Unicode scalar U+%X", cp)
			}
			b.WriteRune(rune(cp))
		}
		if i > 0 && i < len(codepoints)-1 {
			appendScaleMarker(&b, codepoints, i, scale)
		}
	}
	return b.String(), nil
}

func lipamankaNeedsTranslation(codepoints []int, settings map[string]any) bool {
	deterministic := settingBool(settings, "deterministicAlternates", true)
	jaki, ko := wordToCP["jaki"], wordToCP["ko"]
	for _, cp := range codepoints {
		switch cp {
		case ColonCodepoint, MiddleDotCodepoint, TallyCodepoint,
			0xF1989, 0xF198A, 0xF198B, 0xF198C,
			OpenQuoteCodepoint, CloseQuoteCodepoint, 0x3000:
			return true
		}
		if cp == 0xF19A5 || (cp > 0xF19A3 && cp != 0xF19A4 && cp != 0xF19A6) {
			return true
		}
		if deterministic && (cp == jaki || cp == ko) {
			return true
		}
	}
	return false
}

func lipamankaProductionCartouche(codepoints []int, settings map[string]any, scale bool) (string, error) {
	if !lipamankaNeedsTranslation(codepoints, settings) {
		return directProductionCartouche(codepoints, scale)
	}
	if len(codepoints) < 2 || codepoints[0] != CartoucheStart || codepoints[len(codepoints)-1] != CartoucheEnd {
		return directProductionCartouche(codepoints, scale)
	}
	var b strings.Builder
	b.WriteByte('[')
	for i, cp := range codepoints[1 : len(codepoints)-1] {
		index := i + 1
		if i > 0 {
			b.WriteByte(' ')
		}
		switch cp {
		case ColonCodepoint:
			b.WriteByte(':')
		case MiddleDotCodepoint:
			b.WriteByte('.')
		case 0xF1989, 0xF198A, 0xF198B:
			b.WriteString("ni")
		case 0xF198C:
			b.WriteString("sewi")
		default:
			word, ok := cpToWord[cp]
			if !ok {
				b.WriteRune('\uFFFD')
			} else {
				b.WriteString(word)
			}
		}
		appendScaleMarker(&b, codepoints, index, scale)
	}
	b.WriteByte(']')
	return b.String(), nil
}

func adaptProductionCartouche(codepoints []int, adapterID string, adapterSettings, fontSettings map[string]any) (string, bool, error) {
	if adapterID == "" {
		adapterID = "identity"
	}
	scale := vulgarScalingEnabled(fontSettings)
	switch adapterID {
	case "linja-pona-legacy-v1", "linja-sike-legacy-v1":
		text, err := legacyProductionCartouche(codepoints, adapterID, scale)
		return text, true, err
	case "nasin-sitelen-pu-mono-v1":
		text, err := nasinPuProductionCartouche(codepoints, scale)
		return text, false, err
	case "linja-lipamanka-v1":
		text, err := lipamankaProductionCartouche(codepoints, adapterSettings, scale)
		return text, false, err
	default:
		text, err := directProductionCartouche(codepoints, scale)
		return text, false, err
	}
}

func renderCodepointsWithoutScaleMarkers(text string) []int {
	out := []int{}
	for _, r := range text {
		if vulgarScaleMarkers[int(r)] {
			continue
		}
		out = append(out, int(r))
	}
	return out
}

func productionOpenTypeFeatures(fontSize int) []string {
	// Protocol v1.1 carries cartouche scaling in the text stream via inline
	// vulgar-fraction controls. ss12/ss13/ss14 are never selected automatically.
	return []string{"calt", "liga", "ccmp"}
}
