package nanpa

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"reflect"
	"strings"
	"testing"

	productionassets "nanpa-linja-n.com/resources"
)

type v11SmokeExpected struct {
	Caps               *string  `json:"caps"`
	Kind               string   `json:"kind"`
	NumberBase         int      `json:"numberBase"`
	ProperName         string   `json:"properName"`
	UniqueCode         string   `json:"uniqueCode"`
	DisplayValue       string   `json:"displayValue"`
	SemanticKind       *string  `json:"semanticKind"`
	SemanticStartGlyph *string  `json:"semanticStartGlyph"`
	IsDate             bool     `json:"isDate"`
	IsTime             bool     `json:"isTime"`
	NumericMode        string   `json:"numericMode"`
	TpWords            []string `json:"tpWords"`
	AbbreviatedWords   []string `json:"abbreviatedWords"`
}

type v11SmokeCase struct {
	ID      string                 `json:"id"`
	Input   string                 `json:"input"`
	Options map[string]interface{} `json:"options"`
	Result  *v11SmokeExpected      `json:"result"`
}

type v11ProfileDocument struct {
	ProfileVersion        string         `json:"profileVersion"`
	NanpaParserSmokeCases []v11SmokeCase `json:"nanpaParserSmokeCases"`
}

func sha256Bytes(b []byte) string {
	s := sha256.Sum256(b)
	return hex.EncodeToString(s[:])
}

func sha256File(t *testing.T, path string) string {
	t.Helper()
	b, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	return sha256Bytes(b)
}

func applyV11SmokeOverrides(o *Options, m map[string]interface{}) {
	boolOpt := func(key string, dst *bool) {
		if v, ok := m[key].(bool); ok {
			*dst = v
		}
	}
	strOpt := func(key string, dst *string) {
		if v, ok := m[key].(string); ok {
			*dst = v
		}
	}
	boolOpt("relaxedNanpaLinjanParsing", &o.RelaxedNanpaLinjanParsing)
	boolOpt("relaxedNanpaLinjanRendering", &o.RelaxedNanpaLinjanRendering)
	boolOpt("nanpaColonParsing", &o.NanpaColonParsing)
	boolOpt("nanpaColonRendering", &o.NanpaColonRendering)
	boolOpt("enableHexParsing", &o.EnableHexParsing)
	boolOpt("enableBinaryParsing", &o.EnableBinaryParsing)
	boolOpt("enableBinaryRendering", &o.EnableBinaryRendering)
	boolOpt("abbreviateNumericCartouches", &o.AbbreviateNumericCartouches)
	boolOpt("preserveNumericCartoucheBreaksInAbbreviation", &o.PreserveNumericCartoucheBreaksInAbbreviation)
	boolOpt("nasinNanpaPona", &o.NasinNanpaPona)
	strOpt("numericCartoucheStartGlyph", &o.NumericCartoucheStartGlyph)
	strOpt("numericMode", &o.NumericMode)
	strOpt("mode", &o.Mode)
	strOpt("mixedStyle", &o.MixedStyle)
}

func normalizedV11KindBase(r *ParseResult) (string, int) {
	if r == nil {
		return "", 0
	}
	if r.Kind != nil && r.NumberBase != nil {
		return *r.Kind, *r.NumberBase
	}
	return "decimal", 10
}

func TestProtocolV11Profile(t *testing.T) {
	profileBytes, err := os.ReadFile("../protocol/conformance/parser-renderer-profile-v1.1.0.json")
	if err != nil {
		t.Fatal(err)
	}
	var profile v11ProfileDocument
	if err := json.Unmarshal(profileBytes, &profile); err != nil {
		t.Fatal(err)
	}
	if profile.ProfileVersion != "1.1.0" {
		t.Fatalf("profile version = %q", profile.ProfileVersion)
	}
	if ReferenceImplementationVersion != "1.1.0" {
		t.Fatalf("reference version = %q", ReferenceImplementationVersion)
	}

	facade, err := CreateNanpaLinjaN()
	if err != nil {
		t.Fatal(err)
	}
	defer facade.Close()

	t.Run("authority-hashes", func(t *testing.T) {
		if got := sha256File(t, "../reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js"); got != "fdeb3e3bfd46b9f86650fd411a2d1dfb2515580aa258aa8c11a002913631418c" {
			t.Fatalf("canonical JS hash = %s", got)
		}
		if got := sha256File(t, "../resources/fonts.zip"); got != "08d0409e0b180a6b90a0617fe557fd3e59a08dd26781d907ed5d772a9fefcae1" {
			t.Fatalf("fonts.zip hash = %s", got)
		}
		manifest, err := productionassets.Manifest()
		if err != nil {
			t.Fatal(err)
		}
		if got := sha256Bytes(manifest); got != "50b8a4b6cab0c27f2061f94e404a2af992cbf95c8097c58caa5e6b2dc4625f09" {
			t.Fatalf("production manifest hash = %s", got)
		}
	})

	t.Run("public-defaults", func(t *testing.T) {
		o := DefaultProductionOptions()
		if o.normalizedMode() != "uniform" || !o.RelaxedNanpaLinjanParsing || !o.RelaxedNanpaLinjanRendering || !o.NanpaColonParsing || !o.NanpaColonRendering || !o.AbbreviateNumericCartouches || o.PreserveNumericCartoucheBreaksInAbbreviation || o.EnableHexParsing || o.EnableBinaryParsing || o.EnableBinaryRendering || o.NasinNanpaPona || o.NumericCartoucheStartGlyph != "" {
			t.Fatalf("unexpected production defaults: %+v", o)
		}
		p := DefaultFullParserOptions()
		if p.NumericMode != "uniform" || !p.RelaxedNanpaLinjanParsing || !p.RelaxedNanpaLinjanRendering || !p.NanpaColonParsing || !p.NanpaColonRendering || !p.AbbreviateNumericCartouches || p.PreserveNumericCartoucheBreaks || p.BreakLinesAtFullStops || p.InterpretDoubleQuotesAsTeTo || p.EnableHexParsing || p.EnableBinaryParsing || p.EnableBinaryRendering || p.NasinNanpaPona || p.NumericCartoucheStartGlyph != "" {
			t.Fatalf("unexpected full parser defaults: %+v", p)
		}
	})

	t.Run("production-font-profile", func(t *testing.T) {
		r, err := loadProductionFontRegistry()
		if err != nil {
			t.Fatal(err)
		}
		fonts := r.List()
		if len(fonts) != 8 {
			t.Fatalf("font pairs = %d, want 8", len(fonts))
		}
		wantAdapters := map[string]bool{
			"identity": true, "linja-pona-legacy-v1": true, "linja-sike-legacy-v1": true,
			"nasin-sitelen-pu-mono-v1": true, "linja-lipamanka-v1": true,
		}
		seen := map[string]bool{}
		for _, f := range fonts {
			if f.ParserMode != "sitelen-pona-ascii-extended" {
				t.Errorf("%s parser mode = %q", f.Key, f.ParserMode)
			}
			if f.Settings["cartoucheVulgarFractions"] != true {
				t.Errorf("%s cartoucheVulgarFractions not true", f.Key)
			}
			if f.Settings["emulateLegacyCartoucheScaling"] != false {
				t.Errorf("%s emulateLegacyCartoucheScaling not false", f.Key)
			}
			seen[f.RenderAdapterID] = true
		}
		if !reflect.DeepEqual(seen, wantAdapters) {
			t.Fatalf("adapter inventory = %#v want %#v", seen, wantAdapters)
		}
		for _, px := range []int{12, 18, 29, 56} {
			for _, feature := range productionOpenTypeFeatures(px) {
				if feature == "ss12" || feature == "ss13" || feature == "ss14" {
					t.Fatalf("legacy stylistic set active at %dpx: %s", px, feature)
				}
			}
		}
	})

	if len(profile.NanpaParserSmokeCases) != 16 {
		t.Fatalf("smoke cases = %d, want 16", len(profile.NanpaParserSmokeCases))
	}
	for _, tc := range profile.NanpaParserSmokeCases {
		tc := tc
		t.Run("smoke-"+tc.ID, func(t *testing.T) {
			o := DefaultProductionOptions()
			applyV11SmokeOverrides(&o, tc.Options)
			got, _ := facade.ParseNumber(tc.Input, o)
			if tc.Result == nil {
				if got != nil {
					t.Fatalf("got parse result %+v, want nil", got)
				}
				return
			}
			if got == nil {
				t.Fatal("got nil parse result")
			}
			kind, base := normalizedV11KindBase(got)
			if kind != tc.Result.Kind || base != tc.Result.NumberBase || !reflect.DeepEqual(got.Caps, tc.Result.Caps) || got.ProperName != tc.Result.ProperName || got.UniqueCode != tc.Result.UniqueCode || got.DisplayValue != tc.Result.DisplayValue || !reflect.DeepEqual(got.SemanticKind, tc.Result.SemanticKind) || !reflect.DeepEqual(got.SemanticStartGlyph, tc.Result.SemanticStartGlyph) || got.IsDate != tc.Result.IsDate || got.IsTime != tc.Result.IsTime || got.NumericMode != tc.Result.NumericMode || !reflect.DeepEqual(got.TpWords, tc.Result.TpWords) {
				t.Fatalf("result mismatch\n got=%+v\nwant=%+v", got, *tc.Result)
			}
			var gotAbbr []string
			if kind == "hex" || kind == "binary" {
				gotAbbr = got.AbbreviatedWords
			}
			if !reflect.DeepEqual(gotAbbr, tc.Result.AbbreviatedWords) {
				t.Fatalf("abbreviatedWords = %#v want %#v", gotAbbr, tc.Result.AbbreviatedWords)
			}
		})
	}
}

func TestProtocolV11CartoucheScalingAndVectorOutput(t *testing.T) {
	n, err := CreateNanpaLinjaN()
	if err != nil {
		t.Fatal(err)
	}
	defer n.Close()

	o := DefaultFullRenderOptions()
	o.Font = "nasinNanpa"
	o.Parser.AbbreviateNumericCartouches = false
	plan, err := n.BuildFullRenderPlan("[jan½ pona] [jan1/2 pona] [jan 1/3 pona] 123.45", o)
	if err != nil {
		t.Fatal(err)
	}
	var texts []string
	for _, line := range plan.Lines {
		for _, run := range line.Runs {
			texts = append(texts, run.RenderText)
		}
	}
	joined := strings.Join(texts, "\n")
	for _, marker := range []string{"½", "⅓", "¼", "⅔"} {
		if !strings.Contains(joined, marker) {
			t.Fatalf("render plan is missing inline scale marker %q: %q", marker, joined)
		}
	}

	svg, err := n.RenderFullToSVG("123.45", o)
	if err != nil {
		t.Fatal(err)
	}
	svgText := string(svg)
	if !strings.Contains(svgText, "<path") || strings.Contains(svgText, "<image") || strings.Contains(svgText, "data:image") {
		t.Fatal("numeric SVG must contain vector paths and no raster image fallback")
	}
	pdf, err := n.RenderFullToPDF("123.45", o)
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(string(pdf), "/Subtype /Image") {
		t.Fatal("numeric PDF contains a raster Image XObject")
	}
}
