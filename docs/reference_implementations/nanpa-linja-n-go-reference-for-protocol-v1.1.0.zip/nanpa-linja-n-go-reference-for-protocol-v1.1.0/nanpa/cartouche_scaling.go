package nanpa

// Protocol v1.1 cartouche scaling controls are font-facing postfix characters.
// They are not semantic code points in the canonical parser output.
const (
	VulgarScaleQuarter       = 0x00BC // ¼
	VulgarScaleThird         = 0x2153 // ⅓
	VulgarScaleHalf          = 0x00BD // ½
	VulgarScaleTwoThirds     = 0x2154 // ⅔
	VulgarScaleThreeQuarters = 0x00BE // ¾
)

var vulgarScaleMarkers = map[int]bool{
	VulgarScaleQuarter: true, VulgarScaleThird: true, VulgarScaleHalf: true,
	VulgarScaleTwoThirds: true, VulgarScaleThreeQuarters: true,
}

var asciiScaleAliases = map[string]int{
	"1/4": VulgarScaleQuarter,
	"1/3": VulgarScaleThird,
	"1/2": VulgarScaleHalf,
	"2/3": VulgarScaleTwoThirds,
	"3/4": VulgarScaleThreeQuarters,
}

func vulgarScalingEnabled(settings map[string]any) bool {
	return settingBool(settings, "cartoucheVulgarFractions", false) || settingBool(settings, "emulateLegacyCartoucheScaling", false)
}

func numericCartoucheScaleMarker(cps []int, index int) int {
	if index <= 0 || index >= len(cps)-1 {
		return 0
	}
	cp := cps[index]
	first := 1
	last := len(cps) - 2
	halfHeads := map[int]bool{
		wordToCP["nanpa"]: true, wordToCP["nasa"]: true, wordToCP["noka"]: true,
		wordToCP["tenpo"]: true, wordToCP["suno"]: true, wordToCP["toki"]: true,
	}
	halfClosers := map[int]bool{wordToCP["nanpa"]: true, wordToCP["nasa"]: true, wordToCP["noka"]: true}
	if index == first && halfHeads[cp] {
		return VulgarScaleHalf
	}
	if index == first+1 && cp == ColonCodepoint && halfHeads[cps[first]] {
		return VulgarScaleHalf
	}
	if index == last && halfClosers[cp] {
		return VulgarScaleHalf
	}
	// Leading explicit-positive "en" in [head : nena en ...] or [head en ...].
	if cp == wordToCP["en"] && len(cps) >= 4 && halfHeads[cps[first]] {
		if index == first+1 ||
			(index == first+2 && cps[first+1] == ColonCodepoint) ||
			(index == first+3 && cps[first+2] == wordToCP["nena"] && (cps[first+1] == wordToCP["e"] || cps[first+1] == ColonCodepoint)) {
			return VulgarScaleTwoThirds
		}
	}
	if w, ok := cpToWord[cp]; ok && len(w) > 0 && (w[0] == 'e' || w[0] == 'n') {
		letters := true
		for _, r := range w {
			if r < 'a' || r > 'z' {
				letters = false
				break
			}
		}
		if letters {
			return VulgarScaleQuarter
		}
	}
	switch cp {
	case wordToCP["ala"], wordToCP["ike"], wordToCP["uta"], wordToCP["open"]:
		return VulgarScaleQuarter
	case wordToCP["kasi"], wordToCP["kule"]:
		return VulgarScaleThird
	case wordToCP["kala"]:
		return VulgarScaleHalf
	case wordToCP["ona"], wordToCP["o"], wordToCP["kulupu"], wordToCP["kipisi"], wordToCP["kin"]:
		return VulgarScaleTwoThirds
	}
	return 0
}
