# nanpa-linja-n Go reference — Protocol v1.1.0

This release updates the native Go reference from Protocol v1.0.0 to Protocol v1.1.0 while retaining the frozen Core-v1 implementation unchanged.

The production facade now follows v1.1 defaults, including opt-in hexadecimal/binary parsing and abbreviated numeric cartouches by default. The current eight-font production bundle and render adapters are embedded. Legacy automatic ss12/ss13/ss14 scaling is disabled; cartouche scaling uses the current inline vulgar-fraction controls.

The public production facade exposes `renderer.ParseNumber(...)` with v1.1 defaults and profile-normalized output. The package-level `nanpa.ParseNumber(input, opts)` remains the frozen Core-v1 binding for compatibility.

Qualification includes the unchanged 1030-check Core corpus, 16/16 v1.1 parser smoke cases, 128/128 production render plans, 128/128 native production renders, 254/254 full-renderer cases, current production font/tally profiles, and vector SVG/PDF requirements.
