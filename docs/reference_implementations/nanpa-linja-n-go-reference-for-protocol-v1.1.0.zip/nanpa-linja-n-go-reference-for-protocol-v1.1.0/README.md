# nanpa-linja-n Go reference implementation

Native Go reference implementation for **nanpa-linja-n Protocol v1.1.0**.

The release layers the Protocol-v1.1 parser/renderer and production-font profiles on top of the unchanged frozen Core-v1 implementation. The seven historical Core source files remain hash-pinned and unchanged; v1.1 behavior that differs at the production/profile boundary is implemented in the facade and full renderer.

Reference implementation version: **1.1.0**.

## Requirements

- Go **1.18 or newer**
- Linux production rendering uses cgo plus the system Cairo, Pango/HarfBuzz and Fontconfig libraries
- no third-party Go modules are required

The native renderer dynamically loads the Linux graphics/text stack at runtime.

## Protocol v1.1 defaults

The production facade and full renderer default to:

- numeric mode: `uniform`
- relaxed parsing: enabled
- relaxed rendering: enabled
- Nanpa-format colon parsing/rendering: enabled
- abbreviated numeric cartouches: enabled
- preservation of abbreviation break markers: disabled
- hexadecimal parsing: disabled unless explicitly enabled
- binary parsing/rendering: disabled unless explicitly enabled
- `nasinNanpaPona`: disabled
- double quotes as `te` / `to`: disabled
- line breaking at full stops: disabled
- numeric cartouche start-glyph override: none

The frozen package-level Core function `nanpa.ParseNumber(input, opts)` remains available for Core-v1 compatibility. For the Protocol-v1.1 production facade, use `renderer.ParseNumber(...)` or `renderer.Parse(...)`.

## Production fonts

`resources/fonts.zip` is the supplied Protocol-v1.1 production-font archive and is embedded directly into the Go module.

The manifest defines eight production font pairs:

- `nasinNanpa`
- `sitelenSeliKiwen`
- `fairfaxHd`
- `fairfaxPonaHd`
- `linjaPona`
- `linjaSike`
- `nasinSitelenPuMono`
- `linjaLipamanka`

Built-in render adapters are:

- `identity`
- `linja-pona-legacy-v1`
- `linja-sike-legacy-v1`
- `nasin-sitelen-pu-mono-v1`
- `linja-lipamanka-v1`

All eight production profiles opt into `cartoucheVulgarFractions`. Automatic legacy OpenType `ss12`, `ss13`, and `ss14` selection is **not used** in Protocol v1.1.0.

Numeric cartouche scaling and explicit ordinary-cartouche scaling use inline postfix controls:

```text
¼  ⅓  ½  ⅔  ¾
```

Approved ASCII aliases such as `1/2`, `1/3`, `1/4`, `2/3`, and `3/4` are accepted in ordinary cartouches and are normalized to the corresponding inline scale control.

## Quick production API

```go
package main

import (
    "fmt"
    "os"

    nanpa "nanpa-linja-n.com/nanpa"
)

func main() {
    renderer, err := nanpa.CreateNanpaLinjaN()
    if err != nil {
        panic(err)
    }
    defer renderer.Close()

    parsed, err := renderer.ParseNumber("123")
    if err != nil {
        panic(err)
    }
    fmt.Println(parsed.ProperName)

    opts := nanpa.DefaultRenderOptions()
    opts.Font = "linjaPona"
    png, err := renderer.RenderToPNG("123.45", opts)
    if err != nil {
        panic(err)
    }
    if err := os.WriteFile("number.png", png, 0644); err != nil {
        panic(err)
    }

    // Hexadecimal and binary are opt-in in v1.1.0.
    hexOpts := nanpa.DefaultRenderOptions()
    hexOpts.ParserOptions.EnableHexParsing = true
    svg, err := renderer.RenderToSVG("#ABCDEF", hexOpts)
    if err != nil {
        panic(err)
    }
    _ = os.WriteFile("hex.svg", svg, 0644)
}
```

## Full renderer API

```go
opts := nanpa.DefaultFullRenderOptions()
opts.Font = "linjaPona"
opts.FontSize = 56

plan, err := renderer.BuildFullRenderPlan(
    `mi toki e ni: [jan pona,,] 123.45 "Hello"`,
    opts,
)
if err != nil { panic(err) }

png, _ := renderer.RenderFullToPNG(`jan [pona,,] 123.45`, opts)
svg, _ := renderer.RenderFullToSVG(`jan [pona,,] 123.45`, opts)
pdf, _ := renderer.RenderFullToPDF(`jan [pona,,] 123.45`, opts)

_, _, _, _ = plan, png, svg, pdf
```

Full-renderer methods include `ParseInput`, `AstToText`, `BuildFullRenderPlan`, `RenderFull`, `RenderToCanvas`, PNG/SVG/PDF exports, low-level run/text/UCSUR rendering, runtime render-adapter registration, and vector-document output.

Go cannot overload the existing numeric `BuildRenderPlan`/`RenderToPNG` methods by option type, so full-document operations use explicit `Full` names.

## Parser/profile notes

### Hexadecimal and binary

Hexadecimal and binary are still fully supported, but they are opt-in:

```go
opts := nanpa.DefaultProductionOptions()
opts.EnableHexParsing = true
hex, err := renderer.ParseNumber("#ABCDEF", opts)

opts = nanpa.DefaultProductionOptions()
opts.EnableBinaryParsing = true
bin, err := renderer.ParseNumber("0b10101", opts)

_, _, _, _ = hex, bin, err, opts
```

### Yearless dates

The accepted yearless numeric form is:

```text
--MM-DD
```

For example `--02-29` is valid. Bare `02-29` is not classified as a yearless date.

The frozen Core representation historically uses `kulupu` for the date separator. The Protocol-v1.1 production facade exposes the current `kasi` representation without modifying the frozen Core source files.

### Numeric whitespace

Whitespace terminates a digit-based numeric construct. Examples:

```text
1 2 3    -> three numbers
1 1/2    -> two numbers
1+1/2    -> one mixed fraction
```

This rule does not remove the intentional spaces used by numeric proper names or numeric cartouches.

### Punctuation

Outside cartouches, ASCII comma U+002C remains an ordinary comma rendered through the word-font path. It is not converted into a tally mark. Inside cartouches, comma behavior follows the selected font profile's tally mode.

## Conformance and regression coverage

The release qualifies:

- frozen Core-v1 protocol corpus: **1030 checks**
- frozen Core source integrity: **7/7 unchanged**
- frozen public Core API surface: **35/35 operations**
- Protocol-v1.1 `parseNumber` smoke cases: **16/16**
- production font pairs: **8/8**
- production render-plan matrix: **128/128**
- native production rendering matrix: **128/128**
- canonical full-renderer semantic corpus: **254/254**
- canonical syntax cases: **28/28**
- production render-adapter checks: **5/5**
- manual-tally production fonts: **4/4**
- UCSUR-tally production fonts: **4/4**
- `AstToText` regression: **8/8**, plus rendering integration
- vector SVG qualification: real vector paths, no `<image>` / `data:image` fallback
- vector PDF qualification: no raster `/Subtype /Image` XObject for generated numeric content
- `go vet`
- no-cgo frozen Core/logical qualification

The canonical JavaScript authority is bundled under `reference/`, and the current branch-oriented renderer corpus is under:

```text
conformance/full-renderer-canonical-v1.1.0/cases.json
```

## Run the complete regression

```bash
./tools/run_go_regression.sh
```

The runner is deliberately non-fail-fast. All configured groups are attempted and the consolidated report is written to:

```text
test-output/go-regression-report.txt
```

You can also run the Go suite directly:

```bash
go test ./... -count=1
go vet ./...
```

The main regression runner additionally performs a no-cgo Core/logical qualification pass.

## Vector-output quality

Protocol-v1.1 qualification requires numeric SVG output to remain genuine vector content. The tests require SVG `<path>` geometry and reject raster `<image>` and `data:image` fallback.

Numeric PDF output is likewise required to remain resolution-independent. The tests reject `/Subtype /Image` raster XObjects for generated cartouche content.

PNG output is intentionally raster.

## Visual audit exporters

The existing native visual-audit tooling remains available under `tools/` and `cmd/visual-audit/`. Generated visual files belong under `test-output/` and are not part of the release ZIP.

## CLI

The Core-oriented command is retained:

```bash
go run ./cmd/nanpa-linja-n parse '12:30'
go run ./cmd/nanpa-linja-n parse '--02-29'
go run ./cmd/nanpa-linja-n encode '123.456'
go run ./cmd/nanpa-linja-n decode 'NEWETESEN'
```

The CLI preserves the historical Core command behavior. Production-profile rendering and profile-normalized parsing are exposed by the `NanpaLinjaN` facade.

## Repository layout

```text
nanpa-linja-n-go-reference-for-protocol-v1.1.0/
├── conformance/
│   └── full-renderer-canonical-v1.1.0/
├── protocol/
│   ├── API.md
│   ├── PARSER-RENDERER-PROFILE.md
│   ├── protocol.json
│   └── conformance/
├── reference/
│   └── renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js
├── resources/
│   ├── embed.go
│   └── fonts.zip
├── cmd/
├── nanpa/
├── testdata/
│   ├── nanpa-linja-n-regression-v1.0.2.json
│   ├── core-source-sha256-v1.0.0.json
│   └── production/
├── tools/
├── go.mod
├── README.md
├── TESTING.md
├── RELEASE_NOTES.md
└── CHANGELOG.md
```

## Authority hashes

```text
canonical JavaScript
fdeb3e3bfd46b9f86650fd411a2d1dfb2515580aa258aa8c11a002913631418c

resources/fonts.zip
08d0409e0b180a6b90a0617fe557fd3e59a08dd26781d907ed5d772a9fefcae1

Parser/Renderer Profile v1.1
009ecab501a57c1b64fd1ff1f9fac50b072aecb706a162970b1f17c0cc45338b

Production font manifest
50b8a4b6cab0c27f2061f94e404a2af992cbf95c8097c58caa5e6b2dc4625f09

Frozen Core corpus
e4baf51251861c114f5314fc2af05eb44e1b5dbcbdebdcd2678c868f5dbf306a
```

## Reference status

Protocol v1.1.0 is the release target. Core-v1 remains frozen and is tested as the unchanged compatibility foundation; the v1.1 parser/renderer and production-font profiles are additive qualification layers implemented natively in Go.
