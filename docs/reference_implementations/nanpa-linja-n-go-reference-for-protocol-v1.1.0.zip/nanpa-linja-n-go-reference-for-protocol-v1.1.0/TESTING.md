# Testing the Go reference

Requirements: Go 1.18+; Linux native rendering requires cgo and the Cairo/Pango/HarfBuzz/Fontconfig runtime libraries.

Run the complete non-fail-fast qualification:

```bash
./tools/run_go_regression.sh
```

The consolidated report is written to:

```text
test-output/go-regression-report.txt
```

The runner performs four groups:

1. frozen Core corpus SHA-256 integrity;
2. all Go tests with native/cgo rendering;
3. `go vet ./...`;
4. no-cgo frozen Core/logical qualification.

Direct commands:

```bash
go test ./... -count=1
go vet ./...
CGO_ENABLED=0 go test ./nanpa -run '^(TestFrozenAPISurface35|TestNumericWhitespaceBaseline|TestAstToTextRegression|TestAstToTextNumericBaseline|TestParserConformance|TestRendererConformance|TestAPICases|TestEquivalenceGroups|TestProductionFacadePlanConformance128|TestFrozenCoreSourceHashesUnchanged|TestProductionFontAssetsHashes|TestProtocolV11Profile)$' -count=1
```

Key expected results include Core 1030 checks, v1.1 parser smoke 16/16, production plans 128/128, native production renders 128/128, canonical renderer 254/254, syntax 28/28, adapters 5/5, four manual-tally fonts plus four UCSUR-tally fonts, and vector-only SVG/PDF qualification.

Do not modify or regenerate frozen Core fixtures or production goldens merely to make a failure disappear. Changes to an oracle require an intentional authority update and independent verification.
