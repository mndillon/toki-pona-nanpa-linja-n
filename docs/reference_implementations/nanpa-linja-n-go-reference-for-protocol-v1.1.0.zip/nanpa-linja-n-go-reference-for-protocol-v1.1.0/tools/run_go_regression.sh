#!/usr/bin/env bash
# Complete Go regression runner.
#
# IMPORTANT: this runner is deliberately non-fail-fast. Every configured test
# group is attempted even when an earlier group fails. A single consolidated
# report is written so all observed failures can be repaired in one pass.
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CORPUS="$ROOT/testdata/nanpa-linja-n-regression-v1.0.2.json"
EXPECTED_SHA="e4baf51251861c114f5314fc2af05eb44e1b5dbcbdebdcd2678c868f5dbf306a"
REPORT="${GO_REGRESSION_REPORT:-$ROOT/test-output/go-regression-report.txt}"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$(dirname "$REPORT")"
: > "$REPORT"

TOTAL_GROUPS=0
FAILED_GROUPS=0
PASSED_GROUPS=0
FAIL_SUMMARY="$TMP/failures.txt"
: > "$FAIL_SUMMARY"

append() {
  printf '%s\n' "$*" | tee -a "$REPORT"
}

run_group() {
  local name="$1"
  shift
  local slug
  slug="$(printf '%s' "$name" | tr ' /:' '___' | tr -cd '[:alnum:]_.-')"
  local log="$TMP/${slug}.log"
  local status

  TOTAL_GROUPS=$((TOTAL_GROUPS + 1))
  append ""
  append "==============================================================================="
  append "GROUP $TOTAL_GROUPS: $name"
  append "==============================================================================="
  append "COMMAND: $*"

  (
    cd "$ROOT" || exit 125
    export TERM="dumb"
    "$@"
  ) >"$log" 2>&1
  status=$?

  cat "$log" | tee -a "$REPORT"
  if [[ $status -eq 0 ]]; then
    PASSED_GROUPS=$((PASSED_GROUPS + 1))
    append "GROUP RESULT: PASS ($name)"
  else
    FAILED_GROUPS=$((FAILED_GROUPS + 1))
    append "GROUP RESULT: FAIL ($name; exit=$status)"
    {
      echo "[$name] exit=$status"
      # Go test subtests / top-level tests.
      grep -E -- '^--- FAIL:|^[[:space:]]+--- FAIL:' "$log" || true
      # Compiler/vet diagnostics and explicit mismatch/error messages.
      grep -E -- '(^# |undefined:|cannot use |syntax error|mismatch|ERROR|Error:|FAIL[[:space:]]*$)' "$log" || true
      echo
    } >> "$FAIL_SUMMARY"
  fi
  return 0
}

append "nanpa-linja-n Go reference complete regression"
append "=============================================="
append "Started: $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
append "Root: $ROOT"
append "Go toolchain: $(go version 2>&1)"
append "Report: $REPORT"
append "Policy: NON-FAIL-FAST — all configured groups are attempted."

# Integrity checks are a group too: a bad corpus must be reported, but must not
# prevent compilation/vet/other tests from running and reporting their results.
run_group "Frozen protocol corpus integrity" bash -c '
  set -u
  corpus="$1"; expected="$2"
  if [[ ! -f "$corpus" ]]; then
    echo "missing frozen corpus: $corpus" >&2
    exit 1
  fi
  actual="$(sha256sum "$corpus")"
  actual="${actual%% *}"
  echo "expected: $expected"
  echo "actual:   $actual"
  [[ "$actual" == "$expected" ]]
' bash "$CORPUS" "$EXPECTED_SHA"

# One ordinary go test invocation executes every current and future package test.
# The Go testing framework itself continues with other top-level tests/subtests
# after assertion failures, which makes this the primary comprehensive failure
# inventory.
run_group "All Go tests (native/cgo)" go test ./... -count=1 -v

# Static analysis is intentionally run even if tests fail.
run_group "go vet" go vet ./...

# No-cgo qualification is limited to the frozen Core and logical production
# facade. Full-document graphical planning measures native fonts and therefore
# intentionally requires the Linux native renderer.
NO_CGO_RE='^(TestFrozenAPISurface35|TestNumericWhitespaceBaseline|TestAstToTextRegression|TestAstToTextNumericBaseline|TestParserConformance|TestRendererConformance|TestAPICases|TestEquivalenceGroups|TestProductionFacadePlanConformance128|TestFrozenCoreSourceHashesUnchanged|TestProductionFontAssetsHashes|TestProtocolV11Profile)$'
run_group "No-cgo Core/logical regression" env CGO_ENABLED=0 go test ./nanpa -run "$NO_CGO_RE" -count=1 -v

append ""
append "==============================================================================="
append "CONSOLIDATED RESULT"
append "==============================================================================="
append "Groups attempted: $TOTAL_GROUPS"
append "Groups passed:    $PASSED_GROUPS"
append "Groups failed:    $FAILED_GROUPS"

if [[ $FAILED_GROUPS -eq 0 ]]; then
  append ""
  append "Observed qualification summary:"
  append "  frozen Core-v1 protocol checks: 1030; failures: 0"
  append "  frozen Core source integrity: 7/7 unchanged"
  append "  Protocol v1.1 NanpaParser smoke cases: 16/16"
  append "  production font pairs: 8/8; inline cartouche scaling enabled"
  append "  production render-plan conformance: 128/128"
  append "  production native render matrix: 128/128"
  append "  canonical full-renderer branch corpus: 254/254"
  append "  canonical syntax cases: 28/28; production adapters: 5/5"
  append "  manual-tally production fonts: 4/4; UCSUR tally fonts: 4/4"
  append "  AstToText regression/integration: PASS"
  append "  SVG numeric output: vector paths only; PDF numeric output: no raster Image XObject"
  append "  legacy automatic ss12/ss13/ss14 selection: disabled"
  append "  go vet: PASS"
  append "  no-cgo frozen Core/logical facade: PASS"
  append ""
  append "FINAL RESULT: PASS — ALL CONFIGURED GO REFERENCE TEST GROUPS PASSED"
else
  append ""
  append "Failure index (all failed groups/cases found during this run):"
  cat "$FAIL_SUMMARY" | tee -a "$REPORT"
  append "FINAL RESULT: FAIL — see the complete group logs above; no later group was skipped because of an earlier test failure."
fi

append "Finished: $(date -u '+%Y-%m-%dT%H:%M:%SZ')"

# Keep normal CI semantics while still completing every group first.
if [[ $FAILED_GROUPS -ne 0 ]]; then
  exit 1
fi
exit 0
