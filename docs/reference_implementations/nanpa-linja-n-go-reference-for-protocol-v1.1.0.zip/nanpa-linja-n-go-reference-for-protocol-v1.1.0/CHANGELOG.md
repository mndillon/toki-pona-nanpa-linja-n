# Changelog

## 1.1.0 — Protocol v1.1.0

- Updated the native Go reference to Protocol v1.1.0 while preserving all seven hash-pinned Core-v1 source files unchanged.
- Updated public production defaults: relaxed/Nanpa-format behavior and abbreviated numeric cartouches are enabled; hexadecimal and binary are opt-in.
- Added the Protocol-v1.1 production-facade `ParseNumber` operation with current date-separator normalization while retaining the package-level frozen Core `ParseNumber` binding.
- Updated to the exact supplied v1.1 `fonts.zip` and eight-font production manifest.
- Added all current production render adapters and per-font settings.
- Replaced automatic ss12/ss13/ss14 cartouche scaling with inline `¼`, `⅓`, `½`, `⅔`, `¾` controls and ordinary-cartouche ASCII aliases.
- Updated outside-cartouche U+002C handling so comma remains an ordinary word-font run.
- Replaced the active full-renderer corpus with the v1.1.0 254-case corpus and regenerated the 128-case production plan oracle.
- Added Protocol-v1.1 authority/default/font-profile/16-case parser smoke qualification and vector-only SVG/PDF checks.
- Updated native font families and current manual/UCSUR tally-font sets.
- Removed obsolete active v1.0 candidate-profile tests and stale v1.0 production goldens.

## 2026-09-21 — Current JavaScript baseline parity

- Ported the current JavaScript rule that internal whitespace terminates digit-based decimal, fraction, scientific, percent, date, and time input.
- `ParseNumber` and `EncodeDecimal` now reject whitespace-bearing digit expressions such as `12 34`, `12 %`, `1 e8`, `1 /2`, and the obsolete spaced mixed fraction `1 1/2`; valid mixed fractions continue to use `+`, for example `1+1/2`. Numeric proper names and numeric cartouches retain their intentional spaces.
- Updated `ParseNumber` alternative-output metadata for decimal values (`abbreviatedWords`, abbreviated code points, and `nasinNanpaPonaWords` when requested).
- Updated `ParseInput` ASTs with numeric-span metadata and extended `AstToText` with `NumericOutput` modes `source`, `properName`, `#~`, and `cartouche`, including abbreviation, nasin nanpa pona precedence, stale-metadata protection, and raw-UCSUR serialization/validation.
- Updated the bundled canonical JavaScript authority, the canonical mixed-space renderer oracle, and the protocol regression corpus from 311 to 320 parser cases / 1,030 checks.
- Added focused Go baseline regressions. No unrelated rendering or parser behavior was changed.

## 0.4.0 — Canonical full-renderer parser/syntax parity

- Added a 254-case branch-oriented semantic corpus generated directly from the bundled, SHA-pinned canonical JavaScript renderer.
- Implemented missing full-renderer syntax and precedence across Standard Core, Extended, and sitelen seli kiwen modes, including `&` ZWJ compounds, `-` stack compounds, `+` nest compounds, chains/mixed compounds, `te`/`to`/`zz`, long-glyph forms, early aliases, raw `U+...`, and cartouche variants.
- Added the canonical whole-text numeric scanner so mixed prose can recognize and prioritize decimal/fraction/scientific/date/time/telephone/hex/binary/Toki Pona numeric spans without reducing parsing to whitespace-separated tokens.
- Added explicit `EnableBinaryRendering` to the additive full-renderer parser options and qualified binary parsing/rendering option interactions with real `0b...` cases.
- Corrected numeric bracket precedence, TP numeric phrase handling, positive-marker rendering, quote semantics, unknown/literal roles, raw UCSUR adapter bypass, and production word-adapter application.
- Corrected linja Lipamanka long-glyph adapter routing to match the canonical renderer.
- Preserved the seven frozen Core-v1 source files unchanged; full-renderer compatibility logic remains additive.
- Reworked `tools/run_go_regression.sh` to be non-fail-fast: every configured group runs, all output is collected, and one consolidated `test-output/go-regression-report.txt` is produced before the final exit status is returned.
- Full configured regression passes, including the 1,017 frozen Protocol checks, 128/128 production plans, 128/128 production native renders, legacy Full Renderer Profile, 254/254 canonical semantic cases, `go vet`, and no-cgo frozen Core/logical qualification.

## 0.3.0 — Full Renderer Profile v1.0.0-candidate

- Added a native Go full-document renderer alongside the unchanged frozen Core-v1/numeric production facade.
- Added document parsing, ordinary cartouches, literal/unknown text, multiline layout, inline images, Canvas-equivalent rendering, PNG/SVG/PDF, vector documents, and low-level run/text/UCSUR operations.
- Added runtime render-adapter registration.
- Added canonical browser semantic qualification: 64 parity cases, 20 operation checks, 9 vector cases, and 38 feature areas.
- Added exact-font-file Pango/Fontconfig layout isolation for full rendering so companion font registration cannot alter base-font selection.
- Fixed manual tally placement for the five manual-tally production fonts. U+F199E is excluded from manual font runs and synthetic tallies derive from the complete shaped owner-glyph span.
- Preserved all existing 1,017 frozen Protocol checks, 128/128 production render-plan checks, and 128/128 existing native production render cases.
- Added 72-image `test-output` visual audit exporters.
