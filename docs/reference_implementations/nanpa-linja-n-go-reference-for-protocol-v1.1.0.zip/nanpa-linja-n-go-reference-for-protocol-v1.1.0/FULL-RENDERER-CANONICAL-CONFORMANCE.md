# Canonical full-renderer conformance

The Go full-renderer binding is checked against the bundled canonical JavaScript renderer:

```text
reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js
SHA-256: fdeb3e3bfd46b9f86650fd411a2d1dfb2515580aa258aa8c11a002913631418c
```

The active Protocol-v1.1 oracle is:

```text
conformance/full-renderer-canonical-v1.1.0/cases.json
```

It contains **254 branch-oriented semantic cases** generated from the canonical renderer. The Go test compares AST structure and semantic render runs, including canonical codepoints, full cartouche codepoints, adapted render codepoints, run kind/role, source text/kind, quote/unknown flags, numeric-cartouche classification, manual tallies, image metadata, and production adapter routing.

## Coverage inventory

| Case family | Cases | Main coverage |
| --- | ---: | --- |
| bracket | 43 | ordinary/numeric/literal/legacy/compound/tally cartouches, typed heads, option-off fallbacks, TP numeric phrases |
| numeric | 43 | decimal, sign, percent, fractions, vulgar fractions, scientific, magnitude, grouping, time/date, number code, telephone, hex, binary, abbreviation and parser/render switches |
| adapter | 40 | all 8 production fonts × word/compound/long/cartouche/raw-UCSUR behavior |
| extended | 19 | Extended compounds, long glyphs and legacy long-`pi` syntax |
| ssk | 19 | sitelen seli kiwen compounds/long glyphs and legacy exclusions |
| core | 19 | Standard Core compounds, `pi(...)`, `|`, exclusions and alias behavior |
| early-alias | 10 | every early text alias substitution |
| core-alias-excluded | 10 | Standard Core exclusion behavior for those aliases |
| scanner | 9 | whole-text mixed-prose numeric span detection, overlap and precedence |
| quote | 7 | straight/curly/literal/interpreted quotes, compound/numeric/unknown content |
| alias-glyph | 6 | `ni01`–`ni04`, `sewi01`, `sewi02` |
| raw | 6 | raw `U+...` precedence, sequences, embedding and invalid forms |
| option | 4 | hex/binary parse/render interactions with real binary syntax |
| document | 4 | multiline, CRLF normalization and full-stop line splitting |
| word | 3 | ordinary words including `ale`/`ali`/`ota` |
| proper | 3 | automatic proper-name cartouche behavior |
| unknown | 3 | hidden/shown/Core quoted unknown text |
| image | 2 | inline image parsing including quoted comma arguments |
| integration | 1 | compound + abbreviated numeric cartouche end-to-end (`toki&pona 123`) |
| direct/punct/dash | 3 | `te`/`to`/`zz`, punctuation, Unicode dash separators |

Total: **254**.

## Random cartouche fallback

The canonical JavaScript renderer intentionally chooses random glyphs for its final Latin-letter bracket fallback. The Go reference uses a stable first glyph from each accepted initial-letter bucket so render plans are reproducible. Cases whose exact fallback codepoints are intentionally random in JavaScript are marked `randomCps`; their structural/run semantics are still checked.

## Frozen Core boundary

The seven Core-v1 source files remain hash-pinned and unchanged. Canonical full-renderer compatibility is implemented in the additive full-renderer binding and whole-text scanner rather than by changing the frozen Core parser.

## Regression behavior

Run:

```bash
./tools/run_go_regression.sh
```

The runner is non-fail-fast. It attempts all configured groups and writes one complete report to:

```text
test-output/go-regression-report.txt
```

If one group fails, later groups still run. The final process exit status is non-zero only after all configured groups have been attempted and the consolidated failure index has been written.
