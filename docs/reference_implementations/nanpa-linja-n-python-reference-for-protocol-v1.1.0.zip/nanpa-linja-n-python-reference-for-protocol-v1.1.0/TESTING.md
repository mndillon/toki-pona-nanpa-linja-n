# Testing the Python Protocol v1.1.0 reference

From the extracted package directory:

```bash
python3 -m pip install -e .
python3 scripts/run_all.py
```

The runner is non-fail-fast and writes `test-output/python-regression-report.txt`.

Useful focused gates:

```bash
python3 scripts/run_regression.py
python3 scripts/run_ast_to_text.py
python3 scripts/run_differential.py reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js
python3 scripts/run_font_regression.py
python3 scripts/run_canonical_syntax.py
python3 scripts/run_canonical_full_renderer.py
python3 scripts/run_v1_1_profile.py
python3 -m unittest discover -s tests -p 'test_*.py'
```

`python3 scripts/font_goldens.py` verifies the approved 128-artifact production-font matrix. `--update` deliberately replaces the approved visual baseline and should only be used when a font/rendering change is intentional.
