"""Native Python full-document renderer for the nanpa-linja-n Full Renderer Profile.

This module extends the frozen numeric Core with the host-independent document,
ordinary-cartouche, layout, raster/vector and low-level rendering surface of the
canonical JavaScript reference.  It does not execute JavaScript.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from io import BytesIO
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple
import base64
import ctypes
import ctypes.util
import html
import math
import re
import urllib.parse

from PIL import Image, ImageDraw, ImageFilter, ImageFont
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen

from .parser import NanpaParser, _try_plain_decimal_to_nasin_nanpa_pona_words, _codepoints_to_words_internal
from .font_registry import FontPairSpec, SupportFontSpec
from .font_adapters import adapt_numeric_cartouche
from . import number_glyph_renderer as legacy

CARTOUCHE_START = 0xF1990
CARTOUCHE_END = 0xF1991
TALLY_CP = 0xF199E
MIDDLE_DOT_CP = 0xF199C
COLON_CP = 0xF199D
STACK_JOINER_CP = 0xF1995
NEST_JOINER_CP = 0xF1996
OPEN_QUOTE_CP = 0x300C
CLOSE_QUOTE_CP = 0x300D
VULGAR_SCALE_MARKERS = {0x00BC, 0x2153, 0x00BD, 0x2154, 0x00BE}
ASCII_SCALE_ALIASES = {"1/4":0x00BC, "1/3":0x2153, "1/2":0x00BD, "2/3":0x2154, "3/4":0x00BE}

_RGBA = Tuple[int, int, int, int]


def _cp_for_word(word: str) -> Optional[int]:
    value = getattr(legacy, "WORDS_TO_UNC_CODES_MAP", {}).get((word or "").lower())
    if not value:
        return None
    return ord(value[0])


def _word_for_cp(cp: int) -> Optional[str]:
    table = getattr(legacy, "UNC_CODES_TO_WORDS_MAP", {})
    value = table.get(f"{int(cp):X}") or table.get(f"{int(cp):04X}")
    return str(value).lower() if value else None


def _hex_color(value: Any, default: str = "#000000") -> str:
    s = str(value or default).strip()
    if re.fullmatch(r"#[0-9a-fA-F]{6}", s):
        return s.upper()
    if re.fullmatch(r"#[0-9a-fA-F]{3}", s):
        a = s[1:].upper()
        return "#" + "".join(ch * 2 for ch in a)
    return default.upper()


def _rgba_from_hex(value: str, alpha: int = 255) -> _RGBA:
    s = _hex_color(value)
    return (int(s[1:3], 16), int(s[3:5], 16), int(s[5:7], 16), alpha)


@dataclass(frozen=True)
class ParseOptions:
    enable_binary_parsing: bool = False
    enable_binary_rendering: bool = False
    enable_hex_parsing: bool = False
    mode: str = "uniform"
    numeric_mode: str = "uniform"
    nanpa_colon_parsing: bool = True
    nanpa_colon_rendering: bool = True
    relaxed_nanpa_linjan_parsing: bool = True
    relaxed_nanpa_linjan_rendering: bool = True
    abbreviate_numeric_cartouches: bool = True
    preserve_numeric_cartouche_breaks_in_abbreviation: bool = False
    numeric_cartouche_start_glyph: Optional[str] = None
    renderer_mode: str = "sitelen-pona-ascii-extended"
    mixed_style: str = "short"
    break_lines_at_full_stops: bool = False
    show_unknown_text: bool = False
    auto_cartouche_standalone_proper_names: bool = True
    interpret_double_quotes_as_te_to: bool = False
    cartouche_comma_tally_marks: bool = True
    cartouche_tally_mode: Optional[str] = None
    manual_tally_small_font_lift_px: Optional[float] = None
    manual_tally_small_font_max_px: Optional[float] = None
    nasin_nanpa_pona: bool = False

    @staticmethod
    def from_mapping(raw: Optional[Mapping[str, Any]]) -> "ParseOptions":
        m = dict(raw or {})
        mode_v = str(m.get("mode", "uniform"))
        renderer_mode = str(m.get("rendererMode", "sitelen-pona-ascii-extended"))
        if mode_v not in ("uniform", "traditional"):
            renderer_mode = mode_v
            mode_v = "uniform"
        if renderer_mode not in ("standard-sitelen-pona-ascii-core", "sitelen-pona-ascii-extended", "sitelen-seli-kiwen"):
            renderer_mode = "sitelen-pona-ascii-extended"
        numeric_mode = str(m.get("numericMode", mode_v))
        if numeric_mode not in ("uniform", "traditional"):
            numeric_mode = mode_v
        tally_mode = m.get("cartoucheTallyMode", m.get("tallyMode", m.get("ordinaryCartoucheTallyMode")))
        if tally_mode is not None:
            tally_mode = str(tally_mode).lower().strip()
            if tally_mode not in ("manual", "comma", "ucsur"):
                tally_mode = None
        comma_value = m.get("cartoucheCommaTallyMarks", m.get("commaTallyMarks", m.get("enableCartoucheCommaTallies", True)))
        def b(key: str, default: bool) -> bool:
            v = m.get(key, default)
            if isinstance(v, str):
                return v.lower() not in ("false", "0", "no", "off", "")
            return bool(v)
        def first_bool(keys: Sequence[str], default: bool) -> bool:
            for k in keys:
                if k in m:
                    v=m[k]
                    if isinstance(v,str): return v.lower() not in ("false","0","no","off","")
                    return bool(v)
            return default
        def num(keys: Sequence[str]) -> Optional[float]:
            for k in keys:
                if k in m:
                    try:
                        v=float(m[k])
                        if math.isfinite(v): return v
                    except Exception: pass
            return None
        start = m.get("numericCartoucheStartGlyph")
        start = str(start).lower() if start is not None and str(start).lower() in ("nanpa","tenpo","suno","toki") else None
        return ParseOptions(
            enable_binary_parsing=b("enableBinaryParsing", False),
            enable_binary_rendering=b("enableBinaryRendering", False),
            enable_hex_parsing=b("enableHexParsing", False),
            mode=mode_v,
            numeric_mode=numeric_mode,
            nanpa_colon_parsing=b("nanpaColonParsing", True),
            nanpa_colon_rendering=b("nanpaColonRendering", True),
            relaxed_nanpa_linjan_parsing=b("relaxedNanpaLinjanParsing", True),
            relaxed_nanpa_linjan_rendering=b("relaxedNanpaLinjanRendering", True),
            abbreviate_numeric_cartouches=first_bool(("abbreviateNumericCartouches","numericCartoucheAbbreviation","abbreviatedNumericCartouches"), True),
            preserve_numeric_cartouche_breaks_in_abbreviation=first_bool(("preserveNumericCartoucheBreaksInAbbreviation","abbreviatedNumericCartoucheBreakAsEn"), False),
            numeric_cartouche_start_glyph=start,
            renderer_mode=renderer_mode,
            mixed_style="long" if str(m.get("mixedStyle", "short")).lower()=="long" else "short",
            break_lines_at_full_stops=b("breakLinesAtFullStops", False),
            show_unknown_text=b("showUnknownText", False),
            auto_cartouche_standalone_proper_names=b("autoCartoucheStandaloneProperNames", True),
            interpret_double_quotes_as_te_to=b("interpretDoubleQuotesAsTeTo", False),
            cartouche_comma_tally_marks=(comma_value if isinstance(comma_value,bool) else str(comma_value).lower() not in ("false","0","no","off","")),
            cartouche_tally_mode=tally_mode,
            manual_tally_small_font_lift_px=num(("manualTallySmallFontLiftPx","tallySmallFontLiftPx")),
            manual_tally_small_font_max_px=num(("manualTallySmallFontMaxPx","tallySmallFontMaxPx")),
            nasin_nanpa_pona=b("nasinNanpaPona", False),
        )

    def numeric_mapping(self) -> Dict[str, Any]:
        mode = "traditional" if self.mode == "traditional" or self.numeric_mode == "traditional" else "uniform"
        out: Dict[str, Any] = {
            "enableBinaryParsing": self.enable_binary_parsing,
            "enableBinaryRendering": self.enable_binary_rendering,
            "enableHexParsing": self.enable_hex_parsing,
            "mode": mode,
            "numericMode": mode,
            "nanpaColonParsing": self.nanpa_colon_parsing,
            "nanpaColonRendering": self.nanpa_colon_rendering,
            "relaxedNanpaLinjanParsing": self.relaxed_nanpa_linjan_parsing,
            "relaxedNanpaLinjanRendering": self.relaxed_nanpa_linjan_rendering,
            "abbreviateNumericCartouches": self.abbreviate_numeric_cartouches,
            "preserveNumericCartoucheBreaksInAbbreviation": self.preserve_numeric_cartouche_breaks_in_abbreviation,
            "mixedStyle": self.mixed_style,
            "nasinNanpaPona": self.nasin_nanpa_pona,
        }
        if self.numeric_cartouche_start_glyph:
            out["numericCartoucheStartGlyph"] = self.numeric_cartouche_start_glyph
        return out


@dataclass(frozen=True)
class LayoutOptions:
    align: str = "left"
    spacing_preset: str = "default"
    glyph_gap_scale: Optional[float] = None
    glyph_gap_min_px: Optional[float] = None
    glyph_gap_max_px: Optional[float] = None
    cartouche_lead_gap_scale: Optional[float] = None
    cartouche_pad_scale: Optional[float] = None
    cartouche_pad_min_px: Optional[float] = None
    line_gap_px: Optional[float] = None
    force_line_gap_px: bool = False

    @staticmethod
    def from_mapping(raw: Optional[Mapping[str, Any]]) -> "LayoutOptions":
        m=dict(raw or {})
        def n(k):
            try:
                v=float(m[k]); return v if math.isfinite(v) else None
            except Exception: return None
        align=str(m.get("align","left")).lower(); align=align if align in ("left","center","right") else "left"
        preset=str(m.get("spacingPreset","default")).lower(); preset=preset if preset in ("default","compact","comfortable") else "default"
        return LayoutOptions(align,preset,n("glyphGapScale"),n("glyphGapMinPx"),n("glyphGapMaxPx"),n("cartoucheLeadGapScale"),n("cartouchePadScale"),n("cartouchePadMinPx"),n("lineGapPx"),bool(m.get("forceLineGapPx",False)))
    def glyph_gap(self,px:float)->float:
        if self.glyph_gap_scale is not None:
            v=px*self.glyph_gap_scale
            if self.glyph_gap_min_px is not None:v=max(v,self.glyph_gap_min_px)
            if self.glyph_gap_max_px is not None:v=min(v,self.glyph_gap_max_px)
            return max(0.0,v)
        return max(2,px*.08) if self.spacing_preset=="compact" else max(6,px*.22) if self.spacing_preset=="comfortable" else max(4,px*.14)
    def cartouche_lead_gap(self,px:float)->float:
        return max(0,px*self.cartouche_lead_gap_scale) if self.cartouche_lead_gap_scale is not None else self.glyph_gap(px)
    def cartouche_pad(self,px:float)->float:
        v=px*(self.cartouche_pad_scale if self.cartouche_pad_scale is not None else .12)
        if self.cartouche_pad_min_px is not None:v=max(v,self.cartouche_pad_min_px)
        return max(0,v)
    def line_gap(self,px:float)->float:
        if self.line_gap_px is not None and (self.force_line_gap_px or self.line_gap_px>=0):return max(0,self.line_gap_px)
        return max(8,px*.20) if self.spacing_preset=="compact" else max(18,px*.40) if self.spacing_preset=="comfortable" else 18.0


@dataclass(frozen=True)
class UnknownTextStyle:
    style: str = "outline-box"
    color: str = "#000000"
    line_width_px: float = 1.5
    padding_px: float = 2.0
    dash: Tuple[float,...] = ()
    @staticmethod
    def from_mapping(raw: Any)->"UnknownTextStyle":
        m=dict(raw) if isinstance(raw,Mapping) else {}
        dash=[]
        for x in m.get("dash",[]) or []:
            try: dash.append(float(x))
            except Exception: pass
        try: lw=max(0,float(m.get("lineWidthPx",1.5)))
        except Exception: lw=1.5
        try: pad=max(0,float(m.get("paddingPx",2)))
        except Exception: pad=2
        return UnknownTextStyle(str(m.get("style","outline-box")),_hex_color(m.get("color"),"#000000"),lw,pad,tuple(dash))

@dataclass(frozen=True)
class PaintOptions:
    fill_style: str = "#000000"
    unknown_text: UnknownTextStyle = field(default_factory=UnknownTextStyle)
    halo_enabled: bool = False
    halo_color: str = "#FFFFFF"
    halo_width_px: float = 0.0
    @staticmethod
    def from_mapping(raw: Optional[Mapping[str,Any]])->"PaintOptions":
        m=dict(raw or {}); hm=dict(m.get("halo") or {}) if isinstance(m.get("halo"),Mapping) else {}
        try: hw=max(0,float(hm.get("widthPx",0)))
        except Exception: hw=0
        return PaintOptions(_hex_color(m.get("fillStyle"),"#000000"),UnknownTextStyle.from_mapping(m.get("unknownText")),bool(hm.get("enabled",False)),_hex_color(hm.get("color"),"#FFFFFF"),hw)

@dataclass(frozen=True)
class FullRenderOptions:
    font_key: str = "nasinNanpa"
    font_size: float = 56.0
    padding_px: int = 18
    parser: ParseOptions = field(default_factory=ParseOptions)
    layout: LayoutOptions = field(default_factory=LayoutOptions)
    paint: PaintOptions = field(default_factory=PaintOptions)
    include_plan: bool = True
    format: str = "canvas"
    @staticmethod
    def from_mapping(raw: Optional[Mapping[str,Any]], *, defaults: Optional[Mapping[str,Any]]=None)->"FullRenderOptions":
        m=dict(defaults or {}); m.update(dict(raw or {}))
        layout=LayoutOptions.from_mapping(m.get("layout") if isinstance(m.get("layout"),Mapping) else {})
        paint=PaintOptions.from_mapping(m.get("paint") if isinstance(m.get("paint"),Mapping) else {})
        parser=ParseOptions.from_mapping(m.get("parser") if isinstance(m.get("parser"),Mapping) else {})
        fs=m.get("fontSize", (m.get("layout") or {}).get("fontPx",56) if isinstance(m.get("layout"),Mapping) else 56)
        try: fs=max(8,float(fs))
        except Exception: fs=56
        pad=m.get("paddingPx", (m.get("layout") or {}).get("paddingPx",18) if isinstance(m.get("layout"),Mapping) else 18)
        try: pad=max(0,int(round(float(pad))))
        except Exception: pad=18
        return FullRenderOptions(str(m.get("font","nasinNanpa")),fs,pad,parser,layout,paint,bool(m.get("includePlan",True)),str(m.get("format","canvas")).lower())


@dataclass(frozen=True)
class ImageDescriptor:
    src: str=""; w: Optional[str]=None; h: Optional[str]=None; alt: Optional[str]=None; valign: str="baseline"; wriggle: float=8; transparent: bool=True
@dataclass(frozen=True)
class DocumentSegment:
    kind: str; value: Optional[str]=None; image: Optional[ImageDescriptor]=None; open_quote: Optional[str]=None; close_quote: Optional[str]=None; source_start:int=0; source_end:int=0; numeric_structures:Tuple[Mapping[str,Any],...]=()

    @property
    def numericStructures(self) -> Tuple[Mapping[str, Any], ...]:
        return self.numeric_structures
@dataclass(frozen=True)
class DocumentLine:
    index:int; source_line_index:int; sentence_index_in_source_line:int; source_text:str; children:Tuple[DocumentSegment,...]
@dataclass(frozen=True)
class DocumentAst:
    type:str; normalized_input:str; parser_options:Mapping[str,Any]; lines:Tuple[DocumentLine,...]

@dataclass(frozen=True)
class TallyGroup:
    owner_index:int; count:int; owner_left_px:float; owner_right_px:float; center_x_px:float; top_y_px:float; bottom_y_px:float; stroke_width_px:float; stroke_centers_px:Tuple[float,...]

@dataclass(frozen=True)
class FullRenderRun:
    id:str=""; line_index:int=0; run_index:int=0; kind:str="glyph"; render_mode:str="text"; font_role:str="word"
    numeric_cartouche:bool=False; hex_cartouche:bool=False; binary_cartouche:bool=False; numeric_base:int=0
    opener_codepoint:Optional[int]=None; closer_codepoint:Optional[int]=None
    canonical_codepoints:Tuple[int,...]=(); render_codepoints:Tuple[int,...]=(); render_text:str=""; render_adapter_id:str="identity"
    source_text:Optional[str]=None; source_kind:Optional[str]=None; source_start:int=-1; source_end:int=-1
    manual_tallies:Tuple[int,...]=(); tally_groups:Tuple[TallyGroup,...]=(); quoted:bool=False; interpreted_quote:bool=False; unrecognized:bool=False; image_alt:Optional[str]=None
    x_px:float=0; y_px:float=0; width_px:float=0; height_px:float=0; baseline_y_px:float=0

@dataclass(frozen=True)
class FullRenderLinePlan:
    line_index:int; source_line_index:int; sentence_index_in_source_line:int; x_px:float; y_px:float; width_px:float; height_px:float; baseline_y_px:float; ascent_px:float; descent_px:float; runs:Tuple[FullRenderRun,...]

@dataclass(frozen=True)
class FullRenderPlan:
    input:str; font_key:str; abbreviated:bool; width:int; height:int; open_type_features:Tuple[str,...]; runs:Tuple[FullRenderRun,...]; parsed:Optional[Mapping[str,Any]]; diagnostics:Tuple[str,...]; ast:DocumentAst; lines:Tuple[FullRenderLinePlan,...]
    @property
    def line_count(self)->int:return len(self.lines)
    @property
    def cartouche_count(self)->int:return sum(1 for r in self.runs if r.numeric_cartouche or r.font_role=="cartouche")

@dataclass
class CanvasRenderResult:
    image:Image.Image; plan:Optional[FullRenderPlan]; font_key:str
    @property
    def width(self)->int:return self.image.width
    @property
    def height(self)->int:return self.image.height
    @property
    def canvas(self)->Image.Image:return self.image

@dataclass(frozen=True)
class VectorElement:
    kind:str; run_id:Optional[str]; path:Optional[str]; fill:Optional[str]; href:Optional[str]; x:float; y:float; width:float; height:float
@dataclass(frozen=True)
class VectorDocument:
    width:int; height:int; elements:Tuple[VectorElement,...]; diagnostics:Tuple[str,...]; plan:FullRenderPlan


ALIASES=(
    ("'cartouche-start'","["),("'cartouche-end'","]"),("'zw-joiner'","&"),("'stack-joiner'","-"),("'nesting-joiner'","+"),
    ("'ideographic-space'"," zz "),("'long-start'","("),("'long-end'",")"),("'left-bracket'"," te "),("'right-bracket'"," to "),
    ("'middle-dot'","."),("'colon'",":"),("'tally'",",")
)

def _normalize_document(s:str,p:ParseOptions)->str:
    out=s or ""
    if p.renderer_mode!="standard-sitelen-pona-ascii-core":
        for a,b in ALIASES: out=out.replace(a,b)
    return out.replace("\r\n","\n").replace("\r","\n")

def _sentence_stop(s:str,i:int)->bool:
    prev=s[i-1] if i>0 else ""; nxt=s[i+1] if i+1<len(s) else ""
    numeric=nxt.isdigit() and (prev.isdigit() or i==0 or prev.isspace() or prev in "+-(,:=")
    return not numeric

def _split_full_stops(line:str)->List[str]:
    out=[]; start=0; square=paren=brace=0; quote=None; i=0
    while i<len(line):
        ch=line[i]
        if quote:
            if ch=="\\":i+=2;continue
            close=(quote=="“" and ch in ("”",'"')) or (quote=='"' and ch in ('"','”'))
            if close:quote=None
            i+=1;continue
        if ch in ('"','“'):quote=ch;i+=1;continue
        if ch=='[':square+=1
        elif ch==']':square=max(0,square-1)
        elif ch=='(':paren+=1
        elif ch==')':paren=max(0,paren-1)
        elif ch=='{':brace+=1
        elif ch=='}':brace=max(0,brace-1)
        elif ch=='.' and not square and not paren and not brace and _sentence_stop(line,i):
            end=i+1
            while end<len(line) and line[end]=='.' and _sentence_stop(line,end):end+=1
            out.append(line[start:end]);start=end;i=end;continue
        i+=1
    tail=line[start:]
    if tail.strip() or not out:out.append(tail)
    return out

def _split_args(s:str)->List[str]:
    out=[];cur=[];quote=None;esc=False;depth=0
    for ch in s:
        if esc:cur.append(ch);esc=False;continue
        if ch=='\\':cur.append(ch);esc=True;continue
        if quote:
            cur.append(ch)
            if ch==quote:quote=None
            continue
        if ch in ('"',"'"):quote=ch;cur.append(ch);continue
        if ch=='(':depth+=1;cur.append(ch);continue
        if ch==')':depth=max(0,depth-1);cur.append(ch);continue
        if ch==',' and depth==0:out.append(''.join(cur).strip());cur=[];continue
        cur.append(ch)
    out.append(''.join(cur).strip())
    return out

def _strip_quotes(s:str)->str:
    s=s.strip()
    if len(s)>=2 and s[0]==s[-1] and s[0] in ('"',"'"):return s[1:-1]
    return s

def _parse_image_args(arg:str)->ImageDescriptor:
    parts=_split_args(arg); src=""; w=h=alt=None; valign="baseline"; wriggle=8.0; transparent=True; start=0
    if parts and '=' not in parts[0]:src=_strip_quotes(parts[0]);start=1
    for x in parts[start:]:
        if '=' not in x:continue
        k,v=x.split('=',1);k=k.strip();v=_strip_quotes(v)
        if k=='src':src=v
        elif k=='w':w=v
        elif k=='h':h=v
        elif k=='alt':alt=v
        elif k=='valign':valign=v
        elif k=='wriggle':
            try:wriggle=float(v)
            except Exception:pass
        elif k=='transparent':transparent=str(v).lower() not in ('false','0','no','off')
    return ImageDescriptor(src,w,h,alt,valign,wriggle,transparent)

def _segments(line:str)->Tuple[DocumentSegment,...]:
    out=[]; i=0; start=0
    def push(a,b):
        if b>a:out.append(DocumentSegment('text',line[a:b],source_start=a,source_end=b))
    while i<len(line):
        ch=line[i]
        if ch=='[':
            j=line.find(']',i+1)
            if j<0:break
            push(start,i);out.append(DocumentSegment('bracket',line[i+1:j],source_start=i,source_end=j+1));i=j+1;start=i;continue
        if ch in ('"','“'):
            close='”' if ch=='“' else '"';j=i+1;found=False
            while j<len(line):
                cj=line[j]; isclose=cj==close or (ch=='“' and cj=='"') or (ch=='"' and cj=='”')
                if isclose and (j==0 or line[j-1]!='\\'):found=True;break
                j+=1
            if not found:break
            push(start,i);out.append(DocumentSegment('quote',line[i+1:j],open_quote=ch,close_quote=line[j],source_start=i,source_end=j+1));i=j+1;start=i;continue
        if line.startswith('img(',i):
            j=i+4;depth=1;quote=None;esc=False
            while j<len(line):
                cj=line[j]
                if esc:esc=False;j+=1;continue
                if cj=='\\':esc=True;j+=1;continue
                if quote:
                    if cj==quote:quote=None
                    j+=1;continue
                if cj in ('"',"'"):quote=cj;j+=1;continue
                if cj=='(':depth+=1
                elif cj==')':
                    depth-=1
                    if depth==0:break
                j+=1
            if j>=len(line):break
            push(start,i);out.append(DocumentSegment('image',image=_parse_image_args(line[i+4:j]),source_start=i,source_end=j+1));i=j+1;start=i;continue
        i+=1
    push(start,len(line));return tuple(out)

def parse_document(input_text:str, options:ParseOptions)->DocumentAst:
    normalized=_normalize_document(input_text or '',options); lines=[]
    for sli,source in enumerate(normalized.split('\n')):
        rendered=_split_full_stops(source) if options.break_lines_at_full_stops else [source]
        for si,s in enumerate(rendered):
            lines.append(DocumentLine(len(lines),sli,si,s,_segments(s)))
    return DocumentAst('document',normalized,{"breakLinesAtFullStops":options.break_lines_at_full_stops},tuple(lines))


def _quote_image_argument(value: Any) -> str:
    text = str(value if value is not None else "")
    if "'" not in text:
        return f"'{text}'"
    if '"' not in text:
        return f'"{text}"'
    escaped = text.replace('\\', '\\\\').replace('\"', '\\\"')
    return f'"{escaped}"'


def _image_descriptor_to_text(desc: Optional[ImageDescriptor]) -> str:
    image = desc if isinstance(desc, ImageDescriptor) else ImageDescriptor()
    args: List[str] = []
    if image.src:
        args.append(f"src={_quote_image_argument(image.src)}")
    if image.w is not None and str(image.w) != "":
        args.append(f"w={_quote_image_argument(image.w)}")
    if image.h is not None and str(image.h) != "":
        args.append(f"h={_quote_image_argument(image.h)}")
    if image.alt is not None:
        args.append(f"alt={_quote_image_argument(image.alt)}")
    if image.valign is not None and str(image.valign) not in ("", "baseline"):
        args.append(f"valign={_quote_image_argument(image.valign)}")
    if image.wriggle is not None and float(image.wriggle) != 8.0:
        wriggle = float(image.wriggle)
        args.append(f"wriggle={wriggle:g}")
    if image.transparent is False:
        args.append("transparent=false")
    return f"img({','.join(args)})"


def _document_segment_source_text(segment: DocumentSegment) -> str:
    if not isinstance(segment, DocumentSegment):
        raise TypeError("AST segment must be a DocumentSegment.")
    if segment.kind == "text":
        return str(segment.value if segment.value is not None else "")
    if segment.kind == "bracket":
        return f"[{str(segment.value if segment.value is not None else '')}]"
    if segment.kind == "quote":
        open_quote = str(segment.open_quote or '"')
        default_close = "”" if open_quote == "“" else '"'
        close_quote = str(segment.close_quote or default_close)
        return f"{open_quote}{str(segment.value if segment.value is not None else '')}{close_quote}"
    if segment.kind == "image":
        return _image_descriptor_to_text(segment.image)
    raise TypeError(f"Unsupported AST segment kind: {segment.kind}")


_NUMERIC_OUTPUT_MODES = {"source", "properName", "#~", "cartouche"}


def _numeric_output_mode(options: Optional[Mapping[str, Any]]) -> str:
    raw = dict(options or {})
    mode = str(raw.get("numericOutput", raw.get("numeric_output", "source")))
    if mode not in _NUMERIC_OUTPUT_MODES:
        raise ValueError(f"Unsupported numericOutput mode: {mode}")
    return mode


def _parser_options_for_text_conversion(ast: DocumentAst, options: Optional[Mapping[str, Any]]) -> Dict[str, Any]:
    parser = ParseOptions().numeric_mapping()
    if isinstance(ast.parser_options, Mapping):
        parser.update(dict(ast.parser_options))
    raw = dict(options or {})
    config = raw.get("config")
    if isinstance(config, Mapping) and isinstance(config.get("parser"), Mapping):
        parser.update(dict(config["parser"]))
    if isinstance(raw.get("parser"), Mapping):
        parser.update(dict(raw["parser"]))
    if isinstance(raw.get("parser_options"), Mapping):
        parser.update(dict(raw["parser_options"]))
    return parser


def _prefers_abbreviated_numeric_cartouches(parser: Mapping[str, Any]) -> bool:
    return (parser.get("abbreviateNumericCartouches") is True or
            parser.get("numericCartoucheAbbreviation") is True or
            parser.get("abbreviatedNumericCartouches") is True or
            parser.get("abbreviate_numeric_cartouches") is True)


def _numeric_source_to_text(source_text: Any, numeric_output: str, parser: Mapping[str, Any]) -> str:
    source = str(source_text if source_text is not None else "")
    if numeric_output == "source":
        return source
    try:
        parsed = NanpaParser.parseNumber(source, dict(parser))
    except Exception:
        parsed = None
    if not isinstance(parsed, Mapping):
        return source

    if parser.get("nasinNanpaPona") is True:
        nnp = _try_plain_decimal_to_nasin_nanpa_pona_words(source)
        if isinstance(nnp, (list, tuple)) and nnp:
            return " ".join(map(str, nnp))

    if numeric_output == "properName":
        proper = parsed.get("properName")
        return str(proper) if proper is not None and str(proper) != "" else source

    if numeric_output == "#~":
        unique = str(parsed.get("uniqueCode") or "")
        return unique if unique.startswith("#~") else source

    if numeric_output == "cartouche":
        if _prefers_abbreviated_numeric_cartouches(parser):
            words = parsed.get("abbreviatedWords")
            if not isinstance(words, (list, tuple)) or not words:
                inner = tuple(int(cp) for cp in (parsed.get("innerCodepoints") or ()))
                if inner:
                    abbreviated = legacy.abbreviate_numeric_cartouche_ucsur(
                        "".join(chr(cp) for cp in inner),
                        preserve_nene_as_en=bool(parser.get("preserveNumericCartoucheBreaksInAbbreviation", False)),
                    )
                    words = _codepoints_to_words_internal([ord(ch) for ch in abbreviated])
        else:
            words = parsed.get("tpWords")
        if isinstance(words, (list, tuple)) and words:
            return "[" + " ".join(map(str, words)) + "]"
        return source

    return source


def _apply_numeric_structures_to_serialized_source(source_text: str, segment: DocumentSegment, options: Optional[Mapping[str, Any]], ast: DocumentAst) -> str:
    source = str(source_text)
    numeric_output = _numeric_output_mode(options)
    if numeric_output == "source":
        return source
    structures = tuple(segment.numeric_structures or ())
    if not structures:
        return source
    parser = _parser_options_for_text_conversion(ast, options)

    valid: List[Tuple[int, int, str]] = []
    for structure in structures:
        if not isinstance(structure, Mapping):
            continue
        try:
            index = int(structure.get("index"))
            end = int(structure.get("end"))
        except Exception:
            continue
        expected = str(structure.get("sourceText", structure.get("source_text", "")))
        if index < 0 or end <= index or end > len(source):
            continue
        if len(expected) != end - index or source[index:end] != expected:
            continue
        valid.append((index, end, expected))
    valid.sort(key=lambda item: (item[0], item[1]))
    if not valid:
        return source

    output: List[str] = []
    position = 0
    for index, end, expected in valid:
        if index < position:
            continue
        output.append(source[position:index])
        output.append(_numeric_source_to_text(expected, numeric_output, parser))
        position = end
    output.append(source[position:])
    return "".join(output)


def _document_segment_to_text(segment: DocumentSegment, options: Optional[Mapping[str, Any]] = None, ast: Optional[DocumentAst] = None) -> str:
    source = _document_segment_source_text(segment)
    if ast is None:
        return source
    return _apply_numeric_structures_to_serialized_source(source, segment, options, ast)


def ast_to_text(ast: DocumentAst, options: Optional[Mapping[str, Any]] = None) -> str:
    """Convert a full-document AST back into valid nanpa-linja-n source text.

    The default ``numericOutput='source'`` retains the existing source-preserving
    behavior.  Explicit ``properName``, ``#~`` and ``cartouche`` modes re-serialize
    numeric spans identified by :func:`parse_input` through ``parseNumber`` while
    respecting the existing parser formatting flags.  If a requested numeric
    representation is unavailable, the exact numeric source is preserved.
    """
    if not isinstance(ast, DocumentAst):
        raise TypeError("ast_to_text() expects a DocumentAst.")
    _numeric_output_mode(options)
    output: List[str] = []
    have_previous = False
    previous_source_line_index: Optional[int] = None
    for i, line in enumerate(ast.lines):
        if not isinstance(line, DocumentLine):
            raise TypeError("AST line must be a DocumentLine.")
        current = ''.join(_document_segment_to_text(segment, options, ast) for segment in line.children)
        source_line_index = line.source_line_index if isinstance(line.source_line_index, int) and line.source_line_index >= 0 else i
        if have_previous and source_line_index != previous_source_line_index:
            output.append('\n')
        output.append(current)
        have_previous = True
        previous_source_line_index = source_line_index
    return ''.join(output)


def parse_raw_unicode_sequence(text:str)->Optional[List[int]]:
    toks=text.strip().split()
    if not toks:return None
    out=[]
    for t in toks:
        m=re.fullmatch(r"(?i)U\+([0-9A-F]{4,6})",t)
        if not m:return None
        cp=int(m.group(1),16)
        if cp>0x10FFFF:return None
        out.append(cp)
    return out



GLYPH_INPUT_ALIASES = {
    "ni01": "ni", "ni02": "ni>", "ni03": "ni^", "ni04": "ni<",
    "sewi01": "sewi", "sewi02": "sewi^",
}
_COMPOUND_SPLIT_RE = re.compile(r'([&+-])')
_RAW_UNICODE_SCAN_RE = re.compile(r'(?i)U\+[0-9a-f]{4,6}(?:[ \t]+U\+[0-9a-f]{4,6})*')
_SSK_SPECIAL_RE = re.compile(r'(?:\{([^{}]+)\}\s*)?([A-Za-z][A-Za-z0-9_^<>]*)\(([^()]+)\)|([A-Za-z][A-Za-z0-9_^<>]*(?:[&+-][A-Za-z][A-Za-z0-9_^<>]*)+)|\{([^{}]+)\}\s*([A-Za-z][A-Za-z0-9_^<>]*)')
_STANDARD_CORE_SPECIAL_RE = re.compile(r'(?i)pi\(([^()]+)\)|([A-Za-z][A-Za-z0-9_^<>]*(?:[&+-][A-Za-z][A-Za-z0-9_^<>]*)+)|(\|)|(pi\s+\{[^{}]*\})')
_LEGACY_LONG_PI_RE = re.compile(r'(?i)pi\+__[A-Za-z][A-Za-z0-9^<>]*(?:__[A-Za-z][A-Za-z0-9^<>]*){0,2}|pi(?:\+\+\+|---)[ \t]*[A-Za-z][A-Za-z0-9_^<>]*[ \t]+[A-Za-z][A-Za-z0-9_^<>]*[ \t]+[A-Za-z][A-Za-z0-9_^<>]*|pi(?:\+\+|--)[ \t]*[A-Za-z][A-Za-z0-9_^<>]*[ \t]+[A-Za-z][A-Za-z0-9_^<>]*|pi\+[A-Za-z][A-Za-z0-9_^<>]*')


def _sanitize_word(s: str) -> str:
    return ''.join(ch for ch in str(s).lower() if ('a' <= ch <= 'z') or ('0' <= ch <= '9') or ch in '<>^.').strip()


def _normalize_full_glyph_key(raw: str) -> str:
    key = str(raw).strip().lower()
    key = GLYPH_INPUT_ALIASES.get(key, key)
    if key in ('·', '.', ':', ','):
        return key
    return _sanitize_word(key)


def _full_glyph_cp(key: str) -> Optional[int]:
    key = _normalize_full_glyph_key(key)
    if key == 'te': return OPEN_QUOTE_CP
    if key == 'to': return CLOSE_QUOTE_CP
    if key == 'zz': return 0x3000
    return _cp_for_word(key)


def _glyph_expression_cps(expression: str) -> Optional[List[int]]:
    source = str(expression).strip()
    if not source or any(ch.isspace() for ch in source): return None
    parts = _COMPOUND_SPLIT_RE.split(source)
    cps: List[int] = []
    expect_word = True
    for part in parts:
        if part == '': return None
        if expect_word:
            cp = _full_glyph_cp(part)
            if cp is None: return None
            cps.append(cp)
        else:
            if part == '&': cps.append(0x200D)
            elif part == '-': cps.append(STACK_JOINER_CP)
            elif part == '+': cps.append(NEST_JOINER_CP)
            else: return None
        expect_word = not expect_word
    return cps if not expect_word else None


def _glyph_words_cps(text: str) -> Optional[List[int]]:
    fields = str(text).strip().split()
    if not fields: return None
    out: List[int] = []
    for field in fields:
        cps = _glyph_expression_cps(field)
        if cps is None:
            cp = _full_glyph_cp(field)
            if cp is None: return None
            cps = [cp]
        out.extend(cps)
    return out


def _extended_glyph_cps(left: str, head: str, right: str) -> Optional[List[int]]:
    head_cp = _full_glyph_cp(head)
    if head_cp is None: return None
    out: List[int] = []
    if str(left).strip():
        cps = _glyph_words_cps(left)
        if not cps: return None
        out += [0xF199A, *cps, 0xF199B]
    out.append(head_cp)
    if str(right).strip():
        cps = _glyph_words_cps(right)
        if not cps: return None
        out += [0xF1997, *cps, 0xF1998]
    return out if len(out) > 1 else None


def _legacy_long_pi_inner(source: str) -> Optional[str]:
    s = str(source).strip()
    if s.lower().startswith('pi+__'):
        parts = s[5:].split('__')
        if not 1 <= len(parts) <= 3 or any(_full_glyph_cp(x) is None for x in parts): return None
        return ' '.join(parts)
    m = re.fullmatch(r'(?i)pi(\+{1,3}|-{2,3})(.*)', s)
    if not m: return None
    expected = len(m.group(1)); words = m.group(2).strip().split()
    if len(words) != expected or any(_full_glyph_cp(w) is None for w in words): return None
    return ' '.join(words)


def _legacy_ordinary_word(cp: int, kind: str, pair: Optional[FontPairSpec]=None) -> Optional[str]:
    if cp == MIDDLE_DOT_CP: return '.'
    if cp == COLON_CP: return ':'
    if cp == 0x3000: return 'zz' if kind == 'linja-lipamanka' else '  '
    if cp == 0xF1989: return 'ni<' if kind == 'linja-lipamanka' else 'ni'
    if cp == 0xF198A: return 'ni^' if kind in ('linja-sike','linja-lipamanka') else 'ni'
    if cp == 0xF198B: return 'ni>' if kind in ('linja-sike','linja-lipamanka') else 'ni'
    if cp == 0xF198C: return 'sewi1' if kind == 'linja-sike' else 'sewi'
    if (cp in (OPEN_QUOTE_CP, CLOSE_QUOTE_CP) and kind in ('linja-pona','linja-sike') and
            pair is not None and str((pair.render_adapter_settings or {}).get('cornerBracketMode') or '').strip().lower() == 'synthetic'):
        return chr(cp)
    if cp == OPEN_QUOTE_CP and kind == 'linja-lipamanka': return 'te'
    if cp == CLOSE_QUOTE_CP and kind == 'linja-lipamanka': return 'to'
    w = _word_for_cp(cp)
    if w is None: return None
    if kind == 'linja-pona' and cp in (0xF19A2,0xF19A4,0xF19A5,0xF19A6): return None
    if kind == 'linja-lipamanka' and (cp in (0xF19A4,0xF19A5,0xF19A6) or cp > 0xF19A3): return None
    return w


def _full_control_only(cp: int) -> bool:
    return cp in (0xF1992,0xF1993,0xF1994,0xF1997,0xF1998,0xF1999,0xF199A,0xF199B)

def _full_joiner(cp: int) -> bool:
    return cp in (0x200D, STACK_JOINER_CP, NEST_JOINER_CP)

def _split_full_cells(cps: Sequence[int], start: int=0, end: Optional[int]=None) -> List[Tuple[List[int], bool]]:
    vals=list(map(int,cps)); end=len(vals) if end is None else end; cells=[]; i=start
    while i<end:
        cp=vals[i]
        if _full_control_only(cp): cells.append(([cp],True)); i+=1; continue
        cell=[cp]; i+=1
        while i+1<end and _full_joiner(vals[i]): cell.extend([vals[i],vals[i+1]]); i+=2
        cells.append((cell,False))
    return cells

def _append_legacy_cell(cell: Sequence[int], kind: str, pair: FontPairSpec) -> str:
    if not cell or _full_control_only(cell[0]): return ''
    out=[]; i=0
    while i<len(cell):
        out.append(_legacy_ordinary_word(cell[i],kind,pair) or '\ufffd'); i+=1
        if i<len(cell):
            joiner=cell[i]; op='-'
            if kind=='linja-lipamanka':
                if joiner==STACK_JOINER_CP: op='+'
                elif joiner==NEST_JOINER_CP: op='-'
                else: op=str((pair.render_adapter_settings or {}).get('genericCompoundOperator') or '-')[:1]
            out.append(op); i+=1
    return ''.join(out)

def _find_current_long(cps: Sequence[int]):
    vals=list(cps)
    try: start=vals.index(0xF1997)
    except ValueError: return None
    if start<=0:return None
    try:end=vals.index(0xF1998,start+1)
    except ValueError:return None
    return (start-1,start,end)

def _has_reverse_long(cps: Sequence[int])->bool:return any(cp in (0xF199A,0xF199B) for cp in cps)

def _adapt_builtin_full_word_run(pair: FontPairSpec, cps: Sequence[int]) -> Tuple[int,...]:
    vals=tuple(map(int,cps)); rid=pair.render_adapter_id or 'identity'; settings=pair.render_adapter_settings or {}
    if rid in ('linja-pona-legacy-v1','linja-sike-legacy-v1'):
        kind='linja-pona' if rid.startswith('linja-pona') else 'linja-sike'
        cur=_find_current_long(vals)
        if cur and not _has_reverse_long(vals) and vals[cur[0]]==_cp_for_word('pi'):
            usable=[c for c,control in _split_full_cells(vals,cur[1]+1,cur[2]) if not control]
            max_cells=int(settings.get('maxLongPiCells') or 3)
            if 1<=len(usable)<=max_cells:
                if kind=='linja-pona':
                    text='pi'+'+'*len(usable)+''.join((' ' if i else '')+_append_legacy_cell(c,kind,pair) for i,c in enumerate(usable))
                else:
                    text='pi+'+''.join('__'+_append_legacy_cell(c,kind,pair) for c in usable)
                return tuple(map(ord,text))
        text=''.join(_append_legacy_cell(c,kind,pair) for c,control in _split_full_cells(vals) if not control)
        return tuple(map(ord,text))
    if rid=='nasin-sitelen-pu-mono-v1':
        repl=int(settings.get('unsupportedReplacementCodepoint',0xFFFD)); out=[]
        for cp in vals:
            if _full_joiner(cp) or _full_control_only(cp): continue
            if cp in (0xF1989,0xF198A,0xF198B): out.append(0xF1941)
            elif cp==0xF198C: out.append(0xF195A)
            elif cp==MIDDLE_DOT_CP: out.append(ord('.'))
            elif cp==COLON_CP: out.append(ord(':'))
            elif (0xF1900<=cp<=0xF1988) or (0xF19A0<=cp<=0xF19A3) or cp in (CARTOUCHE_START,CARTOUCHE_END,0x3000,OPEN_QUOTE_CP,CLOSE_QUOTE_CP): out.append(cp)
            else: out.append(repl)
        return tuple(out)
    if rid=='linja-lipamanka-v1':
        deterministic_alternates=settings.get('deterministicAlternates') is not False
        jaki_cp=_cp_for_word('jaki'); ko_cp=_cp_for_word('ko')
        deterministic_cps=tuple(x for x in (jaki_cp,ko_cp) if x is not None)
        def needs(cp):
            return (_full_joiner(cp) or
                    cp in (MIDDLE_DOT_CP,COLON_CP,TALLY_CP,0xF1989,0xF198A,0xF198B,0xF198C,OPEN_QUOTE_CP,CLOSE_QUOTE_CP,0x3000) or
                    cp>=0xF19A4 or
                    (deterministic_alternates and cp in deterministic_cps))
        cur=_find_current_long(vals)
        if not any(needs(cp) for cp in vals) and not _has_reverse_long(vals) and not (cur and vals[cur[0]] not in (_cp_for_word('pi'),_cp_for_word('lon'))): return vals
        if cur and not _has_reverse_long(vals) and vals[cur[0]] in (_cp_for_word('pi'),_cp_for_word('lon')):
            cells=[c for c,control in _split_full_cells(vals,cur[1]+1,cur[2]) if not control]
            text=(_legacy_ordinary_word(vals[cur[0]],'linja-lipamanka',pair) or '\ufffd')+'('+ ' '.join(_append_legacy_cell(c,'linja-lipamanka',pair) for c in cells)+')'
            return tuple(map(ord,text))
        text=''.join(_append_legacy_cell(c,'linja-lipamanka',pair) for c,control in _split_full_cells(vals) if not control)
        return tuple(map(ord,text))
    return vals


def _letters_to_fallback_glyph_cps(source: str) -> List[int]:
    banned={'ota','kolon','koma','te','to','zz'}
    words=[]
    for key in getattr(legacy,'WORDS_TO_UNC_CODES_MAP',{}).keys():
        w=str(key).lower()
        if re.fullmatch(r'[a-z]+',w) and w not in banned: words.append(w)
    # The map key shape varies between generated versions; fall back to UNC reverse map.
    if not words:
        words=[str(w).lower() for w in getattr(legacy,'UNC_CODES_TO_WORDS_MAP',{}).values() if re.fullmatch(r'[a-z]+',str(w).lower()) and str(w).lower() not in banned]
    bucket={}
    for w in sorted(set(words)):
        cp=_cp_for_word(w)
        if cp is not None: bucket.setdefault(w[0],cp)
    out=[]
    for ch in str(source).lower():
        if 'a'<=ch<='z' and ch in bucket: out.append(bucket[ch])
    return out

def _unescape_full_quoted(raw: str) -> str:
    return str(raw).replace(r'\"','"').replace(r'\\','\\').replace(r'\t','    ').replace(r'\n','\n')

def _normalize_extended_legacy_cartouche(body: str) -> Optional[str]:
    s=str(body).strip()
    if not s.startswith('_'): return None
    words=[]
    for part in s.split('_'):
        part=part.strip()
        if not part: continue
        if _full_glyph_cp(part) is None: return None
        words.append(part)
    return ' '.join(words) if words else None


_FULL_NUMERIC_DIGIT_WORDS = {"ijo","wan","tu","seli","awen","luka","utala","mun","pipi","jo"}
_RELAXED_PHRASE_FOLLOWERS = {"wan":"ala","pipi":"ike","tu":"uta","luka":"uta","mun":"uta","jo":"open"}
_SCIENTIFIC_PHRASE_REPLACEMENTS = [
    (("nena","e","kala","open","wan","e","nena","ijo","nena","e","kala","open"),("nena","e","kala","open")),
    (("nena","e","kala","open","wan","ala","nena","ijo","nena","e","kala","open"),("nena","e","kala","open")),
    (("nena","en","kala","open","wan","en","nena","ijo","nena","en","kala","open"),("nena","e","kala","open")),
    (("nena","en","kala","open","wan","ala","nena","ijo","nena","en","kala","open"),("nena","e","kala","open")),
    (("nasa","e","kala","open","wan","esun","nasa","ijo","nasa","e","kala","open"),("nasa","e","kala","open")),
    (("nasa","e","kala","open","wan","ala","nasa","ijo","nasa","e","kala","open"),("nasa","e","kala","open")),
]

def _phrase_word_allowed(words: Sequence[str], i: int, p: ParseOptions) -> bool:
    w=words[i]
    if w=='nasin' or _cp_for_word(w) is None:return False
    if w=='open' and i>0 and words[i-1]=='jo':return p.relaxed_nanpa_linjan_parsing
    if w not in ('ala','ike','uta'):return True
    if not p.relaxed_nanpa_linjan_parsing or i<=2 or i>=len(words)-1:return False
    return _RELAXED_PHRASE_FOLLOWERS.get(words[i-1])==w

def _canonicalize_scientific_phrase_words(words: Sequence[str]) -> List[str]:
    vals=list(words);out=[];i=0
    while i<len(vals):
        matched=False
        for old,new in _SCIENTIFIC_PHRASE_REPLACEMENTS:
            if tuple(vals[i:i+len(old)])==old:
                out.extend(new);i+=len(old);matched=True;break
        if not matched:out.append(vals[i]);i+=1
    return out

def _canonical_phrase_words(input_words: Sequence[str], p: ParseOptions) -> Optional[List[str]]:
    words=[str(w).strip().lower() for w in input_words if str(w).strip()]
    if len(words)<3 or words[0]!='nanpa' or words[-1]!='nanpa' or words[1] not in ('e','en','esun'):return None
    if any(not _phrase_word_allowed(words,i,p) for i in range(len(words))):return None
    if any(words[i-1] in _FULL_NUMERIC_DIGIT_WORDS and words[i] in _FULL_NUMERIC_DIGIT_WORDS for i in range(1,len(words))):return None
    canonical=_canonicalize_scientific_phrase_words(words)
    if len(canonical)>=6 and canonical[:4]==['nanpa','en','nena','en']:
        canonical=['nanpa','e',*canonical[4:]]
    positive=len(canonical)>=5 and canonical[:4]==['nanpa','e','nena','en']
    canonical=[('e' if w=='en' and not (positive and i==3) else w) for i,w in enumerate(canonical)]
    if not any(w in _FULL_NUMERIC_DIGIT_WORDS for w in canonical[2:-1]):return None
    if words[1]=='en':
        scaff={'nanpa','en','e','nena','open','ala','ike','uta'}
        if not any(w in scaff for w in words[2:-1]):return None
    return canonical

def _phrase_words_to_codepoints(words: Sequence[str], p: ParseOptions) -> Optional[List[int]]:
    source=list(words)
    positive=len(source)>=4 and source[:4]==['nanpa','e','nena','en']
    if p.nanpa_colon_rendering and len(source)>=3 and source[0]=='nanpa' and source[1] in ('e','en','esun'):
        source=['nanpa',':',*source[2:]]
    cps=[]
    for w in source:
        cp=_cp_for_word(w)
        if cp is None:return None
        cps.append(cp)
    if p.numeric_mode=='uniform' or p.mode=='uniform':
        cps=[ord(ch) for ch in legacy._uniformize_numeric_ucsur(''.join(map(chr,cps)))]
    if positive and len(cps)>=4 and cps[2]==_cp_for_word('nena'):cps[3]=_cp_for_word('en')
    return cps

def _phrase_result(source: str, cps: Sequence[int], words: Sequence[str], p: ParseOptions) -> Dict[str,Any]:
    inner=list(map(int,cps));mode='traditional' if p.mode=='traditional' or p.numeric_mode=='traditional' else 'uniform'
    return {'input':source,'ucsurCodepoints':inner,'innerCodepoints':list(inner),'codepoints':[CARTOUCHE_START,*inner,CARTOUCHE_END],
            'tpWords':list(words),'words':list(words),'numericMode':mode,'numberBase':10,'isTime':False,'isDate':False}

def _new_phrase_parse_result(words: Sequence[str], p: ParseOptions) -> Optional[Dict[str,Any]]:
    canonical=_canonical_phrase_words(words,p)
    if canonical is None:return None
    cps=_phrase_words_to_codepoints(canonical,p)
    return _phrase_result(' '.join(words),cps,canonical,p) if cps is not None else None

def _abbreviated_phrase_result(words: Sequence[str], p: ParseOptions) -> Optional[Dict[str,Any]]:
    words=[str(w).lower() for w in words]
    if len(words)<3 or words[0]!='nanpa' or words[-1]!='nanpa':return None
    positive=len(words)>=4 and words[1]=='en';cps=[];has_digit=False
    for i,w in enumerate(words):
        if w in ('nasin','ala','ike','uta'):return None
        cp=_cp_for_word(w)
        if cp is None:return None
        final_nanpa=w=='nanpa' and i==len(words)-1
        positive_marker=positive and i==1 and w=='en'
        if i>0 and not final_nanpa and not positive_marker and w in ('nanpa','en','e','nena','open','ala','ike','uta'):return None
        has_digit|=w in _FULL_NUMERIC_DIGIT_WORDS;cps.append(cp)
    if not has_digit:return None
    return _phrase_result(' '.join(words),cps,words,p)

@dataclass(frozen=True)
class AdaptedOrdinary:
    text:str; canonical_spans:Tuple[Tuple[int,int],...]

def _adapt_ordinary(pair:FontPairSpec, inner:Sequence[int])->AdaptedOrdinary:
    full=[CARTOUCHE_START,*map(int,inner),CARTOUCHE_END]
    rid=pair.render_adapter_id or 'identity'; settings=pair.render_adapter_settings or {}
    def identity(cps):
        return AdaptedOrdinary(''.join(chr(x) for x in cps),tuple((i,i+1) for i in range(len(cps))))
    def legacy_word(cp:int,kind:str)->Optional[str]:
        if cp==MIDDLE_DOT_CP:return '.'
        if cp==COLON_CP:return ':'
        if cp==0x3000:return 'zz' if kind=='linja-lipamanka' else '  '
        if cp==0xF1989:return 'ni<' if kind=='linja-lipamanka' else 'ni'
        if cp==0xF198A:return 'ni^' if kind in ('linja-sike','linja-lipamanka') else 'ni'
        if cp==0xF198B:return 'ni>' if kind in ('linja-sike','linja-lipamanka') else 'ni'
        if cp==0xF198C:return 'sewi1' if kind=='linja-sike' else 'sewi'
        if cp==OPEN_QUOTE_CP and kind=='linja-lipamanka':return 'te'
        if cp==CLOSE_QUOTE_CP and kind=='linja-lipamanka':return 'to'
        w=_word_for_cp(cp)
        if w is None:return None
        if kind=='linja-pona' and cp in (0xF19A2,0xF19A4,0xF19A5,0xF19A6):return None
        if kind=='linja-lipamanka' and (cp in (0xF19A4,0xF19A5,0xF19A6) or cp>0xF19A3):return None
        return w
    if rid in ('linja-pona-legacy-v1','linja-sike-legacy-v1'):
        kind='linja-pona' if rid.startswith('linja-pona') else 'linja-sike'; out='['; spans=[(0,1)]+[(0,0)]*(len(full)-2)+[(0,0)]
        for i,cp in enumerate(full[1:-1],1):
            st=len(out); w=legacy_word(cp,kind) or '\ufffd'; out+='_'+w; spans[i]=(st,len(out))
        st=len(out); out+=']'; spans[-1]=(st,len(out)); return AdaptedOrdinary(out,tuple(spans))
    if rid=='nasin-sitelen-pu-mono-v1':
        def mapped(cp):
            if cp in (0xF1989,0xF198A,0xF198B):return 0xF1941
            if cp==0xF198C:return 0xF195A
            if cp==MIDDLE_DOT_CP:return ord('.')
            if cp==COLON_CP:return ord(':')
            if (0xF1900<=cp<=0xF1988) or (0xF19A0<=cp<=0xF19A3) or cp in (CARTOUCHE_START,CARTOUCHE_END,0x3000,OPEN_QUOTE_CP,CLOSE_QUOTE_CP):return cp
            return int(settings.get('unsupportedReplacementCodepoint',0xFFFD))
        vals=[mapped(x) for x in full];return AdaptedOrdinary(''.join(chr(x) for x in vals),tuple((i,i+1) for i in range(len(vals))))
    if rid=='linja-lipamanka-v1':
        deterministic_alternates=settings.get('deterministicAlternates') is not False
        jaki_cp=_cp_for_word('jaki'); ko_cp=_cp_for_word('ko')
        def needs(cp):
            return (cp in (MIDDLE_DOT_CP,COLON_CP,TALLY_CP,0xF1989,0xF198A,0xF198B,0xF198C,OPEN_QUOTE_CP,CLOSE_QUOTE_CP,0x3000,0xF19A4,0xF19A5,0xF19A6) or
                    cp>0xF19A3 or
                    (deterministic_alternates and cp in tuple(x for x in (jaki_cp,ko_cp) if x is not None)))
        if any(needs(cp) for cp in full):
            out='[';spans=[(0,1)]+[(0,0)]*(len(full)-2)+[(0,0)]
            for i,cp in enumerate(full[1:-1],1):
                if i>1:out+=' '
                st=len(out);out+=legacy_word(cp,'linja-lipamanka') or '\ufffd';spans[i]=(st,len(out))
            st=len(out);out+=']';spans[-1]=(st,len(out));return AdaptedOrdinary(out,tuple(spans))
    return identity(full)

def _apply_ordinary_scale_markers(adapted: AdaptedOrdinary, markers: Sequence[Optional[int]]) -> AdaptedOrdinary:
    if not markers or not any(int(m) in VULGAR_SCALE_MARKERS for m in markers if m is not None):
        return adapted
    text=list(adapted.text); spans=list(adapted.canonical_spans); insertions=[]
    for inner_index, marker in enumerate(markers):
        if marker is None or int(marker) not in VULGAR_SCALE_MARKERS: continue
        canonical_index=inner_index+1
        if canonical_index>=len(spans): continue
        pos=int(spans[canonical_index][1]); insertions.append((pos,canonical_index,int(marker)))
    if not insertions:return adapted
    insertions.sort(key=lambda x:(x[0],x[1]))
    by_pos={}
    for item in insertions:by_pos.setdefault(item[0],[]).append(item)
    out=[]
    for pos in range(len(text)+1):
        for _p,_ci,marker in by_pos.get(pos,[]):out.append(chr(marker))
        if pos<len(text):out.append(text[pos])
    def before(pos):return sum(1 for p,_ci,_m in insertions if p<pos)
    def at_or_before(pos):return sum(1 for p,_ci,_m in insertions if p<=pos)
    new_spans=[]
    for ci,(a,b) in enumerate(spans):
        own=sum(1 for p,owner,_m in insertions if owner==ci and p==b)
        na=a+at_or_before(a); nb=b+before(b)+own
        new_spans.append((na,max(na,nb)))
    return AdaptedOrdinary(''.join(out),tuple(new_spans))

@dataclass(frozen=True)
class OrdinaryCartouche:
    inner_codepoints:Tuple[int,...]; manual_tallies:Tuple[int,...]; tally_mode:str; scale_markers:Tuple[Optional[int],...]=()
    @property
    def has_manual_tallies(self)->bool:return any(x>0 for x in self.manual_tallies)

def parse_ordinary_body(body:str,pair:FontPairSpec,p:ParseOptions)->Optional[OrdinaryCartouche]:
    if body is None or not body.strip():return None
    mode=p.cartouche_tally_mode or str(pair.settings.get('cartoucheTallyMode','ucsur')).lower()
    if mode not in ('manual','comma','ucsur'):mode='ucsur'
    vulgar=pair.settings.get('cartoucheVulgarFractions') is True
    cps=[];tallies=[];scales=[];cur=[];last_scalable=-1;tally_started=False
    def push(cp:int, *, scalable=True):
        nonlocal last_scalable,tally_started
        cps.append(int(cp));tallies.append(0);scales.append(None)
        if scalable:last_scalable=len(cps)-1;tally_started=False
        else:last_scalable=-1
    def flush()->bool:
        nonlocal last_scalable,tally_started
        if not cur:return True
        token=''.join(cur).strip().lower();cur.clear()
        if not token:return True
        cp=_cp_for_word(token)
        if cp is None:return False
        if cp==TALLY_CP and mode=='manual':
            if cps:tallies[-1]=min(8,tallies[-1]+1)
            last_scalable=-1;tally_started=True
            return True
        push(cp);return True
    i=0;sbody=str(body)
    while i<len(sbody):
        ch=sbody[i]
        if ch.isspace():
            if not flush():return None
            i+=1;continue
        marker=ord(ch) if vulgar and ord(ch) in VULGAR_SCALE_MARKERS else None
        if marker is not None:
            if not flush() or last_scalable<0 or tally_started or scales[last_scalable] is not None:return None
            scales[last_scalable]=marker;i+=1;continue
        alias=None
        if vulgar and i+3<=len(sbody):
            candidate=sbody[i:i+3]; m=ASCII_SCALE_ALIASES.get(candidate)
            nxt=sbody[i+3:i+4]
            if m is not None and not (nxt and nxt in '0123456789/'):
                alias=m
        if alias is not None:
            had=bool(''.join(cur).strip())
            if had and not flush():return None
            if last_scalable>=0:
                if tally_started or scales[last_scalable] is not None:return None
                scales[last_scalable]=alias;i+=3;continue
        if ch in '.·:':
            if not flush():return None
            push(COLON_CP if ch==':' else MIDDLE_DOT_CP);i+=1;continue
        if ch==',':
            if not flush():return None
            tally_started=True;last_scalable=-1
            if not p.cartouche_comma_tally_marks:i+=1;continue
            if mode=='manual':
                if cps:tallies[-1]=min(8,tallies[-1]+1)
            elif mode=='comma':push(ord(','),scalable=False)
            else:push(TALLY_CP,scalable=False)
            i+=1;continue
        cur.append(ch);i+=1
    if not flush() or not cps:return None
    return OrdinaryCartouche(tuple(cps),tuple(tallies),mode,tuple(scales))


# HarfBuzz is used only for complete-run cluster/caret geometry and vector outlines.
class _HBGlyphInfo(ctypes.Structure):
    _fields_=[('codepoint',ctypes.c_uint32),('mask',ctypes.c_uint32),('cluster',ctypes.c_uint32),('var1',ctypes.c_uint32),('var2',ctypes.c_uint32)]
class _HBGlyphPos(ctypes.Structure):
    _fields_=[('x_advance',ctypes.c_int32),('y_advance',ctypes.c_int32),('x_offset',ctypes.c_int32),('y_offset',ctypes.c_int32),('var',ctypes.c_uint32)]
@dataclass(frozen=True)
class _ShapedGlyph:
    gid:int; cluster:int; x_advance:int; y_advance:int; x_offset:int; y_offset:int

_HB=None
def _hb_lib():
    global _HB
    if _HB is not None:return _HB
    name=ctypes.util.find_library('harfbuzz')
    if not name:raise RuntimeError('libharfbuzz is required for full-renderer vector/tally geometry')
    h=ctypes.CDLL(name)
    h.hb_blob_create.argtypes=[ctypes.c_void_p,ctypes.c_uint,ctypes.c_int,ctypes.c_void_p,ctypes.c_void_p];h.hb_blob_create.restype=ctypes.c_void_p
    h.hb_face_create.argtypes=[ctypes.c_void_p,ctypes.c_uint];h.hb_face_create.restype=ctypes.c_void_p
    h.hb_face_get_upem.argtypes=[ctypes.c_void_p];h.hb_face_get_upem.restype=ctypes.c_uint
    h.hb_font_create.argtypes=[ctypes.c_void_p];h.hb_font_create.restype=ctypes.c_void_p
    h.hb_ot_font_set_funcs.argtypes=[ctypes.c_void_p];h.hb_font_set_scale.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_int]
    h.hb_buffer_create.restype=ctypes.c_void_p;h.hb_buffer_add_utf8.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_int,ctypes.c_uint,ctypes.c_int];h.hb_buffer_guess_segment_properties.argtypes=[ctypes.c_void_p]
    h.hb_feature_from_string.argtypes=[ctypes.c_char_p,ctypes.c_int,ctypes.c_void_p];h.hb_feature_from_string.restype=ctypes.c_int
    h.hb_shape.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_uint]
    h.hb_buffer_get_glyph_infos.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_uint)];h.hb_buffer_get_glyph_infos.restype=ctypes.POINTER(_HBGlyphInfo)
    h.hb_buffer_get_glyph_positions.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_uint)];h.hb_buffer_get_glyph_positions.restype=ctypes.POINTER(_HBGlyphPos)
    for f in ('hb_buffer_destroy','hb_font_destroy','hb_face_destroy','hb_blob_destroy'):getattr(h,f).argtypes=[ctypes.c_void_p]
    _HB=h;return h

class _HBFeature(ctypes.Structure):
    _fields_=[('tag',ctypes.c_uint32),('value',ctypes.c_uint32),('start',ctypes.c_uint),('end',ctypes.c_uint)]

def _shape_hb(font_path:Path,text:str,features:Sequence[str]=())->Tuple[int,Tuple[_ShapedGlyph,...]]:
    h=_hb_lib();data=Path(font_path).read_bytes();cdata=ctypes.create_string_buffer(data);blob=face=font=buf=None
    try:
        blob=h.hb_blob_create(ctypes.cast(cdata,ctypes.c_void_p),len(data),0,None,None);face=h.hb_face_create(blob,0);upem=int(h.hb_face_get_upem(face));font=h.hb_font_create(face);h.hb_ot_font_set_funcs(font);h.hb_font_set_scale(font,upem,upem);buf=h.hb_buffer_create();b=text.encode('utf-8');h.hb_buffer_add_utf8(buf,b,len(b),0,len(b));h.hb_buffer_guess_segment_properties(buf)
        arr=None;nfeat=0
        if features:
            vals=[]
            for f in features:
                ft=_HBFeature()
                if h.hb_feature_from_string(str(f).encode(),-1,ctypes.byref(ft)):vals.append(ft)
            if vals:arr=(_HBFeature*len(vals))(*vals);nfeat=len(vals)
        h.hb_shape(font,buf,arr,nfeat);n=ctypes.c_uint();infos=h.hb_buffer_get_glyph_infos(buf,ctypes.byref(n));pos=h.hb_buffer_get_glyph_positions(buf,ctypes.byref(n));glyphs=tuple(_ShapedGlyph(int(infos[i].codepoint),int(infos[i].cluster),int(pos[i].x_advance),int(pos[i].y_advance),int(pos[i].x_offset),int(pos[i].y_offset)) for i in range(n.value));return upem,glyphs
    finally:
        if buf:h.hb_buffer_destroy(buf)
        if font:h.hb_font_destroy(font)
        if face:h.hb_face_destroy(face)
        if blob:h.hb_blob_destroy(blob)

def _byte_offset_for_cp_index(text:str,index:int)->int:return len(''.join(list(text)[:max(0,index)]).encode('utf-8'))
def _caret_x_complete(font_path:Path,text:str,font_px:float,cp_index:int,features:Sequence[str]=())->float:
    upem,g=_shape_hb(font_path,text,features);boundary=_byte_offset_for_cp_index(text,cp_index);x=0
    for q in g:
        if q.cluster>=boundary:break
        x+=q.x_advance
    return x*font_px/upem

def _vector_path(font_path:Path,text:str,font_px:float,features:Sequence[str]=())->Tuple[str,float,float,float]:
    upem,glyphs=_shape_hb(font_path,text,features);tt=TTFont(str(font_path),lazy=True);order=tt.getGlyphOrder();gs=tt.getGlyphSet();scale=font_px/upem;x=0;y=0;commands=[];minx=miny=float('inf');maxx=maxy=float('-inf')
    try:
        from fontTools.pens.boundsPen import BoundsPen
        for q in glyphs:
            if q.gid>=len(order):x+=q.x_advance;continue
            name=order[q.gid]; bp=BoundsPen(gs); gs[name].draw(bp); b=bp.bounds
            tx=(x+q.x_offset)*scale; ty=-(y+q.y_offset)*scale
            if b:
                x0,y0,x1,y1=b; X0=tx+x0*scale; X1=tx+x1*scale; Y0=ty-y1*scale; Y1=ty-y0*scale;minx=min(minx,X0);maxx=max(maxx,X1);miny=min(miny,Y0);maxy=max(maxy,Y1)
            pen=SVGPathPen(gs);tpen=TransformPen(pen,(scale,0,0,-scale,tx,ty));gs[name].draw(tpen);cmd=pen.getCommands()
            if cmd:commands.append(cmd)
            x+=q.x_advance;y+=q.y_advance
    finally:tt.close()
    if minx==float('inf'):minx=miny=0;maxx=maxy=max(1,font_px)
    # Normalize to a positive local box.
    dx=-minx;dy=-miny
    # SVG path strings cannot be translated textually safely; wrap all glyph paths in a group transform later.
    return ' '.join(commands),dx,dy,max(1,maxx-minx)


def _features_for(font_px:float)->Tuple[str,...]:
    # Protocol v1.1: cartouche scale is carried by inline vulgar-fraction controls.
    return ()

def _load_font(path:Path,size:float)->ImageFont.FreeTypeFont:
    return ImageFont.truetype(str(path),size=max(1,int(round(size))),layout_engine=ImageFont.Layout.RAQM)

def _text_bbox(text:str,font:ImageFont.FreeTypeFont,features:Sequence[str]=())->Tuple[int,int,int,int]:
    im=Image.new('L',(1,1));d=ImageDraw.Draw(im)
    kwargs={'anchor':'ls'}
    if features:kwargs['features']=list(features)
    try:return tuple(map(int,d.textbbox((0,0),text or ' ',font=font,**kwargs)))
    except Exception:return tuple(map(int,d.textbbox((0,0),text or ' ',font=font,anchor='ls')))

def _render_text_local(text:str,font_path:Path,font_px:float,features:Sequence[str],fill:_RGBA)->Tuple[Image.Image,float,str,float,float]:
    font=_load_font(font_path,font_px);l,t,r,b=_text_bbox(text,font,features);w=max(1,r-l);h=max(1,b-t);im=Image.new('RGBA',(w,h),(0,0,0,0));d=ImageDraw.Draw(im);kwargs={'anchor':'ls'}
    if features:kwargs['features']=list(features)
    try:d.text((-l,-t),text or ' ',font=font,fill=fill,**kwargs)
    except Exception:d.text((-l,-t),text or ' ',font=font,fill=fill,anchor='ls')
    baseline=-t
    try:path,dx,dy,_=_vector_path(font_path,text,font_px,features)
    except Exception:path='';dx=-l;dy=-t
    # path baseline is y=0 before normalization; translate by vector dx/dy when emitted.
    return im,float(baseline),path,float(dx),float(dy)

def _synthetic_corner_bracket_local(codepoint:int,font_px:float,fill:_RGBA)->Tuple[Image.Image,float,str,float,float]:
    """Render the canonical synthetic U+300C/U+300D bracket used by the JS reference.

    linja pona and linja sike intentionally request ``cornerBracketMode=synthetic``
    because their legacy font inputs do not contain reliable U+300C/U+300D glyphs.
    The geometry below mirrors the canonical browser renderer's
    ``measureSyntheticCornerBracket`` / ``drawSyntheticCornerBracket`` contract.
    """
    cp=int(codepoint)
    if cp not in (OPEN_QUOTE_CP,CLOSE_QUOTE_CP):
        raise ValueError(f'not a corner bracket codepoint: U+{cp:04X}')
    px=max(1.0,float(font_px))
    width=max(1,int(math.ceil(px*.36)))
    height=max(1,int(math.ceil(px*.76)))
    is_right=cp==CLOSE_QUOTE_CP
    stroke=max(1.0,px*.065) if px<=12 else max(2.5,px*.065)
    pad=max(.5,stroke*.5)
    x_left=pad
    x_right=width-pad
    lift=0.0 if is_right else max(4.0,px*.18)
    baseline=height*.82+lift
    y_top=0.0
    y_bottom=float(height)
    arm=max(px*.26,min(width*.82,px*.48))

    # Raster form: filled rectangles are the same geometry used by the canonical
    # vector exporter and avoid ever asking the legacy font for a missing glyph.
    scale=4
    im_hi=Image.new('RGBA',(width*scale,height*scale),(0,0,0,0))
    draw=ImageDraw.Draw(im_hi)
    def rect(x:float,y:float,w:float,h:float)->None:
        draw.rectangle((round(x*scale),round(y*scale),round((x+w)*scale)-1,round((y+h)*scale)-1),fill=fill)
    if is_right:
        rect(x_right-stroke,y_top,stroke,height)
        rect(x_right-arm,y_bottom-stroke,arm,stroke)
        path=(f'M {x_right-stroke:.6f} {y_top:.6f} h {stroke:.6f} v {height:.6f} h {-stroke:.6f} Z '
              f'M {x_right-arm:.6f} {y_bottom-stroke:.6f} h {arm:.6f} v {stroke:.6f} h {-arm:.6f} Z')
    else:
        rect(x_left,y_top,stroke,height)
        rect(x_left,y_top,arm,stroke)
        path=(f'M {x_left:.6f} {y_top:.6f} h {stroke:.6f} v {height:.6f} h {-stroke:.6f} Z '
              f'M {x_left:.6f} {y_top:.6f} h {arm:.6f} v {stroke:.6f} h {-arm:.6f} Z')
    try:
        resample=Image.Resampling.LANCZOS
    except AttributeError:
        resample=Image.LANCZOS
    im=im_hi.resize((width,height),resample=resample)
    return im,float(baseline),path,0.0,0.0


def _uses_synthetic_corner_bracket(pair:FontPairSpec,canonical:Sequence[int],raw_bypass:bool=False)->Optional[int]:
    if raw_bypass or len(canonical)!=1:
        return None
    cp=int(canonical[0])
    if cp not in (OPEN_QUOTE_CP,CLOSE_QUOTE_CP):
        return None
    mode=str((pair.render_adapter_settings or {}).get('cornerBracketMode') or '').strip().lower()
    return cp if mode=='synthetic' else None


def _render_cartouche_text_local(text:str,font_path:Path,font_px:float,features:Sequence[str],fill:_RGBA,*,has_manual_tallies:bool=False)->Tuple[Image.Image,float,str,float,float,float]:
    """Render a cartouche using the canonical JS cartouche-canvas coordinates.

    The browser renderer crops to the actual foreground ink, then places that
    crop inside a six-pixel cartouche pad.  The resulting baseline text origin
    is therefore ``6 - ink_left``.  Manual tally ownership must use this same
    origin; measuring against the uncropped font run is what caused the old
    font-dependent horizontal displacement (most visibly with linja lipamanka).
    """
    raw,baseline,path,vdx,vdy=_render_text_local(text,font_path,font_px,features,fill)
    alpha=raw.getchannel('A');bbox=alpha.getbbox()
    if bbox:
        x0,y0,x1,y1=bbox
    else:
        x0=y0=0;x1=max(1,raw.width);y1=max(1,raw.height)
    crop=raw.crop((x0,y0,x1,y1))
    pad=6
    bottom_extra=int(math.ceil(font_px*.34)) if has_manual_tallies else 0
    out=Image.new('RGBA',(max(1,crop.width+pad*2),max(1,crop.height+pad*2+bottom_extra)),(0,0,0,0))
    out.alpha_composite(crop,(pad,pad))
    baseline=float(baseline-y0+pad)
    text_origin_x=float(pad-x0)
    # Vector outlines are normalized to their own ink bbox; place that ink at
    # the same six-pixel padded origin used by the raster cartouche.
    return out,baseline,path,float(vdx+pad),float(vdy+pad),text_origin_x


def _halo_alpha(alpha:Image.Image,width:float)->Image.Image:
    radius=max(1,int(math.ceil(width)));size=radius*2+1
    return alpha.filter(ImageFilter.MaxFilter(size))

@dataclass
class _Graphic:
    image:Image.Image; baseline:float; vector_path:str=''; vector_dx:float=0; vector_dy:float=0; tally_groups:Tuple[TallyGroup,...]=(); image_href:Optional[str]=None; decoration:Optional[Dict[str,Any]]=None
    @property
    def width(self):return self.image.width
    @property
    def height(self):return self.image.height
@dataclass
class _Logical:
    run:FullRenderRun; graphic:_Graphic


def _manual_tally_lift(pair:FontPairSpec,p:ParseOptions,px:float)->float:
    try:maxv=p.manual_tally_small_font_max_px if p.manual_tally_small_font_max_px is not None else float(pair.settings.get('manualTallySmallFontMaxPx',12))
    except Exception:maxv=12
    try:lift=p.manual_tally_small_font_lift_px if p.manual_tally_small_font_lift_px is not None else float(pair.settings.get('manualTallySmallFontLiftPx',0))
    except Exception:lift=0
    return max(0,lift) if px<=maxv else 0.0

def _detect_bottom_rule_y(alpha:Image.Image,font_px:float)->float:
    bbox=alpha.getbbox()
    if not bbox:return float(alpha.height)
    x0,y0,x1,y1=bbox;span=max(1,x1-x0);threshold=max(4,round(span*.18));pix=alpha.load();start=max(0,min(alpha.height-1,int((y0+y1)/2)))
    for y in range(alpha.height-1,start-1,-1):
        count=sum(1 for x in range(x0,x1) if pix[x,y]>8)
        if count>=threshold:return y+1.0
    return float(y1)


def _parse_size(v:Optional[str],base:float)->float:
    if not v:return float('nan')
    s=v.strip().lower()
    try:
        if s.endswith('em'):return float(s[:-2])*base
        if s.endswith('px'):return float(s[:-2])
        return float(s)
    except Exception:return float('nan')

def _load_inline_image(desc:ImageDescriptor,font_px:float)->Image.Image:
    src=None
    href=desc.src or ''
    try:
        if href.startswith('data:image/') and ',' in href:
            meta,data=href.split(',',1);raw=base64.b64decode(data) if ';base64' in meta else urllib.parse.unquote_to_bytes(data);src=Image.open(BytesIO(raw)).convert('RGBA')
        elif href and Path(href).is_file():src=Image.open(href).convert('RGBA')
    except Exception:src=None
    if src is None:src=Image.new('RGBA',(1,1),(0,0,0,0))
    w=_parse_size(desc.w,font_px);h=_parse_size(desc.h,font_px)
    if math.isnan(w) and math.isnan(h):h=font_px
    if math.isnan(w):w=max(1,h*src.width/max(1,src.height))
    if math.isnan(h):h=max(1,w*src.height/max(1,src.width))
    out=src.resize((max(1,round(w)),max(1,round(h))),Image.Resampling.BILINEAR)
    if desc.transparent:
        key=out.getpixel((0,0));tol=max(0,int(desc.wriggle));pix=out.load()
        for y in range(out.height):
            for x in range(out.width):
                c=pix[x,y]
                if all(abs(c[i]-key[i])<=tol for i in range(3)) and abs(c[3]-key[3])<=max(8,tol):pix[x,y]=(c[0],c[1],c[2],0)
    return out


def _proper_name_cps(word:str)->Optional[List[int]]:
    if not re.fullmatch(r'[A-Za-z]+',word or '') or not re.fullmatch(r'(?i)[aeijklmnostpuw]+',word or ''):return None
    bucket={}
    for w in sorted(getattr(legacy,'WORDS_TO_UNC_CODES_MAP',{})):
        if re.fullmatch(r'[a-z]+',w) and w:
            cp=_cp_for_word(w)
            if cp is not None:bucket.setdefault(w[0],cp)
    out=[]
    for c in word.lower():
        if c not in bucket:return None
        out.append(bucket[c])
    return out

def _nnp_words(digits:str)->List[str]:
    try:n=int(digits)
    except Exception:return []
    if n<0:return []
    out=[]
    def enc(x:int):
        if x==0:out.append('ala');return
        if x>=100:
            q,r=divmod(x,100);enc(q);out.append('ali')
            if r:enc(r)
            return
        while x>=20:out.append('mute');x-=20
        if x>=5:out.append('luka');x-=5
        while x>=2:out.append('tu');x-=2
        if x:out.append('wan')
    enc(n);return out

class FullRenderer:
    def __init__(self,pairs:Mapping[str,FontPairSpec],aliases:Mapping[str,str],runtime_adapters:Dict[str,Callable[[Sequence[int],FontPairSpec,float],Sequence[int]]],support_fonts:Mapping[str,SupportFontSpec]|None=None):
        self.pairs=dict(pairs);self.aliases=dict(aliases);self.runtime_adapters=runtime_adapters;self.support_fonts=dict(support_fonts or {})
    def support_font(self,key:str)->Optional[SupportFontSpec]:
        return self.support_fonts.get(key)
    def pair(self,key:str)->FontPairSpec:
        if key in self.pairs:return self.pairs[key]
        norm=re.sub(r'[^a-z0-9]+','',str(key).lower());k=self.aliases.get(norm)
        if k:return self.pairs[k]
        raise KeyError(key)
    def parse_input(self, input_text: str, opts: FullRenderOptions) -> DocumentAst:
        ast = parse_document(input_text, opts.parser)
        lines: List[DocumentLine] = []
        for line in ast.lines:
            children: List[DocumentSegment] = []
            for segment in line.children:
                structures: List[Mapping[str, Any]] = []
                if segment.kind == "text":
                    source = str(segment.value or "")
                    for st, en, hit_kind, parsed in self._scan_canonical_numeric_hits(source, opts.parser):
                        structures.append({
                            "kind": str(hit_kind or parsed.get("kind") or parsed.get("semanticKind") or "number"),
                            "index": int(st),
                            "end": int(en),
                            "sourceText": source[st:en],
                            "semanticKind": parsed.get("semanticKind"),
                            "semanticStartGlyph": parsed.get("semanticStartGlyph"),
                            "nasinNanpaPonaWords": list(parsed.get("nasinNanpaPonaWords") or []) or None,
                        })
                elif segment.kind == "bracket":
                    source = f"[{str(segment.value or '')}]"
                    parsed = self._numeric_parsed(source, opts.parser)
                    if parsed:
                        structures.append({
                            "kind": str(parsed.get("kind") or parsed.get("semanticKind") or "number"),
                            "index": 0,
                            "end": len(source),
                            "sourceText": source,
                            "semanticKind": parsed.get("semanticKind"),
                            "semanticStartGlyph": parsed.get("semanticStartGlyph"),
                            "wholeSegment": True,
                        })
                children.append(replace(segment, numeric_structures=tuple(structures)))
            lines.append(replace(line, children=tuple(children)))
        return replace(ast, lines=tuple(lines))

    def _numeric_parsed(self,source:str,p:ParseOptions)->Optional[Dict[str,Any]]:
        try:return NanpaParser.parseNumber(source,p.numeric_mapping())
        except Exception:return None
    def _numeric_active(self,parsed:Mapping[str,Any],p:ParseOptions)->Tuple[Tuple[int,...],Tuple[int,...]]:
        full=tuple(map(int,parsed.get('codepoints') or ()));inner=tuple(map(int,parsed.get('innerCodepoints') or ()))
        if p.abbreviate_numeric_cartouches and len(full)>=3:
            ab=legacy.abbreviate_numeric_cartouche_ucsur(''.join(chr(x) for x in full[1:-1]),preserve_nene_as_en=p.preserve_numeric_cartouche_breaks_in_abbreviation)
            full=(CARTOUCHE_START,*map(ord,ab),CARTOUCHE_END);inner=tuple(map(ord,ab))
        return tuple(full),tuple(inner)

    def _glyph_run(self,source:str,cps:Sequence[int],start:int,end:int,source_kind:str,pair:FontPairSpec,o:FullRenderOptions,quoted=False,interpreted=False)->_Logical:
        canonical=tuple(map(int,cps)); raw_bypass=parse_raw_unicode_sequence((source or '').strip()) is not None
        if raw_bypass:
            render=canonical; adapter_id='identity'
        else:
            adapter=self.runtime_adapters.get(pair.render_adapter_id)
            render=tuple(map(int,adapter(canonical,pair,o.font_size))) if adapter else _adapt_builtin_full_word_run(pair,canonical)
            adapter_id=pair.render_adapter_id
        text=''.join(chr(x) for x in render)
        synthetic_cp=_uses_synthetic_corner_bracket(pair,canonical,raw_bypass)
        if synthetic_cp is not None:
            im,baseline,path,vdx,vdy=_synthetic_corner_bracket_local(synthetic_cp,o.font_size,_rgba_from_hex(o.paint.fill_style))
        else:
            im,baseline,path,vdx,vdy=_render_text_local(text,pair.base.path,o.font_size,(),_rgba_from_hex(o.paint.fill_style))
        kind_value='run' if raw_bypass or canonical==(ord(','),) or len(canonical)>1 or len(render)>1 else 'glyph'
        r=FullRenderRun(kind=kind_value,render_mode='text',font_role='word',canonical_codepoints=canonical,render_codepoints=render,render_text=text,render_adapter_id=adapter_id,source_text=source,source_kind=source_kind,source_start=start,source_end=end,quoted=quoted,interpreted_quote=interpreted)
        return _Logical(r,_Graphic(im,baseline,path,vdx,vdy))

    def _literal_rendered_run(self,render_text:str,source:str,start:int,end:int,source_kind:str,pair:FontPairSpec,o:FullRenderOptions,quoted=False,interpreted=False,unknown=False)->_Logical:
        support=self.support_font('literalText');font_path=support.path if support and support.path.exists() else pair.base.path
        im,baseline,path,vdx,vdy=_render_text_local(render_text or ' ',font_path,o.font_size,(),_rgba_from_hex(o.paint.fill_style));dec=None
        if unknown:
            us=o.paint.unknown_text;pad=max(0,round(us.padding_px));canvas=Image.new('RGBA',(im.width+2*pad,im.height+2*pad),(0,0,0,0));canvas.alpha_composite(im,(pad,pad));draw=ImageDraw.Draw(canvas);draw.rectangle((0,0,canvas.width-1,canvas.height-1),outline=_rgba_from_hex(us.color),width=max(1,round(us.line_width_px)));im=canvas;baseline+=pad;dec={'outline':True,'color':us.color}
        role='unknown' if unknown and source_kind=='interpretedQuote' else 'literal'
        r=FullRenderRun(kind='text',render_mode='raster',font_role=role,render_adapter_id='identity',source_text=source,source_kind=source_kind,source_start=start,source_end=end,quoted=quoted,interpreted_quote=interpreted,unrecognized=unknown,render_text=render_text)
        return _Logical(r,_Graphic(im,baseline,path,vdx,vdy,decoration=dec))

    def _literal_run(self,source:str,start:int,end:int,source_kind:str,pair:FontPairSpec,o:FullRenderOptions,quoted=False,interpreted=False,unknown=False)->_Logical:
        return self._literal_rendered_run(source,source,start,end,source_kind,pair,o,quoted,interpreted,unknown)

    def _numeric_run(self,source:str,parsed:Mapping[str,Any],start:int,end:int,source_kind:str,pair:FontPairSpec,o:FullRenderOptions)->_Logical:
        full,inner=self._numeric_active(parsed,o.parser)
        # Keep semantic render-codepoint metadata aligned with the canonical JS
        # conformance corpus. Protocol-v1.1 vulgar-fraction scaling is a
        # post-adapter, font-facing transformation used only for actual drawing.
        semantic_adapted=adapt_numeric_cartouche(full,pair.render_adapter_id,pair.render_adapter_settings)
        adapted=adapt_numeric_cartouche(full,pair.render_adapter_id,pair.render_adapter_settings,font_settings=pair.settings)
        features=_features_for(o.font_size)
        im,baseline,path,vdx,vdy,_=_render_cartouche_text_local(adapted.text,pair.companion.path,o.font_size,features,_rgba_from_hex(o.paint.fill_style))
        base=int(parsed.get('numberBase') or 10)
        r=FullRenderRun(kind='cartouche',render_mode='raster',font_role='number',numeric_cartouche=True,hex_cartouche=bool(parsed.get('isHex')),binary_cartouche=bool(parsed.get('isBinary')),numeric_base=base,opener_codepoint=inner[0] if inner else None,closer_codepoint=inner[-1] if inner else None,canonical_codepoints=inner,render_codepoints=tuple(map(ord,semantic_adapted.text)),render_text=adapted.text,render_adapter_id=pair.render_adapter_id,source_text=source,source_kind=source_kind,source_start=start,source_end=end)
        return _Logical(r,_Graphic(im,baseline,path,vdx,vdy))

    def _cartouche_run(self,source:str,oc:OrdinaryCartouche,start:int,end:int,source_kind:str,pair:FontPairSpec,o:FullRenderOptions)->_Logical:
        adapted=_adapt_ordinary(pair,oc.inner_codepoints);adapted=_apply_ordinary_scale_markers(adapted,oc.scale_markers);fill=_rgba_from_hex(o.paint.fill_style);im,baseline,path,vdx,vdy,owner_origin_x=_render_cartouche_text_local(adapted.text,pair.base.path,o.font_size,(),fill,has_manual_tallies=oc.has_manual_tallies);groups=[]
        if oc.has_manual_tallies:
            # Complete-run ownership: U+F199E is never inserted for manual-tally
            # fonts.  Canonical spans map each owner to its adapted substring.  The
            # owner advance is translated by the *same* ink-crop/pad text origin
            # used for raster drawing, matching the canonical browser renderer.
            #
            # IMPORTANT: do not paint the tally strokes into the cartouche image
            # itself.  Manual tally marks are renderer-owned geometry so the halo
            # pass can draw a rounded group backing first and the foreground pass
            # can then draw the non-halo tally strokes on top, matching the JS
            # reference for both PNG and SVG/PDF.
            bottom=_detect_bottom_rule_y(im.getchannel('A'),o.font_size);lift=_manual_tally_lift(pair,o.parser,o.font_size);top=bottom-lift;bot=top+o.font_size*.10;stroke=max(1.5,o.font_size*.045);gap=o.font_size*.075
            for i,count in enumerate(oc.manual_tallies):
                count=max(0,min(8,int(count)))
                if count<=0:continue
                span=adapted.canonical_spans[i+1];left=owner_origin_x+_caret_x_complete(pair.base.path,adapted.text,o.font_size,span[0]);right=owner_origin_x+_caret_x_complete(pair.base.path,adapted.text,o.font_size,span[1]);center=(left+right)/2;total=stroke if count<=1 else count*stroke+(count-1)*gap;first=center-total/2+stroke/2;centers=tuple(first+k*(stroke+gap) for k in range(count));need_h=int(math.ceil(bot+2));
                if need_h>im.height:
                    ext=Image.new('RGBA',(im.width,need_h),(0,0,0,0));ext.alpha_composite(im);im=ext
                groups.append(TallyGroup(i,count,left,right,center,top,bot,stroke,centers))
        canonical=tuple(oc.inner_codepoints);semantic=tuple(oc.manual_tallies) if oc.has_manual_tallies else ();r=FullRenderRun(kind='cartouche',render_mode='raster',font_role='cartouche',opener_codepoint=CARTOUCHE_START,closer_codepoint=CARTOUCHE_END,canonical_codepoints=canonical,render_codepoints=tuple(map(ord,adapted.text)),render_text=adapted.text,render_adapter_id=pair.render_adapter_id,source_text=source,source_kind=source_kind,source_start=start,source_end=end,manual_tallies=semantic)
        return _Logical(r,_Graphic(im,baseline,path,vdx,vdy,tuple(groups)))

    def _image_run(self,seg:DocumentSegment,pair:FontPairSpec,o:FullRenderOptions)->_Logical:
        d=seg.image or ImageDescriptor();im=_load_inline_image(d,o.font_size);baseline=im.height*.75 if d.valign.lower()=='center' else im.height;r=FullRenderRun(kind='cartouche',render_mode='raster',font_role='cartouche',render_adapter_id=pair.render_adapter_id,source_text='',source_kind='image',source_start=seg.source_start,source_end=seg.source_end,image_alt=d.alt)
        return _Logical(r,_Graphic(im,baseline,image_href=d.src))

    def _emit_core(self,core:str,start:int,end:int,kind:str,seg_index:int,out:List[_Logical],pair:FontPairSpec,o:FullRenderOptions):
        direct=[ord(c) for c in core]
        if direct and all((0xF1900<=cp<=0xF19FF) or cp in (OPEN_QUOTE_CP,CLOSE_QUOTE_CP) for cp in direct):
            out.append(self._glyph_run(core,direct,start,end,kind,pair,o)); return
        alias=GLYPH_INPUT_ALIASES.get(core.strip().lower())
        if alias:
            cp=_full_glyph_cp(alias)
            if cp is not None: out.append(self._glyph_run(core,[cp],start,end,kind,pair,o))
            return
        key=_normalize_full_glyph_key(core)
        if key=='zz':
            out.append(self._literal_rendered_run('\u3000',core,start,end,kind,pair,o)); return
        if key in ('te','to'):
            cp=_full_glyph_cp(key)
            if cp is not None: out.append(self._glyph_run(core,[cp],start,end,kind,pair,o))
            return
        parsed=self._numeric_parsed(core,o.parser)
        if parsed:
            if o.parser.nasin_nanpa_pona and re.fullmatch(r'\+?[0-9]+',core):
                for w in _nnp_words(core.lstrip('+')):
                    cp=_cp_for_word(w)
                    if cp is not None: out.append(self._glyph_run(core,[cp],start,end,kind,pair,o))
            else: out.append(self._numeric_run(core,parsed,start,end,kind,pair,o))
            return
        if o.parser.auto_cartouche_standalone_proper_names and core and core[0].isupper():
            cps=_proper_name_cps(core)
            if cps:
                out.append(self._cartouche_run(core,OrdinaryCartouche(tuple(cps),tuple(0 for _ in cps),'ucsur'),start,end,kind,pair,o)); return
        cp=_full_glyph_cp(key)
        if cp is not None:
            if key!=',': out.append(self._glyph_run(core,[cp],start,end,kind,pair,o))
            return
        if o.parser.show_unknown_text:
            literal=core;ls=start;le=end
            if o.parser.renderer_mode=='standard-sitelen-pona-ascii-core' and len(literal)>=2 and literal.startswith("'") and literal.endswith("'"):
                literal=literal[1:-1];ls+=1;le-=1
            out.append(self._literal_run(literal,ls,le,kind,pair,o,unknown=True))

    @staticmethod
    def _fallback_core_char(ch:str,numeric_like:bool)->bool:
        if ch.isascii() and ch.isalnum(): return True
        if ch in '#~^<>': return True
        if ch in '.,_-': return numeric_like
        return False

    def _split_fallback_token(self,token:str):
        numeric_like=bool(re.search(r'[0-9]|^-?\.\d|^-?\d',token))
        a=0;b=len(token)
        while a<b and not self._fallback_core_char(token[a],numeric_like): a+=1
        while b>a and not self._fallback_core_char(token[b-1],numeric_like): b-=1
        while b>a and token[b-1] in ')]}.,;:!?': b-=1
        return token[:a],token[a:b],token[b:],a,b

    def _emit_fallback_punct(self,punct:str,source_start:int,kind:str,out:List[_Logical],pair:FontPairSpec,o:FullRenderOptions):
        for off,ch in enumerate(punct):
            cp=MIDDLE_DOT_CP if ch in ('.','·') else COLON_CP if ch==':' else None
            if cp is not None:
                out.append(self._glyph_run(ch,[cp],source_start+off,source_start+off+1,kind,pair,o))
            elif ch==',':
                # U+002C is an ordinary visible comma outside cartouches in v1.1.
                out.append(self._glyph_run(ch,[ord(',')],source_start+off,source_start+off+1,kind,pair,o))

    def _render_tp_words_fallback(self,text:str,base:int,kind:str,seg_index:int,out:List[_Logical],pair:FontPairSpec,o:FullRenderOptions):
        if not text or not text.strip(): return
        for m in re.finditer(r'[^\s\u2010\u2011\u2012\u2013\u2014\u2212\uFE63\uFF0D]+',text):
            token=m.group();lead,core,trail,cs,ce=self._split_fallback_token(token)
            self._emit_fallback_punct(lead,base+m.start(),kind,out,pair,o)
            if core and core not in ('&','+','-'): self._emit_core(core,base+m.start()+cs,base+m.start()+ce,kind,seg_index,out,pair,o)
            self._emit_fallback_punct(trail,base+m.start()+ce,kind,out,pair,o)

    @staticmethod
    def _numeric_hit_priority(kind:str)->int:
        return {'hex':6,'binary':6,'date':5,'decimal':4,'time':4,'tpPhrase':3,'code':2}.get(kind,1)

    @staticmethod
    def _horizontal_only(s:str,a:int,b:int)->bool:
        return 0<=a<=b<=len(s) and all(ch in ' \t' for ch in s[a:b])

    def _scan_proper_name_hits(self,s:str,p:ParseOptions):
        words=[(m.group(),m.start(),m.end()) for m in re.finditer(r'[A-Za-z]+',s)]
        hits=[];i=0
        while i<len(words):
            raw,st,en=words[i]
            if not raw or not raw[0].isupper():i+=1;continue
            low=raw.lower();colon=p.nanpa_colon_parsing or p.nanpa_colon_rendering
            starts_legacy=low.startswith('ne');starts_hex=p.enable_hex_parsing and low.startswith('nasa')
            starts_bin=(p.enable_binary_parsing or p.enable_binary_rendering) and low.startswith('noka')
            starts_typed=colon and (raw=='Nanpa' or raw.startswith('Nanpa') or raw in ('Tenpo','Suno','Toki'))
            if not (starts_legacy or starts_hex or starts_bin or starts_typed):i+=1;continue
            best=-1;best_parsed=None;limit=min(len(words)-1,i+30)
            if starts_typed and not starts_hex and not starts_bin:limit=min(limit,i+20)
            for j in range(i,limit+1):
                if j>i and (not words[j][0][0].isupper() or not self._horizontal_only(s,words[j-1][2],words[j][1])):break
                candidate=s[st:words[j][2]];parsed=self._numeric_parsed(candidate,p)
                if parsed:best=j;best_parsed=parsed
            if raw=='Toki' and best>=0 and best+1<len(words) and words[best+1][0][0].isupper() and self._horizontal_only(s,words[best][2],words[best+1][1]):
                best=-1;best_parsed=None
            if best>=0 and best_parsed:
                hk='hex' if best_parsed.get('isHex') else 'binary' if best_parsed.get('isBinary') else 'name'
                hits.append((st,words[best][2],hk,best_parsed));i=best+1
            else:i+=1
        return hits

    def _scan_tp_phrase_hits(self,s:str,p:ParseOptions):
        toks=[]
        for m in re.finditer(r'\S+',s):
            mm=re.fullmatch(r'([A-Za-z]+)([)\]},.;:!?]*)',m.group())
            word=mm.group(1).lower() if mm else '';trail=mm.group(2) if mm else ''
            toks.append((word,m.start(),m.start()+len(word),trail))
        hits=[];i=0
        while i+2<len(toks):
            if toks[i][0]!='nanpa' or toks[i+1][0] not in ('e','en','esun'):i+=1;continue
            best=-1;parsed=None
            for j in range(i+2,len(toks)):
                if toks[j][0]!='nanpa':continue
                words=[];good=True
                for k in range(i,j+1):
                    if not toks[k][0] or (k<j and toks[k][3]):good=False;break
                    words.append(toks[k][0])
                if good:
                    r=_new_phrase_parse_result(words,p)
                    if r is not None:best=j;parsed=r
            if best>=0:
                hits.append((toks[i][1],toks[best][2],'tpPhrase',parsed));i=best+1
            else:i+=1
        return hits

    def _scan_glyph_numeric_suffix_hits(self,s:str,p:ParseOptions):
        hits=[]
        for m in re.finditer(r'[A-Za-z^<>]+[0-9]+',s):
            if m.start()>0 and (s[m.start()-1].isalnum() or s[m.start()-1] in '^<>'):continue
            if m.end()<len(s) and (s[m.end()].isalnum() or s[m.end()] in '^<>'):continue
            raw=m.group()
            if raw.lower() in GLYPH_INPUT_ALIASES:continue
            mm=re.fullmatch(r'(.+?)([0-9]+)',raw)
            if not mm:continue
            glyph,digits=mm.groups()
            if _full_glyph_cp(_normalize_full_glyph_key(glyph)) is None:continue
            parsed=self._numeric_parsed(digits,p)
            if parsed:hits.append((m.start()+len(glyph),m.end(),'decimal',parsed))
        return hits

    def _exhaustive_numeric_candidate_hits(self,s:str,p:ParseOptions):
        if not s:return []
        vulgar=set('¼½¾⅐⅑⅒⅓⅔⅕⅖⅗⅘⅙⅚⅛⅜⅝⅞')
        def word(ch):return ch.isalnum() or ch=='_'
        def plausible(i):return i<len(s) and (s[i].isdigit() or s[i] in '+-#.' or s[i] in vulgar or s[i] in 'Xx')
        def bstart(i):return i==0 or not word(s[i-1])
        def bend(i):return i==len(s) or not word(s[i])
        bad_terminal=set(').,;:!?]}')
        hits=[];seen=set()
        for a in range(len(s)):
            if not plausible(a) or not bstart(a):continue
            for b in range(a+1,min(len(s),a+512)+1):
                if not bend(b):continue
                segment=s[a:b]
                l=len(segment)-len(segment.lstrip());r=len(segment)-len(segment.rstrip())
                st=a+l;en=b-r
                if st>=en or not bstart(st) or not bend(en):continue
                raw=s[st:en]
                stripped=raw.strip()
                if not stripped or stripped in ('+','-') or stripped[-1] in bad_terminal:continue
                if any(ch.isspace() for ch in raw):
                    if not re.fullmatch(r'[+-]?[0-9][0-9,]*[ \t]+(?:[0-9]+/[0-9]+|[¼½¾⅐-⅞])',raw):continue
                parsed=self._numeric_parsed(raw,p)
                if not parsed:continue
                hk='date' if parsed.get('isDate') else 'time' if parsed.get('isTime') else 'hex' if parsed.get('isHex') else 'binary' if parsed.get('isBinary') else 'code' if raw.startswith('#~') else 'decimal'
                if (st,en) not in seen:seen.add((st,en));hits.append((st,en,hk,parsed))
        return hits

    @staticmethod
    def _protected_alias_spans(s:str):
        return [(m.start(),m.end()) for m in re.finditer(r'[A-Za-z0-9^<>]+',s) if m.group().lower() in GLYPH_INPUT_ALIASES]

    def _scan_canonical_numeric_hits(self,s:str,p:ParseOptions):
        all_hits=[]
        if not p.enable_binary_parsing and not p.enable_binary_rendering:
            for m in re.finditer(r'0b([01]+)',s):
                if m.start()>0 and (s[m.start()-1].isalnum() or s[m.start()-1]=='_'):continue
                prefix_end=m.start()+2;parsed=self._numeric_parsed(s[m.start():prefix_end],p)
                if parsed:all_hits.append((m.start(),prefix_end,'decimal',parsed))
                ds,de=m.start(1),m.end(1)
                if de>ds:
                    first=ds+1;parsed=self._numeric_parsed(s[ds:first],p)
                    if parsed:all_hits.append((ds,first,'decimal',parsed))
                    if first<de:
                        parsed=self._numeric_parsed(s[first:de],p)
                        if parsed:all_hits.append((first,de,'decimal',parsed))
        all_hits.extend(self._scan_glyph_numeric_suffix_hits(s,p))
        all_hits.extend(self._scan_proper_name_hits(s,p))
        all_hits.extend(self._scan_tp_phrase_hits(s,p))
        aliases=self._protected_alias_spans(s)
        for h in self._exhaustive_numeric_candidate_hits(s,p):
            if not any(h[0]<b and h[1]>a for a,b in aliases):all_hits.append(h)
        all_hits.sort(key=lambda h:(h[0],-(h[1]-h[0]),-self._numeric_hit_priority(h[2])))
        out=[];last_end=-1
        for h in all_hits:
            if h[0]<last_end:continue
            out.append(h);last_end=h[1]
        return out

    def _parse_text_base(self,text:str,base:int,kind:str,seg_index:int,out:List[_Logical],pair:FontPairSpec,o:FullRenderOptions):
        hits=self._scan_canonical_numeric_hits(text,o.parser)
        if not hits:
            self._render_tp_words_fallback(text,base,kind,seg_index,out,pair,o);return
        pos=0
        for st,en,hk,parsed in hits:
            if st>pos:self._render_tp_words_fallback(text[pos:st],base+pos,kind,seg_index,out,pair,o)
            raw=text[st:en]
            if o.parser.nasin_nanpa_pona and re.fullmatch(r'\+?[0-9]+',raw):
                for w in _nnp_words(raw.lstrip('+')):
                    cp=_cp_for_word(w)
                    if cp is not None:out.append(self._glyph_run(raw,[cp],base+st,base+en,kind,pair,o))
            else:out.append(self._numeric_run(raw,parsed,base+st,base+en,kind,pair,o))
            pos=en
        if pos<len(text):self._render_tp_words_fallback(text[pos:],base+pos,kind,seg_index,out,pair,o)

    def _parse_ssk_like_text(self,text:str,base:int,kind:str,seg_index:int,out:List[_Logical],pair:FontPairSpec,o:FullRenderOptions):
        pos=0
        for m in _SSK_SPECIAL_RE.finditer(text):
            cps=None
            if m.group(3) is not None: cps=_extended_glyph_cps(m.group(1) or '',m.group(2),m.group(3))
            elif m.group(4) is not None: cps=_glyph_expression_cps(m.group(4))
            elif m.group(5) is not None and m.group(6) is not None: cps=_extended_glyph_cps(m.group(5),m.group(6),'')
            if cps is None: continue
            if m.start()>pos: self._parse_text_base(text[pos:m.start()],base+pos,kind,seg_index,out,pair,o)
            out.append(self._glyph_run(m.group(),cps,base+m.start(),base+m.end(),kind,pair,o));pos=m.end()
        if pos<len(text): self._parse_text_base(text[pos:],base+pos,kind,seg_index,out,pair,o)

    def _parse_extended_text(self,text:str,base:int,kind:str,seg_index:int,out:List[_Logical],pair:FontPairSpec,o:FullRenderOptions):
        pos=0
        for m in _LEGACY_LONG_PI_RE.finditer(text):
            if m.start()>pos:self._parse_ssk_like_text(text[pos:m.start()],base+pos,kind,seg_index,out,pair,o)
            alias=m.group();inner=_legacy_long_pi_inner(alias)
            cps=_extended_glyph_cps('', 'pi', inner) if inner is not None else None
            if cps is not None: out.append(self._glyph_run(alias,cps,base+m.start(),base+m.end(),kind,pair,o))
            else:self._parse_ssk_like_text(alias,base+m.start(),kind,seg_index,out,pair,o)
            pos=m.end()
        if pos<len(text):self._parse_ssk_like_text(text[pos:],base+pos,kind,seg_index,out,pair,o)

    def _parse_standard_core_text(self,text:str,base:int,kind:str,seg_index:int,out:List[_Logical],pair:FontPairSpec,o:FullRenderOptions):
        pos=0
        for m in _STANDARD_CORE_SPECIAL_RE.finditer(text):
            match=m.group();cps=None
            if m.group(1) is not None:
                inner=_glyph_words_cps(m.group(1))
                if inner:cps=[_cp_for_word('pi'),0xF1997,*inner,0xF1998]
            elif m.group(2) is not None:cps=_glyph_expression_cps(m.group(2))
            elif m.group(3)=='|':cps=[0x3000]
            if m.start()>pos:self._parse_text_base(text[pos:m.start()],base+pos,kind,seg_index,out,pair,o)
            if cps is None:
                self._parse_text_base(match,base+m.start(),kind,seg_index,out,pair,o);pos=m.end();continue
            lr=self._glyph_run(match,cps,base+m.start(),base+m.end(),kind,pair,o)
            if cps==[0x3000]:lr=_Logical(replace(lr.run,kind='run'),lr.graphic)
            out.append(lr);pos=m.end()
        if pos<len(text):self._parse_text_base(text[pos:],base+pos,kind,seg_index,out,pair,o)

    def _parse_text_no_raw(self,text:str,base:int,kind:str,seg_index:int,out:List[_Logical],pair:FontPairSpec,o:FullRenderOptions):
        mode=o.parser.renderer_mode
        if mode=='standard-sitelen-pona-ascii-core':return self._parse_standard_core_text(text,base,kind,seg_index,out,pair,o)
        if mode=='sitelen-pona-ascii-extended':return self._parse_extended_text(text,base,kind,seg_index,out,pair,o)
        if mode=='sitelen-seli-kiwen':return self._parse_ssk_like_text(text,base,kind,seg_index,out,pair,o)
        return self._parse_text_base(text,base,kind,seg_index,out,pair,o)

    def _parse_text(self,text:str,base:int,kind:str,seg_index:int,out:List[_Logical],pair:FontPairSpec,o:FullRenderOptions):
        if not text or not text.strip():return
        matches=list(_RAW_UNICODE_SCAN_RE.finditer(text))
        if not matches:return self._parse_text_no_raw(text,base,kind,seg_index,out,pair,o)
        pos=0
        for m in matches:
            if m.start()>pos:self._parse_text_no_raw(text[pos:m.start()],base+pos,kind,seg_index,out,pair,o)
            raw=m.group();cps=parse_raw_unicode_sequence(raw)
            if cps is not None:out.append(self._glyph_run(raw,cps,base+m.start(),base+m.end(),kind,pair,o))
            else:self._parse_text_no_raw(raw,base+m.start(),kind,seg_index,out,pair,o)
            pos=m.end()
        if pos<len(text):self._parse_text_no_raw(text[pos:],base+pos,kind,seg_index,out,pair,o)

    def _parse_bracket(self,body:str,source_start:int,kind:str,seg_index:int,out:List[_Logical],pair:FontPairSpec,o:FullRenderOptions):
        trim=(body or '').strip()
        if not trim:return
        if len(trim)>=2 and trim.startswith('"') and trim.endswith('"'):
            literal=_unescape_full_quoted(trim[1:-1])
            if literal:
                inner=[]
                for ch in literal: inner.extend([ord(ch),0xF1992])
                out.append(self._cartouche_run(trim,OrdinaryCartouche(tuple(inner),tuple(0 for _ in inner),'ucsur'),source_start,source_start+len(body),kind,pair,o));return
        parsed=self._numeric_parsed('['+trim+']',o.parser)
        if parsed:out.append(self._numeric_run(trim,parsed,source_start,source_start+len(body),kind,pair,o));return
        parsed=self._numeric_parsed(trim,o.parser)
        if parsed and not parsed.get('isHex') and not parsed.get('isBinary'):
            out.append(self._numeric_run(trim,parsed,source_start,source_start+len(body),kind,pair,o));return
        strict_words=trim.split()
        strict_clean=bool(strict_words) and all(w==w.lower() and re.fullmatch(r'[a-z]+',w) for w in strict_words)
        if strict_clean:
            parsed=_new_phrase_parse_result(strict_words,o.parser)
            if parsed is not None:
                out.append(self._numeric_run(trim,parsed,source_start,source_start+len(body),kind,pair,o));return
            if o.parser.abbreviate_numeric_cartouches:
                parsed=_abbreviated_phrase_result(strict_words,o.parser)
                if parsed is not None:
                    copy_o=replace(o,parser=replace(o.parser,abbreviate_numeric_cartouches=False))
                    out.append(self._numeric_run(trim,parsed,source_start,source_start+len(body),kind,pair,copy_o));return
        ordinary_source=trim
        if o.parser.renderer_mode=='sitelen-pona-ascii-extended':
            norm=_normalize_extended_legacy_cartouche(body)
            if norm is not None:ordinary_source=norm
        cps=_glyph_words_cps(ordinary_source)
        if cps is not None and any(ch in ordinary_source for ch in '&+-'):
            out.append(self._cartouche_run(trim,OrdinaryCartouche(tuple(cps),tuple(0 for _ in cps),'ucsur'),source_start,source_start+len(body),kind,pair,o));return
        oc=parse_ordinary_body(ordinary_source,pair,o.parser)
        if oc:out.append(self._cartouche_run(trim,oc,source_start,source_start+len(body),kind,pair,o));return
        cps=_letters_to_fallback_glyph_cps(trim)
        if cps:out.append(self._cartouche_run(trim,OrdinaryCartouche(tuple(cps),tuple(0 for _ in cps),'ucsur'),source_start,source_start+len(body),kind,pair,o))

    def _parse_quote(self,seg:DocumentSegment,seg_index:int,out:List[_Logical],pair:FontPairSpec,o:FullRenderOptions):
        q=_unescape_full_quoted(seg.value or '')
        if o.parser.interpret_double_quotes_as_te_to:
            out.append(self._glyph_run('te',[OPEN_QUOTE_CP],seg.source_start,seg.source_start+1,'interpretedQuote',pair,o,interpreted=True));before=len(out);self._parse_text(q,seg.source_start+1,'interpretedQuote',seg_index,out,pair,o)
            for i in range(before,len(out)):out[i]=_Logical(replace(out[i].run,interpreted_quote=True),out[i].graphic)
            out.append(self._glyph_run('to',[CLOSE_QUOTE_CP],max(seg.source_start+1,seg.source_end-1),seg.source_end,'interpretedQuote',pair,o,interpreted=True))
        else:out.append(self._literal_rendered_run(q,seg.value or '',seg.source_start,seg.source_end,'quote',pair,o,quoted=True))

    def prepare(self,input_text:str,o:FullRenderOptions)->Tuple[FullRenderPlan,List[Tuple[FullRenderRun,_Graphic,float,float]]]:
        pair=self.pair(o.font_key);ast=parse_document(input_text,o.parser);logical_lines=[];any_abbr=False;first_parsed=None
        for line in ast.lines:
            runs=[]
            for si,seg in enumerate(line.children):
                if seg.kind=='text':self._parse_text(seg.value or '',seg.source_start,'text',si,runs,pair,o)
                elif seg.kind=='bracket':self._parse_bracket(seg.value or '',seg.source_start,'bracket',si,runs,pair,o)
                elif seg.kind=='quote':self._parse_quote(seg,si,runs,pair,o)
                elif seg.kind=='image':runs.append(self._image_run(seg,pair,o))
            for l in runs:
                if l.run.numeric_cartouche:
                    p=self._numeric_parsed(l.run.source_text or '',o.parser)
                    if p and first_parsed is None:first_parsed=p
                    any_abbr|=o.parser.abbreviate_numeric_cartouches
            logical_lines.append(runs)
        line_gap=o.layout.line_gap(o.font_size);pad=o.padding_px;line_widths=[];line_asc=[];line_desc=[];maxw=0
        for line in logical_lines:
            x=0;asc=0;desc=0;first=True
            for l in line:
                if not first:x+=o.layout.cartouche_lead_gap(o.font_size) if (l.run.font_role=='cartouche' or l.run.numeric_cartouche) else o.layout.glyph_gap(o.font_size)
                first=False;x+=l.graphic.width;asc=max(asc,l.graphic.baseline);desc=max(desc,max(0,l.graphic.height-l.graphic.baseline))
            h=max(o.font_size,asc+desc)
            if not line:asc=o.font_size*.82;desc=h-asc
            line_widths.append(x);line_asc.append(asc);line_desc.append(desc);maxw=max(maxw,x)
        width=max(1,math.ceil(maxw+2*pad));total=2*pad+sum(max(o.font_size,line_asc[i]+line_desc[i]) for i in range(len(logical_lines)))+line_gap*max(0,len(logical_lines)-1);height=max(1,math.ceil(total));placed=[];allruns=[];lineplans=[];y=pad
        for li,line in enumerate(logical_lines):
            lw=line_widths[li];asc=line_asc[li];desc=line_desc[li];lh=max(o.font_size,asc+desc);x=pad+((maxw-lw)/2 if o.layout.align=='center' else (maxw-lw) if o.layout.align=='right' else 0);line_start=x;lr=[];first=True
            for ri,l in enumerate(line):
                if not first:x+=o.layout.cartouche_lead_gap(o.font_size) if (l.run.font_role=='cartouche' or l.run.numeric_cartouche) else o.layout.glyph_gap(o.font_size)
                first=False;ty=y+asc-l.graphic.baseline;tx=x;groups=tuple(TallyGroup(g.owner_index,g.count,g.owner_left_px+tx,g.owner_right_px+tx,g.center_x_px+tx,g.top_y_px+ty,g.bottom_y_px+ty,g.stroke_width_px,tuple(c+tx for c in g.stroke_centers_px)) for g in l.graphic.tally_groups);r=replace(l.run,id=f'L{li}R{ri}',line_index=li,run_index=ri,tally_groups=groups,x_px=tx,y_px=ty,width_px=l.graphic.width,height_px=l.graphic.height,baseline_y_px=y+asc);placed.append((r,l.graphic,tx,ty));allruns.append(r);lr.append(r);x+=l.graphic.width
            lineplans.append(FullRenderLinePlan(li,ast.lines[li].source_line_index,ast.lines[li].sentence_index_in_source_line,line_start,y,lw,lh,y+asc,asc,desc,tuple(lr)));y+=lh+(line_gap if li+1<len(logical_lines) else 0)
        plan=FullRenderPlan(input_text,pair.font_key,any_abbr,width,height,_features_for(o.font_size),tuple(allruns),first_parsed,(),ast,tuple(lineplans));return plan,placed

    def render_canvas(self,input_text:str,o:FullRenderOptions)->CanvasRenderResult:
        plan,placed=self.prepare(input_text,o);canvas=Image.new('RGBA',(plan.width,plan.height),(0,0,0,0));
        # Build foreground from the run images only.  For manual-tally cartouches,
        # the run image intentionally excludes the renderer-owned tally strokes so
        # their halo backing and foreground lines can be painted in separate passes
        # like the JavaScript reference.
        fg=Image.new('RGBA',canvas.size,(0,0,0,0))
        tally_runs=[]
        for r,g,x,y in placed:
            fg.alpha_composite(g.image,(round(x),round(y)))
            if r.tally_groups:
                tally_runs.append(r)
        if o.paint.halo_enabled:
            hw=o.paint.halo_width_px or max(2,min(24,round(max(8,o.font_size)*.10)))
            alpha=_halo_alpha(fg.getchannel('A'),hw);halo=Image.new('RGBA',canvas.size,_rgba_from_hex(o.paint.halo_color));halo.putalpha(alpha);canvas.alpha_composite(halo)
            if tally_runs:
                draw=ImageDraw.Draw(canvas)
                halo_fill=_rgba_from_hex(o.paint.halo_color)
                pad_x=hw*.85;pad_bottom=hw*.85;radius=max(1.25,min(hw,o.font_size*.045))
                for r in tally_runs:
                    for tg in r.tally_groups:
                        if not tg.stroke_centers_px:continue
                        left=tg.stroke_centers_px[0]-tg.stroke_width_px/2
                        right=tg.stroke_centers_px[-1]+tg.stroke_width_px/2
                        top=tg.top_y_px
                        bottom=tg.bottom_y_px
                        draw.rounded_rectangle((left-pad_x, top, right+pad_x, bottom+pad_bottom), radius=radius, fill=halo_fill)
        canvas.alpha_composite(fg)
        if tally_runs:
            draw=ImageDraw.Draw(canvas)
            fill=_rgba_from_hex(o.paint.fill_style)
            for r in tally_runs:
                for tg in r.tally_groups:
                    width=max(1,round(tg.stroke_width_px))
                    for cx in tg.stroke_centers_px:
                        draw.line((cx,tg.top_y_px,cx,tg.bottom_y_px),fill=fill,width=width)
        return CanvasRenderResult(canvas,plan if o.include_plan else None,plan.font_key)

    def render_svg(self,input_text:str,o:FullRenderOptions)->Tuple[str,FullRenderPlan]:
        plan,placed=self.prepare(input_text,o);parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{plan.width}" height="{plan.height}" viewBox="0 0 {plan.width} {plan.height}">']
        for r,g,x,y in placed:
            if g.image_href is not None:
                parts.append(f'<image x="{x:.3f}" y="{y:.3f}" width="{g.width}" height="{g.height}" href="{html.escape(g.image_href,quote=True)}"/>');continue
            # Manual-tally halo is a renderer-owned group backing.  Paint it before
            # the cartouche/text foreground so it can never overwrite the bottom rule.
            if o.paint.halo_enabled and r.tally_groups:
                hw=o.paint.halo_width_px or max(2,min(24,round(max(8,o.font_size)*.10)));pad_x=hw*.85;pad_bottom=hw*.85;radius=max(1.25,min(hw,o.font_size*.045))
                for tg in r.tally_groups:
                    if not tg.stroke_centers_px:continue
                    left=tg.stroke_centers_px[0]-tg.stroke_width_px/2;right=tg.stroke_centers_px[-1]+tg.stroke_width_px/2;top=tg.top_y_px;bottom=tg.bottom_y_px
                    parts.append(f'<rect x="{left-pad_x:.3f}" y="{top:.3f}" width="{right-left+2*pad_x:.3f}" height="{max(1,bottom-top+pad_bottom):.3f}" rx="{radius:.3f}" ry="{radius:.3f}" fill="{o.paint.halo_color}"/>')
            if g.vector_path:
                tx=x+g.vector_dx;ty=y+g.vector_dy
                if o.paint.halo_enabled:
                    hw=o.paint.halo_width_px or max(2,min(24,round(max(8,o.font_size)*.10)));parts.append(f'<path d="{g.vector_path}" transform="translate({tx:.3f} {ty:.3f})" fill="{o.paint.fill_style}" stroke="{o.paint.halo_color}" stroke-width="{2*hw:.3f}" stroke-linejoin="round" stroke-linecap="round"/>')
                else:parts.append(f'<path d="{g.vector_path}" transform="translate({tx:.3f} {ty:.3f})" fill="{o.paint.fill_style}"/>')
            # Manual tally foreground is painted after the cartouche/text using
            # butt-ended strokes, matching the browser reference renderer.
            for tg in r.tally_groups:
                for cx in tg.stroke_centers_px:
                    parts.append(f'<path d="M {cx:.3f} {tg.top_y_px:.3f} L {cx:.3f} {tg.bottom_y_px:.3f}" fill="none" stroke="{o.paint.fill_style}" stroke-width="{tg.stroke_width_px:.3f}" stroke-linecap="butt"/>')
            if r.unrecognized and g.decoration:
                us=o.paint.unknown_text;parts.append(f'<rect x="{x:.3f}" y="{y:.3f}" width="{g.width:.3f}" height="{g.height:.3f}" fill="none" stroke="{us.color}" stroke-width="{us.line_width_px:.3f}"/>')
        parts.append('</svg>');return ''.join(parts),plan

    def render_pdf(self,input_text:str,o:FullRenderOptions)->Tuple[bytes,FullRenderPlan]:
        svg,plan=self.render_svg(input_text,o)
        try:
            import cairosvg
            pdf=cairosvg.svg2pdf(bytestring=svg.encode('utf-8'))
        except Exception:
            # Valid fallback, while full qualification requires CairoSVG for vector PDF.
            im=self.render_canvas(input_text,o).image.convert('RGB');b=BytesIO();im.save(b,format='PDF');pdf=b.getvalue()
        return pdf,plan

    def vector_document(self,input_text:str,o:FullRenderOptions)->VectorDocument:
        plan,placed=self.prepare(input_text,o);els=[]
        for r,g,x,y in placed:
            if g.image_href is not None:els.append(VectorElement('image',r.id,None,None,g.image_href,x,y,g.width,g.height))
            elif g.vector_path:els.append(VectorElement('path',r.id,g.vector_path,o.paint.fill_style,None,x+g.vector_dx,y+g.vector_dy,g.width,g.height))
            for tg in r.tally_groups:
                for cx in tg.stroke_centers_px:els.append(VectorElement('path',r.id,f'M {cx:.3f} {tg.top_y_px:.3f} L {cx:.3f} {tg.bottom_y_px:.3f}',o.paint.fill_style,None,0,0,0,0))
        return VectorDocument(plan.width,plan.height,tuple(els),plan.diagnostics,plan)


    def render_run_to_new_canvas(self,run:FullRenderRun,o:FullRenderOptions)->CanvasRenderResult:
        """Render one already-measured semantic run on a fresh Pillow surface."""
        pair=self.pair(o.font_key)
        fill=_rgba_from_hex(o.paint.fill_style)
        if run.font_role=='number':
            font_path=pair.companion.path;features=_features_for(o.font_size)
        elif run.font_role in ('literal','unknown'):
            support=self.support_font('literalText');font_path=support.path if support and support.path.exists() else pair.base.path;features=()
        else:
            font_path=pair.base.path;features=()
        text=run.render_text or ''.join(chr(cp) for cp in run.render_codepoints)
        raw_bypass=parse_raw_unicode_sequence((run.source_text or '').strip()) is not None
        synthetic_cp=_uses_synthetic_corner_bracket(pair,run.canonical_codepoints,raw_bypass) if run.font_role=='word' else None
        if synthetic_cp is not None:
            im,baseline,_,_,_=_synthetic_corner_bracket_local(synthetic_cp,o.font_size,fill)
        elif run.kind=='cartouche' and run.source_kind!='image':
            im,baseline,_,_,_,_=_render_cartouche_text_local(
                text or ' ',font_path,o.font_size,features,fill,
                has_manual_tallies=bool(run.tally_groups),
            )
        else:
            im,baseline,_,_,_=_render_text_local(text or ' ',font_path,o.font_size,features,fill)
        if run.unrecognized:
            us=o.paint.unknown_text;upad=max(0,round(us.padding_px));canvas=Image.new('RGBA',(im.width+2*upad,im.height+2*upad),(0,0,0,0));canvas.alpha_composite(im,(upad,upad));draw=ImageDraw.Draw(canvas);draw.rectangle((0,0,canvas.width-1,canvas.height-1),outline=_rgba_from_hex(us.color),width=max(1,round(us.line_width_px)));im=canvas;baseline+=upad
        # Recreate synthetic tallies using run-local geometry when present.  Plan
        # tally groups are absolute, so translate them back by the run origin.
        if run.tally_groups:
            d=ImageDraw.Draw(im)
            for tg in run.tally_groups:
                top=tg.top_y_px-run.y_px;bot=tg.bottom_y_px-run.y_px
                for cx in tg.stroke_centers_px:
                    d.line((cx-run.x_px,top,cx-run.x_px,bot),fill=fill,width=max(1,round(tg.stroke_width_px)))
        pad=max(0,o.padding_px);canvas=Image.new('RGBA',(im.width+2*pad,im.height+2*pad),(0,0,0,0));canvas.alpha_composite(im,(pad,pad))
        return CanvasRenderResult(canvas,None,pair.font_key)

    def render_text_to_new_canvas(self,text:str,o:FullRenderOptions)->CanvasRenderResult:
        return self.render_canvas(text,o)

    def render_text_to_canvas(self,target:Image.Image,x:float,y:float,text:str,o:FullRenderOptions)->Image.Image:
        result=self.render_canvas(text,replace(o,padding_px=0,include_plan=False))
        if target.mode!='RGBA':
            raise ValueError('target image must be RGBA so alpha compositing is deterministic')
        target.alpha_composite(result.image,(round(x),round(y)))
        return target

    @staticmethod
    def _ucsur_lines_to_source(lines:Sequence[Sequence[int]])->str:
        rendered=[]
        for line in lines:
            rendered.append(' '.join(f'U+{int(cp):04X}' for cp in line))
        return '\n'.join(rendered)

    def render_ucsur_to_new_canvas(self,lines:Sequence[Sequence[int]],o:FullRenderOptions)->CanvasRenderResult:
        return self.render_canvas(self._ucsur_lines_to_source(lines),o)

    def render_ucsur_to_canvas(self,target:Image.Image,x:float,y:float,lines:Sequence[Sequence[int]],o:FullRenderOptions)->Image.Image:
        return self.render_text_to_canvas(target,x,y,self._ucsur_lines_to_source(lines),o)
