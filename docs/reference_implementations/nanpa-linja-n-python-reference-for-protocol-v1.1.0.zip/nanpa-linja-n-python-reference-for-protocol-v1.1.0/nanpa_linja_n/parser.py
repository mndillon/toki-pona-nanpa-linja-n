"""Current nanpa-linja-n public parser API, implemented in Python.

This module uses the existing Python parity algorithms in number_glyph_renderer.py
and layers the September 13 semantic source forms on top.  It does not execute
or embed JavaScript at runtime.
"""
from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from . import number_glyph_renderer as _b

CARTOUCHE_START_CP = 0xF1990
CARTOUCHE_END_CP = 0xF1991

_ALLOWED_START_GLYPHS = {"nanpa", "tenpo", "suno", "toki"}
_ABBREVIATED_WORD_TO_CODE = {
    "ijo": "I", "wan": "W", "tu": "T", "seli": "S", "awen": "A",
    "luka": "L", "utala": "U", "mun": "M", "pipi": "P", "jo": "J",
}


def _opt(opts: Dict[str, Any], camel: str, snake: str, default: Any = None) -> Any:
    if camel in opts:
        return opts[camel]
    if snake in opts:
        return opts[snake]
    return default


def _relaxed_parsing(opts: Dict[str, Any]) -> bool:
    return bool(_opt(opts, "relaxedNanpaLinjanParsing", "relaxed_nanpa_linjan_parsing", True))


def _relaxed_rendering(opts: Dict[str, Any]) -> bool:
    return bool(_opt(opts, "relaxedNanpaLinjanRendering", "relaxed_nanpa_linjan_rendering", True))


def _colon_rendering(opts: Dict[str, Any]) -> bool:
    return bool(_opt(opts, "nanpaColonRendering", "nanpa_colon_rendering", True))


def _colon_parsing(opts: Dict[str, Any]) -> bool:
    return bool(_opt(opts, "nanpaColonParsing", "nanpa_colon_parsing", False)) or _colon_rendering(opts)


def _mode(opts: Dict[str, Any]) -> str:
    return "traditional" if (_opt(opts, "mode", "mode", "uniform") == "traditional" or
                              _opt(opts, "numericMode", "numeric_mode", "uniform") == "traditional") else "uniform"


def _mixed_style(opts: Dict[str, Any]) -> str:
    return "long" if _opt(opts, "mixedStyle", "mixed_style", "short") == "long" else "short"


def _abbreviate(opts: Dict[str, Any]) -> bool:
    keys = (
        "abbreviateNumericCartouches", "numericCartoucheAbbreviation",
        "abbreviatedNumericCartouches", "abbreviate_numeric_cartouches",
    )
    explicit = [opts[k] for k in keys if k in opts and opts[k] is not None]
    if not explicit:
        return True
    return any(v is True for v in explicit)


def _preserve_abbreviation_breaks(opts: Dict[str, Any]) -> bool:
    return bool(opts.get("preserveNumericCartoucheBreaksInAbbreviation") is True or
                opts.get("abbreviatedNumericCartoucheBreakAsEn") is True or
                opts.get("preserve_numeric_cartouche_breaks_in_abbreviation") is True)


def _codepoints_to_words_internal(codepoints: Sequence[int]) -> List[str]:
    reverse: Dict[int, str] = {}
    for word, char in _b.WORDS_TO_UNC_CODES_MAP.items():
        if len(char) == 1:
            reverse.setdefault(ord(char), word)
    colon_cp = ord(_b.WORDS_TO_UNC_CODES_MAP[":"])
    out: List[str] = []
    for cp in codepoints:
        n = int(cp)
        if n == colon_cp:
            out.append(":")
        else:
            out.append(reverse.get(n, f"U+{n:04X}"))
    return out


def _nasin_nanpa_pona_base100_group_to_words(group_value: int) -> Optional[List[str]]:
    try:
        n = int(group_value)
    except Exception:
        return None
    if n < 0 or n > 99:
        return None
    words: List[str] = []
    while n >= 20:
        words.append("mute")
        n -= 20
    while n >= 5:
        words.append("luka")
        n -= 5
    while n >= 2:
        words.append("tu")
        n -= 2
    if n == 1:
        words.append("wan")
    return words


def _nasin_nanpa_pona_grouped_digits_to_words(groups: Sequence[str]) -> Optional[List[str]]:
    out: List[str] = []
    for i, group in enumerate(groups):
        text = str(group)
        if not re.fullmatch(r"\d{1,2}", text):
            return None
        words = _nasin_nanpa_pona_base100_group_to_words(int(text))
        if words is None:
            return None
        out.extend(words)
        if i < len(groups) - 1:
            out.append("ale")
    return out


def _split_digits_base100_from_right(digits: str) -> Optional[List[str]]:
    value = str(digits)
    if not re.fullmatch(r"\d+", value):
        return None
    groups: List[str] = []
    end = len(value)
    while end > 0:
        groups.insert(0, value[max(0, end - 2):end])
        end -= 2
    return groups


def _split_digits_base100_from_left(digits: str) -> Optional[List[str]]:
    value = str(digits)
    if not re.fullmatch(r"\d+", value):
        return None
    if len(value) % 2:
        value += "0"
    return [value[i:i + 2] for i in range(0, len(value), 2)]


def _try_plain_decimal_to_nasin_nanpa_pona_words(raw_value: Any) -> Optional[List[str]]:
    raw = str(raw_value if raw_value is not None else "").strip()
    raw = re.sub(r"[−‒–—]", "-", raw)
    if not raw:
        return None
    m = re.fullmatch(r"(-)?(?:(0|[1-9]\d*|[1-9]\d{0,2}(?:,\d{3})+)(?:\.(\d+))?|\.(\d+))", raw)
    if not m:
        return None
    negative = bool(m.group(1))
    integer_digits = (m.group(2).replace(",", "") if m.group(2) is not None else "0")
    fraction_digits = m.group(3) if m.group(3) is not None else (m.group(4) or "")
    fraction_digits = re.sub(r"0+$", "", fraction_digits)
    if integer_digits == "0" and not fraction_digits:
        return ["ala"]
    integer_groups = _split_digits_base100_from_right(integer_digits)
    if integer_groups is None:
        return None
    integer_words = ["ala"] if integer_digits == "0" else _nasin_nanpa_pona_grouped_digits_to_words(integer_groups)
    if integer_words is None:
        return None
    words: List[str] = []
    if negative:
        words.append("weka")
    words.extend(integer_words)
    if fraction_digits:
        fraction_groups = _split_digits_base100_from_left(fraction_digits)
        if fraction_groups is None:
            return None
        fraction_words = _nasin_nanpa_pona_grouped_digits_to_words(fraction_groups)
        if fraction_words is None:
            return None
        words.extend(["ala", *fraction_words])
    return words


def _numeric_start_override(opts: Dict[str, Any]) -> Optional[str]:
    value = str(_opt(opts, "numericCartoucheStartGlyph", "numeric_cartouche_start_glyph", "") or "").strip().lower()
    return value if value in _ALLOWED_START_GLYPHS else None


def _encode_digits(digits: str, opts: Dict[str, Any]) -> str:
    return "".join(_b._decimal_digit_to_nanpa_token(ch, relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts)) for ch in str(digits))


def _is_valid_yearless_month_day(mm: str, dd: str) -> bool:
    if not re.fullmatch(r"\d{2}", str(mm)) or not re.fullmatch(r"\d{2}", str(dd)):
        return False
    month, day = int(mm), int(dd)
    max_day = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    return 1 <= month <= 12 and 1 <= day <= max_day[month]


def _try_parse_date_parts(raw: str) -> Optional[Dict[str, Any]]:
    source = str(raw or "").strip()
    if source and not re.search(r"\s", source):
        m = re.fullmatch(r"--(\d{2})-(\d{2})", source)
        if m is None:
            m = re.fullmatch(r"XXXX-(\d{2})-(\d{2})", source)
        if m is not None and _is_valid_yearless_month_day(m.group(1), m.group(2)):
            return {"yyyy": None, "mm": m.group(1), "dd": m.group(2), "yearless": True}
    normalized = _b._normalize_datetime_input(source)
    m = re.fullmatch(r"(\d{4})([/-])(\d{2})\2(\d{2})", normalized)
    if m is None:
        return None
    yyyy, mm, dd = m.group(1), m.group(3), m.group(4)
    if not 1 <= int(mm) <= 12 or not 1 <= int(dd) <= 31:
        return None
    return {"yyyy": yyyy, "mm": mm, "dd": dd, "yearless": False}


def _date_to_caps(raw: str, opts: Dict[str, Any]) -> Optional[str]:
    parts = _try_parse_date_parts(raw)
    if parts is None:
        return None
    caps = "NE"
    if not parts["yearless"]:
        caps += _encode_digits(parts["yyyy"], opts) + "NEKE"
    caps += _encode_digits(parts["mm"], opts) + "NEKE" + _encode_digits(parts["dd"], opts) + "N"
    _b.tokenize_nanpa_caps(caps, relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts))
    return caps


def _decode_yearless_caps(caps: str, opts: Dict[str, Any]) -> Optional[Tuple[str, str]]:
    try:
        tokens = _b.tokenize_nanpa_caps(caps, relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts))
    except Exception:
        return None
    if not tokens or tokens[0] != "NE" or tokens[-1] != "N":
        return None
    body = tokens[1:-1]
    if len(body) != 6 or body[2:4] != ["NE", "KE"]:
        return None
    if any(t not in _b._DIGIT_TOKENS for t in (body[0], body[1], body[4], body[5])):
        return None
    mm = _b._TOKEN_TO_DIGIT_CHAR[body[0]] + _b._TOKEN_TO_DIGIT_CHAR[body[1]]
    dd = _b._TOKEN_TO_DIGIT_CHAR[body[4]] + _b._TOKEN_TO_DIGIT_CHAR[body[5]]
    return (mm, dd) if _is_valid_yearless_month_day(mm, dd) else None


def _is_day_of_month_caps(caps: str, opts: Dict[str, Any]) -> bool:
    try:
        tokens = _b.tokenize_nanpa_caps(caps, relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts))
    except Exception:
        return False
    body = tokens[1:-1] if len(tokens) >= 3 and tokens[0] == "NE" and tokens[-1] == "N" else []
    if not body or any(t not in _b._DIGIT_TOKENS for t in body):
        return False
    digits = "".join(_b._TOKEN_TO_DIGIT_CHAR[t] for t in body)
    return digits.isdigit() and 1 <= int(digits) <= 31


def _typed_proper_name(raw: str, opts: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    if not _colon_parsing(opts):
        return None
    source = str(raw or "").strip()
    m = re.fullmatch(r"(Toki|Tenpo|Suno)(?:[ \t]+[A-Z][a-z]*)+", source)
    if m is None:
        return None
    words = re.split(r"[ \t]+", source)
    head = words[0].lower()
    nanpa_equivalent = "Nanpa " + " ".join(words[1:])
    caps = _b._nanpa_linjan_proper_name_to_caps(
        nanpa_equivalent,
        relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts),
        nanpa_colon_parsing=True,
    )
    if caps is None:
        return None
    if head == "toki":
        return {"caps": caps, "head": "toki", "semanticStartGlyph": "toki", "semanticKind": None, "dateKind": None}
    if head == "tenpo":
        if not _b._caps_is_time(caps, relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts)):
            return None
        return {"caps": caps, "head": "tenpo", "semanticStartGlyph": None, "semanticKind": "time", "dateKind": None}
    is_full_date = _b._caps_is_date(caps, relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts))
    yearless = _decode_yearless_caps(caps, opts)
    if is_full_date or yearless is not None:
        return {"caps": caps, "head": "suno", "semanticStartGlyph": None, "semanticKind": "date", "dateKind": "yearless" if yearless is not None and not is_full_date else "full"}
    if _is_day_of_month_caps(caps, opts):
        return {"caps": caps, "head": "suno", "semanticStartGlyph": "suno", "semanticKind": None, "dateKind": None}
    return None


def _tokenize_typed_cartouche(raw: str) -> Optional[List[str]]:
    source = str(raw or "").strip()
    if len(source) < 2 or not source.startswith("[") or not source.endswith("]"):
        return None
    inner = source[1:-1]
    tokens: List[str] = []
    i = 0
    while i < len(inner):
        if inner[i].isspace():
            i += 1
            continue
        if inner[i] == ":":
            tokens.append(":")
            i += 1
            continue
        if inner[i].isalpha() and inner[i].isascii():
            j = i + 1
            while j < len(inner) and inner[j].isalpha() and inner[j].isascii():
                j += 1
            tokens.append(inner[i:j].lower())
            i = j
            continue
        return None
    return tokens


def _try_parse_typed_cartouche(raw: str, opts: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    if not _colon_parsing(opts):
        return None
    tokens = _tokenize_typed_cartouche(raw)
    if not tokens or len(tokens) < 3 or tokens[0] not in {"nanpa", "tenpo", "suno", "toki"} or tokens[-1] != "nanpa":
        return None
    head = tokens[0]
    has_colon = len(tokens) > 1 and tokens[1] == ":"
    if not has_colon and head != "suno":
        return None
    body = tokens[2 if has_colon else 1:-1]
    if not body or "nanpa" in body or "nasin" in body:
        return None

    def try_abbrev() -> Optional[str]:
        index = 0
        positive = False
        if body and body[0] == "en":
            positive = True
            index = 1
        code = ""
        has_digit = False
        while index < len(body):
            word = body[index]
            if word in _ABBREVIATED_WORD_TO_CODE:
                code += _ABBREVIATED_WORD_TO_CODE[word]
                has_digit = True
            elif word == "e":
                code += "EE"
            elif word in {"o", "ona"}:
                code += "O"
            elif word in {"kulupu", "kasi", "kolon", ":"}:
                code += "K"
            elif word == "kala":
                code += "EKO"
            elif word == "kin":
                code += "OKO"
            elif word == "kipisi" and index == len(body) - 1:
                code += "OK"
            else:
                return None
            index += 1
        if not has_digit or not code:
            return None
        try:
            return _b.hash_tilde_payload_to_nanpa_caps(("+" if positive else "") + code)
        except Exception:
            return None

    def try_full() -> Optional[str]:
        if not all(word == ":" or word in _b.WORDS_TO_UNC_CODES_MAP for word in body):
            return None
        letters = "".join("K" if word == ":" else word[0] for word in body).upper()
        caps = "NE" + letters + "N"
        if len(body) >= 2 and body[0] == "nena" and body[1] == "en" and caps.startswith("NENE"):
            caps = "NENS" + caps[4:]
        if caps.endswith("NOKEN"):
            caps = caps[:-5] + "OKN"
        try:
            parsed = _b.tokenize_nanpa_caps(caps, relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts))
        except Exception:
            return None
        return caps if any(t in _b._DIGIT_TOKENS for t in parsed) else None

    prefer_abbrev = _abbreviate(opts)
    parsed_form = None
    caps = None
    for form, fn in (("abbreviated", try_abbrev), ("full", try_full)) if prefer_abbrev else (("full", try_full), ("abbreviated", try_abbrev)):
        caps = fn()
        if caps:
            parsed_form = form
            break
    if not caps:
        return None

    if head == "suno":
        is_full_date = _b._caps_is_date(caps, relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts))
        yearless = _decode_yearless_caps(caps, opts)
        is_day = _is_day_of_month_caps(caps, opts)
        if not (is_full_date or yearless is not None or is_day) and prefer_abbrev and parsed_form == "abbreviated":
            full_caps = try_full()
            if full_caps:
                caps = full_caps
                parsed_form = "full"
                is_full_date = _b._caps_is_date(caps, relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts))
                yearless = _decode_yearless_caps(caps, opts)
                is_day = _is_day_of_month_caps(caps, opts)
        if is_full_date or yearless is not None:
            return {"caps": caps, "semanticKind": "date", "dateKind": "yearless" if yearless is not None and not is_full_date else "full", "head": head, "semanticStartGlyph": None, "form": parsed_form}
        if is_day:
            return {"caps": caps, "semanticKind": None, "dateKind": None, "head": head, "semanticStartGlyph": "suno", "form": parsed_form}
        return None
    if head == "tenpo":
        if not _b._caps_is_time(caps, relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts)):
            return None
        return {"caps": caps, "semanticKind": "time", "dateKind": None, "head": head, "semanticStartGlyph": None, "form": parsed_form}
    return {"caps": caps, "semanticKind": None, "dateKind": None, "head": head, "semanticStartGlyph": "toki" if head == "toki" else None, "form": parsed_form}


def _replace_opener(words: List[str], *, semantic_kind: Optional[str], semantic_start: Optional[str], opts: Dict[str, Any]) -> List[str]:
    if not words:
        return words
    explicit = semantic_start if semantic_start in _ALLOWED_START_GLYPHS else None
    if _colon_rendering(opts):
        default = "suno" if semantic_kind == "date" else "tenpo" if semantic_kind == "time" else "nanpa"
    else:
        default = "nanpa"
    start = _numeric_start_override(opts) or explicit or default
    result = list(words)
    result[0] = start
    return result


def _proper_name_from_legacy(legacy: str, semantic_start: Optional[str]) -> str:
    body = str(legacy or "").strip().lower()
    if body.startswith("ne"):
        body = body[2:].lstrip()
    elif body.startswith("n ene"):
        body = body[2:].lstrip()
    words = body.split()
    if words and words[0] in {"no", "ne"} and len(words) > 1:
        words[0] += words[1]
        del words[1]
    titled = [w[:1].upper() + w[1:] for w in words if w]
    head = "Toki" if semantic_start == "toki" else "Suno" if semantic_start == "suno" else "Nanpa"
    return f"{head} {' '.join(titled)}" if titled else ""


def _base_caps_result(source: str, caps: str, opts: Dict[str, Any], *, structured_kind: Optional[str] = None,
                      semantic_start: Optional[str] = None, yearless_parts: Optional[Tuple[str, str]] = None) -> Optional[Dict[str, Any]]:
    try:
        if _b._caps_is_time(caps, relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts)):
            decoded_time = _b._decode_time_caps(caps, relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts))
            if decoded_time and decoded_time.get("negative_input") and decoded_time.get("is_zero"):
                toks = _b.tokenize_nanpa_caps(caps, relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts))
                if toks[:2] == ["NE", "NO"]:
                    del toks[1]
                    caps = "".join(toks)
        tokens = _b.tokenize_nanpa_caps(caps, relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts))
        caps_is_date = _b._caps_is_date(caps, relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts))
        caps_is_time = _b._caps_is_time(caps, relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts))
        explicit_date = structured_kind in {"date", "date-yearless"}
        is_date = True if explicit_date else False if structured_kind == "time" else caps_is_date
        is_time = True if structured_kind == "time" else False if explicit_date else (not caps_is_date and caps_is_time)
        is_time_like = is_date or is_time
        semantic_kind = "date" if is_date else "time" if is_time else None
        has_percent = "OK" in tokens
        words = _b.nanpa_caps_tokens_to_tp_words(
            [t for t in tokens if t != "OK"],
            number_word_style=_mode(opts),
            relaxed_nanpa_linjan_rendering=_relaxed_rendering(opts),
            nanpa_colon_rendering=_colon_rendering(opts),
        )
        words = _replace_opener(words, semantic_kind=semantic_kind, semantic_start=semantic_start, opts=opts)
        if is_time_like:
            words = _b._replace_time_separators_words(words, _mode(opts))
        if has_percent:
            suffix = ["nena", "open", "kipisi", "e"] if _mode(opts) == "uniform" else ["noka", "open", "kipisi", "e"]
            idx = len(words) - 1 - words[::-1].index("nanpa") if "nanpa" in words else len(words)
            words[idx:idx] = suffix
        inner = _b.tp_words_to_nasin_nanpa_unicodes(words)
        cps = [ord(ch) for ch in inner]
        abbreviated_inner = _b.abbreviate_numeric_cartouche_ucsur(
            inner,
            preserve_nene_as_en=_preserve_abbreviation_breaks(opts),
        )
        abbreviated_cps = [ord(ch) for ch in abbreviated_inner]
        abbreviated_words = _codepoints_to_words_internal(abbreviated_cps)
        all_cps = [CARTOUCHE_START_CP, *cps, CARTOUCHE_END_CP]
        proper_caps = _b._caps_for_output_rendering(caps, relaxed_nanpa_linjan_rendering=_relaxed_rendering(opts))
        legacy = _b.split_cartouche_caps_letters(
            proper_caps,
            title_case_words=not (semantic_start == "toki" or _colon_rendering(opts)),
            relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts) or _relaxed_rendering(opts),
        )
        proper_name = _proper_name_from_legacy(legacy, semantic_start) if (semantic_start == "toki" or _colon_rendering(opts)) else legacy
        unique = _b.caps_to_canonical_unique_code(caps)
        if structured_kind == "date-yearless":
            # Current JS uses a leading lowercase k in number-code output for yearless dates.
            if unique.startswith("#~"):
                unique = "#~k" + unique[2:]
        display = f"--{yearless_parts[0]}-{yearless_parts[1]}" if yearless_parts else _b.nanpa_caps_to_numeric_expression(caps)
        nasin_nanpa_pona_words = (
            _try_plain_decimal_to_nasin_nanpa_pona_words(display)
            if opts.get("nasinNanpaPona") is True or opts.get("nasin_nanpa_pona") is True
            else None
        )
        return {
            "input": source,
            "caps": caps,
            "properName": proper_name,
            "uniqueCode": unique,
            "ucsurCodepoints": cps,
            "hexCodepoints": " ".join(f"{cp:04X}" for cp in cps),
            "hexWithCartouche": " ".join(f"{cp:04X}" for cp in all_cps),
            "tpWords": words,
            "words": list(words),
            "displayValue": display,
            "isTime": is_time,
            "isDate": is_date,
            "semanticKind": semantic_kind,
            "semanticStartGlyph": semantic_start,
            "isTimeLike": is_time_like,
            "innerCodepoints": list(cps),
            "codepoints": all_cps,
            "numericMode": _mode(opts),
        }
    except Exception:
        return None


def _convert_base_result(result: Dict[str, Any]) -> Dict[str, Any]:
    mapping = {
        "number_base": "numberBase", "is_binary": "isBinary", "is_hex": "isHex",
        "proper_name": "properName", "unique_code": "uniqueCode", "display_value": "displayValue",
        "binary_digits": "binaryDigits", "binary_parts": "binaryParts", "hex_digits": "hexDigits",
        "hex_parts": "hexParts", "ucsur_codepoints": "ucsurCodepoints",
        "abbreviated_ucsur_codepoints": "abbreviatedUcsurCodepoints", "hex_codepoints": "hexCodepoints",
        "hex_with_cartouche": "hexWithCartouche", "tp_words": "tpWords", "abbreviated_words": "abbreviatedWords",
        "inner_codepoints": "innerCodepoints", "is_time": "isTime", "is_date": "isDate",
        "is_time_like": "isTimeLike", "numeric_mode": "numericMode",
    }
    converted = {mapping.get(k, k): v for k, v in result.items()}
    if converted.get("kind") == "hex":
        converted.pop("isBinary", None)
    elif converted.get("kind") == "binary":
        converted.pop("isHex", None)
    if converted.get("kind") not in {"hex", "binary"}:
        for key in ("kind", "numberBase", "isHex", "isBinary"):
            converted.pop(key, None)
        converted.setdefault("semanticKind", "date" if converted.get("isDate") else "time" if converted.get("isTime") else None)
        converted.setdefault("semanticStartGlyph", None)
    return converted


def parse_number(input_value: Any, opts: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
    opts = dict(opts or {})
    if input_value is None or not str(input_value).strip():
        return None
    source = str(input_value).strip()

    # Hex and binary have first precedence exactly as in the JS public API.
    try:
        base_result = _b.parse_number(
            source,
            enable_hex_parsing=bool(_opt(opts, "enableHexParsing", "enable_hex_parsing", False)),
            enable_binary_parsing=bool(_opt(opts, "enableBinaryParsing", "enable_binary_parsing", False)),
            enable_binary_rendering=bool(_opt(opts, "enableBinaryRendering", "enable_binary_rendering", False)),
            nanpa_colon_parsing=False,
            nanpa_colon_rendering=False,
            relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts),
            relaxed_nanpa_linjan_rendering=_relaxed_rendering(opts),
            abbreviate_numeric_cartouches=_abbreviate(opts),
            mode=_mode(opts),
            mixed_style=_mixed_style(opts),
        )
        if base_result.get("kind") in {"hex", "binary"}:
            return _convert_base_result(base_result)
    except Exception:
        pass

    caps: Optional[str] = None
    structured_kind: Optional[str] = None
    semantic_start: Optional[str] = None
    yearless_parts: Optional[Tuple[str, str]] = None
    try:
        typed_cartouche = _try_parse_typed_cartouche(source, opts)
        if caps is None and typed_cartouche:
            caps = typed_cartouche["caps"]
            semantic_start = typed_cartouche.get("semanticStartGlyph")
            if typed_cartouche.get("semanticKind") == "date":
                structured_kind = "date-yearless" if typed_cartouche.get("dateKind") == "yearless" else "date"
            elif typed_cartouche.get("semanticKind") == "time":
                structured_kind = "time"
            if structured_kind == "date-yearless":
                yearless_parts = _decode_yearless_caps(caps, opts)

        typed_proper = _typed_proper_name(source, opts)
        normalized = _b._normalize_vulgar_fraction_input(source)
        prefer_plus = (
            re.match(r"^nene", source, flags=re.I) is not None
            and re.fullmatch(r"[A-Z]+", source) is None
            and _b._is_valid_nanpa_linjan_proper_name(source,
                relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts), nanpa_colon_parsing=_colon_parsing(opts))
        )
        if caps is None and typed_proper:
            caps = typed_proper["caps"]
            semantic_start = typed_proper.get("semanticStartGlyph")
            if typed_proper.get("semanticKind") == "date":
                structured_kind = "date-yearless" if typed_proper.get("dateKind") == "yearless" else "date"
            elif typed_proper.get("semanticKind") == "time":
                structured_kind = "time"
            if structured_kind == "date-yearless":
                yearless_parts = _decode_yearless_caps(caps, opts)
        elif caps is None and prefer_plus:
            caps = _b._proper_name_to_caps(source,
                relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts), nanpa_colon_parsing=_colon_parsing(opts))
        elif caps is None and _b._looks_like_nanpa_caps(normalized):
            caps = _b.canonicalize_scientific_nanpa_caps(normalized)
        elif caps is None:
            date_parts = _try_parse_date_parts(normalized)
            date_caps = _date_to_caps(normalized, opts) if date_parts else None
            time_caps = None if date_caps is not None else _b.time_str_to_nanpa_caps(normalized, relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts))
            if date_caps is not None:
                caps = date_caps
                structured_kind = "date-yearless" if date_parts and date_parts["yearless"] else "date"
                if date_parts and date_parts["yearless"]:
                    yearless_parts = (date_parts["mm"], date_parts["dd"])
            elif time_caps is not None:
                caps = time_caps
                structured_kind = "time"
            elif _b._is_valid_nanpa_linjan_proper_name(source,
                    relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts), nanpa_colon_parsing=_colon_parsing(opts)):
                caps = _b._proper_name_to_caps(source,
                    relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts), nanpa_colon_parsing=_colon_parsing(opts))
            elif source.upper().startswith("#~"):
                # Existing Python number-code parser. Current yearless #~k can be added without changing ordinary code handling.
                body = re.sub(r"\s+", "", source)[2:]
                explicit_yearless = body.startswith("k")
                if explicit_yearless:
                    body = body[1:]
                    if not body:
                        return None
                caps = _b.hash_tilde_payload_to_nanpa_caps(body)
                if explicit_yearless:
                    yearless_parts = _decode_yearless_caps(caps, opts)
                    if yearless_parts is None:
                        return None
                    structured_kind = "date-yearless"
            else:
                caps = _b.decimal_string_to_nanpa_caps(
                    normalized, thousands_char=",", group_fraction_triplets=True, fraction_group_size=3,
                    mixed_style=_mixed_style(opts), relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts))
    except Exception:
        return None

    if not caps:
        return None
    caps = _b.canonicalize_scientific_nanpa_caps(caps)
    return _base_caps_result(source, caps, opts, structured_kind=structured_kind,
                             semantic_start=semantic_start, yearless_parts=yearless_parts)


def encode_decimal(value: Any, opts: Optional[Dict[str, Any]] = None) -> str:
    opts = dict(opts or {})
    return _b.decimal_string_to_nanpa_caps(
        str(value if value is not None else ""), thousands_char=",", group_fraction_triplets=True,
        fraction_group_size=3, mixed_style=_mixed_style(opts), relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts))


def decimal_to_ucsur_codepoints(value: Any, opts: Optional[Dict[str, Any]] = None) -> List[int]:
    result = parse_number(value, opts)
    return list(result.get("ucsurCodepoints", [])) if result else []


def proper_name_to_ucsur_codepoints(value: Any, opts: Optional[Dict[str, Any]] = None) -> List[int]:
    result = parse_number(value, opts)
    return list(result.get("ucsurCodepoints", [])) if result else []


def split_caps_to_proper_name(caps: str, opts: Optional[Dict[str, Any]] = None) -> str:
    opts = dict(opts or {})
    rendered = _b._caps_for_output_rendering(str(caps), relaxed_nanpa_linjan_rendering=_relaxed_rendering(opts))
    return _b.split_cartouche_caps_letters(
        rendered, title_case_words=bool(opts.get("titleCase")),
        relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts) or _relaxed_rendering(opts))


def caps_to_words(caps: str, opts: Optional[Dict[str, Any]] = None) -> List[str]:
    opts = dict(opts or {})
    tokens = _b.tokenize_nanpa_caps(str(caps), relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts))
    semantic_kind = "date" if _b._caps_is_date(str(caps), relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts)) else (
        "time" if _b._caps_is_time(str(caps), relaxed_nanpa_linjan_parsing=_relaxed_parsing(opts)) else None)
    words = _b.nanpa_caps_tokens_to_tp_words(
        [t for t in tokens if t != "OK"], number_word_style=_mode(opts),
        relaxed_nanpa_linjan_rendering=_relaxed_rendering(opts), nanpa_colon_rendering=_colon_rendering(opts))
    return _replace_opener(words, semantic_kind=semantic_kind, semantic_start=None, opts=opts)


def caps_to_codepoints(caps: str, opts: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
    opts = dict(opts or {})
    result = _base_caps_result(str(caps), _b.canonicalize_scientific_nanpa_caps(str(caps)), opts)
    if result is None:
        return None
    inner = list(result["innerCodepoints"])
    return {
        "innerCodepoints": inner,
        "codepoints": [CARTOUCHE_START_CP, *inner, CARTOUCHE_END_CP],
        "words": codepoints_to_words(inner),
        "numericMode": _mode(opts),
        "isTimeLike": bool(result["isTimeLike"]),
    }


def parse_identifier(value: str, opts: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
    opts = dict(opts or {})
    result = parse_number(value, opts)
    if result is None:
        return None
    inner = list(result.get("innerCodepoints", []))
    if not inner:
        return None
    return {
        "input": str(value if value is not None else ""),
        "innerCodepoints": inner,
        "codepoints": [CARTOUCHE_START_CP, *inner, CARTOUCHE_END_CP],
        "words": codepoints_to_words(inner),
        "numericMode": _mode(opts),
    }


def codepoints_to_words(codepoints: Sequence[int], opts: Optional[Dict[str, Any]] = None) -> List[str]:
    reverse: Dict[int, str] = {}
    for word, char in _b.WORDS_TO_UNC_CODES_MAP.items():
        if len(char) == 1:
            reverse.setdefault(ord(char), word)
    return [reverse.get(int(cp), f"U+{int(cp):04X}") for cp in codepoints]


class _NanpaParserAPI:
    def parseNumber(self, input_value: Any, opts: Optional[Dict[str, Any]] = None):
        return parse_number(input_value, opts)
    def encodeDecimal(self, value: Any, opts: Optional[Dict[str, Any]] = None):
        return encode_decimal(value, opts)
    def decimalToUcsurCodepoints(self, value: Any, opts: Optional[Dict[str, Any]] = None):
        return decimal_to_ucsur_codepoints(value, opts)
    def properNameToUcsurCodepoints(self, value: Any, opts: Optional[Dict[str, Any]] = None):
        return proper_name_to_ucsur_codepoints(value, opts)
    def splitCapsToProperName(self, value: str, opts: Optional[Dict[str, Any]] = None):
        return split_caps_to_proper_name(value, opts)
    def capsToWords(self, value: str, opts: Optional[Dict[str, Any]] = None):
        return caps_to_words(value, opts)
    def capsToCodepoints(self, value: str, opts: Optional[Dict[str, Any]] = None):
        return caps_to_codepoints(value, opts)
    def parseIdentifier(self, value: str, opts: Optional[Dict[str, Any]] = None):
        return parse_identifier(value, opts)
    def codepointsToWords(self, value: Sequence[int], opts: Optional[Dict[str, Any]] = None):
        return codepoints_to_words(value, opts)

NanpaParser = _NanpaParserAPI()

# ---------------------------------------------------------------------------
# Additional public utility API parity with the canonical JavaScript object.
# ---------------------------------------------------------------------------

def caps_to_unique_code(caps: str, opts: Optional[Dict[str, Any]] = None) -> str:
    return _b.caps_to_canonical_unique_code(
        _b.canonicalize_scientific_nanpa_caps(str(caps)),
        relaxed_nanpa_linjan_parsing=_relaxed_parsing(dict(opts or {})),
    )


def decode_caps(caps: str, opts: Optional[Dict[str, Any]] = None) -> Optional[str]:
    try:
        return _b.nanpa_caps_to_numeric_expression(_b.canonicalize_scientific_nanpa_caps(str(caps)))
    except Exception:
        return None


def tp_words_to_text(words: Iterable[str]) -> str:
    return " ".join(str(x) for x in (words or []))


def parse_tp_words_to_codepoints(value: Any) -> List[int]:
    raw = str(value or "").strip()
    if not raw:
        return []
    parts = [p for p in re.split(r"(\s+|[·:])", raw) if p and not p.isspace()]
    cps: List[int] = []
    for p in parts:
        key = p.lower()
        if key == "·": key = "ota"
        elif key == ":": key = "kolon"
        char = _b.WORDS_TO_UNC_CODES_MAP.get(key)
        if char is None or len(char) != 1:
            raise ValueError(f'Invalid Toki Pona word "{p}".')
        cps.append(ord(char))
    if len(cps) >= 2 and cps[0] == CARTOUCHE_START_CP and cps[-1] == CARTOUCHE_END_CP:
        return cps[1:-1]
    return cps


def codepoints_to_hex(codepoints: Iterable[int]) -> str:
    return " ".join(f"{int(cp):04X}" for cp in (codepoints or []))


def codepoints_to_hex_with_cartouche(codepoints: Iterable[int]) -> str:
    return codepoints_to_hex([CARTOUCHE_START_CP, *list(codepoints or []), CARTOUCHE_END_CP])


def parse_hex_codepoints(value: Any) -> List[int]:
    raw = str(value or "").strip()
    if not raw:
        return []
    cps: List[int] = []
    # Accept U+F193D, F193D, 0xF193D and whitespace/comma separated forms.
    for token in re.split(r"[\s,]+", raw):
        if not token:
            continue
        t = token.upper()
        if t.startswith("U+"):
            t = t[2:]
        elif t.startswith("0X"):
            t = t[2:]
        if not re.fullmatch(r"[0-9A-F]{1,6}", t):
            raise ValueError(f"Invalid Unicode codepoint token {token!r}")
        cp = int(t, 16)
        if cp > 0x10FFFF or 0xD800 <= cp <= 0xDFFF:
            raise ValueError(f"Invalid Unicode scalar U+{cp:X}")
        cps.append(cp)
    if len(cps) >= 2 and cps[0] == CARTOUCHE_START_CP and cps[-1] == CARTOUCHE_END_CP:
        return cps[1:-1]
    return cps


def with_cartouche_markers(codepoints: Iterable[int]) -> List[int]:
    return [CARTOUCHE_START_CP, *[int(cp) for cp in (codepoints or [])], CARTOUCHE_END_CP]


def strip_cartouche_markers(codepoints: Iterable[int]) -> List[int]:
    arr = [int(cp) for cp in (codepoints or [])]
    if len(arr) >= 2 and arr[0] == CARTOUCHE_START_CP and arr[-1] == CARTOUCHE_END_CP:
        return arr[1:-1]
    return arr


def is_valid_caps(value: Any) -> bool:
    return _b._looks_like_nanpa_caps(str(value or ""))


def is_valid_proper_name(value: Any, opts: Optional[Dict[str, Any]] = None) -> bool:
    options = dict(opts or {})
    return _typed_proper_name(str(value or ""), options) is not None or _b._is_valid_nanpa_linjan_proper_name(
        str(value or ""), relaxed_nanpa_linjan_parsing=_relaxed_parsing(options), nanpa_colon_parsing=_colon_parsing(options))


def is_valid_time(caps: str, opts: Optional[Dict[str, Any]] = None) -> bool:
    return _b._caps_is_time(str(caps), relaxed_nanpa_linjan_parsing=_relaxed_parsing(dict(opts or {})))


def is_valid_date(caps: str, opts: Optional[Dict[str, Any]] = None) -> bool:
    return _b._caps_is_date(str(caps), relaxed_nanpa_linjan_parsing=_relaxed_parsing(dict(opts or {})))


def is_valid_time_or_date(caps: str, opts: Optional[Dict[str, Any]] = None) -> bool:
    options = dict(opts or {})
    return is_valid_date(caps, options) or is_valid_time(caps, options)


def tokenize_caps(caps: str, opts: Optional[Dict[str, Any]] = None) -> List[str]:
    return _b.tokenize_nanpa_caps(str(caps), relaxed_nanpa_linjan_parsing=_relaxed_parsing(dict(opts or {})))


def caps_tokens_to_tp_words(tokens: Sequence[str], opts: Optional[Dict[str, Any]] = None) -> List[str]:
    options = dict(opts or {})
    return _b.nanpa_caps_tokens_to_tp_words(
        list(tokens or []), number_word_style=_mode(options), relaxed_nanpa_linjan_rendering=_relaxed_rendering(options),
        nanpa_colon_rendering=_colon_rendering(options))


def tp_words_to_ucsur_codepoints(words: Iterable[str]) -> List[int]:
    return [ord(ch) for ch in _b.tp_words_to_nasin_nanpa_unicodes(list(words or []))]


def normalize_vulgar_fraction(value: Any) -> str:
    return _b._normalize_vulgar_fraction_input(str(value or ""))


def normalize_tp_word(value: Any) -> str:
    return re.sub(r"[^a-z]", "", str(value or "").lower())


def get_small_codepoints_set() -> set[int]:
    return {0xF193D, 0xF1940, 0xF1941, 0xF193E, 0xF1909, 0xF190B, 0xF190A}


def get_quarter_codepoints_set() -> set[int]:
    return {0xF193D, 0xF1940, 0xF1941, 0xF193E, 0xF1909, 0xF190B, 0xF190A, 0xF1947}


def get_one_third_codepoints_set() -> set[int]:
    return {0xF1917}


def get_two_thirds_codepoints_set() -> set[int]:
    return {0xF1946, 0xF1944, 0xF191F, 0xF1979}


def get_half_codepoints_set() -> set[int]:
    return {0xF1914}


def is_allowed_tp_ucsur_codepoint(cp: int) -> bool:
    cp = int(cp)
    return (0xF1900 <= cp <= 0xF19FF) or cp in {CARTOUCHE_START_CP, CARTOUCHE_END_CP}


# Attach the utility methods after class construction to keep the core implementation compact.
NanpaParser.capsToUniqueCode = caps_to_unique_code
NanpaParser.decodeCaps = decode_caps
NanpaParser.ucsurCodepointsToTpWords = codepoints_to_words
NanpaParser.tpWordsToText = tp_words_to_text
NanpaParser.parseTpWordsToCodepoints = parse_tp_words_to_codepoints
NanpaParser.codepointsToHex = codepoints_to_hex
NanpaParser.codepointsToHexWithCartouche = codepoints_to_hex_with_cartouche
NanpaParser.parseHexCodepoints = parse_hex_codepoints
NanpaParser.withCartoucheMarkers = with_cartouche_markers
NanpaParser.stripCartoucheMarkers = strip_cartouche_markers
NanpaParser.isValidCaps = is_valid_caps
NanpaParser.isValidProperName = is_valid_proper_name
NanpaParser.isValidTimeOrDate = is_valid_time_or_date
NanpaParser.isValidTime = is_valid_time
NanpaParser.isValidDate = is_valid_date
NanpaParser.tokenizeCaps = tokenize_caps
NanpaParser.capsTokensToTpWords = caps_tokens_to_tp_words
NanpaParser.tpWordsToUcsurCodepoints = tp_words_to_ucsur_codepoints
NanpaParser.normalizeVulgarFraction = normalize_vulgar_fraction
NanpaParser.normalizeTpWord = normalize_tp_word
NanpaParser.getSmallCodepointsSet = get_small_codepoints_set
NanpaParser.getQuarterCodepointsSet = get_quarter_codepoints_set
NanpaParser.getOneThirdCodepointsSet = get_one_third_codepoints_set
NanpaParser.getTwoThirdsCodepointsSet = get_two_thirds_codepoints_set
NanpaParser.getHalfCodepointsSet = get_half_codepoints_set
NanpaParser.isAllowedTpUcsurCodepoint = is_allowed_tp_ucsur_codepoint
