"""Numeric-cartouche render adapters used by the Python font regression layer.

The canonical parser output is UCSUR.  Most production companion fonts consume
that stream directly.  ``linja pona`` and ``linja sike`` are legacy ASCII
ligature fonts; for numeric cartouches the production renderer converts each
canonical cell to ``[_word_word...]`` syntax.  This module implements that
numeric-cartouche subset, which is exactly what the 128 full/abbreviated font golden cases need.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, Sequence

from . import number_glyph_renderer as legacy

CARTOUCHE_START = 0xF1990
CARTOUCHE_END = 0xF1991
COLON = 0xF199D
LEGACY_ASCII_ADAPTERS = {"linja-pona-legacy-v1", "linja-sike-legacy-v1"}

# Build an unambiguous canonical codepoint -> Toki Pona name table from the
# source map. Aliases added later to WORDS_TO_UNC_CODES_MAP do not replace the
# canonical names here.
_CP_TO_WORD: Dict[int, str] = {}
for hex_cp, word in getattr(legacy, "UNC_CODES_TO_WORDS_MAP", {}).items():
    try:
        _CP_TO_WORD[int(hex_cp, 16)] = str(word).lower()
    except Exception:
        pass
_CP_TO_WORD[COLON] = ":"


@dataclass(frozen=True)
class AdaptedRun:
    text: str
    adapter_id: str
    canonical_codepoints: tuple[int, ...]
    legacy_ascii: bool


# Protocol v1.1.0 cartouche scaling controls. These are font-facing postfix
# controls, not semantic code points in the canonical parser output.
VULGAR_SCALE_QUARTER = 0x00BC       # ¼
VULGAR_SCALE_THIRD = 0x2153         # ⅓
VULGAR_SCALE_HALF = 0x00BD          # ½
VULGAR_SCALE_TWO_THIRDS = 0x2154    # ⅔
VULGAR_SCALE_THREE_QUARTERS = 0x00BE # ¾
VULGAR_SCALE_MARKERS = {
    VULGAR_SCALE_QUARTER,
    VULGAR_SCALE_THIRD,
    VULGAR_SCALE_HALF,
    VULGAR_SCALE_TWO_THIRDS,
    VULGAR_SCALE_THREE_QUARTERS,
}


def _cp(word: str) -> int | None:
    for cp, name in _CP_TO_WORD.items():
        if name == word:
            return cp
    return None


_HALF_HEADS = {cp for cp in (_cp('nanpa'), _cp('nasa'), _cp('noka'), _cp('tenpo'), _cp('suno'), _cp('toki')) if cp is not None}
_HALF_CLOSERS = {cp for cp in (_cp('nanpa'), _cp('nasa'), _cp('noka')) if cp is not None}
_CP_EN = _cp('en')
_CP_E = _cp('e')
_CP_NENA = _cp('nena')
_FIXED_SCALE: Dict[int, int] = {}
for word in ('ala', 'ike', 'uta', 'open'):
    cp = _cp(word)
    if cp is not None: _FIXED_SCALE[cp] = VULGAR_SCALE_QUARTER
for word in ('kasi', 'kule'):
    cp = _cp(word)
    if cp is not None: _FIXED_SCALE[cp] = VULGAR_SCALE_THIRD
for word in ('kala',):
    cp = _cp(word)
    if cp is not None: _FIXED_SCALE[cp] = VULGAR_SCALE_HALF
for word in ('ona', 'o', 'kulupu', 'kipisi', 'kin'):
    cp = _cp(word)
    if cp is not None: _FIXED_SCALE[cp] = VULGAR_SCALE_TWO_THIRDS
_INTERIOR_QUARTER_INITIAL = {
    cp for cp, word in _CP_TO_WORD.items()
    if word and word[0] in ('e', 'n') and word.isalpha()
}


def _leading_positive_en(cps: Sequence[int], index: int) -> bool:
    if len(cps) < 4 or _CP_EN is None or int(cps[index]) != _CP_EN:
        return False
    first = 1
    if int(cps[first]) not in _HALF_HEADS:
        return False
    if index == first + 1:
        return True
    if index == first + 2 and int(cps[first + 1]) == COLON:
        return True
    return (
        index == first + 3
        and _CP_NENA is not None
        and int(cps[first + 2]) == _CP_NENA
        and int(cps[first + 1]) in {x for x in (_CP_E, COLON) if x is not None}
    )


def numeric_cartouche_scale_marker(cps: Sequence[int], index: int) -> int | None:
    """Return the Protocol v1.1 font-facing postfix scale control for one canonical cell."""
    values = tuple(int(cp) for cp in cps)
    if index <= 0 or index >= len(values) - 1:
        return None
    cp = values[index]
    first = 1
    last = len(values) - 2
    first_cp = values[first]
    if index == first and cp in _HALF_HEADS:
        return VULGAR_SCALE_HALF
    if index == first + 1 and cp == COLON and first_cp in _HALF_HEADS:
        return VULGAR_SCALE_HALF
    if index == last and cp in _HALF_CLOSERS:
        return VULGAR_SCALE_HALF
    if _leading_positive_en(values, index):
        return VULGAR_SCALE_TWO_THIRDS
    if cp in _INTERIOR_QUARTER_INITIAL:
        return VULGAR_SCALE_QUARTER
    return _FIXED_SCALE.get(cp)


def _vulgar_scaling_enabled(font_settings: Dict[str, Any] | None) -> bool:
    cfg = font_settings or {}
    return bool(cfg.get('cartoucheVulgarFractions') is True or cfg.get('emulateLegacyCartoucheScaling') is True)


def _legacy_numeric_cartouche(cps: Sequence[int], adapter_id: str, *, scale: bool = False) -> str:
    values = [int(cp) for cp in cps]
    if len(values) < 2 or values[0] != CARTOUCHE_START or values[-1] != CARTOUCHE_END:
        raise ValueError(f"{adapter_id}: numeric regression input is not a complete canonical cartouche")
    parts = ["["]
    for index, cp in enumerate(values[1:-1], 1):
        word = _CP_TO_WORD.get(cp)
        if word is None:
            raise ValueError(f"{adapter_id}: no legacy numeric encoding for U+{cp:04X}")
        parts.append("_")
        parts.append(word)
        if scale:
            marker = numeric_cartouche_scale_marker(values, index)
            if marker is not None:
                parts.append(chr(marker))
    parts.append("]")
    return "".join(parts)


def _direct_numeric_cartouche(cps: Sequence[int], *, scale: bool = False) -> str:
    values = [int(cp) for cp in cps]
    out: list[str] = []
    for index, cp in enumerate(values):
        out.append(chr(cp))
        if scale and 0 < index < len(values) - 1:
            marker = numeric_cartouche_scale_marker(values, index)
            if marker is not None:
                out.append(chr(marker))
    return ''.join(out)


def _nasin_pu_numeric_cartouche(cps: Sequence[int], *, scale: bool = False) -> str:
    values = [int(cp) for cp in cps]
    ni = _cp('ni'); sewi = _cp('sewi')
    out: list[str] = []
    for index, cp in enumerate(values):
        if cp in (0xF1989, 0xF198A, 0xF198B) and ni is not None:
            out.append(chr(ni))
        elif cp == 0xF198C and sewi is not None:
            out.append(chr(sewi))
        elif cp == COLON:
            out.append(':')
        elif cp == 0xF199C:
            out.append('.')
        else:
            out.append(chr(cp))
        if scale and 0 < index < len(values) - 1:
            marker = numeric_cartouche_scale_marker(values, index)
            if marker is not None:
                out.append(chr(marker))
    return ''.join(out)


def _lipamanka_needs_translation(cps: Sequence[int], settings: Dict[str, Any] | None) -> bool:
    cfg = settings or {}
    jaki = _cp('jaki'); ko = _cp('ko')
    deterministic = cfg.get('deterministicAlternates') is not False
    specials = {COLON, 0xF199C, 0xF199E, 0xF1989, 0xF198A, 0xF198B, 0xF198C, 0x300C, 0x300D, 0x3000}
    for cp in map(int, cps):
        if cp in specials:
            return True
        if cp == 0xF19A5 or (cp > 0xF19A3 and cp not in (0xF19A4, 0xF19A6)):
            return True
        if deterministic and cp in {x for x in (jaki, ko) if x is not None}:
            return True
    return False


def _lipamanka_numeric_cartouche(cps: Sequence[int], settings: Dict[str, Any] | None, *, scale: bool = False) -> str:
    values = [int(cp) for cp in cps]
    if not _lipamanka_needs_translation(values, settings):
        return _direct_numeric_cartouche(values, scale=scale)
    if len(values) < 2 or values[0] != CARTOUCHE_START or values[-1] != CARTOUCHE_END:
        return _direct_numeric_cartouche(values, scale=scale)
    parts = ['[']
    for index, cp in enumerate(values[1:-1], 1):
        if index > 1:
            parts.append(' ')
        if cp == COLON:
            token = ':'
        elif cp == 0xF199C:
            token = '.'
        elif cp in (0xF1989, 0xF198A, 0xF198B):
            token = 'ni'
        elif cp == 0xF198C:
            token = 'sewi'
        else:
            token = _CP_TO_WORD.get(cp)
            if token is None:
                token = '\ufffd'
        parts.append(token)
        if scale:
            marker = numeric_cartouche_scale_marker(values, index)
            if marker is not None:
                parts.append(chr(marker))
    parts.append(']')
    return ''.join(parts)


def adapt_numeric_cartouche(
    codepoints: Iterable[int],
    render_adapter_id: str = "identity",
    settings: Dict[str, Any] | None = None,
    *,
    font_settings: Dict[str, Any] | None = None,
) -> AdaptedRun:
    cps = tuple(int(cp) for cp in codepoints)
    adapter_id = str(render_adapter_id or "identity").strip() or "identity"
    use_scale = _vulgar_scaling_enabled(font_settings)
    if adapter_id in LEGACY_ASCII_ADAPTERS:
        text = _legacy_numeric_cartouche(cps, adapter_id, scale=use_scale)
        return AdaptedRun(text=text, adapter_id=adapter_id, canonical_codepoints=cps, legacy_ascii=True)
    if adapter_id == "nasin-sitelen-pu-mono-v1":
        return AdaptedRun(
            text=_nasin_pu_numeric_cartouche(cps, scale=use_scale),
            adapter_id=adapter_id, canonical_codepoints=cps, legacy_ascii=False,
        )
    if adapter_id == "linja-lipamanka-v1":
        text = _lipamanka_numeric_cartouche(cps, settings, scale=use_scale)
        return AdaptedRun(text=text, adapter_id=adapter_id, canonical_codepoints=cps, legacy_ascii=text.isascii())
    return AdaptedRun(
        text=_direct_numeric_cartouche(cps, scale=use_scale),
        adapter_id=adapter_id,
        canonical_codepoints=cps,
        legacy_ascii=False,
    )
