"""Production font-manifest loading for the Python regression/rendering layer.

The loader intentionally consumes the same ``fonts/preloaded-font-pairs.manifest.json``
format used by the JavaScript application.  It does not invent a Python-only font
configuration format.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional
import hashlib
import json
import tempfile
import zipfile


DEFAULT_MANIFEST_ENTRY = 'fonts/preloaded-font-pairs.manifest.json'
DEFAULT_BUNDLE_CANDIDATES = (
    Path('resources/fonts.zip'),
    Path('nanpa_linja_n/resources/fonts.zip'),
)


@dataclass(frozen=True)
class FontFaceSpec:
    role: str
    family: str
    path: Path
    format: str
    sample: str = ""
    sha256: Optional[str] = None


@dataclass(frozen=True)
class SupportFontSpec:
    key: str
    family: str
    path: Path
    format: str
    sample: str = ""
    sha256: Optional[str] = None
    raw: Dict[str, Any] | None = None


@dataclass(frozen=True)
class FontPairSpec:
    font_key: str
    label: str
    rev: str
    parser_mode: str
    render_adapter_id: str
    render_adapter_settings: Dict[str, Any]
    settings: Dict[str, Any]
    support: Dict[str, Any]
    faces: tuple[FontFaceSpec, ...]
    raw: Dict[str, Any]

    def face(self, role: str) -> Optional[FontFaceSpec]:
        return next((face for face in self.faces if face.role == role), None)

    @property
    def base(self) -> FontFaceSpec:
        face = self.face('base')
        if face is None:
            raise KeyError(f'{self.font_key}: no base face')
        return face

    @property
    def companion(self) -> FontFaceSpec:
        face = self.face('companion')
        if face is None:
            raise KeyError(f'{self.font_key}: no companion face')
        return face

    @property
    def literal_cartouche(self) -> Optional[FontFaceSpec]:
        return self.face('literalCartouche')


@dataclass(frozen=True)
class FontManifest:
    path: Path
    schema: int
    generated: str
    pairs: tuple[FontPairSpec, ...]
    support_fonts: tuple[SupportFontSpec, ...]
    raw: Dict[str, Any]

    def support_font(self, key: str) -> Optional[SupportFontSpec]:
        return next((font for font in self.support_fonts if font.key == key), None)


def _without_query_hash(value: Any) -> str:
    text = str(value or '').strip().replace('\\', '/')
    for sep in ('?', '#'):
        if sep in text:
            text = text.split(sep, 1)[0]
    return text


def _normalise_format(value: Any, filename: str = '') -> str:
    raw = str(value or '').strip().lower()
    if raw in {'otf', 'opentype'}:
        return 'opentype'
    if raw in {'ttf', 'truetype'}:
        return 'truetype'
    if raw in {'woff', 'woff2'}:
        return raw
    lower = filename.lower()
    if lower.endswith('.otf'):
        return 'opentype'
    if lower.endswith('.woff2'):
        return 'woff2'
    if lower.endswith('.woff'):
        return 'woff'
    return 'truetype'


def _default_bundle_path(project_root: Path) -> Path:
    for rel in DEFAULT_BUNDLE_CANDIDATES:
        candidate = (project_root / rel).resolve()
        if candidate.exists():
            return candidate
    return (project_root / DEFAULT_BUNDLE_CANDIDATES[0]).resolve()


def _extract_bundle(bundle_path: Path) -> Path:
    bundle = Path(bundle_path).resolve()
    digest = hashlib.sha256(bundle.read_bytes()).hexdigest()
    target = Path(tempfile.gettempdir()) / 'nanpa_linja_n_python_fonts' / digest
    manifest_path = target / DEFAULT_MANIFEST_ENTRY
    if manifest_path.exists():
        return target
    target.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(bundle) as zf:
        members = [m for m in zf.namelist() if not m.endswith('/')]
        for name in members:
            if not name.startswith('fonts/'):
                continue
            out = target / name
            out.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(name) as src, out.open('wb') as dst:
                dst.write(src.read())
    if not manifest_path.exists():
        raise FileNotFoundError(f'Manifest entry not found inside {bundle}: {DEFAULT_MANIFEST_ENTRY}')

    # Protocol v1.1.0 production manifest intentionally names a nasin-nanpa
    # literal-cartouche compatibility face that is not duplicated in the
    # supplied fonts.zip.  The JavaScript/Node references resolve that name to
    # the bundled Liberation Sans donor without altering fonts.zip; do the same
    # here so Python consumes the exact supplied archive bytes.
    literal_alias = target / 'fonts' / 'nanpa-linja-n-nasin-nanpa-liberation-sans-literal.ttf'
    donor = target / 'fonts' / 'LiberationSans-Regular.ttf'
    if not literal_alias.exists() and donor.exists():
        literal_alias.write_bytes(donor.read_bytes())
    return target


def resolve_asset_path(project_root: Path, manifest_path: Path, raw_url: Any, filename_hint: Any = '') -> Path:
    """Resolve a production font asset from the extracted bundle or manifest-relative path only.

    The canonical bundled source is ``resources/fonts.zip``.  After extraction,
    all manifest asset URLs are resolved only within that extracted bundle tree
    (or, for explicit advanced overrides, relative to the supplied manifest).
    No legacy ``assets/fonts``/``resources/fonts``/top-level ``fonts`` fallbacks
    are consulted here.
    """
    root = Path(project_root).resolve()
    manifest_dir = Path(manifest_path).resolve().parent
    raw = _without_query_hash(raw_url)
    hint = _without_query_hash(filename_hint)
    if raw and ':' in raw.split('/', 1)[0] and not raw.startswith('file:'):
        raise ValueError(f'Network/data URL is not allowed in offline regression assets: {raw}')

    candidates: List[Path] = []

    def add(path: Optional[Path]) -> None:
        if path is not None and path not in candidates:
            candidates.append(path)

    stripped = raw.lstrip('./').lstrip('/')
    if stripped.startswith('fonts/'):
        add((root / stripped).resolve())
    if raw and not Path(raw).is_absolute():
        add((manifest_dir / raw).resolve())
    base = Path(hint).name if hint else (Path(stripped).name if stripped else '')
    if base:
        add((root / 'fonts' / base).resolve())
        add((manifest_dir / base).resolve())

    for candidate in candidates:
        if candidate.exists():
            return candidate
    if not candidates:
        raise ValueError(f'No local path can be resolved for {raw_url!r} / {filename_hint!r}')
    return candidates[0]


def _sha_field(node: Dict[str, Any], prefix: str) -> Optional[str]:
    return node.get(prefix + 'Sha256') or node.get(prefix + 'SHA256') or (node.get(prefix + 'sha256') if prefix else node.get('sha256')) or None


def _faces_for_pair(root: Path, manifest_path: Path, pair: Dict[str, Any]) -> tuple[FontFaceSpec, ...]:
    defs = [
        (
            'base',
            pair.get('baseFamily') or pair.get('textFamily') or pair.get('fontKey') or '',
            pair.get('baseUrl'), pair.get('baseFilename'), pair.get('baseFormat'), pair.get('baseSample'),
            _sha_field(pair, 'base'),
        ),
        (
            'companion',
            pair.get('companionFamily') or pair.get('cartoucheFamily') or f"{pair.get('fontKey','')}-nanpa-linja-n",
            pair.get('companionUrl'), pair.get('companionFilename'), pair.get('companionFormat'), pair.get('companionSample'),
            _sha_field(pair, 'companion'),
        ),
    ]
    literal_url = pair.get('literalCartoucheUrl') or pair.get('literalCartoucheFontUrl') or ''
    literal_filename = pair.get('literalCartoucheFilename') or pair.get('literalCartoucheFileName') or ''
    if literal_url or literal_filename:
        defs.append((
            'literalCartouche',
            pair.get('literalCartoucheFamily') or pair.get('literalCartoucheFontFamily') or pair.get('baseFamily') or pair.get('fontKey') or '',
            literal_url, literal_filename, pair.get('literalCartoucheFormat'), pair.get('literalCartoucheSample'),
            _sha_field(pair, 'literalCartouche'),
        ))
    out = []
    for role, family, url, filename, fmt, sample, sha in defs:
        path = resolve_asset_path(root, manifest_path, url, filename)
        out.append(FontFaceSpec(
            role=role,
            family=str(family or ''),
            path=path,
            format=_normalise_format(fmt, str(filename or url or '')),
            sample=str(sample or ''),
            sha256=str(sha) if sha else None,
        ))
    return tuple(out)


def _support_fonts(root: Path, manifest_path: Path, raw: Dict[str, Any]) -> tuple[SupportFontSpec, ...]:
    support_raw = raw.get('supportFonts') or {}
    if not isinstance(support_raw, dict):
        raise ValueError('manifest.supportFonts must be an object when present')
    out: List[SupportFontSpec] = []
    for key, node in support_raw.items():
        if not isinstance(node, dict):
            raise ValueError(f'manifest.supportFonts.{key} must be an object')
        filename = node.get('filename') or node.get('fileName') or ''
        url = node.get('url') or node.get('fontUrl') or f'./fonts/{filename}'
        path = resolve_asset_path(root, manifest_path, url, filename)
        out.append(SupportFontSpec(
            key=str(key),
            family=str(node.get('family') or key),
            path=path,
            format=_normalise_format(node.get('format'), str(filename or url or '')),
            sample=str(node.get('sample') or ''),
            sha256=str(_sha_field(node, '')) if _sha_field(node, '') else None,
            raw=dict(node),
        ))
    return tuple(out)


def load_font_manifest(
    project_root: Path | str = '.',
    manifest_path: Path | str | None = None,
    *,
    bundle_path: Path | str | None = None,
    required: bool = True,
) -> Optional[FontManifest]:
    root = Path(project_root).resolve()
    if manifest_path is not None:
        mp = Path(manifest_path)
        if not mp.is_absolute():
            mp = root / mp
        mp = mp.resolve()
    else:
        bundle = Path(bundle_path) if bundle_path is not None else _default_bundle_path(root)
        if not bundle.is_absolute():
            bundle = root / bundle
        bundle = bundle.resolve()
        if not bundle.exists():
            if required:
                raise FileNotFoundError(
                    f'Production font bundle not found: {bundle} (expected bundled source: resources/fonts.zip)'
                )
            return None
        extracted_root = _extract_bundle(bundle)
        root = extracted_root
        mp = (extracted_root / DEFAULT_MANIFEST_ENTRY).resolve()
    if not mp.exists():
        if required:
            raise FileNotFoundError(f'Production font manifest not found: {mp}')
        return None
    raw = json.loads(mp.read_text(encoding='utf-8'))
    if not isinstance(raw.get('pairs'), list):
        raise ValueError('manifest.pairs must be an array')
    pairs: List[FontPairSpec] = []
    seen = set()
    for pair in raw['pairs']:
        key = str(pair.get('fontKey') or '').strip()
        if not key:
            raise ValueError('manifest pair is missing fontKey')
        if key in seen:
            raise ValueError(f'duplicate manifest fontKey: {key}')
        seen.add(key)
        pairs.append(FontPairSpec(
            font_key=key,
            label=str(pair.get('label') or key),
            rev=str(pair.get('rev') or ''),
            parser_mode=str(pair.get('parserMode') or ''),
            render_adapter_id=str(pair.get('renderAdapterId') or 'identity').strip() or 'identity',
            render_adapter_settings=dict(pair.get('renderAdapterSettings') or {}),
            settings=dict(pair.get('settings') or {}),
            support=dict(pair.get('support') or {}),
            faces=_faces_for_pair(root, mp, pair),
            raw=dict(pair),
        ))
    return FontManifest(
        path=mp,
        schema=int(raw.get('schema') or 0),
        generated=str(raw.get('generated') or ''),
        pairs=tuple(pairs),
        support_fonts=_support_fonts(root, mp, raw),
        raw=raw,
    )
