"""Offline production-font regression checks for the Python implementation."""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

from PIL import Image, ImageDraw, ImageFont, features
from fontTools.ttLib import TTFont

from .parser import NanpaParser
from .font_registry import FontManifest, FontPairSpec, load_font_manifest
from .font_adapters import LEGACY_ASCII_ADAPTERS, VULGAR_SCALE_MARKERS, adapt_numeric_cartouche
from . import number_glyph_renderer as legacy

DEFAULT_CASES = Path("tests/font-golden-cases.json")
DEFAULT_CORPUS = Path("tests/nanpa-linja-n-regression-v1.0.2.json")
DEFAULT_GOLDEN_DIR = Path("goldens/python-font")
DEFAULT_GOLDEN_MANIFEST = Path("goldens/python-font-manifest.json")

PARSER_OPTIONS = {
    "mode": "uniform",
    "mixedStyle": "short",
    "relaxedNanpaLinjanParsing": True,
    "relaxedNanpaLinjanRendering": True,
    "nanpaColonParsing": True,
    "nanpaColonRendering": True,
    "enableHexParsing": True,
    "enableBinaryParsing": True,
    "numericMode": "uniform",
}

TOKI_PONA_ASCII_ALPHABET = "aeijklmnopstuw"
LEGACY_REQUIRED_CPS = {ord(ch) for ch in TOKI_PONA_ASCII_ALPHABET + "[]_:"} | set(VULGAR_SCALE_MARKERS)
REQUIRED_FEATURES: tuple[str, ...] = ()
EXPECTED_FULL_CASES = 8
EXPECTED_ABBREVIATED_CASES = 8
EXPECTED_CASES_PER_PAIR = EXPECTED_FULL_CASES + EXPECTED_ABBREVIATED_CASES


@dataclass
class CheckLog:
    checks: int = 0
    failures: int = 0

    def passed(self, message: str) -> None:
        self.checks += 1
        print(f"PASS {message}")

    def failed(self, message: str) -> None:
        self.checks += 1
        self.failures += 1
        print(f"FAIL {message}", file=sys.stderr)


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _manifest_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _font_cmap(font_path: Path) -> Set[int]:
    with TTFont(font_path, lazy=True, fontNumber=0) as font:
        cmap: Set[int] = set()
        table = font.get("cmap")
        if table is None:
            return cmap
        for sub in table.tables:
            if sub.isUnicode():
                cmap.update(int(cp) for cp in sub.cmap.keys())
        return cmap


def _gsub_feature_tags(font_path: Path) -> Set[str]:
    with TTFont(font_path, lazy=True, fontNumber=0) as font:
        if "GSUB" not in font:
            return set()
        fl = getattr(font["GSUB"].table, "FeatureList", None)
        if fl is None:
            return set()
        return {str(record.FeatureTag) for record in fl.FeatureRecord}


def _required_numeric_codepoints(root: Path) -> Set[int]:
    corpus = json.loads((root / DEFAULT_CORPUS).read_text(encoding="utf-8"))
    cps: Set[int] = {0xF1990, 0xF1991, 0xF199D}
    for tc in corpus.get("parserCases", []):
        if tc.get("assert", {}).get("result") != "accept" or not isinstance(tc.get("input"), str):
            continue
        api = str(tc.get("api") or "parseNumber")
        fn = getattr(NanpaParser, api, None)
        if not callable(fn):
            continue
        try:
            result = fn(tc["input"], tc.get("options", {}))
        except Exception:
            continue
        if not isinstance(result, dict):
            continue
        for key in ("ucsurCodepoints", "abbreviatedUcsurCodepoints", "innerCodepoints", "codepoints"):
            for cp in result.get(key) or []:
                if isinstance(cp, int) and not isinstance(cp, bool):
                    cps.add(cp)
    cps.update(VULGAR_SCALE_MARKERS)
    return cps


def _font_size_features(font_px: int) -> List[str]:
    # Protocol v1.1 carries numeric-cartouche scale in the font-facing text
    # stream via vulgar-fraction postfix controls, not ss12/ss13/ss14.
    return ["calt", "liga", "ccmp"]


def _load_raqm_font(path: Path, size: int) -> ImageFont.FreeTypeFont:
    if not features.check("raqm"):
        raise RuntimeError("Pillow was built without RAQM; OpenType shaping regression cannot run")
    return ImageFont.truetype(str(path), size=int(size), layout_engine=ImageFont.Layout.RAQM)


def _render_text(text: str, font_path: Path, font_px: int) -> Image.Image:
    font = _load_raqm_font(font_path, font_px)
    active_features = _font_size_features(font_px)
    probe = Image.new("RGBA", (1, 1), (0, 0, 0, 0))
    draw = ImageDraw.Draw(probe)
    bbox = draw.textbbox((0, 0), text, font=font, features=active_features)
    l, t, r, b = [int(v) for v in bbox]
    pad = 4
    image = Image.new("RGBA", (max(1, r-l+2*pad), max(1, b-t+2*pad)), (0,0,0,0))
    draw = ImageDraw.Draw(image)
    draw.text((pad-l, pad-t), text, font=font, fill=(0,0,0,255), features=active_features)
    return image


def _image_payload_hash(image: Image.Image) -> str:
    rgba = image.convert("RGBA")
    h = hashlib.sha256()
    h.update(f"RGBA:{rgba.width}x{rgba.height}:".encode("ascii"))
    h.update(rgba.tobytes())
    return h.hexdigest()


def _image_nonblank(image: Image.Image) -> bool:
    return image.convert("RGBA").getchannel("A").getbbox() is not None


def _load_cases(root: Path) -> List[Dict[str, Any]]:
    data = json.loads((root / DEFAULT_CASES).read_text(encoding="utf-8"))
    cases = list(data.get("cases") or [])
    full = [case for case in cases if not bool(case.get("abbreviateNumericCartouches"))]
    abbreviated = [case for case in cases if bool(case.get("abbreviateNumericCartouches"))]
    if len(full) != EXPECTED_FULL_CASES or len(abbreviated) != EXPECTED_ABBREVIATED_CASES:
        raise ValueError(
            f"font golden matrix must contain exactly {EXPECTED_FULL_CASES} full + "
            f"{EXPECTED_ABBREVIATED_CASES} abbreviated cases; got {len(full)} + {len(abbreviated)}"
        )
    full_ids = {str(case.get("id") or "") for case in full}
    abbreviated_base_ids = {
        str(case.get("id") or "")[:-5]
        for case in abbreviated
        if str(case.get("id") or "").endswith("-abbr")
    }
    if full_ids != abbreviated_base_ids:
        raise ValueError(
            "font golden matrix must have a one-to-one full/-abbr case pairing; "
            f"full-only={sorted(full_ids-abbreviated_base_ids)!r} "
            f"abbr-only={sorted(abbreviated_base_ids-full_ids)!r}"
        )
    return cases


def _parse_case(case: Dict[str, Any]) -> Dict[str, Any]:
    parsed = NanpaParser.parseNumber(case["input"], PARSER_OPTIONS)
    if not isinstance(parsed, dict):
        raise ValueError(f"font golden input did not parse: {case['input']!r}")
    return parsed


def _display_codepoints_for_case(parsed: Dict[str, Any], case: Dict[str, Any]) -> List[int]:
    full = [int(cp) for cp in (parsed.get("codepoints") or [])]
    if len(full) < 3 or full[0] != 0xF1990 or full[-1] != 0xF1991:
        raise ValueError("numeric font case did not produce a complete canonical cartouche")
    if not bool(case.get("abbreviateNumericCartouches")):
        return full

    preserve_breaks = bool(case.get("preserveNumericCartoucheBreaksInAbbreviation", True))
    inner = "".join(chr(cp) for cp in full[1:-1])
    abbreviated_inner = legacy.abbreviate_numeric_cartouche_ucsur(
        inner, preserve_nene_as_en=preserve_breaks
    )
    abbreviated = [0xF1990, *[ord(ch) for ch in abbreviated_inner], 0xF1991]
    if abbreviated == full:
        raise ValueError("abbreviated cartouche is identical to its full cartouche")
    if len(abbreviated) >= len(full):
        raise ValueError(
            f"abbreviated cartouche is not shorter than full cartouche ({len(abbreviated)} >= {len(full)})"
        )
    return abbreviated


def _artifact_id(pair: FontPairSpec, case: Dict[str, Any]) -> str:
    return f"{pair.font_key}__{case['id']}"


def inspect_and_test_fonts(root: Path, *, render_smoke: bool = True) -> CheckLog:
    log = CheckLog()
    manifest = load_font_manifest(root, required=True)
    assert manifest is not None
    print(f"manifest: {manifest.path.relative_to(root) if manifest.path.is_relative_to(root) else manifest.path}")
    print(f"schema: {manifest.schema}")
    print(f"pairs: {len(manifest.pairs)}")

    required_cps = _required_numeric_codepoints(root)
    seen_files: Set[Path] = set()

    if manifest.schema != 2:
        log.failed(f"manifest schema {manifest.schema}; expected 2")
    else:
        log.passed("manifest schema 2")

    for pair in manifest.pairs:
        if not pair.rev:
            log.failed(f"{pair.font_key}: missing rev")
        else:
            log.passed(f"{pair.font_key}: rev {pair.rev}")
        for face in pair.faces:
            if not face.path.exists():
                log.failed(f"{pair.font_key}/{face.role}: missing {face.path}")
                continue
            seen_files.add(face.path)
            digest = _sha256(face.path)
            if face.sha256 and digest.lower() != face.sha256.lower():
                log.failed(f"sha256 {pair.font_key}/{face.role} {face.family}: {digest} != {face.sha256}")
            else:
                suffix = "" if face.sha256 else " (recorded; manifest has no hash)"
                log.passed(f"sha256 {pair.font_key}/{face.role} {face.family}: {digest}{suffix}")

        companion = pair.companion
        if companion.path.exists():
            try:
                cmap = _font_cmap(companion.path)
                native = pair.render_adapter_id in LEGACY_ASCII_ADAPTERS
                required = LEGACY_REQUIRED_CPS if native else required_cps
                missing = sorted(required - cmap)
                if missing:
                    kind = f"adapter-native ({pair.render_adapter_id})" if native else "canonical numeric/render"
                    log.failed(f"cmap {pair.font_key}/{companion.family}: missing {len(missing)} {kind} codepoints: " + ", ".join(f"U+{cp:04X}" for cp in missing[:30]))
                elif native:
                    log.passed(f"cmap-native {pair.font_key}/{companion.family}: {len(required)} legacy adapter input codepoints ({pair.render_adapter_id}); canonical UCSUR cmap intentionally not required")
                else:
                    log.passed(f"cmap {pair.font_key}/{companion.family}: {len(required)} required numeric/render codepoints")
                tags = _gsub_feature_tags(companion.path)
                for ft in REQUIRED_FEATURES:
                    if ft in tags:
                        log.passed(f"GSUB {pair.font_key}/{companion.family}: {ft}")
                    else:
                        log.failed(f"GSUB {pair.font_key}/{companion.family}: missing {ft}")
            except Exception as exc:
                log.failed(f"font tables {pair.font_key}/{companion.family}: {exc}")

        # Pillow load/shaping checks replace the browser FontFace/canvas layer.
        for face in pair.faces:
            if not face.path.exists():
                continue
            try:
                font = _load_raqm_font(face.path, 56)
                # A basic metrics request ensures FreeType accepted the face.
                font.getbbox(face.sample or "A")
                log.passed(f"Pillow/RAQM load {pair.font_key}/{face.role} {face.family}")
            except Exception as exc:
                log.failed(f"Pillow/RAQM load {pair.font_key}/{face.role} {face.family}: {exc}")

        if render_smoke and companion.path.exists():
            for case in _load_cases(root):
                aid = _artifact_id(pair, case)
                try:
                    parsed = _parse_case(case)
                    display_codepoints = _display_codepoints_for_case(parsed, case)
                    adapted = adapt_numeric_cartouche(display_codepoints, pair.render_adapter_id, pair.render_adapter_settings, font_settings=pair.settings)
                    if "\ufffd" in adapted.text:
                        raise ValueError("render adapter produced U+FFFD")
                    if adapted.legacy_ascii:
                        semantic_ascii = ''.join(ch for ch in adapted.text if ord(ch) not in VULGAR_SCALE_MARKERS)
                        if not semantic_ascii.isascii():
                            raise ValueError("legacy adapter produced non-ASCII content other than v1.1 scale controls")
                    image = _render_text(adapted.text, companion.path, int(case["fontPx"]))
                    if not _image_nonblank(image):
                        raise ValueError("rendered image is blank")
                    log.passed(f"render {aid}: {image.width}x{image.height} adapter={adapted.adapter_id}")
                except Exception as exc:
                    log.failed(f"render {aid}: {exc}")

    print(f"font manifest: {len(manifest.pairs)} pair(s), {len(seen_files)} referenced font file(s), {len(required_cps)} required numeric/render codepoints")
    return log


def _environment_info() -> Dict[str, Any]:
    import PIL
    return {
        "pillow": getattr(PIL, "__version__", None),
        "raqm": features.version("raqm") if features.check("raqm") else None,
        "freetype2": features.version("freetype2") if features.check("freetype2") else None,
        "harfbuzz": features.version("harfbuzz") if features.check("harfbuzz") else None,
        "fribidi": features.version("fribidi") if features.check("fribidi") else None,
    }


def render_font_artifacts(root: Path) -> Tuple[FontManifest, Dict[str, Dict[str, Any]], Dict[str, Image.Image]]:
    manifest = load_font_manifest(root, required=True)
    assert manifest is not None
    cases = _load_cases(root)
    records: Dict[str, Dict[str, Any]] = {}
    images: Dict[str, Image.Image] = {}
    for pair in manifest.pairs:
        companion = pair.companion
        if not companion.path.exists():
            raise FileNotFoundError(f"{pair.font_key}: companion font missing: {companion.path}")
        for case in cases:
            parsed = _parse_case(case)
            display_codepoints = _display_codepoints_for_case(parsed, case)
            adapted = adapt_numeric_cartouche(display_codepoints, pair.render_adapter_id, pair.render_adapter_settings, font_settings=pair.settings)
            image = _render_text(adapted.text, companion.path, int(case["fontPx"]))
            aid = _artifact_id(pair, case)
            images[aid] = image
            records[aid] = {
                "fontKey": pair.font_key,
                "caseId": case["id"],
                "input": case["input"],
                "fontPx": int(case["fontPx"]),
                "abbreviateNumericCartouches": bool(case.get("abbreviateNumericCartouches")),
                "renderAdapterId": pair.render_adapter_id,
                "companionFilename": companion.path.name,
                "companionSha256": _sha256(companion.path),
                "width": image.width,
                "height": image.height,
                "rgbaSha256": _image_payload_hash(image),
            }
    expected = len(manifest.pairs) * EXPECTED_CASES_PER_PAIR
    if len(records) != expected:
        raise ValueError(f"font golden artifact count mismatch: expected {expected}, got {len(records)}")
    return manifest, records, images


def _golden_summary(records: Dict[str, Dict[str, Any]]) -> str:
    full = sum(1 for rec in records.values() if not rec.get("abbreviateNumericCartouches"))
    abbreviated = sum(1 for rec in records.values() if rec.get("abbreviateNumericCartouches"))
    return f"{len(records)} artifact(s) ({full} full + {abbreviated} abbreviated)"


def update_goldens(root: Path) -> int:
    manifest, records, images = render_font_artifacts(root)
    golden_dir = root / DEFAULT_GOLDEN_DIR
    golden_dir.mkdir(parents=True, exist_ok=True)
    for aid, image in images.items():
        filename = aid.replace("/", "_") + ".png"
        image.save(golden_dir / filename, format="PNG", optimize=False, compress_level=9)
        records[aid]["file"] = str((DEFAULT_GOLDEN_DIR / filename).as_posix())
        print(f"UPDATED {aid} {records[aid]['rgbaSha256']}")
    payload = {
        "schemaVersion": "1.0.0",
        "productionManifestSha256": _manifest_sha256(manifest.path),
        "environment": _environment_info(),
        "files": records,
    }
    out = root / DEFAULT_GOLDEN_MANIFEST
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Python font goldens: {_golden_summary(records)} UPDATED")
    return 0


def _baseline_record_matches(current: Dict[str, Any], old: Dict[str, Any]) -> List[str]:
    """Return differing regression fields, treating v0.1.1 full records as full cartouches.

    v0.1.1 did not store ``abbreviateNumericCartouches``.  Those records are
    necessarily full-cartouche records, so a missing field is equivalent to False.
    """
    diffs: List[str] = []
    for field in ("rgbaSha256", "width", "height", "companionSha256", "renderAdapterId"):
        if current.get(field) != old.get(field):
            diffs.append(field)
    current_abbr = bool(current.get("abbreviateNumericCartouches"))
    old_abbr = bool(old.get("abbreviateNumericCartouches", False))
    if current_abbr != old_abbr:
        diffs.append("abbreviateNumericCartouches")
    return diffs


def _lookup_baseline_record(
    expected_files: Dict[str, Dict[str, Any]],
    aid: str,
    current: Dict[str, Any],
) -> Tuple[Optional[str], Optional[Dict[str, Any]]]:
    """Find an approved record by canonical id, with a metadata fallback.

    The fallback makes baseline migration resilient to an old manifest whose
    dictionary key was rewritten while its recorded ``fontKey``/``caseId``
    identity remained intact.
    """
    direct = expected_files.get(aid)
    if isinstance(direct, dict):
        return aid, direct
    matches = [
        (key, rec)
        for key, rec in expected_files.items()
        if isinstance(rec, dict)
        and rec.get("fontKey") == current.get("fontKey")
        and rec.get("caseId") == current.get("caseId")
    ]
    if len(matches) == 1:
        return matches[0]
    return None, None


def test_goldens(root: Path, *, allow_missing: bool = False) -> int:
    baseline_path = root / DEFAULT_GOLDEN_MANIFEST
    if not baseline_path.exists():
        if allow_missing:
            print("Python font goldens: SKIP (no approved baseline yet; run `python scripts/font_goldens.py --update` after visual review)")
            return 0
        print("Python font goldens: FAIL (no approved baseline; run --update only after deliberate review)", file=sys.stderr)
        return 1
    baseline = json.loads(baseline_path.read_text(encoding="utf-8"))
    manifest, records, _images = render_font_artifacts(root)
    fail = 0
    if baseline.get("productionManifestSha256") != _manifest_sha256(manifest.path):
        print("FAIL production manifest changed; review and deliberately refresh Python font goldens", file=sys.stderr)
        fail += 1
    expected_files = baseline.get("files") or {}
    if not isinstance(expected_files, dict):
        print("FAIL approved golden manifest has invalid 'files' structure", file=sys.stderr)
        return 1

    consumed: Set[str] = set()
    overlap = 0
    for aid, current in records.items():
        old_key, old = _lookup_baseline_record(expected_files, aid, current)
        if old is None:
            print(f"FAIL {aid}: golden missing", file=sys.stderr)
            fail += 1
            continue
        assert old_key is not None
        consumed.add(old_key)
        overlap += 1
        diffs = _baseline_record_matches(current, old)
        if diffs:
            print(f"FAIL {aid}: changed fields {', '.join(diffs)}", file=sys.stderr)
            fail += 1
        else:
            print(f"PASS {aid} {current['rgbaSha256']}")
    for aid in expected_files:
        if aid not in consumed:
            print(f"FAIL stale golden entry: {aid}", file=sys.stderr)
            fail += 1
    print(
        f"golden baseline: {len(expected_files)} approved, {len(records)} current, {overlap} matched",
        file=sys.stderr if fail else sys.stdout,
    )
    if fail:
        print(f"Python font goldens: {fail} failure(s)", file=sys.stderr)
        return 1
    print(f"Python font goldens: {_golden_summary(records)} PASS")
    return 0


def extend_goldens(root: Path) -> int:
    """Extend an approved 64-full baseline with new abbreviated artifacts only.

    Existing approved artifacts are verified byte-for-render-byte through their
    stored hashes/geometry and are never overwritten.  This is the safe upgrade
    path from the v0.1.1 64-full baseline to the v0.1.3 128-artifact baseline.
    """
    baseline_path = root / DEFAULT_GOLDEN_MANIFEST
    if not baseline_path.exists():
        print("Python font goldens: EXTEND FAIL (no approved baseline exists)", file=sys.stderr)
        return 1
    baseline = json.loads(baseline_path.read_text(encoding="utf-8"))
    manifest, records, images = render_font_artifacts(root)
    if baseline.get("productionManifestSha256") != _manifest_sha256(manifest.path):
        print("Python font goldens: EXTEND FAIL (production manifest changed)", file=sys.stderr)
        return 1
    expected_files = baseline.get("files") or {}
    if not isinstance(expected_files, dict):
        print("Python font goldens: EXTEND FAIL (invalid approved manifest)", file=sys.stderr)
        return 1

    consumed: Set[str] = set()
    merged: Dict[str, Dict[str, Any]] = {}
    missing_abbreviated: List[str] = []
    problems: List[str] = []

    for aid, current in records.items():
        old_key, old = _lookup_baseline_record(expected_files, aid, current)
        if old is not None:
            assert old_key is not None
            consumed.add(old_key)
            diffs = _baseline_record_matches(current, old)
            if diffs:
                problems.append(f"{aid}: approved artifact changed fields {', '.join(diffs)}")
                continue
            normalized = dict(current)
            normalized["file"] = old.get("file") or str((DEFAULT_GOLDEN_DIR / (aid.replace('/', '_') + '.png')).as_posix())
            merged[aid] = normalized
            continue

        if not bool(current.get("abbreviateNumericCartouches")):
            problems.append(f"{aid}: approved full-cartouche golden missing")
            continue
        missing_abbreviated.append(aid)

    for stale in expected_files:
        if stale not in consumed:
            problems.append(f"stale approved golden entry: {stale}")

    if problems:
        for message in problems:
            print(f"FAIL {message}", file=sys.stderr)
        print(f"Python font goldens: EXTEND FAIL ({len(problems)} problem(s))", file=sys.stderr)
        return 1

    golden_dir = root / DEFAULT_GOLDEN_DIR
    golden_dir.mkdir(parents=True, exist_ok=True)
    for aid in missing_abbreviated:
        current = dict(records[aid])
        filename = aid.replace("/", "_") + ".png"
        images[aid].save(golden_dir / filename, format="PNG", optimize=False, compress_level=9)
        current["file"] = str((DEFAULT_GOLDEN_DIR / filename).as_posix())
        merged[aid] = current
        print(f"ADDED {aid} {current['rgbaSha256']}")

    if len(merged) != len(records):
        print(
            f"Python font goldens: EXTEND FAIL (expected {len(records)} merged artifacts, got {len(merged)})",
            file=sys.stderr,
        )
        return 1

    payload = {
        "schemaVersion": "1.1.0",
        "productionManifestSha256": _manifest_sha256(manifest.path),
        "environment": _environment_info(),
        "files": merged,
    }
    baseline_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(
        f"Python font goldens: {_golden_summary(merged)} EXTENDED "
        f"({len(missing_abbreviated)} abbreviated artifact(s) added; existing approved full artifacts preserved)"
    )
    return 0

def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--no-render-smoke", action="store_true")
    parser.add_argument("--test-goldens", action="store_true")
    parser.add_argument("--extend-goldens", action="store_true")
    args = parser.parse_args(argv)
    root = Path(args.root).resolve()
    try:
        log = inspect_and_test_fonts(root, render_smoke=not args.no_render_smoke)
    except Exception as exc:
        print(f"font regression: FAIL: {exc}", file=sys.stderr)
        return 1
    if log.failures:
        print(f"font regression: {log.checks} checks, {log.failures} failures", file=sys.stderr)
        return 1
    print(f"font regression: {log.checks} checks, 0 failures")
    if args.extend_goldens:
        return extend_goldens(root)
    if args.test_goldens:
        return test_goldens(root, allow_missing=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
