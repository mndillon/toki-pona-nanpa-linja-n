# Python reference — Protocol v1.1.0

This release upgrades the native Python implementation to the integrated Protocol v1.1.0 parser/renderer and production-font profile. It retains the frozen Core-v1 corpus, follows the current canonical JavaScript defaults and 35-operation parser surface, uses the supplied eight-font bundle, and replaces legacy stylistic-set cartouche scaling with inline vulgar-fraction controls.

The implementation remains native Python. The bundled JavaScript file is a qualification oracle only and is not executed by the library at runtime.
