# nanpa-linja-n Python reference implementation

Native Python reference implementation for **nanpa-linja-n Protocol v1.1.0**, qualified for parser and full-renderer semantic compatibility with the bundled canonical JavaScript reference.

The Python implementation does not execute or embed JavaScript at runtime. The canonical JavaScript renderer is retained in `reference/` as the behavioral oracle used by qualification tests. The current qualification uses the same **254-case canonical full-renderer corpus** and canonical syntax coverage used to qualify the Go reference implementation.

## Full renderer API

`NanpaLinjaN` now exposes the complete document-rendering surface used by the Full Renderer Profile:

```python
from pathlib import Path
from nanpa_linja_n import NanpaLinjaN

nanpa = NanpaLinjaN.create()

plan = nanpa.build_full_render_plan(
    'mi toki e ni: [jan pona,,] 123.45 "Hello"'
)

canvas = nanpa.render_to_canvas('jan [pona,,] 123.45')
Path('mixed.png').write_bytes(nanpa.render_full_to_png('jan [pona,,] 123.45'))
Path('mixed.svg').write_text(nanpa.render_to_svg('jan [pona,,] 123.45'))
Path('mixed.pdf').write_bytes(nanpa.render_to_pdf('jan [pona,,] 123.45'))
```

The full renderer supports:

- document AST/source segmentation and multiline input;
- ordinary sitelen pona words and mixed inline rendering;
- ordinary cartouches;
- automatic standalone proper-name cartouches;
- literal and interpreted quotes;
- raw UCSUR input and renderer text aliases;
- numeric/date/time/telephone/hex/binary cartouches;
- full and abbreviated numeric forms;
- all eight production font pairs and their manifest-selected adapters;
- manual and UCSUR tally modes;
- unknown-text display/decorations;
- inline images;
- alignment and spacing controls;
- halo/fill paint controls;
- Pillow canvas rendering and PNG;
- native vector-path SVG;
- vector PDF through CairoSVG;
- vector-document conversion;
- low-level run/text/UCSUR rendering;
- runtime render-adapter registration.

JavaScript-style aliases are also available on `NanpaLinjaN`, including `parseInput`, `astToText`, `parseNumber`, `buildRenderPlan`, `renderToCanvas`, `renderToPng`, `renderToSvg`, `renderToPdf`, `toVectorDocument`, `renderRunToNewCanvas`, `renderTextToNewCanvas`, `renderTextToCanvas`, `renderUcsurToNewCanvas`, and `renderUcsurToCanvas`.

### Editing a parsed document with `ast_to_text()`

Python exposes the AST serializer as the idiomatic `ast_to_text()` method/function, with `NanpaLinjaN.astToText()` provided as the JavaScript-style alias. This supports the same parse -> edit AST -> source text -> normal renderer workflow without changing the existing renderer path.

```python
from dataclasses import replace
from nanpa_linja_n import NanpaLinjaN

nanpa = NanpaLinjaN.create()
ast = nanpa.parse_input('jan   pona [ jan  pona,, ]')

line = ast.lines[0]
children = list(line.children)
index = next(i for i, segment in enumerate(children) if segment.kind == 'bracket')
children[index] = replace(children[index], value=' jan  suno,, ')

edited_ast = replace(
    ast,
    lines=(replace(line, children=tuple(children)),),
)

edited_text = nanpa.ast_to_text(edited_ast)
png = nanpa.render_full_to_png(edited_text, {"font": "linjaPona"})
```

`ast_to_text()` now also accepts the same explicit numeric text-output selector used by the JavaScript reference. The default remains source-preserving:

```python
ast = nanpa.parse_input("mi jo e 123")

assert nanpa.ast_to_text(ast, {"numericOutput": "source"}) == "mi jo e 123"
assert nanpa.ast_to_text(ast, {"numericOutput": "properName"}) == "mi jo e Nanpa Watusen"
assert nanpa.ast_to_text(ast, {"numericOutput": "#~"}) == "mi jo e #~WTS"
assert nanpa.ast_to_text(ast, {
    "numericOutput": "cartouche",
    "parser": {"abbreviateNumericCartouches": True},
}) == "mi jo e [nanpa : wan tu seli nanpa]"
assert nanpa.ast_to_text(ast, {
    "numericOutput": "cartouche",
    "parser": {"nasinNanpaPona": True},
}) == "mi jo e wan ale mute tu wan"
```

The allowed values are `source`, `properName`, `#~`, and `cartouche`. Existing numeric formatting flags continue to control the selected representation. If the requested representation is unavailable (for example `#~` for hexadecimal or binary input), the exact original numeric source is preserved. `parse_input()` keeps the established AST segment kinds and attaches optional `DocumentSegment.numeric_structures` metadata for recognized numeric spans.

The AST records are frozen dataclasses, so use `dataclasses.replace()` rather than mutating them in place. The application-editable content is primarily:

- `DocumentSegment.value` for `text`, `bracket`, and `quote` segments;
- `DocumentSegment.open_quote` and `close_quote` for quote delimiters;
- `DocumentSegment.image` and its `src`, `w`, `h`, `alt`, `valign`, `wriggle`, and `transparent` fields.

`source_start`, `source_end`, `DocumentLine.source_text`, and `DocumentAst.normalized_input` are source/diagnostic metadata; `ast_to_text()` serializes the current segment values rather than those stale originals. `DocumentLine.source_line_index` is used to reconstruct physical newlines when `breakLinesAtFullStops` split one source line into multiple AST lines. Exact original `img(...)` argument formatting is not retained, so image nodes are emitted in a canonical equivalent form. Parser normalization (for example CRLF -> LF or text aliases) can also prevent byte-for-byte reconstruction of the original input.

### Public `parseNumber()` parity API

The existing low-level `parse_number()` function and `NanpaParser.parseNumber()` remain unchanged. For cross-language facade parity, Python now also exposes a public `parseNumber()` wrapper and `NanpaLinjaN.parseNumber()` / `NanpaLinjaN.parse_number()` methods. These use the facade's established default parser profile and expose the alternative numeric representations needed by `ast_to_text()`, including `abbreviatedWords`, `abbreviatedUcsurCodepoints`, and `nasinNanpaPonaWords` when applicable.

```python
from nanpa_linja_n import NanpaLinjaN, parseNumber

parsed = parseNumber("123")
assert parsed["properName"] == "Nanpa Watusen"
assert parsed["uniqueCode"] == "#~WTS"
assert parsed["abbreviatedWords"] == ["nanpa", ":", "wan", "tu", "seli", "nanpa"]

nanpa = NanpaLinjaN.create()
assert nanpa.parseNumber("123")["uniqueCode"] == "#~WTS"
```

## Stable numeric facade

The established Python numeric facade remains available and unchanged so the approved 128-artifact Python baseline stays stable:

```python
from nanpa_linja_n import NanpaLinjaN

nanpa = NanpaLinjaN.create()
result = nanpa.render('123.45')
png = nanpa.render_to_png('12:30', font='linjaPona')
```

That legacy/stable numeric surface includes:

- `parse()`
- `build_render_plan()`
- `render()`
- `render_to_image()`
- `render_to_png()`
- `save_png()`

The full-document surface is additive and does not alter the approved numeric output path.

## Production fonts

The bundled font keys are:

- `nasinNanpa` (default)
- `sitelenSeliKiwen`
- `fairfaxHd`
- `fairfaxPonaHd`
- `linjaPona`
- `linjaSike`
- `nasinSitelenPuMono`
- `linjaLipamanka`

The package contains its production font bundle at `nanpa_linja_n/resources/fonts.zip`. All production font loading goes through that ZIP bundle for both the installed package and repository regression/visual-audit tooling.

## Manual tally behavior

Five production pairs use renderer-manual tallies:

- `nasinNanpa`
- `linjaPona`
- `linjaSike`
- `nasinSitelenPuMono`
- `linjaLipamanka`

For these fonts, **U+F199E is never inserted into the font run**. Synthetic tally strokes are positioned from the owning canonical glyph span in the complete shaped/adapted run.

The production renderer follows the canonical JavaScript cartouche coordinate system: crop to actual ink bounds, then apply the 6 px cartouche pad before deriving owner geometry. This is important for fonts with large side bearings, especially `linjaLipamanka`; centering against the uncropped run places the tallies incorrectly.

`linjaPona` additionally follows the current manifest setting `manualTallySmallFontLiftPx: 1` through `manualTallySmallFontMaxPx: 144`.

The other three production pairs use their native UCSUR U+F199E tally glyphs.

## Requirements

- Python 3.10+
- Pillow 9+ built with RAQM/HarfBuzz support
- fontTools 4.40+
- CairoSVG 2.7+ for vector PDF output
- system HarfBuzz (`libharfbuzz`) for complete-run shaping/caret geometry

The renderer deliberately fails rather than silently substituting unshaped production text where correct shaping is required.

## Regression testing

Run the complete non-fail-fast qualification gate:

```bash
python scripts/run_all.py
```

The consolidated report is written to `test-output/python-regression-report.txt`. The v1.1.0 release gate includes:

- compile checks;
- the frozen Core-v1 corpus: **1,030/1,030** checks;
- `ast_to_text()` / `astToText()` regression: **26/26** plus PNG integration;
- **26/26** native unit tests;
- exact current-JavaScript `NanpaParser` differential: **344 invocations, 0 mismatches**;
- production font regression and **128/128** Python font goldens across all eight font pairs;
- canonical syntax **28/28** and production adapters **5/5**;
- current canonical full renderer **254/254**;
- Protocol-v1.1 profile/default/font checks, including all **16/16** profile smoke cases;
- vector-quality checks requiring path-based SVG and PDF output with no raster image fallback for generated numeric-cartouche content.

Protocol v1.1.0 uses inline cartouche scale controls `¼`, `⅓`, `½`, `⅔`, `¾`. The production profile does **not** require legacy `ss12`, `ss13`, or `ss14` OpenType stylistic sets. Ordinary cartouches also accept the approved postfix ASCII aliases `1/4`, `1/3`, `1/2`, `2/3`, and `3/4` when the selected production font opts into `cartoucheVulgarFractions`.

The exact supplied `fonts.zip` is retained as the packaged resource. At extraction time the manifest-requested nasin-nanpa literal filename is provided, when absent, as a byte-identical compatibility copy of the supplied `LiberationSans-Regular.ttf`; the source ZIP itself is never modified.
