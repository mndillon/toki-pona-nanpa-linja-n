from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from nanpa_linja_n import NanpaLinjaN, list_fonts, render, render_to_png, save_png, parseNumber

ROOT = Path(__file__).resolve().parents[1]


def image_payload_hash(image) -> str:
    rgba = image.convert("RGBA")
    h = hashlib.sha256()
    h.update(f"RGBA:{rgba.width}x{rgba.height}:".encode("ascii"))
    h.update(rgba.tobytes())
    return h.hexdigest()


class FacadeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.nanpa = NanpaLinjaN.create()

    def test_lists_all_eight_production_fonts(self):
        fonts = self.nanpa.list_fonts()
        self.assertEqual(len(fonts), 8)
        self.assertEqual({font.key for font in fonts}, {
            "nasinNanpa", "sitelenSeliKiwen", "fairfaxHd", "fairfaxPonaHd",
            "linjaPona", "linjaSike", "nasinSitelenPuMono", "linjaLipamanka",
        })
        self.assertEqual(len(list_fonts()), 8)

    def test_font_alias_and_legacy_adapter_are_automatic(self):
        plan = self.nanpa.build_render_plan("2026-09-13", font="linja-pona")
        self.assertEqual(plan.font.key, "linjaPona")
        self.assertEqual(plan.render_adapter_id, "linja-pona-legacy-v1")
        self.assertTrue(plan.legacy_ascii)
        self.assertTrue(''.join(ch for ch in plan.render_text if ch not in '¼⅓½⅔¾').isascii())
        self.assertTrue(plan.render_text.startswith("[_suno"))

    def test_ast_to_text_numeric_outputs_and_public_parse_number(self):
        ast = self.nanpa.parse_input("mi jo e 123")
        self.assertEqual(self.nanpa.ast_to_text(ast, {"numericOutput": "source"}), "mi jo e 123")
        self.assertEqual(self.nanpa.astToText(ast, {"numericOutput": "properName"}), "mi jo e Nanpa Watusen")
        self.assertEqual(self.nanpa.ast_to_text(ast, {"numericOutput": "#~"}), "mi jo e #~WTS")
        self.assertEqual(
            self.nanpa.ast_to_text(ast, {"numericOutput": "cartouche", "parser": {"abbreviateNumericCartouches": True}}),
            "mi jo e [nanpa : wan tu seli nanpa]",
        )
        named = parseNumber("123")
        instance = self.nanpa.parseNumber("123")
        self.assertIsNone(parseNumber("12 34"))
        self.assertIsNone(self.nanpa.parseNumber("12 34"))
        self.assertEqual(named["uniqueCode"], "#~WTS")
        self.assertEqual(instance["properName"], "Nanpa Watusen")

    def test_one_call_render_and_png(self):
        result = render("12:30")
        self.assertEqual(result.font_key, "nasinNanpa")
        self.assertGreater(result.width, 0)
        self.assertGreater(result.height, 0)
        self.assertIsNotNone(result.image.getbbox())
        png = render_to_png("123.45", font="linjaPona")
        self.assertEqual(png[:8], b"\x89PNG\r\n\x1a\n")
        with tempfile.TemporaryDirectory() as td:
            path = save_png("0b10101", Path(td) / "out.png", font="linjaSike", parser_options={"enableBinaryParsing": True})
            self.assertTrue(path.exists())
            self.assertEqual(path.read_bytes()[:8], b"\x89PNG\r\n\x1a\n")

    def test_facade_matches_all_approved_font_goldens(self):
        cases_doc = json.loads((ROOT / "tests/font-golden-cases.json").read_text(encoding="utf-8"))
        baseline = json.loads((ROOT / "goldens/python-font-manifest.json").read_text(encoding="utf-8"))
        files = baseline["files"]
        for font in self.nanpa.list_fonts():
            for case in cases_doc["cases"]:
                with self.subTest(font=font.key, case=case["id"]):
                    result = self.nanpa.render(
                        case["input"],
                        font=font.key,
                        font_size=int(case["fontPx"]),
                        abbreviate=bool(case.get("abbreviateNumericCartouches")),
                        preserve_numeric_cartouche_breaks=bool(
                            case.get("preserveNumericCartoucheBreaksInAbbreviation", True)
                        ),
                        parser_options={
                            "enableHexParsing": str(case.get("input", "")).startswith("#"),
                            "enableBinaryParsing": str(case.get("input", "")).startswith("0b"),
                        },
                    )
                    aid = f"{font.key}__{case['id']}"
                    expected = files[aid]
                    self.assertEqual(result.width, expected["width"])
                    self.assertEqual(result.height, expected["height"])
                    self.assertEqual(image_payload_hash(result.image), expected["rgbaSha256"])
                    self.assertEqual(result.render_adapter_id, expected["renderAdapterId"])


if __name__ == "__main__":
    unittest.main()
