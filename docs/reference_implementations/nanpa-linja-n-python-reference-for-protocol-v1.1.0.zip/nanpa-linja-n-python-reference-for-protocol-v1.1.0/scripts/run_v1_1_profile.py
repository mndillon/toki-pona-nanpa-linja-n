#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from nanpa_linja_n import NanpaLinjaN
from nanpa_linja_n.parser import NanpaParser
from nanpa_linja_n.facade import DEFAULT_PARSER_OPTIONS
from nanpa_linja_n.font_registry import load_font_manifest

PROFILE=ROOT/'protocol'/'conformance'/'parser-renderer-profile-v1.1.0.json'
JS=ROOT/'reference'/'renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js'
FONTS=ROOT/'nanpa_linja_n'/'resources'/'fonts.zip'
EXPECTED_JS='fdeb3e3bfd46b9f86650fd411a2d1dfb2515580aa258aa8c11a002913631418c'
EXPECTED_FONTS='08d0409e0b180a6b90a0617fe557fd3e59a08dd26781d907ed5d772a9fefcae1'
EXPECTED_MANIFEST='50b8a4b6cab0c27f2061f94e404a2af992cbf95c8097c58caa5e6b2dc4625f09'
OPS={
'parseNumber','encodeDecimal','decimalToUcsurCodepoints','properNameToUcsurCodepoints','splitCapsToProperName',
'capsToUniqueCode','decodeCaps','ucsurCodepointsToTpWords','codepointsToWords','tpWordsToText','parseTpWordsToCodepoints',
'tpWordsToUcsurCodepoints','codepointsToHex','codepointsToHexWithCartouche','parseHexCodepoints','withCartoucheMarkers',
'stripCartoucheMarkers','isValidCaps','isValidProperName','isValidTimeOrDate','isValidTime','isValidDate','tokenizeCaps',
'capsTokensToTpWords','capsToWords','capsToCodepoints','parseIdentifier','normalizeVulgarFraction','normalizeTpWord',
'getSmallCodepointsSet','getQuarterCodepointsSet','getOneThirdCodepointsSet','getTwoThirdsCodepointsSet','getHalfCodepointsSet',
'isAllowedTpUcsurCodepoint'}

def sha(p:Path)->str:return hashlib.sha256(p.read_bytes()).hexdigest()

def normalized(result):
    if result is None:return None
    kind='hex' if result.get('isHex') else 'binary' if result.get('isBinary') else 'decimal'
    base=16 if kind=='hex' else 2 if kind=='binary' else 10
    return {
      'caps':result.get('caps'),'kind':kind,'numberBase':base,'properName':result.get('properName'),
      'uniqueCode':result.get('uniqueCode'),'displayValue':result.get('displayValue'),
      'semanticKind':result.get('semanticKind'),'semanticStartGlyph':result.get('semanticStartGlyph'),
      'isDate':bool(result.get('isDate')),'isTime':bool(result.get('isTime')),'numericMode':result.get('numericMode'),
      'tpWords':result.get('tpWords'),'abbreviatedWords':result.get('abbreviatedWords')
    }

def main()->int:
    checks=0; fails=[]
    def ck(cond,msg):
        nonlocal checks; checks+=1
        print(('PASS ' if cond else 'FAIL ')+msg)
        if not cond:fails.append(msg)
    profile=json.loads(PROFILE.read_text())
    ck(profile.get('profileVersion')=='1.1.0','profile version 1.1.0')
    ck(sha(JS)==EXPECTED_JS,'canonical JavaScript SHA-256')
    ck(sha(FONTS)==EXPECTED_FONTS,'supplied fonts.zip SHA-256')
    d=profile['defaults']
    expected_defaults={
      'numericMode':'uniform','relaxedNanpaLinjanParsing':True,'relaxedNanpaLinjanRendering':True,
      'nanpaColonParsing':True,'nanpaColonRendering':True,'abbreviateNumericCartouches':True,
      'preserveNumericCartoucheBreaksInAbbreviation':False,'breakLinesAtFullStops':False,
      'interpretDoubleQuotesAsTeTo':False,'numericCartoucheStartGlyph':None,'enableHexParsing':False,
      'enableBinaryParsing':False,'enableBinaryRendering':False,'nasinNanpaPona':False}
    for k,v in expected_defaults.items(): ck(DEFAULT_PARSER_OPTIONS.get(k)==v,f'default {k}={v!r}')
    public={name for name in dir(NanpaParser) if not name.startswith('_') and callable(getattr(NanpaParser,name))}
    ck(public==OPS,f'NanpaParser exact 35-operation surface ({len(public)})')
    smoke_ok=0
    for case in profile['nanpaParserSmokeCases']:
        got=normalized(NanpaParser.parseNumber(case['input'],case.get('options') or {}))
        want=case.get('result')
        ok=got==want
        ck(ok,'smoke '+case['id'])
        smoke_ok+=int(ok)
    manifest=load_font_manifest(ROOT,required=True); assert manifest is not None
    ck(hashlib.sha256(manifest.path.read_bytes()).hexdigest()==EXPECTED_MANIFEST,'production manifest SHA-256')
    ck(manifest.schema==2,'production manifest schema 2')
    ck(len(manifest.pairs)==8,'production manifest 8 font pairs')
    adapters=set()
    for pair in manifest.pairs:
        adapters.add(pair.render_adapter_id or 'identity')
        ck(pair.parser_mode=='sitelen-pona-ascii-extended',pair.font_key+' parser mode extended')
        ck(pair.settings.get('cartoucheVulgarFractions') is True,pair.font_key+' vulgar scaling enabled')
        ck(pair.settings.get('emulateLegacyCartoucheScaling') is False,pair.font_key+' legacy scale emulation disabled')
    ck(adapters=={'identity','linja-pona-legacy-v1','linja-sike-legacy-v1','nasin-sitelen-pu-mono-v1','linja-lipamanka-v1'},'production render-adapter inventory')
    n=NanpaLinjaN(project_root=ROOT)
    for source,marker in [('[jan½ pona]','½'),('[jan1/2 pona]','½'),('[jan 1/3 pona]','⅓')]:
        run=n.build_full_render_plan(source,{'font':'nasinNanpa'}).runs[0]
        ck(marker in run.render_text and ord(marker) not in run.canonical_codepoints,'ordinary cartouche postfix scale '+source)
    svg=n.render_to_svg('123.45',{'font':'nasinNanpa','parser':{'abbreviateNumericCartouches':False}})
    ck('<path' in svg,'numeric SVG contains vector path geometry')
    ck('<image' not in svg.lower() and 'data:image' not in svg.lower(),'numeric SVG has no raster image fallback')
    pdf=n.render_to_pdf('123.45',{'font':'nasinNanpa','parser':{'abbreviateNumericCartouches':False}})
    ck(pdf.startswith(b'%PDF-'),'numeric PDF signature')
    ck(b'/Subtype /Image' not in pdf,'numeric PDF has no raster Image XObject')
    print(f'Protocol v1.1 profile checks: {checks-len(fails)}/{checks} PASS')
    print(f'NanpaParser smoke cases: {smoke_ok}/{len(profile["nanpaParserSmokeCases"])} PASS')
    if fails:
        print('FAILED:',*fails,sep='\n - ');return 1
    print('PROTOCOL v1.1 PROFILE PASS');return 0
if __name__=='__main__':raise SystemExit(main())
