#!/usr/bin/env python3
from __future__ import annotations

from dataclasses import replace
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from nanpa_linja_n import (  # noqa: E402
    DocumentAst,
    DocumentLine,
    DocumentSegment,
    NanpaLinjaN,
    astToText,
    ast_to_text,
    parseNumber,
)


def check(condition: bool, label: str, detail: str = "") -> None:
    if not condition:
        suffix = f": {detail}" if detail else ""
        raise AssertionError(f"FAIL {label}{suffix}")
    print(f"PASS {label}")


def replace_first_segment(ast: DocumentAst, kind: str, **changes) -> DocumentAst:
    for line_index, line in enumerate(ast.lines):
        for segment_index, segment in enumerate(line.children):
            if segment.kind != kind:
                continue
            children = list(line.children)
            children[segment_index] = replace(segment, **changes)
            lines = list(ast.lines)
            lines[line_index] = replace(line, children=tuple(children))
            return replace(ast, lines=tuple(lines))
    raise AssertionError(f"segment kind not found: {kind}")


def main() -> None:
    nanpa = NanpaLinjaN.create()
    passed = 0

    source = 'jan   pona\t[ jan  pona,, ]\n\n“toki  pona”'
    ast = nanpa.parse_input(source)
    round_trip = nanpa.ast_to_text(ast)
    check(round_trip == source, "ast_to_text exact whitespace/blank-line/quote round-trip", repr(round_trip))
    passed += 1

    check(nanpa.astToText(ast) == source, "astToText JavaScript-style alias")
    passed += 1

    check(ast_to_text(ast) == source and astToText(ast) == source, "module-level ast_to_text / astToText")
    passed += 1

    split_source = 'jan pona. mi toki.\npona.'
    split_ast = nanpa.parse_input(split_source, parser_options={"breakLinesAtFullStops": True})
    check(len(split_ast.lines) == 3 and nanpa.ast_to_text(split_ast) == split_source,
          "breakLinesAtFullStops physical-line reconstruction")
    passed += 1

    edited = replace_first_segment(ast, "bracket", value=" jan  suno,, ")
    edited_text = nanpa.ast_to_text(edited)
    expected_edited = 'jan   pona\t[ jan  suno,, ]\n\n“toki  pona”'
    check(edited_text == expected_edited, "edited bracket serialization", repr(edited_text))
    passed += 1

    quote_edited = replace_first_segment(ast, "quote", value="Hello", open_quote='"', close_quote='"')
    quote_text = nanpa.ast_to_text(quote_edited)
    check(quote_text.endswith('"Hello"'), "edited quote content/delimiters", repr(quote_text))
    passed += 1

    image_source = "img(src='icon.png',w='20',h='30',alt='sample',valign='middle',wriggle=5,transparent=false)"
    image_ast = nanpa.parse_input(image_source)
    image_text = nanpa.ast_to_text(image_ast)
    image_round_trip = nanpa.parse_input(image_text)
    before = image_ast.lines[0].children[0].image
    after = image_round_trip.lines[0].children[0].image
    check(before == after, "image descriptor semantic round-trip", image_text)
    passed += 1

    bad_ast = DocumentAst(
        "document",
        "",
        {},
        (DocumentLine(0, 0, 0, "", (DocumentSegment("unsupported"),)),),
    )
    try:
        nanpa.ast_to_text(bad_ast)
    except TypeError:
        ok = True
    else:
        ok = False
    check(ok, "unsupported AST segment rejection")
    passed += 1

    numeric = nanpa.parse_input("mi jo e 123")
    numeric_segment = numeric.lines[0].children[0]
    check(numeric_segment.kind == "text" and len(numeric_segment.numeric_structures) == 1 and
          numeric_segment.numeric_structures[0]["sourceText"] == "123",
          "parse_input numeric span metadata without changing AST segment kind")
    passed += 1

    check(nanpa.ast_to_text(numeric, {"numericOutput": "source"}) == "mi jo e 123",
          "numericOutput source preserves numeric source")
    passed += 1

    check(nanpa.ast_to_text(numeric, {"numericOutput": "properName"}) == "mi jo e Nanpa Watusen",
          "numericOutput properName")
    passed += 1

    check(nanpa.ast_to_text(numeric, {"numericOutput": "#~"}) == "mi jo e #~WTS",
          "numericOutput #~")
    passed += 1

    full = nanpa.ast_to_text(numeric, {
        "numericOutput": "cartouche",
        "parser": {"abbreviateNumericCartouches": False},
    })
    check(full == "mi jo e [nanpa : wan ala tu uta seli e nanpa]", "full numeric cartouche", full)
    passed += 1

    abbreviated = nanpa.ast_to_text(numeric, {
        "numericOutput": "cartouche",
        "parser": {"abbreviateNumericCartouches": True},
    })
    check(abbreviated == "mi jo e [nanpa : wan tu seli nanpa]", "abbreviated numeric cartouche", abbreviated)
    passed += 1

    nnp = nanpa.ast_to_text(numeric, {
        "numericOutput": "cartouche",
        "parser": {"nasinNanpaPona": True},
    })
    check(nnp == "mi jo e wan ale mute tu wan", "nasin nanpa pona output", nnp)
    passed += 1

    nnp_hash = nanpa.ast_to_text(numeric, {
        "numericOutput": "#~",
        "parser": {"nasinNanpaPona": True},
    })
    check(nnp_hash == "mi jo e wan ale mute tu wan", "nasin nanpa pona precedence over #~", nnp_hash)
    passed += 1

    fallback = nanpa.parse_input("#ABC 0b1010", parser_options={"enableHexParsing": True, "enableBinaryParsing": True})
    fallback_text = nanpa.ast_to_text(fallback, {
        "numericOutput": "#~",
        "parser": {"enableHexParsing": True, "enableBinaryParsing": True},
    })
    check(fallback_text == "#ABC 0b1010", "#~ fallback preserves hex/binary source", fallback_text)
    passed += 1

    mixed = nanpa.parse_input("1+1/2")
    without_break = nanpa.ast_to_text(mixed, {
        "numericOutput": "cartouche",
        "parser": {
            "abbreviateNumericCartouches": True,
            "preserveNumericCartoucheBreaksInAbbreviation": False,
        },
    })
    with_break = nanpa.ast_to_text(mixed, {
        "numericOutput": "cartouche",
        "parser": {
            "abbreviateNumericCartouches": True,
            "preserveNumericCartoucheBreaksInAbbreviation": True,
        },
    })
    check(without_break == "[nanpa : wan kin wan o o tu nanpa]" and
          with_break == "[nanpa : wan kin wan o o tu nanpa]",
          "valid mixed fraction uses kin delimiter", f"{without_break!r} / {with_break!r}")
    passed += 1

    whitespace_public = parseNumber("12 34")
    whitespace_instance = nanpa.parseNumber("12 34")
    check(whitespace_public is None and whitespace_instance is None,
          "parseNumber rejects internal digit whitespace")
    passed += 1

    whitespace_doc = nanpa.parse_input("12 34")
    structures = whitespace_doc.lines[0].children[0].numeric_structures
    check([item.get("sourceText") for item in structures] == ["12", "34"],
          "document parser treats whitespace as numeric token boundary", repr(structures))
    passed += 1

    multiple = nanpa.parse_input("a 123 b 45 c")
    check(nanpa.ast_to_text(multiple, {"numericOutput": "#~"}) == "a #~WTS b #~AL c",
          "multiple numeric structures preserve surrounding text")
    passed += 1

    stale = nanpa.parse_input("123")
    stale_seg = stale.lines[0].children[0]
    edited_seg = replace(stale_seg, value="124")
    edited_line = replace(stale.lines[0], children=(edited_seg,))
    stale_edited = replace(stale, lines=(edited_line,))
    check(nanpa.ast_to_text(stale_edited, {"numericOutput": "properName"}) == "124",
          "stale numeric metadata does not rewrite edited source")
    passed += 1

    bracket_numeric = nanpa.parse_input("[nanpa : wan ala tu uta seli e nanpa]")
    check(bracket_numeric.lines[0].children[0].kind == "bracket" and
          bracket_numeric.lines[0].children[0].numeric_structures and
          nanpa.ast_to_text(bracket_numeric, {"numericOutput": "#~"}) == "#~WTS",
          "numeric bracket metadata and conversion")
    passed += 1

    public = parseNumber("123")
    instance = nanpa.parseNumber("123")
    check(public and instance and public.get("properName") == "Nanpa Watusen" and
          public.get("uniqueCode") == "#~WTS" and "abbreviatedWords" not in public and
          "nasinNanpaPonaWords" not in public and instance.get("uniqueCode") == "#~WTS",
          "public parseNumber named and instance APIs match v1.1 surface")
    passed += 1

    public_nnp = parseNumber("123", {"parser": {"nasinNanpaPona": True}})
    check(public_nnp and "nasinNanpaPonaWords" not in public_nnp,
          "parseNumber keeps v1.1 public surface with nasinNanpaPona enabled")
    passed += 1

    try:
        nanpa.ast_to_text(numeric, {"numericOutput": "abbreviation"})
    except ValueError:
        ok = True
    else:
        ok = False
    check(ok, "unsupported numericOutput rejection")
    passed += 1

    print(f"Python ast_to_text regression: {passed}/{passed} PASS")

    png = nanpa.render_full_to_png(edited_text, {"font": "linjaPona", "fontSize": 56})
    check(png.startswith(b"\x89PNG\r\n\x1a\n"), "edited AST -> text -> PNG render integration")
    print("Python ast_to_text render integration: 1/1 PASS")


if __name__ == "__main__":
    main()
