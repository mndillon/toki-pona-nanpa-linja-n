#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import sys
import tomllib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST_PATH = ROOT / "RELEASE-MANIFEST.json"

EXPECTED = {
    "packageVersion": "1.1.0",
    "protocolVersion": "1.1.0",
    "canonicalJavaScriptSha256": "fdeb3e3bfd46b9f86650fd411a2d1dfb2515580aa258aa8c11a002913631418c",
    "fontsZipSha256": "08d0409e0b180a6b90a0617fe557fd3e59a08dd26781d907ed5d772a9fefcae1",
    "parserRendererProfileSha256": "009ecab501a57c1b64fd1ff1f9fac50b072aecb706a162970b1f17c0cc45338b",
    "regressionCorpusSha256": "e4baf51251861c114f5314fc2af05eb44e1b5dbcbdebdcd2678c868f5dbf306a",
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def included(rel: Path) -> bool:
    parts = rel.parts
    if rel.as_posix() == "RELEASE-MANIFEST.json":
        return False
    if "__pycache__" in parts or "test-output" in parts or "build" in parts:
        return False
    if rel.suffix == ".pyc":
        return False
    if any(part.endswith(".egg-info") for part in parts):
        return False
    return True


def fail(msg: str) -> None:
    print(f"FAIL {msg}")
    raise SystemExit(1)


def main() -> None:
    if not MANIFEST_PATH.exists():
        fail("RELEASE-MANIFEST.json missing")
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))

    for key, value in EXPECTED.items():
        if manifest.get(key) != value:
            fail(f"manifest {key}: expected {value!r}, got {manifest.get(key)!r}")

    pyproject = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    if pyproject.get("project", {}).get("version") != EXPECTED["packageVersion"]:
        fail("pyproject.toml package version is not 1.1.0")

    protocol = json.loads((ROOT / "protocol/protocol.json").read_text(encoding="utf-8"))
    if protocol.get("protocolVersion") != EXPECTED["protocolVersion"]:
        fail("protocol/protocol.json protocolVersion is not 1.1.0")

    fixed = {
        "reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js": EXPECTED["canonicalJavaScriptSha256"],
        "nanpa_linja_n/resources/fonts.zip": EXPECTED["fontsZipSha256"],
        "protocol/conformance/parser-renderer-profile-v1.1.0.json": EXPECTED["parserRendererProfileSha256"],
        "tests/nanpa-linja-n-regression-v1.0.2.json": EXPECTED["regressionCorpusSha256"],
    }
    for rel, expected_hash in fixed.items():
        actual = sha256(ROOT / rel)
        if actual != expected_hash:
            fail(f"fixed authority hash {rel}: {actual} != {expected_hash}")

    recorded = manifest.get("files", {})
    actual_files = {
        p.relative_to(ROOT).as_posix(): sha256(p)
        for p in ROOT.rglob("*")
        if p.is_file() and included(p.relative_to(ROOT))
    }
    if set(recorded) != set(actual_files):
        missing = sorted(set(recorded) - set(actual_files))
        extra = sorted(set(actual_files) - set(recorded))
        fail(f"release file set differs; missing={missing} extra={extra}")

    mismatches = [
        rel for rel, digest in actual_files.items()
        if recorded.get(rel) != digest
    ]
    if mismatches:
        fail(f"release hash mismatch: {mismatches}")

    summary = json.loads((ROOT / "validation-summary.json").read_text(encoding="utf-8"))
    if summary.get("packageVersion") != "1.1.0" or summary.get("protocolVersion") != "1.1.0":
        fail("validation-summary release identity mismatch")
    gate = summary.get("validation", {}).get("aggregateConfiguredGate", {})
    if gate.get("status") != "PASS" or gate.get("configuredSuites") != 9 or gate.get("failedSuites") != 0:
        fail("validation-summary consolidated gate is not 9/9 PASS")

    print(f"PASS release identity {EXPECTED['packageVersion']} / protocol {EXPECTED['protocolVersion']}")
    print(f"PASS canonical JavaScript {EXPECTED['canonicalJavaScriptSha256']}")
    print(f"PASS supplied fonts.zip {EXPECTED['fontsZipSha256']}")
    print(f"PASS parser-renderer profile {EXPECTED['parserRendererProfileSha256']}")
    print(f"PASS frozen Core corpus {EXPECTED['regressionCorpusSha256']}")
    print(f"PASS {len(actual_files)} release file hashes and exact file set")


if __name__ == "__main__":
    main()
