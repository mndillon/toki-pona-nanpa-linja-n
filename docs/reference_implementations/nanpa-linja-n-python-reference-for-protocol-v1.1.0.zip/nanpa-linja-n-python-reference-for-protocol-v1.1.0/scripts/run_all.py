#!/usr/bin/env python3
from __future__ import annotations
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REFERENCE_JS = ROOT / 'reference' / 'renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js'
BUNDLE = ROOT / 'nanpa_linja_n' / 'resources' / 'fonts.zip'
PROFILE = ROOT / 'protocol' / 'conformance' / 'parser-renderer-profile-v1.1.0.json'
CANONICAL_SYNTAX = ROOT / 'conformance' / 'canonical-syntax-v1.0.1-phase1' / 'cases.json'
CANONICAL_FULL = ROOT / 'conformance' / 'full-renderer-canonical-v1.1.0' / 'cases.json'
REPORT = ROOT / 'test-output' / 'python-regression-report.txt'

commands: list[tuple[str,list[str]]] = [
    ('compileall', [sys.executable, '-m', 'compileall', '-q', str(ROOT / 'nanpa_linja_n'), str(ROOT / 'tests'), str(ROOT / 'scripts')]),
    ('protocol regression', [sys.executable, str(ROOT / 'scripts' / 'run_regression.py')]),
    ('ast_to_text', [sys.executable, str(ROOT / 'scripts' / 'run_ast_to_text.py')]),
    ('unit tests', [sys.executable, '-m', 'unittest', 'discover', '-s', str(ROOT / 'tests'), '-p', 'test_*.py']),
]

skips: list[str] = []
if REFERENCE_JS.exists() and shutil.which('node'):
    commands.append(('JavaScript differential', [sys.executable, str(ROOT / 'scripts' / 'run_differential.py'), str(REFERENCE_JS)]))
elif not REFERENCE_JS.exists():
    skips.append(f'JavaScript differential: SKIP ({REFERENCE_JS.relative_to(ROOT)} not found)')
else:
    skips.append('JavaScript differential: SKIP (node not found)')

if BUNDLE.exists():
    commands.append(('production font regression', [sys.executable, str(ROOT / 'scripts' / 'run_font_regression.py')]))
else:
    skips.append(f'production font regression: SKIP ({BUNDLE.relative_to(ROOT)} not found)')

if CANONICAL_SYNTAX.exists():
    commands.append(('canonical syntax + adapters', [sys.executable, str(ROOT / 'scripts' / 'run_canonical_syntax.py')]))
else:
    skips.append(f'canonical syntax + adapters: SKIP ({CANONICAL_SYNTAX.relative_to(ROOT)} not found)')

if CANONICAL_FULL.exists():
    commands.append(('canonical full renderer', [sys.executable, str(ROOT / 'scripts' / 'run_canonical_full_renderer.py')]))
else:
    skips.append(f'canonical full renderer: SKIP ({CANONICAL_FULL.relative_to(ROOT)} not found)')

if PROFILE.exists():
    commands.append(('Protocol v1.1 profile + vector quality', [sys.executable, str(ROOT / 'scripts' / 'run_v1_1_profile.py')]))
else:
    skips.append(f'Protocol v1.1 profile: SKIP ({PROFILE.relative_to(ROOT)} not found)')


def emit(lines: list[str], value: str='') -> None:
    print(value, flush=True)
    lines.append(value)


def main() -> int:
    report: list[str] = []
    emit(report, 'nanpa-linja-n Python consolidated regression report')
    emit(report, f'generatedUtc: {datetime.now(timezone.utc).isoformat()}')
    emit(report, f'python: {sys.version.split()[0]}')
    emit(report, f'root: {ROOT}')
    emit(report)
    for item in skips: emit(report, item)
    if skips: emit(report)

    results: list[tuple[str,int]] = []
    for label, cmd in commands:
        emit(report, f'=== {label} ===')
        emit(report, '+ ' + ' '.join(map(str,cmd)))
        proc = subprocess.run(cmd, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        output = proc.stdout or ''
        if output:
            print(output, end='' if output.endswith('\n') else '\n', flush=True)
            report.extend(output.rstrip('\n').splitlines())
        status = 'PASS' if proc.returncode == 0 else f'FAIL (exit {proc.returncode})'
        emit(report, f'=== RESULT: {label}: {status} ===')
        emit(report)
        results.append((label,proc.returncode))

    emit(report, '=== CONSOLIDATED SUMMARY ===')
    for label, rc in results: emit(report, f'{"PASS" if rc == 0 else "FAIL"}: {label}')
    failed=[label for label,rc in results if rc]
    emit(report, f'configured suites: {len(results)}')
    emit(report, f'failed suites: {len(failed)}')
    if failed: emit(report, 'failed: ' + ', '.join(failed))
    else: emit(report, 'ALL CONFIGURED PYTHON TESTS PASS')

    REPORT.parent.mkdir(parents=True,exist_ok=True)
    REPORT.write_text('\n'.join(report)+'\n',encoding='utf-8')
    print(f'consolidated report: {REPORT.relative_to(ROOT)}', flush=True)
    return 1 if failed else 0

if __name__ == '__main__':
    raise SystemExit(main())
