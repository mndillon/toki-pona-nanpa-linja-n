//! Protocol v1.1 numeric normalizations layered above frozen Core-v1.

/// Collapse historical Core-v1 mixed/fraction marker expansions to the
/// Protocol-v1.1 abbreviated surface without modifying frozen Core sources.
pub fn normalize_v11_abbreviated_words<I, S>(words: I) -> Vec<String>
where
    I: IntoIterator<Item = S>,
    S: AsRef<str>,
{
    let input: Vec<String> = words.into_iter().map(|s| s.as_ref().to_string()).collect();
    let mut out = Vec::with_capacity(input.len());
    let mut i = 0usize;
    while i < input.len() {
        let has = |needle: &[&str]| -> bool {
            i + needle.len() <= input.len()
                && needle.iter().enumerate().all(|(j, w)| input[i + j] == *w)
        };
        // NONONO -> o o o (must precede NONO).
        if has(&["nena", "o", "nena", "o", "nena", "o"]) {
            out.extend(["o", "o", "o"].into_iter().map(str::to_string));
            i += 6;
            continue;
        }
        // NOKO, the mixed-fraction delimiter -> kin.
        if has(&["nena", "open", "kin", "open"]) {
            out.push("kin".to_string());
            i += 4;
            continue;
        }
        // NONO, the fraction delimiter -> o o.
        if has(&["nena", "o", "nena", "o"]) {
            out.extend(["o", "o"].into_iter().map(str::to_string));
            i += 4;
            continue;
        }
        out.push(input[i].clone());
        i += 1;
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn mixed_fraction_marker_collapses_to_kin() {
        let got = normalize_v11_abbreviated_words([
            "nanpa", ":", "wan", "nena", "open", "kin", "open",
            "wan", "nena", "o", "nena", "o", "tu", "nanpa",
        ]);
        assert_eq!(got.join(" "), "nanpa : wan kin wan o o tu nanpa");
    }
}


/// Normalize the frozen Core-v1 yearless-date separator to the current v1.1
/// public spelling (`kasi`) without changing the Core parser tables.
pub fn normalize_v11_yearless_date_result(mut parsed: crate::model::ParseResult) -> crate::model::ParseResult {
    let yearless = parsed.input.starts_with("--") || parsed.input.starts_with("XXXX-");
    if !yearless || !parsed.is_date { return parsed; }
    const KULUPU: u32 = 0xF191F;
    const KASI: u32 = 0xF1917;
    fn cps(xs: &mut [u32]) { for cp in xs { if *cp == KULUPU { *cp = KASI; } } }
    fn words(xs: &mut [String]) { for word in xs { if word == "kulupu" { *word = "kasi".into(); } } }
    cps(&mut parsed.ucsur_codepoints);
    cps(&mut parsed.inner_codepoints);
    cps(&mut parsed.codepoints);
    if let Some(ref mut xs)=parsed.abbreviated_ucsur_codepoints { cps(xs); }
    words(&mut parsed.tp_words);
    words(&mut parsed.words);
    if let Some(ref mut xs)=parsed.abbreviated_words { words(xs); }
    parsed
}
