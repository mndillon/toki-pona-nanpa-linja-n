//! Protocol-v1.1 public numeric parser layered over the frozen Core-v1 parser.
//!
//! Core-v1 source and `ParseOptions::default()` remain hash-pinned.  This
//! module supplies the v1.1 public defaults and canonical public result shape.

use crate::model::ParseResult;
use crate::options::{MixedStyle, NumericMode, ParseOptions};

/// Protocol-v1.1 public parser defaults.
pub fn default_public_parse_options() -> ParseOptions {
    ParseOptions {
        enable_binary_parsing: false,
        enable_hex_parsing: false,
        mixed_style: MixedStyle::Short,
        mode: NumericMode::Uniform,
        numeric_mode: NumericMode::Uniform,
        nanpa_colon_parsing: true,
        nanpa_colon_rendering: true,
        relaxed_nanpa_linjan_parsing: true,
        relaxed_nanpa_linjan_rendering: true,
        abbreviate_numeric_cartouches: true,
        preserve_numeric_cartouche_breaks_in_abbreviation: false,
        numeric_cartouche_start_glyph: None,
        nasin_nanpa_pona: false,
    }
}

fn canonical_public_result(mut parsed: ParseResult) -> ParseResult {
    // Canonical v1.1 decimal/date/time parseNumber results do not expose the
    // serializer-only convenience alternatives.  Hex/binary results retain
    // their explicit abbreviated forms as in the canonical JavaScript API.
    if parsed.is_decimal() {
        parsed.abbreviated_ucsur_codepoints = None;
        parsed.abbreviated_words = None;
        parsed.nasin_nanpa_pona_words = None;
    }
    parsed
}

/// Parse with Protocol-v1.1 public defaults.
pub fn parse_number(input: &str) -> Option<ParseResult> {
    parse_number_with_options(input, &default_public_parse_options())
}

/// Parse with caller-supplied options while retaining the v1.1 public result
/// shape.  The frozen Core parser remains available at `crate::parser`.
pub fn parse_number_with_options(input: &str, options: &ParseOptions) -> Option<ParseResult> {
    crate::parser::parse_number(input, options).map(crate::v11_numeric::normalize_v11_yearless_date_result).map(canonical_public_result)
}
