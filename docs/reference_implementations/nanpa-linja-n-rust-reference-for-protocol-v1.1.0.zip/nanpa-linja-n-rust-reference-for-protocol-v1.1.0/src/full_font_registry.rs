use serde::Deserialize;
use serde_json::Value;
use std::collections::BTreeMap;

use crate::font_zip;

const MANIFEST_ENTRY: &str = "fonts/preloaded-font-pairs.manifest.json";

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
struct ManifestDoc {
    schema: u32,
    pairs: Vec<ManifestPair>,
    #[serde(default)]
    support_fonts: BTreeMap<String, ManifestSupportFont>,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
struct ManifestPair {
    font_key: String,
    #[serde(default)] label: String,
    #[serde(default)] parser_mode: String,
    #[serde(default = "identity")] render_adapter_id: String,
    #[serde(default)] render_adapter_settings: BTreeMap<String, Value>,
    #[serde(default)] settings: BTreeMap<String, Value>,
    #[serde(default)] base_family: String,
    #[serde(default)] companion_family: String,
    #[serde(default)] base_filename: String,
    #[serde(default)] companion_filename: String,
    #[serde(default)] literal_cartouche_family: String,
    #[serde(default)] literal_cartouche_filename: String,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
struct ManifestSupportFont {
    #[serde(default)]
    filename: String,
}

fn identity() -> String { "identity".to_string() }

#[derive(Debug, Clone)]
pub struct FullFontInfo {
    pub key: String, pub label: String, pub parser_mode: String, pub render_adapter_id: String,
    pub render_adapter_settings: BTreeMap<String, Value>, pub settings: BTreeMap<String, Value>,
    pub base_family: String, pub companion_family: String, pub base_filename: String, pub companion_filename: String,
    pub literal_cartouche_family: String, pub literal_cartouche_filename: String,
}

#[derive(Debug, Clone)]
pub struct FullFontRegistry {
    fonts: Vec<FullFontInfo>,
    support_fonts: BTreeMap<String, String>,
}

impl FullFontRegistry {
    pub fn bundled() -> Result<Self,String> {
        let manifest = font_zip::entry_str(MANIFEST_ENTRY)?;
        let doc:ManifestDoc=serde_json::from_str(manifest).map_err(|e|format!("full font manifest invalid: {e}"))?;
        if doc.schema!=2 {return Err(format!("unsupported full font manifest schema {}",doc.schema));}
        let fonts=doc.pairs.into_iter().map(|p|FullFontInfo{
            key:p.font_key.clone(), label:if p.label.trim().is_empty(){p.font_key}else{p.label}, parser_mode:p.parser_mode,
            render_adapter_id:if p.render_adapter_id.trim().is_empty(){"identity".into()}else{p.render_adapter_id},
            render_adapter_settings:p.render_adapter_settings,settings:p.settings,base_family:p.base_family,companion_family:p.companion_family,
            base_filename:p.base_filename,companion_filename:p.companion_filename,literal_cartouche_family:p.literal_cartouche_family,literal_cartouche_filename:p.literal_cartouche_filename,
        }).collect();
        let support_fonts=doc.support_fonts.into_iter().filter_map(|(key,font)|{
            if font.filename.trim().is_empty(){None}else{Some((key,font.filename))}
        }).collect();
        Ok(Self{fonts,support_fonts})
    }
    pub fn list(&self)->&[FullFontInfo]{&self.fonts}
    pub fn get(&self,key:&str)->Option<&FullFontInfo>{ let n=normalize(key); self.fonts.iter().find(|f|[&f.key,&f.label,&f.base_family,&f.companion_family].iter().any(|x|normalize(x)==n)) }
    pub fn support_font_filename(&self,key:&str)->Option<&str>{self.support_fonts.get(key).map(String::as_str)}
}
fn normalize(v:&str)->String{v.chars().filter(|c|c.is_ascii_alphanumeric()).flat_map(|c|c.to_lowercase()).collect()}

pub fn bundled_full_font_bytes(filename:&str)->Option<&'static [u8]>{
    let entry=format!("fonts/{filename}");
    if let Ok(bytes)=font_zip::entry(&entry){return Some(bytes);}
    // Protocol v1.1 manifest compatibility alias: the literal-cartouche font
    // is deliberately byte-identical to the bundled Liberation Sans donor.
    // Keep fonts.zip byte-for-byte authoritative and resolve the alias here.
    if filename=="nanpa-linja-n-nasin-nanpa-liberation-sans-literal.ttf"{
        return font_zip::entry("fonts/LiberationSans-Regular.ttf").ok();
    }
    None
}

pub fn setting_string(m:&BTreeMap<String,Value>,key:&str,default:&str)->String{m.get(key).and_then(Value::as_str).filter(|s|!s.trim().is_empty()).unwrap_or(default).to_string()}
pub fn setting_f64(m:&BTreeMap<String,Value>,key:&str,default:f64)->f64{m.get(key).and_then(Value::as_f64).unwrap_or(default)}
pub fn setting_i64(m:&BTreeMap<String,Value>,key:&str,default:i64)->i64{m.get(key).and_then(Value::as_i64).or_else(||m.get(key).and_then(Value::as_u64).map(|x|x as i64)).unwrap_or(default)}
