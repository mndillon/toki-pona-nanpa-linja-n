//! Production-font adapter subset used by numeric cartouche rendering.
//!
//! Most companion fonts consume canonical UCSUR directly.  The two legacy
//! fonts consume their native ASCII ligature syntax.  This mirrors the
//! production renderer contract rather than asking callers to know the
//! difference.

use crate::api::codepoint_to_word;
use serde_json::Value;
use std::collections::BTreeMap;
use crate::protocol::{CARTOUCHE_END, CARTOUCHE_START};

const COLON: u32 = 0xF199D;
const MIDDLE_DOT: u32 = 0xF199C;
const TALLY: u32 = 0xF199E;
const OPEN_QUOTE: u32 = 0x300C;
const CLOSE_QUOTE: u32 = 0x300D;

pub const VULGAR_SCALE_QUARTER: u32 = 0x00BC; // ¼
pub const VULGAR_SCALE_THIRD: u32 = 0x2153; // ⅓
pub const VULGAR_SCALE_HALF: u32 = 0x00BD; // ½
pub const VULGAR_SCALE_TWO_THIRDS: u32 = 0x2154; // ⅔
pub const VULGAR_SCALE_THREE_QUARTERS: u32 = 0x00BE; // ¾

pub fn is_vulgar_scale_marker(cp: u32) -> bool {
    matches!(cp, VULGAR_SCALE_QUARTER | VULGAR_SCALE_THIRD | VULGAR_SCALE_HALF | VULGAR_SCALE_TWO_THIRDS | VULGAR_SCALE_THREE_QUARTERS)
}

fn setting_bool(values: &BTreeMap<String, Value>, key: &str, fallback: bool) -> bool {
    values.get(key).and_then(Value::as_bool).unwrap_or(fallback)
}

pub fn vulgar_scaling_enabled(settings: &BTreeMap<String, Value>) -> bool {
    setting_bool(settings, "cartoucheVulgarFractions", false)
        || setting_bool(settings, "emulateLegacyCartoucheScaling", false)
}

fn cp_for_word(word: &str) -> Option<u32> {
    (0xF1900..=0xF19FF).find(|cp| codepoint_to_word(*cp) == Some(word))
}

pub fn numeric_cartouche_scale_marker(cps: &[u32], index: usize) -> u32 {
    if index == 0 || index + 1 >= cps.len() { return 0; }
    let cp = cps[index];
    let first = 1usize;
    let last = cps.len() - 2;
    let nanpa = cp_for_word("nanpa").unwrap_or(0xF193D);
    let nasa = cp_for_word("nasa").unwrap_or(0xF193E);
    let noka = cp_for_word("noka").unwrap_or(0xF1943);
    let tenpo = cp_for_word("tenpo").unwrap_or(0xF196B);
    let suno = cp_for_word("suno").unwrap_or(0xF1964);
    let toki = cp_for_word("toki").unwrap_or(0xF196C);
    let half_heads = [nanpa, nasa, noka, tenpo, suno, toki];
    let half_closers = [nanpa, nasa, noka];
    if index == first && half_heads.contains(&cp) { return VULGAR_SCALE_HALF; }
    if index == first + 1 && cp == COLON && half_heads.contains(&cps[first]) { return VULGAR_SCALE_HALF; }
    if index == last && half_closers.contains(&cp) { return VULGAR_SCALE_HALF; }

    let en = cp_for_word("en").unwrap_or(0xF190A);
    let nena = cp_for_word("nena").unwrap_or(0xF1940);
    let e = cp_for_word("e").unwrap_or(0xF1909);
    if cp == en && cps.len() >= 4 && half_heads.contains(&cps[first]) {
        if index == first + 1
            || (index == first + 2 && cps[first + 1] == COLON)
            || (index == first + 3 && cps[first + 2] == nena && (cps[first + 1] == e || cps[first + 1] == COLON))
        { return VULGAR_SCALE_TWO_THIRDS; }
    }
    if let Some(word) = codepoint_to_word(cp) {
        if !word.is_empty() && (word.starts_with('e') || word.starts_with('n')) && word.chars().all(|c| c.is_ascii_lowercase()) {
            return VULGAR_SCALE_QUARTER;
        }
    }
    for word in ["ala", "ike", "uta", "open"] { if cp_for_word(word) == Some(cp) { return VULGAR_SCALE_QUARTER; } }
    for word in ["kasi", "kule"] { if cp_for_word(word) == Some(cp) { return VULGAR_SCALE_THIRD; } }
    if cp_for_word("kala") == Some(cp) { return VULGAR_SCALE_HALF; }
    for word in ["ona", "o", "kulupu", "kipisi", "kin"] { if cp_for_word(word) == Some(cp) { return VULGAR_SCALE_TWO_THIRDS; } }
    0
}

pub fn render_codepoints_without_scale_markers(text: &str) -> Vec<u32> {
    text.chars().map(u32::from).filter(|cp| !is_vulgar_scale_marker(*cp)).collect()
}


pub const LEGACY_ASCII_ADAPTERS: [&str; 2] = [
    "linja-pona-legacy-v1",
    "linja-sike-legacy-v1",
];

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AdaptedRun {
    pub text: String,
    pub adapter_id: String,
    pub canonical_codepoints: Vec<u32>,
    pub legacy_ascii: bool,
}

fn is_legacy_adapter(adapter_id: &str) -> bool {
    LEGACY_ASCII_ADAPTERS.iter().any(|candidate| *candidate == adapter_id)
}

fn append_scale_marker(out: &mut String, cps: &[u32], index: usize, enabled: bool) {
    if !enabled { return; }
    let marker = numeric_cartouche_scale_marker(cps, index);
    if marker != 0 { if let Some(ch) = char::from_u32(marker) { out.push(ch); } }
}

fn legacy_numeric_cartouche(codepoints: &[u32], adapter_id: &str, scale: bool) -> Result<String, String> {
    if codepoints.len() < 2
        || codepoints.first() != Some(&CARTOUCHE_START)
        || codepoints.last() != Some(&CARTOUCHE_END)
    { return Err(format!("{adapter_id}: numeric render input is not a complete canonical cartouche")); }
    let mut out = String::from("[");
    for i in 1..codepoints.len()-1 {
        let cp = codepoints[i];
        out.push('_');
        if cp == COLON { out.push(':'); }
        else {
            let word = codepoint_to_word(cp).ok_or_else(|| format!("{adapter_id}: no legacy numeric encoding for U+{cp:04X}"))?;
            out.push_str(word);
        }
        append_scale_marker(&mut out, codepoints, i, scale);
    }
    out.push(']');
    Ok(out)
}

fn direct_numeric_cartouche(codepoints: &[u32], scale: bool) -> Result<String, String> {
    let mut out = String::new();
    for (i, cp) in codepoints.iter().copied().enumerate() {
        let ch = char::from_u32(cp).ok_or_else(|| format!("invalid Unicode scalar value U+{cp:04X}"))?;
        out.push(ch);
        if i > 0 && i + 1 < codepoints.len() { append_scale_marker(&mut out, codepoints, i, scale); }
    }
    Ok(out)
}

fn nasin_pu_numeric_cartouche(codepoints: &[u32], scale: bool) -> Result<String, String> {
    let ni = cp_for_word("ni").unwrap_or(0xF1941);
    let sewi = cp_for_word("sewi").unwrap_or(0xF195A);
    let mut out=String::new();
    for (i, cp0) in codepoints.iter().copied().enumerate() {
        let cp=match cp0 { 0xF1989|0xF198A|0xF198B=>ni, 0xF198C=>sewi, COLON=>':' as u32, MIDDLE_DOT=>'.' as u32, _=>cp0 };
        out.push(char::from_u32(cp).ok_or_else(||format!("invalid Unicode scalar value U+{cp:04X}"))?);
        if i>0 && i+1<codepoints.len(){append_scale_marker(&mut out,codepoints,i,scale);}
    }
    Ok(out)
}

fn lipamanka_needs_translation(codepoints:&[u32], settings:&BTreeMap<String,Value>)->bool{
    let deterministic=setting_bool(settings,"deterministicAlternates",true);
    let jaki=cp_for_word("jaki");let ko=cp_for_word("ko");
    codepoints.iter().copied().any(|cp| {
        matches!(cp,COLON|MIDDLE_DOT|TALLY|0xF1989|0xF198A|0xF198B|0xF198C|OPEN_QUOTE|CLOSE_QUOTE|0x3000)
            || cp==0xF19A5 || (cp>0xF19A3 && cp!=0xF19A4 && cp!=0xF19A6)
            || (deterministic && (Some(cp)==jaki || Some(cp)==ko))
    })
}

fn lipamanka_numeric_cartouche(codepoints:&[u32],settings:&BTreeMap<String,Value>,scale:bool)->Result<String,String>{
    if codepoints.len()<2 || codepoints.first()!=Some(&CARTOUCHE_START) || codepoints.last()!=Some(&CARTOUCHE_END) || !lipamanka_needs_translation(codepoints,settings){return direct_numeric_cartouche(codepoints,scale);}
    let mut out=String::from("[");
    for i in 1..codepoints.len()-1 {
        if i>1{out.push(' ');}let cp=codepoints[i];
        match cp {
            COLON=>out.push(':'), MIDDLE_DOT=>out.push('.'),
            0xF1989|0xF198A|0xF198B=>out.push_str("ni"), 0xF198C=>out.push_str("sewi"),
            _=>out.push_str(codepoint_to_word(cp).unwrap_or("�")),
        }
        append_scale_marker(&mut out,codepoints,i,scale);
    }
    out.push(']');Ok(out)
}

pub fn adapt_numeric_cartouche_with_settings(
    codepoints: &[u32],
    render_adapter_id: &str,
    render_adapter_settings: &BTreeMap<String, Value>,
    font_settings: &BTreeMap<String, Value>,
) -> Result<AdaptedRun, String> {
    let adapter_id = if render_adapter_id.trim().is_empty() { "identity" } else { render_adapter_id.trim() };
    let scale=vulgar_scaling_enabled(font_settings);
    let (text,legacy_ascii)=if is_legacy_adapter(adapter_id){(legacy_numeric_cartouche(codepoints,adapter_id,scale)?,true)}
        else if adapter_id=="nasin-sitelen-pu-mono-v1"{(nasin_pu_numeric_cartouche(codepoints,scale)?,false)}
        else if adapter_id=="linja-lipamanka-v1"{(lipamanka_numeric_cartouche(codepoints,render_adapter_settings,scale)?,false)}
        else{(direct_numeric_cartouche(codepoints,scale)?,false)};
    Ok(AdaptedRun{text,adapter_id:adapter_id.to_string(),canonical_codepoints:codepoints.to_vec(),legacy_ascii})
}

pub fn adapt_numeric_cartouche(codepoints:&[u32],render_adapter_id:&str)->Result<AdaptedRun,String>{
    adapt_numeric_cartouche_with_settings(codepoints,render_adapter_id,&BTreeMap::new(),&BTreeMap::new())
}

