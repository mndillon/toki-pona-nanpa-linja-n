use std::collections::BTreeMap;
use std::sync::{Mutex, OnceLock};

use fontdue::{Font, FontSettings};
use harfrust::{Direction, Feature, FontRef, ShapeOptions, ShaperData, UnicodeBuffer};
use image::codecs::png::PngEncoder;
use image::{ColorType, GenericImageView, ImageEncoder};
use ttf_parser::{Face as TtfFace, GlyphId, OutlineBuilder};

use crate::api::codepoint_to_word;
use crate::facade::{NanpaLinjaN, RenderError};
use crate::font_adapters::{adapt_numeric_cartouche_with_settings, render_codepoints_without_scale_markers};
use crate::full_adapter::*;
use crate::full_document::{decode_data_image, parse_full_document, parse_raw_unicode_sequence};
use crate::full_font_registry::{bundled_full_font_bytes, setting_string, FullFontInfo, FullFontRegistry};
use crate::full_types::*;
use crate::parser::parse_number;
use crate::protocol::{CARTOUCHE_END, CARTOUCHE_START};

static ADAPTERS: OnceLock<Mutex<BTreeMap<String, RenderAdapter>>> = OnceLock::new();
fn adapters() -> &'static Mutex<BTreeMap<String, RenderAdapter>> { ADAPTERS.get_or_init(|| Mutex::new(BTreeMap::new())) }

#[derive(Clone)]
struct GlyphBitmap { left:f64, top:f64, width:usize, height:usize, bitmap:Vec<u8> }
#[derive(Clone)]
struct ShapedText { glyphs:Vec<GlyphBitmap>, min_x:f64, min_y:f64, max_x:f64, max_y:f64, width:f64, height:f64, baseline:f64, origin_x:f64, origin_y:f64, carets:Vec<(usize,f64)> }
#[derive(Clone,Default)]
struct FullGraphic { text:String, font_filename:String, features:Vec<String>, width:f64, height:f64, baseline:f64, origin_x:f64, origin_y:f64, tally_groups:Vec<TallyGroup>, image_bytes:Vec<u8>, image_href:String, unknown_decoration:bool, synthetic_corner_codepoint:Option<u32>, embedded_corners:Vec<(u32,f64)> }
#[derive(Clone)]
struct LogicalRun { run:FullRenderRun, graphic:FullGraphic }
#[derive(Clone)]
struct PreparedFull { plan:FullRenderPlan, placed:Vec<LogicalRun>, options:FullRenderOptions }

fn normalize_options(mut o:FullRenderOptions)->FullRenderOptions {
    let d=FullRenderOptions::default();
    if o.font.trim().is_empty(){o.font=d.font;}
    if o.font_size==0.0{o.font_size=d.font_size;}
    if o.font_size<8.0{o.font_size=8.0;}
    if o.padding_px<0{o.padding_px=0;}
    if o.parser.renderer_mode.is_empty(){o.parser=d.parser;}
    if o.layout.align.is_empty(){o.layout=d.layout;}
    if o.paint.fill_style.is_empty(){o.paint=d.paint;}
    if o.paint.unknown_text.color.is_empty(){o.paint.unknown_text=UnknownTextStyle::default();}
    if o.paint.halo_color.is_empty(){o.paint.halo_color="#FFFFFF".into();}
    if o.numeric_output.trim().is_empty(){o.numeric_output=d.numeric_output;}
    o
}

fn full_registry()->Result<FullFontRegistry,RenderError>{FullFontRegistry::bundled().map_err(RenderError::Manifest)}
fn literal_text_font_filename()->Result<String,RenderError>{let registry=full_registry()?;registry.support_font_filename("literalText").map(str::to_string).ok_or_else(||RenderError::Manifest("production font manifest is missing supportFonts.literalText".into()))}

impl NanpaLinjaN {
    pub fn list_full_fonts(&self)->Result<Vec<FullFontInfo>,RenderError>{Ok(full_registry()?.list().to_vec())}
    pub fn get_full_font_info(&self,font:&str)->Result<FullFontInfo,RenderError>{full_registry()?.get(font).cloned().ok_or_else(||RenderError::UnknownFont(format!("unknown production font: {font}")))}
    pub fn register_render_adapter(&self,id:&str,adapter:RenderAdapter){if let Ok(mut m)=adapters().lock(){m.insert(id.to_string(),adapter);}}
    pub fn get_render_adapter(&self,id:&str)->Option<RenderAdapter>{adapters().lock().ok().and_then(|m|m.get(id).copied())}
    pub fn remove_render_adapter(&self,id:&str)->Option<RenderAdapter>{adapters().lock().ok().and_then(|mut m|m.remove(id))}
    pub fn parse_input(&self,input:&str,options:&FullRenderOptions)->DocumentAst{let o=normalize_options(options.clone());let mut ast=parse_full_document(input,&o.parser);annotate_numeric_structures(&mut ast,&o.parser);ast}
    pub fn ast_to_text(&self,ast:&DocumentAst)->Result<String,RenderError>{crate::full_document::ast_to_text(ast).map_err(RenderError::InvalidInput)}
    pub fn ast_to_text_with_options(&self,ast:&DocumentAst,options:&FullRenderOptions)->Result<String,RenderError>{crate::full_document::ast_to_text_with_options(ast,options).map_err(RenderError::InvalidInput)}
    #[allow(non_snake_case)]
    pub fn astToText(&self,ast:&DocumentAst)->Result<String,RenderError>{self.ast_to_text(ast)}
    #[allow(non_snake_case)]
    pub fn astToTextWithOptions(&self,ast:&DocumentAst,options:&FullRenderOptions)->Result<String,RenderError>{self.ast_to_text_with_options(ast,options)}
}

fn patch_mixed_long(mut p:crate::model::ParseResult,source:&str,opts:&FullParserOptions)->crate::model::ParseResult{
    if opts.mixed_style!="long"||!source.contains('+')||!source.contains('/') {return p;}
    let open=word_to_cp("open").unwrap_or(0xF1947);let kin=word_to_cp("kin").unwrap_or(0xF1979);let nena=word_to_cp("nena").unwrap_or(0xF1940);let o=word_to_cp("o").unwrap_or(0xF1944);
    // The frozen parser emits the long mixed-fraction bridge as
    // `nena open kin open`.  The browser renderer canonicalizes that whole
    // four-codepoint bridge to `nena o nena o nena o`.  Replacing only
    // `open kin open` leaves an extra leading nena, which is observably wrong.
    fn conv(xs:&mut Vec<u32>,open:u32,kin:u32,nena:u32,o:u32){let mut i=0;while i+3<xs.len(){if xs[i]==nena&&xs[i+1]==open&&xs[i+2]==kin&&xs[i+3]==open{xs.splice(i..i+4,[nena,o,nena,o,nena,o]);break;}i+=1;}}
    conv(&mut p.inner_codepoints,open,kin,nena,o);conv(&mut p.ucsur_codepoints,open,kin,nena,o);conv(&mut p.codepoints,open,kin,nena,o);if let Some(ref mut a)=p.abbreviated_ucsur_codepoints{conv(a,open,kin,nena,o);}p
}
fn numeric_full_parse(source:&str,p:&FullParserOptions)->Option<crate::model::ParseResult>{
    let mut r=parse_number(source,&p.numeric_options())?;
    r=crate::v11_numeric::normalize_v11_yearless_date_result(r);
    r=patch_mixed_long(r,source,p);
    // The browser renderer's strict (non-relaxed) nanpa-linja-n rendering uses
    // `e` as the inter-digit separator.  The frozen Core parser deliberately
    // preserves its own historical word sequence, so normalize only the
    // full-renderer semantic vectors here rather than changing Core.
    if !p.relaxed_nanpa_linjan_rendering {
        const ALA:u32=0xF1902;
        const UTA:u32=0xF1970;
        const E:u32=0xF1909;
        fn strict_separators(xs:&mut Vec<u32>){for cp in xs.iter_mut(){if *cp==ALA||*cp==UTA{*cp=E;}}}
        strict_separators(&mut r.inner_codepoints);
        strict_separators(&mut r.ucsur_codepoints);
        strict_separators(&mut r.codepoints);
        if let Some(ref mut xs)=r.abbreviated_ucsur_codepoints{strict_separators(xs);}
    }
    Some(r)
}


fn direct_numeric_parse_result(source:&str,inner:Vec<u32>,p:&FullParserOptions)->crate::model::ParseResult{
    let words:Vec<String>=inner.iter().filter_map(|cp|codepoint_to_word(*cp).map(str::to_string)).collect();
    crate::model::ParseResult{
        input:source.into(),caps:None,proper_name:String::new(),unique_code:String::new(),
        ucsur_codepoints:inner.clone(),hex_codepoints:String::new(),hex_with_cartouche:String::new(),
        tp_words:words.clone(),words,display_value:source.into(),is_time:false,is_date:false,is_time_like:false,
        inner_codepoints:inner.clone(),codepoints:std::iter::once(CARTOUCHE_START).chain(inner).chain(std::iter::once(CARTOUCHE_END)).collect(),
        numeric_mode:p.numeric_mode.clone(),semantic_kind:None,semantic_start_glyph:None,kind:None,number_base:Some(10),
        is_hex:false,is_binary:false,hex_digits:None,binary_digits:None,hex_parts:None,binary_parts:None,
        abbreviated_ucsur_codepoints:None,abbreviated_words:None,nasin_nanpa_pona_words:None,
    }
}

fn full_phrase_parse(source:&str,p:&FullParserOptions,abbreviated_only:bool)->Option<crate::model::ParseResult>{
    let t=source.trim();
    if t.is_empty() || !t.chars().all(|c|c.is_ascii_lowercase()||c.is_ascii_whitespace()) {return None;}
    let words:Vec<&str>=t.split_whitespace().collect();
    if words.len()<3||words.first()!=Some(&"nanpa")||words.last()!=Some(&"nanpa"){return None;}
    const DIGITS:[&str;10]=["ijo","wan","tu","seli","awen","luka","utala","mun","pipi","jo"];
    const SCAFFOLD:[&str;8]=["nanpa","en","e","nena","open","ala","ike","uta"];
    if abbreviated_only{
        if !p.abbreviate_numeric_cartouches{return None;}
        let positive=words.len()>=4&&words[1]=="en";let mut has=false;
        for (i,w) in words.iter().enumerate(){
            if word_to_cp(w).is_none(){return None;}
            let final_nanpa=*w=="nanpa"&&i+1==words.len();let marker=positive&&i==1&&*w=="en";
            if i>0&&!final_nanpa&&!marker&&SCAFFOLD.contains(w){return None;}
            if DIGITS.contains(w){has=true;}
        }
        if !has{return None;}
        let inner=words.iter().map(|w|word_to_cp(w)).collect::<Option<Vec<_>>>()?;
        return Some(direct_numeric_parse_result(t,inner,p));
    }
    if !matches!(words[1],"e"|"en"|"esun"){return None;}
    if words[1]=="en" && !words[2..words.len()-1].iter().any(|w|SCAFFOLD.contains(w)){return None;}
    let mut has=false;
    for (i,w) in words.iter().enumerate(){if word_to_cp(w).is_none(){return None;}if DIGITS.contains(w){has=true;}if i>0&&DIGITS.contains(&words[i-1])&&DIGITS.contains(w){return None;}}
    if !has{return None;}
    let mut canon:Vec<String>=words.iter().map(|w|(*w).to_string()).collect();
    let positive=canon.len()>=5&&canon[0]=="nanpa"&&canon[1]=="e"&&canon[2]=="nena"&&canon[3]=="en";
    if p.nanpa_colon_rendering&&canon.len()>=3{canon[1]=":".into();}
    for i in 2..canon.len()-1{if canon[i]=="en"&&!(positive&&i==3){canon[i]="e".into();}}
    let inner=canon.iter().map(|w|word_to_cp(w)).collect::<Option<Vec<_>>>()?;
    Some(direct_numeric_parse_result(t,inner,p))
}

fn ascii_word_spans(text:&str)->Vec<(usize,usize)> {let b=text.as_bytes();let mut out=Vec::new();let mut i=0;while i<b.len(){if b[i].is_ascii_alphabetic(){let st=i;i+=1;while i<b.len()&&b[i].is_ascii_alphabetic(){i+=1;}out.push((st,i));}else{i+=1;}}out}
fn proper_numeric_prefix(text:&str,p:&FullParserOptions)->Option<(usize,usize,crate::model::ParseResult)>{
    let spans=ascii_word_spans(text);if spans.is_empty(){return None;}
    for i in 0..spans.len(){let (st,en)=spans[i];let first=&text[st..en];if !first.as_bytes().first().is_some_and(u8::is_ascii_uppercase){continue;}let low=first.to_ascii_lowercase();let typed=p.nanpa_colon_parsing||p.nanpa_colon_rendering;let plausible=low.starts_with("ne")||(p.enable_hex_parsing&&low.starts_with("nasa"))||((p.enable_binary_parsing||p.enable_binary_rendering)&&low.starts_with("noka"))||(typed&&(first=="Nanpa"||first.starts_with("Nanpa")||first=="Tenpo"||first=="Suno"||first=="Toki"));if !plausible{continue;}
        let mut best:Option<(usize,crate::model::ParseResult)>=None;
        for j in i..spans.len().min(i+31){if j>i{let prev=spans[j-1].1;let (ws,we)=spans[j];if !text[prev..ws].chars().all(|c|c==' '||c=='\t')||!text[ws..we].as_bytes().first().is_some_and(u8::is_ascii_uppercase){break;}}let end=spans[j].1;if let Some(r)=numeric_full_parse(&text[st..end],p){best=Some((end,r));}}
        if let Some((best_end,r))=best{if first=="Toki"&&i+1<spans.len()&&best_end<text.len(){let bi=spans.iter().position(|x|x.1==best_end).unwrap_or(i);if bi+1<spans.len(){let next=spans[bi+1];if text[best_end..next.0].chars().all(|c|c==' '||c=='\t')&&text[next.0..next.1].as_bytes().first().is_some_and(u8::is_ascii_uppercase){continue;}}}return Some((st,best_end,r));}
    }
    None
}

fn numeric_structure_from_result(source:&str,index:usize,end:usize,parsed:&crate::model::ParseResult,whole_segment:bool)->NumericStructure{
    let kind=parsed.kind.as_ref().map(|kind|kind.as_str().to_string())
        .or_else(||parsed.semantic_kind.map(|kind|kind.as_str().to_string()))
        .unwrap_or_else(||"number".to_string());
    NumericStructure{
        kind,
        source_text:source.to_string(),
        index,
        end,
        semantic_kind:parsed.semantic_kind.map(|kind|kind.as_str().to_string()).unwrap_or_default(),
        semantic_start_glyph:parsed.semantic_start_glyph.map(|glyph|glyph.as_str().to_string()).unwrap_or_default(),
        whole_segment,
    }
}

fn scan_text_numeric_structures(text:&str,p:&FullParserOptions)->Vec<NumericStructure>{
    let mut hits:Vec<NumericStructure>=Vec::new();

    // Proper-name numeric syntax may intentionally contain horizontal spaces.
    let mut proper_cursor=0usize;
    while proper_cursor<text.len(){
        let rest=&text[proper_cursor..];
        let Some((start,end,parsed))=proper_numeric_prefix(rest,p) else{break;};
        let abs_start=proper_cursor+start;let abs_end=proper_cursor+end;
        hits.push(numeric_structure_from_result(&text[abs_start..abs_end],abs_start,abs_end,&parsed,false));
        proper_cursor=abs_end.max(proper_cursor+1);
    }

    // Digit-based numeric syntax is bounded by whitespace in the current
    // JavaScript baseline. Test every complete non-whitespace token (and a
    // punctuation-trimmed sentence token) through the authoritative parser.
    let bytes=text.as_bytes();let mut at=0usize;
    while at<text.len(){
        while at<text.len()&&bytes[at].is_ascii_whitespace(){at+=1;}
        if at>=text.len(){break;}
        let start=at;while at<text.len()&&!bytes[at].is_ascii_whitespace(){at+=1;}let mut end=at;
        while end>start&&matches!(text.as_bytes()[end-1],b')'|b';'|b'!'|b'?'|b'}'){end-=1;}
        if end>start{
            let raw=&text[start..end];
            if let Some(parsed)=numeric_full_parse(raw,p){
                hits.push(numeric_structure_from_result(raw,start,end,&parsed,false));
            }else if raw.ends_with('.')&&raw.len()>1{
                let candidate=&raw[..raw.len()-1];
                if let Some(parsed)=numeric_full_parse(candidate,p){let ce=end-1;hits.push(numeric_structure_from_result(candidate,start,ce,&parsed,false));}
            }
        }
    }

    hits.sort_by_key(|item|(item.index,item.end));
    let mut out=Vec::new();let mut occupied_end=0usize;
    for hit in hits{
        if hit.index<occupied_end{continue;}
        occupied_end=hit.end;out.push(hit);
    }
    out
}

fn annotate_numeric_structures(ast:&mut DocumentAst,p:&FullParserOptions){
    for line in &mut ast.lines{
        for seg in &mut line.children{
            let structures=match seg.kind.as_str(){
                "text"=>scan_text_numeric_structures(&seg.value,p),
                "bracket"=>{
                    let source=format!("[{}]",seg.value);
                    numeric_full_parse(&source,p).map(|parsed|vec![numeric_structure_from_result(&source,0,source.len(),&parsed,true)]).unwrap_or_default()
                }
                _=>Vec::new(),
            };
            if !structures.is_empty(){seg.numeric_structures=structures;}
        }
    }
}

fn legacy_long_pi_syntax(source:&str)->bool{
    // Outside sitelen-pona-ascii-extended, a single `+` remains the ordinary
    // nesting/compound joiner (`pi+telo`).  Only the multi-marker legacy
    // long-pi spellings are excluded in Core/SSK modes.
    let low=source.to_ascii_lowercase();
    low.starts_with("pi+__") || low.starts_with("pi++") || low.starts_with("pi--")
}

fn normalize_final_numeric_codepoints(full:&mut [u32],o:&FullRenderOptions){
    // The frozen Rust extended parser can emit `nena o nena en` for the
    // decimal marker of an explicit-positive uniform number.  The canonical
    // JavaScript renderer requires `nena o nena e`.  Detect this from the
    // semantic vector itself so the correction cannot depend on document
    // tokenisation or source-text plumbing.
    let traditional=o.parser.numeric_mode=="traditional"||o.parser.mode=="traditional";
    if traditional || full.len()<4 {return;}
    const NENA:u32=0xF1940;
    const O:u32=0xF1944;
    const E:u32=0xF1909;
    const EN:u32=0xF190A;

    let sign_pos=full.windows(2).position(|w|w[0]==NENA&&w[1]==EN);
    let decimal_pos=full.windows(4).position(|w|w[0]==NENA&&w[1]==O&&w[2]==NENA&&w[3]==EN);
    if let (Some(sign),Some(decimal))=(sign_pos,decimal_pos) {
        if sign<decimal {full[decimal+3]=E;}
    }
}

#[cfg(test)]
mod explicit_positive_normalization_tests {
    use super::*;

    #[test]
    fn exact_failing_vector_is_normalized_to_javascript_reference() {
        let mut actual=vec![
            989501,989597,989504,989450,989555,989442,989550,989552,989527,
            989449,989504,989508,989504,989450,989504,989448,989485,989552,989501,
        ];
        normalize_final_numeric_codepoints(&mut actual,&FullRenderOptions::default());
        assert_eq!(actual,vec![
            989501,989597,989504,989450,989555,989442,989550,989552,989527,
            989449,989504,989508,989504,989449,989504,989448,989485,989552,989501,
        ]);
    }
}

#[cfg(test)]
mod abbreviation_routing_tests {
    use super::*;

    #[test]
    fn exact_full_decimal_vector_abbreviates_to_javascript_reference() {
        let full=vec![
            CARTOUCHE_START,
            989501,989597,989555,989442,989550,989552,989527,989449,989504,
            989508,989504,989449,989504,989448,989485,989552,989501,
            CARTOUCHE_END,
        ];
        let got=abbreviate_full_numeric_cartouche(&full,false);
        assert_eq!(got,vec![
            CARTOUCHE_START,
            989501,989597,989555,989550,989527,989508,989448,989485,989501,
            CARTOUCHE_END,
        ]);
    }
}

fn features(tags:&[String])->Result<Vec<Feature>,RenderError>{tags.iter().map(|t|Feature::from_str(t).map_err(|e|RenderError::Shaping(format!("invalid feature {t}: {e}")))).collect()}
use std::str::FromStr;
fn shape_text(text:&str,font_bytes:&'static [u8],font_px:f64,feature_tags:&[String],pad:f64,bottom_extra:f64)->Result<ShapedText,RenderError>{
    let font_ref=FontRef::from_index(font_bytes,0).map_err(|e|RenderError::Font(format!("font parse: {e:?}")))?;
    let raster_font=Font::from_bytes(font_bytes,FontSettings::default()).map_err(|e|RenderError::Font(format!("fontdue: {e}")))?;
    let upem=raster_font.units_per_em();if !upem.is_finite()||upem<=0.0{return Err(RenderError::Font("invalid units-per-em".into()));}let scale=font_px as f32/upem;
    let mut buffer=UnicodeBuffer::new();buffer.push_str(text);buffer.set_direction(Direction::LeftToRight);let fs=features(feature_tags)?;let sd=ShaperData::new(&font_ref);let sh=sd.shaper(&font_ref).build();let gb=sh.shape(buffer,ShapeOptions::new().features(&fs));let infos=gb.glyph_infos();let pos=gb.glyph_positions();if infos.is_empty()||infos.len()!=pos.len(){return Err(RenderError::Shaping("blank shaping".into()));}
    let mut pen_x=0f64;let mut pen_y=0f64;let mut min_x=f64::INFINITY;let mut min_y=f64::INFINITY;let mut max_x=f64::NEG_INFINITY;let mut max_y=f64::NEG_INFINITY;let mut glyphs=Vec::new();let mut carets=vec![(0usize,0.0)];
    for (info,p) in infos.iter().zip(pos.iter()){let cluster=info.cluster as usize;if carets.last().map(|x|x.0)!=Some(cluster){carets.push((cluster,pen_x));}if info.glyph_id>u16::MAX as u32{return Err(RenderError::Shaping("glyph id overflow".into()));}let (m,bm)=raster_font.rasterize_indexed(info.glyph_id as u16,font_px as f32);let ox=pen_x+p.x_offset as f64*scale as f64;let oy=pen_y+p.y_offset as f64*scale as f64;let left=ox+m.xmin as f64;let top=-(oy+m.ymin as f64+m.height as f64);let right=left+m.width as f64;let bottom=top+m.height as f64;if m.width>0&&m.height>0{min_x=min_x.min(left);min_y=min_y.min(top);max_x=max_x.max(right);max_y=max_y.max(bottom);glyphs.push(GlyphBitmap{left,top,width:m.width,height:m.height,bitmap:bm});}pen_x+=p.x_advance as f64*scale as f64;pen_y+=p.y_advance as f64*scale as f64;}
    carets.push((text.len(),pen_x));
    if !min_x.is_finite(){min_x=0.0;min_y=-font_px*0.8;max_x=pen_x.max(1.0);max_y=font_px*0.2;}
    let width=(max_x-min_x+2.0*pad).max(1.0);let height=(max_y-min_y+2.0*pad+bottom_extra).max(1.0);let origin_x=pad-min_x;let origin_y=pad-min_y;let baseline=origin_y;
    Ok(ShapedText{glyphs,min_x,min_y,max_x,max_y,width,height,baseline,origin_x,origin_y,carets})
}
fn caret_x(sh:&ShapedText,byte_index:usize)->f64{let mut x=0.0;for &(b,cx) in &sh.carets{if b>byte_index{break;}x=cx;}x}
fn byte_index_for_rune_index(s:&str,index:usize)->usize{if index==0{return 0;}s.char_indices().nth(index).map(|x|x.0).unwrap_or(s.len())}


#[derive(Debug,Clone,Copy)]
struct VectorGlyphPos{glyph_id:u16,x:f64,y:f64}

fn shape_vector_positions(text:&str,font_bytes:&'static [u8],font_px:f64,feature_tags:&[String])->Result<(Vec<VectorGlyphPos>,f64),RenderError>{
    let font_ref=FontRef::from_index(font_bytes,0).map_err(|e|RenderError::Font(format!("font parse: {e:?}")))?;
    let face=TtfFace::parse(font_bytes,0).map_err(|e|RenderError::Font(format!("ttf-parser: {e:?}")))?;
    let upem=face.units_per_em() as f64;if upem<=0.0{return Err(RenderError::Font("invalid units-per-em".into()));}
    let scale=font_px/upem;
    let mut buffer=UnicodeBuffer::new();buffer.push_str(text);buffer.set_direction(Direction::LeftToRight);
    let fs=features(feature_tags)?;let sd=ShaperData::new(&font_ref);let sh=sd.shaper(&font_ref).build();let gb=sh.shape(buffer,ShapeOptions::new().features(&fs));
    let infos=gb.glyph_infos();let pos=gb.glyph_positions();if infos.len()!=pos.len(){return Err(RenderError::Shaping("glyph position count mismatch".into()));}
    let mut pen_x=0.0f64;let mut pen_y=0.0f64;let mut out=Vec::with_capacity(infos.len());
    for (info,p) in infos.iter().zip(pos.iter()){
        if info.glyph_id>u16::MAX as u32{return Err(RenderError::Shaping("glyph id overflow".into()));}
        out.push(VectorGlyphPos{glyph_id:info.glyph_id as u16,x:pen_x+p.x_offset as f64*scale,y:pen_y+p.y_offset as f64*scale});
        pen_x+=p.x_advance as f64*scale;pen_y+=p.y_advance as f64*scale;
    }
    Ok((out,scale))
}

#[derive(Default)]
struct SvgOutline{d:String,scale:f64,base_x:f64,base_y:f64,current:(f64,f64)}
impl SvgOutline{fn tx(&self,x:f32)->f64{self.base_x+x as f64*self.scale}fn ty(&self,y:f32)->f64{self.base_y-y as f64*self.scale}}
impl OutlineBuilder for SvgOutline{
    fn move_to(&mut self,x:f32,y:f32){let p=(self.tx(x),self.ty(y));self.d.push_str(&format!("M{:.3} {:.3}",p.0,p.1));self.current=p;}
    fn line_to(&mut self,x:f32,y:f32){let p=(self.tx(x),self.ty(y));self.d.push_str(&format!("L{:.3} {:.3}",p.0,p.1));self.current=p;}
    fn quad_to(&mut self,x1:f32,y1:f32,x:f32,y:f32){let p0=self.current;let q=(self.tx(x1),self.ty(y1));let p=(self.tx(x),self.ty(y));let c1=(p0.0+2.0*(q.0-p0.0)/3.0,p0.1+2.0*(q.1-p0.1)/3.0);let c2=(p.0+2.0*(q.0-p.0)/3.0,p.1+2.0*(q.1-p.1)/3.0);self.d.push_str(&format!("C{:.3} {:.3} {:.3} {:.3} {:.3} {:.3}",c1.0,c1.1,c2.0,c2.1,p.0,p.1));self.current=p;}
    fn curve_to(&mut self,x1:f32,y1:f32,x2:f32,y2:f32,x:f32,y:f32){let a=(self.tx(x1),self.ty(y1));let b=(self.tx(x2),self.ty(y2));let p=(self.tx(x),self.ty(y));self.d.push_str(&format!("C{:.3} {:.3} {:.3} {:.3} {:.3} {:.3}",a.0,a.1,b.0,b.1,p.0,p.1));self.current=p;}
    fn close(&mut self){self.d.push('Z');}
}

fn svg_text_paths(text:&str,font_bytes:&'static [u8],font_px:f64,feature_tags:&[String],base_x:f64,baseline_y:f64)->Result<String,RenderError>{
    let face=TtfFace::parse(font_bytes,0).map_err(|e|RenderError::Font(format!("ttf-parser: {e:?}")))?;
    let (glyphs,scale)=shape_vector_positions(text,font_bytes,font_px,feature_tags)?;let mut d=String::new();
    for gp in glyphs{let mut b=SvgOutline{scale,base_x:base_x+gp.x,base_y:baseline_y-gp.y,..SvgOutline::default()};let _=face.outline_glyph(GlyphId(gp.glyph_id),&mut b);d.push_str(&b.d);}
    Ok(d)
}

#[derive(Default)]
struct PdfOutline{path:String,scale:f64,base_x:f64,base_y:f64,current:(f64,f64)}
impl PdfOutline{fn tx(&self,x:f32)->f64{self.base_x+x as f64*self.scale}fn ty(&self,y:f32)->f64{self.base_y-y as f64*self.scale}}
impl OutlineBuilder for PdfOutline{
    fn move_to(&mut self,x:f32,y:f32){let p=(self.tx(x),self.ty(y));self.path.push_str(&format!("{:.3} {:.3} m\n",p.0,p.1));self.current=p;}
    fn line_to(&mut self,x:f32,y:f32){let p=(self.tx(x),self.ty(y));self.path.push_str(&format!("{:.3} {:.3} l\n",p.0,p.1));self.current=p;}
    fn quad_to(&mut self,x1:f32,y1:f32,x:f32,y:f32){let p0=self.current;let q=(self.tx(x1),self.ty(y1));let p=(self.tx(x),self.ty(y));let c1=(p0.0+2.0*(q.0-p0.0)/3.0,p0.1+2.0*(q.1-p0.1)/3.0);let c2=(p.0+2.0*(q.0-p.0)/3.0,p.1+2.0*(q.1-p.1)/3.0);self.path.push_str(&format!("{:.3} {:.3} {:.3} {:.3} {:.3} {:.3} c\n",c1.0,c1.1,c2.0,c2.1,p.0,p.1));self.current=p;}
    fn curve_to(&mut self,x1:f32,y1:f32,x2:f32,y2:f32,x:f32,y:f32){let a=(self.tx(x1),self.ty(y1));let b=(self.tx(x2),self.ty(y2));let p=(self.tx(x),self.ty(y));self.path.push_str(&format!("{:.3} {:.3} {:.3} {:.3} {:.3} {:.3} c\n",a.0,a.1,b.0,b.1,p.0,p.1));self.current=p;}
    fn close(&mut self){self.path.push_str("h\n");}
}

fn pdf_text_path(text:&str,font_bytes:&'static [u8],font_px:f64,feature_tags:&[String],base_x:f64,baseline_y:f64)->Result<String,RenderError>{
    let face=TtfFace::parse(font_bytes,0).map_err(|e|RenderError::Font(format!("ttf-parser: {e:?}")))?;
    let (glyphs,scale)=shape_vector_positions(text,font_bytes,font_px,feature_tags)?;let mut path=String::new();
    for gp in glyphs{let mut b=PdfOutline{scale,base_x:base_x+gp.x,base_y:baseline_y-gp.y,..PdfOutline::default()};let _=face.outline_glyph(GlyphId(gp.glyph_id),&mut b);path.push_str(&b.path);}
    Ok(path)
}

fn rgba_hex(s:&str,default:[u8;4])->[u8;4]{let x=s.trim();if !x.starts_with('#'){return default;}let h=&x[1..];let v=if h.len()==3{format!("{}{}{}{}{}{}",&h[0..1],&h[0..1],&h[1..2],&h[1..2],&h[2..3],&h[2..3])}else{h.to_string()};if v.len()!=6{return default;}let Ok(n)=u32::from_str_radix(&v,16)else{return default};[((n>>16)&255)as u8,((n>>8)&255)as u8,(n&255)as u8,255]}
fn runes(s:&str)->Vec<u32>{s.chars().map(|c|c as u32).collect()}

fn make_graphic(text:&str,font_filename:&str,size:f64,features:&[String],pad:f64,bottom_extra:f64)->Result<FullGraphic,RenderError>{let bytes=bundled_full_font_bytes(font_filename).ok_or_else(||RenderError::Font(format!("missing bundled font {font_filename}")))?;let sh=shape_text(text,bytes,size,features,pad,bottom_extra)?;Ok(FullGraphic{text:text.into(),font_filename:font_filename.into(),features:features.to_vec(),width:sh.width,height:sh.height,baseline:sh.baseline,origin_x:sh.origin_x,origin_y:sh.origin_y,..FullGraphic::default()})}

fn synthetic_corner_graphic(cp:u32,size:f64)->FullGraphic{
    let px=size.max(1.0);
    let width=(px*0.36).ceil().max(1.0);
    let height=(px*0.76).ceil().max(1.0);
    let lift=if cp==CLOSE_QUOTE_CODEPOINT{0.0}else{(px*0.18).max(4.0)};
    let y_top_from_baseline=-(height*0.82)-lift;
    let ascent=(-y_top_from_baseline).max(0.0);
    FullGraphic{width,height,baseline:ascent,synthetic_corner_codepoint:Some(cp),..FullGraphic::default()}
}
fn glyph_logical(source:&str,cps:&[u32],start:usize,end:usize,source_kind:&str,font:&FullFontInfo,o:&FullRenderOptions,quoted:bool,interpreted:bool)->Result<LogicalRun,RenderError>{
    let canonical=cps.to_vec();let raw_bypass=parse_raw_unicode_sequence(source.trim()).is_some();
    let custom_adapter=adapters().lock().ok().and_then(|m|m.get(&font.render_adapter_id).copied());
    let synthetic_profile=matches!(font.render_adapter_id.as_str(),"linja-pona-legacy-v1"|"linja-sike-legacy-v1")
        && setting_string(&font.render_adapter_settings,"cornerBracketMode","").eq_ignore_ascii_case("synthetic");
    let synthetic=!raw_bypass&&custom_adapter.is_none()&&synthetic_profile&&canonical.len()==1&&matches!(canonical[0],OPEN_QUOTE_CODEPOINT|CLOSE_QUOTE_CODEPOINT);
    let mut render=if raw_bypass||synthetic{canonical.clone()}else{adapt_full_word_run(font,&canonical)};
    if !raw_bypass&&!synthetic{if let Some(a)=custom_adapter{render=a(&canonical,&font.key,o.font_size);}}
    let text:String=render.iter().map(|cp|char::from_u32(*cp).unwrap_or('\u{FFFD}')).collect();
    let g=if synthetic{synthetic_corner_graphic(canonical[0],o.font_size)}else{make_graphic(&text,&font.base_filename,o.font_size,&[],0.0,0.0)?};
    let mut r=FullRenderRun{kind:if raw_bypass||canonical.len()>1||render.len()>1{"run".into()}else{"glyph".into()},render_mode:if synthetic{"synthetic-corner-bracket".into()}else{"text".into()},font_role:"word".into(),canonical_codepoints:canonical,render_codepoints:render,render_text:text,render_adapter_id:if raw_bypass{"identity".into()}else{font.render_adapter_id.clone()},requested_render_adapter_id:if font.render_adapter_id.is_empty(){"identity".into()}else{font.render_adapter_id.clone()},source_text:source.into(),source_kind:source_kind.into(),source_start:start,source_end:end,quoted,interpreted_quote:interpreted,..FullRenderRun::default()};if r.render_adapter_id.is_empty(){r.render_adapter_id="identity".into();}Ok(LogicalRun{run:r,graphic:g})
}
fn literal_rendered_logical(rendered:&str,source:&str,start:usize,end:usize,source_kind:&str,_font:&FullFontInfo,o:&FullRenderOptions,quoted:bool,interpreted:bool,unknown:bool)->Result<LogicalRun,RenderError>{
    let mut g=if !rendered.is_empty()&&rendered.chars().all(char::is_whitespace){FullGraphic{width:if rendered.chars().all(|c|c=='\u{3000}'){o.font_size}else{o.font_size*0.5},height:0.0,baseline:0.0,..FullGraphic::default()}}else{let literal_font=literal_text_font_filename()?;make_graphic(if rendered.is_empty(){" "}else{rendered},&literal_font,o.font_size,&[],0.0,0.0)?};
    if unknown{let pad=o.paint.unknown_text.padding_px.max(0.0);g.width+=2.0*pad;g.height+=2.0*pad;g.baseline+=pad;g.origin_x+=pad;g.origin_y+=pad;g.unknown_decoration=true;}
    let role=if unknown&&(interpreted||source_kind=="interpretedQuote"){"unknown"}else{"literal"};
    let r=FullRenderRun{kind:"text".into(),render_mode:"raster".into(),font_role:role.into(),render_text:rendered.into(),render_adapter_id:"identity".into(),requested_render_adapter_id:"identity".into(),source_text:source.into(),source_kind:source_kind.into(),source_start:start,source_end:end,quoted,interpreted_quote:interpreted,unrecognized:unknown,..FullRenderRun::default()};Ok(LogicalRun{run:r,graphic:g})
}
fn literal_logical(source:&str,start:usize,end:usize,source_kind:&str,font:&FullFontInfo,o:&FullRenderOptions,quoted:bool,interpreted:bool,unknown:bool)->Result<LogicalRun,RenderError>{literal_rendered_logical(source,source,start,end,source_kind,font,o,quoted,interpreted,unknown)}
fn ideographic_space_logical(source:&str,start:usize,end:usize,source_kind:&str,font:&FullFontInfo,o:&FullRenderOptions)->Result<LogicalRun,RenderError>{literal_rendered_logical("\u{3000}",source,start,end,source_kind,font,o,false,false,false)}
fn literal_cartouche_logical(source:&str,inner:&[u32],start:usize,end:usize,source_kind:&str,font:&FullFontInfo,o:&FullRenderOptions)->Result<LogicalRun,RenderError>{
    let full:Vec<u32>=std::iter::once(CARTOUCHE_START).chain(inner.iter().copied()).chain(std::iter::once(CARTOUCHE_END)).collect();let text:String=full.iter().filter_map(|cp|char::from_u32(*cp)).collect();let filename=if font.literal_cartouche_filename.trim().is_empty(){&font.base_filename}else{&font.literal_cartouche_filename};let g=make_graphic(&text,filename,o.font_size,&[],6.0,0.0)?;let r=FullRenderRun{kind:"cartouche".into(),render_mode:"raster".into(),font_role:"cartouche".into(),opener_codepoint:Some(CARTOUCHE_START),closer_codepoint:Some(CARTOUCHE_END),canonical_codepoints:inner.to_vec(),render_codepoints:full,render_text:text,render_adapter_id:"identity".into(),requested_render_adapter_id:"identity".into(),literal_cartouche:true,source_text:source.into(),source_kind:source_kind.into(),source_start:start,source_end:end,..FullRenderRun::default()};Ok(LogicalRun{run:r,graphic:g})
}

fn abbreviate_full_numeric_cartouche(full:&[u32],preserve_breaks:bool)->Vec<u32>{
    if full.len()<3||full[0]!=CARTOUCHE_START||*full.last().unwrap_or(&0)!=CARTOUCHE_END{return full.to_vec();}
    let chars=&full[1..full.len()-1];if chars.is_empty(){return full.to_vec();}
    const NANPA:u32=0xF193D;const NASA:u32=0xF193E;const NOKA:u32=0xF1943;const TENPO:u32=0xF196B;const SUNO:u32=0xF1964;const TOKI:u32=0xF196C;const COLON:u32=0xF199D;const NENA:u32=0xF1940;const E:u32=0xF1909;const EN:u32=0xF190A;const OPEN:u32=0xF1947;const ALA:u32=0xF1902;const IKE:u32=0xF190D;const UTA:u32=0xF1970;
    let numeric_heads=[NANPA,NASA,NOKA,TENPO,SUNO,TOKI];let is_head=|cp:u32|numeric_heads.contains(&cp);let is_drop=|cp:u32|matches!(cp,NANPA|EN|E|NENA|OPEN|ALA|IKE|UTA);
    let traditional_full_positive=chars.len()>=4&&is_head(chars[0])&&chars[1]==E&&chars[2]==NENA&&chars[3]==EN;
    let colon_full_positive=chars.len()>=4&&is_head(chars[0])&&chars[1]==COLON&&chars[2]==NENA&&chars[3]==EN;
    let full_positive=traditional_full_positive||colon_full_positive;
    let full_scaffolding_after_opening=chars.len()>3&&chars[2..chars.len()-1].iter().any(|cp|*cp==E||is_drop(*cp));
    let already_abbreviated_positive=!full_positive&&!full_scaffolding_after_opening&&chars.len()>=3&&is_head(chars[0])&&chars[1]==EN;
    let already_abbreviated_colon_positive=!full_positive&&!full_scaffolding_after_opening&&chars.len()>=4&&is_head(chars[0])&&chars[1]==COLON&&chars[2]==EN;
    let mut out_inner=Vec::with_capacity(chars.len());let mut kept_opening_head=false;let mut i=0usize;
    while i<chars.len(){let ch=chars[i];let is_final_nanpa=ch==NANPA&&i==chars.len()-1;if !kept_opening_head{out_inner.push(ch);if(i==0&&is_head(ch))||ch==NANPA{kept_opening_head=true;}i+=1;continue;}if is_final_nanpa{out_inner.push(ch);i+=1;continue;}if traditional_full_positive&&i==1{out_inner.push(EN);i=4;continue;}if colon_full_positive&&i==2{out_inner.push(EN);i=4;continue;}if already_abbreviated_positive&&i==1{out_inner.push(EN);i+=1;continue;}if already_abbreviated_colon_positive&&i==2{out_inner.push(EN);i+=1;continue;}if preserve_breaks&&ch==NENA&&i+3<chars.len()&&matches!(chars[i+1],E|EN)&&chars[i+2]==NENA&&matches!(chars[i+3],E|EN){out_inner.push(E);i+=4;continue;}if !is_drop(ch){out_inner.push(ch);}i+=1;}
    let mut out=Vec::with_capacity(out_inner.len()+2);out.push(CARTOUCHE_START);out.extend(out_inner);out.push(CARTOUCHE_END);out
}
fn numeric_full_codepoints(parsed:&crate::model::ParseResult,o:&FullRenderOptions)->Vec<u32>{
    let full=parsed.codepoints.clone();
    if !o.parser.abbreviate_numeric_cartouches{return full;}
    if let Some(words)=parsed.abbreviated_words.as_ref().filter(|xs|!xs.is_empty()){
        let normalized=crate::v11_numeric::normalize_v11_abbreviated_words(words.iter().map(String::as_str));
        let inner=normalized.iter().map(|w|word_to_cp(w)).collect::<Option<Vec<_>>>();
        if let Some(inner)=inner{
            let out:Vec<u32>=std::iter::once(CARTOUCHE_START).chain(inner).chain(std::iter::once(CARTOUCHE_END)).collect();
            if out!=full&&out.len()<=full.len(){return out;}
        }
    }
    if let Some(inner)=&parsed.abbreviated_ucsur_codepoints{let out:Vec<u32>=std::iter::once(CARTOUCHE_START).chain(inner.iter().copied()).chain(std::iter::once(CARTOUCHE_END)).collect();if out!=full&&out.len()<full.len(){return out;}}
    let out=abbreviate_full_numeric_cartouche(&full,o.parser.preserve_numeric_cartouche_breaks);if out!=full&&out.len()<full.len(){out}else{full}
}
fn apply_final_numeric_start_glyph(full:&mut [u32],parsed:&crate::model::ParseResult,o:&FullRenderOptions){
    // Keep hex/binary semantic openers (nasa/noka) intact.  For decimal
    // cartouches, numericCartoucheStartGlyph is a renderer-level override and
    // therefore must be reflected in the final semantic vector even if the
    // frozen parser path did not carry it through.
    if parsed.is_hex||parsed.is_binary{return;}
    let Some(name)=o.parser.numeric_cartouche_start_glyph.as_deref() else{return;};
    let Some(cp)=word_to_cp(&name.to_ascii_lowercase()) else{return;};
    if full.first()==Some(&CARTOUCHE_START){if full.len()>2{full[1]=cp;}}else if !full.is_empty(){full[0]=cp;}
}

fn numeric_logical(source:&str,parsed:&crate::model::ParseResult,start:usize,end:usize,source_kind:&str,font:&FullFontInfo,o:&FullRenderOptions)->Result<LogicalRun,RenderError>{
    let mut full=numeric_full_codepoints(parsed,o);
    normalize_final_numeric_codepoints(&mut full,o);
    apply_final_numeric_start_glyph(&mut full,parsed,o);

    // Final abbreviation guard.  Some frozen parser paths do not populate
    // abbreviated_ucsur_codepoints, and the full-renderer bridge must not
    // depend on which ParseResult representation happened to be returned.
    // Re-run the proven legacy abbreviation algorithm on the exact semantic
    // vector that is about to be stored in the render plan.
    if o.parser.abbreviate_numeric_cartouches {
        let candidate=if full.first()==Some(&CARTOUCHE_START)&&full.last()==Some(&CARTOUCHE_END){
            abbreviate_full_numeric_cartouche(&full,o.parser.preserve_numeric_cartouche_breaks)
        }else{
            let wrapped:Vec<u32>=std::iter::once(CARTOUCHE_START).chain(full.iter().copied()).chain(std::iter::once(CARTOUCHE_END)).collect();
            abbreviate_full_numeric_cartouche(&wrapped,o.parser.preserve_numeric_cartouche_breaks)
        };
        if candidate.len()<full.len() || (full.first()!=Some(&CARTOUCHE_START)&&candidate.len()<full.len()+2) {
            full=candidate;
        }
    }

    let adapted=adapt_numeric_cartouche_with_settings(&full,&font.render_adapter_id,&font.render_adapter_settings,&font.settings).map_err(RenderError::Adapter)?;let features=full_open_type_features_for(o.font_size);let g=make_graphic(&adapted.text,&font.companion_filename,o.font_size,&features,6.0,0.0)?;let inner=if full.len()>=2&&full.first()==Some(&CARTOUCHE_START)&&full.last()==Some(&CARTOUCHE_END){full[1..full.len()-1].to_vec()}else{full.clone()};let mut r=FullRenderRun{kind:"cartouche".into(),render_mode:"raster".into(),font_role:"number".into(),numeric_cartouche:true,hex_cartouche:parsed.is_hex,binary_cartouche:parsed.is_binary,numeric_base:parsed.number_base.unwrap_or(10),opener_codepoint:inner.first().copied(),closer_codepoint:inner.last().copied(),canonical_codepoints:inner,render_codepoints:render_codepoints_without_scale_markers(&adapted.text),render_text:adapted.text,render_adapter_id:font.render_adapter_id.clone(),requested_render_adapter_id:if font.render_adapter_id.is_empty(){"identity".into()}else{font.render_adapter_id.clone()},source_text:source.into(),source_kind:source_kind.into(),source_start:start,source_end:end,..FullRenderRun::default()};if r.render_adapter_id.is_empty(){r.render_adapter_id="identity".into();}Ok(LogicalRun{run:r,graphic:g})
}

fn cartouche_logical(source:&str,oc:&OrdinaryCartouche,start:usize,end:usize,source_kind:&str,font:&FullFontInfo,o:&FullRenderOptions)->Result<LogicalRun,RenderError>{
    let adapted=adapt_ordinary(font,&oc.inner,&oc.scale_markers);let extra=if oc.has_manual_tallies(){(o.font_size*0.34).ceil()}else{0.0};
    let synthetic_mode=setting_string(&font.render_adapter_settings,"cornerBracketMode","").eq_ignore_ascii_case("synthetic");
    let mut shape_value=adapted.text.clone();let mut corner_indices=Vec::<(u32,usize)>::new();
    if synthetic_mode{let mut out=String::new();for (ri,ch) in adapted.text.chars().enumerate(){let cp=ch as u32;if matches!(cp,OPEN_QUOTE_CODEPOINT|CLOSE_QUOTE_CODEPOINT){corner_indices.push((cp,ri));out.push(' ');}else{out.push(ch);}}shape_value=out;}
    let bytes=bundled_full_font_bytes(&font.base_filename).ok_or_else(||RenderError::Font(format!("missing {}",font.base_filename)))?;let sh=shape_text(&shape_value,bytes,o.font_size,&[],6.0,extra)?;
    let embedded_corners=corner_indices.into_iter().map(|(cp,ri)|{let bi=byte_index_for_rune_index(&shape_value,ri);(cp,sh.origin_x+caret_x(&sh,bi))}).collect::<Vec<_>>();
    let mut groups=Vec::new();if oc.has_manual_tallies(){let bottom=sh.height-extra-6.0;let lift=manual_tally_lift(font,&o.parser,o.font_size);let top=bottom-lift;let bot=top+o.font_size*0.10;let stroke=(o.font_size*0.045).max(1.5);let gap=o.font_size*0.075;for (i,&count0) in oc.manual_tallies.iter().enumerate(){let count=count0.min(8);if count==0{continue;}let span=adapted.canonical_spans[i+1];let lx=caret_x(&sh,byte_index_for_rune_index(&shape_value,span.0));let rx=caret_x(&sh,byte_index_for_rune_index(&shape_value,span.1));let left=sh.origin_x+lx;let right=sh.origin_x+rx;let center=(left+right)/2.0;let total=if count>1{count as f64*stroke+(count-1)as f64*gap}else{stroke};let first=center-total/2.0+stroke/2.0;let centers=(0..count).map(|k|first+k as f64*(stroke+gap)).collect();groups.push(TallyGroup{owner_index:i,count,owner_left_px:left,owner_right_px:right,center_x_px:center,top_y_px:top,bottom_y_px:bot,stroke_width_px:stroke,stroke_centers_px:centers});}}
    let manual=if oc.has_manual_tallies(){oc.manual_tallies.clone()}else{vec![]};let g=FullGraphic{text:shape_value,font_filename:font.base_filename.clone(),width:sh.width,height:sh.height,baseline:sh.baseline,origin_x:sh.origin_x,origin_y:sh.origin_y,tally_groups:groups.clone(),embedded_corners,..FullGraphic::default()};let r=FullRenderRun{kind:"cartouche".into(),render_mode:"raster".into(),font_role:"cartouche".into(),opener_codepoint:Some(CARTOUCHE_START),closer_codepoint:Some(CARTOUCHE_END),canonical_codepoints:oc.inner.clone(),render_codepoints:render_codepoints_without_scale_markers(&adapted.text),render_text:adapted.text,render_adapter_id:font.render_adapter_id.clone(),requested_render_adapter_id:if font.render_adapter_id.is_empty(){"identity".into()}else{font.render_adapter_id.clone()},source_text:source.into(),source_kind:source_kind.into(),source_start:start,source_end:end,manual_tallies:manual,..FullRenderRun::default()};Ok(LogicalRun{run:r,graphic:g})
}
fn parse_size(v:&str,base:f64)->Option<f64>{let mut s=v.trim().to_ascii_lowercase();if s.is_empty(){return None;}let mut mul=1.0;if s.ends_with("em"){mul=base;s.truncate(s.len()-2);}else if s.ends_with("px"){s.truncate(s.len()-2);}s.parse::<f64>().ok().map(|x|x*mul)}
fn image_logical(seg:&DocumentSegment,font:&FullFontInfo,o:&FullRenderOptions)->Result<LogicalRun,RenderError>{let d=seg.image.clone().unwrap_or(ImageDescriptor{v_align:"baseline".into(),transparent:true,..ImageDescriptor::default()});let raw=decode_data_image(&d.src).unwrap_or_default();let mut iw=None;let mut ih=None;if !raw.is_empty(){if let Ok(img)=image::load_from_memory(&raw){let (w,h)=img.dimensions();iw=Some(w as f64);ih=Some(h as f64);}}let mut w=parse_size(&d.width,o.font_size);let mut h=parse_size(&d.height,o.font_size);if w.is_none()&&h.is_none(){h=Some(o.font_size);}if w.is_none(){w=Some(match(iw,ih,h){(Some(a),Some(b),Some(hh))if b!=0.0=>hh*a/b,(_,_,Some(hh))=>hh,_=>o.font_size});}if h.is_none(){h=Some(match(iw,ih,w){(Some(a),Some(b),Some(ww))if a!=0.0=>ww*b/a,(_,_,Some(ww))=>ww,_=>o.font_size});}let w=w.unwrap_or(1.0).max(1.0);let h=h.unwrap_or(1.0).max(1.0);let baseline=if d.v_align.eq_ignore_ascii_case("center"){h*0.75}else{h};let r=FullRenderRun{kind:"cartouche".into(),render_mode:"raster".into(),font_role:"cartouche".into(),render_adapter_id:font.render_adapter_id.clone(),requested_render_adapter_id:if font.render_adapter_id.is_empty(){"identity".into()}else{font.render_adapter_id.clone()},source_kind:"image".into(),source_start:seg.source_start,source_end:seg.source_end,image_alt:d.alt.clone(),..FullRenderRun::default()};let g=FullGraphic{width:w,height:h,baseline,image_bytes:raw,image_href:d.src,..FullGraphic::default()};Ok(LogicalRun{run:r,graphic:g})}

fn is_integer(s:&str)->bool{let t=s.strip_prefix('+').unwrap_or(s);!t.is_empty()&&t.chars().all(|c|c.is_ascii_digit())}
fn has_digit(s:&str)->bool{s.chars().any(|c|c.is_ascii_digit())}
fn is_word_char(c:char)->bool{c.is_ascii_alphanumeric()||matches!(c,'<'|'>'|'^')}
fn is_protected_alias(s:&str)->bool{matches!(s.to_ascii_lowercase().as_str(),"ni01"|"ni02"|"ni03"|"ni04"|"sewi01"|"sewi02")}

fn glyph_expression_cps(source:&str)->Option<Vec<u32>>{
    if source.is_empty(){return None;}
    let mut cps=Vec::new();let mut cur=String::new();let mut saw=false;
    for ch in source.chars(){
        let joiner=match ch{'&'=>Some(0x200D),'-'=>Some(STACK_JOINER_CODEPOINT),'+'=>Some(NEST_JOINER_CODEPOINT),_=>None};
        if let Some(j)=joiner{
            if cur.is_empty(){return None;}let cp=word_to_cp(&sanitize_word(&cur))?;cps.push(cp);cur.clear();cps.push(j);saw=true;
        }else{cur.push(ch);}
    }
    if cur.is_empty(){return None;}cps.push(word_to_cp(&sanitize_word(&cur))?);
    if saw{Some(cps)}else{None}
}
fn glyph_words_cps(source:&str)->Option<Vec<u32>>{
    let mut out=Vec::new();for tok in source.split_whitespace(){if let Some(c)=glyph_expression_cps(tok){out.extend(c);}else{out.push(word_to_cp(&sanitize_word(tok))?);}}if out.is_empty(){None}else{Some(out)}
}
fn find_matching(s:&str,open:usize,open_ch:char,close_ch:char)->Option<usize>{
    let mut depth=0i32;for (rel,ch) in s[open..].char_indices(){if ch==open_ch{depth+=1;}else if ch==close_ch{depth-=1;if depth==0{return Some(open+rel);}}}None
}
fn parse_identifier_at(s:&str,start:usize)->Option<(String,usize)>{
    let mut end=start;for (rel,ch) in s[start..].char_indices(){if is_word_char(ch){end=start+rel+ch.len_utf8();}else{break;}}if end==start{None}else{Some((s[start..end].to_string(),end))}
}
fn long_expression_cps(source:&str,mode:&str)->Option<Vec<u32>>{
    let extended=mode=="sitelen-pona-ascii-extended"||mode=="sitelen-seli-kiwen";
    let core=mode=="standard-sitelen-pona-ascii-core";
    if source.starts_with('{')&&extended{
        let close=find_matching(source,0,'{','}')?;let left=glyph_words_cps(&source[1..close])?;let (head,mut at)=parse_identifier_at(source,close+1)?;let head_cp=word_to_cp(&sanitize_word(&head))?;let mut out=vec![0xF199A];out.extend(left);out.push(0xF199B);out.push(head_cp);
        if at<source.len()&&source[at..].starts_with('('){let e=find_matching(source,at,'(',')')?;if e+1!=source.len(){return None;}let right=glyph_words_cps(&source[at+1..e])?;out.push(0xF1997);out.extend(right);out.push(0xF1998);at=e+1;}
        if at==source.len(){return Some(out);}return None;
    }
    let (head,at)=parse_identifier_at(source,0)?;if at<source.len()&&source[at..].starts_with('(')&&(extended||(core&&head.eq_ignore_ascii_case("pi"))){let e=find_matching(source,at,'(',')')?;if e+1!=source.len(){return None;}let inner=glyph_words_cps(&source[at+1..e])?;let mut out=vec![word_to_cp(&sanitize_word(&head))?,0xF1997];out.extend(inner);out.push(0xF1998);return Some(out);}
    None
}
fn legacy_long_pi_cps(source:&str,mode:&str)->Option<Vec<u32>>{
    if mode!="sitelen-pona-ascii-extended"{return None;}
    let pi=word_to_cp("pi")?;let mut inner=Vec::new();
    if let Some(rest)=source.strip_prefix("pi+__"){
        let parts:Vec<&str>=rest.split("__").collect();if parts.is_empty()||parts.len()>3||parts.iter().any(|x|x.is_empty()){return None;}for p in parts{if let Some(c)=glyph_expression_cps(p){inner.extend(c);}else{inner.push(word_to_cp(&sanitize_word(p))?);}}
    }else{
        let (op,n)=if source.starts_with("pi+++"){('+',3)}else if source.starts_with("pi++"){('+',2)}else if source.starts_with("pi+"){('+',1)}else if source.starts_with("pi---"){('-',3)}else if source.starts_with("pi--"){('-',2)}else{return None;};
        let prefix_len=2+n;let rest=&source[prefix_len..];let parts:Vec<&str>=rest.split_whitespace().collect();if parts.len()!=n{return None;}let _=op;for p in parts{if let Some(c)=glyph_expression_cps(p){inner.extend(c);}else{inner.push(word_to_cp(&sanitize_word(p))?);}}
    }
    let mut out=vec![pi,0xF1997];out.extend(inner);out.push(0xF1998);Some(out)
}
fn core_pipe_cps(source:&str)->Option<Vec<(String,Vec<u32>)>>{
    if !source.contains('|'){return None;}let mut out=Vec::new();let mut first=true;for part in source.split('|'){if !first{out.push(("|".into(),vec![0x3000]));}first=false;if !part.is_empty(){out.push((part.into(),glyph_expression_cps(part).unwrap_or_else(||word_to_cp(&sanitize_word(part)).map(|x|vec![x]).unwrap_or_default())));}}Some(out)
}
fn suffix_split(source:&str)->Option<(&str,&str)>{
    if is_protected_alias(source){return None;}let mut split=source.len();for (i,c) in source.char_indices().rev(){if c.is_ascii_digit(){split=i;}else{break;}}if split==0||split==source.len(){return None;}let (a,b)=source.split_at(split);if !a.chars().all(is_word_char)||!b.chars().all(|c|c.is_ascii_digit())||word_to_cp(&sanitize_word(a)).is_none(){return None;}Some((a,b))
}

fn emit_core(source:&str,start:usize,end:usize,kind:&str,out:&mut Vec<LogicalRun>,font:&FullFontInfo,o:&FullRenderOptions)->Result<(),RenderError>{
    if source.eq_ignore_ascii_case("zz"){out.push(ideographic_space_logical(source,start,end,kind,font,o)?);return Ok(());}
    if all_runes_ucsur(source){out.push(glyph_logical(source,&runes(source),start,end,kind,font,o,false,false)?);return Ok(());}
    let mode=o.parser.effective_renderer_mode();
    if mode!="sitelen-pona-ascii-extended"&&legacy_long_pi_syntax(source){if o.parser.show_unknown_text{out.push(literal_logical(source,start,end,kind,font,o,false,kind=="interpretedQuote",true)?);}return Ok(());}
    if let Some(cps)=long_expression_cps(source,mode){out.push(glyph_logical(source,&cps,start,end,kind,font,o,false,false)?);return Ok(());}
    if let Some(cps)=legacy_long_pi_cps(source,mode){out.push(glyph_logical(source,&cps,start,end,kind,font,o,false,false)?);return Ok(());}
    if mode=="standard-sitelen-pona-ascii-core"{
        if let Some(parts)=core_pipe_cps(source){let mut off=start;for (txt,cps) in parts{let e=off+txt.len();if !cps.is_empty(){let mut l=glyph_logical(&txt,&cps,off,e,kind,font,o,false,false)?;if txt=="|"{l.run.kind="run".into();}out.push(l);}off=e;}return Ok(());}
    }
    if let Some((word,digits))=suffix_split(source){let split=start+word.len();if let Some(cp)=word_to_cp(&sanitize_word(word)){out.push(glyph_logical(word,&[cp],start,split,kind,font,o,false,false)?);}if let Some(parsed)=numeric_full_parse(digits,&o.parser){out.push(numeric_logical(digits,&parsed,split,end,kind,font,o)?);}return Ok(());}
    if let Some(parsed)=numeric_full_parse(source,&o.parser){if o.parser.nasin_nanpa_pona{if let Some(words)=parsed.nasin_nanpa_pona_words.as_ref().filter(|words|!words.is_empty()){for w in words{if let Some(cp)=word_to_cp(w){out.push(glyph_logical(source,&[cp],start,end,kind,font,o,false,false)?);}}return Ok(());}}out.push(numeric_logical(source,&parsed,start,end,kind,font,o)?);return Ok(());}
    if let Some(cps)=glyph_expression_cps(source){out.push(glyph_logical(source,&cps,start,end,kind,font,o,false,false)?);return Ok(());}
    if o.parser.auto_cartouche_standalone_proper_names&&source.chars().next().is_some_and(|c|c.is_uppercase()){if let Some(cps)=proper_name_codepoints(source){let oc=OrdinaryCartouche{manual_tallies:vec![0;cps.len()],inner:cps,tally_mode:"ucsur".into(),scale_markers:vec![]};out.push(cartouche_logical(source,&oc,start,end,kind,font,o)?);return Ok(());}}
    if let Some(cp)=word_to_cp(&sanitize_word(source)){out.push(glyph_logical(source,&[cp],start,end,kind,font,o,false,false)?);return Ok(());}
    if o.parser.show_unknown_text{let mut lit=source.to_string();let mut ls=start;let mut le=end;if mode=="standard-sitelen-pona-ascii-core"&&lit.len()>=2&&lit.starts_with('\'')&&lit.ends_with('\''){lit=lit[1..lit.len()-1].to_string();ls+=1;le=le.saturating_sub(1);}out.push(literal_logical(&lit,ls,le,kind,font,o,false,kind=="interpretedQuote",true)?);}Ok(())
}

fn next_special_unit(text:&str,at:usize,mode:&str)->Option<usize>{
    let rest=&text[at..];
    if rest.starts_with('{')&&(mode=="sitelen-pona-ascii-extended"||mode=="sitelen-seli-kiwen"){let e=find_matching(rest,0,'{','}')?;let (_,mut p)=parse_identifier_at(rest,e+1)?;if p<rest.len()&&rest[p..].starts_with('('){p=find_matching(rest,p,'(',')')?+1;}return Some(at+p);}
    if let Some((_head,p))=parse_identifier_at(rest,0){if p<rest.len()&&rest[p..].starts_with('('){let head=&rest[..p];if mode!="standard-sitelen-pona-ascii-core"||head.eq_ignore_ascii_case("pi"){return Some(at+find_matching(rest,p,'(',')')?+1);}}}
    if mode=="sitelen-pona-ascii-extended"{
        let count=if rest.starts_with("pi+++")||rest.starts_with("pi---"){3}else if rest.starts_with("pi++")||rest.starts_with("pi--"){2}else if rest.starts_with("pi+")&&!rest.starts_with("pi+__"){1}else{0};
        if count>0{let prefix=2+count;let mut end=prefix;let mut n=0;while n<count&&end<rest.len(){while end<rest.len()&&rest.as_bytes()[end].is_ascii_whitespace(){end+=1;}if end>=rest.len(){break;}while end<rest.len()&&!rest.as_bytes()[end].is_ascii_whitespace(){end+=1;}n+=1;}if n==count{return Some(at+end);}}
        if rest.starts_with("pi+__"){let mut end=at+"pi+__".len();while end<text.len()&&!text.as_bytes()[end].is_ascii_whitespace(){end+=1;}return Some(end);}
    }
    None
}
fn raw_sequence_end(text:&str,at:usize)->Option<usize>{
    let mut pos=at;let mut count=0;
    loop{let rest=&text[pos..];if rest.len()<6||!(rest.starts_with("U+")||rest.starts_with("u+")){break;}let mut n=0;for c in rest[2..].chars(){if c.is_ascii_hexdigit()&&n<6{n+=1;}else{break;}}if n<4{break;}let end=pos+2+n;count+=1;pos=end;let mut ws=pos;while ws<text.len()&&text.as_bytes()[ws].is_ascii_whitespace(){ws+=1;}if ws==pos||ws>=text.len()||!(text[ws..].starts_with("U+")||text[ws..].starts_with("u+")){break;}pos=ws;}
    if count>0{Some(pos)}else{None}
}
fn parse_token_with_punctuation(token:&str,start:usize,kind:&str,out:&mut Vec<LogicalRun>,font:&FullFontInfo,o:&FullRenderOptions)->Result<(),RenderError>{
    if token.is_empty(){return Ok(());}let mut core=token;let mut s=start;
    while core.starts_with('(')||core.starts_with('{')||core.starts_with('['){let n=core.chars().next().unwrap().len_utf8();core=&core[n..];s+=n;}
    let mut e=s+core.len();let mut trail=String::new();
    while !core.is_empty(){let last=core.chars().last().unwrap();if !").,;:!?}]·".contains(last){break;}if last=='.'&&has_digit(core){break;}trail.insert(0,last);core=&core[..core.len()-last.len_utf8()];e=e.saturating_sub(last.len_utf8());}
    if core.ends_with('.')&&core.len()>1&&has_digit(&core[..core.len()-1]){trail.insert(0,'.');core=&core[..core.len()-1];e=e.saturating_sub(1);}
    if !core.is_empty()&&!matches!(core,"&"|"+"|"-"){emit_core(core,s,e,kind,out,font,o)?;}
    let mut p=e;for c in trail.chars(){let cp=if c=='.'||c=='·'{Some(MIDDLE_DOT_CODEPOINT)}else if c==':'{Some(COLON_CODEPOINT)}else if c==','{Some(',' as u32)}else{None};if let Some(cp)=cp{let mut logical=glyph_logical(&c.to_string(),&[cp],p,p+c.len_utf8(),kind,font,o,false,kind=="interpretedQuote")?;if c==','{logical.run.kind="run".into();}out.push(logical);}p+=c.len_utf8();}Ok(())
}
fn parse_text_no_direct(text:&str,base:usize,kind:&str,out:&mut Vec<LogicalRun>,font:&FullFontInfo,o:&FullRenderOptions)->Result<(),RenderError>{
    if text.is_empty(){return Ok(());}let trim=text.trim();if trim.is_empty(){return Ok(());}let leading=text.find(trim).unwrap_or(0);let mode=o.parser.effective_renderer_mode();
    // In Core mode the single-quoted extended aliases are not syntax.  The
    // quotes themselves disappear and the alias name is rendered as unknown
    // literal text, while surrounding Core words continue to parse normally.
    if mode=="standard-sitelen-pona-ascii-core"{
        // JavaScript treats the excluded `'colon'` convenience alias as one
        // unknown token when it is embedded in a Core token (for example
        // `jan'colon'pona`), rather than parsing the words on either side.
        if let Some(alias)=text.find("'colon'"){
            let bytes=text.as_bytes();
            let mut token_start=alias;
            while token_start>0 && !bytes[token_start-1].is_ascii_whitespace(){token_start-=1;}
            let mut token_end=alias+"'colon'".len();
            while token_end<text.len() && !bytes[token_end].is_ascii_whitespace(){token_end+=1;}
            if token_start>0{parse_text_no_direct(&text[..token_start],base,kind,out,font,o)?;}
            if o.parser.show_unknown_text{out.push(literal_logical(&text[token_start..token_end],base+token_start,base+token_end,kind,font,o,false,kind=="interpretedQuote",true)?);}
            if token_end<text.len(){parse_text_no_direct(&text[token_end..],base+token_end,kind,out,font,o)?;}
            return Ok(());
        }
        if let Some(open)=text.find('\''){if let Some(rel)=text[open+1..].find('\''){let close=open+1+rel;if open>0{parse_text_no_direct(&text[..open],base,kind,out,font,o)?;}let inner=&text[open+1..close];if !inner.is_empty()&&o.parser.show_unknown_text{out.push(literal_logical(inner,base+open+1,base+close,kind,font,o,false,kind=="interpretedQuote",true)?);}if close+1<text.len(){parse_text_no_direct(&text[close+1..],base+close+1,kind,out,font,o)?;}return Ok(());}}
    }
    if let Some(parsed)=full_phrase_parse(trim,&o.parser,false){out.push(numeric_logical(trim,&parsed,base+leading,base+leading+trim.len(),kind,font,o)?);return Ok(());}
    if let Some((st,en,parsed))=proper_numeric_prefix(text,&o.parser){out.push(numeric_logical(&text[st..en],&parsed,base+st,base+en,kind,font,o)?);if en<text.len(){parse_text_no_direct(&text[en..],base+en,kind,out,font,o)?;}return Ok(());}
    if !o.parser.enable_binary_parsing&&!o.parser.enable_binary_rendering{
        let t=trim;let low=t.to_ascii_lowercase();if let Some(digits)=low.strip_prefix("0b"){if !digits.is_empty()&&digits.chars().all(|c|c=='0'||c=='1'){let off=leading;let ds=off+2;if let Some(a)=numeric_full_parse("0b",&o.parser){out.push(numeric_logical("0b",&a,base+off,base+off+2,kind,font,o)?);}if let Some(b)=numeric_full_parse(&digits[..1],&o.parser){out.push(numeric_logical(&digits[..1],&b,base+ds,base+ds+1,kind,font,o)?);}if digits.len()>1{if let Some(c)=numeric_full_parse(&digits[1..],&o.parser){out.push(numeric_logical(&digits[1..],&c,base+ds+1,base+ds+digits.len(),kind,font,o)?);}}return Ok(());}}
    }
    if let Some(parsed)=numeric_full_parse(trim,&o.parser){if o.parser.nasin_nanpa_pona{if let Some(words)=parsed.nasin_nanpa_pona_words.as_ref().filter(|words|!words.is_empty()){for w in words{if let Some(cp)=word_to_cp(w){out.push(glyph_logical(trim,&[cp],base+leading,base+leading+trim.len(),kind,font,o,false,kind=="interpretedQuote")?);}}return Ok(());}}out.push(numeric_logical(trim,&parsed,base+leading,base+leading+trim.len(),kind,font,o)?);return Ok(());}
    let mut at=0usize;
    while at<text.len(){while at<text.len()&&text.as_bytes()[at].is_ascii_whitespace(){at+=1;}if at>=text.len(){break;}
        if let Some(re)=raw_sequence_end(text,at){let raw=&text[at..re];if let Some(cps)=parse_raw_unicode_sequence(raw){out.push(glyph_logical(raw,&cps,base+at,base+re,kind,font,o,false,kind=="interpretedQuote")?);at=re;continue;}}
        if let Some(end)=next_special_unit(text,at,mode){let src=&text[at..end];emit_core(src,base+at,base+end,kind,out,font,o)?;at=end;continue;}
        let mut end=at;while end<text.len()&&!text.as_bytes()[end].is_ascii_whitespace(){end+=1;}parse_token_with_punctuation(&text[at..end],base+at,kind,out,font,o)?;at=end;
    }Ok(())
}
fn is_direct_render_cp(cp:u32)->bool{(0xF1900..=0xF19FF).contains(&cp)||matches!(cp,OPEN_QUOTE_CODEPOINT|CLOSE_QUOTE_CODEPOINT)}
fn parse_text(text:&str,base:usize,kind:&str,out:&mut Vec<LogicalRun>,font:&FullFontInfo,o:&FullRenderOptions)->Result<(),RenderError>{
    if text.is_empty(){return Ok(());}let mut seg_start=0usize;let mut chars=text.char_indices().peekable();
    while let Some((idx,ch))=chars.next(){
        if matches!(ch,'–'|'—'|'−') { if idx>seg_start{parse_text_no_direct(&text[seg_start..idx],base+seg_start,kind,out,font,o)?;} seg_start=idx+ch.len_utf8(); continue; }
        if !is_direct_render_cp(ch as u32){continue;}
        if idx>seg_start{parse_text_no_direct(&text[seg_start..idx],base+seg_start,kind,out,font,o)?;}
        let mut cps=vec![ch as u32];let start=idx;let mut end=idx+ch.len_utf8();while let Some(&(j,c))=chars.peek(){if j==end&&is_direct_render_cp(c as u32){cps.push(c as u32);end=j+c.len_utf8();chars.next();}else{break;}}
        out.push(glyph_logical(&text[start..end],&cps,base+start,base+end,kind,font,o,false,kind=="interpretedQuote")?);seg_start=end;
    }
    if seg_start<text.len(){parse_text_no_direct(&text[seg_start..],base+seg_start,kind,out,font,o)?;}Ok(())
}

fn literal_cartouche_inner(text:&str)->Vec<u32>{let mut out=Vec::new();for ch in text.chars(){out.push(ch as u32);out.push(0xF1992);}out}
fn fallback_letters(text:&str)->Option<Vec<u32>>{
    const BANNED:[&str;6]=["ota","kolon","koma","te","to","zz"];
    let mut entries:Vec<(&'static str,u32)>=(0xF1900..=0xF19FF).filter_map(|cp|codepoint_to_word(cp).map(|w|(w,cp))).filter(|(w,_)|w.chars().all(|c|c.is_ascii_lowercase())&&!BANNED.contains(w)).collect();entries.sort_by_key(|(w,_)|*w);
    let mut bucket:BTreeMap<char,u32>=BTreeMap::new();for (w,cp) in entries{if let Some(c)=w.chars().next(){bucket.entry(c).or_insert(cp);}}
    let out:Vec<u32>=text.to_ascii_lowercase().chars().filter_map(|c|if c.is_ascii_lowercase(){bucket.get(&c).copied()}else{None}).collect();if out.is_empty(){None}else{Some(out)}
}
fn normalize_legacy_underscore(body:&str)->Option<String>{
    let s=body.trim();if !s.starts_with('_'){return None;}let mut words=Vec::new();for raw in s.split('_'){let p=raw.trim();if p.is_empty(){continue;}if word_to_cp(&sanitize_word(p)).is_none(){return None;}words.push(p);}if words.is_empty(){None}else{Some(words.join(" "))}
}
fn parse_bracket(body:&str,source_start:usize,out:&mut Vec<LogicalRun>,font:&FullFontInfo,o:&FullRenderOptions)->Result<(),RenderError>{
    let trim=body.trim();if trim.is_empty(){return Ok(());}let lead=body.find(trim).unwrap_or(0);let ss=source_start+lead;let ee=ss+trim.len();
    if trim.starts_with('"')&&trim.ends_with('"')&&trim.len()>=2{let inner=&trim[1..trim.len()-1];let unescaped=inner.replace("\\\"","\"").replace("\\\\","\\");let cps=literal_cartouche_inner(&unescaped);out.push(literal_cartouche_logical(trim,&cps,ss,ee,"bracket",font,o)?);return Ok(());}
    let wrapped=format!("[{trim}]");if let Some(parsed)=numeric_full_parse(&wrapped,&o.parser){out.push(numeric_logical(trim,&parsed,ss,ee,"bracket",font,o)?);return Ok(());}if let Some(parsed)=numeric_full_parse(trim,&o.parser){if !parsed.is_hex&&!parsed.is_binary{out.push(numeric_logical(trim,&parsed,ss,ee,"bracket",font,o)?);return Ok(());}}
    if let Some(parsed)=full_phrase_parse(trim,&o.parser,false){out.push(numeric_logical(trim,&parsed,ss,ee,"bracket",font,o)?);return Ok(());}
    if o.parser.abbreviate_numeric_cartouches{if let Some(parsed)=full_phrase_parse(trim,&o.parser,true){out.push(numeric_logical(trim,&parsed,ss,ee,"bracket",font,o)?);return Ok(());}}
    let mode=o.parser.effective_renderer_mode();let mut ordinary=trim.to_string();if mode=="sitelen-pona-ascii-extended"{if let Some(norm)=normalize_legacy_underscore(trim){ordinary=norm;}}
    if !ordinary.chars().any(|c|matches!(c,','|'.'|':'|'·'|'('|')')){if let Some(cps)=glyph_words_cps(&ordinary){let oc=OrdinaryCartouche{manual_tallies:vec![0;cps.len()],inner:cps,tally_mode:"ucsur".into(),scale_markers:vec![]};out.push(cartouche_logical(trim,&oc,ss,ee,"bracket",font,o)?);return Ok(());}}
    if let Some(oc)=parse_ordinary_body(&ordinary,font,&o.parser){out.push(cartouche_logical(trim,&oc,ss,ee,"bracket",font,o)?);return Ok(());}
    if let Some(cps)=fallback_letters(trim){let oc=OrdinaryCartouche{manual_tallies:vec![0;cps.len()],inner:cps,tally_mode:"ucsur".into(),scale_markers:vec![]};out.push(cartouche_logical(trim,&oc,ss,ee,"bracket",font,o)?);return Ok(());}
    if o.parser.show_unknown_text{out.push(literal_logical(trim,ss,ee,"bracket",font,o,false,false,true)?);}Ok(())
}
fn parse_quote(seg:&DocumentSegment,out:&mut Vec<LogicalRun>,font:&FullFontInfo,o:&FullRenderOptions)->Result<(),RenderError>{
    let q=seg.value.replace("\\\"","\"").replace("\\\\","\\").replace("\\t","    ").replace("\\n","\n");
    if o.parser.interpret_double_quotes_as_te_to{out.push(glyph_logical("te",&[OPEN_QUOTE_CODEPOINT],seg.source_start,seg.source_start+1,"interpretedQuote",font,o,false,true)?);let before=out.len();parse_text(&q,seg.source_start+1,"interpretedQuote",out,font,o)?;for r in &mut out[before..]{r.run.interpreted_quote=true;if r.run.unrecognized&&r.run.font_role=="literal"{r.run.font_role="unknown".into();}}out.push(glyph_logical("to",&[CLOSE_QUOTE_CODEPOINT],seg.source_end.saturating_sub(1),seg.source_end,"interpretedQuote",font,o,false,true)?);}else{out.push(literal_rendered_logical(&q,&seg.value,seg.source_start,seg.source_end,"quote",font,o,true,false,false)?);}Ok(())
}

impl NanpaLinjaN {
    fn prepare_full(&self,input:&str,options:&FullRenderOptions)->Result<PreparedFull,RenderError>{
        let o=normalize_options(options.clone());let registry=full_registry()?;let font=registry.get(&o.font).cloned().ok_or_else(||RenderError::UnknownFont(format!("unknown production font: {}",o.font)))?;let ast=parse_full_document(input,&o.parser);let mut logical_lines:Vec<Vec<LogicalRun>>=Vec::with_capacity(ast.lines.len());let mut first_parsed=None;let mut any_abbr=false;
        for line in &ast.lines{let mut runs=Vec::new();for seg in &line.children{match seg.kind.as_str(){"text"=>parse_text(&seg.value,seg.source_start,"text",&mut runs,&font,&o)?,"bracket"=>parse_bracket(&seg.value,seg.source_start,&mut runs,&font,&o)?,"quote"=>parse_quote(seg,&mut runs,&font,&o)?,"image"=>runs.push(image_logical(seg,&font,&o)?),_=>{}}}for l in &runs{if l.run.numeric_cartouche&&first_parsed.is_none(){first_parsed=numeric_full_parse(&l.run.source_text,&o.parser);}if l.run.numeric_cartouche&&o.parser.abbreviate_numeric_cartouches{any_abbr=true;}}logical_lines.push(runs);}
        let line_gap=o.layout.line_gap(o.font_size);let pad=o.padding_px as f64;let mut line_widths=vec![0.0;logical_lines.len()];let mut line_asc=vec![0.0;logical_lines.len()];let mut line_desc=vec![0.0;logical_lines.len()];let mut maxw:f64=0.0;
        for (i,line) in logical_lines.iter().enumerate(){let mut x=0.0;let mut asc:f64=0.0;let mut desc:f64=0.0;let mut first=true;for l in line{if !first{x+=if l.run.font_role=="cartouche"||l.run.numeric_cartouche{o.layout.cartouche_lead_gap(o.font_size)}else{o.layout.glyph_gap(o.font_size)};}first=false;x+=l.graphic.width;asc=asc.max(l.graphic.baseline);desc=desc.max((l.graphic.height-l.graphic.baseline).max(0.0));}let h=o.font_size.max(asc+desc);if line.is_empty(){asc=o.font_size*0.82;desc=h-asc;}line_widths[i]=x;line_asc[i]=asc;line_desc[i]=desc;maxw=maxw.max(x);}
        let width=(maxw+2.0*pad).ceil().max(1.0) as u32;let mut total=2.0*pad+line_gap*((logical_lines.len().saturating_sub(1))as f64);for i in 0..logical_lines.len(){total+=o.font_size.max(line_asc[i]+line_desc[i]);}let height=total.ceil().max(1.0) as u32;
        let mut all_runs=Vec::new();let mut line_plans=Vec::new();let mut placed=Vec::new();let mut y=pad;
        for (li,line) in logical_lines.into_iter().enumerate(){let lw=line_widths[li];let asc=line_asc[li];let desc=line_desc[li];let lh=o.font_size.max(asc+desc);let mut x=pad;match o.layout.align.to_ascii_lowercase().as_str(){"center"=>x+=(maxw-lw)/2.0,"right"=>x+=maxw-lw,_=>{}}let line_start=x;let mut lr=Vec::new();let mut first=true;for (ri,mut l) in line.into_iter().enumerate(){if !first{x+=if l.run.font_role=="cartouche"||l.run.numeric_cartouche{o.layout.cartouche_lead_gap(o.font_size)}else{o.layout.glyph_gap(o.font_size)};}first=false;let ty=y+asc-l.graphic.baseline;let tx=x;l.run.id=format!("L{li}R{ri}");l.run.line_index=li;l.run.run_index=ri;l.run.x_px=tx;l.run.y_px=ty;l.run.width_px=l.graphic.width;l.run.height_px=l.graphic.height;l.run.baseline_y_px=y+asc;if !l.graphic.tally_groups.is_empty(){l.run.tally_groups=l.graphic.tally_groups.iter().cloned().map(|mut g|{g.owner_left_px+=tx;g.owner_right_px+=tx;g.center_x_px+=tx;g.top_y_px+=ty;g.bottom_y_px+=ty;for c in &mut g.stroke_centers_px{*c+=tx;}g}).collect();}let r=l.run.clone();placed.push(l);all_runs.push(r.clone());lr.push(r);x+=all_runs.last().unwrap().width_px;}
            line_plans.push(FullRenderLinePlan{line_index:li,source_line_index:ast.lines[li].source_line_index,sentence_index_in_source_line:ast.lines[li].sentence_index_in_source_line,x_px:line_start,y_px:y,width_px:lw,height_px:lh,baseline_y_px:y+asc,ascent_px:asc,descent_px:desc,runs:lr});y+=lh;if li+1<ast.lines.len(){y+=line_gap;}}
        let plan=FullRenderPlan{input:input.into(),font_key:font.key.clone(),abbreviated:any_abbr,width,height,open_type_features:full_open_type_features_for(o.font_size),runs:all_runs,parsed:first_parsed,diagnostics:vec![],ast:ast.clone(),lines:line_plans};Ok(PreparedFull{plan,placed,options:o})
    }
    pub fn build_full_render_plan(&self,input:&str,options:&FullRenderOptions)->Result<FullRenderPlan,RenderError>{Ok(self.prepare_full(input,options)?.plan)}
}

fn blend(dst:&mut [u8],src:[u8;4],coverage:u8){let sa=(src[3]as u32*coverage as u32+127)/255;let da=dst[3]as u32;let inv=255-sa;let oa=sa+(da*inv+127)/255;if oa==0{dst.copy_from_slice(&[0,0,0,0]);return;}for c in 0..3{let sp=src[c]as u32*sa;let dp=dst[c]as u32*da;let op=sp+(dp*inv+127)/255;dst[c]=((op+oa/2)/oa).min(255)as u8;}dst[3]=oa.min(255)as u8;}
fn put_pixel(rgba:&mut[u8],w:u32,h:u32,x:i32,y:i32,color:[u8;4],coverage:u8){if x<0||y<0||x>=w as i32||y>=h as i32{return;}let i=(y as usize*w as usize+x as usize)*4;blend(&mut rgba[i..i+4],color,coverage);}
fn draw_line(rgba:&mut[u8],w:u32,h:u32,x:f64,y1:f64,y2:f64,width:f64,color:[u8;4]){let left=(x-width/2.0).floor()as i32;let right=(x+width/2.0).ceil()as i32;let top=y1.min(y2).floor()as i32;let bottom=y1.max(y2).ceil()as i32;for yy in top..=bottom{for xx in left..=right{put_pixel(rgba,w,h,xx,yy,color,255);}}}
fn fill_rect_solid(rgba:&mut[u8],w:u32,h:u32,x:f64,y:f64,rw:f64,rh:f64,color:[u8;4]){let left=x.floor()as i32;let right=(x+rw).ceil()as i32;let top=y.floor()as i32;let bottom=(y+rh).ceil()as i32;for yy in top..bottom{for xx in left..right{put_pixel(rgba,w,h,xx,yy,color,255);}}}
fn synthetic_corner_geometry(cp:u32,font_size:f64)->(f64,f64,f64,f64,f64,f64){let run_w=(font_size*0.36).ceil().max(1.0);let run_h=(font_size*0.76).ceil().max(1.0);let stroke=if font_size<=12.0{(font_size*0.065).max(1.0)}else{(font_size*0.065).max(2.5)};let pad=(stroke*0.5).max(0.5);let lift=if cp==CLOSE_QUOTE_CODEPOINT{0.0}else{(font_size*0.18).max(4.0)};let arm=(font_size*0.26).max((run_w*0.82).min(font_size*0.48));(run_w,run_h,stroke,pad,lift,arm)}
fn draw_synthetic_corner(rgba:&mut[u8],w:u32,h:u32,r:&FullRenderRun,g:&FullGraphic,font_size:f64,color:[u8;4]){let Some(cp)=g.synthetic_corner_codepoint else{return;};let (run_w,run_h,stroke,pad,_lift,arm)=synthetic_corner_geometry(cp,font_size);let x_left=r.x_px+pad;let x_right=r.x_px+run_w-pad;let y_top=r.y_px;let y_bottom=y_top+run_h;if cp==CLOSE_QUOTE_CODEPOINT{fill_rect_solid(rgba,w,h,x_right-arm,y_bottom-stroke,arm,stroke,color);fill_rect_solid(rgba,w,h,x_right-stroke,y_top,stroke,run_h,color);}else{fill_rect_solid(rgba,w,h,x_left,y_top,stroke,run_h,color);fill_rect_solid(rgba,w,h,x_left,y_top,arm,stroke,color);}}
fn draw_rect(rgba:&mut[u8],w:u32,h:u32,x:f64,y:f64,rw:f64,rh:f64,lw:f64,color:[u8;4]){let n=lw.ceil().max(1.0)as i32;for k in 0..n{let x0=(x+k as f64).round()as i32;let y0=(y+k as f64).round()as i32;let x1=(x+rw-k as f64).round()as i32;let y1=(y+rh-k as f64).round()as i32;for xx in x0..=x1{put_pixel(rgba,w,h,xx,y0,color,255);put_pixel(rgba,w,h,xx,y1,color,255);}for yy in y0..=y1{put_pixel(rgba,w,h,x0,yy,color,255);put_pixel(rgba,w,h,x1,yy,color,255);}}}
fn draw_shaped(rgba:&mut[u8],w:u32,h:u32,sh:&ShapedText,x:f64,y:f64,color:[u8;4],halo:Option<([u8;4],f64)>){if let Some((hc,hw))=halo{let r=hw.ceil()as i32;for g in &sh.glyphs{let gx=(x+sh.origin_x+g.left).round()as i32;let gy=(y+sh.origin_y+g.top).round()as i32;for row in 0..g.height{for col in 0..g.width{let cov=g.bitmap[row*g.width+col];if cov==0{continue;}for oy in -r..=r{for ox in -r..=r{if ox*ox+oy*oy<=r*r{put_pixel(rgba,w,h,gx+col as i32+ox,gy+row as i32+oy,hc,cov);}}}}}}}for g in &sh.glyphs{let gx=(x+sh.origin_x+g.left).round()as i32;let gy=(y+sh.origin_y+g.top).round()as i32;for row in 0..g.height{for col in 0..g.width{let cov=g.bitmap[row*g.width+col];if cov>0{put_pixel(rgba,w,h,gx+col as i32,gy+row as i32,color,cov);}}}}}
fn draw_shaped_halo_only(rgba:&mut[u8],w:u32,h:u32,sh:&ShapedText,x:f64,y:f64,color:[u8;4],halo_width:f64){let r=halo_width.ceil()as i32;for g in &sh.glyphs{let gx=(x+sh.origin_x+g.left).round()as i32;let gy=(y+sh.origin_y+g.top).round()as i32;for row in 0..g.height{for col in 0..g.width{let cov=g.bitmap[row*g.width+col];if cov==0{continue;}for oy in -r..=r{for ox in -r..=r{if ox*ox+oy*oy<=r*r{put_pixel(rgba,w,h,gx+col as i32+ox,gy+row as i32+oy,color,cov);}}}}}}}
fn draw_shaped_foreground_only(rgba:&mut[u8],w:u32,h:u32,sh:&ShapedText,x:f64,y:f64,color:[u8;4]){for g in &sh.glyphs{let gx=(x+sh.origin_x+g.left).round()as i32;let gy=(y+sh.origin_y+g.top).round()as i32;for row in 0..g.height{for col in 0..g.width{let cov=g.bitmap[row*g.width+col];if cov>0{put_pixel(rgba,w,h,gx+col as i32,gy+row as i32,color,cov);}}}}}
fn fill_rounded_rect(rgba:&mut[u8],w:u32,h:u32,x:f64,y:f64,rw:f64,rh:f64,radius:f64,color:[u8;4]){if rw<=0.0||rh<=0.0{return;}let r=radius.max(0.0).min(rw/2.0).min(rh/2.0);let left=x.floor()as i32;let right=(x+rw).ceil()as i32-1;let top=y.floor()as i32;let bottom=(y+rh).ceil()as i32-1;for yy in top..=bottom{for xx in left..=right{let px=xx as f64+0.5;let py=yy as f64+0.5;if px<x||px>x+rw||py<y||py>y+rh{continue;}let cx=px.max(x+r).min(x+rw-r);let cy=py.max(y+r).min(y+rh-r);let dx=px-cx;let dy=py-cy;if dx*dx+dy*dy<=r*r{put_pixel(rgba,w,h,xx,yy,color,255);}}}}
fn draw_tally_group_halo(rgba:&mut[u8],w:u32,h:u32,tg:&TallyGroup,font_size:f64,halo_width:f64,color:[u8;4]){let Some(first)=tg.stroke_centers_px.first()else{return;};let Some(last)=tg.stroke_centers_px.last()else{return;};let pad_x=halo_width*0.85;let pad_bottom=halo_width*0.85;let radius=1.25_f64.max(halo_width.min(font_size.max(8.0)*0.045));let left=*first-tg.stroke_width_px/2.0;let right=*last+tg.stroke_width_px/2.0;let top=tg.top_y_px;let bottom=tg.bottom_y_px;fill_rounded_rect(rgba,w,h,left-pad_x,top,(right-left)+pad_x*2.0,((bottom-top)+pad_bottom).max(1.0),radius,color);}

fn draw_embedded_corner(rgba:&mut[u8],w:u32,h:u32,r:&FullRenderRun,cp:u32,local_x:f64,font_size:f64,color:[u8;4]){
    let (run_w,run_h,stroke,pad,_lift,arm)=synthetic_corner_geometry(cp,font_size);let x0=r.x_px+local_x;let x_left=x0+pad;let x_right=x0+run_w-pad;let y_top=r.y_px+(r.height_px-run_h).max(0.0)*0.5;let y_bottom=y_top+run_h;if cp==CLOSE_QUOTE_CODEPOINT{fill_rect_solid(rgba,w,h,x_right-arm,y_bottom-stroke,arm,stroke,color);fill_rect_solid(rgba,w,h,x_right-stroke,y_top,stroke,run_h,color);}else{fill_rect_solid(rgba,w,h,x_left,y_top,stroke,run_h,color);fill_rect_solid(rgba,w,h,x_left,y_top,arm,stroke,color);}
}
fn render_prepared_rgba(prep:&PreparedFull)->Result<Vec<u8>,RenderError>{let w=prep.plan.width;let h=prep.plan.height;let mut rgba=vec![0u8;w as usize*h as usize*4];let fg=rgba_hex(&prep.options.paint.fill_style,[0,0,0,255]);let halo=if prep.options.paint.halo_enabled{Some((rgba_hex(&prep.options.paint.halo_color,[255,255,255,255]),if prep.options.paint.halo_width_px>0.0{prep.options.paint.halo_width_px}else{(prep.options.font_size*0.10).round().clamp(2.0,24.0)}))}else{None};for l in &prep.placed{let r=&l.run;let g=&l.graphic;if g.synthetic_corner_codepoint.is_some(){draw_synthetic_corner(&mut rgba,w,h,r,g,prep.options.font_size,fg);}else if !g.image_bytes.is_empty(){if let Ok(img)=image::load_from_memory(&g.image_bytes){let src=img.to_rgba8();let sw=src.width().max(1);let sh=src.height().max(1);let tw=g.width.round().max(1.0)as u32;let th=g.height.round().max(1.0)as u32;for yy in 0..th{for xx in 0..tw{let sx=(xx as u64*sw as u64/tw as u64)as u32;let sy=(yy as u64*sh as u64/th as u64)as u32;let p=src.get_pixel(sx.min(sw-1),sy.min(sh-1)).0;put_pixel(&mut rgba,w,h,(r.x_px+xx as f64)as i32,(r.y_px+yy as f64)as i32,p,255);}}}}else if !g.text.is_empty(){let bytes=bundled_full_font_bytes(&g.font_filename).ok_or_else(||RenderError::Font(format!("missing {}",g.font_filename)))?;let sh=shape_text(&g.text,bytes,prep.options.font_size,&g.features,if r.font_role=="cartouche"||r.numeric_cartouche{6.0}else{0.0},if !r.tally_groups.is_empty(){(prep.options.font_size*0.34).ceil()}else{0.0})?;if !r.tally_groups.is_empty(){if let Some((hc,hw))=halo{draw_shaped_halo_only(&mut rgba,w,h,&sh,r.x_px,r.y_px,hc,hw);for tg in &r.tally_groups{draw_tally_group_halo(&mut rgba,w,h,tg,prep.options.font_size,hw,hc);}draw_shaped_foreground_only(&mut rgba,w,h,&sh,r.x_px,r.y_px,fg);}else{draw_shaped(&mut rgba,w,h,&sh,r.x_px,r.y_px,fg,None);}}else{draw_shaped(&mut rgba,w,h,&sh,r.x_px,r.y_px,fg,halo);}}for (cp,lx) in &g.embedded_corners{draw_embedded_corner(&mut rgba,w,h,r,*cp,*lx,prep.options.font_size,fg);}for tg in &r.tally_groups{for cx in &tg.stroke_centers_px{draw_line(&mut rgba,w,h,*cx,tg.top_y_px,tg.bottom_y_px,tg.stroke_width_px,fg);}}if r.unrecognized&&g.unknown_decoration{let uc=rgba_hex(&prep.options.paint.unknown_text.color,[0,0,0,255]);draw_rect(&mut rgba,w,h,r.x_px,r.y_px,g.width,g.height,prep.options.paint.unknown_text.line_width_px.max(1.0),uc);}}Ok(rgba)}
fn encode_png_rgba(rgba:&[u8],w:u32,h:u32)->Result<Vec<u8>,RenderError>{let mut out=Vec::new();PngEncoder::new(&mut out).write_image(rgba,w,h,ColorType::Rgba8.into()).map_err(|e|RenderError::Image(format!("PNG: {e}")))?;Ok(out)}

fn base64_encode(bytes:&[u8])->String{
    const TABLE:&[u8;64]=b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut out=String::with_capacity(((bytes.len()+2)/3)*4);let mut i=0usize;
    while i+3<=bytes.len(){let n=((bytes[i]as u32)<<16)|((bytes[i+1]as u32)<<8)|bytes[i+2]as u32;out.push(TABLE[((n>>18)&63)as usize]as char);out.push(TABLE[((n>>12)&63)as usize]as char);out.push(TABLE[((n>>6)&63)as usize]as char);out.push(TABLE[(n&63)as usize]as char);i+=3;}
    match bytes.len()-i{1=>{let n=(bytes[i]as u32)<<16;out.push(TABLE[((n>>18)&63)as usize]as char);out.push(TABLE[((n>>12)&63)as usize]as char);out.push('=');out.push('=');},2=>{let n=((bytes[i]as u32)<<16)|((bytes[i+1]as u32)<<8);out.push(TABLE[((n>>18)&63)as usize]as char);out.push(TABLE[((n>>12)&63)as usize]as char);out.push(TABLE[((n>>6)&63)as usize]as char);out.push('=');},_=>{}}
    out
}
fn xml_escape(s:&str)->String{s.replace('&',"&amp;").replace('<',"&lt;").replace('>',"&gt;").replace('"',"&quot;").replace('\'',"&apos;")}
fn svg_color(hex:&str)->String{let c=rgba_hex(hex,[0,0,0,255]);format!("rgb({},{},{})",c[0],c[1],c[2])}
fn mime_for_font(filename:&str)->&'static str{if filename.to_ascii_lowercase().ends_with(".ttf"){"font/ttf"}else{"font/otf"}}

fn svg_from_prepared(prep:&PreparedFull)->Result<String,RenderError>{
    let mut css=String::new();let mut families:BTreeMap<String,String>=BTreeMap::new();
    for (i,l) in prep.placed.iter().enumerate(){let f=&l.graphic.font_filename;if f.is_empty()||families.contains_key(f){continue;}let Some(bytes)=bundled_full_font_bytes(f)else{continue};let fam=format!("NLNFullFont{}",i);css.push_str(&format!("@font-face{{font-family:'{}';src:url(data:{};base64,{});}}",fam,mime_for_font(f),base64_encode(bytes)));families.insert(f.clone(),fam);}
    let fg=svg_color(&prep.options.paint.fill_style);let halo=svg_color(&prep.options.paint.halo_color);let mut body=String::new();
    for l in &prep.placed{let r=&l.run;let g=&l.graphic;let manual_halo=prep.options.paint.halo_enabled&&!r.tally_groups.is_empty();let hw=if prep.options.paint.halo_width_px>0.0{prep.options.paint.halo_width_px}else{(prep.options.font_size*0.10).round().clamp(2.0,24.0)};let mut text_parts:Option<(String,String)>=None;if let Some(cp)=g.synthetic_corner_codepoint{let (run_w,run_h,stroke,pad,_lift,arm)=synthetic_corner_geometry(cp,prep.options.font_size);let xl=r.x_px+pad;let xr=r.x_px+run_w-pad;let yt=r.y_px;let yb=yt+run_h;let d=if cp==CLOSE_QUOTE_CODEPOINT{format!("M {:.3} {:.3} L {:.3} {:.3} L {:.3} {:.3}",xr-arm,yb,xr,yb,xr,yt)}else{format!("M {:.3} {:.3} L {:.3} {:.3} L {:.3} {:.3}",xl,yb,xl,yt,xl+arm,yt)};body.push_str(&format!("<path d=\"{}\" stroke=\"{}\" stroke-width=\"{:.3}\" fill=\"none\"/>",d,fg,stroke));}else if !g.image_bytes.is_empty(){let mime=if g.image_bytes.starts_with(b"\x89PNG"){"image/png"}else if g.image_bytes.starts_with(b"\xFF\xD8"){"image/jpeg"}else{"application/octet-stream"};body.push_str(&format!("<image x=\"{:.3}\" y=\"{:.3}\" width=\"{:.3}\" height=\"{:.3}\" href=\"data:{};base64,{}\"/>",r.x_px,r.y_px,g.width,g.height,mime,base64_encode(&g.image_bytes)));}else if !g.text.is_empty(){if r.numeric_cartouche{let bytes=bundled_full_font_bytes(&g.font_filename).ok_or_else(||RenderError::Font(format!("missing {}",g.font_filename)))?;let d=svg_text_paths(&g.text,bytes,prep.options.font_size,&g.features,r.x_px+g.origin_x,r.y_px+g.baseline)?;body.push_str(&format!("<path d=\"{}\" fill=\"{}\"/>",d,fg));}let fam=families.get(&g.font_filename).cloned().unwrap_or_else(||"sans-serif".into());let features=if g.features.is_empty(){String::new()}else{g.features.iter().map(|x|format!("'{}' 1",x)).collect::<Vec<_>>().join(",")};if manual_halo{body.push_str(&format!("<text x=\"{:.3}\" y=\"{:.3}\" font-family=\"{}\" font-size=\"{:.3}px\" font-feature-settings=\"{}\" fill=\"none\" stroke=\"{}\" stroke-width=\"{:.3}\" style=\"stroke-linejoin:round;\">{}</text>",r.x_px+g.origin_x,r.y_px+g.baseline,xml_escape(&fam),prep.options.font_size,xml_escape(&features),halo,2.0*hw,xml_escape(&g.text)));text_parts=Some((fam,features));}else{let halo_style=if prep.options.paint.halo_enabled{format!("stroke:{};stroke-width:{:.3};paint-order:stroke fill;stroke-linejoin:round;",halo,2.0*hw)}else{String::new()};body.push_str(&format!("<text x=\"{:.3}\" y=\"{:.3}\" font-family=\"{}\" font-size=\"{:.3}px\" font-feature-settings=\"{}\" fill=\"{}\" style=\"{}\">{}</text>",r.x_px+g.origin_x,r.y_px+g.baseline,xml_escape(&fam),prep.options.font_size,xml_escape(&features),fg,halo_style,xml_escape(&g.text)));}}
        if manual_halo{for tg in &r.tally_groups{let Some(first)=tg.stroke_centers_px.first()else{continue;};let Some(last)=tg.stroke_centers_px.last()else{continue;};let pad_x=hw*0.85;let pad_bottom=hw*0.85;let radius=1.25_f64.max(hw.min(prep.options.font_size.max(8.0)*0.045));let left=*first-tg.stroke_width_px/2.0;let right=*last+tg.stroke_width_px/2.0;let height=((tg.bottom_y_px-tg.top_y_px)+pad_bottom).max(1.0);body.push_str(&format!("<rect x=\"{:.3}\" y=\"{:.3}\" width=\"{:.3}\" height=\"{:.3}\" rx=\"{:.3}\" ry=\"{:.3}\" fill=\"{}\"/>",left-pad_x,tg.top_y_px,(right-left)+pad_x*2.0,height,radius,radius,halo));}if let Some((fam,features))=text_parts{body.push_str(&format!("<text x=\"{:.3}\" y=\"{:.3}\" font-family=\"{}\" font-size=\"{:.3}px\" font-feature-settings=\"{}\" fill=\"{}\">{}</text>",r.x_px+g.origin_x,r.y_px+g.baseline,xml_escape(&fam),prep.options.font_size,xml_escape(&features),fg,xml_escape(&g.text)));}}
        for (cp,lx) in &g.embedded_corners{let (run_w,run_h,stroke,pad,_lift,arm)=synthetic_corner_geometry(*cp,prep.options.font_size);let x0=r.x_px+*lx;let xl=x0+pad;let xr=x0+run_w-pad;let yt=r.y_px+(r.height_px-run_h).max(0.0)*0.5;let yb=yt+run_h;let d=if *cp==CLOSE_QUOTE_CODEPOINT{format!("M {:.3} {:.3} L {:.3} {:.3} L {:.3} {:.3}",xr-arm,yb,xr,yb,xr,yt)}else{format!("M {:.3} {:.3} L {:.3} {:.3} L {:.3} {:.3}",xl,yb,xl,yt,xl+arm,yt)};body.push_str(&format!("<path d=\"{}\" stroke=\"{}\" stroke-width=\"{:.3}\" fill=\"none\"/>",d,fg,stroke));}
        for tg in &r.tally_groups{for cx in &tg.stroke_centers_px{body.push_str(&format!("<path d=\"M {:.3} {:.3} L {:.3} {:.3}\" stroke=\"{}\" stroke-width=\"{:.3}\" stroke-linecap=\"butt\" fill=\"none\"/>",cx,tg.top_y_px,cx,tg.bottom_y_px,fg,tg.stroke_width_px));}}
        if r.unrecognized&&g.unknown_decoration{body.push_str(&format!("<rect x=\"{:.3}\" y=\"{:.3}\" width=\"{:.3}\" height=\"{:.3}\" fill=\"none\" stroke=\"{}\" stroke-width=\"{:.3}\"/>",r.x_px,r.y_px,g.width,g.height,svg_color(&prep.options.paint.unknown_text.color),prep.options.paint.unknown_text.line_width_px.max(1.0)));}
    }
    Ok(format!("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{}\" height=\"{}\" viewBox=\"0 0 {} {}\"><style>{}</style>{}</svg>",prep.plan.width,prep.plan.height,prep.plan.width,prep.plan.height,css,body))
}


fn pdf_rgb(hex:&str)->(f64,f64,f64){let c=rgba_hex(hex,[0,0,0,255]);(c[0]as f64/255.0,c[1]as f64/255.0,c[2]as f64/255.0)}
fn pdf_line(content:&mut String,x1:f64,y1:f64,x2:f64,y2:f64,width:f64){content.push_str(&format!("{:.3} w\n{:.3} {:.3} m\n{:.3} {:.3} l\nS\n",width,x1,y1,x2,y2));}
fn vector_pdf(prep:&PreparedFull)->Result<Vec<u8>,RenderError>{
    let mut content=String::new();content.push_str(&format!("q\n1 0 0 -1 0 {} cm\n",prep.plan.height));
    let (fr,fg,fb)=pdf_rgb(&prep.options.paint.fill_style);content.push_str(&format!("{fr:.5} {fg:.5} {fb:.5} rg\n{fr:.5} {fg:.5} {fb:.5} RG\n"));
    for l in &prep.placed{
        let r=&l.run;let g=&l.graphic;
        if !g.image_bytes.is_empty(){return Err(RenderError::Image("vector PDF does not rasterize embedded image runs".into()));}
        if let Some(cp)=g.synthetic_corner_codepoint{
            let (run_w,run_h,stroke,pad,_lift,arm)=synthetic_corner_geometry(cp,prep.options.font_size);let xl=r.x_px+pad;let xr=r.x_px+run_w-pad;let yt=r.y_px;let yb=yt+run_h;
            if cp==CLOSE_QUOTE_CODEPOINT{pdf_line(&mut content,xr-arm,yb,xr,yb,stroke);pdf_line(&mut content,xr,yb,xr,yt,stroke);}else{pdf_line(&mut content,xl,yb,xl,yt,stroke);pdf_line(&mut content,xl,yt,xl+arm,yt,stroke);}
        }else if !g.text.is_empty(){
            let bytes=bundled_full_font_bytes(&g.font_filename).ok_or_else(||RenderError::Font(format!("missing {}",g.font_filename)))?;
            let path=pdf_text_path(&g.text,bytes,prep.options.font_size,&g.features,r.x_px+g.origin_x,r.y_px+g.baseline)?;
            if !path.is_empty(){
                if prep.options.paint.halo_enabled{let (hr,hg,hb)=pdf_rgb(&prep.options.paint.halo_color);let hw=if prep.options.paint.halo_width_px>0.0{prep.options.paint.halo_width_px}else{(prep.options.font_size*0.10).round().clamp(2.0,24.0)};content.push_str(&format!("q\n{hr:.5} {hg:.5} {hb:.5} RG\n{:.3} w\n1 j\n1 J\n{}S\nQ\n",2.0*hw,path));}
                content.push_str(&path);content.push_str("f\n");
            }
        }
        for (cp,lx) in &g.embedded_corners{let (run_w,run_h,stroke,pad,_lift,arm)=synthetic_corner_geometry(*cp,prep.options.font_size);let x0=r.x_px+*lx;let xl=x0+pad;let xr=x0+run_w-pad;let yt=r.y_px+(r.height_px-run_h).max(0.0)*0.5;let yb=yt+run_h;if *cp==CLOSE_QUOTE_CODEPOINT{pdf_line(&mut content,xr-arm,yb,xr,yb,stroke);pdf_line(&mut content,xr,yb,xr,yt,stroke);}else{pdf_line(&mut content,xl,yb,xl,yt,stroke);pdf_line(&mut content,xl,yt,xl+arm,yt,stroke);}}
        for tg in &r.tally_groups{for cx in &tg.stroke_centers_px{pdf_line(&mut content,*cx,tg.top_y_px,*cx,tg.bottom_y_px,tg.stroke_width_px);}}
        if r.unrecognized&&g.unknown_decoration{let (ur,ug,ub)=pdf_rgb(&prep.options.paint.unknown_text.color);content.push_str(&format!("q\n{ur:.5} {ug:.5} {ub:.5} RG\n{:.3} w\n{:.3} {:.3} {:.3} {:.3} re\nS\nQ\n",prep.options.paint.unknown_text.line_width_px.max(1.0),r.x_px,r.y_px,g.width,g.height));}
    }
    content.push_str("Q\n");
    let mut out=Vec::<u8>::new();out.extend_from_slice(b"%PDF-1.4\n%\xE2\xE3\xCF\xD3\n");let mut offsets=vec![0usize];
    fn obj(out:&mut Vec<u8>,offsets:&mut Vec<usize>,n:usize,head:&str,stream:Option<&[u8]>){while offsets.len()<=n{offsets.push(0);}offsets[n]=out.len();out.extend_from_slice(format!("{} 0 obj\n{}",n,head).as_bytes());if let Some(data)=stream{out.extend_from_slice(b"\nstream\n");out.extend_from_slice(data);out.extend_from_slice(b"\nendstream");}out.extend_from_slice(b"\nendobj\n");}
    obj(&mut out,&mut offsets,1,"<< /Type /Catalog /Pages 2 0 R >>",None);obj(&mut out,&mut offsets,2,"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",None);obj(&mut out,&mut offsets,3,&format!("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {} {}] /Resources << >> /Contents 4 0 R >>",prep.plan.width,prep.plan.height),None);obj(&mut out,&mut offsets,4,&format!("<< /Length {} >>",content.len()),Some(content.as_bytes()));
    let xref=out.len();out.extend_from_slice(format!("xref\n0 {}\n0000000000 65535 f \n",offsets.len()).as_bytes());for off in offsets.iter().skip(1){out.extend_from_slice(format!("{:010} 00000 n \n",off).as_bytes());}out.extend_from_slice(format!("trailer\n<< /Size {} /Root 1 0 R >>\nstartxref\n{}\n%%EOF\n",offsets.len(),xref).as_bytes());Ok(out)
}

fn graphic_for_public_run(run:&FullRenderRun,font:&FullFontInfo,o:&FullRenderOptions)->Result<FullGraphic,RenderError>{
    if run.render_mode=="synthetic-corner-bracket"&&run.canonical_codepoints.len()==1&&matches!(run.canonical_codepoints[0],OPEN_QUOTE_CODEPOINT|CLOSE_QUOTE_CODEPOINT){return Ok(synthetic_corner_graphic(run.canonical_codepoints[0],o.font_size));}
    if run.font_role=="literal"{let literal_font=literal_text_font_filename()?;return make_graphic(&run.render_text,&literal_font,o.font_size,&[],0.0,0.0);}
    let filename=if run.font_role=="number"{&font.companion_filename}else{&font.base_filename};let features=if run.font_role=="number"{full_open_type_features_for(o.font_size)}else{vec![]};let pad=if run.font_role=="cartouche"||run.numeric_cartouche{6.0}else{0.0};make_graphic(&run.render_text,filename,o.font_size,&features,pad,0.0)
}

impl NanpaLinjaN{
    pub fn render_to_canvas(&self,input:&str,options:&FullRenderOptions)->Result<FullCanvasResult,RenderError>{let prep=self.prepare_full(input,options)?;let rgba=render_prepared_rgba(&prep)?;Ok(FullCanvasResult{width:prep.plan.width,height:prep.plan.height,rgba,plan:if prep.options.include_plan{Some(prep.plan.clone())}else{None},font_key:prep.plan.font_key.clone()})}
    pub fn render_full_to_png(&self,input:&str,options:&FullRenderOptions)->Result<Vec<u8>,RenderError>{let c=self.render_to_canvas(input,options)?;encode_png_rgba(&c.rgba,c.width,c.height)}
    pub fn render_full_to_svg(&self,input:&str,options:&FullRenderOptions)->Result<String,RenderError>{svg_from_prepared(&self.prepare_full(input,options)?) }
    pub fn render_full_to_pdf(&self,input:&str,options:&FullRenderOptions)->Result<Vec<u8>,RenderError>{vector_pdf(&self.prepare_full(input,options)?) }
    pub fn render_run_to_new_canvas(&self,run:&FullRenderRun,options:&FullRenderOptions)->Result<FullCanvasResult,RenderError>{let o=normalize_options(options.clone());let registry=full_registry()?;let font=registry.get(&o.font).cloned().ok_or_else(||RenderError::UnknownFont(o.font.clone()))?;let g=graphic_for_public_run(run,&font,&o)?;let mut rr=run.clone();rr.id="L0R0".into();rr.line_index=0;rr.run_index=0;rr.x_px=o.padding_px as f64;rr.y_px=o.padding_px as f64;rr.width_px=g.width;rr.height_px=g.height;rr.baseline_y_px=rr.y_px+g.baseline;let width=(g.width+2.0*o.padding_px as f64).ceil().max(1.0)as u32;let height=(g.height+2.0*o.padding_px as f64).ceil().max(1.0)as u32;let plan=FullRenderPlan{input:run.source_text.clone(),font_key:font.key.clone(),width,height,runs:vec![rr.clone()],lines:vec![FullRenderLinePlan{line_index:0,source_line_index:0,sentence_index_in_source_line:0,x_px:rr.x_px,y_px:rr.y_px,width_px:g.width,height_px:g.height,baseline_y_px:rr.baseline_y_px,ascent_px:g.baseline,descent_px:(g.height-g.baseline).max(0.0),runs:vec![rr.clone()]}],..FullRenderPlan::default()};let prep=PreparedFull{plan:plan.clone(),placed:vec![LogicalRun{run:rr,graphic:g}],options:o.clone()};let rgba=render_prepared_rgba(&prep)?;Ok(FullCanvasResult{width,height,rgba,plan:if o.include_plan{Some(plan)}else{None},font_key:font.key})}
    pub fn render_text_to_new_canvas(&self,text:&str,options:&FullRenderOptions)->Result<FullCanvasResult,RenderError>{self.render_to_canvas(text,options)}
    pub fn render_text_to_canvas(&self,target:&mut [u8],target_width:u32,target_height:u32,x:i32,y:i32,text:&str,options:&FullRenderOptions)->Result<FullRenderPlan,RenderError>{let c=self.render_text_to_new_canvas(text,options)?;for yy in 0..c.height as i32{for xx in 0..c.width as i32{let tx=x+xx;let ty=y+yy;if tx<0||ty<0||tx>=target_width as i32||ty>=target_height as i32{continue;}let si=((yy as u32*c.width+xx as u32)*4)as usize;let di=((ty as u32*target_width+tx as u32)*4)as usize;if si+4<=c.rgba.len()&&di+4<=target.len(){let px=[c.rgba[si],c.rgba[si+1],c.rgba[si+2],c.rgba[si+3]];blend(&mut target[di..di+4],px,255);}}}c.plan.ok_or_else(||RenderError::Image("render plan disabled".into()))}
    pub fn render_ucsur_to_new_canvas(&self,lines:&[Vec<u32>],options:&FullRenderOptions)->Result<FullCanvasResult,RenderError>{let text=lines.iter().map(|line|line.iter().filter_map(|cp|char::from_u32(*cp)).collect::<String>()).collect::<Vec<_>>().join("\n");self.render_to_canvas(&text,options)}
    pub fn render_ucsur_to_canvas(&self,target:&mut[u8],target_width:u32,target_height:u32,x:i32,y:i32,lines:&[Vec<u32>],options:&FullRenderOptions)->Result<FullRenderPlan,RenderError>{let text=lines.iter().map(|line|line.iter().filter_map(|cp|char::from_u32(*cp)).collect::<String>()).collect::<Vec<_>>().join("\n");self.render_text_to_canvas(target,target_width,target_height,x,y,&text,options)}
    pub fn to_vector_document(&self,input:&str,options:&FullRenderOptions)->Result<VectorDocument,RenderError>{let prep=self.prepare_full(input,options)?;let mut elements=Vec::new();for l in &prep.placed{let r=&l.run;let g=&l.graphic;if let Some(cp)=g.synthetic_corner_codepoint{let (run_w,run_h,stroke,pad,_lift,arm)=synthetic_corner_geometry(cp,prep.options.font_size);let xl=r.x_px+pad;let xr=r.x_px+run_w-pad;let yt=r.y_px;let yb=yt+run_h;let path=if cp==CLOSE_QUOTE_CODEPOINT{format!("M {:.3} {:.3} L {:.3} {:.3} L {:.3} {:.3}",xr-arm,yb,xr,yb,xr,yt)}else{format!("M {:.3} {:.3} L {:.3} {:.3} L {:.3} {:.3}",xl,yb,xl,yt,xl+arm,yt)};elements.push(VectorElement{kind:"path".into(),run_id:r.id.clone(),path,fill:prep.options.paint.fill_style.clone(),x:r.x_px,y:r.y_px,width:g.width,height:stroke,..VectorElement::default()});}else if !g.image_bytes.is_empty(){elements.push(VectorElement{kind:"image".into(),run_id:r.id.clone(),href:g.image_href.clone(),x:r.x_px,y:r.y_px,width:g.width,height:g.height,..VectorElement::default()});}else{elements.push(VectorElement{kind:"text".into(),run_id:r.id.clone(),text:g.text.clone(),fill:prep.options.paint.fill_style.clone(),x:r.x_px+g.origin_x,y:r.y_px+g.baseline,width:g.width,height:g.height,..VectorElement::default()});}for (cp,lx) in &g.embedded_corners{let (run_w,run_h,_stroke,pad,_lift,arm)=synthetic_corner_geometry(*cp,prep.options.font_size);let x0=r.x_px+*lx;let xl=x0+pad;let xr=x0+run_w-pad;let yt=r.y_px+(r.height_px-run_h).max(0.0)*0.5;let yb=yt+run_h;let path=if *cp==CLOSE_QUOTE_CODEPOINT{format!("M {:.3} {:.3} L {:.3} {:.3} L {:.3} {:.3}",xr-arm,yb,xr,yb,xr,yt)}else{format!("M {:.3} {:.3} L {:.3} {:.3} L {:.3} {:.3}",xl,yb,xl,yt,xl+arm,yt)};elements.push(VectorElement{kind:"path".into(),run_id:r.id.clone(),path,fill:prep.options.paint.fill_style.clone(),x:x0,y:yt,width:run_w,height:run_h,..VectorElement::default()});}for tg in &r.tally_groups{for cx in &tg.stroke_centers_px{elements.push(VectorElement{kind:"path".into(),run_id:r.id.clone(),path:format!("M {:.3} {:.3} L {:.3} {:.3}",cx,tg.top_y_px,cx,tg.bottom_y_px),fill:prep.options.paint.fill_style.clone(),x:*cx,y:tg.top_y_px,width:tg.stroke_width_px,height:tg.bottom_y_px-tg.top_y_px,..VectorElement::default()});}}}Ok(VectorDocument{width:prep.plan.width,height:prep.plan.height,elements,diagnostics:prep.plan.diagnostics.clone(),plan:prep.plan})}
}
