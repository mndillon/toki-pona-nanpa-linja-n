#!/usr/bin/env python3
"""Offline Protocol-v1.1 source/asset validation for the Rust reference."""
import hashlib,json,pathlib,sys,zipfile,re
ROOT=pathlib.Path(__file__).resolve().parents[1]
FAIL=[]; CHECKS=0
def check(ok,msg):
 global CHECKS; CHECKS+=1
 print(('PASS' if ok else 'FAIL'),msg)
 if not ok: FAIL.append(msg)
# Frozen Core source hashes.
core=json.loads((ROOT/'fixtures/core-v1-source-sha256.json').read_text())['files']
for rel,expected in core.items():
 p=ROOT/rel; actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
 check(actual==expected,f'Core source unchanged {rel}')
# Current authorities.
auth={
 'reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js':'fdeb3e3bfd46b9f86650fd411a2d1dfb2515580aa258aa8c11a002913631418c',
 'resources/fonts.zip':'08d0409e0b180a6b90a0617fe557fd3e59a08dd26781d907ed5d772a9fefcae1',
 'conformance/parser-renderer-profile-v1.1.0.json':'009ecab501a57c1b64fd1ff1f9fac50b072aecb706a162970b1f17c0cc45338b',
 'fixtures/production-font-pairs.manifest-v1.1.0.json':'50b8a4b6cab0c27f2061f94e404a2af992cbf95c8097c58caa5e6b2dc4625f09',
}
for rel,expected in auth.items():
 p=ROOT/rel; actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
 check(actual==expected,f'current authority SHA-256 {rel}')
# Font bundle / production manifest.
with zipfile.ZipFile(ROOT/'resources/fonts.zip') as zf:
 names=set(zf.namelist()); raw=zf.read('fonts/preloaded-font-pairs.manifest.json'); manifest=json.loads(raw)
 check(hashlib.sha256(raw).hexdigest()==auth['fixtures/production-font-pairs.manifest-v1.1.0.json'],'embedded production font manifest SHA-256')
 pairs=manifest.get('pairs') or []
 check(len(pairs)==8,'production font manifest has 8 pairs')
 adapters=[]
 for p in pairs:
  adapters.append(p.get('renderAdapterId') or 'identity')
  check(p.get('settings',{}).get('cartoucheVulgarFractions') is True,f"{p.get('fontKey')}: inline vulgar scaling enabled")
  check(p.get('settings',{}).get('emulateLegacyCartoucheScaling') is False,f"{p.get('fontKey')}: legacy scaling disabled")
  for k in ('baseFilename','companionFilename'):
   check('fonts/'+p[k] in names,f"{p.get('fontKey')}: {k} present")
 check(set(adapters)=={'identity','linja-pona-legacy-v1','linja-sike-legacy-v1','nasin-sitelen-pu-mono-v1','linja-lipamanka-v1'},'five production adapter IDs')
# v1.1 fixtures.
for rel,key,want in [
 ('fixtures/font-golden-cases-v1.1.0.json','cases',16),
 ('fixtures/render-facade-plan-goldens-v1.1.0.json','cases',16),
 ('conformance/full-renderer-canonical-v1.1.0/cases.json','cases',254),
]:
 d=json.loads((ROOT/rel).read_text());check(len(d.get(key,[]))==want,f'{rel}: {want} cases')
# Production source invariants.
src='\n'.join((ROOT/'src'/n).read_text() for n in ('facade.rs','font_adapters.rs','full_adapter.rs','full_renderer.rs','full_types.rs','public_parser.rs','v11_numeric.rs'))
check('ss12' not in src and 'ss13' not in src and 'ss14' not in src,'no active ss12/ss13/ss14 production feature strings')
check('ttf-parser = "=0.25.1"' in (ROOT/'Cargo.toml').read_text(),'ttf-parser pinned for vector outlines')
check('/Subtype /Image' not in (ROOT/'src/full_renderer.rs').read_text(),'Rust PDF source has no raster Image XObject')
check('vector_pdf(&self.prepare_full(input,options)?)' in (ROOT/'src/full_renderer.rs').read_text(),'render_full_to_pdf routes to vector PDF')
check('svg_text_paths(&g.text' in (ROOT/'src/full_renderer.rs').read_text(),'numeric SVG emits shaped glyph outline paths')
check('normalize_v11_abbreviated_words' in (ROOT/'src/full_document.rs').read_text(),'astToText uses v1.1 abbreviated normalization')
check('full-renderer-canonical-v1.1.0/cases.json' in (ROOT/'tests/canonical_full_renderer.rs').read_text(),'canonical full-renderer test targets v1.1 corpus')
check("else if c==','{Some(',' as u32)}" in (ROOT/'src/full_renderer.rs').read_text(),'outside-cartouche ASCII comma is preserved')
check("if c==','{logical.run.kind=\"run\".into();}" in (ROOT/'src/full_renderer.rs').read_text(),'outside-cartouche ASCII comma uses canonical run kind')
check('nanpa-linja-n-nasin-nanpa-liberation-sans-literal.ttf' in (ROOT/'src/full_font_registry.rs').read_text() and 'LiberationSans-Regular.ttf' in (ROOT/'src/full_font_registry.rs').read_text(),'literal-cartouche compatibility alias resolves to bundled Liberation Sans')
check('scale_markers: Vec<u32>' in (ROOT/'src/full_adapter.rs').read_text(),'ordinary cartouche carries scale-marker ownership')
for alias in ('"1/4"','"1/3"','"1/2"','"2/3"','"3/4"'):
 check(alias in (ROOT/'src/full_adapter.rs').read_text(),f'ordinary cartouche supports ASCII scale alias {alias}')
print(f'\nsource/asset validation: {CHECKS-len(FAIL)}/{CHECKS} PASS; failures: {len(FAIL)}')
if FAIL: sys.exit(1)
