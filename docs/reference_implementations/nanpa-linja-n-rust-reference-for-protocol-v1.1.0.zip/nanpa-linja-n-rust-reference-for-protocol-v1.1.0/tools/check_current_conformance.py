#!/usr/bin/env python3
import hashlib,json,pathlib,sys
root=pathlib.Path(__file__).resolve().parents[1]
renderer=root/'reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js'
expected='fdeb3e3bfd46b9f86650fd411a2d1dfb2515580aa258aa8c11a002913631418c'
errors=[]
sha=hashlib.sha256(renderer.read_bytes()).hexdigest() if renderer.exists() else None
if sha!=expected: errors.append(f'renderer authority hash got={sha} want={expected}')
checks=[
 ('conformance/canonical-syntax-v1.0.1-phase1/cases.json','cases',28),
 ('conformance/canonical-syntax-v1.0.1-phase1/cases.json','fontAdapterCases',5),
 ('conformance/full-renderer-canonical-v1.1.0/cases.json','cases',254),
 ('conformance/parser-renderer-profile-v1.1.0.json','nanpaParserSmokeCases',16),
]
for rel,key,n in checks:
 p=root/rel
 try:d=json.loads(p.read_text())
 except Exception as e: errors.append(f'{rel}: {e}');continue
 got=len(d.get(key,[]))
 if got!=n: errors.append(f'{rel}:{key} got={got} want={n}')
 auth=d.get('authority')
 if isinstance(auth,dict):
  h=auth.get('sha256') or auth.get('rendererSha256')
  if h and h!=expected: errors.append(f'{rel}: authority sha got={h} want={expected}')
if errors:
 print('Rust current v1.1 conformance authority: FAIL')
 for e in errors: print('FAIL',e)
 sys.exit(1)
print('Rust current v1.1 conformance authority: PASS')
print('renderer sha256:',sha)
print('canonical syntax: 28; adapters: 5; canonical full renderer: 254; NanpaParser smoke: 16')
