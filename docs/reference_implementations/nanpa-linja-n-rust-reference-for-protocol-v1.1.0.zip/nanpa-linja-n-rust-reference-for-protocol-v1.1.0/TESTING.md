# Testing the Rust Protocol-v1.1 reference

From the extracted package root:

```bash
rustc --version
cargo --version
./tools/run_rust_regression.sh
```

The runner attempts every configured suite and writes `test-output/rust-regression-report.txt`.

Useful focused commands:

```bash
cargo check --all-targets
cargo test --lib -- --nocapture
cargo test --test ast_to_text -- --nocapture
cargo test --test canonical_syntax -- --nocapture
cargo test --test canonical_full_renderer -- --nocapture
cargo test --test facade_plan_conformance -- --nocapture
cargo test --test facade_rendering -- --nocapture
cargo test --test v1_1_profile -- --nocapture
```

The v1.1 profile test includes public-default checks, decimal `parseNumber` result shape, mixed-fraction `kin`, whitespace numeric boundaries, ordinary-cartouche inline scale controls, true vector numeric SVG, and PDF rejection of raster Image XObjects.
