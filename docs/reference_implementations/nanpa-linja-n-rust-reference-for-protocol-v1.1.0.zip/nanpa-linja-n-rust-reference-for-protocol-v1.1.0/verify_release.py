#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / 'RELEASE-MANIFEST.json'
EXCLUDED_DIRS = {'target', 'test-output', '__pycache__'}
EXCLUDED_FILES = {'RELEASE-MANIFEST.json'}

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def shipped_files():
    out = []
    for p in ROOT.rglob('*'):
        if not p.is_file():
            continue
        relp = p.relative_to(ROOT)
        rel = relp.as_posix()
        if set(relp.parts[:-1]) & EXCLUDED_DIRS:
            continue
        if p.name.endswith('.pyc') or rel in EXCLUDED_FILES:
            continue
        out.append(rel)
    return sorted(out)

def main() -> int:
    if not MANIFEST.is_file():
        print('FAIL: RELEASE-MANIFEST.json is missing')
        return 1
    data = json.loads(MANIFEST.read_text(encoding='utf-8'))
    expected = data.get('files') or {}
    actual = shipped_files()
    if actual != sorted(expected):
        missing = sorted(set(actual) - set(expected))
        stale = sorted(set(expected) - set(actual))
        print(f'FAIL release file-set mismatch missing-from-manifest={missing} stale={stale}')
        return 1
    failures=[]
    for rel in actual:
        got=sha256(ROOT/rel); want=expected[rel]
        if got != want: failures.append((rel,want,got))
    if failures:
        print(f'FAIL {len(failures)} release file hash mismatch(es)')
        for rel,want,got in failures[:20]: print(f'  {rel}: expected {want}, got {got}')
        return 1
    print(f'PASS {len(actual)}/{len(expected)} shipped files verified')
    print('PASS Rust reference target: 1.1.0')
    print(f"QUALIFICATION: {data.get('qualificationStatus')}")
    return 0

if __name__ == '__main__':
    sys.exit(main())
