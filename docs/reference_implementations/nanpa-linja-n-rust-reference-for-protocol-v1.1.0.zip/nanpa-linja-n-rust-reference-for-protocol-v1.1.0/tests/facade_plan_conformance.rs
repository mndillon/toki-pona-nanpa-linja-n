use nanpa_linja_n_rust::facade::{NanpaLinjaN, RenderOptions};
use serde_json::Value;

const GOLDENS: &str = include_str!("../fixtures/render-facade-plan-goldens-v1.1.0.json");

#[test]
fn facade_render_plans_match_frozen_cross_language_goldens() {
    let nanpa = NanpaLinjaN::create().expect("facade initializes");
    let doc: Value = serde_json::from_str(GOLDENS).expect("valid facade plan goldens");
    let cases = doc["cases"].as_array().expect("cases");
    assert_eq!(cases.len(), 16);

    let fonts = nanpa.list_fonts();
    assert_eq!(fonts.len(), 8);
    let mut checks = 0usize;

    for case in cases {
        let input = case["input"].as_str().unwrap();
        let font_px = case["fontPx"].as_u64().unwrap() as u32;
        let abbreviate = case["abbreviate"].as_bool().unwrap();
        let preserve = case["preserveNumericCartoucheBreaks"].as_bool().unwrap();
        let canonical = case["canonicalCodepoints"]
            .as_array().unwrap().iter().map(|v| v.as_u64().unwrap() as u32).collect::<Vec<_>>();
        let expected_features = case["openTypeFeatures"]
            .as_array().unwrap().iter().map(|v| v.as_str().unwrap().to_string()).collect::<Vec<_>>();
        let per_font = case["perFont"].as_object().expect("perFont");

        for font in &fonts {
            let expected = per_font.get(&font.key).expect("per-font expectation");
            let expected_render = expected["renderCodepoints"]
                .as_array().unwrap().iter().map(|v| v.as_u64().unwrap() as u32).collect::<Vec<_>>();
            let mut options = RenderOptions {
                font: font.key.clone(),
                font_size: font_px,
                abbreviate,
                preserve_numeric_cartouche_breaks: preserve,
                ..RenderOptions::default()
            };
            if input.starts_with('#') { options.parser_options.enable_hex_parsing = true; }
            if input.starts_with("0b") { options.parser_options.enable_binary_parsing = true; }
            let plan = nanpa.build_render_plan(input, &options).unwrap_or_else(|err| {
                panic!("{} / {} failed: {err}", font.key, case["id"])
            });
            assert_eq!(plan.canonical_codepoints, canonical, "{} / {} canonical", font.key, case["id"]);
            assert_eq!(plan.open_type_features, expected_features, "{} / {} features", font.key, case["id"]);
            assert_eq!(plan.render_adapter_id, expected["renderAdapterId"].as_str().unwrap());
            assert_eq!(plan.render_text, expected["renderText"].as_str().unwrap(), "{} / {} render text", font.key, case["id"]);
            assert_eq!(plan.render_codepoints, expected_render, "{} / {} render cps", font.key, case["id"]);
            assert_eq!(plan.legacy_ascii, expected["legacyAdapter"].as_bool().unwrap());
            checks += 1;
        }
    }
    assert_eq!(checks, 128);
    println!("Rust facade render-plan conformance: 128/128 PASS");
}
