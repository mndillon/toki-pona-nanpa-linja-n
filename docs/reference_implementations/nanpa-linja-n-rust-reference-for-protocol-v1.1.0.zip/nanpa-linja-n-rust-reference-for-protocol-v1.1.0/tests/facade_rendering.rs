use nanpa_linja_n_rust::facade::{NanpaLinjaN, RenderOptions};
use serde_json::Value;

const CASES: &str = include_str!("../fixtures/font-golden-cases-v1.1.0.json");

#[test]
fn facade_exposes_all_production_fonts() {
    let nanpa = NanpaLinjaN::create().expect("facade initializes");
    let fonts = nanpa.list_fonts();
    assert_eq!(fonts.len(), 8);
    let keys = fonts.iter().map(|f| f.key.as_str()).collect::<Vec<_>>();
    for key in [
        "nasinNanpa",
        "sitelenSeliKiwen",
        "fairfaxHd",
        "fairfaxPonaHd",
        "linjaPona",
        "linjaSike",
        "nasinSitelenPuMono",
        "linjaLipamanka",
    ] {
        assert!(keys.contains(&key), "missing production font {key}");
    }
    assert_eq!(nanpa.get_font_info("linja-pona").unwrap().key, "linjaPona");
}

#[test]
fn legacy_font_is_adapted_automatically() {
    let nanpa = NanpaLinjaN::create().unwrap();
    let options = RenderOptions {
        font: "linjaPona".to_string(),
        ..RenderOptions::default()
    };
    let plan = nanpa.build_render_plan("2026-09-13", &options).unwrap();
    assert_eq!(plan.render_adapter_id, "linja-pona-legacy-v1");
    assert!(plan.legacy_ascii);
    assert!(plan.render_codepoints.iter().all(|cp| *cp < 128));
    assert!(plan.render_text.starts_with('['));
    assert!(plan.render_text.ends_with(']'));
    assert_ne!(plan.render_codepoints, plan.canonical_codepoints);
}

#[test]
fn png_and_svg_convenience_outputs_are_valid() {
    let nanpa = NanpaLinjaN::create().unwrap();
    let png = nanpa.render_to_png("123.45", &RenderOptions::default()).unwrap();
    assert!(png.starts_with(&[137, 80, 78, 71, 13, 10, 26, 10]));

    let svg = nanpa.render_to_svg("12:30", &RenderOptions::default()).unwrap();
    assert!(svg.svg.starts_with("<svg"));
    assert!(svg.svg.contains("@font-face"));
    assert!(svg.svg.contains("data:font/ttf;base64,"));
    assert!(svg.width > 0 && svg.height > 0);
}

#[test]
fn production_font_matrix_renders_all_128_cases() {
    let nanpa = NanpaLinjaN::create().unwrap();
    let doc: Value = serde_json::from_str(CASES).expect("valid font case fixture");
    let cases = doc["cases"].as_array().expect("font cases");
    assert_eq!(cases.len(), 16);
    let fonts = nanpa.list_fonts();
    assert_eq!(fonts.len(), 8);

    let mut rendered = 0usize;
    for font in fonts {
        for case in cases {
            let input = case["input"].as_str().expect("case input");
            let font_px = case["fontPx"].as_u64().expect("fontPx") as u32;
            let abbreviate = case["abbreviateNumericCartouches"].as_bool().unwrap_or(false);
            let preserve = case["preserveNumericCartoucheBreaksInAbbreviation"]
                .as_bool()
                .unwrap_or(true);
            let mut options = RenderOptions {
                font: font.key.clone(),
                font_size: font_px,
                abbreviate,
                preserve_numeric_cartouche_breaks: preserve,
                ..RenderOptions::default()
            };
            if input.starts_with('#') { options.parser_options.enable_hex_parsing = true; }
            if input.starts_with("0b") { options.parser_options.enable_binary_parsing = true; }
            let result = nanpa.render(input, &options).unwrap_or_else(|err| {
                panic!("{} / {} failed: {err}", font.key, case["id"])
            });
            assert!(result.width() > 0 && result.height() > 0);
            assert!(result.image.rgba.chunks_exact(4).any(|px| px[3] != 0));
            if font.render_adapter_id == "linja-pona-legacy-v1"
                || font.render_adapter_id == "linja-sike-legacy-v1"
            {
                // v1.1 render_text may contain inline ¼/⅓/½/⅔/¾ scale
                // controls, while render_codepoints remain the adapted ASCII
                // glyph stream consumed by the legacy fonts.
                assert!(result.plan.render_codepoints.iter().all(|cp| *cp < 128));
            }
            rendered += 1;
        }
    }
    assert_eq!(rendered, 128);
    println!("Rust production-font facade: 128/128 render cases PASS");
}
