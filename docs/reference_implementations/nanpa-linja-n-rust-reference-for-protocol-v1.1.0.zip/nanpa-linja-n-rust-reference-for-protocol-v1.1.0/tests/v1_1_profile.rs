use nanpa_linja_n_rust::facade::{NanpaLinjaN, RenderOptions};
use nanpa_linja_n_rust::{default_public_parse_options, FullRenderOptions};

#[test]
fn public_v1_1_defaults_and_parse_number_shape() {
    let opts = default_public_parse_options();
    assert!(!opts.enable_hex_parsing);
    assert!(!opts.enable_binary_parsing);
    assert!(opts.relaxed_nanpa_linjan_parsing);
    assert!(opts.relaxed_nanpa_linjan_rendering);
    assert!(opts.nanpa_colon_parsing);
    assert!(opts.nanpa_colon_rendering);
    assert!(opts.abbreviate_numeric_cartouches);
    assert!(!opts.preserve_numeric_cartouche_breaks_in_abbreviation);

    let nanpa = NanpaLinjaN::create().expect("facade");
    let parsed = nanpa.parse_number("123").expect("public decimal parseNumber");
    assert_eq!(parsed.proper_name, "Nanpa Watusen");
    assert_eq!(parsed.unique_code, "#~WTS");
    assert!(parsed.abbreviated_words.is_none());
    assert!(parsed.abbreviated_ucsur_codepoints.is_none());
    assert!(parsed.nasin_nanpa_pona_words.is_none());

    let render = RenderOptions::default();
    assert!(render.abbreviate);
    assert!(!render.preserve_numeric_cartouche_breaks);
    assert!(!render.parser_options.enable_hex_parsing);
    assert!(!render.parser_options.enable_binary_parsing);
}

#[test]
fn yearless_date_public_profile_uses_kasi_separator() {
    let nanpa = NanpaLinjaN::create().expect("facade");
    let parsed = nanpa.parse_number("--02-29").expect("yearless date");
    assert!(parsed.is_date);
    assert_eq!(
        parsed.tp_words,
        vec![
            "suno", ":", "nena", "ijo", "tu", "uta", "nena", "e",
            "kasi", "e", "tu", "uta", "jo", "open", "nanpa",
        ]
        .into_iter()
        .map(str::to_owned)
        .collect::<Vec<_>>()
    );
    assert!(!parsed.tp_words.iter().any(|word| word == "kulupu"));
}

#[test]
fn full_renderer_v1_1_defaults_are_public_defaults() {
    let opts = FullRenderOptions::default();
    assert!(opts.parser.abbreviate_numeric_cartouches);
    assert!(!opts.parser.preserve_numeric_cartouche_breaks);
    assert!(!opts.parser.enable_hex_parsing);
    assert!(!opts.parser.enable_binary_parsing);
    assert!(!opts.parser.enable_binary_rendering);
    assert!(opts.parser.relaxed_nanpa_linjan_parsing);
    assert!(opts.parser.relaxed_nanpa_linjan_rendering);
}

#[test]
fn mixed_fraction_abbreviation_keeps_semantic_kin() {
    let nanpa = NanpaLinjaN::create().expect("facade");
    let ast = nanpa.parse_input("1+1/2", &FullRenderOptions::default());
    let mut opts = FullRenderOptions::default();
    opts.numeric_output = "cartouche".into();
    opts.parser.abbreviate_numeric_cartouches = true;
    opts.parser.preserve_numeric_cartouche_breaks = true;
    let text = nanpa.ast_to_text_with_options(&ast, &opts).expect("astToText");
    assert_eq!(text, "[nanpa : wan kin wan o o tu nanpa]");
}

#[test]
fn whitespace_stops_numeric_constructs() {
    let nanpa = NanpaLinjaN::create().expect("facade");
    let plan = nanpa.build_full_render_plan("8 1/2", &FullRenderOptions::default()).expect("full plan");
    let numeric = plan.runs.iter().filter(|run| run.numeric_cartouche).count();
    assert_eq!(numeric, 2, "8 1/2 must be two numeric constructs");
}

#[test]
fn ordinary_cartouche_inline_scale_aliases_are_render_only_controls() {
    let nanpa = NanpaLinjaN::create().expect("facade");
    let plan = nanpa.build_full_render_plan("[jan1/2 pona⅔]", &FullRenderOptions::default()).expect("ordinary cartouche plan");
    let run = plan.runs.iter().find(|run| run.font_role == "cartouche").expect("cartouche run");
    assert!(run.render_text.contains('½'));
    assert!(run.render_text.contains('⅔'));
    assert!(!run.render_codepoints.contains(&('½' as u32)));
    assert!(!run.render_codepoints.contains(&('⅔' as u32)));
}

#[test]
fn outside_cartouche_comma_is_preserved_as_ascii_word_run() {
    let nanpa = NanpaLinjaN::create().expect("facade");
    let plan = nanpa
        .build_full_render_plan("jan. pona· mi: toki,", &FullRenderOptions::default())
        .expect("punctuation plan");
    let comma = plan
        .runs
        .iter()
        .find(|run| run.source_text == ",")
        .expect("trailing comma run");
    assert_eq!(comma.font_role, "word");
    assert_eq!(comma.canonical_codepoints, vec![',' as u32]);
    assert_eq!(comma.render_codepoints, vec![',' as u32]);
}

#[test]
fn numeric_svg_and_pdf_are_vector_outputs() {
    let nanpa = NanpaLinjaN::create().expect("facade");
    let opts = FullRenderOptions::default();
    let svg = nanpa.render_full_to_svg("123.45", &opts).expect("SVG");
    assert!(svg.starts_with("<svg"));
    assert!(svg.contains("<path"), "numeric SVG must contain shaped glyph paths");
    assert!(!svg.contains("<image"));
    assert!(!svg.contains("data:image"));

    let pdf = nanpa.render_full_to_pdf("123.45", &opts).expect("PDF");
    assert!(pdf.starts_with(b"%PDF-"));
    let text = String::from_utf8_lossy(&pdf);
    assert!(!text.contains("/Subtype /Image"), "generated numeric PDF must not rasterize cartouches");
}
