mod support;
use nanpa_linja_n_rust::facade::NanpaLinjaN;
use serde_json::Value;
use std::fs;

#[test]
fn canonical_full_renderer_semantics(){
    let root:Value=serde_json::from_str(&fs::read_to_string("conformance/full-renderer-canonical-v1.1.0/cases.json").unwrap()).unwrap();let cases=support::array(&root["cases"]);assert_eq!(root["caseCount"].as_u64().unwrap() as usize,cases.len());let n=NanpaLinjaN::create().unwrap();let mut errors=Vec::new();let mut passed=0usize;
    for c in cases{let id=c["id"].as_str().unwrap();let before=errors.len();let oracle=&c["oracle"];if oracle["ok"].as_bool()!=Some(true){errors.push(format!("{id}: oracle not successful"));continue;}let o=support::options(c["font"].as_str().unwrap_or("nasinNanpa"),&c["parser"]);match n.build_full_render_plan(c["input"].as_str().unwrap(),&o){Ok(plan)=>{if c["compareAst"].as_bool()==Some(true){support::compare_ast(&plan.ast,&oracle["ast"],&mut errors,id);}let want=support::array(&oracle["runs"]);let got=support::flatten(&plan);if got.len()!=want.len(){errors.push(format!("{id}: run count got={} want={}",got.len(),want.len()));}else{let random=c.get("randomCps").and_then(Value::as_bool).unwrap_or(false);for (i,(g,w)) in got.iter().zip(want).enumerate(){support::compare_run(g,w,&mut errors,id,i,random);}}},Err(e)=>errors.push(format!("{id}: build threw {e}"))}if errors.len()==before{passed+=1;}}
    println!("Rust canonical full-renderer semantic corpus: {passed}/{} {}",cases.len(),if errors.is_empty(){"PASS"}else{"FAIL"});if !errors.is_empty(){panic!("canonical full renderer failures ({}):\n{}",errors.len(),errors.join("\n"));}
}
