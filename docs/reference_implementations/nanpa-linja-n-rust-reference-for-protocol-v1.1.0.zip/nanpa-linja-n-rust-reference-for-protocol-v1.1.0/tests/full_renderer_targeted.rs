use nanpa_linja_n_rust::facade::NanpaLinjaN;
use nanpa_linja_n_rust::{FullRenderOptions, TALLY_CODEPOINT};

#[test]
fn targeted_full_renderer_regressions() {
    // Keep these focused regressions in one integration-test process.  The
    // bundled font ZIP is process-cached, so this preserves the same coverage
    // without paying font-bundle initialization once per source file.
    let nanpa = NanpaLinjaN::create().expect("facade initializes");

    // Explicit positive decimal.
    let mut options = FullRenderOptions::default();
    options.parser.abbreviate_numeric_cartouches = false;
    let plan = nanpa
        .build_full_render_plan("+123.45", &options)
        .expect("explicit-positive full render plan");
    assert_eq!(plan.lines.len(), 1);
    assert_eq!(plan.lines[0].runs.len(), 1);
    assert_eq!(
        plan.lines[0].runs[0].canonical_codepoints,
        vec![
            989501, 989597, 989504, 989450, 989555, 989442, 989550, 989552, 989527,
            989449, 989504, 989508, 989504, 989449, 989504, 989448, 989485, 989552, 989501,
        ]
    );

    // Abbreviated decimal.
    let mut options = FullRenderOptions::default();
    options.parser.abbreviate_numeric_cartouches = true;
    let plan = nanpa
        .build_full_render_plan("123.45", &options)
        .expect("abbreviated full render plan");
    assert!(plan.abbreviated);
    assert_eq!(plan.lines.len(), 1);
    assert_eq!(plan.lines[0].runs.len(), 1);
    assert_eq!(
        plan.lines[0].runs[0].canonical_codepoints,
        vec![989501, 989597, 989555, 989550, 989527, 989508, 989448, 989485, 989501]
    );

    // Traditional mode.
    let mut options = FullRenderOptions::default();
    options.parser.abbreviate_numeric_cartouches = false;
    options.parser.numeric_mode = "traditional".into();
    options.parser.relaxed_nanpa_linjan_parsing = false;
    options.parser.relaxed_nanpa_linjan_rendering = false;
    let plan = nanpa
        .build_full_render_plan("123.45", &options)
        .expect("traditional full render plan");
    assert_eq!(plan.lines.len(), 1);
    assert_eq!(plan.lines[0].runs.len(), 1);
    assert_eq!(
        plan.lines[0].runs[0].canonical_codepoints,
        vec![989501,989597,989555,989451,989550,989451,989527,989451,989505,989508,989502,989449,989502,989448,989485,989451,989501]
    );

    // Production tally routing.
    let mut manual = 0usize;
    let mut ucsur = 0usize;
    for info in nanpa.list_full_fonts().expect("font registry") {
        let mut options = FullRenderOptions::default();
        options.font = info.key.clone();
        options.font_size = 56.0;
        let plan = nanpa
            .build_full_render_plan("[jan pona,,]", &options)
            .expect("tally plan");
        assert_eq!(plan.lines.len(), 1, "{} line count", info.key);
        assert_eq!(plan.lines[0].runs.len(), 1, "{} run count", info.key);
        let run = &plan.lines[0].runs[0];
        if run.tally_groups.is_empty() {
            ucsur += 1;
            assert!(
                run.render_codepoints.contains(&TALLY_CODEPOINT),
                "{} must retain UCSUR tally",
                info.key
            );
        } else {
            manual += 1;
            assert!(
                !run.render_codepoints.contains(&TALLY_CODEPOINT),
                "{} must not shape U+F199E",
                info.key
            );
            assert_eq!(run.manual_tallies, vec![0, 2], "{} manual tally ownership", info.key);
            assert_eq!(run.tally_groups.len(), 1, "{} tally group count", info.key);
            let group = &run.tally_groups[0];
            assert_eq!(group.owner_index, 1, "{} tally owner", info.key);
            assert_eq!(group.count, 2, "{} tally count", info.key);
            assert!(
                (group.center_x_px - (group.owner_left_px + group.owner_right_px) / 2.0).abs() <= 0.05,
                "{} tally center must be owner-centered",
                info.key
            );
        }
    }
    assert_eq!(manual, 4, "manual-tally font count");
    assert_eq!(ucsur, 4, "UCSUR-tally font count");

    // Long mixed-fraction style.
    let mut options = FullRenderOptions::default();
    options.parser.abbreviate_numeric_cartouches = false;
    options.parser.mixed_style = "long".to_string();
    let plan = nanpa
        .build_full_render_plan("8+1/2", &options)
        .expect("mixed-style full render plan");
    assert_eq!(plan.lines.len(), 1);
    assert_eq!(plan.lines[0].runs.len(), 1);
    assert_eq!(
        plan.lines[0].runs[0].canonical_codepoints,
        vec![
            989501, 989597, 989521, 989453, 989504, 989508, 989504, 989508, 989504,
            989508, 989555, 989442, 989504, 989508, 989504, 989508, 989550, 989552,
            989501,
        ]
    );

    // Decimal start-glyph overrides.
    for (name, expected_head) in [
        ("tenpo", 989547u32),
        ("suno", 989540u32),
        ("toki", 989548u32),
    ] {
        let mut options = FullRenderOptions::default();
        options.parser.abbreviate_numeric_cartouches = false;
        options.parser.numeric_cartouche_start_glyph = Some(name.to_string());
        let plan = nanpa
            .build_full_render_plan("123.45", &options)
            .expect("start-glyph full render plan");
        assert_eq!(plan.lines.len(), 1, "{name}");
        assert_eq!(plan.lines[0].runs.len(), 1, "{name}");
        let cps = &plan.lines[0].runs[0].canonical_codepoints;
        assert_eq!(cps.first().copied(), Some(expected_head), "{name}");
        assert_eq!(
            cps,
            &vec![
                expected_head, 989597, 989555, 989442, 989550, 989552, 989527, 989449,
                989504, 989508, 989504, 989449, 989504, 989448, 989485, 989552, 989501,
            ],
            "{name}"
        );
    }
}
