# Rust reference — Protocol v1.1.0

- Targets nanpa-linja-n Protocol v1.1.0 while retaining frozen Core-v1 source hashes.
- Public defaults: relaxed/uniform/Nanpa-colon enabled; numeric abbreviation enabled; break preservation, hex, and binary disabled by default.
- Adds the v1.1 public `parse_number` facade shape without changing frozen Core parsing APIs.
- Adds v1.1 mixed/fraction abbreviation normalization (`kin`, `o o`).
- Installs the exact current canonical JavaScript, parser-renderer profile, production-font manifest, and supplied `fonts.zip`.
- Uses the five current production adapter IDs across eight font pairs.
- Removes automatic `ss12`/`ss13`/`ss14` production scaling.
- Adds inline vulgar-fraction scale controls to numeric and ordinary cartouches, with approved ASCII aliases for ordinary cartouches.
- Updates the production render-plan oracle to the 128 per-font v1.1 expectations.
- Adds vector glyph-outline PDF output; generated text/cartouche PDF content does not use raster Image XObjects.
- Adds a Protocol-v1.1 regression suite covering defaults, mixed fractions, whitespace boundaries, scale controls, SVG paths, and vector PDF.
- Runtime qualification follow-up fixes: resolve the manifest-only literal-cartouche alias to the byte-identical bundled Liberation Sans donor; preserve outside-cartouche comma as canonical `kind: run`; update targeted regression expectations for v1.1 abbreviation defaults, 4/4 tally split, and inline scale markers.
