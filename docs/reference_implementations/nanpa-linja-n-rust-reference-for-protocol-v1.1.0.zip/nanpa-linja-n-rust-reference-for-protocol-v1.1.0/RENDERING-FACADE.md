# Rust production rendering facade — Protocol v1.1.0

`NanpaLinjaN` provides numeric and full-document production rendering over the frozen Core-v1 parser.

The default `RenderOptions` and `FullRenderOptions` use Protocol-v1.1 public defaults: abbreviated numeric cartouches on, preserve-breaks off, relaxed parsing/rendering on, Nanpa-colon parsing/rendering on, and hex/binary off until explicitly requested.

The production font registry is read from bundled `resources/fonts.zip`; callers select a font key such as `nasinNanpa` or `linjaPona` and do not need to manage adapter syntax themselves.

Production OpenType features are `calt`, `liga`, and `ccmp`. Legacy automatic `ss12`, `ss13`, and `ss14` switching is not used. Where the manifest opts in, cartouche scale controls are encoded inline with `¼`, `⅓`, `½`, `⅔`, and `¾`.

`render_to_png` / `render_full_to_png` return raster PNG. `render_full_to_svg` retains vector text and emits shaped numeric glyph paths. `render_full_to_pdf` emits shaped font outlines directly into PDF path geometry; it does not rasterize generated text/cartouches.
