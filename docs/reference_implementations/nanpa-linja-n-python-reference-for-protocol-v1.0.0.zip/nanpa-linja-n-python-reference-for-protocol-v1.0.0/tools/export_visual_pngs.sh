#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
OUT="${1:-$ROOT/test-output}"; mkdir -p "$OUT"
python3 tools/visual_export.py numeric "$OUT"
python3 tools/finish_numeric_visuals.py "$OUT"
