#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
CASES=ROOT/'tools'/'ordinary-cartouche-audit-cases.json'

def numeric(out):
    from nanpa_linja_n.facade import NanpaLinjaN
    n=NanpaLinjaN(project_root=ROOT)
    out.mkdir(parents=True,exist_ok=True); written=0
    for f in n.list_fonts():
        for abbr,suffix in ((False,'full'),(True,'abbreviated')):
            data=n.render_to_png('123.45',font=f.key,font_size=56,abbreviate=abbr,outer_padding=4)
            path=out/f'{f.key}-{suffix}.png'; path.write_bytes(data)
            if path.stat().st_size <= 100: raise RuntimeError(f'suspiciously small PNG: {path}')
            written+=1
    print(f'Python visual PNG export: {written} base PNG file(s) written to {out.resolve()}')

def ordinary(out):
    """Export ordinary-cartouche audit images through the production full renderer.

    Manual tallies are produced by FullRenderer itself.  This intentionally does
    not use the old audit-only tally post-processor: the audit must exercise the
    same tally ownership/placement path applications use.
    """
    from nanpa_linja_n.facade import NanpaLinjaN
    cases=json.loads(CASES.read_text(encoding='utf-8'))
    n=NanpaLinjaN(project_root=ROOT)
    out.mkdir(parents=True,exist_ok=True); written=0
    for key in cases:
        variants=(
            ('ordinary-cartouche','[jan pona]',False),
            ('ordinary-cartouche-halo-red','[jan pona]',True),
            ('ordinary-cartouche-tallies','[jan pona,,]',False),
            ('ordinary-cartouche-tallies-halo-red','[jan pona,,]',True),
        )
        for suffix,text,halo in variants:
            options={'font':key,'fontSize':56}
            if halo:
                options['paint']={'halo':{'enabled':True,'color':'#D91E18','widthPx':6}}
            data=n.render_full_to_png(text,options)
            path=out/f'{key}--{suffix}.png'; path.write_bytes(data)
            if path.stat().st_size <= 100: raise RuntimeError(f'suspiciously small PNG: {path}')
            written+=1
    print(f'Python production ordinary-cartouche audit export: {written} PNG file(s) written to {out.resolve()}')
    print('Manual-tally audit images use FullRenderer production geometry; no audit-only tally post-processing is applied.')

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('mode',choices=['numeric','ordinary']); ap.add_argument('output')
    a=ap.parse_args(); out=Path(a.output).resolve()
    if a.mode=='numeric': numeric(out)
    else: ordinary(out)
if __name__=='__main__': main()
