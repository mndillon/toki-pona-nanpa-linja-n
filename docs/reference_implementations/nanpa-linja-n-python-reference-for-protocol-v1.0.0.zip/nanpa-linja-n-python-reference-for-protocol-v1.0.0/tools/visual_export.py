#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, shutil, tempfile, sys
from pathlib import Path
from PIL import ImageFont

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
MANIFEST=ROOT/'fonts'/'preloaded-font-pairs.manifest.json'
CASES=ROOT/'tools'/'ordinary-cartouche-audit-cases.json'

def font_dir() -> Path:
    raw=os.environ.get('NANPA_FONT_DIR','').strip()
    if not raw: raise SystemExit('ERROR: set NANPA_FONT_DIR to the production font directory')
    p=Path(raw).expanduser().resolve()
    if not p.is_dir(): raise SystemExit(f'ERROR: NANPA_FONT_DIR is not a directory: {p}')
    return p

def required_pairs(doc):
    for p in doc['pairs']:
        yield p['fontKey'],p['baseFilename'],p['companionFilename']

def check_fonts(fd,doc):
    missing=[]
    for _,base,comp in required_pairs(doc):
        for name in (base,comp):
            if not (fd/name).is_file(): missing.append(name)
    if missing: raise SystemExit('ERROR: NANPA_FONT_DIR is missing: '+', '.join(sorted(set(missing))))

def prepare_asset_root(fd: Path, doc: dict):
    td=tempfile.TemporaryDirectory(prefix='nanpa-python-fonts-')
    root=Path(td.name); (root/'fonts').mkdir()
    (root/'fonts'/'preloaded-font-pairs.manifest.json').write_text(json.dumps(doc),encoding='utf-8')
    for pair in doc['pairs']:
        for field in ('baseFilename','companionFilename','literalCartoucheFilename'):
            name=str(pair.get(field) or '').strip()
            dst=root/'fonts'/name
            if name and (fd/name).exists() and not dst.exists(): os.symlink(fd/name,dst)
    return td,root

def numeric(fd, out):
    from nanpa_linja_n.facade import NanpaLinjaN
    doc=json.loads(MANIFEST.read_text(encoding='utf-8')); check_fonts(fd,doc)
    td,root=prepare_asset_root(fd,doc)
    try:
        n=NanpaLinjaN(project_root=root,manifest_path=root/'fonts'/'preloaded-font-pairs.manifest.json')
        out.mkdir(parents=True,exist_ok=True); written=0
        for f in n.list_fonts():
            for abbr,suffix in ((False,'full'),(True,'abbreviated')):
                data=n.render_to_png('123.45',font=f.key,font_size=56,abbreviate=abbr,outer_padding=4)
                path=out/f'{f.key}-{suffix}.png'; path.write_bytes(data)
                if path.stat().st_size <= 100: raise RuntimeError(f'suspiciously small PNG: {path}')
                written+=1
        print(f'Python visual PNG export: {written} base PNG file(s) written to {out.resolve()}')
    finally: td.cleanup()

def ordinary(fd,out):
    """Export ordinary-cartouche audit images through the production full renderer.

    Manual tallies are produced by FullRenderer itself.  This intentionally does
    not use the old audit-only tally post-processor: the audit must exercise the
    same tally ownership/placement path applications use.
    """
    from nanpa_linja_n.facade import NanpaLinjaN
    doc=json.loads(MANIFEST.read_text(encoding='utf-8')); cases=json.loads(CASES.read_text(encoding='utf-8')); check_fonts(fd,doc)
    td,root=prepare_asset_root(fd,doc)
    try:
        n=NanpaLinjaN(project_root=root,manifest_path=root/'fonts'/'preloaded-font-pairs.manifest.json')
        out.mkdir(parents=True,exist_ok=True); written=0
        for key in cases:
            variants=(
                ('ordinary-cartouche','[jan pona]',False),
                ('ordinary-cartouche-halo-red','[jan pona]',True),
                ('ordinary-cartouche-tallies','[jan pona,,]',False),
                ('ordinary-cartouche-tallies-halo-red','[jan pona,,]',True),
            )
            for suffix,text,halo in variants:
                options={'font':key,'fontSize':56}
                if halo:
                    options['paint']={'halo':{'enabled':True,'color':'#D91E18','widthPx':6}}
                data=n.render_full_to_png(text,options)
                path=out/f'{key}--{suffix}.png'; path.write_bytes(data)
                if path.stat().st_size <= 100: raise RuntimeError(f'suspiciously small PNG: {path}')
                written+=1
        print(f'Python production ordinary-cartouche audit export: {written} PNG file(s) written to {out.resolve()}')
        print('Manual-tally audit images use FullRenderer production geometry; no audit-only tally post-processing is applied.')
    finally: td.cleanup()

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('mode',choices=['numeric','ordinary']); ap.add_argument('output')
    a=ap.parse_args(); fd=font_dir(); out=Path(a.output).resolve()
    if a.mode=='numeric': numeric(fd,out)
    else: ordinary(fd,out)
if __name__=='__main__': main()
