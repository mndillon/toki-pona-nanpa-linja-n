#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
OUT="${1:-$ROOT/test-output/cartouche-audit}"; mkdir -p "$OUT"
python3 tools/visual_export.py ordinary "$OUT"
python3 tools/make_cartouche_contacts.py "$OUT"
