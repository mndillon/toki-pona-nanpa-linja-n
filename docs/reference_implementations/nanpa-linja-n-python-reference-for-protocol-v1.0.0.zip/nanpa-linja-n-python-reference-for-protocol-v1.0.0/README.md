# nanpa-linja-n Python reference implementation

Native Python reference implementation for **nanpa-linja-n Protocol v1.0.0**, qualified for parser and full-renderer semantic compatibility with the bundled canonical JavaScript reference.

The Python implementation does not execute or embed JavaScript at runtime. The canonical JavaScript renderer is retained in `reference/` as the behavioral oracle used by qualification tests. The current qualification uses the same **254-case canonical full-renderer corpus** and canonical syntax coverage used to qualify the Go reference implementation.

## Full renderer API

`NanpaLinjaN` now exposes the complete document-rendering surface used by the Full Renderer Profile:

```python
from pathlib import Path
from nanpa_linja_n import NanpaLinjaN

nanpa = NanpaLinjaN.create()

plan = nanpa.build_full_render_plan(
    'mi toki e ni: [jan pona,,] 123.45 "Hello"'
)

canvas = nanpa.render_to_canvas('jan [pona,,] 123.45')
Path('mixed.png').write_bytes(nanpa.render_full_to_png('jan [pona,,] 123.45'))
Path('mixed.svg').write_text(nanpa.render_to_svg('jan [pona,,] 123.45'))
Path('mixed.pdf').write_bytes(nanpa.render_to_pdf('jan [pona,,] 123.45'))
```

The full renderer supports:

- document AST/source segmentation and multiline input;
- ordinary sitelen pona words and mixed inline rendering;
- ordinary cartouches;
- automatic standalone proper-name cartouches;
- literal and interpreted quotes;
- raw UCSUR input and renderer text aliases;
- numeric/date/time/telephone/hex/binary cartouches;
- full and abbreviated numeric forms;
- all eight production font pairs and their manifest-selected adapters;
- manual and UCSUR tally modes;
- unknown-text display/decorations;
- inline images;
- alignment and spacing controls;
- halo/fill paint controls;
- Pillow canvas rendering and PNG;
- native vector-path SVG;
- vector PDF through CairoSVG;
- vector-document conversion;
- low-level run/text/UCSUR rendering;
- runtime render-adapter registration.

JavaScript-style aliases are also available on `NanpaLinjaN`, including `parseInput`, `astToText`, `parseNumber`, `buildRenderPlan`, `renderToCanvas`, `renderToPng`, `renderToSvg`, `renderToPdf`, `toVectorDocument`, `renderRunToNewCanvas`, `renderTextToNewCanvas`, `renderTextToCanvas`, `renderUcsurToNewCanvas`, and `renderUcsurToCanvas`.

### Editing a parsed document with `ast_to_text()`

Python exposes the AST serializer as the idiomatic `ast_to_text()` method/function, with `NanpaLinjaN.astToText()` provided as the JavaScript-style alias. This supports the same parse -> edit AST -> source text -> normal renderer workflow without changing the existing renderer path.

```python
from dataclasses import replace
from nanpa_linja_n import NanpaLinjaN

nanpa = NanpaLinjaN.create()
ast = nanpa.parse_input('jan   pona [ jan  pona,, ]')

line = ast.lines[0]
children = list(line.children)
index = next(i for i, segment in enumerate(children) if segment.kind == 'bracket')
children[index] = replace(children[index], value=' jan  suno,, ')

edited_ast = replace(
    ast,
    lines=(replace(line, children=tuple(children)),),
)

edited_text = nanpa.ast_to_text(edited_ast)
png = nanpa.render_full_to_png(edited_text, {"font": "linjaPona"})
```

`ast_to_text()` now also accepts the same explicit numeric text-output selector used by the JavaScript reference. The default remains source-preserving:

```python
ast = nanpa.parse_input("mi jo e 123")

assert nanpa.ast_to_text(ast, {"numericOutput": "source"}) == "mi jo e 123"
assert nanpa.ast_to_text(ast, {"numericOutput": "properName"}) == "mi jo e Nanpa Watusen"
assert nanpa.ast_to_text(ast, {"numericOutput": "#~"}) == "mi jo e #~WTS"
assert nanpa.ast_to_text(ast, {
    "numericOutput": "cartouche",
    "parser": {"abbreviateNumericCartouches": True},
}) == "mi jo e [nanpa : wan tu seli nanpa]"
assert nanpa.ast_to_text(ast, {
    "numericOutput": "cartouche",
    "parser": {"nasinNanpaPona": True},
}) == "mi jo e wan ale mute tu wan"
```

The allowed values are `source`, `properName`, `#~`, and `cartouche`. Existing numeric formatting flags continue to control the selected representation. If the requested representation is unavailable (for example `#~` for hexadecimal or binary input), the exact original numeric source is preserved. `parse_input()` keeps the established AST segment kinds and attaches optional `DocumentSegment.numeric_structures` metadata for recognized numeric spans.

The AST records are frozen dataclasses, so use `dataclasses.replace()` rather than mutating them in place. The application-editable content is primarily:

- `DocumentSegment.value` for `text`, `bracket`, and `quote` segments;
- `DocumentSegment.open_quote` and `close_quote` for quote delimiters;
- `DocumentSegment.image` and its `src`, `w`, `h`, `alt`, `valign`, `wriggle`, and `transparent` fields.

`source_start`, `source_end`, `DocumentLine.source_text`, and `DocumentAst.normalized_input` are source/diagnostic metadata; `ast_to_text()` serializes the current segment values rather than those stale originals. `DocumentLine.source_line_index` is used to reconstruct physical newlines when `breakLinesAtFullStops` split one source line into multiple AST lines. Exact original `img(...)` argument formatting is not retained, so image nodes are emitted in a canonical equivalent form. Parser normalization (for example CRLF -> LF or text aliases) can also prevent byte-for-byte reconstruction of the original input.

### Public `parseNumber()` parity API

The existing low-level `parse_number()` function and `NanpaParser.parseNumber()` remain unchanged. For cross-language facade parity, Python now also exposes a public `parseNumber()` wrapper and `NanpaLinjaN.parseNumber()` / `NanpaLinjaN.parse_number()` methods. These use the facade's established default parser profile and expose the alternative numeric representations needed by `ast_to_text()`, including `abbreviatedWords`, `abbreviatedUcsurCodepoints`, and `nasinNanpaPonaWords` when applicable.

```python
from nanpa_linja_n import NanpaLinjaN, parseNumber

parsed = parseNumber("123")
assert parsed["properName"] == "Nanpa Watusen"
assert parsed["uniqueCode"] == "#~WTS"
assert parsed["abbreviatedWords"] == ["nanpa", ":", "wan", "tu", "seli", "nanpa"]

nanpa = NanpaLinjaN.create()
assert nanpa.parseNumber("123")["uniqueCode"] == "#~WTS"
```

## Stable numeric facade

The established Python numeric facade remains available and unchanged so the approved 128-artifact Python baseline stays stable:

```python
from nanpa_linja_n import NanpaLinjaN

nanpa = NanpaLinjaN.create()
result = nanpa.render('123.45')
png = nanpa.render_to_png('12:30', font='linjaPona')
```

That legacy/stable numeric surface includes:

- `parse()`
- `build_render_plan()`
- `render()`
- `render_to_image()`
- `render_to_png()`
- `save_png()`

The full-document surface is additive and does not alter the approved numeric output path.

## Production fonts

The bundled font keys are:

- `nasinNanpa` (default)
- `sitelenSeliKiwen`
- `fairfaxHd`
- `fairfaxPonaHd`
- `linjaPona`
- `linjaSike`
- `nasinSitelenPuMono`
- `linjaLipamanka`

The package contains its production font bundle at `nanpa_linja_n/resources/fonts.zip`. All production font loading goes through that ZIP bundle for both the installed package and repository regression/visual-audit tooling.

## Manual tally behavior

Five production pairs use renderer-manual tallies:

- `nasinNanpa`
- `linjaPona`
- `linjaSike`
- `nasinSitelenPuMono`
- `linjaLipamanka`

For these fonts, **U+F199E is never inserted into the font run**. Synthetic tally strokes are positioned from the owning canonical glyph span in the complete shaped/adapted run.

The production renderer follows the canonical JavaScript cartouche coordinate system: crop to actual ink bounds, then apply the 6 px cartouche pad before deriving owner geometry. This is important for fonts with large side bearings, especially `linjaLipamanka`; centering against the uncropped run places the tallies incorrectly.

`linjaPona` additionally follows the current manifest setting `manualTallySmallFontLiftPx: 1` through `manualTallySmallFontMaxPx: 144`.

The other three production pairs use their native UCSUR U+F199E tally glyphs.

## Requirements

- Python 3.10+
- Pillow 9+ built with RAQM/HarfBuzz support
- fontTools 4.40+
- CairoSVG 2.7+ for vector PDF output
- system HarfBuzz (`libharfbuzz`) for complete-run shaping/caret geometry

The renderer deliberately fails rather than silently substituting unshaped production text where correct shaping is required.

## Regression testing

Run the complete configured gate:

```bash
python scripts/run_all.py
```

It is **non-fail-fast**: every configured suite is attempted even when an earlier suite fails. One consolidated report is written to `test-output/python-regression-report.txt`.

It includes:

- compile checks;
- the frozen **1,030-check Protocol v1.0.0 corpus**;
- `ast_to_text` regression and integration checks;
- unit tests;
- **335** JavaScript parser/API differential invocations when Node is available;
- the existing **128/128 approved Python production-font golden matrix**;
- **28/28** canonical syntax cases plus **5/5** production adapter cases;
- the **254/254 canonical full-renderer semantic corpus**, including AST and semantic run comparison;
- the older **Full Renderer Profile v1.0.0-candidate** qualification as a regression gate.

The current canonical full-renderer gate verifies **254/254** JavaScript-derived branch-oriented cases. See `FULL-RENDERER-CANONICAL-CONFORMANCE.md` for its coverage inventory.

The older Full Renderer Profile gate remains in place and verifies:

- **64/64** canonical browser semantic cases;
- **20/20** required operation checks;
- **9/9** vector/export cases;
- **38/38** feature-manifest areas;
- all **5/5** renderer-manual font pairs against explicit tally-placement regressions.

The older candidate profile contains documented stale capture details. `numeric-traditional` retained uniform separator codepoints; `ordinary-cartouche-tallies-disabled` retained tally metadata; and older image-run captures stored `sourceText: null` whereas the current canonical JavaScript emits an empty string. The qualification normalizes those old-oracle details rather than regressing the implementation away from current JavaScript behavior.

To run the full-renderer qualification alone:

```bash
python scripts/run_full_renderer_profile.py
```

## Visual `test-output`

The numeric and ordinary-cartouche audits are separate from the automated gate because they create files for visual inspection.

Point the audit at the production font directory and run:

```bash
export NANPA_FONT_DIR="$PWD/fonts"
./tools/export_visual_pngs.sh
./tools/export_cartouche_audit.sh
```

The ordinary-cartouche audit now renders through the **production `FullRenderer` tally path itself**. It no longer adds manual tallies afterward with the old audit-only post-processor.

Outputs are written under `test-output/`, including per-font contact sheets for ordinary cartouches, manual/UCSUR tallies and red-halo variants.

## Lower-level APIs

The existing lower-level APIs remain available:

```python
from nanpa_linja_n import (
    NanpaParser,
    parse_number,
    load_font_manifest,
    adapt_numeric_cartouche,
    number_glyph_renderer,
)
```

The full renderer is an extension of those validated components, not a replacement for the frozen Core-v1 implementation.
