# Changelog

## 0.3.0

- Added the native Python Full Renderer Profile implementation while preserving the established numeric facade and its approved 128-artifact output path.
- Added document AST parsing, mixed ordinary/numeric rendering, ordinary cartouches, quotes, proper names, raw UCSUR, inline images, multiline layout, alignment/spacing, halo/fill controls and runtime adapter registration.
- Added full raster/vector output surfaces: Pillow canvas, PNG, SVG, PDF and vector-document conversion.
- Added low-level run, text and UCSUR rendering operations matching the Full Renderer Profile surface.
- Fixed renderer-manual tally placement for all five manual-tally production font pairs. Manual fonts never insert U+F199E into the shaped font run; synthetic strokes are positioned from complete-run owner geometry after canonical ink-crop/cartouche-pad translation.
- Added explicit tally-position regressions for `nasinNanpa`, `linjaPona`, `linjaSike`, `nasinSitelenPuMono` and `linjaLipamanka`, including the side-bearing-sensitive `linjaLipamanka` case.
- Applied the manifest-controlled small-font tally lift, including the 1 px `linjaPona` lift through 144 px.
- Added Full Renderer Profile v1.0.0-candidate qualification: 64 semantic cases, 20 operations, 9 vector cases and 38 feature areas.
- Updated ordinary-cartouche visual audit export to use the production FullRenderer directly; the audit-only manual-tally post-processing workaround is no longer used.
- Added CairoSVG as the vector-PDF dependency.


## 0.2.0

- Added the high-level `NanpaLinjaN` production rendering facade.
- Added `render`, `render_to_image`, `render_to_png`, `save_png`, `parse`, `build_render_plan`, `list_fonts`, and `get_font_info`.
- Production font selection now automatically applies the correct font-specific adapter, including the legacy `linjaPona` and `linjaSike` ASCII shaping paths.
- Bundled the production font manifest and referenced production fonts as installable package assets.
- Added facade regression coverage that reproduces all 128 approved Python font golden artifacts exactly.
- Existing parser, low-level renderer, font registry, adapter APIs, corpus and approved golden baseline remain unchanged.

## 0.1.3

- Fixed migration of the approved Python 64-full-cartouche golden baseline to the 128-artifact full+abbreviated matrix.
- Legacy v0.1.1 records without `abbreviateNumericCartouches` are explicitly treated as full-cartouche records.
- Added metadata fallback matching by `fontKey` + `caseId` and baseline/current overlap diagnostics.
- Added `python scripts/font_goldens.py --extend`, which verifies and preserves all existing approved full goldens and adds only missing abbreviated goldens.
- `--extend` refuses to overwrite an approved full artifact if its hash, dimensions, companion hash, or adapter changed.

## 0.1.2

- Expanded Python font visual regression to 128 artifacts: 64 full + 64 abbreviated.
