# Changelog

## 0.4.0

- Updated to the current JavaScript numeric-whitespace baseline: internal whitespace terminates digit-based numeric tokens, while proper-name and numeric-cartouche spacing remains valid.
- `parseNumber("12 34")` now rejects; document parsing continues to recognize `12` and `34` as separate numeric spans.
- Replaced the obsolete spaced mixed-fraction regression with valid `1+1/2` / `kin` behavior.
- Added numeric-aware `ast_to_text()` / `astToText()` serialization with `numericOutput` values `source`, `properName`, `#~`, and `cartouche`, while keeping `source` as the backward-compatible default.
- `parse_input()` now attaches additive numeric-span metadata to existing AST segment kinds so numeric source can be re-serialized without changing document structure.
- Added public cross-language `parseNumber()` and `NanpaLinjaN.parseNumber()` APIs while preserving the established low-level `parse_number()` behavior.
- `parseNumber()` results now expose abbreviated cartouche words/codepoints and `nasinNanpaPonaWords` where applicable.
- Added focused numeric `ast_to_text` regression coverage, including full/abbreviated cartouches, preserved abbreviation breaks, nasin nanpa pona, `#~` fallbacks, multiple numeric spans, stale metadata, and public `parseNumber()` surfaces.
- Brought the native Python full renderer to the same canonical JavaScript semantic qualification level as the Go reference implementation.
- Added the JavaScript-derived **254-case canonical full-renderer corpus** and a permanent conformance runner; all 254 AST/run cases pass.
- Added **28 canonical syntax cases** and **5 production font-adapter cases** covering compounds, `&`, stack/nest joiners, long-glyph syntax, `te`/`to`/`zz`, glyph aliases, raw UCSUR precedence, legacy cartouche forms and adapter bypass/routing.
- Added whole-text canonical numeric scanning for signed values, percentages, mixed and vulgar fractions, date/time/telephone/hex/binary proper-name spans, number codes, Toki Pona numeric phrases and glyph+numeric suffixes.
- Added strict bracket numeric-phrase handling, including abbreviated numeric cartouches without double abbreviation.
- Added `enableBinaryRendering` to full-renderer parser options so binary parse/render switches match the canonical JavaScript behavior.
- Corrected literal/unknown role semantics, quote source preservation, lowercase raw `U+...` handling and image-run source metadata to match the current canonical JavaScript oracle.
- Added built-in production word-run adapter behavior for legacy fonts and canonical raw-UCSUR adapter bypass.
- Changed `scripts/run_all.py` to non-fail-fast execution and a consolidated `test-output/python-regression-report.txt`.
- Preserved all established gates: **1,030/1,030** protocol regression checks, **344/344** JavaScript differential invocations, **128/128** production-font goldens and **64/64** older Full Renderer Profile semantic cases.

## 0.3.0

- Added the native Python Full Renderer Profile implementation while preserving the established numeric facade and its approved 128-artifact output path.
- Added document AST parsing, mixed ordinary/numeric rendering, ordinary cartouches, quotes, proper names, raw UCSUR, inline images, multiline layout, alignment/spacing, halo/fill controls and runtime adapter registration.
- Added full raster/vector output surfaces: Pillow canvas, PNG, SVG, PDF and vector-document conversion.
- Added low-level run, text and UCSUR rendering operations matching the Full Renderer Profile surface.
- Fixed renderer-manual tally placement for all five manual-tally production font pairs. Manual fonts never insert U+F199E into the shaped font run; synthetic strokes are positioned from complete-run owner geometry after canonical ink-crop/cartouche-pad translation.
- Added explicit tally-position regressions for `nasinNanpa`, `linjaPona`, `linjaSike`, `nasinSitelenPuMono` and `linjaLipamanka`, including the side-bearing-sensitive `linjaLipamanka` case.
- Applied the manifest-controlled small-font tally lift, including the 1 px `linjaPona` lift through 144 px.
- Added Full Renderer Profile v1.0.0-candidate qualification: 64 semantic cases, 20 operations, 9 vector cases and 38 feature areas.
- Updated ordinary-cartouche visual audit export to use the production FullRenderer directly; the audit-only manual-tally post-processing workaround is no longer used.
- Added CairoSVG as the vector-PDF dependency.


## 0.2.0

- Added the high-level `NanpaLinjaN` production rendering facade.
- Added `render`, `render_to_image`, `render_to_png`, `save_png`, `parse`, `build_render_plan`, `list_fonts`, and `get_font_info`.
- Production font selection now automatically applies the correct font-specific adapter, including the legacy `linjaPona` and `linjaSike` ASCII shaping paths.
- Bundled the production font manifest and referenced production fonts as installable package assets.
- Added facade regression coverage that reproduces all 128 approved Python font golden artifacts exactly.
- Existing parser, low-level renderer, font registry, adapter APIs, corpus and approved golden baseline remain unchanged.

## 0.1.3

- Fixed migration of the approved Python 64-full-cartouche golden baseline to the 128-artifact full+abbreviated matrix.
- Legacy v0.1.1 records without `abbreviateNumericCartouches` are explicitly treated as full-cartouche records.
- Added metadata fallback matching by `fontKey` + `caseId` and baseline/current overlap diagnostics.
- Added `python scripts/font_goldens.py --extend`, which verifies and preserves all existing approved full goldens and adds only missing abbreviated goldens.
- `--extend` refuses to overwrite an approved full artifact if its hash, dimensions, companion hash, or adapter changed.

## 0.1.2

- Expanded Python font visual regression to 128 artifacts: 64 full + 64 abbreviated.
