from .parser import NanpaParser, parse_number
from . import number_glyph_renderer
from .font_registry import load_font_manifest, FontManifest, FontPairSpec, FontFaceSpec
from .font_adapters import adapt_numeric_cartouche
from .facade import (
    DEFAULT_FONT_KEY,
    DEFAULT_FONT_SIZE,
    DEFAULT_OUTER_PADDING,
    DEFAULT_PARSER_OPTIONS,
    FontInfo,
    RenderPlan,
    RenderResult,
    NanpaLinjaN,
    default_facade,
    list_fonts,
    render,
    render_to_image,
    render_to_png,
    save_png,
    parse_input,
    ast_to_text,
    build_full_render_plan,
    render_to_canvas,
    render_full_to_png,
    render_to_svg,
    render_to_pdf,
    to_vector_document,
)



# JavaScript-style public aliases for cross-language API parity. Existing
# snake_case parse_number() retains its established low-level defaults; the new
# parseNumber() wrapper uses the facade defaults, matching the JS public API.
def parseNumber(input_value, options=None):
    raw = dict(options or {})
    parser = dict(DEFAULT_PARSER_OPTIONS)
    config = raw.get("config")
    if isinstance(config, dict) and isinstance(config.get("parser"), dict):
        parser.update(config["parser"])
    if isinstance(raw.get("parser"), dict):
        parser.update(raw["parser"])
    elif raw and "config" not in raw:
        parser.update(raw)
    return parse_number(input_value, parser)


def astToText(ast, options=None, **kwargs):
    return ast_to_text(ast, options, **kwargs)

from .full_renderer import (
    ParseOptions as FullParseOptions,
    LayoutOptions,
    UnknownTextStyle,
    PaintOptions,
    FullRenderOptions,
    ImageDescriptor,
    DocumentSegment,
    DocumentLine,
    DocumentAst,
    TallyGroup,
    FullRenderRun,
    FullRenderLinePlan,
    FullRenderPlan,
    CanvasRenderResult,
    VectorElement,
    VectorDocument,
)

__all__ = [
    "NanpaParser",
    "parse_number",
    "parseNumber",
    "number_glyph_renderer",
    "load_font_manifest",
    "FontManifest",
    "FontPairSpec",
    "FontFaceSpec",
    "adapt_numeric_cartouche",
    "DEFAULT_FONT_KEY",
    "DEFAULT_FONT_SIZE",
    "DEFAULT_OUTER_PADDING",
    "DEFAULT_PARSER_OPTIONS",
    "FontInfo",
    "RenderPlan",
    "RenderResult",
    "NanpaLinjaN",
    "default_facade",
    "list_fonts",
    "render",
    "render_to_image",
    "render_to_png",
    "save_png",
    "FullParseOptions",
    "LayoutOptions",
    "UnknownTextStyle",
    "PaintOptions",
    "FullRenderOptions",
    "ImageDescriptor",
    "DocumentSegment",
    "DocumentLine",
    "DocumentAst",
    "TallyGroup",
    "FullRenderRun",
    "FullRenderLinePlan",
    "FullRenderPlan",
    "CanvasRenderResult",
    "VectorElement",
    "VectorDocument",
    "parse_input",
    "ast_to_text",
    "astToText",
    "build_full_render_plan",
    "render_to_canvas",
    "render_full_to_png",
    "render_to_svg",
    "render_to_pdf",
    "to_vector_document",
]
