"""Native Python full-document renderer for the nanpa-linja-n Full Renderer Profile.

This module extends the frozen numeric Core with the host-independent document,
ordinary-cartouche, layout, raster/vector and low-level rendering surface of the
canonical JavaScript reference.  It does not execute JavaScript.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from io import BytesIO
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple
import base64
import ctypes
import ctypes.util
import html
import math
import re
import urllib.parse

from PIL import Image, ImageDraw, ImageFilter, ImageFont
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen

from .parser import NanpaParser
from .font_registry import FontPairSpec
from .font_adapters import adapt_numeric_cartouche
from . import number_glyph_renderer as legacy

CARTOUCHE_START = 0xF1990
CARTOUCHE_END = 0xF1991
TALLY_CP = 0xF199E
MIDDLE_DOT_CP = 0xF199C
COLON_CP = 0xF199D
STACK_JOINER_CP = 0xF1995
NEST_JOINER_CP = 0xF1996
OPEN_QUOTE_CP = 0x300C
CLOSE_QUOTE_CP = 0x300D

_RGBA = Tuple[int, int, int, int]


def _cp_for_word(word: str) -> Optional[int]:
    value = getattr(legacy, "WORDS_TO_UNC_CODES_MAP", {}).get((word or "").lower())
    if not value:
        return None
    return ord(value[0])


def _word_for_cp(cp: int) -> Optional[str]:
    table = getattr(legacy, "UNC_CODES_TO_WORDS_MAP", {})
    value = table.get(f"{int(cp):X}") or table.get(f"{int(cp):04X}")
    return str(value).lower() if value else None


def _hex_color(value: Any, default: str = "#000000") -> str:
    s = str(value or default).strip()
    if re.fullmatch(r"#[0-9a-fA-F]{6}", s):
        return s.upper()
    if re.fullmatch(r"#[0-9a-fA-F]{3}", s):
        a = s[1:].upper()
        return "#" + "".join(ch * 2 for ch in a)
    return default.upper()


def _rgba_from_hex(value: str, alpha: int = 255) -> _RGBA:
    s = _hex_color(value)
    return (int(s[1:3], 16), int(s[3:5], 16), int(s[5:7], 16), alpha)


@dataclass(frozen=True)
class ParseOptions:
    enable_binary_parsing: bool = True
    enable_hex_parsing: bool = True
    mode: str = "uniform"
    numeric_mode: str = "uniform"
    nanpa_colon_parsing: bool = True
    nanpa_colon_rendering: bool = True
    relaxed_nanpa_linjan_parsing: bool = True
    relaxed_nanpa_linjan_rendering: bool = True
    abbreviate_numeric_cartouches: bool = False
    preserve_numeric_cartouche_breaks_in_abbreviation: bool = False
    numeric_cartouche_start_glyph: Optional[str] = None
    renderer_mode: str = "sitelen-pona-ascii-extended"
    mixed_style: str = "short"
    break_lines_at_full_stops: bool = False
    show_unknown_text: bool = False
    auto_cartouche_standalone_proper_names: bool = True
    interpret_double_quotes_as_te_to: bool = False
    cartouche_comma_tally_marks: bool = True
    cartouche_tally_mode: Optional[str] = None
    manual_tally_small_font_lift_px: Optional[float] = None
    manual_tally_small_font_max_px: Optional[float] = None
    nasin_nanpa_pona: bool = False

    @staticmethod
    def from_mapping(raw: Optional[Mapping[str, Any]]) -> "ParseOptions":
        m = dict(raw or {})
        mode_v = str(m.get("mode", "uniform"))
        renderer_mode = str(m.get("rendererMode", "sitelen-pona-ascii-extended"))
        if mode_v not in ("uniform", "traditional"):
            renderer_mode = mode_v
            mode_v = "uniform"
        if renderer_mode not in ("standard-sitelen-pona-ascii-core", "sitelen-pona-ascii-extended", "sitelen-seli-kiwen"):
            renderer_mode = "sitelen-pona-ascii-extended"
        numeric_mode = str(m.get("numericMode", mode_v))
        if numeric_mode not in ("uniform", "traditional"):
            numeric_mode = mode_v
        tally_mode = m.get("cartoucheTallyMode", m.get("tallyMode", m.get("ordinaryCartoucheTallyMode")))
        if tally_mode is not None:
            tally_mode = str(tally_mode).lower().strip()
            if tally_mode not in ("manual", "comma", "ucsur"):
                tally_mode = None
        comma_value = m.get("cartoucheCommaTallyMarks", m.get("commaTallyMarks", m.get("enableCartoucheCommaTallies", True)))
        def b(key: str, default: bool) -> bool:
            v = m.get(key, default)
            if isinstance(v, str):
                return v.lower() not in ("false", "0", "no", "off", "")
            return bool(v)
        def first_bool(keys: Sequence[str], default: bool) -> bool:
            for k in keys:
                if k in m:
                    v=m[k]
                    if isinstance(v,str): return v.lower() not in ("false","0","no","off","")
                    return bool(v)
            return default
        def num(keys: Sequence[str]) -> Optional[float]:
            for k in keys:
                if k in m:
                    try:
                        v=float(m[k])
                        if math.isfinite(v): return v
                    except Exception: pass
            return None
        start = m.get("numericCartoucheStartGlyph")
        start = str(start).lower() if start is not None and str(start).lower() in ("nanpa","tenpo","suno","toki") else None
        return ParseOptions(
            enable_binary_parsing=b("enableBinaryParsing", True),
            enable_hex_parsing=b("enableHexParsing", True),
            mode=mode_v,
            numeric_mode=numeric_mode,
            nanpa_colon_parsing=b("nanpaColonParsing", True),
            nanpa_colon_rendering=b("nanpaColonRendering", True),
            relaxed_nanpa_linjan_parsing=b("relaxedNanpaLinjanParsing", True),
            relaxed_nanpa_linjan_rendering=b("relaxedNanpaLinjanRendering", True),
            abbreviate_numeric_cartouches=first_bool(("abbreviateNumericCartouches","numericCartoucheAbbreviation","abbreviatedNumericCartouches"), False),
            preserve_numeric_cartouche_breaks_in_abbreviation=first_bool(("preserveNumericCartoucheBreaksInAbbreviation","abbreviatedNumericCartoucheBreakAsEn"), False),
            numeric_cartouche_start_glyph=start,
            renderer_mode=renderer_mode,
            mixed_style="long" if str(m.get("mixedStyle", "short")).lower()=="long" else "short",
            break_lines_at_full_stops=b("breakLinesAtFullStops", False),
            show_unknown_text=b("showUnknownText", False),
            auto_cartouche_standalone_proper_names=b("autoCartoucheStandaloneProperNames", True),
            interpret_double_quotes_as_te_to=b("interpretDoubleQuotesAsTeTo", False),
            cartouche_comma_tally_marks=(comma_value if isinstance(comma_value,bool) else str(comma_value).lower() not in ("false","0","no","off","")),
            cartouche_tally_mode=tally_mode,
            manual_tally_small_font_lift_px=num(("manualTallySmallFontLiftPx","tallySmallFontLiftPx")),
            manual_tally_small_font_max_px=num(("manualTallySmallFontMaxPx","tallySmallFontMaxPx")),
            nasin_nanpa_pona=b("nasinNanpaPona", False),
        )

    def numeric_mapping(self) -> Dict[str, Any]:
        mode = "traditional" if self.mode == "traditional" or self.numeric_mode == "traditional" else "uniform"
        out: Dict[str, Any] = {
            "enableBinaryParsing": self.enable_binary_parsing,
            "enableHexParsing": self.enable_hex_parsing,
            "mode": mode,
            "numericMode": mode,
            "nanpaColonParsing": self.nanpa_colon_parsing,
            "nanpaColonRendering": self.nanpa_colon_rendering,
            "relaxedNanpaLinjanParsing": self.relaxed_nanpa_linjan_parsing,
            "relaxedNanpaLinjanRendering": self.relaxed_nanpa_linjan_rendering,
            "abbreviateNumericCartouches": self.abbreviate_numeric_cartouches,
            "preserveNumericCartoucheBreaksInAbbreviation": self.preserve_numeric_cartouche_breaks_in_abbreviation,
            "mixedStyle": self.mixed_style,
            "nasinNanpaPona": self.nasin_nanpa_pona,
        }
        if self.numeric_cartouche_start_glyph:
            out["numericCartoucheStartGlyph"] = self.numeric_cartouche_start_glyph
        return out


@dataclass(frozen=True)
class LayoutOptions:
    align: str = "left"
    spacing_preset: str = "default"
    glyph_gap_scale: Optional[float] = None
    glyph_gap_min_px: Optional[float] = None
    glyph_gap_max_px: Optional[float] = None
    cartouche_lead_gap_scale: Optional[float] = None
    cartouche_pad_scale: Optional[float] = None
    cartouche_pad_min_px: Optional[float] = None
    line_gap_px: Optional[float] = None
    force_line_gap_px: bool = False

    @staticmethod
    def from_mapping(raw: Optional[Mapping[str, Any]]) -> "LayoutOptions":
        m=dict(raw or {})
        def n(k):
            try:
                v=float(m[k]); return v if math.isfinite(v) else None
            except Exception: return None
        align=str(m.get("align","left")).lower(); align=align if align in ("left","center","right") else "left"
        preset=str(m.get("spacingPreset","default")).lower(); preset=preset if preset in ("default","compact","comfortable") else "default"
        return LayoutOptions(align,preset,n("glyphGapScale"),n("glyphGapMinPx"),n("glyphGapMaxPx"),n("cartoucheLeadGapScale"),n("cartouchePadScale"),n("cartouchePadMinPx"),n("lineGapPx"),bool(m.get("forceLineGapPx",False)))
    def glyph_gap(self,px:float)->float:
        if self.glyph_gap_scale is not None:
            v=px*self.glyph_gap_scale
            if self.glyph_gap_min_px is not None:v=max(v,self.glyph_gap_min_px)
            if self.glyph_gap_max_px is not None:v=min(v,self.glyph_gap_max_px)
            return max(0.0,v)
        return max(2,px*.08) if self.spacing_preset=="compact" else max(6,px*.22) if self.spacing_preset=="comfortable" else max(4,px*.14)
    def cartouche_lead_gap(self,px:float)->float:
        return max(0,px*self.cartouche_lead_gap_scale) if self.cartouche_lead_gap_scale is not None else self.glyph_gap(px)
    def cartouche_pad(self,px:float)->float:
        v=px*(self.cartouche_pad_scale if self.cartouche_pad_scale is not None else .12)
        if self.cartouche_pad_min_px is not None:v=max(v,self.cartouche_pad_min_px)
        return max(0,v)
    def line_gap(self,px:float)->float:
        if self.line_gap_px is not None and (self.force_line_gap_px or self.line_gap_px>=0):return max(0,self.line_gap_px)
        return max(8,px*.20) if self.spacing_preset=="compact" else max(18,px*.40) if self.spacing_preset=="comfortable" else 18.0


@dataclass(frozen=True)
class UnknownTextStyle:
    style: str = "outline-box"
    color: str = "#000000"
    line_width_px: float = 1.5
    padding_px: float = 2.0
    dash: Tuple[float,...] = ()
    @staticmethod
    def from_mapping(raw: Any)->"UnknownTextStyle":
        m=dict(raw) if isinstance(raw,Mapping) else {}
        dash=[]
        for x in m.get("dash",[]) or []:
            try: dash.append(float(x))
            except Exception: pass
        try: lw=max(0,float(m.get("lineWidthPx",1.5)))
        except Exception: lw=1.5
        try: pad=max(0,float(m.get("paddingPx",2)))
        except Exception: pad=2
        return UnknownTextStyle(str(m.get("style","outline-box")),_hex_color(m.get("color"),"#000000"),lw,pad,tuple(dash))

@dataclass(frozen=True)
class PaintOptions:
    fill_style: str = "#000000"
    unknown_text: UnknownTextStyle = field(default_factory=UnknownTextStyle)
    halo_enabled: bool = False
    halo_color: str = "#FFFFFF"
    halo_width_px: float = 0.0
    @staticmethod
    def from_mapping(raw: Optional[Mapping[str,Any]])->"PaintOptions":
        m=dict(raw or {}); hm=dict(m.get("halo") or {}) if isinstance(m.get("halo"),Mapping) else {}
        try: hw=max(0,float(hm.get("widthPx",0)))
        except Exception: hw=0
        return PaintOptions(_hex_color(m.get("fillStyle"),"#000000"),UnknownTextStyle.from_mapping(m.get("unknownText")),bool(hm.get("enabled",False)),_hex_color(hm.get("color"),"#FFFFFF"),hw)

@dataclass(frozen=True)
class FullRenderOptions:
    font_key: str = "nasinNanpa"
    font_size: float = 56.0
    padding_px: int = 18
    parser: ParseOptions = field(default_factory=ParseOptions)
    layout: LayoutOptions = field(default_factory=LayoutOptions)
    paint: PaintOptions = field(default_factory=PaintOptions)
    include_plan: bool = True
    format: str = "canvas"
    @staticmethod
    def from_mapping(raw: Optional[Mapping[str,Any]], *, defaults: Optional[Mapping[str,Any]]=None)->"FullRenderOptions":
        m=dict(defaults or {}); m.update(dict(raw or {}))
        layout=LayoutOptions.from_mapping(m.get("layout") if isinstance(m.get("layout"),Mapping) else {})
        paint=PaintOptions.from_mapping(m.get("paint") if isinstance(m.get("paint"),Mapping) else {})
        parser=ParseOptions.from_mapping(m.get("parser") if isinstance(m.get("parser"),Mapping) else {})
        fs=m.get("fontSize", (m.get("layout") or {}).get("fontPx",56) if isinstance(m.get("layout"),Mapping) else 56)
        try: fs=max(8,float(fs))
        except Exception: fs=56
        pad=m.get("paddingPx", (m.get("layout") or {}).get("paddingPx",18) if isinstance(m.get("layout"),Mapping) else 18)
        try: pad=max(0,int(round(float(pad))))
        except Exception: pad=18
        return FullRenderOptions(str(m.get("font","nasinNanpa")),fs,pad,parser,layout,paint,bool(m.get("includePlan",True)),str(m.get("format","canvas")).lower())


@dataclass(frozen=True)
class ImageDescriptor:
    src: str=""; w: Optional[str]=None; h: Optional[str]=None; alt: Optional[str]=None; valign: str="baseline"; wriggle: float=8; transparent: bool=True
@dataclass(frozen=True)
class DocumentSegment:
    kind: str; value: Optional[str]=None; image: Optional[ImageDescriptor]=None; open_quote: Optional[str]=None; close_quote: Optional[str]=None; source_start:int=0; source_end:int=0
@dataclass(frozen=True)
class DocumentLine:
    index:int; source_line_index:int; sentence_index_in_source_line:int; source_text:str; children:Tuple[DocumentSegment,...]
@dataclass(frozen=True)
class DocumentAst:
    type:str; normalized_input:str; parser_options:Mapping[str,Any]; lines:Tuple[DocumentLine,...]

@dataclass(frozen=True)
class TallyGroup:
    owner_index:int; count:int; owner_left_px:float; owner_right_px:float; center_x_px:float; top_y_px:float; bottom_y_px:float; stroke_width_px:float; stroke_centers_px:Tuple[float,...]

@dataclass(frozen=True)
class FullRenderRun:
    id:str=""; line_index:int=0; run_index:int=0; kind:str="glyph"; render_mode:str="text"; font_role:str="word"
    numeric_cartouche:bool=False; hex_cartouche:bool=False; binary_cartouche:bool=False; numeric_base:int=0
    opener_codepoint:Optional[int]=None; closer_codepoint:Optional[int]=None
    canonical_codepoints:Tuple[int,...]=(); render_codepoints:Tuple[int,...]=(); render_text:str=""; render_adapter_id:str="identity"
    source_text:Optional[str]=None; source_kind:Optional[str]=None; source_start:int=-1; source_end:int=-1
    manual_tallies:Tuple[int,...]=(); tally_groups:Tuple[TallyGroup,...]=(); quoted:bool=False; interpreted_quote:bool=False; unrecognized:bool=False; image_alt:Optional[str]=None
    x_px:float=0; y_px:float=0; width_px:float=0; height_px:float=0; baseline_y_px:float=0

@dataclass(frozen=True)
class FullRenderLinePlan:
    line_index:int; source_line_index:int; sentence_index_in_source_line:int; x_px:float; y_px:float; width_px:float; height_px:float; baseline_y_px:float; ascent_px:float; descent_px:float; runs:Tuple[FullRenderRun,...]

@dataclass(frozen=True)
class FullRenderPlan:
    input:str; font_key:str; abbreviated:bool; width:int; height:int; open_type_features:Tuple[str,...]; runs:Tuple[FullRenderRun,...]; parsed:Optional[Mapping[str,Any]]; diagnostics:Tuple[str,...]; ast:DocumentAst; lines:Tuple[FullRenderLinePlan,...]
    @property
    def line_count(self)->int:return len(self.lines)
    @property
    def cartouche_count(self)->int:return sum(1 for r in self.runs if r.numeric_cartouche or r.font_role=="cartouche")

@dataclass
class CanvasRenderResult:
    image:Image.Image; plan:Optional[FullRenderPlan]; font_key:str
    @property
    def width(self)->int:return self.image.width
    @property
    def height(self)->int:return self.image.height
    @property
    def canvas(self)->Image.Image:return self.image

@dataclass(frozen=True)
class VectorElement:
    kind:str; run_id:Optional[str]; path:Optional[str]; fill:Optional[str]; href:Optional[str]; x:float; y:float; width:float; height:float
@dataclass(frozen=True)
class VectorDocument:
    width:int; height:int; elements:Tuple[VectorElement,...]; diagnostics:Tuple[str,...]; plan:FullRenderPlan


ALIASES=(
    ("'cartouche-start'","["),("'cartouche-end'","]"),("'zw-joiner'","&"),("'stack-joiner'","-"),("'nesting-joiner'","+"),
    ("'ideographic-space'"," zz "),("'long-start'","("),("'long-end'",")"),("'left-bracket'"," te "),("'right-bracket'"," to "),
    ("'middle-dot'","."),("'colon'",":"),("'tally'",",")
)

def _normalize_document(s:str,p:ParseOptions)->str:
    out=s or ""
    if p.renderer_mode!="standard-sitelen-pona-ascii-core":
        for a,b in ALIASES: out=out.replace(a,b)
    return out.replace("\r\n","\n").replace("\r","\n")

def _sentence_stop(s:str,i:int)->bool:
    prev=s[i-1] if i>0 else ""; nxt=s[i+1] if i+1<len(s) else ""
    numeric=nxt.isdigit() and (prev.isdigit() or i==0 or prev.isspace() or prev in "+-(,:=")
    return not numeric

def _split_full_stops(line:str)->List[str]:
    out=[]; start=0; square=paren=brace=0; quote=None; i=0
    while i<len(line):
        ch=line[i]
        if quote:
            if ch=="\\":i+=2;continue
            close=(quote=="“" and ch in ("”",'"')) or (quote=='"' and ch in ('"','”'))
            if close:quote=None
            i+=1;continue
        if ch in ('"','“'):quote=ch;i+=1;continue
        if ch=='[':square+=1
        elif ch==']':square=max(0,square-1)
        elif ch=='(':paren+=1
        elif ch==')':paren=max(0,paren-1)
        elif ch=='{':brace+=1
        elif ch=='}':brace=max(0,brace-1)
        elif ch=='.' and not square and not paren and not brace and _sentence_stop(line,i):
            end=i+1
            while end<len(line) and line[end]=='.' and _sentence_stop(line,end):end+=1
            out.append(line[start:end]);start=end;i=end;continue
        i+=1
    tail=line[start:]
    if tail.strip() or not out:out.append(tail)
    return out

def _split_args(s:str)->List[str]:
    out=[];cur=[];quote=None;esc=False;depth=0
    for ch in s:
        if esc:cur.append(ch);esc=False;continue
        if ch=='\\':cur.append(ch);esc=True;continue
        if quote:
            cur.append(ch)
            if ch==quote:quote=None
            continue
        if ch in ('"',"'"):quote=ch;cur.append(ch);continue
        if ch=='(':depth+=1;cur.append(ch);continue
        if ch==')':depth=max(0,depth-1);cur.append(ch);continue
        if ch==',' and depth==0:out.append(''.join(cur).strip());cur=[];continue
        cur.append(ch)
    out.append(''.join(cur).strip())
    return out

def _strip_quotes(s:str)->str:
    s=s.strip()
    if len(s)>=2 and s[0]==s[-1] and s[0] in ('"',"'"):return s[1:-1]
    return s

def _parse_image_args(arg:str)->ImageDescriptor:
    parts=_split_args(arg); src=""; w=h=alt=None; valign="baseline"; wriggle=8.0; transparent=True; start=0
    if parts and '=' not in parts[0]:src=_strip_quotes(parts[0]);start=1
    for x in parts[start:]:
        if '=' not in x:continue
        k,v=x.split('=',1);k=k.strip();v=_strip_quotes(v)
        if k=='src':src=v
        elif k=='w':w=v
        elif k=='h':h=v
        elif k=='alt':alt=v
        elif k=='valign':valign=v
        elif k=='wriggle':
            try:wriggle=float(v)
            except Exception:pass
        elif k=='transparent':transparent=str(v).lower() not in ('false','0','no','off')
    return ImageDescriptor(src,w,h,alt,valign,wriggle,transparent)

def _segments(line:str)->Tuple[DocumentSegment,...]:
    out=[]; i=0; start=0
    def push(a,b):
        if b>a:out.append(DocumentSegment('text',line[a:b],source_start=a,source_end=b))
    while i<len(line):
        ch=line[i]
        if ch=='[':
            j=line.find(']',i+1)
            if j<0:break
            push(start,i);out.append(DocumentSegment('bracket',line[i+1:j],source_start=i,source_end=j+1));i=j+1;start=i;continue
        if ch in ('"','“'):
            close='”' if ch=='“' else '"';j=i+1;found=False
            while j<len(line):
                cj=line[j]; isclose=cj==close or (ch=='“' and cj=='"') or (ch=='"' and cj=='”')
                if isclose and (j==0 or line[j-1]!='\\'):found=True;break
                j+=1
            if not found:break
            push(start,i);out.append(DocumentSegment('quote',line[i+1:j],open_quote=ch,close_quote=line[j],source_start=i,source_end=j+1));i=j+1;start=i;continue
        if line.startswith('img(',i):
            j=i+4;depth=1;quote=None;esc=False
            while j<len(line):
                cj=line[j]
                if esc:esc=False;j+=1;continue
                if cj=='\\':esc=True;j+=1;continue
                if quote:
                    if cj==quote:quote=None
                    j+=1;continue
                if cj in ('"',"'"):quote=cj;j+=1;continue
                if cj=='(':depth+=1
                elif cj==')':
                    depth-=1
                    if depth==0:break
                j+=1
            if j>=len(line):break
            push(start,i);out.append(DocumentSegment('image',image=_parse_image_args(line[i+4:j]),source_start=i,source_end=j+1));i=j+1;start=i;continue
        i+=1
    push(start,len(line));return tuple(out)

def parse_document(input_text:str, options:ParseOptions)->DocumentAst:
    normalized=_normalize_document(input_text or '',options); lines=[]
    for sli,source in enumerate(normalized.split('\n')):
        rendered=_split_full_stops(source) if options.break_lines_at_full_stops else [source]
        for si,s in enumerate(rendered):
            lines.append(DocumentLine(len(lines),sli,si,s,_segments(s)))
    return DocumentAst('document',normalized,{"breakLinesAtFullStops":options.break_lines_at_full_stops},tuple(lines))


def _quote_image_argument(value: Any) -> str:
    text = str(value if value is not None else "")
    if "'" not in text:
        return f"'{text}'"
    if '"' not in text:
        return f'"{text}"'
    escaped = text.replace('\\', '\\\\').replace('\"', '\\\"')
    return f'"{escaped}"'


def _image_descriptor_to_text(desc: Optional[ImageDescriptor]) -> str:
    image = desc if isinstance(desc, ImageDescriptor) else ImageDescriptor()
    args: List[str] = []
    if image.src:
        args.append(f"src={_quote_image_argument(image.src)}")
    if image.w is not None and str(image.w) != "":
        args.append(f"w={_quote_image_argument(image.w)}")
    if image.h is not None and str(image.h) != "":
        args.append(f"h={_quote_image_argument(image.h)}")
    if image.alt is not None:
        args.append(f"alt={_quote_image_argument(image.alt)}")
    if image.valign is not None and str(image.valign) not in ("", "baseline"):
        args.append(f"valign={_quote_image_argument(image.valign)}")
    if image.wriggle is not None and float(image.wriggle) != 8.0:
        wriggle = float(image.wriggle)
        args.append(f"wriggle={wriggle:g}")
    if image.transparent is False:
        args.append("transparent=false")
    return f"img({','.join(args)})"


def _document_segment_to_text(segment: DocumentSegment) -> str:
    if not isinstance(segment, DocumentSegment):
        raise TypeError("AST segment must be a DocumentSegment.")
    if segment.kind == "text":
        return str(segment.value if segment.value is not None else "")
    if segment.kind == "bracket":
        return f"[{str(segment.value if segment.value is not None else '')}]"
    if segment.kind == "quote":
        open_quote = str(segment.open_quote or '"')
        default_close = "”" if open_quote == "“" else '"'
        close_quote = str(segment.close_quote or default_close)
        return f"{open_quote}{str(segment.value if segment.value is not None else '')}{close_quote}"
    if segment.kind == "image":
        return _image_descriptor_to_text(segment.image)
    raise TypeError(f"Unsupported AST segment kind: {segment.kind}")


def ast_to_text(ast: DocumentAst) -> str:
    """Convert a full-document AST back into valid nanpa-linja-n source text.

    Current AST values are serialized; ``normalized_input`` and ``source_text``
    are not used as fallback content.  Text/bracket/quote whitespace is therefore
    retained, sentence-split AST lines are rejoined by ``source_line_index``, and
    image descriptors are emitted in a canonical ``img(...)`` form.
    """
    if not isinstance(ast, DocumentAst):
        raise TypeError("ast_to_text() expects a DocumentAst.")
    output: List[str] = []
    have_previous = False
    previous_source_line_index: Optional[int] = None
    for i, line in enumerate(ast.lines):
        if not isinstance(line, DocumentLine):
            raise TypeError("AST line must be a DocumentLine.")
        current = ''.join(_document_segment_to_text(segment) for segment in line.children)
        source_line_index = line.source_line_index if isinstance(line.source_line_index, int) and line.source_line_index >= 0 else i
        if have_previous and source_line_index != previous_source_line_index:
            output.append('\n')
        output.append(current)
        have_previous = True
        previous_source_line_index = source_line_index
    return ''.join(output)


def parse_raw_unicode_sequence(text:str)->Optional[List[int]]:
    toks=text.strip().split()
    if not toks:return None
    out=[]
    for t in toks:
        m=re.fullmatch(r"U\+([0-9A-Fa-f]{4,6})",t)
        if not m:return None
        cp=int(m.group(1),16)
        if cp>0x10FFFF:return None
        out.append(cp)
    return out


@dataclass(frozen=True)
class AdaptedOrdinary:
    text:str; canonical_spans:Tuple[Tuple[int,int],...]

def _adapt_ordinary(pair:FontPairSpec, inner:Sequence[int])->AdaptedOrdinary:
    full=[CARTOUCHE_START,*map(int,inner),CARTOUCHE_END]
    rid=pair.render_adapter_id or 'identity'; settings=pair.render_adapter_settings or {}
    def identity(cps):
        return AdaptedOrdinary(''.join(chr(x) for x in cps),tuple((i,i+1) for i in range(len(cps))))
    def legacy_word(cp:int,kind:str)->Optional[str]:
        if cp==MIDDLE_DOT_CP:return '.'
        if cp==COLON_CP:return ':'
        if cp==0x3000:return 'zz' if kind=='linja-lipamanka' else '  '
        if cp==0xF1989:return 'ni<' if kind=='linja-lipamanka' else 'ni'
        if cp==0xF198A:return 'ni^' if kind in ('linja-sike','linja-lipamanka') else 'ni'
        if cp==0xF198B:return 'ni>' if kind in ('linja-sike','linja-lipamanka') else 'ni'
        if cp==0xF198C:return 'sewi1' if kind=='linja-sike' else 'sewi'
        if cp==OPEN_QUOTE_CP and kind=='linja-lipamanka':return 'te'
        if cp==CLOSE_QUOTE_CP and kind=='linja-lipamanka':return 'to'
        w=_word_for_cp(cp)
        if w is None:return None
        if kind=='linja-pona' and cp in (0xF19A2,0xF19A4,0xF19A5,0xF19A6):return None
        if kind=='linja-lipamanka' and (cp in (0xF19A4,0xF19A5,0xF19A6) or cp>0xF19A3):return None
        return w
    if rid in ('linja-pona-legacy-v1','linja-sike-legacy-v1'):
        kind='linja-pona' if rid.startswith('linja-pona') else 'linja-sike'; out='['; spans=[(0,1)]+[(0,0)]*(len(full)-2)+[(0,0)]
        for i,cp in enumerate(full[1:-1],1):
            st=len(out); w=legacy_word(cp,kind) or '\ufffd'; out+='_'+w; spans[i]=(st,len(out))
        st=len(out); out+=']'; spans[-1]=(st,len(out)); return AdaptedOrdinary(out,tuple(spans))
    if rid=='nasin-sitelen-pu-mono-v1':
        def mapped(cp):
            if cp in (0xF1989,0xF198A,0xF198B):return 0xF1941
            if cp==0xF198C:return 0xF195A
            if cp==MIDDLE_DOT_CP:return ord('.')
            if cp==COLON_CP:return ord(':')
            if (0xF1900<=cp<=0xF1988) or (0xF19A0<=cp<=0xF19A3) or cp in (CARTOUCHE_START,CARTOUCHE_END,0x3000,OPEN_QUOTE_CP,CLOSE_QUOTE_CP):return cp
            return int(settings.get('unsupportedReplacementCodepoint',0xFFFD))
        vals=[mapped(x) for x in full];return AdaptedOrdinary(''.join(chr(x) for x in vals),tuple((i,i+1) for i in range(len(vals))))
    if rid=='linja-lipamanka-v1':
        def needs(cp):return cp in (MIDDLE_DOT_CP,COLON_CP,TALLY_CP,0xF1989,0xF198A,0xF198B,0xF198C,OPEN_QUOTE_CP,CLOSE_QUOTE_CP,0x3000,0xF19A4,0xF19A5,0xF19A6) or cp>0xF19A3
        if any(needs(cp) for cp in full):
            out='[';spans=[(0,1)]+[(0,0)]*(len(full)-2)+[(0,0)]
            for i,cp in enumerate(full[1:-1],1):
                if i>1:out+=' '
                st=len(out);out+=legacy_word(cp,'linja-lipamanka') or '\ufffd';spans[i]=(st,len(out))
            st=len(out);out+=']';spans[-1]=(st,len(out));return AdaptedOrdinary(out,tuple(spans))
    return identity(full)

@dataclass(frozen=True)
class OrdinaryCartouche:
    inner_codepoints:Tuple[int,...]; manual_tallies:Tuple[int,...]; tally_mode:str
    @property
    def has_manual_tallies(self)->bool:return any(x>0 for x in self.manual_tallies)

def parse_ordinary_body(body:str,pair:FontPairSpec,p:ParseOptions)->Optional[OrdinaryCartouche]:
    if body is None or not body.strip():return None
    mode=p.cartouche_tally_mode or str(pair.settings.get('cartoucheTallyMode','ucsur')).lower()
    if mode not in ('manual','comma','ucsur'):mode='ucsur'
    cps=[];tallies=[];cur=[]
    def flush()->bool:
        if not cur:return True
        token=''.join(cur).strip().lower();cur.clear()
        if not token:return True
        cp=_cp_for_word(token)
        if cp is None:return False
        if cp==TALLY_CP and mode=='manual':
            if cps:tallies[-1]=min(8,tallies[-1]+1)
            return True
        cps.append(cp);tallies.append(0);return True
    for ch in body:
        if ch.isspace():
            if not flush():return None
        elif ch in '.·:':
            if not flush():return None
            cps.append(COLON_CP if ch==':' else MIDDLE_DOT_CP);tallies.append(0)
        elif ch==',':
            if not flush():return None
            if not p.cartouche_comma_tally_marks:continue
            if mode=='manual':
                if cps:tallies[-1]=min(8,tallies[-1]+1)
            elif mode=='comma':cps.append(ord(','));tallies.append(0)
            else:cps.append(TALLY_CP);tallies.append(0)
        else:cur.append(ch)
    if not flush() or not cps:return None
    return OrdinaryCartouche(tuple(cps),tuple(tallies),mode)


# HarfBuzz is used only for complete-run cluster/caret geometry and vector outlines.
class _HBGlyphInfo(ctypes.Structure):
    _fields_=[('codepoint',ctypes.c_uint32),('mask',ctypes.c_uint32),('cluster',ctypes.c_uint32),('var1',ctypes.c_uint32),('var2',ctypes.c_uint32)]
class _HBGlyphPos(ctypes.Structure):
    _fields_=[('x_advance',ctypes.c_int32),('y_advance',ctypes.c_int32),('x_offset',ctypes.c_int32),('y_offset',ctypes.c_int32),('var',ctypes.c_uint32)]
@dataclass(frozen=True)
class _ShapedGlyph:
    gid:int; cluster:int; x_advance:int; y_advance:int; x_offset:int; y_offset:int

_HB=None
def _hb_lib():
    global _HB
    if _HB is not None:return _HB
    name=ctypes.util.find_library('harfbuzz')
    if not name:raise RuntimeError('libharfbuzz is required for full-renderer vector/tally geometry')
    h=ctypes.CDLL(name)
    h.hb_blob_create.argtypes=[ctypes.c_void_p,ctypes.c_uint,ctypes.c_int,ctypes.c_void_p,ctypes.c_void_p];h.hb_blob_create.restype=ctypes.c_void_p
    h.hb_face_create.argtypes=[ctypes.c_void_p,ctypes.c_uint];h.hb_face_create.restype=ctypes.c_void_p
    h.hb_face_get_upem.argtypes=[ctypes.c_void_p];h.hb_face_get_upem.restype=ctypes.c_uint
    h.hb_font_create.argtypes=[ctypes.c_void_p];h.hb_font_create.restype=ctypes.c_void_p
    h.hb_ot_font_set_funcs.argtypes=[ctypes.c_void_p];h.hb_font_set_scale.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_int]
    h.hb_buffer_create.restype=ctypes.c_void_p;h.hb_buffer_add_utf8.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_int,ctypes.c_uint,ctypes.c_int];h.hb_buffer_guess_segment_properties.argtypes=[ctypes.c_void_p]
    h.hb_feature_from_string.argtypes=[ctypes.c_char_p,ctypes.c_int,ctypes.c_void_p];h.hb_feature_from_string.restype=ctypes.c_int
    h.hb_shape.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_uint]
    h.hb_buffer_get_glyph_infos.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_uint)];h.hb_buffer_get_glyph_infos.restype=ctypes.POINTER(_HBGlyphInfo)
    h.hb_buffer_get_glyph_positions.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_uint)];h.hb_buffer_get_glyph_positions.restype=ctypes.POINTER(_HBGlyphPos)
    for f in ('hb_buffer_destroy','hb_font_destroy','hb_face_destroy','hb_blob_destroy'):getattr(h,f).argtypes=[ctypes.c_void_p]
    _HB=h;return h

class _HBFeature(ctypes.Structure):
    _fields_=[('tag',ctypes.c_uint32),('value',ctypes.c_uint32),('start',ctypes.c_uint),('end',ctypes.c_uint)]

def _shape_hb(font_path:Path,text:str,features:Sequence[str]=())->Tuple[int,Tuple[_ShapedGlyph,...]]:
    h=_hb_lib();data=Path(font_path).read_bytes();cdata=ctypes.create_string_buffer(data);blob=face=font=buf=None
    try:
        blob=h.hb_blob_create(ctypes.cast(cdata,ctypes.c_void_p),len(data),0,None,None);face=h.hb_face_create(blob,0);upem=int(h.hb_face_get_upem(face));font=h.hb_font_create(face);h.hb_ot_font_set_funcs(font);h.hb_font_set_scale(font,upem,upem);buf=h.hb_buffer_create();b=text.encode('utf-8');h.hb_buffer_add_utf8(buf,b,len(b),0,len(b));h.hb_buffer_guess_segment_properties(buf)
        arr=None;nfeat=0
        if features:
            vals=[]
            for f in features:
                ft=_HBFeature()
                if h.hb_feature_from_string(str(f).encode(),-1,ctypes.byref(ft)):vals.append(ft)
            if vals:arr=(_HBFeature*len(vals))(*vals);nfeat=len(vals)
        h.hb_shape(font,buf,arr,nfeat);n=ctypes.c_uint();infos=h.hb_buffer_get_glyph_infos(buf,ctypes.byref(n));pos=h.hb_buffer_get_glyph_positions(buf,ctypes.byref(n));glyphs=tuple(_ShapedGlyph(int(infos[i].codepoint),int(infos[i].cluster),int(pos[i].x_advance),int(pos[i].y_advance),int(pos[i].x_offset),int(pos[i].y_offset)) for i in range(n.value));return upem,glyphs
    finally:
        if buf:h.hb_buffer_destroy(buf)
        if font:h.hb_font_destroy(font)
        if face:h.hb_face_destroy(face)
        if blob:h.hb_blob_destroy(blob)

def _byte_offset_for_cp_index(text:str,index:int)->int:return len(''.join(list(text)[:max(0,index)]).encode('utf-8'))
def _caret_x_complete(font_path:Path,text:str,font_px:float,cp_index:int,features:Sequence[str]=())->float:
    upem,g=_shape_hb(font_path,text,features);boundary=_byte_offset_for_cp_index(text,cp_index);x=0
    for q in g:
        if q.cluster>=boundary:break
        x+=q.x_advance
    return x*font_px/upem

def _vector_path(font_path:Path,text:str,font_px:float,features:Sequence[str]=())->Tuple[str,float,float,float]:
    upem,glyphs=_shape_hb(font_path,text,features);tt=TTFont(str(font_path),lazy=True);order=tt.getGlyphOrder();gs=tt.getGlyphSet();scale=font_px/upem;x=0;y=0;commands=[];minx=miny=float('inf');maxx=maxy=float('-inf')
    try:
        from fontTools.pens.boundsPen import BoundsPen
        for q in glyphs:
            if q.gid>=len(order):x+=q.x_advance;continue
            name=order[q.gid]; bp=BoundsPen(gs); gs[name].draw(bp); b=bp.bounds
            tx=(x+q.x_offset)*scale; ty=-(y+q.y_offset)*scale
            if b:
                x0,y0,x1,y1=b; X0=tx+x0*scale; X1=tx+x1*scale; Y0=ty-y1*scale; Y1=ty-y0*scale;minx=min(minx,X0);maxx=max(maxx,X1);miny=min(miny,Y0);maxy=max(maxy,Y1)
            pen=SVGPathPen(gs);tpen=TransformPen(pen,(scale,0,0,-scale,tx,ty));gs[name].draw(tpen);cmd=pen.getCommands()
            if cmd:commands.append(cmd)
            x+=q.x_advance;y+=q.y_advance
    finally:tt.close()
    if minx==float('inf'):minx=miny=0;maxx=maxy=max(1,font_px)
    # Normalize to a positive local box.
    dx=-minx;dy=-miny
    # SVG path strings cannot be translated textually safely; wrap all glyph paths in a group transform later.
    return ' '.join(commands),dx,dy,max(1,maxx-minx)


def _features_for(font_px:float)->Tuple[str,...]:
    if font_px<=18:return ('ss12',)
    if font_px<=29:return ('ss13',)
    return ()

def _load_font(path:Path,size:float)->ImageFont.FreeTypeFont:
    return ImageFont.truetype(str(path),size=max(1,int(round(size))),layout_engine=ImageFont.Layout.RAQM)

def _text_bbox(text:str,font:ImageFont.FreeTypeFont,features:Sequence[str]=())->Tuple[int,int,int,int]:
    im=Image.new('L',(1,1));d=ImageDraw.Draw(im)
    kwargs={'anchor':'ls'}
    if features:kwargs['features']=list(features)
    try:return tuple(map(int,d.textbbox((0,0),text or ' ',font=font,**kwargs)))
    except Exception:return tuple(map(int,d.textbbox((0,0),text or ' ',font=font,anchor='ls')))

def _render_text_local(text:str,font_path:Path,font_px:float,features:Sequence[str],fill:_RGBA)->Tuple[Image.Image,float,str,float,float]:
    font=_load_font(font_path,font_px);l,t,r,b=_text_bbox(text,font,features);w=max(1,r-l);h=max(1,b-t);im=Image.new('RGBA',(w,h),(0,0,0,0));d=ImageDraw.Draw(im);kwargs={'anchor':'ls'}
    if features:kwargs['features']=list(features)
    try:d.text((-l,-t),text or ' ',font=font,fill=fill,**kwargs)
    except Exception:d.text((-l,-t),text or ' ',font=font,fill=fill,anchor='ls')
    baseline=-t
    try:path,dx,dy,_=_vector_path(font_path,text,font_px,features)
    except Exception:path='';dx=-l;dy=-t
    # path baseline is y=0 before normalization; translate by vector dx/dy when emitted.
    return im,float(baseline),path,float(dx),float(dy)

def _render_cartouche_text_local(text:str,font_path:Path,font_px:float,features:Sequence[str],fill:_RGBA,*,has_manual_tallies:bool=False)->Tuple[Image.Image,float,str,float,float,float]:
    """Render a cartouche using the canonical JS cartouche-canvas coordinates.

    The browser renderer crops to the actual foreground ink, then places that
    crop inside a six-pixel cartouche pad.  The resulting baseline text origin
    is therefore ``6 - ink_left``.  Manual tally ownership must use this same
    origin; measuring against the uncropped font run is what caused the old
    font-dependent horizontal displacement (most visibly with linja lipamanka).
    """
    raw,baseline,path,vdx,vdy=_render_text_local(text,font_path,font_px,features,fill)
    alpha=raw.getchannel('A');bbox=alpha.getbbox()
    if bbox:
        x0,y0,x1,y1=bbox
    else:
        x0=y0=0;x1=max(1,raw.width);y1=max(1,raw.height)
    crop=raw.crop((x0,y0,x1,y1))
    pad=6
    bottom_extra=int(math.ceil(font_px*.34)) if has_manual_tallies else 0
    out=Image.new('RGBA',(max(1,crop.width+pad*2),max(1,crop.height+pad*2+bottom_extra)),(0,0,0,0))
    out.alpha_composite(crop,(pad,pad))
    baseline=float(baseline-y0+pad)
    text_origin_x=float(pad-x0)
    # Vector outlines are normalized to their own ink bbox; place that ink at
    # the same six-pixel padded origin used by the raster cartouche.
    return out,baseline,path,float(vdx+pad),float(vdy+pad),text_origin_x


def _halo_alpha(alpha:Image.Image,width:float)->Image.Image:
    radius=max(1,int(math.ceil(width)));size=radius*2+1
    return alpha.filter(ImageFilter.MaxFilter(size))

@dataclass
class _Graphic:
    image:Image.Image; baseline:float; vector_path:str=''; vector_dx:float=0; vector_dy:float=0; tally_groups:Tuple[TallyGroup,...]=(); image_href:Optional[str]=None; decoration:Optional[Dict[str,Any]]=None
    @property
    def width(self):return self.image.width
    @property
    def height(self):return self.image.height
@dataclass
class _Logical:
    run:FullRenderRun; graphic:_Graphic


def _manual_tally_lift(pair:FontPairSpec,p:ParseOptions,px:float)->float:
    try:maxv=p.manual_tally_small_font_max_px if p.manual_tally_small_font_max_px is not None else float(pair.settings.get('manualTallySmallFontMaxPx',12))
    except Exception:maxv=12
    try:lift=p.manual_tally_small_font_lift_px if p.manual_tally_small_font_lift_px is not None else float(pair.settings.get('manualTallySmallFontLiftPx',0))
    except Exception:lift=0
    return max(0,lift) if px<=maxv else 0.0

def _detect_bottom_rule_y(alpha:Image.Image,font_px:float)->float:
    bbox=alpha.getbbox()
    if not bbox:return float(alpha.height)
    x0,y0,x1,y1=bbox;span=max(1,x1-x0);threshold=max(4,round(span*.18));pix=alpha.load();start=max(0,min(alpha.height-1,int((y0+y1)/2)))
    for y in range(alpha.height-1,start-1,-1):
        count=sum(1 for x in range(x0,x1) if pix[x,y]>8)
        if count>=threshold:return y+1.0
    return float(y1)


def _parse_size(v:Optional[str],base:float)->float:
    if not v:return float('nan')
    s=v.strip().lower()
    try:
        if s.endswith('em'):return float(s[:-2])*base
        if s.endswith('px'):return float(s[:-2])
        return float(s)
    except Exception:return float('nan')

def _load_inline_image(desc:ImageDescriptor,font_px:float)->Image.Image:
    src=None
    href=desc.src or ''
    try:
        if href.startswith('data:image/') and ',' in href:
            meta,data=href.split(',',1);raw=base64.b64decode(data) if ';base64' in meta else urllib.parse.unquote_to_bytes(data);src=Image.open(BytesIO(raw)).convert('RGBA')
        elif href and Path(href).is_file():src=Image.open(href).convert('RGBA')
    except Exception:src=None
    if src is None:src=Image.new('RGBA',(1,1),(0,0,0,0))
    w=_parse_size(desc.w,font_px);h=_parse_size(desc.h,font_px)
    if math.isnan(w) and math.isnan(h):h=font_px
    if math.isnan(w):w=max(1,h*src.width/max(1,src.height))
    if math.isnan(h):h=max(1,w*src.height/max(1,src.width))
    out=src.resize((max(1,round(w)),max(1,round(h))),Image.Resampling.BILINEAR)
    if desc.transparent:
        key=out.getpixel((0,0));tol=max(0,int(desc.wriggle));pix=out.load()
        for y in range(out.height):
            for x in range(out.width):
                c=pix[x,y]
                if all(abs(c[i]-key[i])<=tol for i in range(3)) and abs(c[3]-key[3])<=max(8,tol):pix[x,y]=(c[0],c[1],c[2],0)
    return out


def _proper_name_cps(word:str)->Optional[List[int]]:
    if not re.fullmatch(r'[A-Za-z]+',word or '') or not re.fullmatch(r'(?i)[aeijklmnostpuw]+',word or ''):return None
    bucket={}
    for w in sorted(getattr(legacy,'WORDS_TO_UNC_CODES_MAP',{})):
        if re.fullmatch(r'[a-z]+',w) and w:
            cp=_cp_for_word(w)
            if cp is not None:bucket.setdefault(w[0],cp)
    out=[]
    for c in word.lower():
        if c not in bucket:return None
        out.append(bucket[c])
    return out

def _nnp_words(digits:str)->List[str]:
    try:n=int(digits)
    except Exception:return []
    if n<0:return []
    out=[]
    def enc(x:int):
        if x==0:out.append('ala');return
        if x>=100:
            q,r=divmod(x,100);enc(q);out.append('ali')
            if r:enc(r)
            return
        while x>=20:out.append('mute');x-=20
        if x>=5:out.append('luka');x-=5
        while x>=2:out.append('tu');x-=2
        if x:out.append('wan')
    enc(n);return out

class FullRenderer:
    def __init__(self,pairs:Mapping[str,FontPairSpec],aliases:Mapping[str,str],runtime_adapters:Dict[str,Callable[[Sequence[int],FontPairSpec,float],Sequence[int]]]):
        self.pairs=dict(pairs);self.aliases=dict(aliases);self.runtime_adapters=runtime_adapters
    def pair(self,key:str)->FontPairSpec:
        if key in self.pairs:return self.pairs[key]
        norm=re.sub(r'[^a-z0-9]+','',str(key).lower());k=self.aliases.get(norm)
        if k:return self.pairs[k]
        raise KeyError(key)
    def parse_input(self,input_text:str,opts:FullRenderOptions)->DocumentAst:return parse_document(input_text,opts.parser)

    def _numeric_parsed(self,source:str,p:ParseOptions)->Optional[Dict[str,Any]]:
        try:return NanpaParser.parseNumber(source,p.numeric_mapping())
        except Exception:return None
    def _numeric_active(self,parsed:Mapping[str,Any],p:ParseOptions)->Tuple[Tuple[int,...],Tuple[int,...]]:
        full=tuple(map(int,parsed.get('codepoints') or ()));inner=tuple(map(int,parsed.get('innerCodepoints') or ()))
        if p.abbreviate_numeric_cartouches and len(full)>=3:
            ab=legacy.abbreviate_numeric_cartouche_ucsur(''.join(chr(x) for x in full[1:-1]),preserve_nene_as_en=p.preserve_numeric_cartouche_breaks_in_abbreviation)
            full=(CARTOUCHE_START,*map(ord,ab),CARTOUCHE_END);inner=tuple(map(ord,ab))
        return tuple(full),tuple(inner)

    def _glyph_run(self,source:str,cps:Sequence[int],start:int,end:int,source_kind:str,pair:FontPairSpec,o:FullRenderOptions,quoted=False,interpreted=False)->_Logical:
        canonical=tuple(map(int,cps));render=canonical
        adapter=self.runtime_adapters.get(pair.render_adapter_id)
        if adapter:render=tuple(map(int,adapter(canonical,pair,o.font_size)))
        text=''.join(chr(x) for x in render); im,baseline,path,vdx,vdy=_render_text_local(text,pair.base.path,o.font_size,(),_rgba_from_hex(o.paint.fill_style));r=FullRenderRun(kind='run' if len(canonical)>1 else 'glyph',render_mode='text',font_role='word',canonical_codepoints=canonical,render_codepoints=render,render_text=text,render_adapter_id=pair.render_adapter_id,source_text=source,source_kind=source_kind,source_start=start,source_end=end,quoted=quoted,interpreted_quote=interpreted)
        return _Logical(r,_Graphic(im,baseline,path,vdx,vdy))

    def _literal_run(self,source:str,start:int,end:int,source_kind:str,pair:FontPairSpec,o:FullRenderOptions,quoted=False,interpreted=False,unknown=False)->_Logical:
        literal_path=pair.base.path.parent/'PatrickHand-Regular.ttf';font_path=literal_path if literal_path.exists() else pair.base.path
        im,baseline,path,vdx,vdy=_render_text_local(source or ' ',font_path,o.font_size,(),_rgba_from_hex(o.paint.fill_style));dec=None
        if unknown:
            us=o.paint.unknown_text;pad=max(0,round(us.padding_px));canvas=Image.new('RGBA',(im.width+2*pad,im.height+2*pad),(0,0,0,0));canvas.alpha_composite(im,(pad,pad));draw=ImageDraw.Draw(canvas);draw.rectangle((0,0,canvas.width-1,canvas.height-1),outline=_rgba_from_hex(us.color),width=max(1,round(us.line_width_px)));im=canvas;baseline+=pad;dec={'outline':True,'color':us.color}
        r=FullRenderRun(kind='text',render_mode='raster',font_role='literal',render_adapter_id=pair.render_adapter_id,source_text=source,source_kind=source_kind,source_start=start,source_end=end,quoted=quoted,interpreted_quote=interpreted,unrecognized=unknown,render_text=source)
        return _Logical(r,_Graphic(im,baseline,path,vdx,vdy,decoration=dec))

    def _numeric_run(self,source:str,parsed:Mapping[str,Any],start:int,end:int,source_kind:str,pair:FontPairSpec,o:FullRenderOptions)->_Logical:
        full,inner=self._numeric_active(parsed,o.parser);adapted=adapt_numeric_cartouche(full,pair.render_adapter_id,pair.render_adapter_settings);features=_features_for(o.font_size);im,baseline,path,vdx,vdy,_=_render_cartouche_text_local(adapted.text,pair.companion.path,o.font_size,features,_rgba_from_hex(o.paint.fill_style));base=int(parsed.get('numberBase') or 10);r=FullRenderRun(kind='cartouche',render_mode='raster',font_role='number',numeric_cartouche=True,hex_cartouche=bool(parsed.get('isHex')),binary_cartouche=bool(parsed.get('isBinary')),numeric_base=base,opener_codepoint=inner[0] if inner else None,closer_codepoint=inner[-1] if inner else None,canonical_codepoints=inner,render_codepoints=tuple(map(ord,adapted.text)),render_text=adapted.text,render_adapter_id=pair.render_adapter_id,source_text=source,source_kind=source_kind,source_start=start,source_end=end)
        return _Logical(r,_Graphic(im,baseline,path,vdx,vdy))

    def _cartouche_run(self,source:str,oc:OrdinaryCartouche,start:int,end:int,source_kind:str,pair:FontPairSpec,o:FullRenderOptions)->_Logical:
        adapted=_adapt_ordinary(pair,oc.inner_codepoints);fill=_rgba_from_hex(o.paint.fill_style);im,baseline,path,vdx,vdy,owner_origin_x=_render_cartouche_text_local(adapted.text,pair.base.path,o.font_size,(),fill,has_manual_tallies=oc.has_manual_tallies);groups=[]
        if oc.has_manual_tallies:
            # Complete-run ownership: U+F199E is never inserted for manual-tally
            # fonts.  Canonical spans map each owner to its adapted substring.  The
            # owner advance is translated by the *same* ink-crop/pad text origin
            # used for raster drawing, matching the canonical browser renderer.
            #
            # IMPORTANT: do not paint the tally strokes into the cartouche image
            # itself.  Manual tally marks are renderer-owned geometry so the halo
            # pass can draw a rounded group backing first and the foreground pass
            # can then draw the non-halo tally strokes on top, matching the JS
            # reference for both PNG and SVG/PDF.
            bottom=_detect_bottom_rule_y(im.getchannel('A'),o.font_size);lift=_manual_tally_lift(pair,o.parser,o.font_size);top=bottom-lift;bot=top+o.font_size*.10;stroke=max(1.5,o.font_size*.045);gap=o.font_size*.075
            for i,count in enumerate(oc.manual_tallies):
                count=max(0,min(8,int(count)))
                if count<=0:continue
                span=adapted.canonical_spans[i+1];left=owner_origin_x+_caret_x_complete(pair.base.path,adapted.text,o.font_size,span[0]);right=owner_origin_x+_caret_x_complete(pair.base.path,adapted.text,o.font_size,span[1]);center=(left+right)/2;total=stroke if count<=1 else count*stroke+(count-1)*gap;first=center-total/2+stroke/2;centers=tuple(first+k*(stroke+gap) for k in range(count));need_h=int(math.ceil(bot+2));
                if need_h>im.height:
                    ext=Image.new('RGBA',(im.width,need_h),(0,0,0,0));ext.alpha_composite(im);im=ext
                groups.append(TallyGroup(i,count,left,right,center,top,bot,stroke,centers))
        canonical=tuple(oc.inner_codepoints);semantic=tuple(oc.manual_tallies) if oc.has_manual_tallies else ();r=FullRenderRun(kind='cartouche',render_mode='raster',font_role='cartouche',opener_codepoint=CARTOUCHE_START,closer_codepoint=CARTOUCHE_END,canonical_codepoints=canonical,render_codepoints=tuple(map(ord,adapted.text)),render_text=adapted.text,render_adapter_id=pair.render_adapter_id,source_text=source,source_kind=source_kind,source_start=start,source_end=end,manual_tallies=semantic)
        return _Logical(r,_Graphic(im,baseline,path,vdx,vdy,tuple(groups)))

    def _image_run(self,seg:DocumentSegment,pair:FontPairSpec,o:FullRenderOptions)->_Logical:
        d=seg.image or ImageDescriptor();im=_load_inline_image(d,o.font_size);baseline=im.height*.75 if d.valign.lower()=='center' else im.height;r=FullRenderRun(kind='cartouche',render_mode='raster',font_role='cartouche',render_adapter_id=pair.render_adapter_id,source_kind='image',source_start=seg.source_start,source_end=seg.source_end,image_alt=d.alt)
        return _Logical(r,_Graphic(im,baseline,image_href=d.src))

    def _emit_core(self,core:str,start:int,end:int,kind:str,seg_index:int,out:List[_Logical],pair:FontPairSpec,o:FullRenderOptions):
        direct=[ord(c) for c in core]
        if direct and all((0xF1900<=cp<=0xF19FF) or cp in (OPEN_QUOTE_CP,CLOSE_QUOTE_CP) for cp in direct):out.append(self._glyph_run(core,direct,start,end,kind,pair,o));return
        parsed=self._numeric_parsed(core,o.parser)
        if parsed:
            if o.parser.nasin_nanpa_pona and re.fullmatch(r'\+?[0-9]+',core):
                for w in _nnp_words(core.replace('+','')):
                    cp=_cp_for_word(w)
                    if cp is not None:out.append(self._glyph_run(core,[cp],start,end,kind,pair,o))
            else:out.append(self._numeric_run(core,parsed,start,end,kind,pair,o))
            return
        if o.parser.renderer_mode in ('sitelen-pona-ascii-extended','sitelen-seli-kiwen') and ('-' in core or '+' in core):
            pieces=re.split(r'([+-])',core);cps=[];ok=True
            for p in pieces:
                if not p:continue
                if p=='-':cps.append(STACK_JOINER_CP)
                elif p=='+':cps.append(NEST_JOINER_CP)
                else:
                    cp=_cp_for_word(re.sub(r'[^a-z0-9<>^.]','',p.lower()))
                    if cp is None:ok=False;break
                    cps.append(cp)
            if ok:out.append(self._glyph_run(core,cps,start,end,kind,pair,o));return
        if o.parser.auto_cartouche_standalone_proper_names and core and core[0].isupper():
            cps=_proper_name_cps(core)
            if cps:out.append(self._cartouche_run(core,OrdinaryCartouche(tuple(cps),tuple(0 for _ in cps),'ucsur'),start,end,kind,pair,o));return
        cp=_cp_for_word(re.sub(r'[^a-z0-9<>^.]','',core.lower()))
        if cp is not None:out.append(self._glyph_run(core,[cp],start,end,kind,pair,o));return
        if o.parser.show_unknown_text:
            literal=core;ls=start;le=end
            if o.parser.renderer_mode=='standard-sitelen-pona-ascii-core' and len(literal)>=2 and literal.startswith("'") and literal.endswith("'"):literal=literal[1:-1];ls+=1;le-=1
            out.append(self._literal_run(literal,ls,le,kind,pair,o,unknown=True))

    def _parse_text(self,text:str,base:int,kind:str,seg_index:int,out:List[_Logical],pair:FontPairSpec,o:FullRenderOptions):
        if not text:return
        trimmed=text.strip()
        if not trimmed:return
        leading=text.index(trimmed);raw=parse_raw_unicode_sequence(trimmed)
        if raw is not None:out.append(self._glyph_run(trimmed,raw,base+leading,base+leading+len(trimmed),kind,pair,o));return
        parsed=self._numeric_parsed(trimmed,o.parser)
        if parsed:
            if o.parser.nasin_nanpa_pona and re.fullmatch(r'\+?[0-9]+',trimmed):
                for w in _nnp_words(trimmed.replace('+','')):
                    cp=_cp_for_word(w)
                    if cp is not None:out.append(self._glyph_run(trimmed,[cp],base+leading,base+leading+len(trimmed),kind,pair,o))
            else:out.append(self._numeric_run(trimmed,parsed,base+leading,base+leading+len(trimmed),kind,pair,o))
            return
        for m in re.finditer(r'\S+',text):
            token=m.group();start=base+m.start();end=base+m.end();core=token
            while core.startswith(('(','{')):core=core[1:];start+=1
            trail=''
            while core and core[-1] in ').;:!?}':
                c=core[-1]
                if c=='.' and re.search(r'[0-9]',core):break
                trail=c+trail;core=core[:-1];end-=1
            if core.endswith('.') and len(core)>1 and re.search(r'[0-9]',core[:-1]):trail='.'+trail;core=core[:-1];end-=1
            if core:self._emit_core(core,start,end,kind,seg_index,out,pair,o)
            for j,c in enumerate(trail):
                cp=MIDDLE_DOT_CP if c=='.' else COLON_CP if c==':' else None
                if cp is not None:out.append(self._glyph_run(c,[cp],end+j,end+j+1,kind,pair,o))

    def _parse_bracket(self,body:str,source_start:int,kind:str,seg_index:int,out:List[_Logical],pair:FontPairSpec,o:FullRenderOptions):
        trimmed=(body or '').strip();parsed=self._numeric_parsed('['+trimmed+']',o.parser)
        if parsed:out.append(self._numeric_run(trimmed,parsed,source_start,source_start+len(body),kind,pair,o));return
        oc=parse_ordinary_body(trimmed,pair,o.parser)
        if oc:out.append(self._cartouche_run(trimmed,oc,source_start,source_start+len(body),kind,pair,o))
        elif o.parser.show_unknown_text:out.append(self._literal_run(trimmed,source_start,source_start+len(body),kind,pair,o,unknown=True))

    def _parse_quote(self,seg:DocumentSegment,seg_index:int,out:List[_Logical],pair:FontPairSpec,o:FullRenderOptions):
        q=(seg.value or '').replace('\\"','"').replace('\\\\','\\').replace('\\t','    ').replace('\\n','\n')
        if o.parser.interpret_double_quotes_as_te_to:
            out.append(self._glyph_run('te',[OPEN_QUOTE_CP],seg.source_start,seg.source_start+1,'interpretedQuote',pair,o,interpreted=True));before=len(out);self._parse_text(q,seg.source_start+1,'interpretedQuote',seg_index,out,pair,o)
            for i in range(before,len(out)):out[i]=_Logical(replace(out[i].run,interpreted_quote=True),out[i].graphic)
            out.append(self._glyph_run('to',[CLOSE_QUOTE_CP],max(seg.source_start+1,seg.source_end-1),seg.source_end,'interpretedQuote',pair,o,interpreted=True))
        else:out.append(self._literal_run(q,seg.source_start,seg.source_end,'quote',pair,o,quoted=True))

    def prepare(self,input_text:str,o:FullRenderOptions)->Tuple[FullRenderPlan,List[Tuple[FullRenderRun,_Graphic,float,float]]]:
        pair=self.pair(o.font_key);ast=parse_document(input_text,o.parser);logical_lines=[];any_abbr=False;first_parsed=None
        for line in ast.lines:
            runs=[]
            for si,seg in enumerate(line.children):
                if seg.kind=='text':self._parse_text(seg.value or '',seg.source_start,'text',si,runs,pair,o)
                elif seg.kind=='bracket':self._parse_bracket(seg.value or '',seg.source_start,'bracket',si,runs,pair,o)
                elif seg.kind=='quote':self._parse_quote(seg,si,runs,pair,o)
                elif seg.kind=='image':runs.append(self._image_run(seg,pair,o))
            for l in runs:
                if l.run.numeric_cartouche:
                    p=self._numeric_parsed(l.run.source_text or '',o.parser)
                    if p and first_parsed is None:first_parsed=p
                    any_abbr|=o.parser.abbreviate_numeric_cartouches
            logical_lines.append(runs)
        line_gap=o.layout.line_gap(o.font_size);pad=o.padding_px;line_widths=[];line_asc=[];line_desc=[];maxw=0
        for line in logical_lines:
            x=0;asc=0;desc=0;first=True
            for l in line:
                if not first:x+=o.layout.cartouche_lead_gap(o.font_size) if (l.run.font_role=='cartouche' or l.run.numeric_cartouche) else o.layout.glyph_gap(o.font_size)
                first=False;x+=l.graphic.width;asc=max(asc,l.graphic.baseline);desc=max(desc,max(0,l.graphic.height-l.graphic.baseline))
            h=max(o.font_size,asc+desc)
            if not line:asc=o.font_size*.82;desc=h-asc
            line_widths.append(x);line_asc.append(asc);line_desc.append(desc);maxw=max(maxw,x)
        width=max(1,math.ceil(maxw+2*pad));total=2*pad+sum(max(o.font_size,line_asc[i]+line_desc[i]) for i in range(len(logical_lines)))+line_gap*max(0,len(logical_lines)-1);height=max(1,math.ceil(total));placed=[];allruns=[];lineplans=[];y=pad
        for li,line in enumerate(logical_lines):
            lw=line_widths[li];asc=line_asc[li];desc=line_desc[li];lh=max(o.font_size,asc+desc);x=pad+((maxw-lw)/2 if o.layout.align=='center' else (maxw-lw) if o.layout.align=='right' else 0);line_start=x;lr=[];first=True
            for ri,l in enumerate(line):
                if not first:x+=o.layout.cartouche_lead_gap(o.font_size) if (l.run.font_role=='cartouche' or l.run.numeric_cartouche) else o.layout.glyph_gap(o.font_size)
                first=False;ty=y+asc-l.graphic.baseline;tx=x;groups=tuple(TallyGroup(g.owner_index,g.count,g.owner_left_px+tx,g.owner_right_px+tx,g.center_x_px+tx,g.top_y_px+ty,g.bottom_y_px+ty,g.stroke_width_px,tuple(c+tx for c in g.stroke_centers_px)) for g in l.graphic.tally_groups);r=replace(l.run,id=f'L{li}R{ri}',line_index=li,run_index=ri,tally_groups=groups,x_px=tx,y_px=ty,width_px=l.graphic.width,height_px=l.graphic.height,baseline_y_px=y+asc);placed.append((r,l.graphic,tx,ty));allruns.append(r);lr.append(r);x+=l.graphic.width
            lineplans.append(FullRenderLinePlan(li,ast.lines[li].source_line_index,ast.lines[li].sentence_index_in_source_line,line_start,y,lw,lh,y+asc,asc,desc,tuple(lr)));y+=lh+(line_gap if li+1<len(logical_lines) else 0)
        plan=FullRenderPlan(input_text,pair.font_key,any_abbr,width,height,_features_for(o.font_size),tuple(allruns),first_parsed,(),ast,tuple(lineplans));return plan,placed

    def render_canvas(self,input_text:str,o:FullRenderOptions)->CanvasRenderResult:
        plan,placed=self.prepare(input_text,o);canvas=Image.new('RGBA',(plan.width,plan.height),(0,0,0,0));
        # Build foreground from the run images only.  For manual-tally cartouches,
        # the run image intentionally excludes the renderer-owned tally strokes so
        # their halo backing and foreground lines can be painted in separate passes
        # like the JavaScript reference.
        fg=Image.new('RGBA',canvas.size,(0,0,0,0))
        tally_runs=[]
        for r,g,x,y in placed:
            fg.alpha_composite(g.image,(round(x),round(y)))
            if r.tally_groups:
                tally_runs.append(r)
        if o.paint.halo_enabled:
            hw=o.paint.halo_width_px or max(2,min(24,round(max(8,o.font_size)*.10)))
            alpha=_halo_alpha(fg.getchannel('A'),hw);halo=Image.new('RGBA',canvas.size,_rgba_from_hex(o.paint.halo_color));halo.putalpha(alpha);canvas.alpha_composite(halo)
            if tally_runs:
                draw=ImageDraw.Draw(canvas)
                halo_fill=_rgba_from_hex(o.paint.halo_color)
                pad_x=hw*.85;pad_bottom=hw*.85;radius=max(1.25,min(hw,o.font_size*.045))
                for r in tally_runs:
                    for tg in r.tally_groups:
                        if not tg.stroke_centers_px:continue
                        left=tg.stroke_centers_px[0]-tg.stroke_width_px/2
                        right=tg.stroke_centers_px[-1]+tg.stroke_width_px/2
                        top=tg.top_y_px
                        bottom=tg.bottom_y_px
                        draw.rounded_rectangle((left-pad_x, top, right+pad_x, bottom+pad_bottom), radius=radius, fill=halo_fill)
        canvas.alpha_composite(fg)
        if tally_runs:
            draw=ImageDraw.Draw(canvas)
            fill=_rgba_from_hex(o.paint.fill_style)
            for r in tally_runs:
                for tg in r.tally_groups:
                    width=max(1,round(tg.stroke_width_px))
                    for cx in tg.stroke_centers_px:
                        draw.line((cx,tg.top_y_px,cx,tg.bottom_y_px),fill=fill,width=width)
        return CanvasRenderResult(canvas,plan if o.include_plan else None,plan.font_key)

    def render_svg(self,input_text:str,o:FullRenderOptions)->Tuple[str,FullRenderPlan]:
        plan,placed=self.prepare(input_text,o);parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{plan.width}" height="{plan.height}" viewBox="0 0 {plan.width} {plan.height}">']
        for r,g,x,y in placed:
            if g.image_href is not None:
                parts.append(f'<image x="{x:.3f}" y="{y:.3f}" width="{g.width}" height="{g.height}" href="{html.escape(g.image_href,quote=True)}"/>');continue
            # Manual-tally halo is a renderer-owned group backing.  Paint it before
            # the cartouche/text foreground so it can never overwrite the bottom rule.
            if o.paint.halo_enabled and r.tally_groups:
                hw=o.paint.halo_width_px or max(2,min(24,round(max(8,o.font_size)*.10)));pad_x=hw*.85;pad_bottom=hw*.85;radius=max(1.25,min(hw,o.font_size*.045))
                for tg in r.tally_groups:
                    if not tg.stroke_centers_px:continue
                    left=tg.stroke_centers_px[0]-tg.stroke_width_px/2;right=tg.stroke_centers_px[-1]+tg.stroke_width_px/2;top=tg.top_y_px;bottom=tg.bottom_y_px
                    parts.append(f'<rect x="{left-pad_x:.3f}" y="{top:.3f}" width="{right-left+2*pad_x:.3f}" height="{max(1,bottom-top+pad_bottom):.3f}" rx="{radius:.3f}" ry="{radius:.3f}" fill="{o.paint.halo_color}"/>')
            if g.vector_path:
                tx=x+g.vector_dx;ty=y+g.vector_dy
                if o.paint.halo_enabled:
                    hw=o.paint.halo_width_px or max(2,min(24,round(max(8,o.font_size)*.10)));parts.append(f'<path d="{g.vector_path}" transform="translate({tx:.3f} {ty:.3f})" fill="{o.paint.fill_style}" stroke="{o.paint.halo_color}" stroke-width="{2*hw:.3f}" stroke-linejoin="round" stroke-linecap="round"/>')
                else:parts.append(f'<path d="{g.vector_path}" transform="translate({tx:.3f} {ty:.3f})" fill="{o.paint.fill_style}"/>')
            # Manual tally foreground is painted after the cartouche/text using
            # butt-ended strokes, matching the browser reference renderer.
            for tg in r.tally_groups:
                for cx in tg.stroke_centers_px:
                    parts.append(f'<path d="M {cx:.3f} {tg.top_y_px:.3f} L {cx:.3f} {tg.bottom_y_px:.3f}" fill="none" stroke="{o.paint.fill_style}" stroke-width="{tg.stroke_width_px:.3f}" stroke-linecap="butt"/>')
            if r.unrecognized and g.decoration:
                us=o.paint.unknown_text;parts.append(f'<rect x="{x:.3f}" y="{y:.3f}" width="{g.width:.3f}" height="{g.height:.3f}" fill="none" stroke="{us.color}" stroke-width="{us.line_width_px:.3f}"/>')
        parts.append('</svg>');return ''.join(parts),plan

    def render_pdf(self,input_text:str,o:FullRenderOptions)->Tuple[bytes,FullRenderPlan]:
        svg,plan=self.render_svg(input_text,o)
        try:
            import cairosvg
            pdf=cairosvg.svg2pdf(bytestring=svg.encode('utf-8'))
        except Exception:
            # Valid fallback, while full qualification requires CairoSVG for vector PDF.
            im=self.render_canvas(input_text,o).image.convert('RGB');b=BytesIO();im.save(b,format='PDF');pdf=b.getvalue()
        return pdf,plan

    def vector_document(self,input_text:str,o:FullRenderOptions)->VectorDocument:
        plan,placed=self.prepare(input_text,o);els=[]
        for r,g,x,y in placed:
            if g.image_href is not None:els.append(VectorElement('image',r.id,None,None,g.image_href,x,y,g.width,g.height))
            elif g.vector_path:els.append(VectorElement('path',r.id,g.vector_path,o.paint.fill_style,None,x+g.vector_dx,y+g.vector_dy,g.width,g.height))
            for tg in r.tally_groups:
                for cx in tg.stroke_centers_px:els.append(VectorElement('path',r.id,f'M {cx:.3f} {tg.top_y_px:.3f} L {cx:.3f} {tg.bottom_y_px:.3f}',o.paint.fill_style,None,0,0,0,0))
        return VectorDocument(plan.width,plan.height,tuple(els),plan.diagnostics,plan)


    def render_run_to_new_canvas(self,run:FullRenderRun,o:FullRenderOptions)->CanvasRenderResult:
        """Render one already-measured semantic run on a fresh Pillow surface."""
        pair=self.pair(o.font_key)
        fill=_rgba_from_hex(o.paint.fill_style)
        if run.font_role=='number':
            font_path=pair.companion.path;features=_features_for(o.font_size)
        elif run.font_role=='literal':
            candidate=pair.base.path.parent/'PatrickHand-Regular.ttf';font_path=candidate if candidate.exists() else pair.base.path;features=()
        else:
            font_path=pair.base.path;features=()
        text=run.render_text or ''.join(chr(cp) for cp in run.render_codepoints)
        im,baseline,_,_,_=_render_text_local(text or ' ',font_path,o.font_size,features,fill)
        # Recreate synthetic tallies using run-local geometry when present.  Plan
        # tally groups are absolute, so translate them back by the run origin.
        if run.tally_groups:
            d=ImageDraw.Draw(im)
            for tg in run.tally_groups:
                top=tg.top_y_px-run.y_px;bot=tg.bottom_y_px-run.y_px
                for cx in tg.stroke_centers_px:
                    d.line((cx-run.x_px,top,cx-run.x_px,bot),fill=fill,width=max(1,round(tg.stroke_width_px)))
        pad=max(0,o.padding_px);canvas=Image.new('RGBA',(im.width+2*pad,im.height+2*pad),(0,0,0,0));canvas.alpha_composite(im,(pad,pad))
        return CanvasRenderResult(canvas,None,pair.font_key)

    def render_text_to_new_canvas(self,text:str,o:FullRenderOptions)->CanvasRenderResult:
        return self.render_canvas(text,o)

    def render_text_to_canvas(self,target:Image.Image,x:float,y:float,text:str,o:FullRenderOptions)->Image.Image:
        result=self.render_canvas(text,replace(o,padding_px=0,include_plan=False))
        if target.mode!='RGBA':
            raise ValueError('target image must be RGBA so alpha compositing is deterministic')
        target.alpha_composite(result.image,(round(x),round(y)))
        return target

    @staticmethod
    def _ucsur_lines_to_source(lines:Sequence[Sequence[int]])->str:
        rendered=[]
        for line in lines:
            rendered.append(' '.join(f'U+{int(cp):04X}' for cp in line))
        return '\n'.join(rendered)

    def render_ucsur_to_new_canvas(self,lines:Sequence[Sequence[int]],o:FullRenderOptions)->CanvasRenderResult:
        return self.render_canvas(self._ucsur_lines_to_source(lines),o)

    def render_ucsur_to_canvas(self,target:Image.Image,x:float,y:float,lines:Sequence[Sequence[int]],o:FullRenderOptions)->Image.Image:
        return self.render_text_to_canvas(target,x,y,self._ucsur_lines_to_source(lines),o)
