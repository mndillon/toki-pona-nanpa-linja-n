"""High-level production facade for nanpa-linja-n.

The established snake_case numeric facade remains frozen for approved golden
parity.  The additive full-document/JavaScript-style surface delegates to the
native Python FullRenderer and does not execute JavaScript at runtime.
"""
from __future__ import annotations

from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
from threading import Lock
from typing import Any, Dict, Iterable, Mapping, Optional, Tuple
import re

from PIL import Image, ImageFont, features

from .parser import NanpaParser
from .font_registry import FontManifest, FontPairSpec, load_font_manifest
from .font_adapters import AdaptedRun, adapt_numeric_cartouche
from . import number_glyph_renderer as _renderer
from .full_renderer import (
    FullRenderer,
    FullRenderOptions,
    FullRenderPlan,
    FullRenderRun,
    CanvasRenderResult,
    VectorDocument,
    DocumentAst,
    ast_to_text as _ast_to_text,
)

DEFAULT_FONT_KEY = "nasinNanpa"
DEFAULT_FONT_SIZE = 56
DEFAULT_OUTER_PADDING = 4
DEFAULT_PARSER_OPTIONS: Dict[str, Any] = {
    "mode": "uniform",
    "mixedStyle": "short",
    "relaxedNanpaLinjanParsing": True,
    "relaxedNanpaLinjanRendering": True,
    "nanpaColonParsing": True,
    "nanpaColonRendering": True,
    "enableHexParsing": True,
    "enableBinaryParsing": True,
    "numericMode": "uniform",
}

_RGBA = Tuple[int, int, int, int]
_ALIAS_RE = re.compile(r"[^a-z0-9]+")


def _package_asset_root() -> Path:
    return Path(__file__).resolve().parent / "assets"


def _normalize_alias(value: Any) -> str:
    return _ALIAS_RE.sub("", str(value or "").strip().lower())


def _merged_options(base: Mapping[str, Any], override: Optional[Mapping[str, Any]]) -> Dict[str, Any]:
    out = dict(base)
    if override:
        out.update(dict(override))
    return out


def _display_codepoints(
    parsed: Mapping[str, Any],
    *,
    abbreviate: bool,
    preserve_numeric_cartouche_breaks: bool,
) -> tuple[int, ...]:
    full = tuple(int(cp) for cp in (parsed.get("codepoints") or ()))
    if len(full) < 3 or full[0] != 0xF1990 or full[-1] != 0xF1991:
        raise ValueError("Parsed value did not produce a complete canonical numeric cartouche")
    if not abbreviate:
        return full

    inner = "".join(chr(cp) for cp in full[1:-1])
    abbreviated_inner = _renderer.abbreviate_numeric_cartouche_ucsur(
        inner,
        preserve_nene_as_en=bool(preserve_numeric_cartouche_breaks),
    )
    abbreviated = (0xF1990, *(ord(ch) for ch in abbreviated_inner), 0xF1991)
    if abbreviated == full:
        raise ValueError("Abbreviated cartouche is identical to its full cartouche")
    if len(abbreviated) >= len(full):
        raise ValueError(
            f"Abbreviated cartouche is not shorter than full cartouche "
            f"({len(abbreviated)} >= {len(full)})"
        )
    return abbreviated


def _load_raqm_font(path: Path, size: int) -> ImageFont.FreeTypeFont:
    if not features.check("raqm"):
        raise RuntimeError(
            "Pillow was built without RAQM. Correct nanpa-linja-n production-font "
            "shaping requires Pillow with RAQM/HarfBuzz support."
        )
    return ImageFont.truetype(
        str(path),
        size=int(size),
        layout_engine=ImageFont.Layout.RAQM,
    )


@dataclass(frozen=True)
class FontInfo:
    key: str
    label: str
    parser_mode: str
    render_adapter_id: str
    base_family: str
    companion_family: str
    companion_path: Path


@dataclass(frozen=True)
class RenderPlan:
    input: Any
    parsed: Mapping[str, Any]
    font: FontInfo
    canonical_codepoints: tuple[int, ...]
    render_text: str
    render_adapter_id: str
    legacy_ascii: bool
    font_size: int
    outer_padding: int
    open_type_features: tuple[str, ...]
    abbreviated: bool
    preserve_numeric_cartouche_breaks: bool

    @property
    def render_codepoints(self) -> tuple[int, ...]:
        return tuple(ord(ch) for ch in self.render_text)


@dataclass
class RenderResult:
    image: Image.Image
    plan: RenderPlan

    @property
    def width(self) -> int:
        return int(self.image.width)

    @property
    def height(self) -> int:
        return int(self.image.height)

    @property
    def font_key(self) -> str:
        return self.plan.font.key

    @property
    def render_adapter_id(self) -> str:
        return self.plan.render_adapter_id

    def png_bytes(self, *, optimize: bool = False, compress_level: int = 9) -> bytes:
        buffer = BytesIO()
        self.image.save(
            buffer,
            format="PNG",
            optimize=bool(optimize),
            compress_level=max(0, min(9, int(compress_level))),
        )
        return buffer.getvalue()

    def save_png(self, path: str | Path, *, optimize: bool = False, compress_level: int = 9) -> Path:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(self.png_bytes(optimize=optimize, compress_level=compress_level))
        return target


class NanpaLinjaN:
    """One-stop Python API for parsing and rendering nanpa-linja-n cartouches.

    The default instance uses the production font assets bundled with this
    package.  Supplying ``project_root`` keeps the existing source-tree/testing
    layout available for advanced callers.
    """

    def __init__(
        self,
        *,
        project_root: str | Path | None = None,
        manifest_path: str | Path | None = None,
        default_font: str = DEFAULT_FONT_KEY,
        default_font_size: int = DEFAULT_FONT_SIZE,
        parser_options: Optional[Mapping[str, Any]] = None,
    ) -> None:
        if project_root is None:
            root = _package_asset_root()
            mp = Path(manifest_path) if manifest_path is not None else root / "fonts" / "preloaded-font-pairs.manifest.json"
        else:
            root = Path(project_root).resolve()
            mp = Path(manifest_path) if manifest_path is not None else None

        manifest = load_font_manifest(root, mp, required=True)
        assert manifest is not None
        self._root = root
        self._manifest: FontManifest = manifest
        self._pairs = {pair.font_key: pair for pair in manifest.pairs}
        self._aliases: Dict[str, str] = {}
        for pair in manifest.pairs:
            for candidate in (
                pair.font_key,
                pair.label,
                pair.base.family,
                pair.companion.family,
            ):
                alias = _normalize_alias(candidate)
                if alias:
                    self._aliases.setdefault(alias, pair.font_key)
        self._default_font = self.normalize_font_key(default_font)
        self._default_font_size = max(8, int(default_font_size))
        self._parser_options = _merged_options(DEFAULT_PARSER_OPTIONS, parser_options)
        # The full renderer is additive to the frozen numeric facade.  Keeping
        # the legacy numeric path intact preserves the approved 128-artifact
        # Python golden matrix while exposing the complete document renderer.
        self._runtime_render_adapters: Dict[str, Any] = {}
        self._full_renderer = FullRenderer(self._pairs, self._aliases, self._runtime_render_adapters)

    @classmethod
    def create(cls, **kwargs: Any) -> "NanpaLinjaN":
        """Parity-friendly factory matching the JavaScript/TypeScript facade name."""
        return cls(**kwargs)

    @property
    def manifest(self) -> FontManifest:
        return self._manifest

    @property
    def fonts(self) -> tuple[FontInfo, ...]:
        return self.list_fonts()

    def normalize_font_key(self, font: str | None) -> str:
        requested = str(font or DEFAULT_FONT_KEY).strip()
        if requested in self._pairs:
            return requested
        key = self._aliases.get(_normalize_alias(requested))
        if key:
            return key
        raise KeyError(f"Unknown production font: {requested}")

    def _pair(self, font: str | None) -> FontPairSpec:
        key = self.normalize_font_key(font or self._default_font)
        return self._pairs[key]

    @staticmethod
    def _font_info(pair: FontPairSpec) -> FontInfo:
        return FontInfo(
            key=pair.font_key,
            label=pair.label,
            parser_mode=pair.parser_mode,
            render_adapter_id=pair.render_adapter_id,
            base_family=pair.base.family,
            companion_family=pair.companion.family,
            companion_path=pair.companion.path,
        )

    def list_fonts(self) -> tuple[FontInfo, ...]:
        return tuple(self._font_info(pair) for pair in self._manifest.pairs)

    def get_font_info(self, font: str) -> FontInfo:
        return self._font_info(self._pair(font))

    def parse(self, value: Any, *, parser_options: Optional[Mapping[str, Any]] = None) -> Dict[str, Any]:
        opts = _merged_options(self._parser_options, parser_options)
        parsed = NanpaParser.parseNumber(value, opts)
        if not isinstance(parsed, dict):
            raise ValueError(f"Not a valid nanpa-linja-n numeric input: {value!r}")
        return parsed

    def build_render_plan(
        self,
        value: Any,
        *,
        font: str | None = None,
        font_size: int | None = None,
        abbreviate: bool = False,
        preserve_numeric_cartouche_breaks: bool = True,
        outer_padding: int = DEFAULT_OUTER_PADDING,
        parser_options: Optional[Mapping[str, Any]] = None,
    ) -> RenderPlan:
        pair = self._pair(font)
        parsed = self.parse(value, parser_options=parser_options)
        canonical = _display_codepoints(
            parsed,
            abbreviate=bool(abbreviate),
            preserve_numeric_cartouche_breaks=bool(preserve_numeric_cartouche_breaks),
        )
        adapted: AdaptedRun = adapt_numeric_cartouche(
            canonical,
            pair.render_adapter_id,
            pair.render_adapter_settings,
        )
        size = max(8, int(font_size if font_size is not None else self._default_font_size))
        probe_font = _load_raqm_font(pair.companion.path, size)
        ot_features = tuple(_renderer.numeric_cartouche_opentype_features_for_font(probe_font))
        return RenderPlan(
            input=value,
            parsed=parsed,
            font=self._font_info(pair),
            canonical_codepoints=canonical,
            render_text=adapted.text,
            render_adapter_id=adapted.adapter_id,
            legacy_ascii=adapted.legacy_ascii,
            font_size=size,
            outer_padding=max(0, int(outer_padding)),
            open_type_features=ot_features,
            abbreviated=bool(abbreviate),
            preserve_numeric_cartouche_breaks=bool(preserve_numeric_cartouche_breaks),
        )

    def render(
        self,
        value: Any,
        *,
        font: str | None = None,
        font_size: int | None = None,
        abbreviate: bool = False,
        preserve_numeric_cartouche_breaks: bool = True,
        outer_padding: int = DEFAULT_OUTER_PADDING,
        fg: _RGBA = (0, 0, 0, 255),
        background: _RGBA = (0, 0, 0, 0),
        parser_options: Optional[Mapping[str, Any]] = None,
    ) -> RenderResult:
        plan = self.build_render_plan(
            value,
            font=font,
            font_size=font_size,
            abbreviate=abbreviate,
            preserve_numeric_cartouche_breaks=preserve_numeric_cartouche_breaks,
            outer_padding=outer_padding,
            parser_options=parser_options,
        )
        font_obj = _load_raqm_font(plan.font.companion_path, plan.font_size)
        image = _renderer.render_shaped_ucsur_run_to_new_base(
            plan.render_text,
            font=font_obj,
            outer_padding=plan.outer_padding,
            fg=fg,
            background=background,
            features=list(plan.open_type_features),
        )
        return RenderResult(image=image, plan=plan)

    def render_to_image(self, value: Any, **kwargs: Any) -> Image.Image:
        return self.render(value, **kwargs).image

    def render_to_png(self, value: Any, **kwargs: Any) -> bytes:
        return self.render(value, **kwargs).png_bytes()

    def save_png(self, value: Any, path: str | Path, **kwargs: Any) -> Path:
        return self.render(value, **kwargs).save_png(path)

    # ------------------------------------------------------------------
    # Full JavaScript-reference document renderer surface.
    # ------------------------------------------------------------------
    def _full_options(
        self,
        options: Optional[Mapping[str, Any]] = None,
        *,
        font: str | None = None,
        font_size: float | None = None,
        padding_px: int | None = None,
        parser_options: Optional[Mapping[str, Any]] = None,
        layout: Optional[Mapping[str, Any]] = None,
        paint: Optional[Mapping[str, Any]] = None,
        include_plan: bool | None = None,
    ) -> FullRenderOptions:
        cfg: Dict[str, Any] = dict(options or {})
        resolved_font = self.normalize_font_key(font or cfg.get("font") or cfg.get("fontKey") or self._default_font)
        cfg["font"] = resolved_font
        if font_size is not None:
            cfg["fontSize"] = float(font_size)
        elif "fontSize" not in cfg and not (isinstance(cfg.get("layout"), Mapping) and "fontPx" in cfg["layout"]):
            cfg["fontSize"] = float(self._default_font_size)
        if padding_px is not None:
            cfg["paddingPx"] = int(padding_px)
        if parser_options is not None:
            merged = dict(cfg.get("parser") or {})
            merged.update(dict(parser_options))
            cfg["parser"] = merged
        if layout is not None:
            merged = dict(cfg.get("layout") or {})
            merged.update(dict(layout))
            cfg["layout"] = merged
        if paint is not None:
            merged = dict(cfg.get("paint") or {})
            merged.update(dict(paint))
            cfg["paint"] = merged
        if include_plan is not None:
            cfg["includePlan"] = bool(include_plan)
        return FullRenderOptions.from_mapping(cfg)

    def parse_input(self, input_text: str, options: Optional[Mapping[str, Any]] = None, **kwargs: Any) -> DocumentAst:
        o = self._full_options(options, **kwargs)
        return self._full_renderer.parse_input(str(input_text), o)

    def ast_to_text(self, ast: DocumentAst) -> str:
        """Serialize a full-document AST back into nanpa-linja-n source text."""
        return _ast_to_text(ast)

    def build_full_render_plan(self, input_text: str, options: Optional[Mapping[str, Any]] = None, **kwargs: Any) -> FullRenderPlan:
        o = self._full_options(options, **kwargs)
        return self._full_renderer.prepare(str(input_text), o)[0]

    def render_to_canvas(self, input_text: str, options: Optional[Mapping[str, Any]] = None, **kwargs: Any) -> CanvasRenderResult:
        o = self._full_options(options, **kwargs)
        return self._full_renderer.render_canvas(str(input_text), o)

    def render_document(self, input_text: str, options: Optional[Mapping[str, Any]] = None, **kwargs: Any) -> CanvasRenderResult:
        return self.render_to_canvas(input_text, options, **kwargs)

    def render_full_to_png(self, input_text: str, options: Optional[Mapping[str, Any]] = None, **kwargs: Any) -> bytes:
        result = self.render_to_canvas(input_text, options, **kwargs)
        buffer = BytesIO()
        result.image.save(buffer, format="PNG", optimize=False, compress_level=9)
        return buffer.getvalue()

    def render_to_svg(self, input_text: str, options: Optional[Mapping[str, Any]] = None, **kwargs: Any) -> str:
        o = self._full_options(options, **kwargs)
        return self._full_renderer.render_svg(str(input_text), o)[0]

    def render_to_pdf(self, input_text: str, options: Optional[Mapping[str, Any]] = None, **kwargs: Any) -> bytes:
        o = self._full_options(options, **kwargs)
        return self._full_renderer.render_pdf(str(input_text), o)[0]

    def to_vector_document(self, input_text: str, options: Optional[Mapping[str, Any]] = None, **kwargs: Any) -> VectorDocument:
        o = self._full_options(options, **kwargs)
        return self._full_renderer.vector_document(str(input_text), o)

    def render_run_to_new_canvas(self, run: FullRenderRun, options: Optional[Mapping[str, Any]] = None, **kwargs: Any) -> CanvasRenderResult:
        o = self._full_options(options, **kwargs)
        return self._full_renderer.render_run_to_new_canvas(run, o)

    def render_text_to_new_canvas(self, text: str, options: Optional[Mapping[str, Any]] = None, **kwargs: Any) -> CanvasRenderResult:
        o = self._full_options(options, **kwargs)
        return self._full_renderer.render_text_to_new_canvas(str(text), o)

    def render_text_to_canvas(self, target: Image.Image, x: float, y: float, text: str, options: Optional[Mapping[str, Any]] = None, **kwargs: Any) -> Image.Image:
        o = self._full_options(options, **kwargs)
        return self._full_renderer.render_text_to_canvas(target, x, y, str(text), o)

    def render_ucsur_to_new_canvas(self, lines: Iterable[Iterable[int]], options: Optional[Mapping[str, Any]] = None, **kwargs: Any) -> CanvasRenderResult:
        o = self._full_options(options, **kwargs)
        normalized = tuple(tuple(int(cp) for cp in line) for line in lines)
        return self._full_renderer.render_ucsur_to_new_canvas(normalized, o)

    def render_ucsur_to_canvas(self, target: Image.Image, x: float, y: float, lines: Iterable[Iterable[int]], options: Optional[Mapping[str, Any]] = None, **kwargs: Any) -> Image.Image:
        o = self._full_options(options, **kwargs)
        normalized = tuple(tuple(int(cp) for cp in line) for line in lines)
        return self._full_renderer.render_ucsur_to_canvas(target, x, y, normalized, o)

    def register_render_adapter(self, adapter_id: str, adapter: Any) -> None:
        if not callable(adapter):
            raise TypeError("render adapter must be callable")
        self._runtime_render_adapters[str(adapter_id)] = adapter

    def get_render_adapter(self, adapter_id: str) -> Any:
        return self._runtime_render_adapters.get(str(adapter_id))

    def remove_render_adapter(self, adapter_id: str) -> Any:
        return self._runtime_render_adapters.pop(str(adapter_id), None)

    # JavaScript-style aliases make the one-to-one binding explicit while the
    # existing Python snake_case numeric facade remains backward compatible.
    parseInput = parse_input
    astToText = ast_to_text
    buildRenderPlan = build_full_render_plan
    renderToCanvas = render_to_canvas
    renderToPng = render_full_to_png
    renderToSvg = render_to_svg
    renderToPdf = render_to_pdf
    toVectorDocument = to_vector_document
    renderRunToNewCanvas = render_run_to_new_canvas
    renderTextToNewCanvas = render_text_to_new_canvas
    renderTextToCanvas = render_text_to_canvas
    renderUcsurToNewCanvas = render_ucsur_to_new_canvas
    renderUcsurToCanvas = render_ucsur_to_canvas
    registerRenderAdapter = register_render_adapter
    getRenderAdapter = get_render_adapter
    removeRenderAdapter = remove_render_adapter


_default_instance: Optional[NanpaLinjaN] = None
_default_instance_lock = Lock()


def default_facade() -> NanpaLinjaN:
    global _default_instance
    if _default_instance is None:
        with _default_instance_lock:
            if _default_instance is None:
                _default_instance = NanpaLinjaN()
    return _default_instance


def list_fonts() -> tuple[FontInfo, ...]:
    return default_facade().list_fonts()


def render(value: Any, **kwargs: Any) -> RenderResult:
    return default_facade().render(value, **kwargs)


def render_to_image(value: Any, **kwargs: Any) -> Image.Image:
    return default_facade().render_to_image(value, **kwargs)


def render_to_png(value: Any, **kwargs: Any) -> bytes:
    return default_facade().render_to_png(value, **kwargs)


def save_png(value: Any, path: str | Path, **kwargs: Any) -> Path:
    return default_facade().save_png(value, path, **kwargs)

def parse_input(input_text: str, options: Optional[Mapping[str, Any]] = None, **kwargs: Any) -> DocumentAst:
    return default_facade().parse_input(input_text, options, **kwargs)


def ast_to_text(ast: DocumentAst) -> str:
    return _ast_to_text(ast)


def build_full_render_plan(input_text: str, options: Optional[Mapping[str, Any]] = None, **kwargs: Any) -> FullRenderPlan:
    return default_facade().build_full_render_plan(input_text, options, **kwargs)


def render_to_canvas(input_text: str, options: Optional[Mapping[str, Any]] = None, **kwargs: Any) -> CanvasRenderResult:
    return default_facade().render_to_canvas(input_text, options, **kwargs)


def render_full_to_png(input_text: str, options: Optional[Mapping[str, Any]] = None, **kwargs: Any) -> bytes:
    return default_facade().render_full_to_png(input_text, options, **kwargs)


def render_to_svg(input_text: str, options: Optional[Mapping[str, Any]] = None, **kwargs: Any) -> str:
    return default_facade().render_to_svg(input_text, options, **kwargs)


def render_to_pdf(input_text: str, options: Optional[Mapping[str, Any]] = None, **kwargs: Any) -> bytes:
    return default_facade().render_to_pdf(input_text, options, **kwargs)


def to_vector_document(input_text: str, options: Optional[Mapping[str, Any]] = None, **kwargs: Any) -> VectorDocument:
    return default_facade().to_vector_document(input_text, options, **kwargs)

