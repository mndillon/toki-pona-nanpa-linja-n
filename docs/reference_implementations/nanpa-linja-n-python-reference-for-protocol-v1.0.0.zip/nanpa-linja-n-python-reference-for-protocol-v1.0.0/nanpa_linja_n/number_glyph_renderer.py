from typing import List, Dict, Tuple, Optional, Set
from PIL import Image, ImageDraw, ImageFont
import os
import random
from dataclasses import dataclass
import re
import math

NUMBER_GLYPH_RENDERER_VERSION = "4.2.0"
NUMERIC_CARTOUCHE_RENDERING_VERSION = "font-shaped-opentype-v1.4"

# Project-wide numeric defaults. Full-cartouche examples override
# abbreviate_numeric_cartouches=False explicitly at their call sites.
DEFAULT_NUMBER_WORD_STYLE = "uniform"
DEFAULT_MIXED_STYLE = "short"
DEFAULT_RELAXED_NANPA_LINJAN_PARSING = True
DEFAULT_RELAXED_NANPA_LINJAN_RENDERING = True
DEFAULT_ABBREVIATE_NUMERIC_CARTOUCHES = True
DEFAULT_PRESERVE_NUMERIC_CARTOUCHE_BREAKS_IN_ABBREVIATION = True
DEFAULT_NANPA_COLON_PARSING = False
DEFAULT_NANPA_COLON_RENDERING = False
DEFAULT_ENABLE_HEX_PARSING = False
DEFAULT_ENABLE_BINARY_PARSING = False
DEFAULT_ENABLE_BINARY_RENDERING = False


def close_to_bg(c, bg_rgb, tol: int = 5) -> bool:
    return all(abs(c[i] - bg_rgb[i]) <= tol for i in range(3))


def make_bg_color_transparent(input_path: str) -> Image.Image:
    """
    Load a PNG, use the top-left pixel as the background color,
    and make that color fully transparent everywhere in the image.
    """
    img = Image.open(input_path).convert("RGBA")
    bg = img.getpixel((0, 0))      # (R, G, B, A)
    bg_rgb = bg[:3]                # ignore source alpha

    pixels = img.getdata()
    new_pixels = []

    for r, g, b, a in pixels:
        if close_to_bg((r, g, b), bg_rgb):
            # same as background: make fully transparent
            new_pixels.append((r, g, b, 0))
        else:
            # keep original pixel
            new_pixels.append((r, g, b, a))

    img.putdata(new_pixels)
    return img


def load_digit_images(
    digit_image_paths: Optional[Dict[str, str]]
) -> Dict[str, Image.Image]:
    """
    Given a mapping from character -> file path, load and preprocess glyph images.

    - Applies make_bg_color_transparent to each PNG.
    - Returns a dict[char] = PIL.Image.Image.
    """
    digit_images: Dict[str, Image.Image] = {}

    if not digit_image_paths:
        return digit_images

    for ch, path in digit_image_paths.items():
        if not os.path.exists(path):
            raise FileNotFoundError(f"Digit image for '{ch}' not found at {path}")
        digit_images[ch] = make_bg_color_transparent(path)

    return digit_images

# =========================
# 1) ADD THIS helper near the top (above measure_glyph_string / paste_number_glyphs)
# =========================

def _expand_render_chars(ch: str) -> List[str]:
    """
    Option B: keep two glyphs separate.
    Render the separator token 'P' as two glyphs: 'N' then 'E'.
    """
    if ch == "P":
        return ["N", "E"]
    return [ch]

# =========================
# 2) REPLACE measure_glyph_string(...) with this version
# =========================

def measure_glyph_string(
    digit_images: Dict[str, Image.Image],
    glyph_string: str,
    max_height: int,
    digit_spacing: int = 4,
) -> int:
    x = 0

    for ch in glyph_string:
        if ch == " ":
            x += digit_spacing * 2
            continue

        for sub_ch in _expand_render_chars(ch):
            glyph = digit_images.get(sub_ch)
            if glyph is None:
                raise ValueError(
                    f"No glyph image configured for character '{sub_ch}' "
                    f"(expanded from '{ch}') in {glyph_string!r}"
                )

            g_w, g_h = glyph.size
            scale = max_height / g_h
            new_w = int(g_w * scale)

            x += new_w + digit_spacing

    return max(0, x - digit_spacing)


# =========================
# 3) REPLACE paste_number_glyphs(...) with this version
# =========================

def paste_number_glyphs(
    base_img: Image.Image,
    digit_images: Dict[str, Image.Image],
    number: str,
    top_left_xy: Tuple[int, int],
    max_height: int,
    digit_spacing: int = 4,
    draw_cartouche: bool = False,
    cartouche_padding: int = 8,
    cartouche_outline: str = "black",
    cartouche_width: int = 2,
    cartouche_fill: Optional[str] = None,
    cartouche_radius: Optional[int] = None,
) -> int:
    x, y_top = top_left_xy
    start_x = x

    for ch in number:
        if ch == " ":
            x += digit_spacing * 2
            continue

        for sub_ch in _expand_render_chars(ch):
            glyph = digit_images.get(sub_ch)
            if glyph is None:
                raise ValueError(
                    f"No glyph image configured for character '{sub_ch}' "
                    f"(expanded from '{ch}') in number '{number}'"
                )

            g_w, g_h = glyph.size
            scale = max_height / g_h
            new_w = int(g_w * scale)
            new_h = int(g_h * scale)
            resized = glyph.resize((new_w, new_h), Image.LANCZOS)

            y = int(y_top + (max_height - new_h) / 2)
            base_img.paste(resized, (int(x), y), resized)
            x += new_w + digit_spacing

    end_x = x - digit_spacing

    if draw_cartouche and start_x < end_x:
        draw = ImageDraw.Draw(base_img)

        left = int(start_x - cartouche_padding)
        top = int(y_top - cartouche_padding)
        right = int(end_x + cartouche_padding)
        bottom = int(y_top + max_height + cartouche_padding)

        if cartouche_radius is None:
            cartouche_radius = max(4, int((bottom - top) * 0.25))

        draw.rounded_rectangle(
            [left, top, right, bottom],
            radius=cartouche_radius,
            outline=cartouche_outline,
            width=cartouche_width,
            fill=cartouche_fill,
        )

    return x



def format_with_thousands_preserve_fraction(value, thousands_char: str = ",") -> str:
    """
    Format value with thousands separators in the integer part,
    but preserve all digits after the decimal point exactly.
    """
    s = str(value)

    if "." in s:
        int_part, frac_part = s.split(".", 1)
    else:
        int_part, frac_part = s, None

    # Handle possible sign
    sign = ""
    if int_part.startswith("+"):
        # drop plus sign
        int_part = int_part[1:]
    elif int_part.startswith("-"):
        # keep minus sign
        sign = int_part[0]
        int_part = int_part[1:]

    # Format integer part with thousands separator
    if int_part:
        int_int = int(int_part)  # normalize e.g. "000123" -> 123
        int_formatted = f"{int_int:,}".replace(",", thousands_char)
    else:
        int_formatted = "0"

    # Re-attach fractional part exactly as given
    if frac_part is not None:
        return f"{sign}{int_formatted}.{frac_part}"
    else:
        return f"{sign}{int_formatted}"


def convert_row_value_to_str(value, thousands_char: str = ",", prefix_with_nanpa_symbol=False) -> str:
    """
    Convert a numeric value (int/float/string) into a glyph-string to be rendered.

    Steps:
      - Format with thousands separators (preserving all fractional digits).
      - Convert that into nanpa-linja-n words.
      - Map each Toki Pona block into a glyph character string.
    """
    row_str = ""

    # =========================
    # 4) CHANGE convert_row_value_to_str(...) nanpa prefix token (so 'N' is free for ni)
    #    In toki_pona_word_to_glyph_id_map, replace:
    #       "nanpa": "N",
    #    with:
    #       "nanpa": "^",
    # =========================

    toki_pona_word_to_glyph_id_map = {
        "oselo": ".",
        "nike": "-",
        "esewi": "/",
        "tasa": "P",
        "tasan": "T",
        "masa": "P",
        "masan": "M",
        "wasa": "P",
        "wasan": "W",
        "pasa": "P",
        "pasan": "P",
    }

    # is the value already a string?
    if isinstance(value, str):
        nanpa_words_for_value = value
    else:
        formatted_number_with_thousands = format_with_thousands_preserve_fraction(
            value, thousands_char=thousands_char
        )
        nanpa_words_for_value = number_to_nanpa_linja_n(formatted_number_with_thousands)

    words = nanpa_words_for_value.split()
    first_is_nanpa = bool(words) and words[0] == "nanpa"

    open_block_marker = False
    for idx, word in enumerate(words):
        if word in toki_pona_word_to_glyph_id_map:
            record_word_in_output=True
            mapped_value = toki_pona_word_to_glyph_id_map[word]

            if word in {"tasa", "masa", "wasa"}:
                # we are at the start of an open block
                open_block_marker = True
            else:
                open_block_marker = False

            # Special rule: if 'tasa' is followed by wasa/wasan,
            # map it to 'T' (trillion marker) instead of generic 'P'.
            # Special rule: if 'tasa' is followed by masa/masan,
            # map it to 'W' (same as wassa/wasan marker) instead of generic 'P'.
            # Special rule: if 'masa' is followed by masa/masan/wasa/wasan,
            # map it to 'M' (any number of masa marker) instead of generic 'P'.
            # Special rules: if 'wasa' is followed by wasa/wasan,
            # map it to 'W' (any number of wasa marker) instead of generic 'P'.
            if (
                word == "tasa"
                and idx + 1 < len(words)
                and words[idx + 1] in { "wasa", "wasan"}
            ):
                mapped_value = "T"
                open_block_marker = False
            elif (
                word == "tasa"
                and idx + 1 < len(words)
                and words[idx + 1] in {"masa", "masan"}
            ):
                #tasa followed by masa is the same as wasa
                #tasa followed by masan is the same as wasan
                record_word_in_output=False
                mapped_value = "T"
                open_block_marker = False
                if words[idx + 1] == "masa":
                    words[idx + 1] = "wasa"
                elif words[idx + 1] == "masan":
                    words[idx + 1] = "wasan"
            elif (
                word == "masa"
                and idx + 1 < len(words)
                and words[idx + 1] in {"masa", "masan", "wasa", "wasan"}
            ):
                mapped_value = "M"
                open_block_marker = False

            elif (
                word == "wasa"
                and idx + 1 < len(words)
                and words[idx + 1] in {"wasa", "wasan"}
            ):
                mapped_value = "W"
                open_block_marker = False

            if record_word_in_output:
                row_str += mapped_value

        elif word.endswith("n"):
            # word ends in n, so assume represents a block of at most 3 digits
            # and not tasan/masan/wasan/pasan as they are all in the glyph map
            decoded_value_str_for_word = decode_nanpa_numbers_in_text(
                word, thousands_char=""
            )
            if open_block_marker and len(decoded_value_str_for_word) < 3:
                # pad on left with 0 and take last three characters
                decoded_value_str_for_word = decoded_value_str_for_word.zfill(3)[-3:]
            open_block_marker = False
            row_str += decoded_value_str_for_word

        else:
            # ignore anything we dont understand
            open_block_marker = False



    return row_str

#map unc codes to words
UNC_CODES_TO_WORDS_MAP: Dict[str, str] = {

    "F1900":"A",
    "F1901":"AKESI",
    "F1902":"ALA",
    "F1903":"ALASA",
    "F1904":"ALE",
    "F1905":"ANPA",
    "F1906":"ANTE",
    "F1907":"ANU",
    "F1908":"AWEN",
    "F1909":"E",
    "F190A":"EN",
    "F190B":"ESUN",
    "F190C":"IJO",
    "F190D":"IKE",
    "F190E":"ILO",
    "F190F":"INSA",
    "F1910":"JAKI",
    "F1911":"JAN",
    "F1912":"JELO",
    "F1913":"JO",
    "F1914":"KALA",
    "F1915":"KALAMA",
    "F1916":"KAMA",
    "F1917":"KASI",
    "F1918":"KEN",
    "F1919":"KEPEKEN",
    "F191A":"KILI",
    "F191B":"KIWEN",
    "F191C":"KO",
    "F191D":"KON",
    "F191E":"KULE",
    "F191F":"KULUPU",
    "F1920":"KUTE",
    "F1921":"LA",
    "F1922":"LAPE",
    "F1923":"LASO",
    "F1924":"LAWA",
    "F1925":"LEN",
    "F1926":"LETE",
    "F1927":"LI",
    "F1928":"LILI",
    "F1929":"LINJA",
    "F192A":"LIPU",
    "F192B":"LOJE",
    "F192C":"LON",
    "F192D":"LUKA",
    "F192E":"LUKIN",
    "F192F":"LUPA",
    "F1930":"MA",
    "F1931":"MAMA",
    "F1932":"MANI",
    "F1933":"MELI",
    "F1934":"MI",
    "F1935":"MIJE",
    "F1936":"MOKU",
    "F1937":"MOLI",
    "F1938":"MONSI",
    "F1939":"MU",
    "F193A":"MUN",
    "F193B":"MUSI",
    "F193C":"MUTE",
    "F193D":"NANPA",
    "F193E":"NASA",
    "F193F":"NASIN",
    "F1940":"NENA",
    "F1941":"NI",
    "F1942":"NIMI",
    "F1943":"NOKA",
    "F1944":"O",
    "F1945":"OLIN",
    "F1946":"ONA",
    "F1947":"OPEN",
    "F1948":"PAKALA",
    "F1949":"PALI",
    "F194A":"PALISA",
    "F194B":"PAN",
    "F194C":"PANA",
    "F194D":"PI",
    "F194E":"PILIN",
    "F194F":"PIMEJA",
    "F1950":"PINI",
    "F1951":"PIPI",
    "F1952":"POKA",
    "F1953":"POKI",
    "F1954":"PONA",
    "F1955":"PU",
    "F1956":"SAMA",
    "F1957":"SELI",
    "F1958":"SELO",
    "F1959":"SEME",
    "F195A":"SEWI",
    "F195B":"SIJELO",
    "F195C":"SIKE",
    "F195D":"SIN",
    "F195E":"SINA",
    "F195F":"SINPIN",
    "F1960":"SITELEN",
    "F1961":"SONA",
    "F1962":"SOWELI",
    "F1963":"SULI",
    "F1964":"SUNO",
    "F1965":"SUPA",
    "F1966":"SUWI",
    "F1967":"TAN",
    "F1968":"TASO",
    "F1969":"TAWA",
    "F196A":"TELO",
    "F196B":"TENPO",
    "F196C":"TOKI",
    "F196D":"tomo",
    "F196E":"TU",
    "F196F":"UNPA",
    "F1970":"UTA",
    "F1971":"UTALA",
    "F1972":"WALO",
    "F1973":"WAN",
    "F1974":"WASO",
    "F1975":"WAWA",
    "F1976":"WEKA",
    "F1977":"WILE",
    "F1978":"NAMAKO",
    "F1979":"KIN",
    "F197A":"OKO",
    "F197B":"KIPISI",
    "F197C":"LEKO",
    "F197D":"MONSUTA",
    "F197E":"TONSI",
    "F197F":"JASIMA",
    "F1980":"KIJETESANTAKALU",
    "F1981":"SOKO",
    "F1982":"MESO",
    "F1983":"EPIKU",
    "F1984":"KOKOSILA",
    "F1985":"LANPAN",
    "F1986":"N",
    "F1987":"MISIKEKE",
    "F1988":"KU",
    "F199D":"KOLON",
}

# inverse: lowercase words -> unc codes
WORDS_TO_UNC_CODES_MAP: Dict[str, str] = {
    word.lower(): chr(int(code, 16)) for code, word in UNC_CODES_TO_WORDS_MAP.items()
}

# Optional: guard against duplicates (would silently overwrite otherwise)
if len(WORDS_TO_UNC_CODES_MAP) != len(UNC_CODES_TO_WORDS_MAP):
    raise ValueError("Duplicate word(s) detected in UNC_CODES_TO_WORDS_MAP; inverse map would collide.")

# Standard SP glyph aliases and later UCSUR additions used by the JavaScript
# renderer.  The digit-bearing source aliases are normalized by the text parser
# below before ordinary cleanup can discard their suffixes.
WORDS_TO_UNC_CODES_MAP.update({
    "ni<": chr(0xF1989),
    "ni^": chr(0xF198A),
    "ni>": chr(0xF198B),
    "sewi^": chr(0xF198C),
    "pake": chr(0xF19A0),
    "apeja": chr(0xF19A1),
    "majuna": chr(0xF19A2),
    "powe": chr(0xF19A3),
    "linluwi": chr(0xF19A4),
    "su": chr(0xF19A6),
    # JavaScript-compatible aliases.
    "ali": WORDS_TO_UNC_CODES_MAP["ale"],
    "·": chr(0xF199C),
    ".": chr(0xF199C),
    "ota": chr(0xF199C),
    ":": chr(0xF199D),
    "kolon": chr(0xF199D),
    ",": chr(0xF199E),
    "koma": chr(0xF199E),
})

TP_GLYPH_KEY_ALIASES: Dict[str, str] = {
    "ni01": "ni",
    "ni02": "ni>",
    "ni03": "ni^",
    "ni04": "ni<",
    "sewi01": "sewi",
    "sewi02": "sewi^",
}

# UCSUR controls used by modern SP ASCII compound and extended/long-glyph
# syntax.  They are kept as explicit constants so callers and regressions can
# inspect the semantic rendering stream without requiring a font binary.
SP_GENERIC_COMPOUND_JOINER_UCSUR = chr(0x200D)
SP_STACKED_COMPOUND_JOINER_UCSUR = chr(0xF1995)
SP_NESTED_COMPOUND_JOINER_UCSUR = chr(0xF1996)
SP_LONG_RIGHT_START_UCSUR = chr(0xF1997)
SP_LONG_RIGHT_END_UCSUR = chr(0xF1998)
SP_LONG_LEFT_START_UCSUR = chr(0xF199A)
SP_LONG_LEFT_END_UCSUR = chr(0xF199B)


# these code points will be displayed using the small font, which is usually set at one quarter the original font size
SMALL_UNC_CHARS_CODES = {
    WORDS_TO_UNC_CODES_MAP["nanpa"],
    WORDS_TO_UNC_CODES_MAP["nena"],
    WORDS_TO_UNC_CODES_MAP["ni"],
    WORDS_TO_UNC_CODES_MAP["nasa"],
    WORDS_TO_UNC_CODES_MAP["e"],
    WORDS_TO_UNC_CODES_MAP["esun"],
    WORDS_TO_UNC_CODES_MAP["en"],
    WORDS_TO_UNC_CODES_MAP["open"],
}


TWO_THIRDS_UNC_CHARS_CODES = { 
    WORDS_TO_UNC_CODES_MAP["ona"], 
    WORDS_TO_UNC_CODES_MAP["kulupu"], 
    WORDS_TO_UNC_CODES_MAP["o"] 
}

# NEW: one-third-size glyphs for sitelen_text cartouche rendering.
# Keep this separate from SMALL_UNC_CHARS_CODES so existing number/cartouche
# behavior does not change.
ONE_THIRD_UNC_CHARS_CODES = {
    WORDS_TO_UNC_CODES_MAP["kasi"],
}

# Half-size glyphs: kala is the shortened scientific-notation marker and renders at half font size.
HALF_UNC_CHARS_CODES = {
    WORDS_TO_UNC_CODES_MAP["kala"],
}

# 
# Map characters to your glyph image files
# n is duplicated
# n at start is always nanpa, this is the only place that nanpa will be found
# n after n is ni representing ike negative
# n after e is ni representing ike negative
# n after anything else is ni representing tasa/masa/wasa/pasa
# k is duplicated
# k can repeat but that maps to kupulu representing tasan, masan, wasan
# o is duplicated
# o by itself is decimal point
# e doubled is o o, separator of integer from fraction

# =========================
# 6) UPDATE DIGIT_IMAGE_PATHS so:
#    '^' = nanpa
#    'N' = ni   (so P->NE uses N=ni)
#    'E' = e
#    'P' can remain whatever you want as a token; expansion happens in the image renderer,
#        BUT for the Unicode/font pipeline, P must encode to ni+e.
# =========================

DIGIT_IMAGE_PATHS: Dict[str, str] = {
    "0": WORDS_TO_UNC_CODES_MAP["ijo"],
    "1": WORDS_TO_UNC_CODES_MAP["wan"],
    "2": WORDS_TO_UNC_CODES_MAP["tu"],
    "3": WORDS_TO_UNC_CODES_MAP["seli"],# sijelo # sin
    "4": WORDS_TO_UNC_CODES_MAP["awen"], # ante
    "5": WORDS_TO_UNC_CODES_MAP["luka"],
    "6": WORDS_TO_UNC_CODES_MAP["utala"],
    "7": WORDS_TO_UNC_CODES_MAP["mun"],
    "8": WORDS_TO_UNC_CODES_MAP["pipi"],
    "9": WORDS_TO_UNC_CODES_MAP["jo"],

    ".": WORDS_TO_UNC_CODES_MAP["o"],
    "-": WORDS_TO_UNC_CODES_MAP["ni"],

    "N": WORDS_TO_UNC_CODES_MAP["ni"],       # CHANGED: N is ni (used by separator NE)
    "E": WORDS_TO_UNC_CODES_MAP["e"],        # NEW: E is e (used by separator NE)

    # Separator token: rendered as NE (two glyphs) in BOTH pipelines
    "P": WORDS_TO_UNC_CODES_MAP["ni"] + WORDS_TO_UNC_CODES_MAP["e"],

    "T": WORDS_TO_UNC_CODES_MAP["kulupu"],
    "M": WORDS_TO_UNC_CODES_MAP["kulupu"] + WORDS_TO_UNC_CODES_MAP["kulupu"],
    "W": WORDS_TO_UNC_CODES_MAP["kulupu"] + WORDS_TO_UNC_CODES_MAP["kulupu"] + WORDS_TO_UNC_CODES_MAP["kulupu"],

    "/": WORDS_TO_UNC_CODES_MAP["o"] + WORDS_TO_UNC_CODES_MAP["o"],
    "+": WORDS_TO_UNC_CODES_MAP["o"] + WORDS_TO_UNC_CODES_MAP["o"] + WORDS_TO_UNC_CODES_MAP["o"],

    "*": WORDS_TO_UNC_CODES_MAP["weka"],
    "?": WORDS_TO_UNC_CODES_MAP["seme"],
    "#": WORDS_TO_UNC_CODES_MAP["nanpa"],
}

# A practical baseline lexicon (PU + common KU), excluding "nanpa".
# PU-only lexicon (excluding "nanpa")
TOKI_PONA_WORDS_BY_INITIAL: Dict[str, List[str]] = {
    "a": ["a", "akesi", "ala", "alasa", "ale",  "anpa", "ante", "anu", "awen"],
    "e": ["e", "en", "esun"],
    "i": ["ijo", "ike", "ilo", "insa"],
    "j": ["jaki", "jan", "jelo", "jo"],
    "k": ["kala", "kalama", "kama", "kasi", "ken", "kepeken", "kili", "kiwen", "ko", "kon", "kule", "kulupu", "kute"],
    "l": ["la", "lape", "laso", "lawa", "len", "lete", "li", "lili", "linja", "lipu", "loje", "lon", "luka", "lukin", "lupa"],
    "m": ["ma", "mama", "mani", "meli", "mi", "mije", "moku", "moli", "monsi", "mu", "mun", "musi", "mute"],
    "n": ["nanpa", "nasa", "nasin", "nena", "ni", "nimi", "noka"],
    "o": ["o", "olin", "ona", "open"],
    "p": ["pakala", "pali", "palisa", "pan", "pana", "pi", "pilin", "pimeja", "pini", "pipi", "poka", "poki", "pona", "pu"],
    "s": ["sama", "seli", "selo", "seme", "sewi", "sijelo", "sike", "sin", "sina", "sinpin", "sitelen", "sona", "soweli", "suli", "suno", "supa", "suwi"],
    "t": ["tan", "taso", "tawa", "telo", "tenpo", "toki", "tomo", "tu"],
    "u": ["unpa", "uta", "utala"],
    "w": ["walo", "wan", "waso", "wawa", "weka", "wile"],
}

# Ensure 'nanpa' is not present even if someone adds it later.
for k, words in TOKI_PONA_WORDS_BY_INITIAL.items():
    TOKI_PONA_WORDS_BY_INITIAL[k] = [w for w in words if w != "nanpa"]


from typing import List, Optional, Set
import random

def random_toki_pona_sentence_from_letters(
    letters: str,
    disallow: Optional[Set[str]] = None,
    *,
    rng: Optional[random.Random] = None,
    strict: bool = True,
) -> str:
    """
    Convert a string of Toki Pona letters into a space-delimited sentence.

    - For each character c in `letters`, pick a random Toki Pona word that starts with c.
    - Never returns "nanpa".
    - Additionally avoids any words in `disallow` (case-insensitive).
    - If strict=True, raises ValueError for any character that has no usable candidates
      (either unmapped or all candidates disallowed).
      If strict=False, unsupported characters or characters with no usable candidates are skipped.
    """
    if rng is None:
        rng = random

    if letters is None:
        raise ValueError("letters must be a string, not None")

    # Normalize disallowed set (case-insensitive) and always exclude "nanpa"
    disallow_lc: Set[str] = set()
    if disallow:
        disallow_lc = {w.strip().lower() for w in disallow if w and w.strip()}
    disallow_lc.add("nanpa")

    s = letters.strip().lower().replace(" ", "")
    if not s:
        return ""

    out: List[str] = []

    for ch in s:
        candidates = TOKI_PONA_WORDS_BY_INITIAL.get(ch, [])
        if not candidates:
            if strict:
                raise ValueError(
                    f"Unsupported or unmapped letter {ch!r}. "
                    f"Supported initials: {sorted(TOKI_PONA_WORDS_BY_INITIAL.keys())}"
                )
            continue

        usable = [w for w in candidates if w.lower() not in disallow_lc]
        if not usable:
            if strict:
                raise ValueError(
                    f"No usable candidates for initial {ch!r} after applying disallow set. "
                    f"Disallowed: {sorted(disallow_lc)}"
                )
            continue

        out.append(rng.choice(usable))

    return " ".join(out)


# =========================
# Add these utilities BELOW your existing maps (WORDS_TO_UNC_CODES_MAP / TOKI_PONA_WORDS_BY_INITIAL)
# =========================



# Letters that can start Toki Pona words (also matches your TOKI_PONA_WORDS_BY_INITIAL keys)
_TP_INITIALS = set(TOKI_PONA_WORDS_BY_INITIAL.keys())

# Used to strip punctuation at word edges when encoding
_WORD_EDGE_STRIP = re.compile(r"^[^a-z]+|[^a-z]+$")


# Validation only: allowed letters after "#~"
_HASH_TILDE_ALLOWED: Set[str] = set("IWTSALUMPJOK")

_HASH_TILDE_RE = re.compile(r"^#~([A-Za-z]+)$")

# Legacy parse_hash_tilde_payload implementation removed; the renderer-v58 parity implementation is defined below.

# Abbreviation digit-letter -> nanpa-caps digit token (2-letter)
# (This is NOT the validation table; it's conversion logic.)
_HASH_TILDE_DIGIT_TO_CAPS_TOKEN: Dict[str, str] = {
    "I": "NI",  # 0
    "W": "WE",  # 1
    "T": "TE",  # 2
    "S": "SE",  # 3
    "A": "NA",  # 4
    "L": "LE",  # 5
    "U": "NU",  # 6
    "M": "ME",  # 7
    "P": "PE",  # 8
    "J": "JE",  # 9
}

# Legacy hash_tilde_payload_to_nanpa_caps implementation removed; the renderer-v58 parity implementation is defined below.

def random_toki_pona_sentence_from_letters_to_nasin_nanpa_unicodes(
    letters: str,
    disallow: Optional[Set[str]] = None,
    *,
    rng: Optional[random.Random] = None,
    strict: bool = True,
) -> str:
    """
    Like `random_toki_pona_sentence_from_letters(...)`, but returns the UCSUR
    codepoint sequence (no spaces) for the chosen words.

    - Each input character selects a random Toki Pona word starting with that letter.
    - 'nanpa' is never selected.
    - Output is a concatenation of WORDS_TO_UNC_CODES_MAP[word] for each chosen word.

    Example:
        letters="jpt"
        -> "<JAN><PONA><TAN>"  (as UCSUR characters, concatenated; no spaces)
    """
    sentence = random_toki_pona_sentence_from_letters(
        letters,
        disallow,
        rng=rng,
        strict=strict,
    )
    return toki_pona_sentence_to_nasin_nanpa_unicodes(sentence, strict=strict)


# Modern SP ASCII syntax is deliberately whitespace-sensitive.  This is the
# direct Python equivalent of renderer v61 parseSskTextSegmentToElements().
_SP_ASCII_CONSTRUCTION_RE = re.compile(
    r"(?:\{([^{}]+)\}\s*)?([A-Za-z][A-Za-z0-9_]*)\(([^()]+)\)"
    r"|([A-Za-z][A-Za-z0-9_]*)([&+-])([A-Za-z][A-Za-z0-9_]*)"
    r"|\{([^{}]+)\}\s*([A-Za-z][A-Za-z0-9_]*)"
)

# Non-ASCII dash/minus lookalikes are ordinary word separators in renderer v61.
# ASCII U+002D is intentionally absent because it remains the stacked-compound
# operator when it occurs without surrounding whitespace.
_SP_NON_ASCII_DASH_CHARS = "\u2010\u2011\u2012\u2013\u2014\u2212\uFE63\uFF0D"
_SP_FALLBACK_TOKEN_RE = re.compile(rf"[^\s{_SP_NON_ASCII_DASH_CHARS}]+")
_SP_WORD_EDGE_STRIP = re.compile(r"^[^A-Za-z0-9^<>:,.·]+|[^A-Za-z0-9^<>:,.·]+$")

_SP_EARLY_TEXT_ALIAS_SUBSTITUTIONS: Tuple[Tuple[str, str], ...] = (
    ("'cartouche-start'", "["),
    ("'cartouche-end'", "]"),
    ("'zw-joiner'", "&"),
    ("'stack-joiner'", "-"),
    ("'nesting-joiner'", "+"),
    ("'ideographic-space'", " zz "),
    ("'long-start'", "("),
    ("'long-end'", ")"),
    ("'left-bracket'", " te "),
    ("'right-bracket'", " to "),
    ("'middle-dot'", "."),
    ("'colon'", ":"),
    ("'tally'", ","),
)


def preprocess_sp_ascii_aliases(text: str) -> str:
    """Apply the same early literal aliases as the JavaScript renderer."""
    out = str(text or "")
    for source, replacement in _SP_EARLY_TEXT_ALIAS_SUBSTITUTIONS:
        out = out.replace(source, replacement)
    return out


def _normalize_sp_glyph_key(raw: str) -> str:
    key = str(raw or "").strip().lower()
    if not key:
        return ""
    direct = TP_GLYPH_KEY_ALIASES.get(key)
    if direct:
        return direct
    stripped = _SP_WORD_EDGE_STRIP.sub("", key)
    alias = TP_GLYPH_KEY_ALIASES.get(stripped)
    if alias:
        return alias
    return re.sub(r"[^a-z^<>:,.·]", "", stripped)


def _sp_word_to_ucsur(word: str, *, strict: bool) -> Optional[str]:
    key = _normalize_sp_glyph_key(word)
    if not key:
        return None

    cp = WORDS_TO_UNC_CODES_MAP.get(key)
    if cp is None and strict:
        raise ValueError(f"Unknown Toki Pona glyph key {key!r}; not present in WORDS_TO_UNC_CODES_MAP.")
    return cp


def _sp_words_to_ucsur(text: str, *, strict: bool) -> Optional[str]:
    words = [part for part in re.split(r"\s+", str(text or "").strip()) if part]
    if not words:
        return None
    out: List[str] = []
    for word in words:
        cp = _sp_word_to_ucsur(word, strict=strict)
        if cp is None:
            return None
        out.append(cp)
    return "".join(out)


def _encode_sp_fallback_text(text: str, *, strict: bool) -> str:
    """
    Encode ordinary tokens after compound/long-glyph extraction.

    Unicode dash lookalikes split tokens exactly as in renderer v61.  ASCII
    hyphen is not split here: a compact ``left-right`` was already claimed by
    the construction regex, while malformed/internal ASCII-hyphen text remains
    an unknown glyph key instead of becoming a compound accidentally.
    """
    out: List[str] = []
    for match in _SP_FALLBACK_TOKEN_RE.finditer(str(text or "")):
        cp = _sp_word_to_ucsur(match.group(0), strict=strict)
        if cp is not None:
            out.append(cp)
    return "".join(out)


def parse_sitelen_pona_ascii_to_ucsur(
    text: str,
    *,
    strict: bool = True,
    preprocess_aliases: bool = True,
) -> str:
    """
    Parse modern SP ASCII text into an exact UCSUR shaping stream.

    Recognized only with no disallowed whitespace:
      - ``head(inner words)``: right-side extended/long glyph
      - ``left+right``: nested/scaled compound
      - ``left-right``: stacked compound; ASCII U+002D only
      - ``left&right``: generic/font-defined compound

    Whitespace before ``(`` or around a compound operator prevents recognition.
    The optional ``{left words}head`` form mirrors the JavaScript SSK parser and
    may be combined with ``head(right words)``.
    """
    if text is None:
        raise ValueError("text must be a string, not None")

    source = preprocess_sp_ascii_aliases(text) if preprocess_aliases else str(text)
    if not source.strip():
        return ""

    out: List[str] = []
    pos = 0

    for match in _SP_ASCII_CONSTRUCTION_RE.finditer(source):
        if match.start() > pos:
            out.append(_encode_sp_fallback_text(source[pos:match.start()], strict=strict))

        encoded: Optional[str] = None
        left_text, head_word, right_text = match.group(1), match.group(2), match.group(3)
        compound_left, operator, compound_right = match.group(4), match.group(5), match.group(6)
        left_only_text, left_only_head = match.group(7), match.group(8)

        if head_word and (left_text is not None or right_text is not None):
            head_cp = _sp_word_to_ucsur(head_word, strict=False)
            left_cps = _sp_words_to_ucsur(left_text, strict=False) if left_text is not None else None
            right_cps = _sp_words_to_ucsur(right_text, strict=False) if right_text is not None else None
            if head_cp is not None and (left_text is None or left_cps) and (right_text is None or right_cps):
                parts: List[str] = []
                if left_cps:
                    parts.extend((SP_LONG_LEFT_START_UCSUR, left_cps, SP_LONG_LEFT_END_UCSUR))
                parts.append(head_cp)
                if right_cps:
                    parts.extend((SP_LONG_RIGHT_START_UCSUR, right_cps, SP_LONG_RIGHT_END_UCSUR))
                encoded = "".join(parts)

        elif compound_left and operator and compound_right:
            left_cp = _sp_word_to_ucsur(compound_left, strict=False)
            right_cp = _sp_word_to_ucsur(compound_right, strict=False)
            if left_cp is not None and right_cp is not None:
                joiner = {
                    "&": SP_GENERIC_COMPOUND_JOINER_UCSUR,
                    "-": SP_STACKED_COMPOUND_JOINER_UCSUR,
                    "+": SP_NESTED_COMPOUND_JOINER_UCSUR,
                }[operator]
                encoded = left_cp + joiner + right_cp

        elif left_only_text is not None and left_only_head:
            head_cp = _sp_word_to_ucsur(left_only_head, strict=False)
            left_cps = _sp_words_to_ucsur(left_only_text, strict=False)
            if head_cp is not None and left_cps:
                encoded = SP_LONG_LEFT_START_UCSUR + left_cps + SP_LONG_LEFT_END_UCSUR + head_cp

        if encoded is None:
            # Match the JavaScript fallback: syntactically matched text whose
            # glyph names are not all known is sent through ordinary parsing.
            out.append(_encode_sp_fallback_text(match.group(0), strict=strict))
        else:
            out.append(encoded)
        pos = match.end()

    if pos < len(source):
        out.append(_encode_sp_fallback_text(source[pos:], strict=strict))

    return "".join(out)


def toki_pona_sentence_to_nasin_nanpa_unicodes(
    sentence: str,
    *,
    strict: bool = True,
) -> str:
    """
    Convert Toki Pona / modern SP ASCII input to a concatenated UCSUR stream.

    In addition to ordinary glyph names, this now mirrors renderer v61's
    whitespace-sensitive compound and extended/long-glyph syntax.  Output has
    no layout spaces; joiner and extension controls are retained for OpenType
    shaping by the selected sitelen font.
    """
    return parse_sitelen_pona_ascii_to_ucsur(sentence, strict=strict)


def _group_fraction_digits_only(
    s: str,
    *,
    decimal_char: str = ".",
    group_size: int = 3,
    sep_char: str = ",",
) -> str:
    """
    Insert sep_char every `group_size` digits in the fractional part ONLY.
    Does not change the integer part at all, and does not insert anything
    immediately after the decimal point.

    Examples (group_size=3, sep_char=","):
      "12.3"        -> "12.3"
      "12.345"      -> "12.345"
      "12.3456"     -> "12.345,6"
      "12.345678"   -> "12.345,678"
      "12.3456789"  -> "12.345,678,9"
    """
    if decimal_char not in s:
        return s

    left, right = s.split(decimal_char, 1)

    # Only group the leading digit run after the decimal; preserve suffix.
    i = 0
    while i < len(right) and right[i].isdigit():
        i += 1

    frac_digits = right[:i]
    suffix = right[i:]

    # No delimiter unless we have > group_size digits
    if len(frac_digits) <= group_size:
        return s

    # If the fractional digits already contain a separator, do nothing (avoid double-grouping)
    if sep_char and sep_char in frac_digits:
        return s

    groups = [frac_digits[j : j + group_size] for j in range(0, len(frac_digits), group_size)]
    grouped_frac = sep_char.join(groups)
    return f"{left}{decimal_char}{grouped_frac}{suffix}"

def group_fraction_digits_only(
    s: str,
    *,
    decimal_char: str = ".",
    group_size: int = 3,
    sep_char: str = ",",
) -> str:
    """
    Public wrapper: insert separators every `group_size` digits in the fractional part ONLY.
    """
    return _group_fraction_digits_only(
        s,
        decimal_char=decimal_char,
        group_size=group_size,
        sep_char=sep_char,
    )


# =========================
# NEW: nanpa-caps encoding + rendering helpers (Rules A/B)
# =========================

# Rule A: digits -> 2-letter tokens
_DIGIT_TO_TOKEN: Dict[str, str] = {
    "0": "NI",
    "1": "WE",
    "2": "TE",
    "3": "SE",
    "4": "NA",
    "5": "LE",
    "6": "NU",
    "7": "ME",
    "8": "PE",
    "9": "JE",
}

# Reverse for convenience
_TOKEN_TO_DIGIT_WORD: Dict[str, str] = {
    "NI": "ijo",
    "WE": "wan",
    "TE": "tu",
    "SE": "seli",# sijelo
    "NA": "awen", # "ante"
    "LE": "luka",
    "NU": "utala",
    "ME": "mun",
    "PE": "pipi",
    "JE": "jo",
}

# Rule A: operators/delimiters
# (NOTE: '.' and '-' both encode as NO; '-' only occurs immediately after initial NE)
_OPCHAR_TO_TOKEN: Dict[str, str] = {
    ".": "NONE",
    "-": "NO",       # only leading '-' is supported
    "/": "NONO",
    "+": "NONONO",
}

# Rule A: magnitude suffixes
_MAGCHAR_TO_TOKEN: Dict[str, str] = {
    "T": "KE",
    "M": "KEKE",
    "W": "KEKEKE",
}

# Token recognizers (longest-first)
_TOKEN_PREFIXES: Tuple[str, ...] = (
    "KEKEKE",
    "KEKE",
    "KO",
    "KE",
    "NONONO",
    "NONO",
    "NOKO",
    "OK",
    "NE",
    "NO",
    # digit tokens are handled separately (2-letter set)
)

_DIGIT_TOKENS = set(_TOKEN_TO_DIGIT_WORD.keys())


def _looks_like_nanpa_caps(s: str) -> bool:
    """
    Heuristic: caps strings are letters ending in a single 'N' (any case),
    and starting with 'NE' (any case). Whitespace is ignored at edges.
    """
    if not s:
        return False

    t = str(s).strip()
    if not t:
        return False

    # letters only + final N (case-insensitive)
    if not re.fullmatch(r"[A-Za-z]+[Nn]", t):
        return False

    # must start with NE (case-insensitive)
    return t[:2].upper() == "NE"

# --- Vulgar fraction normalization (¼, ½, ¾, etc.) ---

_VULGAR_FRACTIONS = {
    "¼": (1, 4),
    "½": (1, 2),
    "¾": (3, 4),
    "⅐": (1, 7),
    "⅑": (1, 9),
    "⅒": (1, 10),
    "⅓": (1, 3),
    "⅔": (2, 3),
    "⅕": (1, 5),
    "⅖": (2, 5),
    "⅗": (3, 5),
    "⅘": (4, 5),
    "⅙": (1, 6),
    "⅚": (5, 6),
    "⅛": (1, 8),
    "⅜": (3, 8),
    "⅝": (5, 8),
    "⅞": (7, 8),
}

_VULGAR_RE = re.compile("[" + re.escape("".join(_VULGAR_FRACTIONS.keys())) + "]")

def _normalize_vulgar_fractions(expr: str) -> str:
    """
    Convert Unicode vulgar fraction chars into your explicit syntax.

      - "9¾"  -> "9+3/4"
      - "¾"   -> "3/4"
      - "-9¾" -> "-9+3/4"
      - "-¾"  -> "-3/4"

    Only supports at most one vulgar fraction char in the expression.
    """
    s = (expr or "").strip()
    if not s:
        return s

    m = _VULGAR_RE.search(s)
    if not m:
        return s

    # If there are multiple vulgar fraction chars, reject (keeps behavior predictable).
    m2 = _VULGAR_RE.search(s, m.end())
    if m2:
        raise ValueError(f"Multiple vulgar fraction characters are not supported: {expr!r}")

    frac_ch = m.group(0)
    num, den = _VULGAR_FRACTIONS[frac_ch]

    prefix = s[:m.start()].strip()
    suffix = s[m.end():].strip()
    if suffix:
        raise ValueError(f"Unexpected trailing characters after vulgar fraction: {expr!r}")

    # If there is a whole-number prefix (digits/commas with optional leading '-'), treat as mixed number.
    if any(c.isdigit() for c in prefix):
        return f"{prefix}+{num}/{den}"

    # Otherwise treat as a plain fraction (optionally negative).
    if prefix == "-":
        return f"-{num}/{den}"
    if prefix == "":
        return f"{num}/{den}"

    raise ValueError(f"Unexpected characters before vulgar fraction: {expr!r}")

# Legacy _try_parse_scientific_decimal_to_caps implementation removed; the renderer-v58 parity implementation is defined below.


# Legacy number_str_to_nanpa_caps implementation removed; the renderer-v58 parity implementation is defined below.






# Legacy tokenize_nanpa_caps implementation removed; the renderer-v58 parity implementation is defined below.


# Legacy nanpa_caps_tokens_to_tp_words implementation removed; the renderer-v58 parity implementation is defined below.



def tp_words_to_nasin_nanpa_unicodes(words: List[str]) -> str:
    """
    Convert mapped Toki Pona words into concatenated UCSUR characters.
    """
    out: List[str] = []
    for w in words:
        uc = WORDS_TO_UNC_CODES_MAP.get(w.lower())
        if uc is None:
            raise ValueError(f"No UCSUR code for word {w!r} in WORDS_TO_UNC_CODES_MAP")
        out.append(uc)
    return "".join(out)



# Legacy abbreviate_numeric_cartouche_ucsur implementation removed; the renderer-v58 parity implementation is defined below.


# Legacy convert_encoded_str_to_nasin_nanpa_char_codes implementation removed; the renderer-v58 parity implementation is defined below.










BBox = Tuple[int, int, int, int]  # (left, top, right, bottom)


@dataclass(frozen=True)
class CartoucheLayout:
    text_bbox: BBox                 # bbox of rendered text at its drawn position
    cartouche_bbox: BBox | None     # bbox of the cartouche rectangle (None if not requested)
    text_pos: Tuple[int, int]       # actual (x, y) used for draw.text


# ---------- bbox helpers ----------

def bbox_union(a: BBox, b: BBox) -> BBox:
    return (min(a[0], b[0]), min(a[1], b[1]), max(a[2], b[2]), max(a[3], b[3]))

def bbox_expand(b: BBox, pad: int) -> BBox:
    return (b[0] - pad, b[1] - pad, b[2] + pad, b[3] + pad)

def bbox_translate(b: BBox, dx: int, dy: int) -> BBox:
    return (b[0] + dx, b[1] + dy, b[2] + dx, b[3] + dy)

def bbox_size(b: BBox) -> Tuple[int, int]:
    return (b[2] - b[0], b[3] - b[1])

import math
from typing import Tuple

BBox = Tuple[int, int, int, int]  # keep your existing alias if already defined

_TEXT_ANCHOR = "ls"  # left + baseline (baseline aligned across fonts)

def _textbbox_baseline(
    draw: ImageDraw.ImageDraw,
    xy: Tuple[float, float],
    text: str,
    font: ImageFont.FreeTypeFont,
) -> Tuple[int, int, int, int]:
    """
    textbbox using a baseline anchor when supported.
    Fallback: approximate baseline by shifting y up by ascent.
    """
    try:
        return draw.textbbox(xy, text, font=font, anchor=_TEXT_ANCHOR)
    except TypeError:
        # Older Pillow: no anchor support
        ascent, _ = font.getmetrics()
        x, y = xy
        return draw.textbbox((x, y - ascent), text, font=font)


def bbox_to_int_pixel_bounds(b) -> BBox:
    """
    Convert possibly-float bbox to integer pixel bounds without clipping.
    - floor left/top
    - ceil right/bottom
    """
    x0, y0, x1, y1 = b
    return (
        int(math.floor(x0)),
        int(math.floor(y0)),
        int(math.ceil(x1)),
        int(math.ceil(y1)),
    )

def bbox_from_layout(layout: CartoucheLayout) -> BBox:
    """Overall reserve bbox (cartouche if present; otherwise text bbox)."""
    if layout.cartouche_bbox is None:
        return layout.text_bbox
    return bbox_union(layout.text_bbox, layout.cartouche_bbox)


# ---------- measurement (no drawing) ----------

def _mixed_font_enabled(
    font_small: Optional[ImageFont.FreeTypeFont],
    small_chars: Optional[Set[str]],
) -> bool:
    """
    Mixed-font rendering is enabled ONLY when:
      - font_small is provided, AND
      - small_chars is provided AND non-empty
    """
    return (font_small is not None) and (small_chars is not None) and (len(small_chars) > 0)

def _multi_font_enabled(
    font_alt: Optional[ImageFont.FreeTypeFont],
    alt_chars: Optional[Set[str]],
) -> bool:
    """
    Mixed-font rendering is enabled ONLY when:
      - font_alt is provided, AND
      - alt_chars is provided AND non-empty
    """
    return (font_alt is not None) and (alt_chars is not None) and (len(alt_chars) > 0)


_SP_SHAPING_FEATURES = ["calt", "liga", "ccmp"]
_SP_COMPOUND_JOINERS = {
    SP_GENERIC_COMPOUND_JOINER_UCSUR,
    SP_STACKED_COMPOUND_JOINER_UCSUR,
    SP_NESTED_COMPOUND_JOINER_UCSUR,
}


def _iter_sp_shaping_units(text: str):
    """
    Yield ``(substring, force_main_font)`` units for mixed-size rendering.

    Compound and extended/long-glyph streams must be measured and drawn as one
    OpenType shaping unit.  Splitting their control sequence character-by-
    character prevents the font from constructing the intended glyph.
    """
    s = str(text or "")
    i = 0
    n = len(s)
    while i < n:
        # Optional left extension: F199A inner... F199B head [F1997 ... F1998]
        if s[i] == SP_LONG_LEFT_START_UCSUR:
            left_end = s.find(SP_LONG_LEFT_END_UCSUR, i + 1)
            if left_end >= 0 and left_end + 1 < n:
                end = left_end + 2  # include the head glyph after F199B
                if end < n and s[end] == SP_LONG_RIGHT_START_UCSUR:
                    right_end = s.find(SP_LONG_RIGHT_END_UCSUR, end + 1)
                    if right_end >= 0:
                        end = right_end + 1
                yield s[i:end], True
                i = end
                continue

        # Compact binary compound: left JOINER right.
        if i + 2 < n and s[i + 1] in _SP_COMPOUND_JOINERS:
            yield s[i:i + 3], True
            i += 3
            continue

        # Right extension: head F1997 inner... F1998.
        if i + 1 < n and s[i + 1] == SP_LONG_RIGHT_START_UCSUR:
            right_end = s.find(SP_LONG_RIGHT_END_UCSUR, i + 2)
            if right_end >= 0:
                yield s[i:right_end + 1], True
                i = right_end + 1
                continue

        yield s[i], False
        i += 1


def _shaped_textbbox(
    draw: ImageDraw.ImageDraw,
    xy: Tuple[float, float],
    text: str,
    font: ImageFont.FreeTypeFont,
):
    try:
        return draw.textbbox(xy, text, font=font, features=_SP_SHAPING_FEATURES)
    except (TypeError, ValueError):
        return draw.textbbox(xy, text, font=font)


def _draw_shaped_text(
    draw: ImageDraw.ImageDraw,
    xy: Tuple[int, int],
    text: str,
    font: ImageFont.FreeTypeFont,
    fill,
) -> None:
    try:
        draw.text(xy, text, font=font, fill=fill, features=_SP_SHAPING_FEATURES)
    except (TypeError, ValueError):
        draw.text(xy, text, font=font, fill=fill)


def _text_advance(draw: ImageDraw.ImageDraw, text: str, font: ImageFont.FreeTypeFont) -> float:
    """Advance width for one shaped text unit."""
    getlength = getattr(font, "getlength", None)
    if callable(getlength):
        try:
            return float(getlength(text, features=_SP_SHAPING_FEATURES))
        except (TypeError, ValueError):
            return float(getlength(text))
    try:
        return float(draw.textlength(text, font=font, features=_SP_SHAPING_FEATURES))
    except (AttributeError, TypeError, ValueError):
        l, _t, r, _b = _shaped_textbbox(draw, (0, 0), text, font)
        return float(r - l)


def _char_advance(draw: ImageDraw.ImageDraw, ch: str, font: ImageFont.FreeTypeFont) -> float:
    """Backward-compatible one-character wrapper around shaped advance."""
    return _text_advance(draw, ch, font)


def measure_text_layout(
    *,
    text: str,
    font: ImageFont.FreeTypeFont,
    origin: Tuple[int, int],
    padding: int = 18,
    include_cartouche: bool = True,
    # NEW (optional): if provided, use font_small for chars in small_chars
    font_small: Optional[ImageFont.FreeTypeFont] = None,
    small_chars: Optional[Set[str]] = None,
    letter_spacing: int = 0,
    # NEW: vertical offset (pixels) applied only to small-font glyphs
    small_dy: int = 0,
    font_two_thirds: Optional[ImageFont.FreeTypeFont] = None,
    two_thirds_chars: Optional[Set[str]] = None,
    two_thirds_dy: int = 0,
    font_one_third: Optional[ImageFont.FreeTypeFont] = None,
    one_third_chars: Optional[Set[str]] = None,
    one_third_dy: int = 0,
    font_half: Optional[ImageFont.FreeTypeFont] = None,
    half_chars: Optional[Set[str]] = None,
    half_dy: int = 0,
) -> CartoucheLayout:
    """
    Compute positions/bboxes WITHOUT drawing anything.

    origin semantics:
      - include_cartouche=True  -> origin is top-left of cartouche rectangle
      - include_cartouche=False -> origin is top-left of tight text ink bbox

    If font_small and small_chars are provided, measure glyph-by-glyph using mixed fonts.
    """
    dummy = Image.new("RGBA", (1, 1), (0, 0, 0, 0))
    d = ImageDraw.Draw(dummy)

    ox, oy = origin

    use_mixed = _mixed_font_enabled(font_small, small_chars)
    small_chars_set = set(small_chars) if use_mixed else set()

    use_two_thirds = _multi_font_enabled(font_two_thirds, two_thirds_chars)
    two_thirds_chars_set = set(two_thirds_chars) if use_two_thirds else set()

    use_one_third = _multi_font_enabled(font_one_third, one_third_chars)
    one_third_chars_set = set(one_third_chars) if use_one_third else set()

    use_half = _multi_font_enabled(font_half, half_chars)
    half_chars_set = set(half_chars) if use_half else set()

    #small_chars_set = set(small_chars or set())
    #two_thirds_chars_set = set(two_thirds_chars or set())

    def _pick_font_and_dy(ch: str):
        """
        Priority: one-third > half > small > two-thirds > normal.
        Returns: (font_obj, dy)
        """
        if font_one_third is not None and ch in one_third_chars_set:
            return font_one_third, one_third_dy
        if font_half is not None and ch in half_chars_set:
            return font_half, half_dy
        if font_two_thirds is not None and ch in two_thirds_chars_set:
            return font_two_thirds, two_thirds_dy
        if font_small is not None and ch in small_chars_set:
            return font_small, small_dy
        return font, 0


    # --- mixed-font measurement path ---
    if use_mixed or use_two_thirds or use_one_third or use_half:
        x_cursor = 0.0
        ink_bbox: Optional[BBox] = None

        for unit, force_main_font in _iter_sp_shaping_units(text):
            if "\n" in unit:
                raise ValueError("measure_text_layout does not support newlines")

            if force_main_font:
                f, dy = font, 0
            else:
                f, dy = _pick_font_and_dy(unit)
            y_off = float(dy)
            l, t, r, b = _shaped_textbbox(d, (x_cursor, y_off), unit, f)

            if ink_bbox is None:
                ink_bbox = (l, t, r, b)
            else:
                ink_bbox = bbox_union(ink_bbox, (l, t, r, b))

            x_cursor += _text_advance(d, unit, f) + float(letter_spacing)

        if ink_bbox is None:
            ink_bbox = (0, 0, 0, 0)

        left, top, right, bottom = ink_bbox
        text_w = right - left
        text_h = bottom - top

        if include_cartouche:
            cart_bbox: BBox | None = (ox, oy, ox + text_w + 2 * padding, oy + text_h + 2 * padding)
            tx = ox + padding - left
            ty = oy + padding - top
            text_pos = (int(tx), int(ty))
        else:
            cart_bbox = None
            tx = ox - left
            ty = oy - top
            text_pos = (int(tx), int(ty))

        # compute ink bbox at final position
        x_cursor = float(text_pos[0])
        ink_bbox2: Optional[BBox] = None
        for unit, force_main_font in _iter_sp_shaping_units(text):
            if force_main_font:
                f, dy = font, 0
            else:
                f, dy = _pick_font_and_dy(unit)
            y_off = float(dy)
            l, t, r, b = _shaped_textbbox(d, (x_cursor, text_pos[1] + y_off), unit, f)

            if ink_bbox2 is None:
                ink_bbox2 = (l, t, r, b)
            else:
                ink_bbox2 = bbox_union(ink_bbox2, (l, t, r, b))
            x_cursor += _text_advance(d, unit, f) + float(letter_spacing)

        if ink_bbox2 is None:
            ink_bbox2 = (text_pos[0], text_pos[1], text_pos[0], text_pos[1])

        return CartoucheLayout(text_bbox=ink_bbox2, cartouche_bbox=cart_bbox, text_pos=text_pos)

    # --- original single-font measurement path (unchanged behavior) ---
    left, top, right, bottom = d.textbbox((0, 0), text, font=font)
    text_w = right - left
    text_h = bottom - top

    if include_cartouche:
        cart_bbox: BBox | None = (ox, oy, ox + text_w + 2 * padding, oy + text_h + 2 * padding)
        tx = ox + padding - left
        ty = oy + padding - top
        text_pos = (tx, ty)
    else:
        cart_bbox = None
        tx = ox - left
        ty = oy - top
        text_pos = (tx, ty)

    t_left, t_top, t_right, t_bottom = d.textbbox(text_pos, text, font=font)
    text_bbox: BBox = (t_left, t_top, t_right, t_bottom)

    return CartoucheLayout(text_bbox=text_bbox, cartouche_bbox=cart_bbox, text_pos=(int(text_pos[0]), int(text_pos[1])))



def measure_reserve_bbox(
    *,
    text: str,
    font: ImageFont.FreeTypeFont,
    padding: int = 18,
    include_cartouche: bool = True,
    outer_padding: int = 0,
    # NEW
    font_small: Optional[ImageFont.FreeTypeFont] = None,
    small_chars: Optional[Set[str]] = None,
    letter_spacing: int = 0,
    # NEW
    small_dy: int = 0,
    font_two_thirds: Optional[ImageFont.FreeTypeFont] = None,
    two_thirds_chars: Optional[Set[str]] = None,
    two_thirds_dy: int = 0,
    font_one_third: Optional[ImageFont.FreeTypeFont] = None,
    one_third_chars: Optional[Set[str]] = None,
    one_third_dy: int = 0,
    font_half: Optional[ImageFont.FreeTypeFont] = None,
    half_chars: Optional[Set[str]] = None,
    half_dy: int = 0,
) -> Tuple[CartoucheLayout, BBox]:
    layout0 = measure_text_layout(
        text=text,
        font=font,
        origin=(0, 0),
        padding=padding,
        include_cartouche=include_cartouche,
        font_small=font_small,
        small_chars=small_chars,
        letter_spacing=letter_spacing,
        small_dy=small_dy,
        font_two_thirds=font_two_thirds,
        two_thirds_chars=two_thirds_chars,
        two_thirds_dy=two_thirds_dy,
        font_one_third=font_one_third,
        one_third_chars=one_third_chars,
        one_third_dy=one_third_dy,
        font_half=font_half,
        half_chars=half_chars,
        half_dy=half_dy,
    )
    reserve = bbox_from_layout(layout0)
    reserve = bbox_expand(reserve, outer_padding) if outer_padding else reserve
    return layout0, reserve



def required_image_size_for_bbox(reserve_bbox) -> Tuple[Tuple[int, int], Tuple[int, int]]:
    """
    Given a bbox that might be float or negative, compute:
      - (width, height) needed so the bbox fits starting at (0,0)
      - (shift_x, shift_y) to add to your drawing origin so the bbox becomes non-negative

    This version is robust to float bboxes by flooring left/top and ceiling right/bottom.
    """
    x0, y0, x1, y1 = reserve_bbox

    # Normalize to integer pixel bounds while guaranteeing we don't clip content.
    x0i = int(math.floor(x0))
    y0i = int(math.floor(y0))
    x1i = int(math.ceil(x1))
    y1i = int(math.ceil(y1))

    # Shifts must be integers
    shift_x = -min(0, x0i)
    shift_y = -min(0, y0i)

    # After shifting, bbox is non-negative; size is integer
    w = (x1i + shift_x) - (x0i + shift_x)
    h = (y1i + shift_y) - (y0i + shift_y)

    # Defensive: never return non-positive sizes
    w = max(1, int(w))
    h = max(1, int(h))

    return (w, h), (int(shift_x), int(shift_y))


# ---------- drawing (onto any provided image) ----------

def draw_text_with_cartouche(
    img: Image.Image,
    *,
    text: str,
    font: ImageFont.FreeTypeFont,
    origin: Tuple[int, int],
    padding: int = 18,
    radius: int = 22,
    outline_width: int = 6,
    fg=(0, 0, 0, 255),
    cart_fill=(255, 255, 255, 0),  # transparent
    cart_outline=(0, 0, 0, 255),
    include_cartouche: bool = True,
    cartouche_first: bool = True,
    # NEW (optional)
    font_small: Optional[ImageFont.FreeTypeFont] = None,
    small_chars: Optional[Set[str]] = None,
    letter_spacing: int = 0,
    # NEW
    small_dy: int = 0,
    font_two_thirds: Optional[ImageFont.FreeTypeFont] = None,
    two_thirds_chars: Optional[Set[str]] = None,
    two_thirds_dy: int = 0,
    font_one_third: Optional[ImageFont.FreeTypeFont] = None,
    one_third_chars: Optional[Set[str]] = None,
    one_third_dy: int = 0,
    font_half: Optional[ImageFont.FreeTypeFont] = None,
    half_chars: Optional[Set[str]] = None,
    half_dy: int = 0,
) -> CartoucheLayout:
    if img.mode != "RGBA":
        img = img.convert("RGBA")

    draw = ImageDraw.Draw(img)

    layout = measure_text_layout(
        text=text,
        font=font,
        origin=origin,
        padding=padding,
        include_cartouche=include_cartouche,
        font_small=font_small,
        small_chars=small_chars,
        letter_spacing=letter_spacing,
        small_dy=small_dy,
        font_two_thirds=font_two_thirds,
        two_thirds_chars=two_thirds_chars,
        two_thirds_dy=two_thirds_dy,
        font_one_third=font_one_third,
        one_third_chars=one_third_chars,
        one_third_dy=one_third_dy,
        font_half=font_half,
        half_chars=half_chars,
        half_dy=half_dy,
    )

    def _draw_cartouche():
        if not layout.cartouche_bbox:
            return
        draw.rounded_rectangle(
            layout.cartouche_bbox,
            radius=radius,
            fill=cart_fill,
            outline=cart_outline if outline_width > 0 else None,
            width=outline_width if outline_width > 0 else 0,
        )

    def _draw_text():
        use_small = _mixed_font_enabled(font_small, small_chars)
        small_chars_set = set(small_chars) if use_small else set()

        use_two_thirds = _multi_font_enabled(font_two_thirds, two_thirds_chars)
        two_thirds_chars_set = set(two_thirds_chars) if use_two_thirds else set()

        use_one_third = _multi_font_enabled(font_one_third, one_third_chars)
        one_third_chars_set = set(one_third_chars) if use_one_third else set()

        use_half = _multi_font_enabled(font_half, half_chars)
        half_chars_set = set(half_chars) if use_half else set()

        def _pick_font_and_dy(ch: str):
            # Priority: one-third > half > two-thirds > small > normal
            if font_one_third is not None and ch in one_third_chars_set:
                return font_one_third, one_third_dy
            if font_half is not None and ch in half_chars_set:
                return font_half, half_dy
            if font_two_thirds is not None and ch in two_thirds_chars_set:
                return font_two_thirds, two_thirds_dy
            if font_small is not None and ch in small_chars_set:
                return font_small, small_dy
            return font, 0

        # Mixed-font draw if configured; otherwise single draw.text like before
        if use_small or use_two_thirds or use_one_third or use_half:
            x_cursor = float(layout.text_pos[0])
            y_cursor = float(layout.text_pos[1])
            for unit, force_main_font in _iter_sp_shaping_units(text):
                if force_main_font:
                    f, dy = font, 0
                else:
                    f, dy = _pick_font_and_dy(unit)
                _draw_shaped_text(draw, (int(x_cursor), int(y_cursor + dy)), unit, f, fg)
                x_cursor += _text_advance(draw, unit, f) + float(letter_spacing)
        else:
            draw.text(layout.text_pos, text, font=font, fill=fg)

    if include_cartouche and cartouche_first:
        _draw_cartouche()
        _draw_text()
    else:
        _draw_text()
        if include_cartouche:
            _draw_cartouche()

    return layout


#BBox = Tuple[int, int, int, int]


@dataclass(frozen=True)
class RenderParams:
    padding: int = 18
    outer_padding: int = 10
    radius: int = 22
    outline_width: int = 6
    include_cartouche: bool = True
    base_bg: Tuple[int, int, int, int] = (255, 255, 255, 255)  # RGBA
    overlay_bg: Tuple[int, int, int, int] = (0, 0, 0, 0)       # RGBA
    # NEW: colors (RGBA) for everything drawn by draw_text_with_cartouche
    fg: Tuple[int, int, int, int] = (0, 0, 0, 255)                 # glyph/text “ink”
    cart_fill: Tuple[int, int, int, int] = (255, 255, 255, 0)      # cartouche fill (default transparent)
    cart_outline: Tuple[int, int, int, int] = (0, 0, 0, 255)       # cartouche outline
    # Forwarded into caps encoder (optional)
    group_fraction_triplets: bool = True
    fraction_group_size: int = 3
    caps_label_style: str = "upper"   # "upper" | "lower" | "sentence"
    # NEW: mixed-font support for UCSUR glyph-string rendering only
    glyph_font_small: Optional[ImageFont.FreeTypeFont] = None
    small_ucsur_chars: Optional[Set[str]] = None  # set of UCSUR characters (each is length-1 string)
    # NEW: vertical offset (pixels) applied ONLY to glyphs drawn with glyph_font_small
    # Positive moves small glyphs DOWN; negative moves them UP.
    small_glyph_dy: int = 0
    # NEW: leading-negative marker word (used only for NO immediately after starting NE)
    negative_particle_word: str = "ona"   # "o" | "ona"
    number_word_style: str = DEFAULT_NUMBER_WORD_STYLE
    glyph_font_two_thirds: Optional[ImageFont.FreeTypeFont] = None
    two_thirds_ucsur_chars: Optional[Set[str]] = None
    two_thirds_glyph_dy: int = 0
    # NEW: dedicated one-third-size tier, used for kasi in sitelen_text cartouches.
    glyph_font_one_third: Optional[ImageFont.FreeTypeFont] = None
    one_third_ucsur_chars: Optional[Set[str]] = None
    one_third_glyph_dy: int = 0
    # NEW: half-size tier, used for kala in the shortened scientific marker.
    glyph_font_half: Optional[ImageFont.FreeTypeFont] = None
    half_ucsur_chars: Optional[Set[str]] = None
    half_glyph_dy: int = 0
    # Controls which token is emitted for the integer+fraction separator in mixed numbers.
    # "long" => NONONO (legacy), "short" => NOKO rendered as nena open kin open.
    mixed_style: str = DEFAULT_MIXED_STYLE
    # Relaxed mode is independent from the always-uniform structural rendering.
    # Parsing selects relaxed digit syllables (wa/tu/lu/mu/pi); rendering selects
    # their relaxed glyph pairs (wan ala, tu uta, luka uta, mun uta, pipi ike).
    relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING
    relaxed_nanpa_linjan_rendering: bool = DEFAULT_RELAXED_NANPA_LINJAN_RENDERING
    # If true, numeric cartouches keep the leading/trailing nanpa boundary glyphs
    # and the main numeric glyphs, but remove small structural marker glyphs
    # such as nena, en, and open.
    abbreviate_numeric_cartouches: bool = DEFAULT_ABBREVIATE_NUMERIC_CARTOUCHES
    # Deprecated compatibility field. Full cartouches always retain the
    # complete NENE sequence; this value is intentionally ignored.
    compact_nene_breaks_as_en: bool = False
    # When abbreviating, replace each full nena-en-nena-en (NENE) sequence with
    # one small en glyph. This is enabled by default; set False explicitly to
    # drop NENE in an abbreviated cartouche.
    abbreviate_nene_as_en: bool = DEFAULT_PRESERVE_NUMERIC_CARTOUCHE_BREAKS_IN_ABBREVIATION
    # Optional current-JavaScript parser/rendering namespaces.
    nanpa_colon_parsing: bool = DEFAULT_NANPA_COLON_PARSING
    nanpa_colon_rendering: bool = DEFAULT_NANPA_COLON_RENDERING
    enable_hex_parsing: bool = DEFAULT_ENABLE_HEX_PARSING


def _build_glyph_and_reserve_bbox(
    *,
    value: str,
    font: ImageFont.FreeTypeFont,
    thousands_char: str,
    prefix_with_nanpa_symbol: bool,
    params: RenderParams,
) -> tuple[str, BBox]:
    # Normalize any accidental leading "N" in the incoming value.
    # This prevents number_str_to_nanpa_caps() from seeing an unsupported 'N'.
    # Only strip a legacy leading 'N' prefix if it is NOT a nanpa-caps string (which begins with 'NE')
    if isinstance(value, str):
        s = value.strip()
        if s.startswith("N") and not s.startswith("NE") and len(s) > 1:
            value = s[1:]
            prefix_with_nanpa_symbol = True


    hex_semantic = parse_hex_input(
        value,
        relaxed_nanpa_linjan_parsing=params.relaxed_nanpa_linjan_parsing,
        abbreviate_numeric_cartouches=params.abbreviate_numeric_cartouches,
    ) if params.enable_hex_parsing else None
    caps = (
        "#" + "".join(part_value if kind == "digits" else (part_value or ":") for kind, part_value in hex_semantic.parts)
        if hex_semantic is not None else
        value_to_cartouche_caps(
            value,
            thousands_char=thousands_char,
            group_fraction_triplets=params.group_fraction_triplets,
            fraction_group_size=params.fraction_group_size,
            label_style=params.caps_label_style,
            mixed_style=params.mixed_style,
            relaxed_nanpa_linjan_parsing=params.relaxed_nanpa_linjan_parsing,
        )
    )



    glyph_string = convert_encoded_str_to_nasin_nanpa_char_codes(
        value=value,
        thousands_char=thousands_char,
        prefix_with_nanpa_symbol=prefix_with_nanpa_symbol,
        group_fraction_triplets=params.group_fraction_triplets,
        fraction_group_size=params.fraction_group_size,
        # NEW:
        negative_particle_word=params.negative_particle_word,
        number_word_style=params.number_word_style,
        mixed_style=params.mixed_style,
        relaxed_nanpa_linjan_parsing=params.relaxed_nanpa_linjan_parsing,
        relaxed_nanpa_linjan_rendering=params.relaxed_nanpa_linjan_rendering,
        nanpa_colon_parsing=params.nanpa_colon_parsing,
        nanpa_colon_rendering=params.nanpa_colon_rendering,
        enable_hex_parsing=params.enable_hex_parsing,
    )

    # JavaScript parity: full numeric cartouches always keep the complete
    # NENE spacer sequence (nena en nena en).  The single-en form exists only
    # inside abbreviated cartouches when preserve_nene_as_en is enabled.
    if params.abbreviate_numeric_cartouches:
        glyph_string = abbreviate_numeric_cartouche_ucsur(
            glyph_string,
            preserve_nene_as_en=params.abbreviate_nene_as_en,
        )

    use_small = _mixed_font_enabled(params.glyph_font_small, params.small_ucsur_chars)
    use_two_thirds = _multi_font_enabled(params.glyph_font_two_thirds, params.two_thirds_ucsur_chars)
    use_half = _multi_font_enabled(params.glyph_font_half, params.half_ucsur_chars)

    # NOTE: no need to gate the call; measure_reserve_bbox ignores None/empty sets.
    _, reserve_bbox = measure_reserve_bbox(
        text=glyph_string,
        font=font,
        padding=params.padding,
        include_cartouche=params.include_cartouche,
        outer_padding=params.outer_padding,
        font_small=(params.glyph_font_small if use_small else None),
        small_chars=(params.small_ucsur_chars if use_small else None),
        small_dy=(params.small_glyph_dy if use_small else 0),

        # NEW two-thirds support
        font_two_thirds=params.glyph_font_two_thirds if use_two_thirds else None,
        two_thirds_chars=params.two_thirds_ucsur_chars if use_two_thirds else None,
        two_thirds_dy=params.two_thirds_glyph_dy,

        # NEW half support
        font_half=params.glyph_font_half if use_half else None,
        half_chars=params.half_ucsur_chars if use_half else None,
        half_dy=params.half_glyph_dy,
    )


    return glyph_string, reserve_bbox, caps

# ---- Literal single-token cartouche caps ----
# These are for cases where the caller wants to render a glyph token itself,
# not a numeric string that must be parsed.
_LITERAL_TOKEN_TO_CAPS = {
    "N": "NE",            # nanpa symbol itself
    ".": "NONE",            # decimal marker (your scheme)
    "+": "NONONO",        # mixed-number split
    "/": "NONO",          # fraction divider
    "-": "NO",            # negative marker (same caps token as decimal in your scheme)
    "T": "KE",            # thousands suffix
    "M": "KEKE",          # millions suffix
    "W": "KEKEKE",        # billions suffix
}

def literal_token_to_caps(value: str, unknown: str = "?") -> str:
    return _LITERAL_TOKEN_TO_CAPS.get(value, unknown)


def _title_case_words(s: str) -> str:
    """
    Capitalize the first character of each space-delimited word.
    Does not change internal characters.
    """
    parts = [p for p in (s or "").split(" ") if p != ""]
    return " ".join(p[:1].upper() + p[1:] if p else p for p in parts)

# =========================
# CHANGE START: NEW caps "letter-break" formatter
# (safe to remove later; no other code depends on it unless you call it)
# =========================

_CAPS_VOWELS = set("AEIOU")

from typing import Optional

from typing import Optional

# Legacy split_cartouche_caps_letters implementation removed; the renderer-v58 parity implementation is defined below.




# =========================
# CHANGE END: NEW caps "letter-break" formatter
# =========================


def format_caps_label(caps: str, style: str = "upper") -> str:
    """
    Format a nanpa-caps label for display.

    style:
      - "upper"    -> "NEWE...N"
      - "lower"    -> "newe...n"
      - "sentence" -> "Newe...n"  (first letter uppercase, rest lowercase)
    """
    if caps is None:
        return caps
    s = str(caps).strip()
    if not s:
        return s

    style = (style or "upper").lower()
    if style == "upper":
        return s.upper()
    if style == "lower":
        return s.lower()
    if style == "sentence":
        return s[0].upper() + s[1:].lower()

    raise ValueError(f"Unknown caps label style {style!r}")


# Legacy value_to_cartouche_caps implementation removed; the renderer-v58 parity implementation is defined below.


#-- text back to decimal start ---

import re
from typing import List, Optional, Tuple

# ============================================================
# Decode split-cartouche-caps (letters + spaces) back to numbers
# ============================================================

# Tokens you actually emit in caps strings
_DIGIT_TOKEN_TO_CHAR = {
    "NI": "0",
    "WE": "1",
    "TE": "2",
    "SE": "3",
    "NA": "4",
    "LE": "5",
    "NU": "6",
    "ME": "7",
    "PE": "8",
    "JE": "9",
}

# Longest-first token matching. Include the 4-letter structural tokens.
_CAPS_FIXED_TOKENS = (
    "NONONO",  # '+'
    "NONO",    # '/'
    "NOKO",    # current mixed-number separator (rendered with kin)
    "OK",      # percent suffix
    "NONE",    # '.'
    "NEKE",    # integer grouping marker
    "NENE",    # fractional grouping marker
    "KEKEKE",  # 3 * 1000 scale marker (in your encoding it often appears after 'NE')
    "KEKE",    # 2 * 1000 scale
    "KO",      # scientific-notation marker component
    "KE",      # 1 * 1000 scale
    "NE",
    "NO",
)

def _tokenize_caps_allow_internal_N(caps: str) -> List[str]:
    """
    Tokenize a caps label, allowing internal single-letter 'N' terminators.

    Key disambiguation:
      - If we see NEKEKE / NEKEKEKE, treat it as NE + KEKE / KEKEKE (scale markers),
        NOT as NEKE (group marker) + KE.
      - If we see NEKE:
          * If the next token is a digit-token (NI/WE/.../JE), treat NEKE as the integer
            grouping marker.
          * Otherwise treat it as NE + KE (scale-by-1000 marker).
    """
    if caps is None:
        raise ValueError("caps must be a string, not None")

    s = str(caps).strip().upper()
    if not s:
        raise ValueError("caps is empty")

    if not s.startswith("NE"):
        raise ValueError(f"caps must start with NE: {caps!r}")
    if not s.endswith("N"):
        raise ValueError(f"caps must end with N: {caps!r}")

    out: List[str] = []
    i = 0
    n = len(s)

    while i < n:
        # ---------- special handling for NE + KE... ambiguity ----------
        # NEKEKEKE  == NE + KEKEKE
        if s.startswith("NEKEKEKE", i):
            out.append("NE")
            out.append("KEKEKE")
            i += 8
            continue

        # NEKEKE    == NE + KEKE
        if s.startswith("NEKEKE", i):
            out.append("NE")
            out.append("KEKE")
            i += 6
            continue

        # NEKE is ambiguous:
        # - integer grouping marker when followed by a digit token
        # - scale marker (NE + KE) otherwise
        if s.startswith("NEKE", i):
            next_two = s[i + 4 : i + 6] if (i + 6) <= n else ""
            if next_two in _DIGIT_TOKEN_TO_CHAR:
                out.append("NEKE")
            else:
                out.append("NE")
                out.append("KE")
            i += 4
            continue
        # ---------- end special handling ----------

        # Try fixed tokens (longest-first by construction/order)
        matched = None
        for tok in _CAPS_FIXED_TOKENS:
            if s.startswith(tok, i):
                matched = tok
                break
        if matched is not None:
            out.append(matched)
            i += len(matched)
            continue

        # Digit tokens are 2 letters
        if i + 2 <= n:
            two = s[i : i + 2]
            if two in _DIGIT_TOKEN_TO_CHAR:
                out.append(two)
                i += 2
                continue

        # Bare terminator
        if s[i] == "N":
            out.append("N")
            i += 1
            continue

        raise ValueError(f"Un-tokenizable caps at position {i}: {caps!r}")

    return out


def _apply_scale_1000(digits: str, decimal_pos: int, thousand_groups: int) -> Tuple[str, int]:
    """
    Multiply by 1000^thousand_groups by shifting the decimal point right.
    digits: only digits
    decimal_pos: index in digits where decimal point is (0..len(digits))
    """
    if thousand_groups <= 0:
        return digits, decimal_pos

    shift = 3 * thousand_groups
    new_decimal_pos = decimal_pos + shift
    if new_decimal_pos > len(digits):
        digits = digits + ("0" * (new_decimal_pos - len(digits)))
    return digits, new_decimal_pos


def _format_with_thousands(integer_digits: str, thousands_char: str = ",") -> str:
    if not thousands_char:
        return integer_digits
    if len(integer_digits) <= 3:
        return integer_digits
    parts = []
    i = len(integer_digits)
    while i > 0:
        j = max(0, i - 3)
        parts.append(integer_digits[j:i])
        i = j
    return thousands_char.join(reversed(parts))


def _segment_tokens_to_number(
    tokens: List[str],
    *,
    thousands_char: str = ",",
    group_thousands: bool = True,
) -> str:
    """
    Decode ONE number segment (no top-level + or /).
    Supports:
      - optional leading negative (NO right after initial NE)
      - digits
      - decimal point (NONE)
      - integer separators (NEKE) and fractional separators (NENE) are ignored structurally
      - scale markers represented by: NE + (KE|KEKE|KEKEKE) (or NEKE... patterns that tokenize as NE + KE)
        which multiply by 1000^k (i.e., shift decimal right by 3k)
    """
    if not tokens:
        raise ValueError("Empty token stream")

    # Must start with NE for a segment (per your caps scheme)
    if tokens[0] != "NE":
        raise ValueError(f"Segment must start with NE, got {tokens[0]!r}")

    sign = ""
    i = 1

    # Negative if NO immediately after starting NE
    if i < len(tokens) and tokens[i] == "NO":
        sign = "-"
        i += 1

    digits = ""
    decimal_pos = None  # set when we see NONE; otherwise integer

    def _current_decimal_pos() -> int:
        return len(digits) if decimal_pos is None else decimal_pos

    while i < len(tokens):
        t = tokens[i]

        # segment terminator
        if t == "N":
            i += 1
            break

        # ignore grouping tokens (they are punctuation-level in your caps)
        if t in ("NEKE", "NENE"):
            i += 1
            continue

        # decimal point
        if t == "NONE":
            if decimal_pos is not None:
                raise ValueError("Multiple decimal points in one segment")
            decimal_pos = len(digits)
            i += 1
            continue

        # digits
        if t in _DIGIT_TOKEN_TO_CHAR:
            digits += _DIGIT_TOKEN_TO_CHAR[t]
            i += 1
            continue

        # scale markers: NE followed by KE/KEKE/KEKEKE
        if t == "NE":
            if i + 1 >= len(tokens):
                raise ValueError("Dangling NE at end of segment")
            nxt = tokens[i + 1]
            if nxt == "KE":
                k = 1
            elif nxt == "KEKE":
                k = 2
            elif nxt == "KEKEKE":
                k = 3
            else:
                # If you ever emit plain NE as something else, handle it here
                raise ValueError(f"Unexpected token after NE in segment: {nxt!r}")

            dp = _current_decimal_pos()
            digits, new_dp = _apply_scale_1000(digits, dp, k)
            decimal_pos = new_dp if decimal_pos is not None else None  # if no decimal yet, still integer semantics
            i += 2
            continue

        # In your scheme, NO/NONO/NONONO/NOKO are top-level operators, not inside a segment.
        if t in ("NO", "NONO", "NONONO", "NOKO"):
            break

        raise ValueError(f"Unexpected token in segment: {t!r}")

    # Build numeric string from digits + decimal_pos
    if digits == "":
        digits = "0"

    if decimal_pos is None:
        # integer (PRESERVE leading zeros)
        int_part = digits if digits != "" else "0"
        if group_thousands:
            int_part = _format_with_thousands(int_part, thousands_char=thousands_char)
        return sign + int_part


    # decimal
    dp = decimal_pos
    if dp <= 0:
        # 0.xxx
        int_digits = "0"
        frac_digits = "0" * (-dp) + digits
    elif dp >= len(digits):
        # xxx.000...
        int_digits = digits + ("0" * (dp - len(digits)))
        frac_digits = ""
    else:
        int_digits = digits[:dp]
        frac_digits = digits[dp:]

    # PRESERVE leading zeros in the integer part
    int_digits = int_digits if int_digits != "" else "0"
    if group_thousands:
        int_digits = _format_with_thousands(int_digits, thousands_char=thousands_char)

    if frac_digits:
        return sign + int_digits + "." + frac_digits
    return sign + int_digits


# Legacy nanpa_caps_to_numeric_expression implementation removed; the renderer-v58 parity implementation is defined below.


# ============================================================
# Text-level decoding: replace split-caps word runs with numbers
# ============================================================

_WORD_EDGE_STRIP = re.compile(r"^[^a-z]+|[^a-z]+$")

def decode_cartouche_caps_in_text(
    text: str,
    *,
    thousands_char: str = ",",
    group_thousands: bool = True,
    max_words: int = 20,
) -> str:
    """
    Scan `text` for runs of words that look like split-cartouche-caps,
    decode them, and replace with numeric expressions.

    Strategy:
      - Greedy longest-match over word windows.
      - Candidate caps = ''.join(words).upper()
      - Validate by attempting nanpa_caps_to_numeric_expression(...)
    """
    if text is None:
        raise ValueError("text must be a string, not None")

    toks = text.split()
    out: List[str] = []

    i = 0
    while i < len(toks):
        best_j = None
        best_decoded = None
        best_prefix = ""
        best_suffix = ""

        # Attempt to match from i to j (greedy longest)
        for j in range(min(len(toks), i + max_words), i, -1):
            chunk = toks[i:j]

            # Extract prefix/core/suffix from first+last for punctuation preservation
            first = chunk[0]
            last = chunk[-1]

            m1 = re.match(r"^([^a-zA-Z]*)([a-zA-Z]+)([^a-zA-Z]*)$", first)
            m2 = re.match(r"^([^a-zA-Z]*)([a-zA-Z]+)([^a-zA-Z]*)$", last)
            if not m1 or not m2:
                continue

            prefix = m1.group(1)
            suffix = m2.group(3)

            cores = []
            ok = True
            for w in chunk:
                core = _WORD_EDGE_STRIP.sub("", w.lower())
                if not core or not core.isalpha():
                    ok = False
                    break
                cores.append(core)

            if not ok:
                continue

            candidate = "".join(cores).upper()

            # Quick shape check (must start NE and end N)
            if not (candidate.startswith("NE") and candidate.endswith("N")):
                continue

            try:
                decoded = nanpa_caps_to_numeric_expression(
                    candidate,
                    thousands_char=thousands_char,
                    group_thousands=group_thousands,
                )
            except Exception:
                continue

            best_j = j
            best_decoded = decoded
            best_prefix = prefix
            best_suffix = suffix
            break  # greedy: first match from largest j wins

        if best_j is not None:
            out.append(f"{best_prefix}{best_decoded}{best_suffix}")
            i = best_j
        else:
            out.append(toks[i])
            i += 1

    return " ".join(out)


#-- text back to decimal end ---





def _paste_glyph_string_via_overlay(
    *,
    base: Image.Image,
    glyph_string: str,
    reserve_bbox: BBox,
    font: ImageFont.FreeTypeFont,
    origin: Tuple[int, int],
    params: RenderParams,
) -> Image.Image:
    """
    Draw into a minimal overlay sized to `reserve_bbox`, then paste onto `base`.

    `origin` semantics:
      - if include_cartouche=True, origin is the top-left of the cartouche on the base
      - if include_cartouche=False, origin is the top-left of the tight ink bbox on the base
    """
    if base.mode != "RGBA":
        base = base.convert("RGBA")

    # Normalize bbox to integer pixel bounds (prevents float sizes)
    x0, y0, x1, y1 = bbox_to_int_pixel_bounds(reserve_bbox)

    ov_w = max(1, int(x1 - x0))
    ov_h = max(1, int(y1 - y0))
    overlay = Image.new("RGBA", (ov_w, ov_h), params.overlay_bg)

    # Draw such that reserve_bbox's top-left maps to overlay (0,0)
    local_origin = (int(-x0), int(-y0))

    use_mixed = _mixed_font_enabled(params.glyph_font_small, params.small_ucsur_chars)
    use_multi = _multi_font_enabled(params.glyph_font_two_thirds, params.two_thirds_ucsur_chars)
    use_half = _multi_font_enabled(params.glyph_font_half, params.half_ucsur_chars)

    draw_text_with_cartouche(
         overlay,
        text=glyph_string,
        font=font,
        origin=local_origin,
        padding=params.padding,
        include_cartouche=params.include_cartouche,
        radius=params.radius,
        outline_width=params.outline_width,
        # NEW: forward colors
        fg=params.fg,
        cart_fill=params.cart_fill,
        cart_outline=params.cart_outline,
        font_small=(params.glyph_font_small if use_mixed else None),
        small_chars=(params.small_ucsur_chars if use_mixed else None),
        small_dy=(params.small_glyph_dy if use_mixed else 0),
        
        font_two_thirds=(params.glyph_font_two_thirds if use_multi else None),
        two_thirds_chars=(params.two_thirds_ucsur_chars if use_multi else None),
        two_thirds_dy=(params.two_thirds_glyph_dy if use_multi else 0),

        font_one_third=params.glyph_font_one_third,
        one_third_chars=params.one_third_ucsur_chars,
        one_third_dy=params.one_third_glyph_dy,

        font_half=(params.glyph_font_half if use_half else None),
        half_chars=(params.half_ucsur_chars if use_half else None),
        half_dy=(params.half_glyph_dy if use_half else 0),
    )


    # Paste so that cartouche/top-left (origin) lands where requested on base.
    paste_xy = (origin[0] + x0, origin[1] + y0)
    base.paste(overlay, paste_xy, overlay)
    return base


def render_value_to_new_base(
    *,
    value: str,
    font: ImageFont.FreeTypeFont,
    thousands_char: str = ",",
    prefix_with_nanpa_symbol: bool = True,
    params: RenderParams = RenderParams(),
) -> Image.Image:
    """
    Create a new base image sized to fit the rendered value and draw it using an overlay.
    """
    glyph_string, reserve_bbox, caps = _build_glyph_and_reserve_bbox(
        value=value,
        font=font,
        thousands_char=thousands_char,
        prefix_with_nanpa_symbol=prefix_with_nanpa_symbol,
        params=params,
    )

    (w, h), (shift_x, shift_y) = required_image_size_for_bbox(reserve_bbox)
    base = Image.new("RGBA", (w, h), params.base_bg)

    return _paste_glyph_string_via_overlay(
        base=base,
        glyph_string=glyph_string,
        reserve_bbox=reserve_bbox,
        font=font,
        origin=(shift_x, shift_y),
        params=params,
    )


def draw_value_onto_base(
    *,
    base: Image.Image,
    value: str,
    font: ImageFont.FreeTypeFont,
    origin: Tuple[int, int],
    thousands_char: str = ",",
    prefix_with_nanpa_symbol: bool = True,
    params: RenderParams = RenderParams(),
) -> Image.Image:
    """
    Draw onto an already-created base using an overlay and return the modified base.
    """

    # Scientific notation such as "4.5*10^-3" legitimately contains '*' and '^'.
    # Keep rejecting accidental operator expressions, but allow values that the
    # numeric parser can encode as scientific notation.
    if isinstance(value, str) and ("*" in value or "^" in value):
        try:
            parse_numeric_input_to_caps(
                value,
                thousands_char=thousands_char,
                group_fraction_triplets=params.group_fraction_triplets,
                fraction_group_size=params.fraction_group_size,
                mixed_style=params.mixed_style,
                relaxed_nanpa_linjan_parsing=params.relaxed_nanpa_linjan_parsing,
            )
        except Exception as exc:
            raise ValueError(
                "'*' and '^' are supported only in valid scientific notation "
                "such as '4.5*10^-3'."
            ) from exc

    glyph_string, reserve_bbox, _ = _build_glyph_and_reserve_bbox(
        value=value,
        font=font,
        thousands_char=thousands_char,
        prefix_with_nanpa_symbol=prefix_with_nanpa_symbol,
        params=params,
    )

    #xxx
    #print(len(glyph_string))

    return _paste_glyph_string_via_overlay(
        base=base,
        glyph_string=glyph_string,
        reserve_bbox=reserve_bbox,
        font=font,
        origin=origin,
        params=params,
    )

def draw_nasin_nanpa_unicodes_onto_base(
    *,
    base: Image.Image,
    glyph_string: str,
    font: ImageFont.FreeTypeFont,
    origin: Tuple[int, int],
    params: RenderParams = RenderParams(),
) -> Image.Image:
    """
    Draw onto an already-created base using an overlay and return the modified base,
    but the input is already a nasin-nanpa UCSUR glyph string (i.e., the exact
    Unicode characters you want rendered). No encoding/mapping is performed.

    `origin` semantics match draw_value_onto_base / _paste_glyph_string_via_overlay:
      - if params.include_cartouche=True, origin is the top-left of the cartouche
      - if params.include_cartouche=False, origin is the top-left of the tight ink bbox
    """
    if glyph_string is None:
        raise ValueError("glyph_string must be a string, not None")

    # Measure reserve bbox directly from the provided glyph string
    _, reserve_bbox = measure_reserve_bbox(
        text=glyph_string,
        font=font,
        padding=params.padding,
        include_cartouche=params.include_cartouche,
        outer_padding=params.outer_padding,
    )

    return _paste_glyph_string_via_overlay(
        base=base,
        glyph_string=glyph_string,
        reserve_bbox=reserve_bbox,
        font=font,
        origin=origin,
        params=params,
    )

def draw_text_onto_base_via_overlay(
    *,
    base: Image.Image,
    text: str,
    font: ImageFont.FreeTypeFont,
    origin: Tuple[int, int],
    params: RenderParams = RenderParams(),
) -> Image.Image:
    """
    Draw ordinary text (with spaces) onto an existing base image using the same
    overlay+bbox approach (avoids clipping for descenders).

    origin semantics match the existing overlay pipeline:
      - if params.include_cartouche=True, origin is the top-left of the cartouche
      - if params.include_cartouche=False, origin is the top-left of the tight ink bbox
    """
    if text is None:
        raise ValueError("text must be a string, not None")

    _, reserve_bbox = measure_reserve_bbox(
        text=text,
        font=font,
        padding=params.padding,
        include_cartouche=params.include_cartouche,
        outer_padding=params.outer_padding,
    )

    return _paste_glyph_string_via_overlay(
        base=base,
        glyph_string=text,   # the pipeline ultimately calls draw.text(..., text=...)
        reserve_bbox=reserve_bbox,
        font=font,
        origin=origin,
        params=params,
    )

def encoded_value_to_cartouche_caps(
    encoded_value: str,
    *,
    thousands_char: str = ",",
    unknown: str = "?",
    nanpa_prefix_token: str = "N",
    label_style: str = "upper",   # "upper" | "lower" | "sentence"
) -> str:
    """
    Generate cartouche caps directly from an *encoded value string*.

    Supports:
      - digits 0-9
      - ".", "+", "/", "-" (mapped via _OPCHAR_TO_TOKEN)
      - magnitude suffixes "T","M","W" (mapped via _MAGCHAR_TO_TOKEN)
      - thousands separators: thousands_char -> "NE"
      - optional leading nanpa prefix token (default "N") -> prepends "NE"

    Does NOT attempt to parse as a numeric string; it maps char-by-char.
    """

    if encoded_value is None:
        raise ValueError("encoded_value must be a string, not None")

    s = str(encoded_value).strip()
    if not s:
        return ""

    # If user already provided a caps label, accept it case-insensitively and normalize style.
    if _looks_like_nanpa_caps(s):
        return format_caps_label(s, label_style)

    # Optional "nanpa glyph prefix" handling (case-insensitive)
    pref = False
    if nanpa_prefix_token:
        npt = str(nanpa_prefix_token)
        if len(npt) != 1:
            raise ValueError("nanpa_prefix_token must be a single character")

        # If the string starts with prefix token (any case) AND is not actually a caps label starting "NE..."
        if len(s) > 1 and s[:1].upper() == npt.upper() and not s[:2].upper().startswith("NE"):
            pref = True
            s = s[1:]  # strip the prefix character

    out: List[str] = []
    if pref:
        out.append("NE")

    int_part=True
    for ch in s:
        # ignore layout-only characters
        if ch in (" ", "_"):
            continue

        if ch in ("."):
            int_part=False
        elif  ch in ("+", "/"):
            int_part=True

        # Normalize letters for token tests
        chU = ch.upper()

        if ch.isdigit():
            out.append(_DIGIT_TO_TOKEN[ch])
            continue

        if thousands_char and ch == thousands_char:
            if int_part:
                out.append("KE")
            else:
                out.append("NE")
            continue

        # If your encoded stream uses 'P' as a separator token, treat it as "NE" too (case-insensitive).
        if chU == "P":
            out.append("NE")
            continue

        if ch in _OPCHAR_TO_TOKEN:
            out.append(_OPCHAR_TO_TOKEN[ch])
            continue

        if chU in _MAGCHAR_TO_TOKEN:
            # Mirror the same rule as number_str_to_nanpa_caps:
            # insert NE before magnitude when it follows a digit token.
            if out and out[-1] in _DIGIT_TOKENS:
                out.append("NE")
            out.append(_MAGCHAR_TO_TOKEN[chU])
            continue

        out.append(unknown)

    # Always terminate (canonical uppercase caps), then style-format for display
    caps = "".join(out) + "N"
    return format_caps_label(caps, label_style)

# =========================
# MULTILINE TEXT RENDERING WITH NANPA CARTOUCHES
# Updated again:
#   - Cartouche segments are centered relative to the *non-cartouche glyph run* on the same line
#     (equal cartouche above/below that glyph run), even if this requires the cartouche to extend
#     above the line’s normal top.
#   - No spaces between glyphs (already done).
# =========================

from dataclasses import dataclass
from typing import List, Optional, Tuple
import re
import math
from PIL import Image, ImageFont

_LETTERS_ONLY_RE = re.compile(r"[^A-Za-z]+")

def _letters_only(tok: str) -> str:
    if tok is None:
        return ""
    return _LETTERS_ONLY_RE.sub("", tok)

def _tp_words_to_ucsur_no_spaces(
    words: List[str],
    *,
    strict_words: bool = False,
) -> str:
    out: List[str] = []
    for w in words:
        ww = (w or "").strip().lower()
        if not ww:
            continue
        # Match the JavaScript text parser: ``zz`` is an ideographic-space
        # indentation cell, not a sitelen pona word glyph.
        if ww == "zz":
            out.append("\u3000")
            continue
        # The mixed-font line renderer must preserve the same compact ASCII
        # stacked-compound syntax as the main sitelen pona parser.  This keeps
        # tokens such as ``sewi-tu`` and ``lili-tu`` as one shaped compound.
        if "-" in ww:
            compound = parse_sitelen_pona_ascii_to_ucsur(
                ww,
                strict=strict_words,
                preprocess_aliases=False,
            )
            if compound:
                out.append(compound)
                continue
        uc = WORDS_TO_UNC_CODES_MAP.get(ww)
        if uc is None:
            if strict_words:
                raise ValueError(f"Unknown Toki Pona word {ww!r}; not present in WORDS_TO_UNC_CODES_MAP.")
            continue
        out.append(uc)
    return "".join(out)

@dataclass
class _SegmentPlan:
    kind: str  # "text" | "nanpa"
    glyph_string: str
    reserve_bbox: Tuple[int, int, int, int]
    w: int
    h: int
    shift_x: int
    shift_y: int
    params: "RenderParams"
    # NEW: vertical offset within the line coordinate system (may be negative)
    y_off: int = 0


# =========================
# ADD: cartouche control UCSUR characters (0xF1990 start, 0xF1991 end)
# Place near the top of the multiline renderer block (after imports is fine)
# =========================

CARTOUCHE_START_UCSUR = chr(0xF1990)
CARTOUCHE_END_UCSUR   = chr(0xF1991)



def _encode_caps_to_cartouche_ucsur(
    caps: str,
    *,
    thousands_char: str = ",",
    negative_particle_word: str = "ona",
    number_word_style: str = DEFAULT_NUMBER_WORD_STYLE,
    mixed_style: str = DEFAULT_MIXED_STYLE,
    relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING,
    relaxed_nanpa_linjan_rendering: bool = DEFAULT_RELAXED_NANPA_LINJAN_RENDERING,
    nanpa_colon_parsing: bool = DEFAULT_NANPA_COLON_PARSING,
    nanpa_colon_rendering: bool = DEFAULT_NANPA_COLON_RENDERING,
    abbreviate_numeric_cartouches: bool = DEFAULT_ABBREVIATE_NUMERIC_CARTOUCHES,
    preserve_nene_as_en: bool = DEFAULT_PRESERVE_NUMERIC_CARTOUCHE_BREAKS_IN_ABBREVIATION,
    compact_nene_breaks_as_en: bool = False,
) -> str:
    """Encode canonical caps as one numeric-cartouche UCSUR shaping run.

    This is the shared path for decimal/proper-name/``#~`` input in the
    multiline renderers.  It deliberately carries the same relaxed-mode,
    mixed-fraction, scientific-marker and NENE-break options as the normal
    fact-sheet numeric-cell renderer.
    """
    ucsur = convert_encoded_str_to_nasin_nanpa_char_codes(
        value=caps,
        thousands_char=thousands_char,
        prefix_with_nanpa_symbol=True,
        group_fraction_triplets=True,
        fraction_group_size=3,
        negative_particle_word=negative_particle_word,
        number_word_style=number_word_style,
        mixed_style=mixed_style,
        relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
        relaxed_nanpa_linjan_rendering=relaxed_nanpa_linjan_rendering,
        nanpa_colon_parsing=nanpa_colon_parsing,
        nanpa_colon_rendering=nanpa_colon_rendering,
    )
    if abbreviate_numeric_cartouches:
        ucsur = abbreviate_numeric_cartouche_ucsur(
            ucsur,
            preserve_nene_as_en=preserve_nene_as_en,
        )
    # compact_nene_breaks_as_en is retained as a compatibility argument only.
    # It intentionally has no effect on full cartouches: JavaScript always
    # emits the complete nena-en-nena-en NENE description there.
    return CARTOUCHE_START_UCSUR + ucsur + CARTOUCHE_END_UCSUR




# Split tokens but keep [ and ] as standalone tokens (even when attached to words)
_BRACKET_TOKEN_RE = re.compile(r"\[|\]|[^\s]+")
# =========================
# REPLACE: _plan_line_segments(...) with this updated version
# =========================

def _plan_line_segments(
    line: str,
    *,
    font_large: ImageFont.FreeTypeFont,
    font_small: Optional[ImageFont.FreeTypeFont],
    small_dy: int,
    font_half: Optional[ImageFont.FreeTypeFont] = None,
    half_dy: int = 0,
    strict_words: bool,
    max_caps_words: int,
    segment_gap: int,
    cartouche_padding: int,
    cartouche_radius: int,
    cartouche_outline_width: int,
    thousands_char: str = ",",
    group_thousands_in_validation: bool = True,
    number_word_style: str = DEFAULT_NUMBER_WORD_STYLE,
    mixed_style: str = DEFAULT_MIXED_STYLE,
    relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING,
    relaxed_nanpa_linjan_rendering: bool = DEFAULT_RELAXED_NANPA_LINJAN_RENDERING,
    abbreviate_numeric_cartouches: bool = DEFAULT_ABBREVIATE_NUMERIC_CARTOUCHES,
    preserve_nene_as_en: bool = DEFAULT_PRESERVE_NUMERIC_CARTOUCHE_BREAKS_IN_ABBREVIATION,
    compact_nene_breaks_as_en: bool = False,
) -> List[_SegmentPlan]:

    # Tokenize while preserving [ and ]
    raw_tokens = _BRACKET_TOKEN_RE.findall(line or "")

    # Prepare render params
    text_params = RenderParams(
        padding=0,
        outer_padding=0,
        radius=0,
        outline_width=0,
        include_cartouche=False,
        base_bg=(0, 0, 0, 0),
        overlay_bg=(0, 0, 0, 0),
        group_fraction_triplets=True,
        fraction_group_size=3,
        caps_label_style="upper",
        glyph_font_small=None,
        small_ucsur_chars=None,
        small_glyph_dy=0,
    )

    use_small = (font_small is not None) and (SMALL_UNC_CHARS_CODES is not None) and (len(SMALL_UNC_CHARS_CODES) > 0)
    use_half = (font_half is not None) and (HALF_UNC_CHARS_CODES is not None) and (len(HALF_UNC_CHARS_CODES) > 0)
    nanpa_params = RenderParams(
        padding=cartouche_padding,
        outer_padding=0,
        radius=cartouche_radius,
        outline_width=cartouche_outline_width,
        include_cartouche=True,   # rectangle cartouche (existing behavior for detected nanpa-caps)
        base_bg=(0, 0, 0, 0),
        overlay_bg=(0, 0, 0, 0),
        group_fraction_triplets=True,
        fraction_group_size=3,
        caps_label_style="upper",
        glyph_font_small=(font_small if use_small else None),
        small_ucsur_chars=(SMALL_UNC_CHARS_CODES if use_small else None),
        small_glyph_dy=(small_dy if use_small else 0),
        glyph_font_half=(font_half if use_half else None),
        half_ucsur_chars=(HALF_UNC_CHARS_CODES if use_half else None),
        half_glyph_dy=(half_dy if use_half else 0),
        number_word_style=number_word_style,
        mixed_style=mixed_style,
        relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
        relaxed_nanpa_linjan_rendering=relaxed_nanpa_linjan_rendering,
        abbreviate_numeric_cartouches=abbreviate_numeric_cartouches,
        abbreviate_nene_as_en=preserve_nene_as_en,
        compact_nene_breaks_as_en=compact_nene_breaks_as_en,
    )

    # For explicit [ ... ] cartouches: rely on the UCSUR control chars (no drawn rectangle)
    bracket_cartouche_params = RenderParams(
        padding=0,
        outer_padding=0,
        radius=0,
        outline_width=0,
        include_cartouche=False,  # IMPORTANT: no drawn cartouche; the font control chars handle it
        base_bg=(0, 0, 0, 0),
        overlay_bg=(0, 0, 0, 0),
        group_fraction_triplets=True,
        fraction_group_size=3,
        caps_label_style="upper",
        glyph_font_small=None,
        small_ucsur_chars=None,
        small_glyph_dy=0,
    )

    plans: List[_SegmentPlan] = []
    pending_words: List[str] = []

    def _flush_text_run():
        nonlocal pending_words
        if not pending_words:
            return

        glyph = _tp_words_to_ucsur_no_spaces(pending_words, strict_words=strict_words)
        pending_words = []
        if not glyph:
            return

        _, reserve_bbox = measure_reserve_bbox(
            text=glyph,
            font=font_large,
            padding=0,
            include_cartouche=False,
            outer_padding=0,
            font_small=None,
            small_chars=None,
            small_dy=0,
        )
        (w, h), (sx, sy) = required_image_size_for_bbox(reserve_bbox)
        plans.append(
            _SegmentPlan(
                kind="text",
                glyph_string=glyph,
                reserve_bbox=reserve_bbox,
                w=w,
                h=h,
                shift_x=sx,
                shift_y=sy,
                params=text_params,
            )
        )

    def _word_to_ucsur(word_core: str) -> str:
        if not word_core:
            return ""
        uc = WORDS_TO_UNC_CODES_MAP.get(word_core.lower())
        if uc is None:
            if strict_words:
                raise ValueError(f"Unknown Toki Pona word {word_core!r}; not present in WORDS_TO_UNC_CODES_MAP.")
            return ""
        return uc

    def _append_bracket_cartouche_segment(glyph_inner: str):
        # Wrap with control chars requested
        glyph = CARTOUCHE_START_UCSUR + (glyph_inner or "") + CARTOUCHE_END_UCSUR
        _, reserve_bbox = measure_reserve_bbox(
            text=glyph,
            font=font_large,
            padding=0,
            include_cartouche=False,
            outer_padding=0,
            font_small=None,
            small_chars=None,
            small_dy=0,
        )
        (w, h), (sx, sy) = required_image_size_for_bbox(reserve_bbox)
        plans.append(
            _SegmentPlan(
                kind="cartouche",   # treat like a cartouche segment for vertical centering
                glyph_string=glyph,
                reserve_bbox=reserve_bbox,
                w=w,
                h=h,
                shift_x=sx,
                shift_y=sy,
                params=bracket_cartouche_params,
            )
        )

    # -------------------------
    # Main scan across tokens
    # -------------------------
    i = 0
    n = len(raw_tokens)

    while i < n:
        tok = raw_tokens[i]

        # ---------- explicit cartouche start ----------
        if tok == "[":
            _flush_text_run()

            # Collect content until matching ']' (supports nesting)
            depth = 1
            i += 1

            # Build inner glyph stream (NO spaces)
            inner_glyph_parts: List[str] = []

            # Work on a local token window until depth returns to 0 or line ends
            inner_tokens: List[str] = []
            while i < n and depth > 0:
                t = raw_tokens[i]
                if t == "[":
                    # Nested cartouche start: map to control char immediately
                    inner_glyph_parts.append(CARTOUCHE_START_UCSUR)
                    depth += 1
                    i += 1
                    continue
                if t == "]":
                    depth -= 1
                    if depth == 0:
                        i += 1
                        break
                    # Nested close
                    inner_glyph_parts.append(CARTOUCHE_END_UCSUR)
                    i += 1
                    continue

                inner_tokens.append(t)
                i += 1

            # Now parse inner_tokens for greedy nanpa-caps runs, otherwise TP words
            # (same logic as outside, but appends into inner_glyph_parts)
            j = 0
            m = len(inner_tokens)
            cores = [_letters_only(t) for t in inner_tokens]

            while j < m:
                c0 = cores[j]
                if not c0:
                    j += 1
                    continue

                best_j: Optional[int] = None
                best_caps: Optional[str] = None

                j_max = min(m, j + max_caps_words)
                for k in range(j_max, j, -1):
                    chunk = cores[j:k]
                    if any((not x) for x in chunk):
                        continue
                    candidate = "".join(chunk).upper()
                    if not (candidate.startswith("NE") and candidate.endswith("N")):
                        continue
                    if not re.fullmatch(r"[A-Z]+", candidate):
                        continue
                    try:
                        _ = nanpa_caps_to_numeric_expression(
                            candidate,
                            thousands_char=thousands_char,
                            group_thousands=group_thousands_in_validation,
                        )
                    except Exception:
                        continue
                    best_j = k
                    best_caps = candidate
                    break

                if best_j is not None and best_caps is not None:
                    # Append the UCSUR glyphs for this caps run (NO spaces)
                    encoded = _encode_caps_to_cartouche_ucsur(
                        best_caps,
                        thousands_char=thousands_char,
                        number_word_style=number_word_style,
                        mixed_style=mixed_style,
                        relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
                        relaxed_nanpa_linjan_rendering=relaxed_nanpa_linjan_rendering,
                        abbreviate_numeric_cartouches=abbreviate_numeric_cartouches,
                        preserve_nene_as_en=preserve_nene_as_en,
                        compact_nene_breaks_as_en=compact_nene_breaks_as_en,
                    )
                    inner_glyph_parts.append(encoded[1:-1])
                    j = best_j
                    continue

                # Otherwise a single TP word core
                uc = _word_to_ucsur(c0.lower())
                if uc:
                    inner_glyph_parts.append(uc)
                j += 1

            _append_bracket_cartouche_segment("".join(inner_glyph_parts))
            continue

        # ---------- explicit cartouche end outside of any '[' ----------
        # Map ']' to the end control char as a standalone glyph (best-effort)
        if tok == "]":
            _flush_text_run()
            _append_bracket_cartouche_segment(CARTOUCHE_END_UCSUR)
            i += 1
            continue

        # ---------- normal path: attempt greedy nanpa-caps from here ----------
        # Build a "cores" view on-the-fly from remaining tokens (excluding brackets)
        # We re-check greedily starting at i over the next max_caps_words non-bracket tokens.
        # If a bracket is encountered, we stop the candidate window before it.

        if tok not in ("[", "]"):
            # Build a list of upcoming non-bracket token cores up to max_caps_words,
            # but also keep their original indices so we can advance i correctly.
            idxs: List[int] = []
            cores_window: List[str] = []

            tpos = i
            while tpos < n and len(cores_window) < max_caps_words:
                if raw_tokens[tpos] in ("[", "]"):
                    break
                c = _letters_only(raw_tokens[tpos])
                idxs.append(tpos)
                cores_window.append(c)
                tpos += 1

            # Greedy match within the window
            best_k: Optional[int] = None
            best_caps: Optional[str] = None

            for k in range(len(cores_window), 0, -1):
                chunk = cores_window[:k]
                if any((not x) for x in chunk):
                    continue
                candidate = "".join(chunk).upper()
                if not (candidate.startswith("NE") and candidate.endswith("N")):
                    continue
                if not re.fullmatch(r"[A-Z]+", candidate):
                    continue
                try:
                    _ = nanpa_caps_to_numeric_expression(
                        candidate,
                        thousands_char=thousands_char,
                        group_thousands=group_thousands_in_validation,
                    )
                except Exception:
                    continue
                best_k = k
                best_caps = candidate
                break

            if best_k is not None and best_caps is not None:
                _flush_text_run()

                encoded = _encode_caps_to_cartouche_ucsur(
                    best_caps,
                    thousands_char=thousands_char,
                    number_word_style=number_word_style,
                    mixed_style=mixed_style,
                    relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
                    relaxed_nanpa_linjan_rendering=relaxed_nanpa_linjan_rendering,
                    abbreviate_numeric_cartouches=abbreviate_numeric_cartouches,
                    preserve_nene_as_en=preserve_nene_as_en,
                    compact_nene_breaks_as_en=compact_nene_breaks_as_en,
                )
                glyph = encoded[1:-1]

                use_mixed = _mixed_font_enabled(nanpa_params.glyph_font_small, nanpa_params.small_ucsur_chars)
                use_half_local = _multi_font_enabled(nanpa_params.glyph_font_half, nanpa_params.half_ucsur_chars)
                _, reserve_bbox = measure_reserve_bbox(
                    text=glyph,
                    font=font_large,
                    padding=nanpa_params.padding,
                    include_cartouche=True,
                    outer_padding=0,
                    font_small=(nanpa_params.glyph_font_small if use_mixed else None),
                    small_chars=(nanpa_params.small_ucsur_chars if use_mixed else None),
                    small_dy=(nanpa_params.small_glyph_dy if use_mixed else 0),
                    font_half=(nanpa_params.glyph_font_half if use_half_local else None),
                    half_chars=(nanpa_params.half_ucsur_chars if use_half_local else None),
                    half_dy=(nanpa_params.half_glyph_dy if use_half_local else 0),
                )

                (w, h), (sx, sy) = required_image_size_for_bbox(reserve_bbox)

                plans.append(
                    _SegmentPlan(
                        kind="nanpa",
                        glyph_string=glyph,
                        reserve_bbox=reserve_bbox,
                        w=w,
                        h=h,
                        shift_x=sx,
                        shift_y=sy,
                        params=nanpa_params,
                    )
                )

                # Advance i to the token after the match
                i = idxs[best_k - 1] + 1
                continue

            # Not a caps run: treat as TP word (letters-only)
            c0 = _letters_only(tok)
            if c0:
                pending_words.append(c0.lower())

        i += 1

    _flush_text_run()
    return plans


def render_multiline_tp_text_with_nanpa_cartouches(
    text: str,
    *,
    font_large: ImageFont.FreeTypeFont,
    font_small: Optional[ImageFont.FreeTypeFont],
    small_dy: int = 0,
    font_half: Optional[ImageFont.FreeTypeFont] = None,
    half_dy: int = 0,
    # layout
    margin: int = 24,
    line_gap: int = 12,
    segment_gap: int = 0,  # no extra gap between segments
    # cartouche style
    cartouche_padding: int = 18,
    cartouche_radius: int = 22,
    cartouche_outline_width: int = 6,
    # parsing/validation
    strict_words: bool = False,
    max_caps_words: int = 20,
    thousands_char: str = ",",
    number_word_style: str = DEFAULT_NUMBER_WORD_STYLE,
    mixed_style: str = DEFAULT_MIXED_STYLE,
    relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING,
    relaxed_nanpa_linjan_rendering: bool = DEFAULT_RELAXED_NANPA_LINJAN_RENDERING,
    abbreviate_numeric_cartouches: bool = DEFAULT_ABBREVIATE_NUMERIC_CARTOUCHES,
    preserve_nene_as_en: bool = DEFAULT_PRESERVE_NUMERIC_CARTOUCHE_BREAKS_IN_ABBREVIATION,
    compact_nene_breaks_as_en: bool = False,
    # background
    base_bg: Tuple[int, int, int, int] = (255, 255, 255, 255),
) -> Image.Image:

    if text is None:
        raise ValueError("text must be a string, not None")

    lines = str(text).split("\n")

    planned_lines: List[List[_SegmentPlan]] = []
    line_widths: List[int] = []
    line_heights: List[int] = []
    line_min_tops: List[int] = []  # NEW: negative/positive min top offset per line

    ascent, descent = font_large.getmetrics()
    empty_line_h = max(1, int(ascent + descent))

    for line in lines:
        segs = _plan_line_segments(
            line,
            font_large=font_large,
            font_small=font_small,
            small_dy=small_dy,
            font_half=font_half,
            half_dy=half_dy,
            strict_words=strict_words,
            max_caps_words=max_caps_words,
            segment_gap=segment_gap,
            cartouche_padding=cartouche_padding,
            cartouche_radius=cartouche_radius,
            cartouche_outline_width=cartouche_outline_width,
            thousands_char=thousands_char,
            group_thousands_in_validation=True,
            number_word_style=number_word_style,
            mixed_style=mixed_style,
            relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
            relaxed_nanpa_linjan_rendering=relaxed_nanpa_linjan_rendering,
            abbreviate_numeric_cartouches=abbreviate_numeric_cartouches,
            preserve_nene_as_en=preserve_nene_as_en,
            compact_nene_breaks_as_en=compact_nene_breaks_as_en,
        )

        planned_lines.append(segs)

        if not segs:
            line_widths.append(0)
            line_heights.append(empty_line_h)
            line_min_tops.append(0)
            continue

        # --- NEW: define a reference glyph-run height (non-cartouche) for vertical centering ---
        non_cart_h = 0
        for s in segs:
            if s.kind not in {"nanpa", "cartouche"}:
                non_cart_h = max(non_cart_h, s.h)

        # If the line is ONLY cartouches, do not apply special centering (no reference run).
        ref_h = non_cart_h if non_cart_h > 0 else max(s.h for s in segs)

        # Assign per-segment y_off:
        # - text stays at y_off = 0
        # - nanpa cartouche is centered around the reference run (may go negative)
        for idx, s in enumerate(segs):
            if s.kind in {"nanpa", "cartouche"} and non_cart_h > 0:
                segs[idx].y_off = int(round((ref_h - s.h) / 2.0))
            else:
                segs[idx].y_off = 0

        # Compute the line's true vertical bounds (to accommodate negative y_off)
        min_top = min(s.y_off for s in segs)
        max_bottom = max(s.y_off + s.h for s in segs)
        line_h = max(1, int(max_bottom - min_top))

        line_min_tops.append(int(min_top))
        line_heights.append(line_h)

        w = sum(s.w for s in segs) + segment_gap * max(0, len(segs) - 1)
        line_widths.append(w)

    total_w = max(line_widths) if line_widths else 1
    total_h = sum(line_heights) + line_gap * max(0, len(line_heights) - 1)

    img_w = max(1, int(total_w + 2 * margin))
    img_h = max(1, int(total_h + 2 * margin))

    base = Image.new("RGBA", (img_w, img_h), base_bg)

    y = margin
    for line_idx, segs in enumerate(planned_lines):
        x = margin

        # NEW: shift the line origin down by -min_top so negative offsets fit
        min_top = line_min_tops[line_idx] if line_idx < len(line_min_tops) else 0
        line_origin_y = int(y - min_top)

        for s in segs:
            base = _paste_glyph_string_via_overlay(
                base=base,
                glyph_string=s.glyph_string,
                reserve_bbox=s.reserve_bbox,
                font=font_large,
                # origin semantics:
                # - text segments: top-left of tight ink bbox (include_cartouche=False)
                # - nanpa segments: top-left of cartouche (include_cartouche=True)
                origin=(int(x + s.shift_x), int(line_origin_y + s.shift_y + s.y_off)),
                params=s.params,
            )
            x += s.w + segment_gap

        y += line_heights[line_idx] + line_gap

    return base


from dataclasses import dataclass
from typing import Callable, List, Optional, Tuple
import re
from PIL import Image, ImageDraw, ImageFont

# OpenType features (safe fallback below if unsupported)
_OT_FEATURES = ["calt", "liga", "ccmp"]
CARTOUCHE_SCALE_HALF_MAX_PX = 18
CARTOUCHE_SCALE_THIRD_MAX_PX = 29


def numeric_cartouche_opentype_features_for_font(font: ImageFont.ImageFont) -> List[str]:
    """Match the JS numeric-font feature thresholds: ss12 <=18px, ss13 <=29px."""
    features = list(_OT_FEATURES)
    size = int(getattr(font, "size", 0) or 0)
    if 0 < size <= CARTOUCHE_SCALE_HALF_MAX_PX:
        features.append("ss12")
    elif size <= CARTOUCHE_SCALE_THIRD_MAX_PX:
        features.append("ss13")
    return features


_WORD_EDGE_STRIP = re.compile(r"^[^a-zA-Z0-9¼½¾⅐⅑⅒⅓⅔⅕⅖⅗⅘⅙⅚⅛⅜⅝⅞+-]+|[^a-zA-Z0-9¼½¾⅐⅑⅒⅓⅔⅕⅖⅗⅘⅙⅚⅛⅜⅝⅞+-]+$")
_BRACKET_TOKEN_RE = re.compile(r"\[|\]|[^\s]+")
_RAW_UNICODE_CODEPOINT_TOKEN_RE = re.compile(r"^U\+([0-9A-Fa-f]{1,6})$", re.IGNORECASE)


def _raw_unicode_codepoint_token_to_char(token: str) -> Optional[str]:
    """Decode one exact ``U+hhhh`` token, rejecting non-scalar values."""
    match = _RAW_UNICODE_CODEPOINT_TOKEN_RE.fullmatch(str(token or ""))
    if match is None:
        return None
    codepoint = int(match.group(1), 16)
    if codepoint > 0x10FFFF or 0xD800 <= codepoint <= 0xDFFF:
        raise ValueError(f"Invalid Unicode scalar value: {token!r}")
    return chr(codepoint)

# Decimal-ish number token (single token), e.g. -1,234.56 or 42 or 9¾
_DECIMAL_TOKEN_RE = re.compile(
    r"""^[+-]?(?:(?:\d{1,3}(?:,\d{3})+)|\d+)(?:\.\d+)?$|^[+-]?(?:\d+)?[¼½¾⅐⅑⅒⅓⅔⅕⅖⅗⅘⅙⅚⅛⅜⅝⅞]$"""
)


_NUMERIC_INPUT_TOKEN_START_RE = re.compile(
    r"^[+-]?(?:\d|\.\d|[¼½¾⅐⅑⅒⅓⅔⅕⅖⅗⅘⅙⅚⅛⅜⅝⅞])"
)


def _looks_like_numeric_input_token(token: str) -> bool:
    """Cheap gate before invoking the full JavaScript-parity numeric parser.

    The mixed text renderer previously recognised only plain integers and
    decimals.  Arithmetic fact-sheet lines also require fractions, grouped
    thousands and scientific notation.  We still gate on a numeric-looking
    prefix so ordinary Toki Pona words are never reinterpreted as proper names.
    """
    value = str(token or "").strip()
    if not value:
        return False
    if value.upper().startswith("#~"):
        return True
    # Hex input begins with '#'. Delegate validation to the numeric parser;
    # invalid hash-prefixed input still falls through to ordinary text.
    if value.startswith("#"):
        return True
    return bool(_NUMERIC_INPUT_TOKEN_START_RE.match(value))

# Words that only exist in your nanpa-linja-n system (adjust if you add/remove markers)
_NLN_MARKER_WORDS = {
    "nanpa",
    "tasa", "tasan",
    "masa", "masan",
    "wasa", "wasan",
    "pasa", "pasan",
    "oselo", "nike", "esewi",
}

@dataclass
class _MixedRun:
    kind: str  # "text" | "cartouche"
    glyphs: str
    font: ImageFont.FreeTypeFont
    bbox: Tuple[int, int, int, int]  # bbox at (0,0)
    w: int
    h: int
    y_off: int = 0  # retained for compatibility; mixed lines use one shared baseline


def _safe_textbbox(
    draw: ImageDraw.ImageDraw,
    s: str,
    font: ImageFont.FreeTypeFont,
    *,
    features: Optional[List[str]] = None,
) -> Tuple[int, int, int, int]:
    if not s:
        return (0, 0, 0, 0)
    active_features = _OT_FEATURES if features is None else features
    try:
        return draw.textbbox((0, 0), s, font=font, features=active_features)
    except (TypeError, ValueError):
        return draw.textbbox((0, 0), s, font=font)


def _safe_draw_text(
    draw: ImageDraw.ImageDraw,
    xy: Tuple[int, int],
    s: str,
    font: ImageFont.FreeTypeFont,
    fill,
    *,
    features: Optional[List[str]] = None,
) -> None:
    if not s:
        return
    active_features = _OT_FEATURES if features is None else features
    try:
        draw.text(xy, s, font=font, fill=fill, features=active_features)
    except (TypeError, ValueError):
        draw.text(xy, s, font=font, fill=fill)


def _safe_textbbox_baseline(
    draw: ImageDraw.ImageDraw,
    s: str,
    font: ImageFont.FreeTypeFont,
) -> Tuple[int, int, int, int]:
    """Measure one shaped run relative to a left-baseline origin."""
    if not s:
        return (0, 0, 0, 0)
    try:
        return draw.textbbox(
            (0, 0),
            s,
            font=font,
            anchor="ls",
            features=_OT_FEATURES,
        )
    except (TypeError, ValueError):
        try:
            return draw.textbbox((0, 0), s, font=font, anchor="ls")
        except (TypeError, ValueError):
            ascent, _descent = font.getmetrics()
            left, top, right, bottom = _safe_textbbox(draw, s, font)
            return (left, top - ascent, right, bottom - ascent)


def _safe_draw_text_baseline(
    draw: ImageDraw.ImageDraw,
    xy: Tuple[int, int],
    s: str,
    font: ImageFont.FreeTypeFont,
    fill,
) -> None:
    """Draw one shaped run at a shared left-baseline origin."""
    if not s:
        return
    try:
        draw.text(
            xy,
            s,
            font=font,
            fill=fill,
            anchor="ls",
            features=_OT_FEATURES,
        )
    except (TypeError, ValueError):
        try:
            draw.text(xy, s, font=font, fill=fill, anchor="ls")
        except (TypeError, ValueError):
            ascent, _descent = font.getmetrics()
            draw.text((xy[0], xy[1] - ascent), s, font=font, fill=fill)


def wrap_numeric_cartouche_controls(glyph_string: str, *, include_cartouche: bool = True) -> str:
    """Wrap one numeric glyph stream in the UCSUR cartouche controls.

    The numeric-cartouche font owns the outline, internal scaling, positioning,
    and ligature construction.  Python supplies one complete shaping stream and
    must not draw a second rectangle or split the stream into per-glyph runs.
    """
    value = str(glyph_string or "")
    if not include_cartouche:
        return value
    if value.startswith(CARTOUCHE_START_UCSUR) and value.endswith(CARTOUCHE_END_UCSUR):
        return value
    return CARTOUCHE_START_UCSUR + value + CARTOUCHE_END_UCSUR


def render_shaped_ucsur_run_to_new_base(
    glyph_string: str,
    *,
    font: ImageFont.FreeTypeFont,
    outer_padding: int = 0,
    fg: Tuple[int, int, int, int] = (0, 0, 0, 255),
    background: Tuple[int, int, int, int] = (0, 0, 0, 0),
    features: Optional[List[str]] = None,
) -> Image.Image:
    """Render a complete UCSUR/OpenType run with exactly one shaping call."""
    text = str(glyph_string or "")
    padding = max(0, int(outer_padding))
    probe = Image.new("RGBA", (1, 1), (0, 0, 0, 0))
    probe_draw = ImageDraw.Draw(probe)
    left, top, right, bottom = _safe_textbbox(probe_draw, text, font, features=features)
    left_i = int(math.floor(left))
    top_i = int(math.floor(top))
    right_i = int(math.ceil(right))
    bottom_i = int(math.ceil(bottom))
    width = max(1, right_i - left_i + 2 * padding)
    height = max(1, bottom_i - top_i + 2 * padding)
    image = Image.new("RGBA", (width, height), background)
    draw = ImageDraw.Draw(image)
    _safe_draw_text(
        draw,
        (padding - left_i, padding - top_i),
        text,
        font,
        fg,
        features=features,
    )
    return image


def render_numeric_cartouche_ucsur_to_new_base(
    glyph_string: str,
    *,
    font: ImageFont.FreeTypeFont,
    include_cartouche: bool = True,
    outer_padding: int = 0,
    fg: Tuple[int, int, int, int] = (0, 0, 0, 255),
    background: Tuple[int, int, int, int] = (0, 0, 0, 0),
) -> Image.Image:
    """Render a pre-encoded numeric cartouche through the font alone."""
    shaped_stream = wrap_numeric_cartouche_controls(
        glyph_string,
        include_cartouche=include_cartouche,
    )
    return render_shaped_ucsur_run_to_new_base(
        shaped_stream,
        font=font,
        outer_padding=outer_padding,
        fg=fg,
        background=background,
        features=numeric_cartouche_opentype_features_for_font(font),
    )


def _tp_word_to_ucsur(word: str, *, strict: bool) -> str:
    w = (word or "").strip().lower()
    if not w:
        return ""
    if w == "zz":
        return "\u3000"
    uc = WORDS_TO_UNC_CODES_MAP.get(w)
    if uc is None:
        if strict:
            raise ValueError(f"Unknown Toki Pona word {w!r}; not present in WORDS_TO_UNC_CODES_MAP.")
        return ""
    return uc


def _encode_number_to_cartouche_ucsur(
    num_str: str,
    *,
    thousands_char: str = ",",
    negative_particle_word: str = "ona",
    number_word_style: str = DEFAULT_NUMBER_WORD_STYLE,
    mixed_style: str = DEFAULT_MIXED_STYLE,
    relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING,
    relaxed_nanpa_linjan_rendering: bool = DEFAULT_RELAXED_NANPA_LINJAN_RENDERING,
    nanpa_colon_parsing: bool = DEFAULT_NANPA_COLON_PARSING,
    nanpa_colon_rendering: bool = DEFAULT_NANPA_COLON_RENDERING,
    enable_hex_parsing: bool = DEFAULT_ENABLE_HEX_PARSING,
    enable_binary_parsing: bool = DEFAULT_ENABLE_BINARY_PARSING,
    enable_binary_rendering: bool = DEFAULT_ENABLE_BINARY_RENDERING,
    abbreviate_numeric_cartouches: bool = DEFAULT_ABBREVIATE_NUMERIC_CARTOUCHES,
    preserve_nene_as_en: bool = DEFAULT_PRESERVE_NUMERIC_CARTOUCHE_BREAKS_IN_ABBREVIATION,
    compact_nene_breaks_as_en: bool = False,
) -> str:
    """Parse a numeric expression and encode one numeric-cartouche run.

    The previous implementation detoured through the legacy ``nanpa_linja_n``
    word converter.  Using the parity parser directly keeps mixed fractions,
    shortened scientific notation, relaxed digit choices, telephone NENE
    breaks and ``#~`` input identical to the current JavaScript implementation.
    """
    if enable_binary_parsing or enable_binary_rendering:
        binary_semantic = parse_binary_input(
            str(num_str),
            relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
            abbreviate_numeric_cartouches=abbreviate_numeric_cartouches,
        )
        if binary_semantic is not None:
            words = binary_semantic_to_words(
                binary_semantic,
                abbreviated=abbreviate_numeric_cartouches,
                relaxed_rendering=relaxed_nanpa_linjan_rendering,
                number_word_style=number_word_style,
            )
            return CARTOUCHE_START_UCSUR + tp_words_to_nasin_nanpa_unicodes(words) + CARTOUCHE_END_UCSUR

    if enable_hex_parsing:
        semantic = parse_hex_input(
            str(num_str),
            relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
            abbreviate_numeric_cartouches=abbreviate_numeric_cartouches,
        )
        if semantic is not None:
            words = hex_semantic_to_words(
                semantic,
                abbreviated=abbreviate_numeric_cartouches,
                relaxed_rendering=relaxed_nanpa_linjan_rendering,
                number_word_style=number_word_style,
            )
            return CARTOUCHE_START_UCSUR + tp_words_to_nasin_nanpa_unicodes(words) + CARTOUCHE_END_UCSUR

    caps, _is_time_like = parse_numeric_input_to_caps(
        str(num_str),
        thousands_char=thousands_char,
        group_fraction_triplets=True,
        fraction_group_size=3,
        mixed_style=mixed_style,
        relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
        nanpa_colon_parsing=nanpa_colon_parsing,
        nanpa_colon_rendering=nanpa_colon_rendering,
    )
    return _encode_caps_to_cartouche_ucsur(
        caps,
        thousands_char=thousands_char,
        negative_particle_word=negative_particle_word,
        number_word_style=number_word_style,
        mixed_style=mixed_style,
        relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
        relaxed_nanpa_linjan_rendering=relaxed_nanpa_linjan_rendering,
        nanpa_colon_parsing=nanpa_colon_parsing,
        nanpa_colon_rendering=nanpa_colon_rendering,
        abbreviate_numeric_cartouches=abbreviate_numeric_cartouches,
        preserve_nene_as_en=preserve_nene_as_en,
        compact_nene_breaks_as_en=compact_nene_breaks_as_en,
    )


def encode_numeric_cartouche_ucsur(
    value: str,
    *,
    thousands_char: str = ",",
    negative_particle_word: str = "ona",
    number_word_style: str = DEFAULT_NUMBER_WORD_STYLE,
    mixed_style: str = DEFAULT_MIXED_STYLE,
    relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING,
    relaxed_nanpa_linjan_rendering: bool = DEFAULT_RELAXED_NANPA_LINJAN_RENDERING,
    nanpa_colon_parsing: bool = DEFAULT_NANPA_COLON_PARSING,
    nanpa_colon_rendering: bool = DEFAULT_NANPA_COLON_RENDERING,
    enable_hex_parsing: bool = DEFAULT_ENABLE_HEX_PARSING,
    enable_binary_parsing: bool = DEFAULT_ENABLE_BINARY_PARSING,
    enable_binary_rendering: bool = DEFAULT_ENABLE_BINARY_RENDERING,
    abbreviate_numeric_cartouches: bool = DEFAULT_ABBREVIATE_NUMERIC_CARTOUCHES,
    preserve_nene_as_en: bool = DEFAULT_PRESERVE_NUMERIC_CARTOUCHE_BREAKS_IN_ABBREVIATION,
    compact_nene_breaks_as_en: bool = False,
    include_cartouche_controls: bool = True,
) -> str:
    """Public font-shaped numeric-cartouche encoder."""
    encoded = _encode_number_to_cartouche_ucsur(
        value,
        thousands_char=thousands_char,
        negative_particle_word=negative_particle_word,
        number_word_style=number_word_style,
        mixed_style=mixed_style,
        relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
        relaxed_nanpa_linjan_rendering=relaxed_nanpa_linjan_rendering,
        nanpa_colon_parsing=nanpa_colon_parsing,
        nanpa_colon_rendering=nanpa_colon_rendering,
        enable_hex_parsing=enable_hex_parsing,
        enable_binary_parsing=enable_binary_parsing,
        enable_binary_rendering=enable_binary_rendering,
        abbreviate_numeric_cartouches=abbreviate_numeric_cartouches,
        preserve_nene_as_en=preserve_nene_as_en,
        compact_nene_breaks_as_en=compact_nene_breaks_as_en,
    )
    if include_cartouche_controls:
        return encoded
    if encoded.startswith(CARTOUCHE_START_UCSUR) and encoded.endswith(CARTOUCHE_END_UCSUR):
        return encoded[1:-1]
    return encoded


def _looks_like_nln_number_word(tok_core: str) -> bool:
    """
    Conservative detector for nanpa-linja-n words to avoid false positives like 'tan', 'lon', 'sin'.
    Strategy:
      - marker words always qualify
      - otherwise: must end with 'n', must NOT be a known TP word, and must be decodable by decode_nanpa_numbers_in_text
    """
    if not tok_core:
        return False
    t = tok_core.lower()
    if t in _NLN_MARKER_WORDS:
        return True
    if not t.endswith("n"):
        return False
    if t in WORDS_TO_UNC_CODES_MAP:
        return False
    try:
        dec = decode_nanpa_numbers_in_text(t, thousands_char="")
    except Exception:
        return False
    return bool(dec) and any(ch.isdigit() for ch in dec)


def _try_match_nln_word_run(
    tokens: List[str],
    start_idx: int,
    *,
    max_words: int,
    thousands_char: str,
) -> Optional[Tuple[int, str]]:
    """
    Attempt greedy longest match of a nanpa-linja-n number-word phrase starting at tokens[start_idx].

    Returns (end_idx_exclusive, numeric_string_decoded) if matched, else None.

    We decode by passing the candidate phrase to decode_nanpa_numbers_in_text; if it yields digits, we accept.
    """
    best: Optional[Tuple[int, str]] = None

    # Build cleaned cores for window
    cores: List[str] = []
    for j in range(start_idx, min(len(tokens), start_idx + max_words)):
        if tokens[j] in ("[", "]"):
            break
        core = _WORD_EDGE_STRIP.sub("", tokens[j])
        if not core or not core.isalpha():
            break
        cores.append(core)

    if not cores:
        return None

    # Greedy longest
    for k in range(len(cores), 0, -1):
        chunk = cores[:k]
        # Must look like NLN-ish tokens
        if not all(_looks_like_nln_number_word(w) for w in chunk):
            continue

        candidate_phrase = " ".join(chunk)
        try:
            decoded = decode_nanpa_numbers_in_text(candidate_phrase, thousands_char=thousands_char)
        except Exception:
            continue

        if decoded and any(ch.isdigit() for ch in decoded):
            best = (start_idx + k, decoded)
            break

    return best


def _try_match_caps_word_run(
    tokens: List[str],
    start_idx: int,
    *,
    max_words: int,
    thousands_char: str,
    group_thousands: bool = True,
) -> Optional[Tuple[int, str]]:
    """
    Greedy match for split-cartouche-caps runs, e.g. ["newen"] or ["n", "ene", "we", "n"] etc.
    Works ONLY on alphabetic cores; stops before '[' or ']'.

    Returns (end_idx_exclusive, decoded_numeric_expression) on success.
    """
    # Build a cores window (letters only) up to max_words, stopping at brackets
    cores: List[str] = []
    for j in range(start_idx, min(len(tokens), start_idx + max_words)):
        if tokens[j] in ("[", "]"):
            break
        core = _WORD_EDGE_STRIP.sub("", tokens[j])
        if not core or not core.isalpha():
            break
        cores.append(core)

    if not cores:
        return None

    # Greedy longest-first
    for k in range(len(cores), 0, -1):
        candidate = "".join(cores[:k]).upper()

        # Quick shape check
        if not (candidate.startswith("NE") and candidate.endswith("N")):
            continue
        if not re.fullmatch(r"[A-Z]+", candidate):
            continue

        try:
            decoded = nanpa_caps_to_numeric_expression(
                candidate,
                thousands_char=thousands_char,
                group_thousands=group_thousands,
            )
        except Exception:
            continue

        # Accept only if it actually yields digits
        if decoded and any(ch.isdigit() for ch in decoded):
            return (start_idx + k, decoded)

    return None

def _plan_line_runs_mixed_fonts(
    line: str,
    *,
    font_text: ImageFont.FreeTypeFont,
    font_number: ImageFont.FreeTypeFont,
    font_cartouche_text: Optional[ImageFont.FreeTypeFont] = None,  # NEW
    font_raw_codepoint: Optional[ImageFont.FreeTypeFont] = None,
    strict_words: bool,
    max_nln_words: int,
    max_caps_words: int,
    thousands_char: str,
    number_word_style: str = DEFAULT_NUMBER_WORD_STYLE,
    mixed_style: str = DEFAULT_MIXED_STYLE,
    relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING,
    relaxed_nanpa_linjan_rendering: bool = DEFAULT_RELAXED_NANPA_LINJAN_RENDERING,
    nanpa_colon_parsing: bool = DEFAULT_NANPA_COLON_PARSING,
    nanpa_colon_rendering: bool = DEFAULT_NANPA_COLON_RENDERING,
    enable_hex_parsing: bool = DEFAULT_ENABLE_HEX_PARSING,
    enable_binary_parsing: bool = DEFAULT_ENABLE_BINARY_PARSING,
    enable_binary_rendering: bool = DEFAULT_ENABLE_BINARY_RENDERING,
    abbreviate_numeric_cartouches: bool = DEFAULT_ABBREVIATE_NUMERIC_CARTOUCHES,
    preserve_nene_as_en: bool = DEFAULT_PRESERVE_NUMERIC_CARTOUCHE_BREAKS_IN_ABBREVIATION,
    compact_nene_breaks_as_en: bool = False,
) -> List[_MixedRun]:

    """
    Plan a line into mixed-font runs.

    - Outside explicit cartouche brackets: detect numbers and convert them to cartouche UCSUR,
      rendered with font_number.
    - Inside explicit [ ... ]: do not detect numbers; encode TP words as UCSUR and keep brackets
      as cartouche control chars. Render with font_text.

    Returns runs with:
      kind="text" or "cartouche"
      glyphs = UCSUR glyph string (may include cartouche control chars)
      font   = chosen font
      bbox,w,h measured at (0,0)
    """
    raw_tokens = _BRACKET_TOKEN_RE.findall(line or "")

    # measurement context
    tmp = Image.new("RGBA", (10, 10), (0, 0, 0, 0))
    d = ImageDraw.Draw(tmp)

    runs: List[_MixedRun] = []
    pending_words: List[str] = []
    pending_font: ImageFont.FreeTypeFont = font_text  # NEW


    # NEW: explicit cartouches ([ ... ]) should use the "sitelen" cartouche font,
    # not the modified number font. Default fallback: font_text.
    cartouche_font = font_cartouche_text or font_text

    depth = 0
    i = 0

    def _append_run(kind: str, glyphs: str, font: ImageFont.FreeTypeFont):
        if not glyphs:
            return
        bbox = _safe_textbbox_baseline(d, glyphs, font)
        l, t, r, b = bbox
        w = int(max(0, r - l))
        h = int(max(0, b - t))
        runs.append(
            _MixedRun(
                kind=kind,
                glyphs=glyphs,
                font=font,
                bbox=bbox,
                w=w,
                h=h,
            )
        )

    def _flush_text_words():
        nonlocal pending_words, pending_font
        if not pending_words:
            return
        glyphs = _tp_words_to_ucsur_no_spaces(pending_words, strict_words=strict_words)
        pending_words = []
        _append_run("text", glyphs, pending_font)


    def _append_text_token(tok: str):
        nonlocal pending_font
        # We only convert *word cores* to UCSUR; punctuation is ignored here.
        core = _WORD_EDGE_STRIP.sub("", tok.lower())
        if not core:
            return

        # NEW: inside explicit cartouche brackets, use cartouche_font (sitelen).
        desired_font = cartouche_font if depth > 0 else font_text

        # If font changes mid-run, flush so each run has a single font.
        if pending_words and pending_font != desired_font:
            _flush_text_words()

        pending_font = desired_font
        pending_words.append(core)


    while i < len(raw_tokens):
        tok = raw_tokens[i]

        # ----- explicit cartouche brackets: emit ONE shaped run: start + inner + end -----
        if tok == "[":
            _flush_text_words()

            depth = 1
            i += 1  # consume '['
            inner_parts: List[str] = []

            while i < len(raw_tokens) and depth > 0:
                t = raw_tokens[i]

                if t == "[":
                    # nested cartouche start (optional support)
                    inner_parts.append(CARTOUCHE_START_UCSUR)
                    depth += 1
                    i += 1
                    continue

                if t == "]":
                    depth -= 1
                    if depth == 0:
                        i += 1  # consume the matching ']'
                        break
                    # nested cartouche end
                    inner_parts.append(CARTOUCHE_END_UCSUR)
                    i += 1
                    continue

                # normal token inside cartouche: encode TP word to UCSUR; ignore punctuation-only tokens
                core = _WORD_EDGE_STRIP.sub("", t.lower())
                if core:
                    inner_parts.append(_tp_word_to_ucsur(core, strict=strict_words))

                i += 1

            # If no closing ']', be tolerant: just close it logically
            glyphs = CARTOUCHE_START_UCSUR + "".join(inner_parts) + CARTOUCHE_END_UCSUR
            _append_run("cartouche", glyphs, cartouche_font)
            continue



        # ============================================================
        # OUTSIDE CARTOUCHE: detect/convert numbers
        # ============================================================
        if depth == 0:
            # Explicit U+ codepoint tokens are ordinary text runs, not Toki Pona
            # word names or numeric-cartouche input.
            raw_codepoint_char = _raw_unicode_codepoint_token_to_char(tok)
            if raw_codepoint_char is not None:
                _flush_text_words()
                _append_run(
                    "text",
                    raw_codepoint_char,
                    font_raw_codepoint or font_text,
                )
                i += 1
                continue

            # (1) caps word-run (e.g., "newen" etc.)
            m_caps = _try_match_caps_word_run(
                raw_tokens,
                i,
                max_words=max_caps_words,
                thousands_char=thousands_char,
                group_thousands=True,
            )
            if m_caps is not None:
                end_i, decoded_numeric = m_caps
                _flush_text_words()

                # IMPORTANT: _encode_number_to_cartouche_ucsur() ALREADY WRAPS with START/END
                cartouche_glyphs = _encode_number_to_cartouche_ucsur(
                    decoded_numeric,
                    thousands_char=thousands_char,
                    number_word_style=number_word_style,
                    mixed_style=mixed_style,
                    relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
                    relaxed_nanpa_linjan_rendering=relaxed_nanpa_linjan_rendering,
                    nanpa_colon_parsing=nanpa_colon_parsing,
                    nanpa_colon_rendering=nanpa_colon_rendering,
                    abbreviate_numeric_cartouches=abbreviate_numeric_cartouches,
                    preserve_nene_as_en=preserve_nene_as_en,
                    compact_nene_breaks_as_en=compact_nene_breaks_as_en,
                )

                _append_run("cartouche", cartouche_glyphs, font_number)
                i = end_i
                continue

            # (X) #~ abbreviation token
            if (tok or "").startswith("#~"):
                _flush_text_words()

                payload = parse_hash_tilde_payload(tok)              # validation-only
                caps = hash_tilde_payload_to_nanpa_caps(payload)     # downstream conversion
                cartouche_glyphs = _encode_caps_to_cartouche_ucsur(
                    caps,
                    thousands_char=thousands_char,
                    number_word_style=number_word_style,
                    mixed_style=mixed_style,
                    relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
                    relaxed_nanpa_linjan_rendering=relaxed_nanpa_linjan_rendering,
                    nanpa_colon_parsing=nanpa_colon_parsing,
                    nanpa_colon_rendering=nanpa_colon_rendering,
                    abbreviate_numeric_cartouches=abbreviate_numeric_cartouches,
                    preserve_nene_as_en=preserve_nene_as_en,
                    compact_nene_breaks_as_en=compact_nene_breaks_as_en,
                )

                _append_run("cartouche", cartouche_glyphs, font_number)
                i += 1
                continue

            # (2) numeric input token.  Use the full parity parser so fractions,
            # grouped thousands, mixed fractions, dates/times and scientific
            # notation follow the same grammar as standalone numeric input.
            if _looks_like_numeric_input_token(tok):
                try:
                    cartouche_glyphs = _encode_number_to_cartouche_ucsur(
                        tok,
                        thousands_char=thousands_char,
                        number_word_style=number_word_style,
                        mixed_style=mixed_style,
                        relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
                        relaxed_nanpa_linjan_rendering=relaxed_nanpa_linjan_rendering,
                        nanpa_colon_parsing=nanpa_colon_parsing,
                        nanpa_colon_rendering=nanpa_colon_rendering,
                        enable_hex_parsing=enable_hex_parsing,
                        enable_binary_parsing=enable_binary_parsing,
                        enable_binary_rendering=enable_binary_rendering,
                        abbreviate_numeric_cartouches=abbreviate_numeric_cartouches,
                        preserve_nene_as_en=preserve_nene_as_en,
                        compact_nene_breaks_as_en=compact_nene_breaks_as_en,
                    )
                except (TypeError, ValueError):
                    # A numeric-looking but invalid token remains ordinary text
                    # or unknown input, matching the tolerant mixed renderer.
                    pass
                else:
                    _flush_text_words()
                    _append_run("cartouche", cartouche_glyphs, font_number)
                    i += 1
                    continue

            # (3) optional NLN word-run detection (only if you want it active)
            m_nln = _try_match_nln_word_run(
                raw_tokens,
                i,
                max_words=max_nln_words,
                thousands_char=thousands_char,
            )
            if m_nln is not None:
                end_i, decoded_numeric = m_nln
                _flush_text_words()
                cartouche_glyphs = _encode_number_to_cartouche_ucsur(
                    decoded_numeric,
                    thousands_char=thousands_char,
                    number_word_style=number_word_style,
                    mixed_style=mixed_style,
                    relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
                    relaxed_nanpa_linjan_rendering=relaxed_nanpa_linjan_rendering,
                    nanpa_colon_parsing=nanpa_colon_parsing,
                    nanpa_colon_rendering=nanpa_colon_rendering,
                    abbreviate_numeric_cartouches=abbreviate_numeric_cartouches,
                    preserve_nene_as_en=preserve_nene_as_en,
                    compact_nene_breaks_as_en=compact_nene_breaks_as_en,
                )
                _append_run("cartouche", cartouche_glyphs, font_number)
                i = end_i
                continue

        # ============================================================
        # DEFAULT: treat token as TP word (inside or outside cartouche)
        # ============================================================
        _append_text_token(tok)
        i += 1

    _flush_text_words()

    # Merge adjacent runs with same kind+font (keeps measurement sane, reduces draw calls)
    merged: List[_MixedRun] = []
    for r in runs:
        if not r.glyphs:
            continue
        if merged and merged[-1].font == r.font and merged[-1].kind == r.kind:
            # merge strings, then re-measure merged bbox
            merged[-1].glyphs += r.glyphs
            bbox = _safe_textbbox_baseline(d, merged[-1].glyphs, merged[-1].font)
            l, t, rr, bb = bbox
            merged[-1].bbox = bbox
            merged[-1].w = int(max(0, rr - l))
            merged[-1].h = int(max(0, bb - t))
        else:
            merged.append(r)

    return merged




def render_multiline_tp_text_with_mixed_fonts_number_cartouches(
    text: str,
    *,
    font_text: ImageFont.FreeTypeFont,
    font_number: ImageFont.FreeTypeFont,
    font_cartouche_text: Optional[ImageFont.FreeTypeFont] = None,  # NEW
    font_raw_codepoint: Optional[ImageFont.FreeTypeFont] = None,
    margin: int = 24,
    line_gap: int = 12,
    run_gap: int = 0,
    strict_words: bool = False,
    max_nln_words: int = 20,
    max_caps_words: int = 20,
    thousands_char: str = ",",
    bg=(255, 255, 255, 255),
    fg=(0, 0, 0, 255),
    number_word_style: str = DEFAULT_NUMBER_WORD_STYLE,
    mixed_style: str = DEFAULT_MIXED_STYLE,
    relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING,
    relaxed_nanpa_linjan_rendering: bool = DEFAULT_RELAXED_NANPA_LINJAN_RENDERING,
    nanpa_colon_parsing: bool = DEFAULT_NANPA_COLON_PARSING,
    nanpa_colon_rendering: bool = DEFAULT_NANPA_COLON_RENDERING,
    enable_hex_parsing: bool = DEFAULT_ENABLE_HEX_PARSING,
    enable_binary_parsing: bool = DEFAULT_ENABLE_BINARY_PARSING,
    enable_binary_rendering: bool = DEFAULT_ENABLE_BINARY_RENDERING,
    abbreviate_numeric_cartouches: bool = DEFAULT_ABBREVIATE_NUMERIC_CARTOUCHES,
    preserve_nene_as_en: bool = DEFAULT_PRESERVE_NUMERIC_CARTOUCHE_BREAKS_IN_ABBREVIATION,
    compact_nene_breaks_as_en: bool = False,
) -> Image.Image:

    """
    Mixed-font multiline renderer:

    - Converts TP words -> UCSUR (font_text).
    - Detects decimal tokens and nanpa-linja-n number-word runs ONLY outside explicit cartouches ([...]).
    - Converts detected numbers -> canonical nanpa-linja-n -> UCSUR, wraps with cartouche control chars,
      and renders those runs with font_number.
    - Explicit cartouches ([...]) are rendered as cartouche control runs using font_text.
    - Every run on a line is measured and drawn from one shared typographic baseline.
    """
    if text is None:
        raise ValueError("text must be a string, not None")

    lines = str(text).split("\n")

    # measure context
    tmp = Image.new("RGBA", (10, 10), (0, 0, 0, 0))
    d = ImageDraw.Draw(tmp)

    planned: List[List[_MixedRun]] = []
    line_widths: List[int] = []
    line_heights: List[int] = []
    line_min_tops: List[int] = []

    for line in lines:
        runs = _plan_line_runs_mixed_fonts(
            line,
            font_text=font_text,
            font_number=font_number,
            font_cartouche_text=font_cartouche_text,  # NEW
            font_raw_codepoint=font_raw_codepoint,
            strict_words=strict_words,
            max_nln_words=max_nln_words,
            max_caps_words=max_caps_words,
            thousands_char=thousands_char,
            number_word_style=number_word_style,
            mixed_style=mixed_style,
            relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
            relaxed_nanpa_linjan_rendering=relaxed_nanpa_linjan_rendering,
            nanpa_colon_parsing=nanpa_colon_parsing,
            nanpa_colon_rendering=nanpa_colon_rendering,
            enable_hex_parsing=enable_hex_parsing,
            enable_binary_parsing=enable_binary_parsing,
            enable_binary_rendering=enable_binary_rendering,
            abbreviate_numeric_cartouches=abbreviate_numeric_cartouches,
            preserve_nene_as_en=preserve_nene_as_en,
            compact_nene_breaks_as_en=compact_nene_breaks_as_en,
        )


        planned.append(runs)

        if not runs:
            a, desc = font_text.getmetrics()
            h = max(1, a + desc)
            line_widths.append(0)
            line_heights.append(h)
            line_min_tops.append(0)
            continue

        # All run bboxes are measured relative to baseline y=0.  Their union
        # determines the line box, while every run retains the same baseline.
        for r in runs:
            r.y_off = 0
        min_top = min(r.bbox[1] for r in runs)
        max_bottom = max(r.bbox[3] for r in runs)
        line_h = max(1, int(max_bottom - min_top))
        line_min_tops.append(int(min_top))
        line_heights.append(line_h)

        w = sum(r.w for r in runs) + run_gap * max(0, len(runs) - 1)
        line_widths.append(int(w))

    total_w = max(line_widths, default=1)
    total_h = sum(line_heights) + line_gap * max(0, len(line_heights) - 1)

    img_w = max(1, int(total_w + 2 * margin))
    img_h = max(1, int(total_h + 2 * margin))

    img = Image.new("RGBA", (img_w, img_h), bg)
    draw = ImageDraw.Draw(img)

    y = margin
    for li, runs in enumerate(planned):
        x = margin

        # Place one baseline far enough below the line's highest ink to avoid
        # clipping, then draw every ordinary and numeric run at that baseline.
        line_baseline_y = int(y - line_min_tops[li])

        for r in runs:
            left, _top, _right, _bottom = r.bbox
            dx = int(x - left)
            _safe_draw_text_baseline(
                draw,
                (dx, line_baseline_y),
                r.glyphs,
                r.font,
                fg,
            )

            x += int(r.w) + int(run_gap)

        y += int(line_heights[li]) + int(line_gap)

    return img

# ============================================================================
# JavaScript NanpaParser parity layer (renderer reference v62)
# ============================================================================
# These definitions intentionally replace the legacy numeric helpers above while
# retaining their public names and compatible call signatures.  The reference is
# renderer-fontuploads-renderer-preview-bottom-detect-final-fixed(62).js.

_STRICT_DIGIT_TOKENS = {"NI", "WE", "TE", "SE", "NA", "LE", "NU", "ME", "PE", "JE"}
_RELAXED_DIGIT_TOKENS = {"WA", "TU", "LU", "MU", "PI", "JO"}
_DIGIT_TOKENS = _STRICT_DIGIT_TOKENS | _RELAXED_DIGIT_TOKENS
_TOKEN_PREFIXES = ("KEKEKE", "KEKE", "KO", "KE", "NONONO", "NONO", "NOKO", "OK", "NE", "NS", "NO")

_RELAXED_TOKEN_TO_STRICT_TOKEN = {
    "WA": "WE", "TU": "TE", "LU": "LE", "MU": "ME", "PI": "PE", "JO": "JE",
}
_RELAXED_TOKEN_TO_RENDER_WORDS = {
    "WE": ["wan", "ala"], "WA": ["wan", "ala"],
    "TE": ["tu", "uta"], "TU": ["tu", "uta"],
    "LE": ["luka", "uta"], "LU": ["luka", "uta"],
    "ME": ["mun", "uta"], "MU": ["mun", "uta"],
    "PE": ["pipi", "ike"], "PI": ["pipi", "ike"],
    "JE": ["jo", "open"], "JO": ["jo", "open"],
}
_STRICT_TO_RELAXED_OUTPUT_TOKEN = {
    "WE": "WA", "TE": "TU", "LE": "LU", "ME": "MU", "PE": "PI", "JE": "JO",
}
_STRICT_DEC_DIGIT_TO_TOKEN = {
    "0": "NI", "1": "WE", "2": "TE", "3": "SE", "4": "NA",
    "5": "LE", "6": "NU", "7": "ME", "8": "PE", "9": "JE",
}
_RELAXED_DEC_DIGIT_TO_TOKEN = {
    "0": "NI", "1": "WA", "2": "TU", "3": "SE", "4": "NA",
    "5": "LU", "6": "NU", "7": "MU", "8": "PI", "9": "JO",
}
_TOKEN_TO_DIGIT_WORD = {
    "NI": "ijo", "WE": "wan", "WA": "wan", "TE": "tu", "TU": "tu",
    "SE": "seli", "NA": "awen", "LE": "luka", "LU": "luka",
    "NU": "utala", "ME": "mun", "MU": "mun", "PE": "pipi",
    "PI": "pipi", "JE": "jo", "JO": "jo",
}
_TOKEN_TO_DIGIT_CHAR = {
    "NI": "0", "WE": "1", "WA": "1", "TE": "2", "TU": "2",
    "SE": "3", "NA": "4", "LE": "5", "LU": "5", "NU": "6",
    "ME": "7", "MU": "7", "PE": "8", "PI": "8", "JE": "9", "JO": "9",
}
_DIGIT_TOKEN_TO_CHAR = dict(_TOKEN_TO_DIGIT_CHAR)
_NUMBER_CODE_LETTER_TO_PAIR = {
    "I": "NI", "W": "WE", "T": "TE", "S": "SE", "A": "NA",
    "L": "LE", "U": "NU", "M": "ME", "P": "PE", "J": "JE",
}
_TOKEN_TO_NUMBER_CODE_LETTER = {
    "NI": "I", "WE": "W", "WA": "W", "TE": "T", "TU": "T",
    "SE": "S", "NA": "A", "LE": "L", "LU": "L", "NU": "U",
    "ME": "M", "MU": "M", "PE": "P", "PI": "P", "JE": "J", "JO": "J",
}

# Renderer scale tiers.  These are codepoint/string sets because Pillow receives
# UCSUR characters rather than integer codepoints.
SMALL_UNC_CHARS_CODES = {
    WORDS_TO_UNC_CODES_MAP[w]
    for w in ("nanpa", "nena", "en", "ala", "ike", "uta", "open")
}
TWO_THIRDS_UNC_CHARS_CODES = {
    WORDS_TO_UNC_CODES_MAP[w]
    for w in ("ona", "o", "kulupu", "kipisi", "kin")
}
ONE_THIRD_UNC_CHARS_CODES = {WORDS_TO_UNC_CODES_MAP["kasi"]}
HALF_UNC_CHARS_CODES = {WORDS_TO_UNC_CODES_MAP["kala"]}


def canonicalize_scientific_nanpa_caps(caps: str) -> str:
    """Normalize the legacy NEKO-WENI-NEKO marker to the current single NEKO."""
    return re.sub(
        r"NEKO(?:WE|WA)NINEKO",
        "NEKO",
        str(caps or "").strip().upper(),
    )


def _caps_for_output_rendering(
    caps: str,
    *,
    relaxed_nanpa_linjan_rendering: bool = DEFAULT_RELAXED_NANPA_LINJAN_RENDERING,
) -> str:
    """Return canonical caps, converting strict digit pairs to relaxed output pairs when requested."""
    canonical = canonicalize_scientific_nanpa_caps(caps)
    if not relaxed_nanpa_linjan_rendering:
        return canonical
    tokens = tokenize_nanpa_caps(canonical, relaxed_nanpa_linjan_parsing=True)
    return "".join(_STRICT_TO_RELAXED_OUTPUT_TOKEN.get(token, token) for token in tokens)


def _decimal_digit_to_nanpa_token(ch: str, *, relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING) -> str:
    mapping = _RELAXED_DEC_DIGIT_TO_TOKEN if relaxed_nanpa_linjan_parsing else _STRICT_DEC_DIGIT_TO_TOKEN
    try:
        return mapping[str(ch)]
    except KeyError as exc:
        raise ValueError(f"Unsupported digit {ch!r}") from exc


def tokenize_nanpa_caps(
    caps: str,
    *,
    relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING,
) -> List[str]:
    """Tokenize canonical nanpa-caps, optionally accepting relaxed digit pairs."""
    if caps is None:
        raise ValueError("caps must be a string, not None")
    s = canonicalize_scientific_nanpa_caps(caps)
    if not s:
        raise ValueError("caps is empty")
    if not s.endswith("N"):
        raise ValueError("nanpa-caps must end with final terminator 'N'")
    if not s.startswith("NE"):
        raise ValueError("nanpa-caps must start with 'NE'")

    accepted_digits = _DIGIT_TOKENS if relaxed_nanpa_linjan_parsing else _STRICT_DIGIT_TOKENS
    tokens: List[str] = []
    i = 0
    end = len(s)
    while i < end - 1:
        matched = next((p for p in _TOKEN_PREFIXES if s.startswith(p, i)), None)
        if matched is not None:
            tokens.append(matched)
            i += len(matched)
            continue
        if i + 2 <= end - 1:
            pair = s[i:i + 2]
            if pair in accepted_digits:
                tokens.append(pair)
                i += 2
                continue
        raise ValueError(f"Invalid tokenization at position {i} in caps string {caps!r}")
    tokens.append("N")
    return tokens


def _nanpa_linjan_proper_name_to_caps(
    raw: str,
    *,
    relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING,
    nanpa_colon_parsing: bool = DEFAULT_NANPA_COLON_PARSING,
) -> Optional[str]:
    """Convert a nanpa-linja-n proper name to canonical caps.

    A contiguous initial ``Nene`` is the explicit-positive proper-name marker.
    Internally it is kept distinct from the existing ``NE`` + ``NE`` no-value
    spacer so rendering can preserve the positive sign through abbreviation.
    """
    source = str(raw or "").strip()
    if nanpa_colon_parsing:
        match = re.fullmatch(r"Nanpa(?:([a-z]+))?((?:[ \t]+[A-Z][a-z]*)+)?", source)
        if match:
            tail = (match.group(1) or "") + "".join((match.group(2) or "").split())
            if tail and tail.lower().endswith("n"):
                core = tail[:-1]
                has_percent = core.lower().endswith("noke")
                if has_percent: core = core[:-4]
                if len(core) >= 2 and len(core) % 2 == 0:
                    body = core.upper()
                    if body.startswith("NE"): body = "NS" + body[2:]
                    caps = "NE" + body + ("OKN" if has_percent else "N")
                    try:
                        tokens = tokenize_nanpa_caps(caps, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing)
                        if any(token in _DIGIT_TOKENS for token in tokens): return caps
                    except ValueError:
                        pass
    if not source or not re.fullmatch(r"[A-Za-z]+(?:\s+[A-Za-z]+)*", source):
        return None

    compact = "".join(source.split())
    if not compact or not compact.lower().endswith("n"):
        return None

    core = compact[:-1]
    if len(core) < 2 or len(core) % 2 != 0:
        return None

    has_percent = False
    if core.lower().endswith("noke"):
        has_percent = True
        core = core[:-4]
        if len(core) < 2 or len(core) % 2 != 0:
            return None

    core_caps = core.upper()
    if not core_caps.startswith("NE"):
        return None

    if re.match(r"^nene", source, flags=re.IGNORECASE) and core_caps.startswith("NENE"):
        core_caps = "NENS" + core_caps[4:]

    caps = core_caps + ("OKN" if has_percent else "N")
    try:
        tokenize_nanpa_caps(caps, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing)
    except ValueError:
        return None
    return canonicalize_scientific_nanpa_caps(caps)


def _is_valid_nanpa_linjan_proper_name(
    raw: str,
    *,
    relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING,
    nanpa_colon_parsing: bool = DEFAULT_NANPA_COLON_PARSING,
) -> bool:
    return _nanpa_linjan_proper_name_to_caps(
        raw,
        relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
        nanpa_colon_parsing=nanpa_colon_parsing,
    ) is not None


def _proper_name_to_caps(raw: str, *, relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING, nanpa_colon_parsing: bool = DEFAULT_NANPA_COLON_PARSING) -> str:
    caps = _nanpa_linjan_proper_name_to_caps(
        raw,
        relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
        nanpa_colon_parsing=nanpa_colon_parsing,
    )
    if caps is None:
        raise ValueError(f"Not a valid nanpa-linja-n proper name: {raw!r}")
    return caps


def parse_hash_tilde_payload(token: str) -> str:
    """Validate a complete #~ code and return its compact uppercase body."""
    if token is None:
        raise ValueError("token must be a string, not None")
    compact = re.sub(r"\s+", "", str(token).strip())
    if not compact.upper().startswith("#~"):
        raise ValueError(f"Not a #~ token: {token!r}")
    body = compact[2:]
    if not body:
        raise ValueError("Number code '#~' must have content after it.")
    if not re.fullmatch(r"\+?[A-Za-z]+", body):
        raise ValueError("Number code may contain only one optional leading '+' followed by letters A-Z.")
    body = ("+" if body.startswith("+") else "") + body.lstrip("+").upper()
    # Semantic validation is delegated to the parser so positive, E/EE/EKO and
    # arbitrary K runs receive the same treatment as the JavaScript implementation.
    hash_tilde_payload_to_nanpa_caps(body)
    return body


def hash_tilde_payload_to_nanpa_caps(payload: str) -> str:
    """Convert a #~ body (or complete #~ token) to canonical nanpa-caps."""
    if payload is None:
        raise ValueError("payload must be a string, not None")
    compact = re.sub(r"\s+", "", str(payload).strip())
    raw_body = compact[2:] if compact.upper().startswith("#~") else compact
    if not raw_body:
        raise ValueError("Empty #~ payload")

    has_leading_plus = False
    if raw_body.startswith("+"):
        has_leading_plus = True
        raw_body = raw_body[1:]
        if not raw_body:
            raise ValueError("Leading plus in number code must be followed immediately by a digit code.")

    body = raw_body.upper()
    if not re.fullmatch(r"[A-Z]+", body):
        raise ValueError("Number code may contain only one optional leading '+' followed by letters A-Z.")

    leading_e_match = re.match(r"^E+", body)
    leading_e_count = len(leading_e_match.group(0)) if leading_e_match else 0
    if has_leading_plus:
        if not body or body[0] not in _NUMBER_CODE_LETTER_TO_PAIR:
            raise ValueError("Leading plus in number code must be followed immediately by a digit code.")
    elif leading_e_count == 1:
        if len(body) < 2 or body[1] not in _NUMBER_CODE_LETTER_TO_PAIR:
            raise ValueError("A single leading 'e' positive marker must be followed immediately by a digit code.")
        has_leading_plus = True
        body = body[1:]
    elif leading_e_count > 1 and leading_e_count % 2 == 1:
        raise ValueError("At the start of a number code, 'e' must be either one positive marker before a digit or an even no-value-spacer run.")

    has_percent = False
    if body.endswith("OK"):
        has_percent = True
        body = body[:-2]
        if not body:
            raise ValueError("Number code '#~' cannot be only 'OK' (no numeric content).")

    tokens: List[str] = ["NE"]
    if has_leading_plus:
        tokens.append("NS")
    i = 0
    legacy_index = body.find("KOWIKO")
    has_legacy_marker = (
        legacy_index > 0
        and body[legacy_index - 1] != "O"
        and legacy_index + len("KOWIKO") < len(body)
    )

    def ensure_ne() -> None:
        if tokens[-1] != "NE":
            tokens.append("NE")

    while i < len(body):
        ch = body[i]
        if body.startswith("OKO", i):
            tokens.append("NOKO")
            i += 3
            continue

        if ch == "E":
            j = i
            while j < len(body) and body[j] == "E":
                j += 1
            count = j - i
            for _ in range(count // 2):
                tokens.extend(("NE", "NE"))
            if count % 2:
                marker_index = j - 1
                has_following_ko = body.startswith("KO", j)
                has_before = marker_index > 0
                has_after = (j + 2) < len(body)
                if not (has_following_ko and has_before and has_after):
                    raise ValueError("An odd run of 'E' in number code must end with a valid EKO scientific marker.")
                tokens.extend(("NE", "KO"))
                i = j + 2
            else:
                i = j
            continue

        if (
            has_legacy_marker
            and body.startswith("KO", i)
            and i in (legacy_index, legacy_index + 4)
        ):
            ensure_ne()
            tokens.append("KO")
            i += 2
            continue

        if ch == "O":
            j = i
            while j < len(body) and body[j] == "O":
                j += 1
            count = j - i
            if count < 1 or count > 3:
                raise ValueError("Invalid run of 'O' in number code (max 3).")
            if count == 1:
                if i == 0 or tokens[-1] == "KO":
                    tokens.append("NO")
                else:
                    tokens.extend(("NO", "NE"))
            else:
                tokens.append("NO" * count)
            i = j
            continue

        if ch == "K":
            j = i
            while j < len(body) and body[j] == "K":
                j += 1
            count = j - i
            ensure_ne()
            tokens.append("KE" * count)
            i = j
            continue

        pair = _NUMBER_CODE_LETTER_TO_PAIR.get(ch)
        if pair is None:
            raise ValueError(f"Invalid letter {ch!r} in number code.")
        tokens.append(pair)
        i += 1

    if has_percent:
        tokens.append("OK")
    tokens.append("N")
    caps = canonicalize_scientific_nanpa_caps("".join(tokens))
    tokenize_nanpa_caps(caps)
    return caps


def _normalize_loose_separators(raw: str) -> str:
    s = str(raw or "").replace("−", "-").replace("‒", "-").replace("–", "-").replace("—", "-")
    negative = s.startswith("-")
    rest = s[1:] if negative else s
    rest = re.sub(r"\s+", " ", rest)
    rest = re.sub(r"-+", "-", rest)
    return (("-" if negative else "") + rest).strip()


def _normalize_vulgar_fraction_input(raw: str) -> str:
    s = str(raw or "").strip().replace("⁄", "/")
    if not s:
        return s
    fractions = {
        "¼": (1, 4), "½": (1, 2), "¾": (3, 4), "⅐": (1, 7),
        "⅑": (1, 9), "⅒": (1, 10), "⅓": (1, 3), "⅔": (2, 3),
        "⅕": (1, 5), "⅖": (2, 5), "⅗": (3, 5), "⅘": (4, 5),
        "⅙": (1, 6), "⅚": (5, 6), "⅛": (1, 8), "⅜": (3, 8),
        "⅝": (5, 8), "⅞": (7, 8), "↉": (0, 3),
    }
    found = next((ch for ch in s if ch in fractions), None)
    if found is None:
        return s
    if s[-1] not in fractions:
        raise ValueError("Vulgar fraction characters must appear at the end (e.g. 9¾ or ¾).")
    if "-" in s[1:]:
        raise ValueError("Only one negative sign is allowed, and it must be at the start.")
    num, den = fractions[s[-1]]
    prefix_raw = s[:-1].strip()
    if not prefix_raw:
        return f"{num}/{den}"
    negative = prefix_raw.startswith("-")
    prefix = prefix_raw[1:].strip() if negative else prefix_raw
    if not prefix:
        return f"-{num}/{den}"
    return f"-{prefix}+{num}/{den}" if negative else f"{prefix}+{num}/{den}"


def _group_fraction_digits_only_js(s: str, decimal_char: str = ".", group_size: int = 3, sep_char: str = "_") -> str:
    text = str(s)
    idx = text.find(decimal_char)
    if idx < 0:
        return text
    left, right = text[:idx], text[idx + 1:]
    i = 0
    while i < len(right) and right[i].isdigit():
        i += 1
    frac_digits, suffix = right[:i], right[i:]
    if len(frac_digits) <= group_size or (sep_char and sep_char in frac_digits):
        return text
    groups = [frac_digits[j:j + group_size] for j in range(0, len(frac_digits), group_size)]
    return f"{left}{decimal_char}{sep_char.join(groups)}{suffix}"


def number_str_to_nanpa_caps(
    s: str,
    *,
    thousands_char: str = ",",
    group_fraction_triplets: bool = True,
    fraction_group_size: int = 3,
    mixed_style: str = DEFAULT_MIXED_STYLE,
    relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING,
) -> str:
    """Encode decimal/fraction/mixed input with current JavaScript parity."""
    if s is None:
        raise ValueError("s must be a string, not None")
    source = str(s).strip()
    if not source:
        raise ValueError("Empty value cannot be encoded")
    if re.search(r"\s", source):
        raise ValueError("Whitespace terminates a digit-based numeric token")
    raw = _normalize_loose_separators(source)
    if group_fraction_triplets:
        raw = _group_fraction_digits_only_js(raw, ".", fraction_group_size, "_")

    has_leading_plus = False
    if raw.startswith("+"):
        has_leading_plus = True
        raw = raw[1:].strip()
        if not raw:
            raise ValueError("Missing numeric part after leading '+' sign")

    def strip_final(caps: str) -> str:
        if not caps.endswith("N"):
            raise ValueError(f"Segment caps did not end with 'N': {caps!r}")
        return caps[:-1]

    def encode_segment(segment: str, include_initial_ne: bool, include_leading_plus: bool = False) -> str:
        seg = str(segment).strip()
        if not seg:
            raise ValueError(f"Empty numeric segment in {s!r}")
        if seg[:1].upper() == "N":
            seg = seg[1:].strip()
            if not seg:
                raise ValueError(f"Missing numeric part after leading 'N' prefix in {s!r}")

        out: List[str] = ["NE"] if include_initial_ne else []
        if include_initial_ne and include_leading_plus:
            out.append("NS")

        def push_nene() -> None:
            if len(out) >= 2 and out[-2:] == ["NE", "NE"]:
                return
            out.extend(("NE", "NE"))

        if seg.startswith("-"):
            if seg.startswith("-."):
                seg = "-0." + seg[2:]
            out.append("NO")
            seg = seg[1:].strip()

        suffix_count = 0
        if seg:
            last = seg[-1].upper()
            if last in {"K", "T", "M", "B"}:
                suffix_count = {"K": 1, "M": 2, "B": 3, "T": 4}[last]
                seg = seg[:-1].strip()
                if not seg:
                    raise ValueError(f"Missing numeric part before magnitude suffix {last!r} in {s!r}")

        if seg.count(".") > 1:
            raise ValueError(f"Invalid numeric segment with multiple decimals: {segment!r}")
        if "." in seg:
            int_part, frac_part = seg.split(".", 1)
            has_decimal = True
        else:
            int_part, frac_part, has_decimal = seg, "", False

        ip = str(int_part or "").strip() or "0"
        has_loose_sep = bool(re.search(r"-", ip))
        if has_loose_sep:
            ip2 = re.sub(r"-+", "-", ip).strip()
            ip2 = re.sub(r"^-+|-+$", "", ip2) or "0"
            for ch in ip2:
                if ch.isdigit():
                    out.append(_decimal_digit_to_nanpa_token(ch, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing))
                elif ch == "-":
                    push_nene()
                elif thousands_char and ch == thousands_char:
                    out.extend(("NE", "KE"))
                else:
                    raise ValueError(f"Unsupported character {ch!r} in integer part of {s!r}")
        else:
            groups = ip.split(thousands_char) if thousands_char else [ip]
            if any((not g or not g.isdigit()) for g in groups):
                bad = next(g for g in groups if not g or not g.isdigit())
                raise ValueError(f"Invalid integer group {bad!r} in {s!r}")
            trailing_zero_groups = 0
            for g in reversed(groups[1:]):
                if len(g) == 3 and g == "000":
                    trailing_zero_groups += 1
                else:
                    break
            for digit in groups[0]:
                out.append(_decimal_digit_to_nanpa_token(digit, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing))
            last_non_trailing = len(groups) - trailing_zero_groups
            for idx in range(1, last_non_trailing):
                out.extend(("NE", "KE"))
                for digit in groups[idx]:
                    out.append(_decimal_digit_to_nanpa_token(digit, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing))
            if trailing_zero_groups:
                out.append("NE")
                out.append("KE" * trailing_zero_groups)

        if has_decimal:
            out.extend(("NO", "NE"))
            if not frac_part:
                raise ValueError(f"Missing fraction digits after '.' in {s!r}")
            for ch in frac_part:
                if ch.isdigit():
                    out.append(_decimal_digit_to_nanpa_token(ch, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing))
                elif ch in {"_", ",", "-"}:
                    push_nene()
                else:
                    raise ValueError(f"Unsupported character {ch!r} in fraction part of {s!r}")

        if suffix_count:
            out.append("NE")
            out.append("KE" * suffix_count)
        out.append("N")
        return "".join(out)

    if "+" in raw:
        left, right = raw.split("+", 1)
        if "/" not in right:
            raise ValueError(f"Mixed number must contain '/' after '+': {s!r}")
        num, den = right.split("/", 1)
        left_caps = strip_final(encode_segment(left, True, has_leading_plus))
        num_caps = strip_final(encode_segment(num, False))
        den_caps = encode_segment(den, False)
        separator = "NOKO" if mixed_style != "long" else "NONONO"
        return left_caps + separator + num_caps + "NONO" + den_caps
    if "/" in raw:
        num, den = raw.split("/", 1)
        return strip_final(encode_segment(num, True, has_leading_plus)) + "NONO" + encode_segment(den, False)
    return encode_segment(raw, True, has_leading_plus)


def _try_parse_scientific_decimal_to_caps(
    raw_value: str,
    opts: Optional[Dict[str, object]] = None,
) -> Optional[str]:
    raw = str(raw_value or "").strip()
    if not raw:
        return None
    raw = raw.replace("−", "-").replace("‒", "-").replace("–", "-").replace("—", "-")
    mantissa = r"([+-]?(?:(?:\d[\d,_-]*)(?:\.\d[\d,_-]*)?|(?:\.\d[\d,_-]*)))"
    patterns = (
        re.compile(rf"^{mantissa}[eE]([+-]?\d+)$"),
        re.compile(rf"^{mantissa}\*10\^([+-]?\d+)$"),
        re.compile(rf"^{mantissa}\*10([+-]\d+)$"),
    )
    match = next((m for p in patterns if (m := p.match(raw))), None)
    if match is None:
        return None
    mantissa_text = str(match.group(1) or "").strip()
    exponent_text = str(match.group(2) or "").strip()
    # A plus on the mantissa is the number's explicit leading sign and is
    # preserved. A plus on the exponent is intentionally ignored.
    if exponent_text.startswith("+"):
        exponent_text = exponent_text[1:].strip()
    if not mantissa_text or not re.fullmatch(r"-?\d+", exponent_text):
        return None
    kwargs = dict(opts or {})
    mantissa_caps = number_str_to_nanpa_caps(mantissa_text, **kwargs)
    exponent_kwargs = {**kwargs, "group_fraction_triplets": False}
    exponent_caps = number_str_to_nanpa_caps(exponent_text, **exponent_kwargs)
    mantissa_core = mantissa_caps[:-1]
    exponent_core = exponent_caps[2:-1]
    if not mantissa_core or not exponent_core:
        return None
    caps = mantissa_core + "NEKO" + exponent_core + "N"
    tokenize_nanpa_caps(
        caps,
        relaxed_nanpa_linjan_parsing=bool(kwargs.get("relaxed_nanpa_linjan_parsing", False)),
    )
    return caps


def decimal_string_to_nanpa_caps(
    raw_decimal: str,
    *,
    thousands_char: str = ",",
    group_fraction_triplets: bool = True,
    fraction_group_size: int = 3,
    mixed_style: str = DEFAULT_MIXED_STYLE,
    relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING,
) -> str:
    raw = str(raw_decimal or "").strip()
    if re.search(r"\s", raw):
        raise ValueError("Whitespace terminates a digit-based numeric token")
    percent = bool(re.search(r"%$", raw))
    if percent:
        raw = raw[:-1]
    normalized = _normalize_vulgar_fraction_input(raw)
    opts = {
        "thousands_char": thousands_char,
        "group_fraction_triplets": group_fraction_triplets,
        "fraction_group_size": fraction_group_size,
        "mixed_style": mixed_style,
        "relaxed_nanpa_linjan_parsing": relaxed_nanpa_linjan_parsing,
    }
    scientific = _try_parse_scientific_decimal_to_caps(normalized, opts)
    if scientific is not None:
        caps = scientific
    elif _looks_like_nanpa_caps(normalized):
        caps = canonicalize_scientific_nanpa_caps(normalized)
    else:
        caps = number_str_to_nanpa_caps(normalized, **opts)
    if percent:
        caps = caps[:-1] + "OKN"
    tokenize_nanpa_caps(caps, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing)
    return caps


def _normalize_datetime_input(raw: str) -> str:
    s = str(raw or "").strip()
    s = re.sub(r"[‐‑‒–—−﹣－]", "-", s)
    s = re.sub(r"[⁄∕／]", "/", s)
    return s.replace("：", ":")


def _parse_time_parts(raw: str) -> Optional[Dict[str, object]]:
    source = str(raw or "").strip()
    if not source or re.search(r"\s", source):
        return None
    fields = source.split(":")
    if len(fields) < 2 or len(fields) > 4:
        return None
    first = re.fullmatch(r"([+-]?)([0-9]+)", fields[0])
    if first is None:
        return None
    sign, first_digits = first.groups()

    def clock_pair(value: str) -> bool:
        return re.fullmatch(r"[0-5][0-9]", value or "") is not None

    def seconds(value: str) -> Optional[Tuple[str, Optional[str]]]:
        match = re.fullmatch(r"([0-5][0-9])(?:\.([0-9]{1,3}))?", value or "")
        return None if match is None else (match.group(1), match.group(2))

    if len(fields) == 2:
        if sign or re.fullmatch(r"[0-9]{1,2}", first_digits) is None or not clock_pair(fields[1]):
            return None
        if not 0 <= int(first_digits) <= 59:
            return None
        return {"has_days": False, "negative": False, "day": None,
                "hour": first_digits, "minute": fields[1], "second": None, "fraction": None}

    if len(fields) == 3:
        final_seconds = seconds(fields[2])
        if final_seconds is not None and final_seconds[1] is not None:
            if sign or re.fullmatch(r"[0-9]{1,2}", first_digits) is None or not clock_pair(fields[1]):
                return None
            if not 0 <= int(first_digits) <= 59:
                return None
            return {"has_days": False, "negative": False, "day": None,
                    "hour": first_digits, "minute": fields[1],
                    "second": final_seconds[0], "fraction": final_seconds[1]}
        if not clock_pair(fields[1]) or not clock_pair(fields[2]):
            return None
        negative = sign == "-" and re.search(r"[1-9]", first_digits + fields[1] + fields[2]) is not None
        return {"has_days": True, "negative": negative, "day": first_digits,
                "hour": fields[1], "minute": fields[2], "second": None, "fraction": None}

    final_seconds = seconds(fields[3])
    if not clock_pair(fields[1]) or not clock_pair(fields[2]) or final_seconds is None:
        return None
    all_digits = first_digits + fields[1] + fields[2] + final_seconds[0] + (final_seconds[1] or "")
    negative = sign == "-" and re.search(r"[1-9]", all_digits) is not None
    return {"has_days": True, "negative": negative, "day": first_digits,
            "hour": fields[1], "minute": fields[2],
            "second": final_seconds[0], "fraction": final_seconds[1]}


def time_str_to_nanpa_caps(raw: str, *, relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING) -> Optional[str]:
    parts = _parse_time_parts(raw)
    if parts is None:
        return None
    encode = lambda digits: "".join(
        _decimal_digit_to_nanpa_token(d, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing)
        for d in digits
    )
    caps = "NE" + ("NO" if parts["negative"] else "")
    if parts["has_days"]:
        caps += encode(str(parts["day"])) + "NEKE"
    caps += encode(str(parts["hour"])) + "NEKE" + encode(str(parts["minute"]))
    if parts["second"] is not None:
        caps += "NEKE" + encode(str(parts["second"]))
        if parts["fraction"] is not None:
            caps += "NONE" + encode(str(parts["fraction"]))
    caps += "N"
    tokenize_nanpa_caps(caps, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing)
    return caps


def date_str_to_nanpa_caps(raw: str, *, relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING) -> Optional[str]:
    normalized = _normalize_datetime_input(raw)
    match = re.fullmatch(r"([0-9]{4})([/-])([0-9]{2})\2([0-9]{2})", normalized)
    if match is None:
        return None
    year, _sep, month, day = match.groups()
    if not 1 <= int(month) <= 12 or not 1 <= int(day) <= 31:
        return None
    encode = lambda digits: "".join(
        _decimal_digit_to_nanpa_token(d, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing)
        for d in digits
    )
    caps = "NE" + encode(year) + "NEKE" + encode(month) + "NEKE" + encode(day) + "N"
    tokenize_nanpa_caps(caps, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing)
    return caps


def _decode_time_caps(caps: str, *, relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING) -> Optional[Dict[str, object]]:
    try:
        tokens = tokenize_nanpa_caps(caps, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing)
    except ValueError:
        return None
    if not tokens or tokens[0] != "NE" or tokens[-1] != "N":
        return None
    final = len(tokens) - 1
    i = 1
    negative_input = i < final and tokens[i] == "NO"
    if negative_input:
        i += 1
    segments: List[Tuple[str, Optional[str]]] = []
    while i < final:
        integer = ""
        while i < final and tokens[i] in _DIGIT_TOKENS:
            integer += _TOKEN_TO_DIGIT_CHAR[tokens[i]]
            i += 1
        if not integer:
            return None
        fraction = None
        if tokens[i:i + 2] == ["NO", "NE"]:
            i += 2
            fraction = ""
            while i < final and tokens[i] in _DIGIT_TOKENS:
                fraction += _TOKEN_TO_DIGIT_CHAR[tokens[i]]
                i += 1
            if not 1 <= len(fraction) <= 3:
                return None
        segments.append((integer, fraction))
        if i == final:
            break
        if tokens[i:i + 2] != ["NE", "KE"]:
            return None
        i += 2
    if i != final or not 2 <= len(segments) <= 4 or any(fraction is not None for _, fraction in segments[:-1]):
        return None

    def pair(segment) -> bool:
        return segment[1] is None and re.fullmatch(r"[0-5][0-9]", segment[0]) is not None

    def seconds_pair(segment) -> bool:
        return re.fullmatch(r"[0-5][0-9]", segment[0]) is not None and (
            segment[1] is None or re.fullmatch(r"[0-9]{1,3}", segment[1]) is not None)

    if len(segments) == 2:
        hour, minute = segments
        if negative_input or hour[1] is not None or re.fullmatch(r"[0-9]{1,2}", hour[0]) is None:
            return None
        if not 0 <= int(hour[0]) <= 59 or not pair(minute):
            return None
        is_zero = int(hour[0]) == 0 and minute[0] == "00"
    elif len(segments) == 3 and segments[2][1] is not None:
        hour, minute, second = segments
        if negative_input or hour[1] is not None or re.fullmatch(r"[0-9]{1,2}", hour[0]) is None:
            return None
        if not 0 <= int(hour[0]) <= 59 or not pair(minute) or not seconds_pair(second):
            return None
        is_zero = re.search(r"[1-9]", "".join(v or "" for segment in segments for v in segment)) is None
    elif len(segments) == 3:
        day, hour, minute = segments
        if day[1] is not None or not pair(hour) or not pair(minute):
            return None
        is_zero = re.search(r"[1-9]", day[0] + hour[0] + minute[0]) is None
    else:
        day, hour, minute, second = segments
        if day[1] is not None or not pair(hour) or not pair(minute) or not seconds_pair(second):
            return None
        is_zero = re.search(r"[1-9]", "".join(v or "" for segment in segments for v in segment)) is None
    return {"negative_input": negative_input, "negative": negative_input and not is_zero,
            "is_zero": is_zero, "segments": segments}


def _caps_is_time(caps: str, *, relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING) -> bool:
    return _decode_time_caps(caps, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing) is not None

def _caps_is_date(caps: str, *, relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING) -> bool:
    try:
        tokens = tokenize_nanpa_caps(caps, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing)
    except ValueError:
        return False
    digits = _DIGIT_TOKENS
    pattern_ok = (
        len(tokens) == 13
        and tokens[0] == "NE" and tokens[-1] == "N"
        and all(tokens[i] in digits for i in (1, 2, 3, 4, 7, 8, 11, 12) if i < len(tokens) - 1)
    )
    # Explicit parser below is clearer than relying on the compact length test.
    i = 1
    if len(tokens) < 13:
        return False
    for _ in range(4):
        if i >= len(tokens) or tokens[i] not in digits: return False
        i += 1
    if tokens[i:i + 2] != ["NE", "KE"]: return False
    i += 2
    mdigits = []
    for _ in range(2):
        if i >= len(tokens) or tokens[i] not in digits: return False
        mdigits.append(_TOKEN_TO_DIGIT_CHAR[tokens[i]]); i += 1
    if tokens[i:i + 2] != ["NE", "KE"]: return False
    i += 2
    ddigits = []
    for _ in range(2):
        if i >= len(tokens) or tokens[i] not in digits: return False
        ddigits.append(_TOKEN_TO_DIGIT_CHAR[tokens[i]]); i += 1
    return i == len(tokens) - 1 and 1 <= int("".join(mdigits)) <= 12 and 1 <= int("".join(ddigits)) <= 31


# Optional hexadecimal namespace.  It deliberately does not share decimal
# nanpa-caps, matching the JavaScript parser/renderer.
_HEX_STRICT_SYLLABLE = {
    "0":"NI", "1":"WE", "2":"TE", "3":"SE", "4":"NA", "5":"LE", "6":"NU", "7":"ME",
    "8":"PE", "9":"JE", "A":"JA", "B":"LA", "C":"MA", "D":"PA", "E":"SI", "F":"TA",
}
_HEX_RELAXED_SYLLABLE = {**_HEX_STRICT_SYLLABLE, "1":"WA", "2":"TU", "5":"LU", "7":"MU", "8":"PI", "9":"JO"}
_HEX_ABBREVIATED_WORD = {
    "0":"ijo", "1":"wan", "2":"tu", "3":"seli", "4":"awen", "5":"luka", "6":"utala",
    "7":"mun", "8":"pipi", "9":"jo", "A":"jan", "B":"lawa", "C":"ma", "D":"pakala",
    "E":"sike", "F":"tan",
}


@dataclass(frozen=True)
class HexSemantic:
    parts: Tuple[Tuple[str, Optional[str]], ...]
    digits: str
    source_type: str = "hash"
    source_text: str = ""


def _hex_group_sizes(length: int) -> List[int]:
    if length <= 0: return []
    if length <= 3: return [length]
    out = []
    while length > 3:
        out.append(2); length -= 2
    out.append(length)
    return out


def _hex_groups(digits: str) -> List[str]:
    sizes = _hex_group_sizes(len(digits)); out = []; pos = 0
    for size in sizes:
        out.append(digits[pos:pos + size]); pos += size
    return out


def _make_hex_semantic(parts, source_type: str, source_text: str) -> Optional[HexSemantic]:
    normalized = []; all_digits = ""
    for kind, value in parts:
        if kind == "digits":
            value = value.upper()
            if not re.fullmatch(r"[0-9A-F]+", value): return None
            all_digits += value
        elif kind != "delimiter": return None
        normalized.append((kind, value))
    if not normalized or normalized[0][0] != "digits" or not all_digits: return None
    return HexSemantic(tuple(normalized), all_digits, source_type, source_text)


def _parse_hex_hash(source: str) -> Optional[HexSemantic]:
    if not re.match(r"^#[0-9A-Fa-f]", source): return None
    parts = []; run = ""
    for ch in source[1:]:
        if ch.isspace() or (ch.isascii() and ch.isalpha() and ch.upper() not in "ABCDEF"): return None
        if ch.upper() in "0123456789ABCDEF": run += ch.upper()
        else:
            if run: parts.append(("digits", run)); run = ""
            parts.append(("delimiter", ch))
    if run: parts.append(("digits", run))
    return _make_hex_semantic(parts, "hash", source)


def _validate_hex_tokens(tokens, source_type: str, source_text: str) -> Optional[HexSemantic]:
    parts = []; run = []; groups = []
    def flush():
        nonlocal run, groups
        if not run: return True
        if not groups: groups = [""]
        for kind, value in run:
            if kind == "digit": groups[-1] += value
            elif kind == "generated" and groups[-1]: groups.append("")
            else: return False
        if not groups[-1]: return False
        digits = "".join(groups)
        if groups != _hex_groups(digits): return False
        parts.append(("digits", digits)); run = []; groups = []
        return True
    for token in tokens:
        if token[0] == "delimiter":
            if not flush() or not parts: return None
            parts.append(token)
        else: run.append(token)
    if not flush(): return None
    return _make_hex_semantic(parts, source_type, source_text)


def _parse_hex_proper_name(source: str, relaxed: bool) -> Optional[HexSemantic]:
    if not re.fullmatch(r"[A-Za-z]+(?:[ \t]+[A-Za-z]+)*", source) or not source.lower().startswith("nasa"): return None
    body = re.sub(r"[ \t]+", "", source)[4:]
    if not body.lower().endswith("n"): return None
    body = body[:-1].upper()
    reverse = {syllable: digit for digit, syllable in _HEX_STRICT_SYLLABLE.items()}
    if relaxed:
        reverse.update({syllable: digit for digit, syllable in _HEX_RELAXED_SYLLABLE.items()})
    tokens = []; i = 0
    while i < len(body):
        if body.startswith("NENE", i): tokens.append(("delimiter", None)); i += 4
        elif body.startswith("NEKE", i): tokens.append(("generated", "")); i += 4
        elif body[i:i+2] in reverse: tokens.append(("digit", reverse[body[i:i+2]])); i += 2
        else: return None
    return _validate_hex_tokens(tokens, "properName", source)


def _tokenize_hex_cartouche_source(source: str) -> Optional[List[str]]:
    value = str(source or "").strip()
    if not value:
        return None
    tokens: List[str] = []
    i = 0
    while i < len(value):
        if value[i].isspace():
            i += 1
            continue
        if value[i] == ":":
            tokens.append(":")
            i += 1
            continue
        if value[i].isascii() and value[i].isalpha():
            start = i
            while i < len(value) and value[i].isascii() and value[i].isalpha():
                i += 1
            tokens.append(value[start:i].lower())
            continue
        return None
    return tokens


def _hex_full_digit_patterns(relaxed: bool) -> List[Tuple[str, Tuple[str, str]]]:
    patterns: List[Tuple[str, Tuple[str, str]]] = []
    join_words = ("e", "en", "esun")
    n_words = ("nena", "nasa")

    def add(digit: str, first: str, seconds) -> None:
        for second in seconds if isinstance(seconds, tuple) else (seconds,):
            patterns.append((digit, (first, second)))

    for n_word in n_words: add("0", n_word, "ijo")
    add("1", "wan", join_words)
    add("2", "tu", join_words)
    add("3", "seli", join_words)
    for n_word in n_words: add("4", n_word, "awen")
    add("5", "luka", join_words)
    for n_word in n_words: add("6", n_word, "utala")
    add("7", "mun", join_words)
    add("8", "pipi", join_words)
    add("9", "jo", join_words)
    if relaxed:
        add("1", "wan", "ala")
        add("2", "tu", "uta")
        add("5", "luka", "uta")
        add("7", "mun", "uta")
        add("8", "pipi", "ike")
        add("9", "jo", "open")
    add("A", "jan", "ala")
    add("B", "lawa", "ala")
    add("C", "ma", "ala")
    add("D", "pakala", "ala")
    add("E", "sike", "ike")
    add("F", "tan", "ala")
    return patterns


def _parse_hex_cartouche(
    source: str,
    *,
    relaxed: bool,
    prefer_abbreviated: bool,
) -> Optional[HexSemantic]:
    tokens = _tokenize_hex_cartouche_source(source)
    if not tokens or len(tokens) < 3 or tokens[0] != "nasa" or tokens[-1] != "nasa":
        return None
    start = 2 if len(tokens) > 1 and tokens[1] == ":" else 1
    body = tokens[start:-1]
    if not body:
        return None

    abbreviated_to_digit = {word: digit for digit, word in _HEX_ABBREVIATED_WORD.items()}

    def try_abbreviated() -> Optional[HexSemantic]:
        structured = []
        for word in body:
            if word == "kule":
                structured.append(("generated", ""))
            elif word == "e":
                structured.append(("delimiter", None))
            elif word in abbreviated_to_digit:
                structured.append(("digit", abbreviated_to_digit[word]))
            else:
                return None
        return _validate_hex_tokens(structured, "cartouche", source)

    if prefer_abbreviated:
        semantic = try_abbreviated()
        if semantic is not None:
            return semantic

    structured = []
    patterns = _hex_full_digit_patterns(relaxed)
    n_words = {"nena", "nasa"}
    join_words = {"e", "en", "esun"}
    i = 0
    while i < len(body):
        if (i + 3 < len(body) and body[i] in n_words and body[i + 1] in join_words
                and body[i + 2] == "kule" and body[i + 3] in join_words):
            structured.append(("generated", ""))
            i += 4
            continue
        if (i + 3 < len(body) and body[i] in n_words and body[i + 1] in join_words
                and body[i + 2] in n_words and body[i + 3] in join_words):
            structured.append(("delimiter", None))
            i += 4
            continue
        match = next((item for item in patterns if tuple(body[i:i + 2]) == item[1]), None)
        if match is None:
            structured = []
            break
        structured.append(("digit", match[0]))
        i += 2
    if structured:
        semantic = _validate_hex_tokens(structured, "cartouche", source)
        if semantic is not None:
            return semantic
    return None if prefer_abbreviated else try_abbreviated()


def parse_hex_input(
    value: str,
    *,
    relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING,
    abbreviate_numeric_cartouches: bool = DEFAULT_ABBREVIATE_NUMERIC_CARTOUCHES,
) -> Optional[HexSemantic]:
    source = str(value or "").strip()
    if source.startswith("#"): return _parse_hex_hash(source)
    if source.startswith("[") and source.endswith("]"):
        return _parse_hex_cartouche(
            source[1:-1],
            relaxed=relaxed_nanpa_linjan_parsing,
            prefer_abbreviated=abbreviate_numeric_cartouches,
        )
    return _parse_hex_proper_name(source, relaxed_nanpa_linjan_parsing)


def hex_semantic_to_words(
    semantic: HexSemantic,
    *,
    abbreviated: bool = False,
    relaxed_rendering: bool = False,
    number_word_style: str = DEFAULT_NUMBER_WORD_STYLE,
) -> List[str]:
    traditional = str(number_word_style or "").lower() == "traditional"
    words = ["nasa", ":"]
    for kind, value in semantic.parts:
        if kind == "delimiter": words.extend(["e"] if abbreviated else ["nena", "e", "nena", "e"]); continue
        groups = _hex_groups(value)
        for gi, group in enumerate(groups):
            for digit in group:
                if abbreviated: words.append(_HEX_ABBREVIATED_WORD[digit]); continue
                if digit in "ABCDEF":
                    words.extend({"A":["jan","ala"],"B":["lawa","ala"],"C":["ma","ala"],"D":["pakala","ala"],"E":["sike","ike"],"F":["tan","ala"]}[digit])
                elif relaxed_rendering and digit in "125789":
                    words.extend({"1":["wan","ala"],"2":["tu","uta"],"5":["luka","uta"],"7":["mun","uta"],"8":["pipi","ike"],"9":["jo","open"]}[digit])
                else:
                    n_word = "nasa" if traditional else "nena"
                    e_word = "esun" if traditional else "e"
                    words.extend({"0":[n_word,"ijo"],"1":["wan",e_word],"2":["tu",e_word],"3":["seli",e_word],"4":[n_word,"awen"],"5":["luka",e_word],"6":[n_word,"utala"],"7":["mun",e_word],"8":["pipi",e_word],"9":["jo",e_word]}[digit])
            if gi < len(groups)-1: words.extend(["kule"] if abbreviated else ["nena","e","kule","e"])
    return words + ["nasa"]


def hex_semantic_to_proper_name(semantic: HexSemantic, *, relaxed_rendering: bool = False) -> str:
    words = ["Nasa"]; syllables = _HEX_RELAXED_SYLLABLE if relaxed_rendering else _HEX_STRICT_SYLLABLE
    for kind, value in semantic.parts:
        if kind == "delimiter": words[-1] += "n"; words.append("Ene"); continue
        for gi, group in enumerate(_hex_groups(value)):
            word = "".join(syllables[d].lower() for d in group); words.append(word.title())
            if gi < len(_hex_groups(value))-1: words[-1] += "n"; words.append("Eke")
    words[-1] += "n"
    return " ".join(words)



# Optional binary namespace. It is parallel to hexadecimal but intentionally
# accepts only the lowercase ``0b`` source prefix, matching the JavaScript renderer.
@dataclass(frozen=True)
class BinarySemantic:
    parts: Tuple[Tuple[str, Optional[str]], ...]
    digits: str
    source_type: str = "prefix"
    source_text: str = ""


def _make_binary_semantic(parts, source_type: str, source_text: str) -> Optional[BinarySemantic]:
    normalized: List[Tuple[str, Optional[str]]] = []
    all_digits = ""
    for kind, value in parts:
        if kind == "digits":
            run = str(value or "")
            if not re.fullmatch(r"[01]+", run):
                return None
            normalized.append(("digits", run))
            all_digits += run
        elif kind == "delimiter":
            normalized.append(("delimiter", value if value else None))
        else:
            return None
    if not normalized or normalized[0][0] != "digits" or not all_digits:
        return None
    return BinarySemantic(tuple(normalized), all_digits, source_type, source_text)


def _parse_binary_prefix(source: str) -> Optional[BinarySemantic]:
    s = str(source or "")
    if not s.startswith("0b") or len(s) < 3 or s[2] not in "01":
        return None
    parts: List[Tuple[str, Optional[str]]] = []
    run = ""
    i = 2
    while i < len(s):
        ch = s[i]
        if ch.isspace() or ch in "23456789" or (ch.isascii() and ch.isalpha()):
            break
        if ch in "01":
            run += ch
        else:
            if run:
                parts.append(("digits", run))
                run = ""
            parts.append(("delimiter", ch))
        i += 1
    if run:
        parts.append(("digits", run))
    # parseCompleteBinaryInput requires the whole supplied source to belong to the run.
    if i != len(s):
        return None
    return _make_binary_semantic(parts, "prefix", s)


def _validate_binary_tokens(tokens, source_type: str, source_text: str) -> Optional[BinarySemantic]:
    seq = list(tokens or [])
    if not seq or seq[0][0] != "digit":
        return None
    parts: List[Tuple[str, Optional[str]]] = []
    digits = ""
    for kind, value in seq:
        if kind == "delimiter":
            if not digits:
                return None
            parts.append(("digits", digits))
            digits = ""
            parts.append(("delimiter", value if value else None))
            continue
        if kind != "digit" or value not in {"0", "1"}:
            return None
        digits += str(value)
    if not digits:
        return None
    parts.append(("digits", digits))
    return _make_binary_semantic(parts, source_type, source_text)


def _parse_binary_proper_name(source: str, relaxed: bool) -> Optional[BinarySemantic]:
    value = str(source or "").strip()
    if not re.fullmatch(r"[A-Za-z]+(?:[ \t]+[A-Za-z]+)*", value):
        return None
    compact = re.sub(r"[ \t]+", "", value)
    if not compact.lower().startswith("noka"):
        return None
    body = compact[4:]
    if not body or not body.lower().endswith("n"):
        return None
    body = body[:-1].upper()
    syllable_map = {"NI": "0", "WE": "1"}
    if relaxed:
        syllable_map["WA"] = "1"
    structured: List[Tuple[str, Optional[str]]] = []
    i = 0
    while i < len(body):
        if body.startswith("NENE", i):
            structured.append(("delimiter", None))
            i += 4
            continue
        if i + 2 > len(body):
            return None
        digit = syllable_map.get(body[i:i + 2])
        if digit is None:
            return None
        structured.append(("digit", digit))
        i += 2
    return _validate_binary_tokens(structured, "properName", value)


def _parse_binary_cartouche(source: str, *, relaxed: bool, prefer_abbreviated: bool) -> Optional[BinarySemantic]:
    tokens = _tokenize_hex_cartouche_source(source)
    if not tokens or len(tokens) < 3 or tokens[0] != "noka" or tokens[-1] != "noka":
        return None
    start = 2 if len(tokens) > 1 and tokens[1] == ":" else 1
    body = tokens[start:-1]
    if not body:
        return None

    def try_abbreviated() -> Optional[BinarySemantic]:
        structured: List[Tuple[str, Optional[str]]] = []
        for word in body:
            if word == "e":
                structured.append(("delimiter", None))
            elif word == "ijo":
                structured.append(("digit", "0"))
            elif word == "wan":
                structured.append(("digit", "1"))
            else:
                return None
        return _validate_binary_tokens(structured, "cartouche", source)

    if prefer_abbreviated:
        semantic = try_abbreviated()
        if semantic is not None:
            return semantic

    patterns = [item for item in _hex_full_digit_patterns(relaxed) if item[0] in {"0", "1"}]
    n_words = {"nena", "nasa"}
    join_words = {"e", "en", "esun"}
    structured: List[Tuple[str, Optional[str]]] = []
    i = 0
    while i < len(body):
        if (i + 3 < len(body) and body[i] in n_words and body[i + 1] in join_words
                and body[i + 2] in n_words and body[i + 3] in join_words):
            structured.append(("delimiter", None))
            i += 4
            continue
        match = next((item for item in patterns if tuple(body[i:i + 2]) == item[1]), None)
        if match is None:
            structured = []
            break
        structured.append(("digit", match[0]))
        i += 2
    if structured:
        semantic = _validate_binary_tokens(structured, "cartouche", source)
        if semantic is not None:
            return semantic
    return None if prefer_abbreviated else try_abbreviated()


def parse_binary_input(
    value: str,
    *,
    relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING,
    abbreviate_numeric_cartouches: bool = DEFAULT_ABBREVIATE_NUMERIC_CARTOUCHES,
) -> Optional[BinarySemantic]:
    source = str(value or "").strip()
    if source.startswith("0b"):
        return _parse_binary_prefix(source)
    if source.startswith("[") and source.endswith("]"):
        return _parse_binary_cartouche(
            source[1:-1],
            relaxed=relaxed_nanpa_linjan_parsing,
            prefer_abbreviated=abbreviate_numeric_cartouches,
        )
    return _parse_binary_proper_name(source, relaxed_nanpa_linjan_parsing)


def binary_semantic_to_words(
    semantic: BinarySemantic,
    *,
    abbreviated: bool = False,
    relaxed_rendering: bool = False,
    number_word_style: str = DEFAULT_NUMBER_WORD_STYLE,
) -> List[str]:
    traditional = str(number_word_style or "").lower() == "traditional"
    words = ["noka", ":"]
    for kind, value in semantic.parts:
        if kind == "delimiter":
            words.extend(["e"] if abbreviated else ["nena", "e", "nena", "e"])
            continue
        run = str(value or "")
        if not re.fullmatch(r"[01]+", run):
            raise ValueError(f"Invalid binary digit run: {run!r}")
        for digit in run:
            if abbreviated:
                words.append("ijo" if digit == "0" else "wan")
            else:
                if digit == "0":
                    words.extend((["nasa", "ijo"] if traditional else ["nena", "ijo"]))
                elif relaxed_rendering:
                    words.extend(["wan", "ala"])
                else:
                    words.extend(["wan", "esun"] if traditional else ["wan", "e"])
    return words + ["noka"]


def binary_semantic_to_proper_name(semantic: BinarySemantic, *, relaxed_rendering: bool = False) -> str:
    words = ["Noka"]
    for kind, value in semantic.parts:
        if kind == "delimiter":
            if len(words) <= 1:
                raise ValueError("Binary delimiter cannot precede the first digit run")
            words[-1] += "n"
            words.append("Ene")
            continue
        run = str(value or "")
        syllables = "".join("ni" if digit == "0" else ("wa" if relaxed_rendering else "we") for digit in run)
        words.append(syllables[:1].upper() + syllables[1:])
    if len(words) <= 1:
        raise ValueError("Binary semantic has no digits")
    words[-1] += "n"
    return " ".join(words)


def binary_semantic_to_canonical_prefix(semantic: BinarySemantic) -> str:
    out = "0b"
    for kind, value in semantic.parts:
        out += str(value) if kind == "digits" else (str(value) if value is not None else ":")
    return out

def parse_numeric_input_to_caps(
    value: str,
    *,
    thousands_char: str = ",",
    group_fraction_triplets: bool = True,
    fraction_group_size: int = 3,
    mixed_style: str = DEFAULT_MIXED_STYLE,
    relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING,
    nanpa_colon_parsing: bool = DEFAULT_NANPA_COLON_PARSING,
    nanpa_colon_rendering: bool = DEFAULT_NANPA_COLON_RENDERING,
) -> Tuple[str, bool]:
    """Return ``(caps, is_time_or_date)`` using the JS parser's precedence."""
    s = str(value or "").strip()
    if not s:
        raise ValueError("Empty numeric input")
    if (nanpa_colon_parsing or nanpa_colon_rendering) and s.startswith("[") and s.endswith("]"):
        inner = s[1:-1].strip()
        raw_tokens = re.findall(r"[A-Za-z]+|:", inner)
        if len(raw_tokens) < 4 or raw_tokens[0].lower() != "nanpa" or raw_tokens[1] != ":" or raw_tokens[-1].lower() != "nanpa":
            raise ValueError(f"Invalid Nanpa-format cartouche: {s!r}")
        body = [token.lower() for token in raw_tokens[2:-1]]
        abbreviated = {"ijo":"I","wan":"W","tu":"T","seli":"S","awen":"A","luka":"L","utala":"U","mun":"M","pipi":"P","jo":"J"}
        positive = bool(body and body[0] == "en")
        if positive: body = body[1:]
        code = ""; valid_abbreviated = True
        for index, word in enumerate(body):
            if word in abbreviated: code += abbreviated[word]
            elif word in {"o","ona"}: code += "O"
            elif word in {"kulupu","kasi","kolon",":"}: code += "K"
            elif word == "kala": code += "EKO"
            elif word == "kin": code += "OKO"
            elif word == "kipisi" and index == len(body)-1: code += "OK"
            else: valid_abbreviated = False; break
        if valid_abbreviated and code:
            caps = hash_tilde_payload_to_nanpa_caps(("+" if positive else "") + code)
        else:
            if not all(word in WORDS_TO_UNC_CODES_MAP or word == ":" for word in body):
                raise ValueError(f"Invalid Nanpa-format cartouche: {s!r}")
            letters = "".join("K" if word == ":" else word[0].upper() for word in body)
            caps = "NE" + letters + "N"
            if body[:2] == ["nena", "en"] and caps.startswith("NENE"): caps = "NENS" + caps[4:]
            if caps.endswith("NOKEN"): caps = caps[:-5] + "OKN"
            tokenize_nanpa_caps(caps, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing)
    elif s.upper().startswith("#~"):
        caps = hash_tilde_payload_to_nanpa_caps(s)
    else:
        normalized = _normalize_vulgar_fraction_input(s)
        prefer_leading_plus_proper_name = (
            re.match(r"^nene", s, flags=re.IGNORECASE) is not None
            and re.fullmatch(r"[A-Z]+", s) is None
            and _is_valid_nanpa_linjan_proper_name(
                s,
                relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
                nanpa_colon_parsing=(nanpa_colon_parsing or nanpa_colon_rendering),
            )
        )
        if prefer_leading_plus_proper_name:
            caps = _proper_name_to_caps(s, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing, nanpa_colon_parsing=(nanpa_colon_parsing or nanpa_colon_rendering))
        elif _looks_like_nanpa_caps(normalized):
            caps = canonicalize_scientific_nanpa_caps(normalized)
            tokenize_nanpa_caps(caps, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing)
        else:
            caps = date_str_to_nanpa_caps(normalized, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing)
            if caps is None:
                caps = time_str_to_nanpa_caps(normalized, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing)
            if caps is None and _is_valid_nanpa_linjan_proper_name(s, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing, nanpa_colon_parsing=(nanpa_colon_parsing or nanpa_colon_rendering)):
                caps = _proper_name_to_caps(s, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing, nanpa_colon_parsing=(nanpa_colon_parsing or nanpa_colon_rendering))
            if caps is None:
                caps = decimal_string_to_nanpa_caps(
                    normalized,
                    thousands_char=thousands_char,
                    group_fraction_triplets=group_fraction_triplets,
                    fraction_group_size=fraction_group_size,
                    mixed_style=mixed_style,
                    relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
                )
    caps = canonicalize_scientific_nanpa_caps(caps)
    is_time_like = _caps_is_time(caps, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing) or _caps_is_date(caps, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing)
    return caps, is_time_like


def nanpa_caps_tokens_to_tp_words(
    tokens: List[str],
    *,
    negative_particle_word: str = "ona",
    number_word_style: str = DEFAULT_NUMBER_WORD_STYLE,
    relaxed_nanpa_linjan_rendering: bool = DEFAULT_RELAXED_NANPA_LINJAN_RENDERING,
    nanpa_colon_rendering: bool = DEFAULT_NANPA_COLON_RENDERING,
) -> List[str]:
    if not tokens:
        return []
    uniform = str(number_word_style or "").lower() != "traditional"
    e_word = "e" if uniform else "esun"
    join = "e"
    n_word = "nena" if uniform else "nasa"
    decimal_word = "nena" if uniform else "ni"
    negative = str(negative_particle_word or "ona").strip().lower()
    if negative not in {"o", "ona"}:
        raise ValueError("negative_particle_word must be 'o' or 'ona'")

    out: List[str] = []
    after_start = False
    after_scientific = False
    i = 0
    while i < len(tokens):
        token = tokens[i]
        if token == "NE":
            nxt = tokens[i + 1] if i + 1 < len(tokens) else None
            if nxt == "KO":
                out.extend((["nanpa", ":", "kala", "open"] if (not out and nanpa_colon_rendering) else (["nanpa", e_word, "kala", "open"] if not out else [n_word, join, "kala", "open"])))
                after_start = False
                after_scientific = True
                i += 2
                continue
            if not out:
                out.extend(("nanpa", ":") if nanpa_colon_rendering else ("nanpa", e_word)); after_start = True
            else:
                out.extend((n_word, join)); after_start = False
            after_scientific = False
            i += 1
            continue
        if token == "NS":
            # Explicit positive full opening: nanpa e nena en ...
            out.extend(("nena", "en"))
            after_start = False
            after_scientific = False
            i += 1
            continue
        if token in _DIGIT_TOKENS:
            after_start = after_scientific = False
            if relaxed_nanpa_linjan_rendering and token in _RELAXED_TOKEN_TO_RENDER_WORDS:
                out.extend(_RELAXED_TOKEN_TO_RENDER_WORDS[token])
            else:
                strict = _RELAXED_TOKEN_TO_STRICT_TOKEN.get(token, token)
                digit_word = _TOKEN_TO_DIGIT_WORD[strict]
                out.extend((n_word, digit_word) if strict in {"NI", "NA", "NU"} else (digit_word, e_word))
            i += 1
            continue
        if token == "NO":
            if after_start or after_scientific:
                out.extend((n_word, negative)); after_start = after_scientific = False; i += 1; continue
            nxt = tokens[i + 1] if i + 1 < len(tokens) else None
            if nxt == "NE":
                out.extend((decimal_word, "o", n_word, join)); i += 2
            else:
                out.extend((decimal_word, "o")); i += 1
            after_start = False
            continue
        if token == "NONO":
            out.extend(("nena", "o", "nena", "o")); after_start = False; i += 1; continue
        if token == "NOKO":
            out.extend(("nena", "open", "kin", "open")); after_start = False; i += 1; continue
        if token == "NONONO":
            out.extend((n_word, "o", n_word, "o", n_word, "o")); after_start = False; i += 1; continue
        if token in {"KE", "KEKE", "KEKEKE"}:
            count = len(token) // 2
            for _ in range(count): out.extend(("kulupu", join))
            after_start = False; i += 1; continue
        if token == "N":
            out.append("nanpa"); after_start = False; i += 1; continue
        if token == "OK":
            # OK is normally consumed by convert_encoded... before this function.
            i += 1; continue
        if token == "KO":
            # KO is consumed together with the preceding NE.
            i += 1; continue
        raise ValueError(f"Unknown token {token!r}")
    return out


def _replace_time_separators_words(words: List[str], number_word_style: str) -> List[str]:
    uniform = str(number_word_style or "").lower() != "traditional"
    join = "e"
    n_word = "nena" if uniform else "nasa"
    pattern = [n_word, join, "kulupu", join]
    out: List[str] = []
    i = 0
    while i < len(words):
        if words[i:i + len(pattern)] == pattern:
            out.extend((n_word, join, "kasi", join)); i += len(pattern)
        else:
            out.append(words[i]); i += 1
    return out


def _uniformize_numeric_ucsur(glyph_string: str) -> str:
    nanpa = WORDS_TO_UNC_CODES_MAP["nanpa"]
    nena = WORDS_TO_UNC_CODES_MAP["nena"]
    e = WORDS_TO_UNC_CODES_MAP["e"]
    en = WORDS_TO_UNC_CODES_MAP["en"]
    to_nena = {WORDS_TO_UNC_CODES_MAP[w] for w in ("nasa", "nasin", "ni", "nimi", "noka", "nena")}
    to_e = {WORDS_TO_UNC_CODES_MAP[w] for w in ("e", "en", "esun")}
    chars = list(glyph_string)

    # The sole canonical ``en`` structural glyph is the explicit-positive full
    # opening: nanpa e nena en ... . All ordinary numeric scaffolding is ``e``.
    has_explicit_positive_opening = (
        len(chars) >= 4
        and chars[0] == nanpa
        and chars[1] == e
        and chars[2] == nena
        and chars[3] == en
    )

    for idx, ch in enumerate(chars):
        if ch == nanpa:
            if idx not in (0, len(chars) - 1):
                chars[idx] = nena
        elif ch in to_nena:
            chars[idx] = nena
        elif ch in to_e:
            chars[idx] = en if (has_explicit_positive_opening and idx == 3) else e
    return "".join(chars)


def convert_encoded_str_to_nasin_nanpa_char_codes(
    value: str,
    *,
    thousands_char: str = ",",
    prefix_with_nanpa_symbol: bool = True,
    mapping: Dict[str, str] = DIGIT_IMAGE_PATHS,
    thousands_as: str = "P",
    group_fraction_triplets: bool = True,
    fraction_group_size: int = 3,
    negative_particle_word: str = "ona",
    number_word_style: str = DEFAULT_NUMBER_WORD_STYLE,
    mixed_style: str = DEFAULT_MIXED_STYLE,
    relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING,
    relaxed_nanpa_linjan_rendering: bool = DEFAULT_RELAXED_NANPA_LINJAN_RENDERING,
    nanpa_colon_parsing: bool = DEFAULT_NANPA_COLON_PARSING,
    nanpa_colon_rendering: bool = DEFAULT_NANPA_COLON_RENDERING,
    enable_hex_parsing: bool = DEFAULT_ENABLE_HEX_PARSING,
    enable_binary_parsing: bool = DEFAULT_ENABLE_BINARY_PARSING,
    enable_binary_rendering: bool = DEFAULT_ENABLE_BINARY_RENDERING,
) -> str:
    if value is None:
        raise ValueError("value must be a string, not None")
    s = str(value).strip()
    if not s:
        return ""

    if s == "N":
        return mapping.get("^", WORDS_TO_UNC_CODES_MAP["nanpa"])
    if len(s) == 1 and s in mapping and not s.isdigit():
        return mapping[s]

    if enable_binary_parsing or enable_binary_rendering:
        binary_semantic = parse_binary_input(
            s,
            relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
            abbreviate_numeric_cartouches=False,
        )
        if binary_semantic is not None:
            words = binary_semantic_to_words(
                binary_semantic,
                abbreviated=False,
                relaxed_rendering=relaxed_nanpa_linjan_rendering,
                number_word_style=number_word_style,
            )
            return tp_words_to_nasin_nanpa_unicodes(words)

    if enable_hex_parsing:
        semantic = parse_hex_input(
            s,
            relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
            abbreviate_numeric_cartouches=False,
        )
        if semantic is not None:
            words = hex_semantic_to_words(
                semantic,
                abbreviated=False,
                relaxed_rendering=relaxed_nanpa_linjan_rendering,
                number_word_style=number_word_style,
            )
            return tp_words_to_nasin_nanpa_unicodes(words)

    # Legacy leading N is a request for the numeric nanpa prefix, not data.
    if s.startswith("N") and not s.startswith("NE") and not s.upper().startswith("#~") and len(s) > 1:
        s = s[1:]

    # Preserve the renderer's established compatibility with compact bare
    # digit words used by existing fact-sheet definitions (for example Nwan).
    decoded_legacy_word = decode_nanpa_numbers_in_text(s, thousands_char="")
    if decoded_legacy_word != s and re.fullmatch(r"[+-]?\d+(?:\.\d+)?", decoded_legacy_word):
        s = decoded_legacy_word

    caps, is_time_like = parse_numeric_input_to_caps(
        s,
        thousands_char=thousands_char,
        group_fraction_triplets=group_fraction_triplets,
        fraction_group_size=fraction_group_size,
        mixed_style=mixed_style,
        relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
        nanpa_colon_parsing=nanpa_colon_parsing,
        nanpa_colon_rendering=nanpa_colon_rendering,
    )
    tokens = tokenize_nanpa_caps(caps, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing)
    has_percent = "OK" in tokens
    tokens_no_percent = [t for t in tokens if t != "OK"]
    words = nanpa_caps_tokens_to_tp_words(
        tokens_no_percent,
        negative_particle_word=negative_particle_word,
        number_word_style=number_word_style,
        relaxed_nanpa_linjan_rendering=relaxed_nanpa_linjan_rendering,
        nanpa_colon_rendering=nanpa_colon_rendering,
    )
    if is_time_like:
        words = _replace_time_separators_words(words, number_word_style)
    if has_percent:
        suffix = (["nena", "open", "kipisi", "e"] if str(number_word_style).lower() == "uniform"
                  else ["noka", "open", "kipisi", "e"])
        idx = len(words) - 1 - words[::-1].index("nanpa") if "nanpa" in words else len(words)
        words[idx:idx] = suffix
    glyphs = tp_words_to_nasin_nanpa_unicodes(words)
    if str(number_word_style).lower() == "uniform":
        glyphs = _uniformize_numeric_ucsur(glyphs)
    return glyphs


def abbreviate_numeric_cartouche_ucsur(
    glyph_string: str,
    *,
    preserve_nene_as_en: bool = DEFAULT_PRESERVE_NUMERIC_CARTOUCHE_BREAKS_IN_ABBREVIATION,
) -> str:
    """Apply the current JavaScript numeric-cartouche abbreviation rules.

    This mirrors the frozen renderer reference: every supported semantic
    numeric opener (nanpa/nasa/noka/tenpo/suno/toki) enters abbreviation
    state, colon-headed positive openings preserve the colon, and the final
    decimal closing nanpa is retained.
    """
    if not glyph_string:
        return glyph_string

    nanpa = WORDS_TO_UNC_CODES_MAP["nanpa"]
    nasa = WORDS_TO_UNC_CODES_MAP["nasa"]
    noka = WORDS_TO_UNC_CODES_MAP["noka"]
    tenpo = WORDS_TO_UNC_CODES_MAP["tenpo"]
    suno = WORDS_TO_UNC_CODES_MAP["suno"]
    toki = WORDS_TO_UNC_CODES_MAP["toki"]
    colon = WORDS_TO_UNC_CODES_MAP[":"]
    numeric_heads = {nanpa, nasa, noka, tenpo, suno, toki}
    nena = WORDS_TO_UNC_CODES_MAP["nena"]
    e = WORDS_TO_UNC_CODES_MAP["e"]
    en = WORDS_TO_UNC_CODES_MAP["en"]
    open_glyph = WORDS_TO_UNC_CODES_MAP["open"]
    drop = {
        nanpa, en, e, nena, open_glyph,
        WORDS_TO_UNC_CODES_MAP["ala"],
        WORDS_TO_UNC_CODES_MAP["ike"],
        WORDS_TO_UNC_CODES_MAP["uta"],
    }
    chars = list(glyph_string)
    has_traditional_full_positive_opening = (
        len(chars) >= 4
        and chars[0] in numeric_heads
        and chars[1] == e
        and chars[2] == nena
        and chars[3] == en
    )
    has_colon_full_positive_opening = (
        len(chars) >= 4
        and chars[0] in numeric_heads
        and chars[1] == colon
        and chars[2] == nena
        and chars[3] == en
    )
    has_full_positive_opening = has_traditional_full_positive_opening or has_colon_full_positive_opening
    has_full_scaffolding_after_opening = any(ch == e or ch in drop for ch in chars[2:-1])
    has_already_abbreviated_positive_opening = (
        not has_full_positive_opening
        and not has_full_scaffolding_after_opening
        and len(chars) >= 3
        and chars[0] in numeric_heads
        and chars[1] == en
    )
    has_already_abbreviated_colon_positive_opening = (
        not has_full_positive_opening
        and not has_full_scaffolding_after_opening
        and len(chars) >= 4
        and chars[0] in numeric_heads
        and chars[1] == colon
        and chars[2] == en
    )

    out: List[str] = []
    kept_opening_head = False
    i = 0
    while i < len(chars):
        ch = chars[i]
        is_final_nanpa = ch == nanpa and i == len(chars) - 1

        if not kept_opening_head:
            out.append(ch)
            if i == 0 and ch in numeric_heads:
                kept_opening_head = True
            elif ch == nanpa:
                kept_opening_head = True
            i += 1
            continue

        if is_final_nanpa:
            out.append(ch)
            i += 1
            continue

        if has_traditional_full_positive_opening and i == 1:
            out.append(en)
            i = 4
            continue
        if has_colon_full_positive_opening and i == 2:
            out.append(en)
            i = 4
            continue
        if has_already_abbreviated_positive_opening and i == 1:
            out.append(en)
            i += 1
            continue
        if has_already_abbreviated_colon_positive_opening and i == 2:
            out.append(en)
            i += 1
            continue

        if (
            preserve_nene_as_en
            and ch == nena
            and i + 3 < len(chars)
            and chars[i + 1] in {e, en}
            and chars[i + 2] == nena
            and chars[i + 3] in {e, en}
        ):
            # The current renderer preserves a full NENE break as one visible
            # ``e`` glyph in abbreviated cartouches.
            out.append(e)
            i += 4
            continue

        if ch not in drop:
            out.append(ch)
        i += 1
    return "".join(out)


def compact_nene_breaks_to_en(glyph_string: str) -> str:
    """Manually replace each full NENE break with one ``en`` glyph.

    This low-level compatibility helper is no longer called by any numeric
    cartouche renderer. JavaScript parity requires full cartouches to retain
    ``nena en nena en``; only the abbreviation path may expose one ``en``.
    """
    if not glyph_string:
        return glyph_string
    nena = WORDS_TO_UNC_CODES_MAP["nena"]
    en = WORDS_TO_UNC_CODES_MAP["en"]
    return str(glyph_string).replace(nena + en + nena + en, en)


def _magnitude_ke_proper_name_fragment(count: int) -> str:
    count = max(0, int(count))
    if count < 1: return ""
    if count <= 3: return "e" + "ke" * count
    groups = [2]
    remaining = count - 2
    while remaining > 3:
        groups.append(2); remaining -= 2
    groups.append(remaining)
    return " ".join(("e" if idx == 0 else "") + "ke" * size for idx, size in enumerate(groups))


def split_cartouche_caps_letters(
    caps: str,
    *,
    title_case_words: bool = False,
    relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING,
) -> str:
    """Format a proper name exactly as the JavaScript NanpaParser does."""
    s = canonicalize_scientific_nanpa_caps(caps)
    if not s:
        return ""
    if len(s) < 3 or not s.startswith("NE") or not s.endswith("N"):
        raise ValueError(f"Not a valid nanpa-caps label: {caps!r}")
    has_ok = s[-3:-1] == "OK"
    main = s[:-3] + "N" if has_ok else s
    end = len(main) - 1
    if end % 2:
        raise ValueError(f"Malformed caps (odd pair area) in {caps!r}")
    out = ""
    i = 0
    while i < end:
        pair = main[i:i + 2]
        next_pair = main[i + 2:i + 4] if i + 4 <= end else None
        if pair == "NE" and next_pair == "NO" and i == 0:
            out += "neno "; i += 4; continue
        if pair == "NE" and next_pair == "NS" and i == 0:
            out += "nene "; i += 4; continue
        if pair == "NE" and next_pair == "NE":
            out += "n ene "; i += 4; continue
        if pair == "NO" and next_pair == "NE" and i > 0:
            out += "n one "; i += 4; continue
        if pair == "NO" and next_pair == "KO" and i > 0:
            out += "n oko" + (" " if i + 4 < end else ""); i += 4; continue
        if pair == "NE" and next_pair == "KO" and i > 0:
            out += "n eko" + (" " if i + 4 < end else ""); i += 4; continue
        if pair == "NO" and next_pair == "NO" and i > 0:
            count = 1; j = i
            while j + 6 <= end and main[j + 4:j + 6] == "NO":
                count += 1; j += 2
            out += "n o" + "no" * count
            if i + 2 * count < end: out += " "
            i += 2 + 2 * count; continue
        if pair == "NE" and next_pair == "KE":
            count = 1; j = i
            while j + 6 <= end and main[j + 4:j + 6] == "KE":
                count += 1; j += 2
            out += "n " + _magnitude_ke_proper_name_fragment(count)
            if i + 2 * count < end: out += " "
            i += 2 + 2 * count; continue
        if pair == "OK":
            if i > 0 and not out.endswith(" "): out += " "
            if i > 0: out += "n "
            out += "oke"
        else:
            out += pair.lower()
        i += 2
    out = re.sub(r"\s+n(?=\s|$)", "n", out).strip() + "n"
    if has_ok: out += " oken"
    # Split the special final-hundred Inin word.  Relaxed parsing accepts
    # the additional wa/tu/lu/mu/pi hundred forms used by JavaScript v62.
    strict_suffixes = [
        "weninin", "teninin", "seninin", "naninin", "leninin",
        "nuninin", "meninin", "peninin", "jeninin",
    ]
    relaxed_suffixes = ["waninin", "tuninin", "luninin", "muninin", "pininin", "joninin"]
    suffixes = strict_suffixes + (relaxed_suffixes if relaxed_nanpa_linjan_parsing else [])
    words: List[str] = []
    for word in out.split():
        if any(word.lower().endswith(sfx) for sfx in suffixes) and word.lower().endswith("inin") and len(word) > 4:
            words.extend((word[:-4], word[-4:]))
        else:
            words.append(word)
    out = " ".join(words)
    if title_case_words:
        out = " ".join(w[:1].upper() + w[1:] for w in out.split())
    return out


def caps_to_canonical_unique_code(caps: str, *, relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING) -> str:
    canonical = canonicalize_scientific_nanpa_caps(caps)
    tokens = tokenize_nanpa_caps(canonical, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing)
    parts: List[str] = []
    i = 0
    while i < len(tokens):
        token = tokens[i]
        if token == "NE":
            if i == 0 and i + 1 < len(tokens) and tokens[i + 1] == "NS":
                parts.append("e")
                i += 2
                continue
            j = i
            while j < len(tokens) and tokens[j] == "NE": j += 1
            count = j - i
            if count // 2: parts.append("ee" * (count // 2))
            if count % 2 and j < len(tokens) and tokens[j] == "KO":
                parts.append("eko"); i = j + 1
            else:
                i = j
            continue
        if token == "N": i += 1; continue
        if token in _TOKEN_TO_NUMBER_CODE_LETTER: parts.append(_TOKEN_TO_NUMBER_CODE_LETTER[token])
        elif token == "NO": parts.append("o")
        elif token == "NONO": parts.append("oo")
        elif token == "NONONO": parts.append("ooo")
        elif token == "NOKO": parts.append("oko")
        elif token == "KO": parts.append("ko")
        elif token == "KE": parts.append("k")
        elif token == "KEKE": parts.append("kk")
        elif token == "KEKEKE": parts.append("kkk")
        elif token == "OK": parts.append("ok")
        i += 1
    return "#~" + "".join(parts)


def value_to_cartouche_caps(
    value: str,
    *,
    thousands_char: str = ",",
    group_fraction_triplets: bool = True,
    fraction_group_size: int = 3,
    label_style: str = "upper",
    mixed_style: str = DEFAULT_MIXED_STYLE,
    relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING,
) -> str:
    if value is None:
        raise ValueError("value must be a string, not None")
    v = str(value).strip()
    if v in _LITERAL_TOKEN_TO_CAPS:
        caps = literal_token_to_caps(v)
    else:
        if v.startswith("N") and not v.startswith("NE") and not v.upper().startswith("#~") and len(v) > 1:
            v = v[1:]
        caps, _ = parse_numeric_input_to_caps(
            v,
            thousands_char=thousands_char,
            group_fraction_triplets=group_fraction_triplets,
            fraction_group_size=fraction_group_size,
            mixed_style=mixed_style,
            relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
        )
    return format_caps_label(caps, style=label_style)


def nanpa_caps_to_numeric_expression(
    caps: str,
    *,
    thousands_char: str = ",",
    group_thousands: bool = True,
) -> str:
    """Decode current and legacy caps, including shortened scientific NEKO."""
    tokens = tokenize_nanpa_caps(canonicalize_scientific_nanpa_caps(caps), relaxed_nanpa_linjan_parsing=True)
    has_percent = len(tokens) >= 2 and tokens[-2] == "OK"
    if has_percent:
        tokens = tokens[:-2] + ["N"]
    end = len(tokens) - 1

    def ke_count(token: str) -> int:
        return len(token) // 2 if token and set(token) <= {"K", "E"} and token.startswith("KE") else 0

    def decode_segment(segment: List[str], *, time_delimiter: bool = False) -> Optional[str]:
        if not segment: return None
        positive = False; neg = False; kind = "int"; int_s = ""; frac_s = ""; suffix_count = 0; i = 0
        if i < len(segment) and segment[i] == "NS":
            positive = True; i += 1
        if i < len(segment) and segment[i] == "NO" and not (i + 1 < len(segment) and segment[i + 1] == "NE"):
            neg = True; i += 1
        def append_sep(frac: bool) -> None:
            nonlocal int_s, frac_s
            if frac:
                if frac_s and not frac_s.endswith("_"):
                    frac_s += "_"
            else:
                if int_s and not int_s.endswith(","):
                    int_s += ","
        while i < len(segment):
            t = segment[i]
            if t in _TOKEN_TO_DIGIT_CHAR:
                if kind == "int": int_s += _TOKEN_TO_DIGIT_CHAR[t]
                else: frac_s += _TOKEN_TO_DIGIT_CHAR[t]
                i += 1; continue
            if t == "NO" and i + 1 < len(segment) and segment[i + 1] == "NE":
                if kind != "int": return None
                int_s = int_s or "0"; kind = "frac"; i += 2; continue
            if t == "NE" and i + 1 < len(segment) and segment[i + 1] == "NE":
                append_sep(kind == "frac"); i += 2; continue
            if t == "NE" and i + 1 < len(segment):
                j = i + 1; count = 0
                while j < len(segment) and ke_count(segment[j]):
                    count += ke_count(segment[j]); j += 1
                if count:
                    if time_delimiter and count == 1 and j < len(segment):
                        int_s += ":"; i = j; continue
                    if j < len(segment) and segment[j] in _TOKEN_TO_DIGIT_CHAR:
                        append_sep(kind == "frac"); i = j; continue
                    suffix_count += count; i = j; continue
            return None
        int_s = int_s or "0"
        suffix = {1: "K", 2: "M", 3: "B", 4: "T"}.get(suffix_count, f"×1000^{suffix_count}" if suffix_count > 4 else "")
        result = ("-" if neg else ("+" if positive else "")) + int_s
        if kind == "frac": result += "." + (frac_s or "0")
        return result + suffix

    mixed_positions = [i for i, t in enumerate(tokens) if t in {"NONONO", "NOKO"}]
    if mixed_positions:
        mix = mixed_positions[0]
        try: frac = tokens.index("NONO", mix + 1)
        except ValueError: raise ValueError("Mixed number missing NONO")
        a = decode_segment(tokens[1:mix]); b = decode_segment(tokens[mix + 1:frac]); c = decode_segment(tokens[frac + 1:end])
        if None in (a, b, c): raise ValueError("Invalid mixed-number caps")
        result = f"{a}+{b}/{c}"
    elif "NONO" in tokens:
        frac = tokens.index("NONO")
        a = decode_segment(tokens[1:frac]); b = decode_segment(tokens[frac + 1:end])
        if None in (a, b): raise ValueError("Invalid fraction caps")
        result = f"{a}/{b}"
    else:
        marker = next((i for i in range(1, end - 1) if tokens[i:i + 2] == ["NE", "KO"]), -1)
        if marker > 1:
            a = decode_segment(tokens[1:marker]); b = decode_segment(tokens[marker + 2:end])
            if None in (a, b): raise ValueError("Invalid scientific caps")
            result = f"{a}e{b}"
        else:
            # The JavaScript public parser decodes NEKE date/time boundaries
            # using the ordinary grouped-value display form (commas).
            decoded = decode_segment(tokens[1:end])
            if decoded is None:
                return None
            result = decoded
    return result + ("%" if has_percent else "")


def parse_number(
    value: str,
    *,
    enable_hex_parsing: bool = DEFAULT_ENABLE_HEX_PARSING,
    enable_binary_parsing: bool = DEFAULT_ENABLE_BINARY_PARSING,
    enable_binary_rendering: bool = DEFAULT_ENABLE_BINARY_RENDERING,
    nanpa_colon_parsing: bool = DEFAULT_NANPA_COLON_PARSING,
    nanpa_colon_rendering: bool = DEFAULT_NANPA_COLON_RENDERING,
    relaxed_nanpa_linjan_parsing: bool = DEFAULT_RELAXED_NANPA_LINJAN_PARSING,
    relaxed_nanpa_linjan_rendering: bool = DEFAULT_RELAXED_NANPA_LINJAN_RENDERING,
    abbreviate_numeric_cartouches: bool = DEFAULT_ABBREVIATE_NUMERIC_CARTOUCHES,
    number_word_style: str = DEFAULT_NUMBER_WORD_STYLE,
    **options,
) -> Dict[str, object]:
    """Parse and encode one decimal or hexadecimal number.

    This is the Python counterpart of JavaScript ``NanpaParser.parseNumber``.
    Rendering flags imply their corresponding parsing flags.
    """
    source = str(value or "").strip()
    if not source: raise ValueError("Empty numeric input")
    mode = "traditional" if str(options.get("mode", options.get("numeric_mode", number_word_style))).lower() == "traditional" else "uniform"
    enable_hex_parsing = bool(options.get("enableHexParsing", enable_hex_parsing))
    enable_binary_parsing = bool(options.get("enableBinaryParsing", enable_binary_parsing))
    enable_binary_rendering = bool(options.get("enableBinaryRendering", enable_binary_rendering))

    if enable_binary_parsing or enable_binary_rendering:
        binary_semantic = parse_binary_input(
            source,
            relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
            abbreviate_numeric_cartouches=abbreviate_numeric_cartouches,
        )
        if binary_semantic is not None:
            full_words = binary_semantic_to_words(
                binary_semantic, abbreviated=False, relaxed_rendering=relaxed_nanpa_linjan_rendering, number_word_style=mode
            )
            abbreviated_words = binary_semantic_to_words(
                binary_semantic, abbreviated=True, relaxed_rendering=relaxed_nanpa_linjan_rendering, number_word_style=mode
            )
            inner = tp_words_to_nasin_nanpa_unicodes(full_words)
            abbreviated_inner = tp_words_to_nasin_nanpa_unicodes(abbreviated_words)
            canonical = binary_semantic_to_canonical_prefix(binary_semantic)
            inner_codepoints = [ord(ch) for ch in inner]
            abbreviated_codepoints = [ord(ch) for ch in abbreviated_inner]
            codepoints = [0xF1990, *inner_codepoints, 0xF1991]
            return {"input":source, "kind":"binary", "number_base":2, "is_binary":True, "is_hex":False, "caps":None,
                    "proper_name":binary_semantic_to_proper_name(binary_semantic, relaxed_rendering=relaxed_nanpa_linjan_rendering),
                    "unique_code":canonical, "display_value":canonical, "binary_digits":binary_semantic.digits,
                    "binary_parts":[{"kind":k, "digits":v} if k == "digits" else {"kind":k, "char":v} for k,v in binary_semantic.parts],
                    "ucsur_codepoints":inner_codepoints, "abbreviated_ucsur_codepoints":abbreviated_codepoints,
                    "hex_codepoints":" ".join(f"{cp:04X}" for cp in inner_codepoints),
                    "hex_with_cartouche":" ".join(f"{cp:04X}" for cp in codepoints),
                    "tp_words":full_words, "abbreviated_words":abbreviated_words, "words":full_words.copy(),
                    "inner_codepoints":inner_codepoints, "codepoints":codepoints,
                    "is_time":False, "is_date":False, "is_time_like":False, "numeric_mode":mode}

    if enable_hex_parsing:
        semantic = parse_hex_input(
            source,
            relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
            abbreviate_numeric_cartouches=abbreviate_numeric_cartouches,
        )
        if semantic is not None:
            full_words = hex_semantic_to_words(
                semantic,
                abbreviated=False,
                relaxed_rendering=relaxed_nanpa_linjan_rendering,
                number_word_style=mode,
            )
            abbreviated_words = hex_semantic_to_words(
                semantic,
                abbreviated=True,
                relaxed_rendering=relaxed_nanpa_linjan_rendering,
                number_word_style=mode,
            )
            inner = tp_words_to_nasin_nanpa_unicodes(full_words)
            abbreviated_inner = tp_words_to_nasin_nanpa_unicodes(abbreviated_words)
            canonical = "#" + "".join(v if k == "digits" else (v or ":") for k, v in semantic.parts)
            inner_codepoints = [ord(ch) for ch in inner]
            abbreviated_codepoints = [ord(ch) for ch in abbreviated_inner]
            codepoints = [0xF1990, *inner_codepoints, 0xF1991]
            return {"input":source, "kind":"hex", "number_base":16, "is_hex":True, "is_binary":False, "caps":None,
                    "proper_name":hex_semantic_to_proper_name(semantic, relaxed_rendering=relaxed_nanpa_linjan_rendering),
                    "unique_code":canonical, "display_value":canonical, "hex_digits":semantic.digits,
                    "hex_parts":[{"kind":k, "digits":v} if k == "digits" else {"kind":k, "char":v} for k,v in semantic.parts],
                    "ucsur_codepoints":inner_codepoints, "abbreviated_ucsur_codepoints":abbreviated_codepoints,
                    "hex_codepoints":" ".join(f"{cp:04X}" for cp in inner_codepoints),
                    "hex_with_cartouche":" ".join(f"{cp:04X}" for cp in codepoints),
                    "tp_words":full_words, "abbreviated_words":abbreviated_words, "words":full_words.copy(),
                    "inner_codepoints":inner_codepoints, "codepoints":codepoints,
                    "is_time":False, "is_date":False, "is_time_like":False, "numeric_mode":mode}

    normalized = _normalize_vulgar_fraction_input(source)
    prefer_leading_plus = (
        re.match(r"^nene", source, flags=re.IGNORECASE) is not None
        and re.fullmatch(r"[A-Z]+", source) is None
        and _is_valid_nanpa_linjan_proper_name(
            source,
            relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
            nanpa_colon_parsing=(nanpa_colon_parsing or nanpa_colon_rendering),
        )
    )
    structured_kind = None
    if not prefer_leading_plus and not _looks_like_nanpa_caps(normalized):
        date_candidate = date_str_to_nanpa_caps(normalized, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing)
        time_candidate = None if date_candidate is not None else time_str_to_nanpa_caps(
            normalized,
            relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
        )
        if date_candidate is not None:
            structured_kind = "date"
        elif time_candidate is not None:
            structured_kind = "time"

    caps, _is_time_like = parse_numeric_input_to_caps(
        source,
        relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing,
        nanpa_colon_parsing=(nanpa_colon_parsing or nanpa_colon_rendering),
        nanpa_colon_rendering=nanpa_colon_rendering,
        **{k:v for k,v in options.items() if k in {"thousands_char","group_fraction_triplets","fraction_group_size","mixed_style"}},
    )
    decoded_time = _decode_time_caps(caps, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing)
    if decoded_time and decoded_time["negative_input"] and decoded_time["is_zero"]:
        normalized_tokens = tokenize_nanpa_caps(caps, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing)
        if normalized_tokens[:2] == ["NE", "NO"]:
            del normalized_tokens[1]
            caps = "".join(normalized_tokens)
    tokens = tokenize_nanpa_caps(caps, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing)
    caps_is_date = _caps_is_date(caps, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing)
    caps_is_time = _caps_is_time(caps, relaxed_nanpa_linjan_parsing=relaxed_nanpa_linjan_parsing)
    is_date = True if structured_kind == "date" else (False if structured_kind == "time" else caps_is_date)
    is_time = True if structured_kind == "time" else (False if structured_kind == "date" else (not caps_is_date and caps_is_time))
    is_time_like = is_date or is_time
    has_percent = "OK" in tokens
    tokens_no_percent = [token for token in tokens if token != "OK"]
    words = nanpa_caps_tokens_to_tp_words(
        tokens_no_percent,
        number_word_style=mode,
        relaxed_nanpa_linjan_rendering=relaxed_nanpa_linjan_rendering,
        nanpa_colon_rendering=nanpa_colon_rendering,
    )
    if is_time_like:
        words = _replace_time_separators_words(words, mode)
    if has_percent:
        suffix = ["nena", "open", "kipisi", "e"] if mode == "uniform" else ["noka", "open", "kipisi", "e"]
        insert_at = len(words) - 1 - words[::-1].index("nanpa") if "nanpa" in words else len(words)
        words[insert_at:insert_at] = suffix
    inner = tp_words_to_nasin_nanpa_unicodes(words)
    inner_codepoints = [ord(ch) for ch in inner]
    codepoints = [0xF1990, *inner_codepoints, 0xF1991]
    proper_name_caps = _caps_for_output_rendering(
        caps,
        relaxed_nanpa_linjan_rendering=relaxed_nanpa_linjan_rendering,
    )
    legacy_proper_name = split_cartouche_caps_letters(
        proper_name_caps,
        title_case_words=True,
        relaxed_nanpa_linjan_parsing=(relaxed_nanpa_linjan_parsing or relaxed_nanpa_linjan_rendering),
    )
    if nanpa_colon_rendering:
        legacy_words = legacy_proper_name.lower().split()
        if legacy_words and legacy_words[0].startswith("ne"):
            legacy_words[0] = legacy_words[0][2:]
            if not legacy_words[0]:
                legacy_words.pop(0)
        if len(legacy_words) > 1 and legacy_words[0] in {"no", "ne"}:
            legacy_words[0] += legacy_words[1]
            del legacy_words[1]
        proper_name = "Nanpa " + " ".join(word[:1].upper() + word[1:] for word in legacy_words)
    else:
        proper_name = legacy_proper_name
    return {"input":source, "kind":"decimal", "number_base":10, "is_hex":False, "is_binary":False, "caps":caps,
            "proper_name":proper_name,
            "unique_code":caps_to_canonical_unique_code(caps), "display_value":nanpa_caps_to_numeric_expression(caps),
            "ucsur_codepoints":inner_codepoints,
            "hex_codepoints":" ".join(f"{cp:04X}" for cp in inner_codepoints),
            "hex_with_cartouche":" ".join(f"{cp:04X}" for cp in codepoints),
            "tp_words":words, "words":words.copy(),
            "inner_codepoints":inner_codepoints, "codepoints":codepoints,
            "is_time":is_time, "is_date":is_date, "is_time_like":is_time_like, "numeric_mode":mode}


def number_to_nanpa_linja_n(value, **options) -> str:
    """Compatibility encoder now backed by this combined parser/renderer."""
    parsed = parse_number(str(value), abbreviate_numeric_cartouches=False, **options)
    if parsed["kind"] in {"hex", "binary"}:
        return str(parsed["proper_name"])
    # The original nanpa_linja_n helper returned the pronounceable compact
    # identifier, not the expanded cartouche word sequence.  Several existing
    # fact-sheet conversion paths rely on each identifier block ending in n.
    relaxed_rendering = bool(options.get("relaxed_nanpa_linjan_rendering", DEFAULT_RELAXED_NANPA_LINJAN_RENDERING))
    output_caps = _caps_for_output_rendering(str(parsed["caps"]), relaxed_nanpa_linjan_rendering=relaxed_rendering)
    return split_cartouche_caps_letters(
        output_caps,
        title_case_words=False,
        relaxed_nanpa_linjan_parsing=bool(options.get("relaxed_nanpa_linjan_parsing", DEFAULT_RELAXED_NANPA_LINJAN_PARSING)) or relaxed_rendering,
    )


def decode_nanpa_numbers_in_text(text: str, thousands_char: str = ",") -> str:
    """Compatibility decoder for numeric identifiers used by legacy layouts."""
    source = str(text or "")
    parsed_caps = _nanpa_linjan_proper_name_to_caps(source, relaxed_nanpa_linjan_parsing=True, nanpa_colon_parsing=True)
    if parsed_caps is not None:
        return nanpa_caps_to_numeric_expression(parsed_caps, thousands_char=thousands_char, group_thousands=bool(thousands_char))
    # Legacy fact-sheet data also uses bare compact digit words such as
    # ``wan``, ``lun`` and ``watusen`` without the leading Ne/Nanpa marker.
    compact = re.sub(r"\s+", "", source).lower()
    if compact.endswith("n"):
        body = compact[:-1]
        syllable_to_digit = {
            "ni":"0", "we":"1", "wa":"1", "te":"2", "tu":"2",
            "se":"3", "na":"4", "le":"5", "lu":"5", "nu":"6",
            "me":"7", "mu":"7", "pe":"8", "pi":"8", "je":"9", "jo":"9",
        }
        if body and len(body) % 2 == 0:
            pairs = [body[i:i + 2] for i in range(0, len(body), 2)]
            if all(pair in syllable_to_digit for pair in pairs):
                return "".join(syllable_to_digit[pair] for pair in pairs)
    return source
