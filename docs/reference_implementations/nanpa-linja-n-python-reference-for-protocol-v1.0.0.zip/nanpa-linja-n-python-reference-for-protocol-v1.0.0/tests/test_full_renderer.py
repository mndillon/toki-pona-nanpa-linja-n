from __future__ import annotations

import unittest
from pathlib import Path

from PIL import Image

from nanpa_linja_n import NanpaLinjaN

ROOT = Path(__file__).resolve().parents[1]
TALLY_CP = 0xF199E
MANUAL_CENTERS_56 = {
    "nasinNanpa": 118.000,
    "linjaPona": 92.804,
    "linjaSike": 91.196,
    "nasinSitelenPuMono": 94.612,
    "linjaLipamanka": 121.000,
}
MANUAL_TOPS_56 = {
    "nasinNanpa": 73.0,
    # Current canonical JS applies manifest manualTallySmallFontLiftPx=1.
    "linjaPona": 59.0,
    "linjaSike": 60.0,
    "nasinSitelenPuMono": 62.0,
    "linjaLipamanka": 77.0,
}
UCSUR_TALLY_FONTS = ("sitelenSeliKiwen", "fairfaxHd", "fairfaxPonaHd")


class FullRendererTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.n = NanpaLinjaN(project_root=ROOT)

    def test_mixed_document_surface(self) -> None:
        plan = self.n.build_full_render_plan('mi toki e ni: [jan pona,,] 123.45 "Hello"')
        roles = {r.font_role for r in plan.runs}
        self.assertTrue({"word", "cartouche", "number", "literal"}.issubset(roles))
        self.assertEqual(1, plan.line_count)

        canvas = self.n.render_to_canvas('jan [pona,,] 123.45')
        self.assertGreater(canvas.width, 0)
        self.assertGreater(canvas.height, 0)
        self.assertIsNotNone(canvas.plan)
        self.assertEqual(b"\x89PNG\r\n\x1a\n", self.n.render_full_to_png('jan [pona,,] 123.45')[:8])
        self.assertTrue(self.n.render_to_svg('jan [pona,,] 123.45').startswith("<svg"))
        self.assertTrue(self.n.render_to_pdf('jan [pona,,] 123.45').startswith(b"%PDF-"))

    def test_manual_tallies_never_enter_font_run_and_match_js_horizontal_geometry(self) -> None:
        for font, expected_center in MANUAL_CENTERS_56.items():
            with self.subTest(font=font):
                plan = self.n.build_full_render_plan("[jan pona,,]", {"font": font, "fontSize": 56})
                self.assertEqual(1, len(plan.runs))
                run = plan.runs[0]
                self.assertNotIn(TALLY_CP, run.render_codepoints)
                self.assertNotIn(TALLY_CP, run.canonical_codepoints)
                self.assertEqual((0, 2), run.manual_tallies)
                self.assertEqual(1, len(run.tally_groups))
                tg = run.tally_groups[0]
                local_center = tg.center_x_px - run.x_px
                self.assertAlmostEqual(expected_center, local_center, places=3)
                self.assertEqual(2, len(tg.stroke_centers_px))
                # The two synthetic strokes straddle the owning glyph center.
                self.assertAlmostEqual(
                    tg.center_x_px,
                    sum(tg.stroke_centers_px) / 2.0,
                    places=6,
                )
                local_top = tg.top_y_px - run.y_px
                self.assertAlmostEqual(MANUAL_TOPS_56[font], local_top, places=3)

    def test_ucsur_tally_fonts_keep_tally_codepoint(self) -> None:
        for font in UCSUR_TALLY_FONTS:
            with self.subTest(font=font):
                run = self.n.build_full_render_plan("[jan pona,,]", {"font": font, "fontSize": 56}).runs[0]
                self.assertIn(TALLY_CP, run.render_codepoints)
                self.assertEqual((), run.tally_groups)

    def test_linja_pona_small_font_lift_is_vertical_only(self) -> None:
        base = self.n.build_full_render_plan(
            "[jan pona,,]",
            {"font": "linjaPona", "fontSize": 56, "parser": {"manualTallySmallFontLiftPx": 0, "manualTallySmallFontMaxPx": 144}},
        ).runs[0].tally_groups[0]
        lifted = self.n.build_full_render_plan(
            "[jan pona,,]",
            {"font": "linjaPona", "fontSize": 56},
        ).runs[0].tally_groups[0]
        self.assertAlmostEqual(base.center_x_px, lifted.center_x_px, places=6)
        self.assertAlmostEqual(base.top_y_px - 1, lifted.top_y_px, places=6)
        self.assertAlmostEqual(base.bottom_y_px - 1, lifted.bottom_y_px, places=6)

        # Above the manifest threshold, the lift is suppressed.
        base_large = self.n.build_full_render_plan(
            "[jan pona,,]",
            {"font": "linjaPona", "fontSize": 145, "parser": {"manualTallySmallFontLiftPx": 0, "manualTallySmallFontMaxPx": 144}},
        ).runs[0].tally_groups[0]
        configured_large = self.n.build_full_render_plan(
            "[jan pona,,]",
            {"font": "linjaPona", "fontSize": 145},
        ).runs[0].tally_groups[0]
        self.assertAlmostEqual(base_large.top_y_px, configured_large.top_y_px, places=6)

    def test_low_level_operations(self) -> None:
        ast = self.n.parse_input("jan [pona] 123")
        self.assertEqual("document", ast.type)
        plan = self.n.build_full_render_plan("jan [pona] 123")
        word = next(r for r in plan.runs if r.font_role == "word")
        self.assertGreater(self.n.render_run_to_new_canvas(word).width, 0)
        self.assertGreater(self.n.render_text_to_new_canvas("jan pona").width, 0)
        target = Image.new("RGBA", (400, 200), (0, 0, 0, 0))
        self.assertIs(target, self.n.render_text_to_canvas(target, 5, 5, "jan pona"))
        lines = ((0xF1911, 0xF1954), (0xF196C,))
        self.assertGreater(self.n.render_ucsur_to_new_canvas(lines).width, 0)
        target2 = Image.new("RGBA", (400, 200), (0, 0, 0, 0))
        self.assertIs(target2, self.n.render_ucsur_to_canvas(target2, 5, 5, lines))
        self.assertGreater(len(self.n.to_vector_document("jan [pona,,] 123.45").elements), 0)


if __name__ == "__main__":
    unittest.main()
