from __future__ import annotations

import unittest
from pathlib import Path

from PIL import Image

from nanpa_linja_n import NanpaLinjaN

ROOT = Path(__file__).resolve().parents[1]
TALLY_CP = 0xF199E
MANUAL_CENTERS_56 = {
    "nasinNanpa": 118.000,
    "linjaPona": 92.804,
    "linjaSike": 91.196,
    "nasinSitelenPuMono": 94.612,
    "linjaLipamanka": 121.000,
}
MANUAL_TOPS_56 = {
    "nasinNanpa": 74.0,
    # Current canonical JS applies manifest manualTallySmallFontLiftPx=1.
    "linjaPona": 59.0,
    "linjaSike": 60.0,
    "nasinSitelenPuMono": 62.0,
    "linjaLipamanka": 77.0,
}
UCSUR_TALLY_FONTS = ("sitelenSeliKiwen", "fairfaxHd", "fairfaxPonaHd")


class FullRendererTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.n = NanpaLinjaN(project_root=ROOT)

    def test_mixed_document_surface(self) -> None:
        plan = self.n.build_full_render_plan('mi toki e ni: [jan pona,,] 123.45 "Hello"')
        roles = {r.font_role for r in plan.runs}
        self.assertTrue({"word", "cartouche", "number", "literal"}.issubset(roles))
        self.assertEqual(1, plan.line_count)

        canvas = self.n.render_to_canvas('jan [pona,,] 123.45')
        self.assertGreater(canvas.width, 0)
        self.assertGreater(canvas.height, 0)
        self.assertIsNotNone(canvas.plan)
        self.assertEqual(b"\x89PNG\r\n\x1a\n", self.n.render_full_to_png('jan [pona,,] 123.45')[:8])
        self.assertTrue(self.n.render_to_svg('jan [pona,,] 123.45').startswith("<svg"))
        self.assertTrue(self.n.render_to_pdf('jan [pona,,] 123.45').startswith(b"%PDF-"))

    def test_manual_tallies_never_enter_font_run_and_match_js_horizontal_geometry(self) -> None:
        for font, expected_center in MANUAL_CENTERS_56.items():
            with self.subTest(font=font):
                plan = self.n.build_full_render_plan("[jan pona,,]", {"font": font, "fontSize": 56})
                self.assertEqual(1, len(plan.runs))
                run = plan.runs[0]
                self.assertNotIn(TALLY_CP, run.render_codepoints)
                self.assertNotIn(TALLY_CP, run.canonical_codepoints)
                self.assertEqual((0, 2), run.manual_tallies)
                self.assertEqual(1, len(run.tally_groups))
                tg = run.tally_groups[0]
                local_center = tg.center_x_px - run.x_px
                self.assertAlmostEqual(expected_center, local_center, places=3)
                self.assertEqual(2, len(tg.stroke_centers_px))
                # The two synthetic strokes straddle the owning glyph center.
                self.assertAlmostEqual(
                    tg.center_x_px,
                    sum(tg.stroke_centers_px) / 2.0,
                    places=6,
                )
                local_top = tg.top_y_px - run.y_px
                self.assertAlmostEqual(MANUAL_TOPS_56[font], local_top, places=3)

    def test_ucsur_tally_fonts_keep_tally_codepoint(self) -> None:
        for font in UCSUR_TALLY_FONTS:
            with self.subTest(font=font):
                run = self.n.build_full_render_plan("[jan pona,,]", {"font": font, "fontSize": 56}).runs[0]
                self.assertIn(TALLY_CP, run.render_codepoints)
                self.assertEqual((), run.tally_groups)

    def test_linja_pona_small_font_lift_is_vertical_only(self) -> None:
        base = self.n.build_full_render_plan(
            "[jan pona,,]",
            {"font": "linjaPona", "fontSize": 56, "parser": {"manualTallySmallFontLiftPx": 0, "manualTallySmallFontMaxPx": 144}},
        ).runs[0].tally_groups[0]
        lifted = self.n.build_full_render_plan(
            "[jan pona,,]",
            {"font": "linjaPona", "fontSize": 56},
        ).runs[0].tally_groups[0]
        self.assertAlmostEqual(base.center_x_px, lifted.center_x_px, places=6)
        self.assertAlmostEqual(base.top_y_px - 1, lifted.top_y_px, places=6)
        self.assertAlmostEqual(base.bottom_y_px - 1, lifted.bottom_y_px, places=6)

        # Above the manifest threshold, the lift is suppressed.
        base_large = self.n.build_full_render_plan(
            "[jan pona,,]",
            {"font": "linjaPona", "fontSize": 145, "parser": {"manualTallySmallFontLiftPx": 0, "manualTallySmallFontMaxPx": 144}},
        ).runs[0].tally_groups[0]
        configured_large = self.n.build_full_render_plan(
            "[jan pona,,]",
            {"font": "linjaPona", "fontSize": 145},
        ).runs[0].tally_groups[0]
        self.assertAlmostEqual(base_large.top_y_px, configured_large.top_y_px, places=6)

    def test_synthetic_te_to_corner_brackets_for_legacy_fonts(self) -> None:
        # linja pona / linja sike declare cornerBracketMode=synthetic because
        # their legacy font inputs do not contain U+300C/U+300D.  The Python
        # renderer must mirror the canonical browser renderer instead of
        # passing a replacement/tofu glyph to the font.
        for font in ("linjaPona", "linjaSike"):
            with self.subTest(font=font):
                plan = self.n.build_full_render_plan("te tomo to", {"font": font, "fontSize": 56, "paddingPx": 18})
                self.assertEqual((0x300C,), plan.runs[0].canonical_codepoints)
                self.assertEqual((0x300C,), plan.runs[0].render_codepoints)
                self.assertEqual((0x300D,), plan.runs[-1].canonical_codepoints)
                self.assertEqual((0x300D,), plan.runs[-1].render_codepoints)
                self.assertNotIn(0xFFFD, plan.runs[0].render_codepoints)
                self.assertNotIn(0xFFFD, plan.runs[-1].render_codepoints)
                self.assertEqual(21, plan.runs[0].width_px)
                self.assertEqual(43, plan.runs[0].height_px)
                self.assertEqual(21, plan.runs[-1].width_px)
                self.assertEqual(43, plan.runs[-1].height_px)

                left = self.n.render_to_canvas("te", {"font": font, "fontSize": 56, "paddingPx": 0}).image.getchannel("A")
                right = self.n.render_to_canvas("to", {"font": font, "fontSize": 56, "paddingPx": 0}).image.getchannel("A")
                lb = left.getbbox(); rb = right.getbbox()
                self.assertIsNotNone(lb); self.assertIsNotNone(rb)
                assert lb is not None and rb is not None

                # U+300C is a top-left corner: its top arm is wider than its
                # bottom row. U+300D is the inverse bottom-right corner.
                def row_ink(alpha, y, x0, x1):
                    return sum(1 for x in range(x0, x1) if alpha.getpixel((x, y)) > 32)

                self.assertGreater(row_ink(left, lb[1], lb[0], lb[2]), row_ink(left, lb[3] - 1, lb[0], lb[2]))
                self.assertGreater(row_ink(right, rb[3] - 1, rb[0], rb[2]), row_ink(right, rb[1], rb[0], rb[2]))

                svg = self.n.render_to_svg("te tomo to", {"font": font, "fontSize": 56})
                self.assertIn("<path", svg)

    def test_special_glyph_matrix_and_zz_ideographic_space(self) -> None:
        # Cross-font coverage for the special direct glyphs that numeric-only
        # goldens do not exercise.  zz is intentionally an inkless one-em
        # ideographic-space cell; te/to must remain visible and never become
        # replacement/tofu glyphs.
        for info in self.n.list_fonts():
            font = info.key
            with self.subTest(font=font):
                plan = self.n.build_full_render_plan("te to zz", {"font": font, "fontSize": 56, "paddingPx": 0})
                self.assertEqual(3, len(plan.runs))
                left, right, space = plan.runs
                self.assertEqual((0x300C,), left.canonical_codepoints)
                self.assertEqual((0x300D,), right.canonical_codepoints)
                self.assertNotIn(0xFFFD, left.render_codepoints)
                self.assertNotIn(0xFFFD, right.render_codepoints)
                self.assertNotIn("\ufffd", left.render_text)
                self.assertNotIn("\ufffd", right.render_text)
                self.assertEqual("literal", space.font_role)
                self.assertEqual("\u3000", space.render_text)
                self.assertEqual(56, space.width_px)
                self.assertIsNone(self.n.render_to_canvas("zz", {"font": font, "fontSize": 56, "paddingPx": 0}).image.getchannel("A").getbbox())
                self.assertIsNotNone(self.n.render_to_canvas("te", {"font": font, "fontSize": 56, "paddingPx": 0}).image.getchannel("A").getbbox())
                self.assertIsNotNone(self.n.render_to_canvas("to", {"font": font, "fontSize": 56, "paddingPx": 0}).image.getchannel("A").getbbox())

    def test_linja_lipamanka_deterministic_jaki_ko_adapter(self) -> None:
        # The production manifest sets deterministicAlternates=true for jaki/ko.
        # Canonical JS therefore feeds the Latin aliases to linja lipamanka
        # instead of direct UCSUR so the alternate selection is deterministic.
        plan = self.n.build_full_render_plan("jaki ko", {"font": "linjaLipamanka", "fontSize": 56})
        self.assertEqual(["jaki", "ko"], [r.render_text for r in plan.runs])
        self.assertEqual([tuple(map(ord, "jaki")), tuple(map(ord, "ko"))], [r.render_codepoints for r in plan.runs])

        cartouche = self.n.build_full_render_plan("[jaki ko]", {"font": "linjaLipamanka", "fontSize": 56}).runs[0]
        self.assertEqual("[jaki ko]", cartouche.render_text)
        self.assertEqual(tuple(map(ord, "[jaki ko]")), cartouche.render_codepoints)

    def test_low_level_run_rerender_preserves_measured_semantics(self) -> None:
        # Raw Unicode must remain raw-exact on a second-stage run render; it must
        # not acquire the synthetic te/to behavior used for parsed ASCII aliases.
        raw_options = {"font": "linjaPona", "fontSize": 56, "paddingPx": 0}
        raw_run = self.n.build_full_render_plan("U+300C", raw_options).runs[0]
        raw_canvas = self.n.render_run_to_new_canvas(raw_run, raw_options)
        self.assertEqual((raw_run.width_px, raw_run.height_px), (raw_canvas.width, raw_canvas.height))

        # Interpreted unknown text is a literal-font run, and cartouche/number
        # runs retain the measured crop/padding when rendered independently.
        unknown_options = {
            "font": "linjaPona", "fontSize": 56, "paddingPx": 0,
            "parser": {"interpretDoubleQuotesAsTeTo": True, "showUnknownText": True},
        }
        unknown_run = next(r for r in self.n.build_full_render_plan('"hello"', unknown_options).runs if r.unrecognized)
        unknown_canvas = self.n.render_run_to_new_canvas(unknown_run, unknown_options)
        self.assertEqual((unknown_run.width_px, unknown_run.height_px), (unknown_canvas.width, unknown_canvas.height))

        for source in ("[jan pona]", "123"):
            with self.subTest(source=source):
                run = self.n.build_full_render_plan(source, raw_options).runs[0]
                canvas = self.n.render_run_to_new_canvas(run, raw_options)
                self.assertEqual((run.width_px, run.height_px), (canvas.width, canvas.height))

    def test_low_level_operations(self) -> None:
        ast = self.n.parse_input("jan [pona] 123")
        self.assertEqual("document", ast.type)
        plan = self.n.build_full_render_plan("jan [pona] 123")
        word = next(r for r in plan.runs if r.font_role == "word")
        self.assertGreater(self.n.render_run_to_new_canvas(word).width, 0)
        self.assertGreater(self.n.render_text_to_new_canvas("jan pona").width, 0)
        target = Image.new("RGBA", (400, 200), (0, 0, 0, 0))
        self.assertIs(target, self.n.render_text_to_canvas(target, 5, 5, "jan pona"))
        lines = ((0xF1911, 0xF1954), (0xF196C,))
        self.assertGreater(self.n.render_ucsur_to_new_canvas(lines).width, 0)
        target2 = Image.new("RGBA", (400, 200), (0, 0, 0, 0))
        self.assertIs(target2, self.n.render_ucsur_to_canvas(target2, 5, 5, lines))
        self.assertGreater(len(self.n.to_vector_document("jan [pona,,] 123.45").elements), 0)


if __name__ == "__main__":
    unittest.main()
