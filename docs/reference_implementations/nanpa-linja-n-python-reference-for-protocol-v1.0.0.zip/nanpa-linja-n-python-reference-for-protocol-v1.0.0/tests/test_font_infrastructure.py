from __future__ import annotations
import json, tempfile, unittest, zipfile
from pathlib import Path
from nanpa_linja_n.font_registry import load_font_manifest
from nanpa_linja_n.font_adapters import adapt_numeric_cartouche
from nanpa_linja_n import NanpaParser
from nanpa_linja_n.font_regression import _load_cases, _parse_case, _display_codepoints_for_case

OPTS={
    'mode':'uniform','mixedStyle':'short','relaxedNanpaLinjanParsing':True,
    'relaxedNanpaLinjanRendering':True,'nanpaColonParsing':True,
    'nanpaColonRendering':True,'enableHexParsing':True,'enableBinaryParsing':True,
    'numericMode':'uniform'
}

class FontInfrastructureTests(unittest.TestCase):
    def test_legacy_numeric_adapter_is_ascii(self):
        parsed=NanpaParser.parseNumber('123.45',OPTS)
        self.assertIsInstance(parsed,dict)
        run=adapt_numeric_cartouche(parsed['codepoints'],'linja-pona-legacy-v1',{})
        self.assertTrue(run.legacy_ascii)
        self.assertTrue(run.text.isascii())
        self.assertTrue(run.text.startswith('[_nanpa'))
        self.assertTrue(run.text.endswith('_nanpa]'))

    def test_identity_adapter_preserves_canonical_stream(self):
        parsed=NanpaParser.parseNumber('#ABCDEF',OPTS)
        run=adapt_numeric_cartouche(parsed['codepoints'],'identity',{})
        self.assertFalse(run.legacy_ascii)
        self.assertEqual([ord(ch) for ch in run.text], parsed['codepoints'])


    def test_font_golden_matrix_has_full_and_abbreviated_pairs(self):
        root=Path(__file__).resolve().parents[1]
        cases=_load_cases(root)
        self.assertEqual(len(cases),16)
        self.assertEqual(sum(not c.get('abbreviateNumericCartouches',False) for c in cases),8)
        self.assertEqual(sum(bool(c.get('abbreviateNumericCartouches',False)) for c in cases),8)

    def test_abbreviation_shortens_semantic_head_cartouches(self):
        root=Path(__file__).resolve().parents[1]
        cases={c['id']:c for c in _load_cases(root)}
        for case_id in ('decimal-56-abbr','date-56-abbr','time-56-abbr','telephone-56-abbr','hex-56-abbr','binary-56-abbr'):
            case=cases[case_id]
            parsed=_parse_case(case)
            full=list(parsed['codepoints'])
            abbreviated=_display_codepoints_for_case(parsed,case)
            self.assertLess(len(abbreviated),len(full),case_id)
            self.assertEqual(abbreviated[0],full[0],case_id)
            self.assertEqual(abbreviated[-1],full[-1],case_id)
            self.assertEqual(abbreviated[1],full[1],case_id)

    def test_manifest_zip_bundle_layout(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); bundle=root/'resources'/'fonts.zip'; bundle.parent.mkdir(parents=True)
            manifest={'schema':2,'pairs':[{
                'fontKey':'x','rev':'1','baseFamily':'A','companionFamily':'B',
                'baseFilename':'a.otf','companionFilename':'b.otf',
                'baseUrl':'./fonts/a.otf','companionUrl':'./fonts/b.otf'
            }], 'supportFonts': {'literalText': {'family': 'Patrick Hand', 'filename': 'p.ttf', 'format': 'truetype'}}}
            with zipfile.ZipFile(bundle, 'w') as zf:
                zf.writestr('fonts/preloaded-font-pairs.manifest.json', json.dumps(manifest))
                zf.writestr('fonts/a.otf', b'x')
                zf.writestr('fonts/b.otf', b'y')
                zf.writestr('fonts/p.ttf', b'z')
            loaded=load_font_manifest(root)
            self.assertTrue(loaded.pairs[0].base.path.exists())
            self.assertTrue(loaded.pairs[0].companion.path.exists())
            self.assertIsNotNone(loaded.support_font('literalText'))
            self.assertTrue(loaded.support_font('literalText').path.exists())

    def test_bundle_is_required_for_default_loading(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            legacy=(root/'fonts'); legacy.mkdir(parents=True)
            (legacy/'preloaded-font-pairs.manifest.json').write_text(json.dumps({'schema':2,'pairs':[]}))
            with self.assertRaises(FileNotFoundError):
                load_font_manifest(root, required=True)
            self.assertIsNone(load_font_manifest(root, required=False))

if __name__=='__main__': unittest.main()
