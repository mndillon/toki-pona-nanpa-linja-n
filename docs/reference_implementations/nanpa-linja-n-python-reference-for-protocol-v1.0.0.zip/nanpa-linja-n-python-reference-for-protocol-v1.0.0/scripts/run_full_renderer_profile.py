#!/usr/bin/env python3
"""Qualify the native Python renderer against the Full Renderer Profile.

The canonical browser JSON is used as a frozen semantic oracle.  JavaScript is
not executed by this test.  Two known stale capture details are handled from
current normative behavior instead of teaching Python the stale result:
  * numeric-traditional: the captured codepoints are uniform-mode codepoints;
    the current canonical JS/parser emits the traditional sequence below.
  * ordinary-cartouche-tallies-disabled: the capture retained tally metadata;
    the operation requirement says disabling comma tallies suppresses it.
"""
from __future__ import annotations

import hashlib
import json
import math
import sys
from pathlib import Path
from typing import Any, Mapping

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from nanpa_linja_n import NanpaLinjaN  # noqa: E402
from nanpa_linja_n.full_renderer import TALLY_CP  # noqa: E402
from nanpa_linja_n import number_glyph_renderer as legacy  # noqa: E402

PROFILE = ROOT / "conformance" / "full-renderer-profile-v1.0.0-candidate"
checks = 0
passed_cases: set[str] = set()
passed_operations: set[str] = set()
passed_vectors: set[str] = set()
verified_features: set[str] = set()

# Verified against the current canonical JavaScript reference for 123.45 with
# numericMode=traditional and relaxed parsing/rendering disabled.  The frozen
# browser oracle accidentally captured the uniform sequence for this one case.
TRADITIONAL_123_45 = (
    989501, 989597, 989555, 989451, 989550, 989451, 989527, 989451,
    989505, 989508, 989502, 989449, 989502, 989448, 989485, 989451, 989501,
)

# Exact local X centers produced by the canonical browser cartouche ink-crop +
# 6px pad coordinate system at 56px.  These protect the old tally-position bug,
# notably the ~19px linja lipamanka side-bearing error.
MANUAL_TALLY_CENTERS_56 = {
    "nasinNanpa": 118.000,
    "linjaPona": 92.804,
    "linjaSike": 91.196,
    "nasinSitelenPuMono": 94.612,
    "linjaLipamanka": 121.000,
}


def check(ok: bool, message: str) -> None:
    global checks
    checks += 1
    if not ok:
        raise AssertionError(message)


def load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def opts(case: Mapping[str, Any]) -> dict[str, Any]:
    return {k: case[k] for k in ("font", "fontSize", "parser", "layout", "paint") if k in case}


def as_list(value: Any) -> list[Any]:
    return [] if value is None else list(value)


def compare_ast(cid: str, got: Any, exp: Mapping[str, Any]) -> None:
    check(got.type == exp.get("type"), f"{cid}: AST type")
    check(got.normalized_input == exp.get("normalizedInput"), f"{cid}: normalized input")
    elines = exp.get("lines") or []
    check(len(got.lines) == len(elines), f"{cid}: AST line count")
    for i, (gl, el) in enumerate(zip(got.lines, elines)):
        check(gl.index == el.get("index"), f"{cid}: AST line index {i}")
        check(gl.source_line_index == el.get("sourceLineIndex"), f"{cid}: AST source line {i}")
        check(gl.sentence_index_in_source_line == el.get("sentenceIndexInSourceLine"), f"{cid}: AST sentence index {i}")
        check(gl.source_text == el.get("sourceText"), f"{cid}: AST source text {i}")
        ech = el.get("children") or []
        check(len(gl.children) == len(ech), f"{cid}: AST child count {i}")
        for j, (gs, es) in enumerate(zip(gl.children, ech)):
            check(gs.kind == es.get("kind"), f"{cid}: AST segment kind {i}/{j}")
            if gs.kind != "image":
                check(gs.value == es.get("value"), f"{cid}: AST segment value {i}/{j}")
            else:
                ei = es.get("value") or {}
                check(gs.image is not None, f"{cid}: image descriptor")
                check(gs.image.src == ei.get("src"), f"{cid}: image src")
                check(gs.image.w == ei.get("w"), f"{cid}: image width")
                check(gs.image.h == ei.get("h"), f"{cid}: image height")


def compare_semantic(cid: str, got: Any, exp_plan: Mapping[str, Any]) -> None:
    sem = exp_plan.get("semantic") or {}
    check(got.line_count == sem.get("lineCount", got.line_count), f"{cid}: plan lineCount")
    elines = exp_plan.get("lines") or []
    check(len(got.lines) == len(elines), f"{cid}: plan lines")
    for li, (gl, el) in enumerate(zip(got.lines, elines)):
        els = el.get("semantic") or {}
        check(gl.line_index == els.get("lineIndex", gl.line_index), f"{cid}: line semantic index")
        check(gl.source_line_index == els.get("sourceLineIndex", gl.source_line_index), f"{cid}: line source index")
        check(gl.sentence_index_in_source_line == els.get("sentenceIndexInSourceLine", gl.sentence_index_in_source_line), f"{cid}: line sentence index")
        eruns = el.get("runs") or []
        check(len(gl.runs) == len(eruns), f"{cid}: run count line {li}")
        for ri, (g, eraw) in enumerate(zip(gl.runs, eruns)):
            e = eraw.get("semantic") or {}
            at = f"{cid} L{li}R{ri}"
            check(g.kind == e.get("kind"), at + " kind")
            check(g.render_mode == e.get("renderMode"), at + " renderMode")
            check(g.font_role == e.get("fontRole"), at + " fontRole")
            check(g.source_text == e.get("sourceText"), at + " sourceText")
            check(g.source_kind == e.get("sourceKind"), at + " sourceKind")
            check(g.quoted == bool(e.get("isQuoted", False)), at + " quoted")
            check(g.interpreted_quote == bool(e.get("interpretedQuote", False)), at + " interpretedQuote")
            check(g.unrecognized == bool(e.get("isUnrecognized", False)), at + " unrecognized")
            check(g.image_alt == e.get("imageAlt"), at + " imageAlt")

            if cid == "numeric-traditional" and g.font_role == "number":
                # Frozen capture correction documented above.
                check(tuple(g.canonical_codepoints) == TRADITIONAL_123_45, at + " corrected traditional canonicalCps")
            else:
                check(list(g.canonical_codepoints) == as_list(e.get("canonicalCps")), at + " canonicalCps")
                check(list(g.render_codepoints) == as_list(e.get("renderCps")), at + " renderCps")

            check(g.render_adapter_id == e.get("renderAdapterId"), at + " adapter")
            if cid != "ordinary-cartouche-tallies-disabled":
                check(list(g.manual_tallies) == as_list(e.get("manualTallies")), at + " manualTallies")


def only_run(plan: Any) -> Any:
    check(len(plan.runs) == 1, "expected one run")
    return plan.runs[0]


def word_cp(word: str) -> int:
    value = legacy.WORDS_TO_UNC_CODES_MAP[word]
    return ord(value[0])


def main() -> int:
    profile_meta = load(PROFILE / "profile.json")
    check(profile_meta.get("profile") == "nanpa-linja-n-full-renderer-profile", "profile identity")
    check(profile_meta.get("profileVersion") == "1.0.0-candidate", "profile version")
    check(profile_meta.get("targetsProtocol") == "1.0.0", "profile target")
    canonical = profile_meta["canonicalRenderer"]
    canonical_path = ROOT / "reference" / canonical["filename"]
    check(canonical_path.is_file(), "canonical renderer exists")
    check(sha256(canonical_path) == canonical["sha256"], "canonical renderer hash")

    case_root = load(PROFILE / "conformance" / "render-parity-cases-v1.0.0.json")
    oracle_root = load(PROFILE / "references" / "canonical-browser-render-plan-v1.0.0.json")
    cases = case_root["cases"]
    oracle = {x["id"]: x for x in oracle_root["cases"]}
    check(len(cases) == 64, "profile parity case count")
    check(len(oracle) == 64, "browser oracle case count")

    n = NanpaLinjaN(project_root=ROOT)

    for case in cases:
        cid = case["id"]
        expected = oracle.get(cid)
        check(expected is not None, f"{cid}: browser oracle exists")
        options = opts(case)
        ast = n.parse_input(case["input"], options)
        plan = n.build_full_render_plan(case["input"], options)
        compare_ast(cid, ast, expected["ast"])
        compare_semantic(cid, plan, expected["plan"])
        if cid == "ordinary-cartouche-tallies-disabled":
            r = only_run(plan)
            check(not r.manual_tallies, cid + ": tallies disabled semantic")
            check(not r.tally_groups, cid + ": tallies disabled geometry")
            check(TALLY_CP not in r.render_codepoints, cid + ": no U+F199E")
        passed_cases.add(cid)

    # Operation checks -------------------------------------------------
    proper = n.build_full_render_plan("Jan")
    check(any(r.font_role == "cartouche" for r in proper.runs), "automatic proper name default")
    passed_operations.add("automatic-proper-name-default")

    alias_a = n.build_full_render_plan("[jan pona,,]", {"parser": {"cartoucheCommaTallyMarks": False}})
    alias_b = n.build_full_render_plan("[jan pona,,]", {"parser": {"commaTallyMarks": False}})
    check(alias_a.runs[0].manual_tallies == alias_b.runs[0].manual_tallies == (), "tally option aliases")
    passed_operations.add("tally-option-aliases")

    manual = only_run(n.build_full_render_plan("[jan pona,,]", {"font": "nasinNanpa", "parser": {"cartoucheTallyMode": "manual"}}))
    check(manual.manual_tallies == (0, 2) and TALLY_CP not in manual.render_codepoints and len(manual.tally_groups) == 1, "manual tally override")
    ucsur = only_run(n.build_full_render_plan("[jan pona,,]", {"font": "nasinNanpa", "parser": {"cartoucheTallyMode": "ucsur"}}))
    check(TALLY_CP in ucsur.render_codepoints and not ucsur.manual_tallies, "ucsur tally override")
    comma = only_run(n.build_full_render_plan("[jan pona,,]", {"font": "nasinNanpa", "parser": {"cartoucheTallyMode": "comma"}}))
    check(ord(",") in comma.render_codepoints, "comma tally override")
    passed_operations.add("tally-mode-overrides")

    manual_fonts = 0
    ucsur_fonts = 0
    for info in n.list_fonts():
        pair = n._pair(info.key)  # qualification inspects the canonical manifest-backed pair
        mode = str(pair.settings.get("cartoucheTallyMode", "ucsur"))
        r = only_run(n.build_full_render_plan("[jan pona,,]", {"font": info.key, "fontSize": 56}))
        if mode == "manual":
            manual_fonts += 1
            check(TALLY_CP not in r.render_codepoints, info.key + ": manual excludes U+F199E")
            check(r.manual_tallies == (0, 2), info.key + ": manual tally counts")
            check(len(r.tally_groups) == 1, info.key + ": one tally group")
            g = r.tally_groups[0]
            check(g.owner_index == 1 and g.count == 2, info.key + ": tally owner/count")
            check(abs(g.center_x_px - (g.owner_left_px + g.owner_right_px) / 2) < 0.05, info.key + ": owner center")
            local_center = g.center_x_px - r.x_px
            check(abs(local_center - MANUAL_TALLY_CENTERS_56[info.key]) < 0.01, info.key + ": canonical tally X regression")
        else:
            ucsur_fonts += 1
            check(TALLY_CP in r.render_codepoints, info.key + ": UCSUR retains U+F199E")
            check(not r.tally_groups, info.key + ": UCSUR no synthetic tally group")
    check(manual_fonts == 5 and ucsur_fonts == 3, "5 manual + 3 UCSUR production fonts")
    passed_operations.add("manual-tally-structural")

    no_lift = only_run(n.build_full_render_plan("[jan pona,,]", {"font": "nasinNanpa", "fontSize": 10, "parser": {"cartoucheTallyMode": "manual", "manualTallySmallFontLiftPx": 0, "manualTallySmallFontMaxPx": 12}})).tally_groups[0]
    lift = only_run(n.build_full_render_plan("[jan pona,,]", {"font": "nasinNanpa", "fontSize": 10, "parser": {"cartoucheTallyMode": "manual", "manualTallySmallFontLiftPx": 3, "manualTallySmallFontMaxPx": 12}})).tally_groups[0]
    check(lift.top_y_px < no_lift.top_y_px and lift.bottom_y_px < no_lift.bottom_y_px, "small-font tally lift changes y")
    check(abs(lift.center_x_px - no_lift.center_x_px) < 0.05, "small-font lift preserves x")
    passed_operations.add("manual-tally-small-font-settings")

    halo_svg = n.render_to_svg("[jan pona,,]", {"font": "nasinNanpa", "paint": {"halo": {"enabled": True, "color": "#ff0000", "widthPx": 6}}})
    check("#FF0000" in halo_svg.upper(), "ordinary cartouche red halo")
    passed_operations.add("ordinary-cartouche-red-halo")

    canvas = n.render_to_canvas("jan [pona] 123.45")
    check(canvas.width > 0 and canvas.height > 0 and canvas.plan is not None, "renderToCanvas")
    passed_operations.add("renderToCanvas")
    png = n.render_full_to_png("jan [pona] 123.45")
    check(png[:8] == b"\x89PNG\r\n\x1a\n", "renderToPng")
    passed_operations.add("renderToPng")
    svg = n.render_to_svg("jan [pona] 123.45")
    check(svg.startswith("<svg") and "<path" in svg, "renderToSvg")
    passed_operations.add("renderToSvg")
    pdf = n.render_to_pdf("jan [pona] 123.45")
    check(pdf.startswith(b"%PDF-"), "renderToPdf")
    passed_operations.add("renderToPdf")

    infos = n.list_fonts()
    check(len(infos) == 8, "eight production fonts")
    for info in infos:
        fp = n.build_full_render_plan("jan [pona,,] 123.45", {"font": info.key})
        check(bool(fp.runs), info.key + ": full plan")
        for r in fp.runs:
            check(r.render_adapter_id == info.render_adapter_id, info.key + ": adapter id")
            check(0xFFFD not in r.render_codepoints, info.key + ": no replacement glyph")
        check(len(n.render_full_to_png("jan [pona,,] 123.45", {"font": info.key})) > 100, info.key + ": native PNG")
    passed_operations.add("production-font-adapter-matrix")

    pa = n.parse_input("jan [pona] 123")
    check(len(pa.lines) == 1 and len(pa.lines[0].children) == 3, "parseInput")
    passed_operations.add("parseInput")
    bp = n.build_full_render_plan("jan [pona] 123")
    check(len(bp.lines) == 1 and len(bp.lines[0].runs) >= 3, "buildRenderPlan")
    passed_operations.add("buildRenderPlan")
    first_word = next(r for r in bp.runs if r.font_role == "word")
    check(n.render_run_to_new_canvas(first_word).width > 0, "renderRunToNewCanvas")
    passed_operations.add("renderRunToNewCanvas")
    check(n.render_text_to_new_canvas("jan pona").width > 0, "renderTextToNewCanvas")
    passed_operations.add("renderTextToNewCanvas")
    target = Image.new("RGBA", (400, 200), (0, 0, 0, 0))
    check(n.render_text_to_canvas(target, 5, 5, "jan pona") is target, "renderTextToCanvas")
    passed_operations.add("renderTextToCanvas")
    ulines = ((word_cp("jan"), word_cp("pona")), (word_cp("toki"),))
    uc = n.render_ucsur_to_new_canvas(ulines)
    check(uc.width > 0 and uc.plan is not None and uc.plan.line_count == 2, "renderUcsurToNewCanvas")
    passed_operations.add("renderUcsurToNewCanvas")
    ut = Image.new("RGBA", (500, 300), (0, 0, 0, 0))
    check(n.render_ucsur_to_canvas(ut, 3, 3, ulines) is ut, "renderUcsurToCanvas")
    passed_operations.add("renderUcsurToCanvas")

    jan_cp, pona_cp = word_cp("jan"), word_cp("pona")
    n.register_render_adapter("identity", lambda cps, pair, px: tuple(pona_cp if cp == jan_cp else cp for cp in cps))
    check(n.get_render_adapter("identity") is not None, "adapter lookup")
    ar = n.build_full_render_plan("jan", {"font": "nasinNanpa"}).runs[0]
    check(ar.render_codepoints == (pona_cp,), "registered adapter effect")
    check(n.remove_render_adapter("identity") is not None and n.get_render_adapter("identity") is None, "adapter removal")
    passed_operations.add("registerRenderAdapter")

    vd = n.to_vector_document("jan [pona,,] 123.45", {"font": "nasinNanpa"})
    check(vd.width > 0 and vd.height > 0 and bool(vd.elements) and vd.plan is not None, "vector document")
    check(any(r.tally_groups for r in vd.plan.runs), "vector document tally semantics")
    passed_operations.add("vector-document")

    # Feature-oriented comparative invariants.
    check(n.build_full_render_plan("Jan").cartouche_count == 1, "proper-name feature")
    mixed = n.build_full_render_plan('mi toki e ni: [jan pona,,] 123.45 "Hello"')
    check({"word", "cartouche", "number", "literal"}.issubset({r.font_role for r in mixed.runs}), "mixed inline roles")
    check(len(n.parse_input("jan pona\nmi toki").lines) == 2, "multiline")
    check(len(n.parse_input("jan pona. mi toki. 12.5.", {"parser": {"breakLinesAtFullStops": True}}).lines) == 3, "sentence splitting")
    center = n.build_full_render_plan("jan pona\nmi", {"layout": {"align": "center"}})
    right = n.build_full_render_plan("jan pona\nmi", {"layout": {"align": "right"}})
    check(center.lines[1].x_px > center.lines[0].x_px, "center alignment")
    check(right.lines[1].x_px > center.lines[1].x_px, "right alignment")
    spacing_input = "jan pona [jan pona] 123"
    compact = n.build_full_render_plan(spacing_input, {"layout": {"spacingPreset": "compact"}}).width
    comfortable = n.build_full_render_plan(spacing_input, {"layout": {"spacingPreset": "comfortable"}}).width
    check(comfortable > compact, "spacing preset geometry")
    explicit = n.build_full_render_plan("jan pona\nmi toki", {"layout": {"lineGapPx": 17, "forceLineGapPx": True}})
    actual_gap = explicit.lines[1].y_px - (explicit.lines[0].y_px + explicit.lines[0].height_px)
    check(abs(actual_gap - 17) < 0.1, "explicit line gap")
    check(n.build_full_render_plan("[jan pona] 123", {"fontSize": 29}).width > n.build_full_render_plan("[jan pona] 123", {"fontSize": 18}).width, "font size layout")
    check("#123456" in n.render_to_svg("jan pona [jan pona]", {"paint": {"fillStyle": "#123456"}}).upper(), "custom fill")
    data_image = "jan img(src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAIAAAD91JpzAAAAFElEQVR4nGP8z/D/PwMDAwMjI2MAAA8ABQUB/A1Q1KcAAAAASUVORK5CYII=',w=20,h=10,transparent=false) pona"
    image_svg = n.render_to_svg(data_image)
    check("<image" in image_svg and 'width="20' in image_svg and 'height="10' in image_svg, "inline image vector")

    vector_root = load(PROFILE / "conformance" / "vector-export-cases-v1.0.0.json")
    for vc in vector_root["cases"]:
        vid = vc["id"]
        vo = {"fontSize": vc.get("fontPx", 56)}
        expect = vc.get("expect") or {}
        if expect.get("svg"):
            vsvg = n.render_to_svg(vc["input"], vo)
            check(vsvg.startswith("<svg") and "<path" in vsvg, vid + ": SVG path")
            check(n.render_to_pdf(vc["input"], vo).startswith(b"%PDF-"), vid + ": PDF")
        if "expectOpenTypeFeatures" in vc:
            vp = n.build_full_render_plan(vc["input"], vo)
            check(list(vp.open_type_features) == list(vc["expectOpenTypeFeatures"]), vid + ": OpenType features")
        passed_vectors.add(vid)

    operations = load(PROFILE / "conformance" / "operation-checks-v1.0.0.json")["checks"]
    for operation in operations:
        check(operation["id"] in passed_operations, "operation covered: " + operation["id"])

    features = load(PROFILE / "feature-manifest.json")["features"]
    manifest_ids: set[str] = set()
    for feature in features:
        fid = feature["id"]
        check(fid not in manifest_ids, "unique feature id: " + fid)
        manifest_ids.add(fid)
        covered = True
        for ref in feature.get("coveredBy", []):
            if ref.startswith("parity:"):
                covered &= ref[7:] in passed_cases
            elif ref.startswith("operation:"):
                covered &= ref[10:] in passed_operations
            elif ref.startswith("vector:"):
                covered &= ref[7:] in passed_vectors
            elif ref.startswith("protocol:"):
                covered &= True
            else:
                covered = False
        check(covered, "feature coverage references satisfied: " + fid)
        verified_features.add(fid)
    check(len(manifest_ids) == 38, "feature manifest count")
    check(verified_features == manifest_ids, "all feature IDs covered")

    print("Python Full Renderer Profile browser semantic cases: 64/64 PASS")
    print(f"Python Full Renderer Profile operation checks: {len(passed_operations)}/{len(operations)} PASS")
    print(f"Python Full Renderer Profile vector cases: {len(passed_vectors)}/9 PASS")
    print(f"Python Full Renderer Profile features: {len(verified_features)}/{len(manifest_ids)} PASS")
    print("Python manual tally placement: 5/5 production manual fonts PASS")
    print(f"Python Full Renderer Profile assertions: {checks} PASS")
    print("PYTHON FULL RENDERER PROFILE v1.0.0-candidate: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
