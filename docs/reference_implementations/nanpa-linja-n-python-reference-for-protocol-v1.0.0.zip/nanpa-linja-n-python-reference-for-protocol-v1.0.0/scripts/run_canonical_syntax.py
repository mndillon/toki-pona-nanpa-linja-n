#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from nanpa_linja_n import NanpaLinjaN

CORPUS=ROOT/'conformance'/'canonical-syntax-v1.0.1-phase1'/'cases.json'
REFERENCE=ROOT/'reference'/'renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js'

def cps(values):
    return [int(v[2:],16) if isinstance(v,str) and v.startswith('U+') else int(v) for v in (values or [])]

def fail_case(errors,cid,msg):
    errors.append(f'{cid}: {msg}')

def main()->int:
    data=json.loads(CORPUS.read_text(encoding='utf-8'))
    authority=data['authority']['sha256']
    actual=hashlib.sha256(REFERENCE.read_bytes()).hexdigest()
    errors=[]
    if actual!=authority:
        errors.append(f'authority hash mismatch: got {actual} want {authority}')
    n=NanpaLinjaN.create()
    passed=0
    for case in data['cases']:
        cid=case['id']
        try:
            parser={'mode':case['rendererMode']}
            plan=n.build_full_render_plan(case['input'],{'font':'nasinNanpa','parser':parser})
            local=[]
            if 'expectedNormalizedInput' in case and plan.ast.normalized_input!=case['expectedNormalizedInput']:
                local.append(f'normalizedInput got {plan.ast.normalized_input!r} want {case["expectedNormalizedInput"]!r}')
            if 'expectedRuns' in case:
                got=[list(r.canonical_codepoints) for r in plan.runs]
                want=[cps(x) for x in case['expectedRuns']]
                if got!=want:local.append(f'runs canonical cps got {got} want {want}')
            else:
                if len(plan.runs)!=1:
                    local.append(f'run count got {len(plan.runs)} want 1')
                elif plan.runs:
                    r=plan.runs[0]
                    want=cps(case.get('expectedCanonicalCodepoints'))
                    if list(r.canonical_codepoints)!=want:local.append(f'canonical cps got {list(r.canonical_codepoints)} want {want}')
                    if 'expectedSourceText' in case and (r.source_text or '')!=case['expectedSourceText']:local.append(f'sourceText got {r.source_text!r} want {case["expectedSourceText"]!r}')
                    if 'expectedFontRole' in case and r.font_role!=case['expectedFontRole']:local.append(f'fontRole got {r.font_role!r} want {case["expectedFontRole"]!r}')
                    if 'expectedRenderText' in case:
                        want_text=''.join(chr(x) for x in cps([case['expectedRenderText']])) if str(case['expectedRenderText']).startswith('U+') else case['expectedRenderText']
                        if r.render_text!=want_text:local.append(f'renderText got {r.render_text!r} want {want_text!r}')
            if local:
                for msg in local:fail_case(errors,cid,msg)
            else:passed+=1
        except Exception as exc:
            fail_case(errors,cid,f'{type(exc).__name__}: {exc}')
    adapter_pass=0
    for case in data.get('fontAdapterCases',[]):
        cid=case['id']
        try:
            plan=n.build_full_render_plan(case['input'],{'font':case['font'],'parser':{'mode':'sitelen-pona-ascii-extended'}})
            local=[]
            if len(plan.runs)!=1:local.append(f'run count got {len(plan.runs)} want 1')
            elif plan.runs:
                r=plan.runs[0]
                if 'expectedRenderText' in case and r.render_text!=case['expectedRenderText']:local.append(f'renderText got {r.render_text!r} want {case["expectedRenderText"]!r}')
                if 'expectedRenderCodepoints' in case and list(r.render_codepoints)!=cps(case['expectedRenderCodepoints']):local.append(f'render cps got {list(r.render_codepoints)} want {cps(case["expectedRenderCodepoints"])}')
                if case.get('mustDifferFromCanonicalCodepoints') and list(r.render_codepoints)==list(r.canonical_codepoints):local.append('render cps did not differ from canonical cps')
            if local:
                for msg in local:fail_case(errors,cid,msg)
            else:adapter_pass+=1
        except Exception as exc:fail_case(errors,cid,f'{type(exc).__name__}: {exc}')
    print(f'Canonical syntax cases: {passed}/{len(data["cases"])} PASS')
    print(f'Canonical font-adapter cases: {adapter_pass}/{len(data.get("fontAdapterCases",[]))} PASS')
    if errors:
        print(f'FAILURES ({len(errors)}):')
        for e in errors:print(' -',e)
        return 1
    print('CANONICAL SYNTAX + FONT ADAPTER CONFORMANCE PASS')
    return 0

if __name__=='__main__':raise SystemExit(main())
