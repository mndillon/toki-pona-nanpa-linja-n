#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from nanpa_linja_n import NanpaLinjaN
from nanpa_linja_n.full_renderer import CARTOUCHE_START,CARTOUCHE_END

CORPUS=ROOT/'conformance'/'full-renderer-canonical-v1.0.1'/'cases.json'

def compare_ast(g,w):
    errs=[]
    if g.type!=w.get('type'):errs.append(f'AST type got {g.type!r} want {w.get("type")!r}')
    if g.normalized_input!=w.get('normalizedInput'):errs.append(f'AST normalizedInput got {g.normalized_input!r} want {w.get("normalizedInput")!r}')
    wl=w.get('lines',[])
    if len(g.lines)!=len(wl):return errs+[f'AST line count got {len(g.lines)} want {len(wl)}']
    for i,(gl,x) in enumerate(zip(g.lines,wl)):
        checks=[('index',gl.index,x.get('index')),('sourceLineIndex',gl.source_line_index,x.get('sourceLineIndex')),('sentenceIndexInSourceLine',gl.sentence_index_in_source_line,x.get('sentenceIndexInSourceLine')),('sourceText',gl.source_text,x.get('sourceText'))]
        for k,a,b in checks:
            if a!=b:errs.append(f'AST line[{i}] {k}: got {a!r} want {b!r}')
        wc=x.get('children',[])
        if len(gl.children)!=len(wc):errs.append(f'AST line[{i}] child count got {len(gl.children)} want {len(wc)}');continue
        for j,(gs,ws) in enumerate(zip(gl.children,wc)):
            if gs.kind!=ws.get('kind'):errs.append(f'AST line[{i}] child[{j}] kind got {gs.kind!r} want {ws.get("kind")!r}')
            for attr,key in [('value','value'),('open_quote','openQuote'),('close_quote','closeQuote')]:
                if ws.get(key) is not None and getattr(gs,attr)!=ws.get(key):errs.append(f'AST line[{i}] child[{j}] {key} got {getattr(gs,attr)!r} want {ws.get(key)!r}')
            wi=ws.get('image')
            if wi is not None:
                if gs.image is None:errs.append(f'AST line[{i}] child[{j}] missing image');continue
                for attr,key in [('src','src'),('w','w'),('h','h'),('alt','alt'),('valign','valign'),('wriggle','wriggle'),('transparent','transparent')]:
                    if getattr(gs.image,attr)!=wi.get(key):errs.append(f'AST line[{i}] child[{j}] image.{key} got {getattr(gs.image,attr)!r} want {wi.get(key)!r}')
    return errs

def compare_run(g,w,font,random_cps):
    errs=[]
    checks=[('kind',g.kind,w.get('kind')),('renderMode',g.render_mode,w.get('renderMode')),('fontRole',g.font_role,w.get('fontRole')),('sourceText',g.source_text or '',w.get('sourceText') or ''),('sourceKind',g.source_kind or '',w.get('sourceKind') or ''),('renderAdapterId',g.render_adapter_id,w.get('renderAdapterId') or ''),('isQuoted',g.quoted,bool(w.get('isQuoted'))),('interpretedQuote',g.interpreted_quote,bool(w.get('interpretedQuote'))),('isUnrecognized',g.unrecognized,bool(w.get('isUnrecognized'))),('manualTallies',list(g.manual_tallies),w.get('manualTallies') or []),('numericCartouche',g.numeric_cartouche,bool(w.get('isNumericCartouche')))]
    if not random_cps:
        checks.extend([('canonicalCps',list(g.canonical_codepoints),w.get('canonicalCps') or []),('renderCps',list(g.render_codepoints),w.get('renderCps') or [])])
        full=[CARTOUCHE_START,*g.canonical_codepoints,CARTOUCHE_END] if (g.font_role in ('cartouche','number') or g.numeric_cartouche) else []
        if w.get('canonicalFullCps'):checks.append(('canonicalFullCps',full,w['canonicalFullCps']))
    if w.get('imageAlt') is not None:checks.append(('imageAlt',g.image_alt,w.get('imageAlt')))
    for key,a,b in checks:
        if a!=b:errs.append(f'{key}: got {a!r} want {b!r}')
    return errs

def main()->int:
    data=json.loads(CORPUS.read_text(encoding='utf-8'))
    if data.get('caseCount')!=len(data.get('cases',[])):
        print(f'corpus count mismatch: declared {data.get("caseCount")} actual {len(data.get("cases",[]))}')
        return 1
    authority=ROOT/data['authority']['path']
    actual=hashlib.sha256(authority.read_bytes()).hexdigest()
    if actual!=data['authority']['sha256']:
        print(f'authority hash mismatch: got {actual} want {data["authority"]["sha256"]}')
        return 1
    n=NanpaLinjaN.create();passed=0;failures=[]
    for case in data['cases']:
        cid=case['id'];local=[]
        try:
            if not case['oracle'].get('ok'):
                local.append(f'oracle generation failed: {case["oracle"].get("error")!r}')
            else:
                plan=n.build_full_render_plan(case['input'],{'font':case['font'],'parser':case['parser']})
                if case.get('compareAst'):local.extend(compare_ast(plan.ast,case['oracle']['ast']))
                wr=case['oracle']['runs']
                if len(plan.runs)!=len(wr):local.append(f'run count got {len(plan.runs)} want {len(wr)}')
                else:
                    for i,(g,w) in enumerate(zip(plan.runs,wr)):
                        local.extend(f'run[{i}] {x}' for x in compare_run(g,w,case['font'],bool(case.get('randomCps'))))
        except Exception as exc:local.append(f'{type(exc).__name__}: {exc}')
        if local:failures.append((cid,local))
        else:passed+=1
    print(f'Canonical full-renderer semantic corpus: {passed}/{len(data["cases"])} PASS')
    if failures:
        print(f'FAILED CASES ({len(failures)}):')
        for cid,errs in failures:
            print(f'[{cid}]')
            for e in errs:print(' -',e)
        return 1
    print('CANONICAL FULL-RENDERER CONFORMANCE PASS')
    return 0

if __name__=='__main__':raise SystemExit(main())
