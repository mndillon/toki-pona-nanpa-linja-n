#!/usr/bin/env python3
from __future__ import annotations
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REFERENCE_JS = ROOT / 'reference' / 'renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js'
MANIFEST = ROOT / 'fonts' / 'preloaded-font-pairs.manifest.json'

commands = [
    [sys.executable, '-m', 'compileall', '-q', str(ROOT / 'nanpa_linja_n'), str(ROOT / 'tests'), str(ROOT / 'scripts')],
    [sys.executable, str(ROOT / 'scripts' / 'run_regression.py')],
    [sys.executable, str(ROOT / 'scripts' / 'run_ast_to_text.py')],
    [sys.executable, '-m', 'unittest', 'discover', '-s', str(ROOT / 'tests'), '-p', 'test_*.py'],
]

if REFERENCE_JS.exists() and shutil.which('node'):
    commands.append([sys.executable, str(ROOT / 'scripts' / 'run_differential.py'), str(REFERENCE_JS)])
elif not REFERENCE_JS.exists():
    print(f'differential: SKIP ({REFERENCE_JS.relative_to(ROOT)} not found)')
else:
    print('differential: SKIP (node not found)')

if MANIFEST.exists():
    commands.append([sys.executable, str(ROOT / 'scripts' / 'run_font_regression.py')])
else:
    print(f'font regression: SKIP ({MANIFEST.relative_to(ROOT)} not found)')

PROFILE = ROOT / 'conformance' / 'full-renderer-profile-v1.0.0-candidate' / 'profile.json'
if PROFILE.exists():
    commands.append([sys.executable, str(ROOT / 'scripts' / 'run_full_renderer_profile.py')])
else:
    print(f'full renderer profile: SKIP ({PROFILE.relative_to(ROOT)} not found)')

for cmd in commands:
    print('+', ' '.join(map(str, cmd)), flush=True)
    result = subprocess.run(cmd, cwd=ROOT)
    if result.returncode:
        raise SystemExit(result.returncode)

print('ALL CONFIGURED PYTHON TESTS PASS')
