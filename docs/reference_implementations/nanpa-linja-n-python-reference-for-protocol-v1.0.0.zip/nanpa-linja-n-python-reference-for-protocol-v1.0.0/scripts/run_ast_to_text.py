#!/usr/bin/env python3
from __future__ import annotations

from dataclasses import replace
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from nanpa_linja_n import (  # noqa: E402
    DocumentAst,
    DocumentLine,
    DocumentSegment,
    NanpaLinjaN,
    ast_to_text,
)


def check(condition: bool, label: str, detail: str = "") -> None:
    if not condition:
        suffix = f": {detail}" if detail else ""
        raise AssertionError(f"FAIL {label}{suffix}")
    print(f"PASS {label}")


def replace_first_segment(ast: DocumentAst, kind: str, **changes) -> DocumentAst:
    for line_index, line in enumerate(ast.lines):
        for segment_index, segment in enumerate(line.children):
            if segment.kind != kind:
                continue
            children = list(line.children)
            children[segment_index] = replace(segment, **changes)
            lines = list(ast.lines)
            lines[line_index] = replace(line, children=tuple(children))
            return replace(ast, lines=tuple(lines))
    raise AssertionError(f"segment kind not found: {kind}")


def main() -> None:
    nanpa = NanpaLinjaN.create()
    passed = 0

    source = 'jan   pona\t[ jan  pona,, ]\n\n“toki  pona”'
    ast = nanpa.parse_input(source)
    round_trip = nanpa.ast_to_text(ast)
    check(round_trip == source, "ast_to_text exact whitespace/blank-line/quote round-trip", repr(round_trip))
    passed += 1

    check(nanpa.astToText(ast) == source, "astToText JavaScript-style alias")
    passed += 1

    check(ast_to_text(ast) == source, "module-level ast_to_text")
    passed += 1

    split_source = 'jan pona. mi toki.\npona.'
    split_ast = nanpa.parse_input(split_source, parser_options={"breakLinesAtFullStops": True})
    check(len(split_ast.lines) == 3 and nanpa.ast_to_text(split_ast) == split_source,
          "breakLinesAtFullStops physical-line reconstruction")
    passed += 1

    edited = replace_first_segment(ast, "bracket", value=" jan  suno,, ")
    edited_text = nanpa.ast_to_text(edited)
    expected_edited = 'jan   pona\t[ jan  suno,, ]\n\n“toki  pona”'
    check(edited_text == expected_edited, "edited bracket serialization", repr(edited_text))
    passed += 1

    quote_edited = replace_first_segment(ast, "quote", value="Hello", open_quote='"', close_quote='"')
    quote_text = nanpa.ast_to_text(quote_edited)
    check(quote_text.endswith('"Hello"'), "edited quote content/delimiters", repr(quote_text))
    passed += 1

    image_source = "img(src='icon.png',w='20',h='30',alt='sample',valign='middle',wriggle=5,transparent=false)"
    image_ast = nanpa.parse_input(image_source)
    image_text = nanpa.ast_to_text(image_ast)
    image_round_trip = nanpa.parse_input(image_text)
    before = image_ast.lines[0].children[0].image
    after = image_round_trip.lines[0].children[0].image
    check(before == after, "image descriptor semantic round-trip", image_text)
    passed += 1

    bad_ast = DocumentAst(
        "document",
        "",
        {},
        (DocumentLine(0, 0, 0, "", (DocumentSegment("unsupported"),)),),
    )
    try:
        nanpa.ast_to_text(bad_ast)
    except TypeError:
        ok = True
    else:
        ok = False
    check(ok, "unsupported AST segment rejection")
    passed += 1

    print(f"Python ast_to_text regression: {passed}/8 PASS")

    png = nanpa.render_full_to_png(edited_text, {"font": "linjaPona", "fontSize": 56})
    check(png.startswith(b"\x89PNG\r\n\x1a\n"), "edited AST -> text -> PNG render integration")
    print("Python ast_to_text render integration: 1/1 PASS")


if __name__ == "__main__":
    main()
