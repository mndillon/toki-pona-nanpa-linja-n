#!/usr/bin/env python3
import hashlib,json,re,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def sha(p):
 h=hashlib.sha256(); h.update(Path(p).read_bytes()); return h.hexdigest()
def check(ok,msg,errs):
 print(('PASS ' if ok else 'FAIL ')+msg)
 if not ok: errs.append(msg)

def main():
 e=[]
 checks={
  'reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js':'6bfcb77e5177eec4d923bbd24d60dbac211e574b62e128e6dbfc07f8e859d220',
  'resources/fonts.zip':'50c0375469508e806d2a6bb1ce555fa81adb72f73a497ddf7d26e4150671b209',
  'conformance/parser-renderer-profile-v1.2.0.json':'62d96529a5d857d6e146afc29433caf8709e9e28803e95d37ff3085468080a0f',
  'conformance/parser-renderer-regression-v1.2.0.json':'f926ed22ee2788bad6061e7f8df78a577b4ef03f75f348d9739225bbe3e10c89',
  'rendering/production-font-pairs.manifest.json':'d8021c7e83d33b776a1e68c70d6adea11956ae88e5fff1baf67926dd1d6833f6',
 }
 for rel,want in checks.items():
  p=ROOT/rel; check(p.is_file() and sha(p)==want,f'authority SHA-256 {rel}',e)
 prof=json.loads((ROOT/'conformance/parser-renderer-profile-v1.2.0.json').read_text())
 check(len(prof.get('nanpaParserSmokeCases',[]))==16,'Parser-Renderer-Profile-v1.2 has 16 smoke cases',e)
 reg=json.loads((ROOT/'conformance/parser-renderer-regression-v1.2.0.json').read_text())
 check(len(reg.get('cases',[]))==24,'Protocol v1.2 parser regression has 24 cases',e)
 syn=json.loads((ROOT/'conformance/canonical-syntax-v1.0.1-phase1/cases.json').read_text())
 check(len(syn.get('cases',[]))==28,'canonical syntax has 28 cases',e)
 full=json.loads((ROOT/'conformance/full-renderer-canonical-v1.2.0/cases.json').read_text())
 check(len(full.get('cases',[]))==254,'canonical full renderer v1.2 has 254 cases',e)
 plan=json.loads((ROOT/'fixtures/render-facade-plan-goldens-v1.1.0.json').read_text()); cases=plan.get('cases') or plan.get('logicalCases') or []
 check(len(cases)==16,'Production-Font-Profile-v1.1 render-plan fixture has 16 logical cases',e)
 man=json.loads((ROOT/'rendering/production-font-pairs.manifest.json').read_text()); pairs=man.get('pairs') or man.get('fonts') or man.get('fontPairs') or []
 check(len(pairs)==8,'production manifest has 8 font pairs',e)
 with zipfile.ZipFile(ROOT/'resources/fonts.zip') as z:
  embedded=z.read('fonts/preloaded-font-pairs.manifest.json')
 check(hashlib.sha256(embedded).hexdigest()=='d8021c7e83d33b776a1e68c70d6adea11956ae88e5fff1baf67926dd1d6833f6','supplied fonts.zip embedded production manifest',e)
 main='\n'.join(p.read_text(errors='ignore') for p in (ROOT/'src/main/java').rglob('*.java'))
 check(not re.search(r'"ss1[234]"',main),'no active ss12/ss13/ss14 string literal in production Java',e)
 check('/Subtype /Image' not in (ROOT/'src/main/java/com/nanpalinjan/FullRenderer.java').read_text(),'FullRenderer source has no raster PDF Image XObject marker',e)
 doc=(ROOT/'src/main/java/com/nanpalinjan/DocumentParser.java').read_text()
 check('mixed-csp-unicode' in doc and 'canonicalizeCspUnicodeInputLine' in doc,'direct CSP/UCSUR canonicalization is wired',e)
 check('isBackslashEscapedAt' in doc,'odd/even backslash quote helper is wired',e)
 line=(ROOT/'src/main/java/com/nanpalinjan/DocumentLine.java').read_text()
 check('canonicalSourceText' in line and 'sourceEncoding' in line,'AST exposes canonical source metadata',e)
 renderer=(ROOT/'src/main/java/com/nanpalinjan/FullRenderer.java').read_text()
 check('forceOrdinary' in renderer,'v1.2 force-ordinary cartouche handling is wired',e)
 check('Protocol v1.2' in renderer,'ordinary full-stop v1.2 fallback is wired',e)
 check('<version>1.2.0</version>' in (ROOT/'pom.xml').read_text(),'Maven package version targets 1.2.0',e)
 total=20
 print(f'Java v1.2 release source/authority checks: {total-len(e)}/{total} PASS' + ('' if not e else f'; failures={len(e)}'))
 return 1 if e else 0
if __name__=='__main__': sys.exit(main())
