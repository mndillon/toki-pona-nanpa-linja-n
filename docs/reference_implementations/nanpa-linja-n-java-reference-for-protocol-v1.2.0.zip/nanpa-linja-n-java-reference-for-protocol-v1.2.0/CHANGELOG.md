# Changelog

## 1.2.0

- Updated Java document parser/renderer semantics to Protocol v1.2.0.
- Added ordinary full-stop → middle-dot parsing with numeric precedence.
- Added protected `breakLinesAtFullStops` semantics.
- Added direct CSP/UCSUR canonicalization and line source metadata.
- Added odd/even quote-backslash handling.
- Added force-ordinary `""` cartouche behavior.
- Added 24-case v1.2 parser regression and 254-case v1.2 canonical renderer corpus.
- Updated canonical JavaScript authority and supplied font resources.
- Retained frozen Core-v1 numeric implementation and Production-Font-Profile-v1.1 behavior.
