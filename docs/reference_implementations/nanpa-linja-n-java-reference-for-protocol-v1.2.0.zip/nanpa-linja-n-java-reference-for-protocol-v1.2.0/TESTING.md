# Java v1.2.0 testing

Requirement: **JDK 21**.

## Compile without executing regressions

```bash
TMP="$(mktemp -d)"
find src/main/java src/test/java -name '*.java' | sort > "$TMP/sources.txt"
javac --release 21 -encoding UTF-8 -d "$TMP/classes" @"$TMP/sources.txt"
```

## Focused Protocol v1.2 parser regression

```bash
java -Djava.awt.headless=true -cp "$TMP/classes" \
  com.nanpalinjan.V12ParserRegression \
  resources/fonts.zip \
  conformance/parser-renderer-regression-v1.2.0.json
```

Expected corpus size: **24 cases**.

## Protocol v1.2 profile/vector checks

```bash
java -Djava.awt.headless=true -cp "$TMP/classes" \
  com.nanpalinjan.V12ProfileRegression \
  resources/fonts.zip \
  conformance/parser-renderer-profile-v1.2.0.json
```

## Canonical full renderer

```bash
java -Djava.awt.headless=true -cp "$TMP/classes" \
  com.nanpalinjan.CanonicalFullRendererRegression \
  resources/fonts.zip \
  conformance/full-renderer-canonical-v1.2.0/cases.json
```

## Complete non-fail-fast suite

```bash
./tools/run_java_regression.sh
```

The complete report is written to `test-output/java-regression-report.txt`.

The package generated in this workflow was build-validated but the full regression suite was intentionally not executed.
