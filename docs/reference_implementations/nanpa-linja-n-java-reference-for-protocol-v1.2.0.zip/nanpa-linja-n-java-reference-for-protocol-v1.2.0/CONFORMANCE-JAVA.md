# Java reference conformance — Protocol v1.2.0

The Java reference targets:

- nanpa-linja-n **Protocol v1.2.0**;
- frozen Core-v1 corpus v1.0.2 / 1030-check baseline;
- Parser-Renderer-Profile-v1.2;
- Production-Font-Profile-v1.1;
- current canonical JavaScript authority SHA-256 `6bfcb77e5177eec4d923bbd24d60dbac211e574b62e128e6dbfc07f8e859d220`.

The v1.2 document-profile delta consists of ordinary full-stop semantics, protected optional sentence splitting, direct CSP/UCSUR canonicalization with source metadata, quote-backslash parity, and force-ordinary cartouches. Frozen Core numeric source behavior is retained.

Normative/current corpora shipped with this package include:

- 320 frozen parser cases / 1030 Core checks;
- 28 canonical syntax cases;
- 5 production adapter cases;
- 24 Protocol-v1.2 parser/renderer cases;
- 254 Protocol-v1.2 canonical full-renderer cases;
- Production-Font-Profile-v1.1 render-plan/vector/font fixtures.

## Full qualification

```bash
./tools/run_java_regression.sh
```

The runner attempts every configured suite and reports all failures at the end.

## Validation status of this generated archive

The archive was compiled and statically validated but was **not** subjected to the complete regression suite during generation. This avoids claiming qualification that was not performed. Full conformance status should be taken from a subsequent `run_java_regression.sh` result.
