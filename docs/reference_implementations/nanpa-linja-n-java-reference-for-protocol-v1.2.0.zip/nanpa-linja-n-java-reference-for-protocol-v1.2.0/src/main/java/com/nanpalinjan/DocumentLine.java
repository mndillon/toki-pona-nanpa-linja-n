package com.nanpalinjan;
import java.util.*;
public record DocumentLine(
        int index,
        int sourceLineIndex,
        int sentenceIndexInSourceLine,
        String sourceText,
        String canonicalSourceText,
        String sourceEncoding,
        List<DocumentSegment> children) {
    public DocumentLine { children=children==null?List.of():List.copyOf(children); }
    /** Compatibility constructor retained for Protocol-v1.1 callers. */
    public DocumentLine(int index,int sourceLineIndex,int sentenceIndexInSourceLine,String sourceText,List<DocumentSegment> children){
        this(index,sourceLineIndex,sentenceIndexInSourceLine,sourceText,null,null,children);
    }
}
