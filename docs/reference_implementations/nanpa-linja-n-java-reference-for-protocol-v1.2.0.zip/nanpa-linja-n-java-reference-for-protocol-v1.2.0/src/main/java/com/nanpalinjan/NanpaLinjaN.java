package com.nanpalinjan;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.nio.file.*;
import java.util.*;

/** High-level Java 21 facade mirroring the canonical JavaScript reference facade. */
public final class NanpaLinjaN implements AutoCloseable {
    public static final String DEFAULT_FONT_KEY = "nasinNanpa";
    public static final float DEFAULT_FONT_SIZE = 56f;

    private final ProductionFontRegistry registry;
    private final ProductionRenderer numericRenderer;
    private final FullRenderer renderer;
    private final Map<String,RenderAdapter> runtimeAdapters=new LinkedHashMap<>();
    private final ProductionFontBundle fontBundle;

    private NanpaLinjaN(ProductionFontRegistry registry, ProductionFontBundle fontBundle) {
        this.registry = registry;this.fontBundle=fontBundle;
        this.numericRenderer = new ProductionRenderer(fontBundle, registry);
        this.renderer = new FullRenderer(numericRenderer,runtimeAdapters);
    }

    public static NanpaLinjaN create() throws Exception {ProductionFontBundle b=ProductionFontBundle.loadDefault();return new NanpaLinjaN(ProductionFontRegistry.load(b),b);}
    /** Existing Path overload retained; the path now identifies fonts.zip or a directory containing it. */
    public static NanpaLinjaN create(Path fontDirectory) throws Exception {ProductionFontBundle b=ProductionFontBundle.load(fontDirectory);return new NanpaLinjaN(ProductionFontRegistry.load(b),b);}
    public static NanpaLinjaN create(Path manifest, Path fontDirectory) throws Exception {ProductionFontBundle b=ProductionFontBundle.load(fontDirectory);return new NanpaLinjaN(ProductionFontRegistry.load(manifest),b);}

    public List<FontPairInfo> listFonts() { return registry.listFonts(); }
    public List<FontPairInfo> fonts() { return listFonts(); }
    public FontPairInfo getFontInfo(String font) { return registry.get(font); }
    public String normalizeFontKey(String font) { return registry.get(font).key(); }

    /** Frozen numeric Core parse operation retained unchanged. */
    public FacadeParseResult parse(String input) { return parse(input,new RenderOptions()); }
    public FacadeParseResult parse(String input, RenderOptions options) {RenderOptions o=options==null?new RenderOptions():options;FontPairInfo pair=registry.get(o.fontKey());ParseResult p=V11Numeric.publicResult(NanpaApi.parseNumber(input,o.parser()),input);return new FacadeParseResult(input,pair.key(),pair,p,p!=null,List.of());}

    /** Full-renderer document AST parser. */
    public ParseResult parseNumber(Object input){return V11Numeric.publicResult(NanpaApi.parseNumber(input,ParseOptions.publicDefaults()),input);}
    public ParseResult parseNumber(Object input,ParseOptions options){ParseOptions p=options==null?ParseOptions.publicDefaults():options;return V11Numeric.publicResult(NanpaApi.parseNumber(input,p),input);}

    public DocumentAst parseInput(String input){return parseInput(input,new RenderOptions());}
    public DocumentAst parseInput(String input,RenderOptions options){RenderOptions o=options==null?new RenderOptions():options;return renderer.parseInput(input,o);}

    /** Convert a full-document AST back into valid nanpa-linja-n source text. */
    public String astToText(DocumentAst ast){return AstTextSerializer.astToText(ast);}
    public String astToText(DocumentAst ast,RenderOptions options){return AstTextSerializer.astToText(ast,options);}

    public RenderPlan buildRenderPlan(String input) throws Exception { return buildRenderPlan(input,new RenderOptions()); }
    public RenderPlan buildRenderPlan(String input, RenderOptions options) throws Exception {RenderOptions o=options==null?new RenderOptions():options;FontPairInfo pair=registry.get(o.fontKey());return renderer.buildPlan(input,pair,o);}

    public Object render(String input, RenderOptions options) throws Exception {RenderOptions o=options==null?new RenderOptions():options;return switch(o.format()){case "canvas","image" -> renderToCanvas(input,o);case "png" -> renderToPng(input,o);case "svg" -> renderToSvg(input,o);case "pdf" -> renderToPdf(input,o);default -> throw new IllegalArgumentException("Unsupported render format: "+o.format());};}

    public CanvasRenderResult renderToCanvas(String input) throws Exception { return renderToCanvas(input,new RenderOptions()); }
    public CanvasRenderResult renderToCanvas(String input, RenderOptions options) throws Exception {RenderOptions o=options==null?new RenderOptions():options;FontPairInfo pair=registry.get(o.fontKey());return renderer.renderCanvas(input,pair,o);}
    public CanvasRenderResult renderToImage(String input, RenderOptions options) throws Exception { return renderToCanvas(input,options); }

    public PngRenderResult renderToPng(String input) throws Exception { return renderToPng(input,new RenderOptions()); }
    public PngRenderResult renderToPng(String input, RenderOptions options) throws Exception {RenderOptions o=options==null?new RenderOptions():options;FontPairInfo pair=registry.get(o.fontKey());return renderer.renderPng(input,pair,o);}

    public SvgRenderResult renderToSvg(String input) throws Exception { return renderToSvg(input,new RenderOptions()); }
    public SvgRenderResult renderToSvg(String input, RenderOptions options) throws Exception {RenderOptions o=options==null?new RenderOptions():options;FontPairInfo pair=registry.get(o.fontKey());return renderer.renderSvg(input,pair,o);}

    public PdfRenderResult renderToPdf(String input) throws Exception { return renderToPdf(input,new RenderOptions()); }
    public PdfRenderResult renderToPdf(String input, RenderOptions options) throws Exception {RenderOptions o=options==null?new RenderOptions():options;FontPairInfo pair=registry.get(o.fontKey());return renderer.renderPdf(input,pair,o);}

    /** Render one semantic/measured run independently. */
    public CanvasRenderResult renderRunToNewCanvas(RenderRun run,RenderOptions options) throws Exception {if(run==null)throw new IllegalArgumentException("run is required");String src=run.sourceText()!=null?run.sourceText():run.renderText();if("cartouche".equals(run.fontRole())&&!run.numericCartouche()&&!src.startsWith("["))src="["+src+"]";return renderToCanvas(src,options);}
    public CanvasRenderResult renderTextToNewCanvas(String input,RenderOptions options)throws Exception{return renderToCanvas(input,options);}
    public BufferedImage renderTextToCanvas(BufferedImage target,int x,int y,String input,RenderOptions options)throws Exception{CanvasRenderResult r=renderToCanvas(input,options);Graphics2D g=target.createGraphics();try{g.drawImage(r.canvas(),x,y,null);}finally{g.dispose();}return target;}
    public CanvasRenderResult renderUcsurToNewCanvas(List<? extends List<Integer>> lines,RenderOptions options)throws Exception{return renderToCanvas(ucsurLines(lines),options==null?new RenderOptions():options.withParser((options==null?new RenderOptions():options).parser().withShowUnknownText(true)));}
    public BufferedImage renderUcsurToCanvas(BufferedImage target,int x,int y,List<? extends List<Integer>>lines,RenderOptions options)throws Exception{CanvasRenderResult r=renderUcsurToNewCanvas(lines,options);Graphics2D g=target.createGraphics();try{g.drawImage(r.canvas(),x,y,null);}finally{g.dispose();}return target;}
    private static String ucsurLines(List<? extends List<Integer>>lines){StringBuilder b=new StringBuilder();for(int i=0;i<lines.size();i++){if(i>0)b.append('\n');for(int cp:lines.get(i))b.appendCodePoint(cp);}return b.toString();}

    /** Runtime extension surface corresponding to registerRenderAdapter. */
    public void registerRenderAdapter(String id,RenderAdapter adapter){if(id==null||id.isBlank()||adapter==null)throw new IllegalArgumentException("adapter id and function are required");runtimeAdapters.put(id,adapter);}
    public RenderAdapter getRenderAdapter(String id){return runtimeAdapters.get(id);}
    public RenderAdapter removeRenderAdapter(String id){return runtimeAdapters.remove(id);}

    public VectorDocument toVectorDocument(String input,RenderOptions options)throws Exception{RenderOptions o=options==null?new RenderOptions():options;return renderer.vectorDocument(input,registry.get(o.fontKey()),o);}

    public void destroy() { runtimeAdapters.clear(); }
    @Override public void close() { destroy(); }
}
