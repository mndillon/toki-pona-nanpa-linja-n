package com.nanpalinjan;

import java.util.*;
import java.util.regex.*;

/** Java port of the canonical renderer's host-independent document segmentation layer. */
final class DocumentParser {
    private DocumentParser(){}
    private static final List<Map.Entry<String,String>> ALIASES=List.of(
            Map.entry("'cartouche-start'","["),Map.entry("'cartouche-end'","]"),
            Map.entry("'zw-joiner'","&"),Map.entry("'stack-joiner'","-"),Map.entry("'nesting-joiner'","+"),
            Map.entry("'ideographic-space'"," zz "),Map.entry("'long-start'","("),Map.entry("'long-end'",")"),
            Map.entry("'left-bracket'"," te "),Map.entry("'right-bracket'"," to "),Map.entry("'middle-dot'","."),
            Map.entry("'colon'",":"),Map.entry("'tally'",","));

    static DocumentAst parse(String input, ParseOptions parser){
        ParseOptions p=parser==null?new ParseOptions():parser;
        String normalized=normalize(input,p);
        List<DocumentLine> lines=new ArrayList<>();
        String[] sourceLines=normalized.split("\\n",-1);
        for(int sourceLineIndex=0;sourceLineIndex<sourceLines.length;sourceLineIndex++){
            List<String> rendered=p.breakLinesAtFullStops()?splitAtFullStops(sourceLines[sourceLineIndex]):List.of(sourceLines[sourceLineIndex]);
            for(int sentence=0;sentence<rendered.size();sentence++){
                String source=rendered.get(sentence);
                CspCanonicalized csp=canonicalizeCspUnicodeInputLine(source,p);
                String parsed=csp.changed()?csp.text():source;
                lines.add(new DocumentLine(lines.size(),sourceLineIndex,sentence,source,
                        csp.changed()?csp.text():null,csp.changed()?"mixed-csp-unicode":null,segments(parsed)));
            }
        }
        return new DocumentAst("document",normalized,p.toMap(),lines);
    }

    static String normalize(String input,ParseOptions p){
        String s=input==null?"":input;
        if(!"standard-sitelen-pona-ascii-core".equals(p.rendererMode()))for(var e:ALIASES)s=s.replace(e.getKey(),e.getValue());
        return s.replace("\r\n","\n").replace('\r','\n');
    }

    static List<DocumentSegment> segments(String line){
        String s=line==null?"":line;List<DocumentSegment> out=new ArrayList<>();int i=0,start=0;
        while(i<s.length()){
            char ch=s.charAt(i);
            if(ch=='['){int j=s.indexOf(']',i+1);if(j<0)break;pushText(out,s,start,i);out.add(DocumentSegment.bracket(s.substring(i+1,j),i,j+1));i=j+1;start=i;continue;}
            if(ch=='"'||ch=='“'){
                char close=ch=='“'?'”':'"';int j=i+1;boolean found=false;
                while(j<s.length()){char cj=s.charAt(j);boolean isClose=cj==close||(ch=='“'&&cj=='"')||(ch=='"'&&cj=='”');if(isClose&&!isBackslashEscapedAt(s,j)){found=true;break;}j++;}
                if(!found)break;pushText(out,s,start,i);out.add(DocumentSegment.quote(s.substring(i+1,j),String.valueOf(ch),String.valueOf(s.charAt(j)),i,j+1));i=j+1;start=i;continue;
            }
            if(s.startsWith("img(",i)){
                int j=i+4,depth=1;Character quote=null;boolean esc=false;
                while(j<s.length()){
                    char cj=s.charAt(j);if(esc){esc=false;j++;continue;}if(cj=='\\'){esc=true;j++;continue;}if(quote!=null){if(cj==quote)quote=null;j++;continue;}if(cj=='"'||cj=='\''){quote=cj;j++;continue;}if(cj=='(')depth++;else if(cj==')'){depth--;if(depth==0)break;}j++;
                }
                if(j>=s.length())break;pushText(out,s,start,i);out.add(DocumentSegment.image(parseImageArgs(s.substring(i+4,j)),i,j+1));i=j+1;start=i;continue;
            }
            i++;
        }
        pushText(out,s,start,s.length());return List.copyOf(out);
    }
    private static void pushText(List<DocumentSegment>out,String s,int a,int b){if(b>a)out.add(DocumentSegment.text(s.substring(a,b),a,b));}

    private static boolean isBackslashEscapedAt(String text,int index){
        int count=0;for(int i=index-1;i>=0&&text.charAt(i)=='\\';i--)count++;return (count&1)==1;
    }

    static List<String> splitAtFullStops(String line){
        String s=line==null?"":line;List<String>out=new ArrayList<>();int start=0,square=0,paren=0,brace=0;char quote=0;
        for(int i=0;i<s.length();i++){
            char ch=s.charAt(i);
            if(quote!=0){boolean close=(quote=='“'&&(ch=='”'||ch=='"'))||(quote=='"'&&(ch=='"'||ch=='”'));if(close&&!isBackslashEscapedAt(s,i))quote=0;continue;}
            if(ch=='"'||ch=='“'){quote=ch;continue;}if(ch=='['){square++;continue;}if(ch==']'){square=Math.max(0,square-1);continue;}if(ch=='('){paren++;continue;}if(ch==')'){paren=Math.max(0,paren-1);continue;}if(ch=='{'){brace++;continue;}if(ch=='}'){brace=Math.max(0,brace-1);continue;}
            if(ch!='.'||square>0||paren>0||brace>0||!sentenceStop(s,i))continue;
            int stop=i+1;while(stop<s.length()&&s.charAt(stop)=='.'&&sentenceStop(s,stop))stop++;out.add(s.substring(start,stop));start=stop;i=stop-1;
        }
        String tail=s.substring(start);if(!tail.trim().isEmpty()||out.isEmpty())out.add(tail);return List.copyOf(out);
    }
    private static boolean sentenceStop(String s,int i){char prev=i>0?s.charAt(i-1):0,next=i+1<s.length()?s.charAt(i+1):0;boolean numeric=Character.isDigit(next)&&(Character.isDigit(prev)||i==0||Character.isWhitespace(prev)||"+-(,:=".indexOf(prev)>=0);return !numeric;}

    private record CspInputToken(String kind,String text){}
    private record CspCanonicalized(boolean changed,String text){}

    private static String cspInputWordForCodepoint(int cp){
        return switch(cp){
            case 0xF1989 -> "ni<"; case 0xF198A -> "ni^"; case 0xF198B -> "ni>"; case 0xF198C -> "sewi^";
            case 0xF19B4,0x300C -> "te"; case 0xF19B5,0x300D -> "to"; case 0x3000 -> "zz";
            default -> ((cp>=0xF1900&&cp<=0xF1988)||(cp>=0xF19A0&&cp<=0xF19A6))?Constants.ALL_CODEPOINT_WORDS.get(cp):null;
        };
    }
    private static CspInputToken cspInputTokenForCodepoint(int cp){
        String word=cspInputWordForCodepoint(cp);if(word!=null)return new CspInputToken("word",word);
        return switch(cp){
            case 0xF1990 -> new CspInputToken("cartoucheStart","["); case 0xF1991 -> new CspInputToken("cartoucheEnd","]");
            case 0xF1992 -> new CspInputToken("ignorableControl",""); case 0xF1993 -> new CspInputToken("deprecatedLongPiStart","");
            case 0xF1994 -> new CspInputToken("deprecatedLongPiExtension",""); case 0xF1995 -> new CspInputToken("joiner","-");
            case 0xF1996 -> new CspInputToken("joiner","+"); case 0xF1997 -> new CspInputToken("longStart","(");
            case 0xF1998 -> new CspInputToken("longEnd",")"); case 0xF1999 -> new CspInputToken("ignorableControl","");
            case 0xF199A -> new CspInputToken("reverseStart","{"); case 0xF199B -> new CspInputToken("reverseEnd","}");
            case 0xF199C -> new CspInputToken("middleDot","."); case 0xF199D -> new CspInputToken("colon",":");
            case 0xF199E -> new CspInputToken("tally",");"); case 0x200D -> new CspInputToken("joiner","&");
            default -> null;
        };
    }
    private static boolean containsRecognizedCspUnicodeInput(String text){
        for(int i=0;i<text.length();){int cp=text.codePointAt(i);if((cp==0x200D||cp==0x3000||cp==0x300C||cp==0x300D||(cp>=0xF1900&&cp<=0xF19FF))&&cspInputTokenForCodepoint(cp)!=null)return true;i+=Character.charCount(cp);}return false;
    }
    private static boolean cspTokenNeedsWordSeparator(CspInputToken left,CspInputToken right){
        if(left==null||right==null)return false;if("word".equals(left.kind())&&"word".equals(right.kind()))return true;
        return Set.of("longEnd","cartoucheEnd","middleDot","tally").contains(left.kind())&&"word".equals(right.kind());
    }
    private static String serializeCspUnicodeTokenRun(List<CspInputToken> input){
        List<CspInputToken> tokens=input.stream().filter(t->!"ignorableControl".equals(t.kind())).toList();if(tokens.isEmpty())return "";
        if("deprecatedLongPiStart".equals(tokens.getFirst().kind())){StringBuilder b=new StringBuilder();CspInputToken prev=null;for(int i=1;i<tokens.size();i++){CspInputToken t=tokens.get(i);if("deprecatedLongPiExtension".equals(t.kind()))continue;if(cspTokenNeedsWordSeparator(prev,t))b.append(' ');b.append(t.text());prev=t;}return "pi("+b+")";}
        StringBuilder b=new StringBuilder();CspInputToken prev=null;for(CspInputToken t:tokens){
            if("deprecatedLongPiExtension".equals(t.kind())){if(!b.isEmpty()&&b.charAt(b.length()-1)!=' ')b.append(' ');prev=null;continue;}
            if("colon".equals(t.kind())){if(!b.isEmpty()&&b.charAt(b.length()-1)!=' '&&b.charAt(b.length()-1)!='[')b.append(' ');b.append(':');prev=t;continue;}
            if(prev!=null&&"colon".equals(prev.kind())){if(!b.isEmpty()&&b.charAt(b.length()-1)!=' ')b.append(' ');}else if(cspTokenNeedsWordSeparator(prev,t)){if(!b.isEmpty()&&b.charAt(b.length()-1)!=' ')b.append(' ');}
            b.append(t.text());prev=t;
        }return b.toString();
    }
    private static boolean cspBoundaryNeedsSpace(String left,String right){
        if(left.isEmpty()||right.isEmpty())return false;int l=left.codePointBefore(left.length()),r=right.codePointAt(0);return cspWordLike(l)&&cspWordLike(r);
    }
    private static boolean cspWordLike(int cp){return Character.isLetterOrDigit(cp)||cp=='_'||cp=='^'||cp=='<'||cp=='>';}
    private static int findProtectedQuotedEnd(String s,int start){
        if(start<0||start>=s.length()||(s.charAt(start)!='"'&&s.charAt(start)!='“'))return -1;char open=s.charAt(start);
        for(int j=start+1;j<s.length();j++){char ch=s.charAt(j);boolean close=(open=='“'&&(ch=='”'||ch=='"'))||(open=='"'&&(ch=='"'||ch=='”'));if(close&&!isBackslashEscapedAt(s,j))return j+1;}return -1;
    }
    private static int findProtectedImgEnd(String s,int start){
        if(start<0||start+4>s.length()||!s.startsWith("img(",start))return -1;int depth=1;char quote=0;boolean escaped=false;
        for(int j=start+4;j<s.length();j++){char ch=s.charAt(j);if(escaped){escaped=false;continue;}if(ch=='\\'){escaped=true;continue;}if(quote!=0){if(ch==quote)quote=0;continue;}if(ch=='"'||ch=='\''){quote=ch;continue;}if(ch=='(')depth++;else if(ch==')'&&--depth==0)return j+1;}return -1;
    }
    private record CspPiece(String kind,String text){}
    private static CspCanonicalized canonicalizeCspUnicodeInputLine(String source,ParseOptions p){
        if(source==null||source.isEmpty()||!containsRecognizedCspUnicodeInput(source))return new CspCanonicalized(false,source==null?"":source);
        List<CspPiece> pieces=new ArrayList<>();boolean interpreted=p.interpretDoubleQuotesAsTeTo();
        for(int i=0;i<source.length();){
            char ch=source.charAt(i);if(!interpreted&&(ch=='"'||ch=='“')){int end=findProtectedQuotedEnd(source,i);if(end>i){pieces.add(new CspPiece("raw",source.substring(i,end)));i=end;continue;}}
            int imageEnd=findProtectedImgEnd(source,i);if(imageEnd>i){pieces.add(new CspPiece("raw",source.substring(i,imageEnd)));i=imageEnd;continue;}
            int cp=source.codePointAt(i);CspInputToken first=cspInputTokenForCodepoint(cp);if(first==null){int n=Character.charCount(cp);pieces.add(new CspPiece("raw",source.substring(i,i+n)));i+=n;continue;}
            List<CspInputToken> tokens=new ArrayList<>();tokens.add(first);int j=i+Character.charCount(cp);while(j<source.length()){int cp2=source.codePointAt(j);CspInputToken t=cspInputTokenForCodepoint(cp2);if(t==null)break;tokens.add(t);j+=Character.charCount(cp2);}String converted=serializeCspUnicodeTokenRun(tokens);if(!converted.isEmpty())pieces.add(new CspPiece("converted",converted));i=j;
        }
        StringBuilder out=new StringBuilder();for(int i=0;i<pieces.size();i++){CspPiece piece=pieces.get(i);if(i>0){CspPiece prev=pieces.get(i-1);if(!prev.kind().equals(piece.kind())&&cspBoundaryNeedsSpace(prev.text(),piece.text())&&!out.isEmpty()&&out.charAt(out.length()-1)!=' ')out.append(' ');}out.append(piece.text());}
        String result=out.toString();return new CspCanonicalized(!result.equals(source),result);
    }

    private static ImageDescriptor parseImageArgs(String arg){
        List<String> parts=splitArgs(arg);String src="",w=null,h=null,alt=null,valign="baseline";double wriggle=8;boolean transparent=true;int start=0;
        if(!parts.isEmpty()&&!parts.getFirst().contains("=")){src=strip(parts.getFirst());start=1;}
        for(int i=start;i<parts.size();i++){String x=parts.get(i);int eq=x.indexOf('=');if(eq<0)continue;String k=x.substring(0,eq).trim(),v=strip(x.substring(eq+1));switch(k){case"src"->src=v;case"w"->w=v;case"h"->h=v;case"alt"->alt=v;case"valign"->valign=v;case"wriggle"->{try{wriggle=Double.parseDouble(v);}catch(Exception ignored){}}case"transparent"->transparent=!v.matches("(?i)false|0|no|off");}}
        return new ImageDescriptor(src,w,h,alt,valign,wriggle,transparent);
    }
    private static List<String> splitArgs(String s){List<String>out=new ArrayList<>();StringBuilder cur=new StringBuilder();Character q=null;boolean esc=false;int depth=0;for(int i=0;i<s.length();i++){char ch=s.charAt(i);if(esc){cur.append(ch);esc=false;continue;}if(ch=='\\'){cur.append(ch);esc=true;continue;}if(q!=null){cur.append(ch);if(ch==q)q=null;continue;}if(ch=='"'||ch=='\''){q=ch;cur.append(ch);continue;}if(ch=='('){depth++;cur.append(ch);continue;}if(ch==')'){if(depth>0)depth--;cur.append(ch);continue;}if(ch==','&&depth==0){out.add(cur.toString().trim());cur.setLength(0);continue;}cur.append(ch);}if(!cur.toString().trim().isEmpty())out.add(cur.toString().trim());return out;}
    private static String strip(String v){String s=v==null?"":v.trim();if(s.length()>=2&&((s.charAt(0)=='"'&&s.charAt(s.length()-1)=='"')||(s.charAt(0)=='\''&&s.charAt(s.length()-1)=='\'')))return s.substring(1,s.length()-1);return s;}

    static List<Integer> parseRawUnicodeSequence(String s){
        String v=s==null?"":s.trim();if(v.isEmpty()||!v.matches("(?i)U\\+[0-9a-f]{1,6}(?:[ \\t]+U\\+[0-9a-f]{1,6})*"))return null;List<Integer>out=new ArrayList<>();Matcher m=Pattern.compile("(?i)U\\+([0-9a-f]{1,6})").matcher(v);while(m.find()){int cp=Integer.parseInt(m.group(1),16);if(!Character.isValidCodePoint(cp)||(cp>=0xD800&&cp<=0xDFFF))return null;out.add(cp);}return List.copyOf(out);
    }
}
