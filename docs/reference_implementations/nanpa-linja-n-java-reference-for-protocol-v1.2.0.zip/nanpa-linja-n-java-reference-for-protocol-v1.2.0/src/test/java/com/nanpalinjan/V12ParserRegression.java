package com.nanpalinjan;

import java.nio.file.*;
import java.util.*;

/** Normative 24-case Parser-Renderer-Profile-v1.2 document regression. */
public final class V12ParserRegression {
    private static void check(boolean ok,String m){if(!ok)throw new IllegalStateException(m);}
    @SuppressWarnings("unchecked") private static Map<String,Object> map(Object v){return v instanceof Map<?,?>m?(Map<String,Object>)m:Map.of();}
    @SuppressWarnings("unchecked") private static List<Object> list(Object v){return v instanceof List<?>l?(List<Object>)l:List.of();}
    private static String str(Object v){return v==null?null:String.valueOf(v);}
    private static String cp(int value){return String.format("U+%04X",value);}

    private static Map<String,Object> astSummary(RenderPlan plan){
        Map<String,Object> out=new LinkedHashMap<>();DocumentAst ast=plan.ast();List<Object> lines=new ArrayList<>();
        out.put("normalizedInput",ast.normalizedInput());out.put("lineCount",(double)ast.lines().size());
        for(DocumentLine line:ast.lines()){
            Map<String,Object> row=new LinkedHashMap<>();row.put("sourceText",line.sourceText());List<Object> segments=new ArrayList<>();
            if(line.canonicalSourceText()!=null)row.put("canonicalSourceText",line.canonicalSourceText());if(line.sourceEncoding()!=null)row.put("sourceEncoding",line.sourceEncoding());
            for(DocumentSegment seg:line.children()){Map<String,Object> item=new LinkedHashMap<>();item.put("kind",seg.kind());if(seg.value()!=null)item.put("value",seg.value());segments.add(item);}row.put("segments",segments);lines.add(row);
        }
        out.put("lines",lines);return out;
    }

    private static Map<String,Object> semantic(List<RenderRun> runs){
        List<Object> kinds=new ArrayList<>(),codepoints=new ArrayList<>(),literals=new ArrayList<>(),classes=new ArrayList<>();
        for(RenderRun run:runs){kinds.add(run.kind());if("text".equals(run.kind()))literals.add(run.renderText());else for(int c:run.canonicalCodepoints())codepoints.add(cp(c));
            if(run.numericCartouche()||"number".equals(run.fontRole()))classes.add("number");else if("cartouche".equals(run.fontRole())){String src=run.sourceText()==null?"":run.sourceText().trim();boolean literal=src.length()>=2&&src.startsWith("\"")&&src.endsWith("\"")&&!src.startsWith("\"\"");classes.add(literal?"literal":"ordinary");}
        }
        Map<String,Object> out=new LinkedHashMap<>();out.put("elementKinds",kinds);out.put("canonicalCodepoints",codepoints);out.put("literalTexts",literals);out.put("cartoucheClasses",classes);return out;
    }
    private static List<Object> semanticLines(RenderPlan plan){List<Object> out=new ArrayList<>();for(RenderLinePlan line:plan.lines())out.add(semantic(line.runs()));return out;}

    public static void main(String[]args)throws Exception{
        if(args.length<2)throw new IllegalArgumentException("usage: V12ParserRegression <fonts.zip> <parser-renderer-regression-v1.2.0.json>");
        Path fonts=Path.of(args[0]),corpus=Path.of(args[1]);Map<String,Object> root=map(MiniJson.parse(Files.readString(corpus)));List<Object> cases=list(root.get("cases"));check(cases.size()==24,"expected 24 v1.2 cases");int pass=0;List<String> failures=new ArrayList<>();
        try(NanpaLinjaN n=NanpaLinjaN.create(fonts)){
            for(Object raw:cases){Map<String,Object> c=map(raw),expected=map(c.get("expected"));String id=str(c.get("id"));try{
                Map<String,Object> om=new LinkedHashMap<>();om.put("font","nasinNanpa");om.put("parser",map(c.get("parserOptions")));RenderOptions opts=RenderOptions.fromMap(om);RenderPlan plan=n.buildRenderPlan(str(c.get("input")),opts);
                Map<String,Object> ga=astSummary(plan),wa=map(expected.get("ast"));List<Object> gs=semanticLines(plan),ws=list(expected.get("semantic"));
                if(!Objects.equals(ga,wa))throw new IllegalStateException("AST got="+ga+" want="+wa);if(!Objects.equals(gs,ws))throw new IllegalStateException("semantic got="+gs+" want="+ws);
                String equivalent=str(expected.get("equivalentCanonicalInput"));if(equivalent!=null){RenderPlan other=n.buildRenderPlan(equivalent,opts);if(!Objects.equals(gs,semanticLines(other)))throw new IllegalStateException("equivalentCanonicalInput semantic mismatch");}pass++;
            }catch(Exception ex){failures.add(id+": "+ex.getMessage());}}
            String[] protectedInputs={"[toki. pona]","[\"toki. pona\"]","pi(toki. pona)","{toki. pona}"};ParseOptions po=ParseOptions.fromPublicMap(Map.of("mode","sitelen-pona-ascii-extended","breakLinesAtFullStops",true));RenderOptions opts=new RenderOptions().withParser(po);
            for(String input:protectedInputs){DocumentAst ast=n.parseInput(input,opts);if(ast.lines().size()!=1||!Objects.equals(ast.lines().getFirst().sourceText(),input))failures.add("protected line-break case split unexpectedly: "+input);}
        }
        System.out.println("Java Protocol v1.2 parser/renderer regression: "+pass+"/"+cases.size()+" PASS");System.out.println("breakLinesAtFullStops protected-region checks: "+(4-(int)failures.stream().filter(x->x.startsWith("protected")).count())+"/4 PASS");
        if(!failures.isEmpty()){for(String f:failures)System.err.println(" - "+f);throw new IllegalStateException("v1.2 parser regression failures: "+failures.size());}
    }
}
