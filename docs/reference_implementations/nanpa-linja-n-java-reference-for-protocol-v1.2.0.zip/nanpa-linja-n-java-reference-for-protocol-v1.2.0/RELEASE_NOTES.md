# nanpa-linja-n Java reference — Protocol v1.2.0

This release updates the native Java 21 reference implementation from Protocol v1.1.0 to v1.2.0 while preserving the frozen Core-v1 numeric implementation and Production-Font-Profile-v1.1 behavior.

## v1.2 changes

- ordinary ASCII full stop maps to U+F199C middle dot after numeric parsing has had precedence;
- adjacent ordinary forms such as `toki.pona` are tokenized as `toki`, middle dot, `pona`;
- sentence splitting via `breakLinesAtFullStops` retains quote/cartouche/long-pi/brace/decimal protection;
- direct recognized CSP/UCSUR document input is canonicalized to textual parser syntax;
- changed lines expose `canonicalSourceText` and `sourceEncoding = "mixed-csp-unicode"` while retaining original `sourceText`;
- explicit textual `U+...` remains the raw UCSUR path;
- quote closing uses odd/even consecutive-backslash parity;
- leading `""` activates force-ordinary cartouche behavior;
- the Protocol-v1.2 24-case parser corpus and 254-case canonical full-renderer corpus are bundled;
- the supplied `fonts.zip` is bundled exactly.

No frozen numeric Core source behavior was intentionally changed.

## Validation performed for this build

- all Java production + test sources compile with `javac --release 21`;
- v1.2 static authority/resource checks pass;
- package/release manifest and ZIP integrity are verified.

The complete regression suite was not run during this update, per request. Run `./tools/run_java_regression.sh` for full qualification.
