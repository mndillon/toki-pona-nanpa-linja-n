# nanpa-linja-n Java reference implementation

Independent **Java 21** reference implementation for **nanpa-linja-n Protocol v1.2.0**. The frozen Core-v1 numeric API and corpus remain unchanged; Protocol v1.2 updates the integrated document parser/renderer profile while retaining **Production-Font-Profile-v1.1**.

The implementation is native Java. It does not execute JavaScript, Node, a browser, Python, Go, Rust, Dart, or Kotlin at runtime. The bundled JavaScript and JSON files are conformance authorities/oracles only.

## Protocol v1.2 additions

Relative to the uploaded Java v1.1.0 reference, this package adds the v1.2 document semantics without changing the frozen numeric Core:

- ordinary ASCII `.` maps to sitelen pona middle dot U+F199C;
- numeric parsing keeps precedence, so decimal points such as `1.25` remain numeric;
- `breakLinesAtFullStops` retains sentence punctuation but does not split inside quoted/literal input, cartouches, `pi(...)` long structures, braces, or decimal numbers;
- directly pasted recognized CSP/UCSUR is translated to canonical parser text and then reparsed through the ordinary parser pipeline;
- changed direct-Unicode lines retain original `sourceText` and expose `canonicalSourceText` plus `sourceEncoding = "mixed-csp-unicode"`;
- explicit textual `U+...` input remains the raw-codepoint path;
- quote closing uses odd/even consecutive-backslash parity;
- cartouches beginning with `""` use the v1.2 force-ordinary path, including ordinary full-stop semantics;
- the normative 24-case Protocol-v1.2 parser/renderer corpus and 254-case canonical full-renderer corpus are bundled.

## Production fonts

The authoritative font bundle is:

```text
resources/fonts.zip
```

It is the supplied v1.2 resource archive, SHA-256:

```text
50c0375469508e806d2a6bb1ce555fa81adb72f73a497ddf7d26e4150671b209
```

The embedded manifest contains eight production font pairs. Production-Font-Profile-v1.1 behavior, vector-output requirements, vulgar-fraction scaling, tally routing, and render adapters remain in place.

## Public facade

The main facade is `com.nanpalinjan.NanpaLinjaN`.

Typical use:

```java
try (NanpaLinjaN nanpa = NanpaLinjaN.create()) {
    DocumentAst ast = nanpa.parseInput("toki.pona");
    PngRenderResult png = nanpa.renderToPng("toki&pona 123");
}
```

Existing v1.1 Java callers remain source-compatible. `DocumentLine` adds `canonicalSourceText` and `sourceEncoding`, with the previous constructor retained for compatibility.

## Requirements

- JDK **21**
- Maven is optional; the supplied shell runner uses `javac` / `java` directly

## Build validation

Compile all production and test sources without running regressions:

```bash
TMP="$(mktemp -d)"
find src/main/java src/test/java -name '*.java' | sort > "$TMP/sources.txt"
javac --release 21 -encoding UTF-8 -d "$TMP/classes" @"$TMP/sources.txt"
rm -rf "$TMP"
```

Static release/authority validation:

```bash
python3 tools/check_v1_2_release.py
```

## Focused Protocol v1.2 test

After compiling the sources into a class directory:

```bash
java -Djava.awt.headless=true -cp "$CLASSES" \
  com.nanpalinjan.V12ParserRegression \
  resources/fonts.zip \
  conformance/parser-renderer-regression-v1.2.0.json
```

The corpus contains 24 cases: 10 full-stop cases, 12 direct CSP/UCSUR cases, and 2 quote-escape cases.

## Full regression

Run when full qualification is required:

```bash
./tools/run_java_regression.sh
```

The runner is non-fail-fast and writes:

```text
test-output/java-regression-report.txt
```

The v1.2 runner includes the frozen Core/API tests, canonical syntax/adapters, the 24-case v1.2 parser regression, 254-case v1.2 canonical full renderer, Production-Font-Profile-v1.1 rendering checks, and the v1.2 profile/vector checks.

## Release validation status

For this generated v1.2 package, only build/package validation was performed here, in accordance with the requested workflow. The complete regression suite was **not** executed. See `VALIDATION-STATUS.txt` and `TESTING.md`.
