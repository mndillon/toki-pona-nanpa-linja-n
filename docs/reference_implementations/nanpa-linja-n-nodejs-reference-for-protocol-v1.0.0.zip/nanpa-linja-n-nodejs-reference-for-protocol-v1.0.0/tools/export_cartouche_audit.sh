#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
command -v node >/dev/null 2>&1 || { echo 'ERROR: Node.js is required.' >&2; exit 1; }
command -v npm >/dev/null 2>&1 || { echo 'ERROR: npm is required.' >&2; exit 1; }
if [[ ! -d node_modules/skia-canvas ]]; then
  echo 'Installing Node.js dependency skia-canvas@3.0.8...'
  npm install --no-audit --no-fund
fi
node tools/cartouche-audit.mjs
