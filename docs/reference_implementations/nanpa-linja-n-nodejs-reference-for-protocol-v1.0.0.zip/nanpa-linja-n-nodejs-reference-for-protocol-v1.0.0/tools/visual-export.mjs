#!/usr/bin/env node
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { NanpaLinjaN } from '../src/node.js';
import { Canvas, Image } from '../src/node-platform.js';

const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const OUT=path.resolve(process.env.NANPA_VISUAL_OUTPUT_DIR || path.join(ROOT,'test-output'));
await fs.mkdir(OUT,{recursive:true});
for (const name of await fs.readdir(OUT)) { if (/\.(?:png)$/i.test(name)) await fs.rm(path.join(OUT,name),{force:true}); }

async function writePng(name, bytes){await fs.writeFile(path.join(OUT,name),Buffer.from(bytes));}
async function whiteVariant(bytes){
  const img=new Image(); img.src=Buffer.from(bytes); await img.decode();
  const c=new Canvas(img.width,img.height); const ctx=c.getContext('2d');
  ctx.fillStyle='#ffffff'; ctx.fillRect(0,0,c.width,c.height); ctx.drawImage(img,0,0);
  return await c.toBuffer('png');
}

const n=await NanpaLinjaN.create();
let base=0,white=0;
try{
  for(const f of n.listFonts()){
    for(const [label,abbr] of [['full',false],['abbreviated',true]]){
      const result=await n.renderToPng('123.45',{font:f.key,fontSize:56,paddingPx:18,parser:{abbreviateNumericCartouches:abbr}});
      const filename=`${f.key}-${label}.png`;
      await writePng(filename,result.bytes); base++;
      await writePng(`${f.key}-${label}-white.png`,await whiteVariant(result.bytes)); white++;
    }
  }
}finally{await n.destroy();}
console.log(`Node.js numeric visual audit: ${base+white} PNG file(s) written to ${OUT} (${base} transparent + ${white} white-background)`);
if(base!==16||white!==16)process.exitCode=1;
