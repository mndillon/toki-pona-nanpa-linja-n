#!/usr/bin/env node
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { NanpaLinjaN } from '../src/node.js';
import { Canvas, Image } from '../src/node-platform.js';

const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const OUT=path.resolve(process.env.NANPA_CARTOUCHE_AUDIT_DIR || path.join(ROOT,'test-output','cartouche-audit'));
await fs.mkdir(OUT,{recursive:true});
for (const name of await fs.readdir(OUT)) { if (/\.(?:png)$/i.test(name)) await fs.rm(path.join(OUT,name),{force:true}); }
const TALLY=0xF199E;
const cases=[
 ['ordinary-cartouche','[jan pona]',null],
 ['ordinary-cartouche-halo-red','[jan pona]',{halo:{enabled:true,color:'#D91E18',widthPx:6}}],
 ['ordinary-cartouche-tallies','[jan pona,,]',null],
 ['ordinary-cartouche-tallies-halo-red','[jan pona,,]',{halo:{enabled:true,color:'#D91E18',widthPx:6}}],
];
async function decode(bytes){const img=new Image();img.src=Buffer.from(bytes);await img.decode();return img;}
async function write(name,bytes){await fs.writeFile(path.join(OUT,name),Buffer.from(bytes));}
async function contact(font,items){
  const imgs=[]; for(const x of items)imgs.push(await decode(x.bytes));
  const margin=18,labelH=28,gap=14;
  const width=Math.max(...imgs.map(i=>i.width))+margin*2;
  const heights=imgs.map(i=>labelH+i.height+margin);
  const height=margin+heights.reduce((a,b)=>a+b,0)+gap*(imgs.length-1);
  const c=new Canvas(width,height);const ctx=c.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,width,height);ctx.fillStyle='#111';ctx.font='15px sans-serif';ctx.textBaseline='top';
  let y=margin;
  for(let i=0;i<imgs.length;i++){
    ctx.fillText(items[i].label,margin,y);y+=labelH;
    ctx.drawImage(imgs[i],margin,y);y+=imgs[i].height+margin;if(i<imgs.length-1)y+=gap;
  }
  return c.toBuffer('png');
}
function assertTallyPlan(fontKey,plan){
  const run=plan.lines.flatMap(l=>l.runs).find(r=>r.kind==='cartouche');
  if(!run)throw new Error(`${fontKey}: ordinary cartouche run missing`);
  const manual=Array.isArray(run.manualTallies)&&run.manualTallies.some(v=>Number(v)>0);
  if(manual){
    if(run.renderFullCps?.includes(TALLY))throw new Error(`${fontKey}: manual tally font leaked U+F199E into shaped font run`);
    if(run.manualTallies?.[1]!==2)throw new Error(`${fontKey}: expected two manual tallies on owner glyph 1`);
    const group=run.manualTallyLayout?.groups?.find(g=>Number(g?.count)>0);const owner=run.audioGlyphLayout?.[1];
    if(!group||!owner)throw new Error(`${fontKey}: missing native owner-glyph/manual-tally layout`);
    const gc=(Number(group.bounds.left)+Number(group.bounds.right))/2;const oc=Number(owner.x)+Number(owner.width)/2;
    if(Math.abs(gc-oc)>=0.02)throw new Error(`${fontKey}: manual tally group is not centered on owner glyph (${gc} vs ${oc})`);
  }else{
    const count=run.renderFullCps?.filter(cp=>cp===TALLY).length||0;
    if(count!==2)throw new Error(`${fontKey}: UCSUR tally mode expected two U+F199E glyphs, got ${count}`);
  }
  return manual?'manual':'ucsur';
}

const n=await NanpaLinjaN.create();let individual=0,contacts=0,manualFonts=0,ucsurFonts=0;
try{
  for(const f of n.listFonts()){
    const tallyBuilt=await n.buildRenderPlan('[jan pona,,]',{font:f.key,fontSize:56,paddingPx:18});
    const mode=assertTallyPlan(f.key,tallyBuilt.plan); if(mode==='manual')manualFonts++;else ucsurFonts++;
    const rendered=[];
    for(const [label,input,paint] of cases){
      const opts={font:f.key,fontSize:56,paddingPx:18};if(paint)opts.paint=paint;
      const result=await n.renderToPng(input,opts);const name=`${f.key}--${label}.png`;await write(name,result.bytes);rendered.push({label,bytes:result.bytes});individual++;
    }
    await write(`${f.key}--ordinary-cartouche-contact.png`,await contact(f.key,rendered));contacts++;
  }
}finally{await n.destroy();}
console.log(`Node.js ordinary-cartouche audit: ${individual+contacts} PNG file(s) written to ${OUT} (${individual} renderer outputs + ${contacts} contact sheets)`);
console.log(`tally routing: ${manualFonts} manual-tally font(s), ${ucsurFonts} UCSUR-tally font(s); owner-glyph alignment PASS`);
if(individual!==32||contacts!==8)process.exitCode=1;
