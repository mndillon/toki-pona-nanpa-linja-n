# nanpa-linja-n Node.js reference implementation

This package is the **Node.js JavaScript reference implementation for nanpa-linja-n Protocol v1.0.0**.

It runs the canonical nanpa-linja-n JavaScript parser, renderer, font-pair controller, facade and vector exporter under Node.js without Chromium. The parser/rendering sources copied from the browser reference are byte-identical to the canonical JavaScript sources. Node-specific code is confined to the platform adapter in `src/node-platform.js` and the Node entry points.

## Requirements

- Node.js 20 or newer
- npm
- Linux, macOS or Windows supported by `skia-canvas` 3.0.8

The package includes the production font bundle at `resources/fonts.zip` and the vector WASM used by the canonical JavaScript renderer. Node reads the ZIP with its built-in runtime APIs; no external ZIP package or exploded font directory is required. `NANPA_FONT_DIR` remains optional for testing an external unpacked copy of the same font set.

## Quick regression and visual audit

From the extracted directory:

```bash
./tools/run_nodejs_regression.sh
./tools/export_visual_pngs.sh
./tools/export_cartouche_audit.sh
```

On the first command, the wrapper automatically installs the declared Node dependency if it is not already present. You can also install it explicitly with:

```bash
npm install
```

The regression command does **not** launch Chromium. Browser parity is checked against a frozen oracle generated from the canonical browser JavaScript renderer. The consolidated runner is **non-fail-fast**: every configured suite is attempted, and one report is written to `test-output/nodejs-regression-report.txt` even when one or more suites fail.

Expected visual output:

- `test-output/`: 32 numeric PNGs (16 transparent + 16 white-background)
- `test-output/cartouche-audit/`: 40 PNGs (32 actual renderer outputs + 8 contact sheets)

The ordinary-cartouche audit renders, for all eight production fonts:

- `[jan pona]`
- `[jan pona]` with halo
- `[jan pona,,]`
- `[jan pona,,]` with halo

For manual-tally fonts the audit verifies that U+F199E is **not** inserted into the shaped font run and that the two synthetic tally marks are centred on the actual owner glyph according to the canonical JavaScript render plan.

## Basic API

```js
import { NanpaLinjaN } from './src/node.js';

const nanpa = await NanpaLinjaN.create();

const parsed = await nanpa.parse('123.45');
console.log(parsed.ast);

const plan = await nanpa.buildRenderPlan('[jan pona,,]');
console.log(plan.plan);

const png = await nanpa.renderToPng('[jan pona,,]', {
  font: 'nasinNanpa',
  fontSize: 56,
  paddingPx: 18,
});

await import('node:fs/promises').then(fs => fs.writeFile('cartouche.png', png.bytes));

const svg = await nanpa.renderToSvg('2026-09-13', { font: 'linjaSike' });
await import('node:fs/promises').then(fs => fs.writeFile('date.svg', svg.svg));

const pdf = await nanpa.renderToPdf('0b10101');
await import('node:fs/promises').then(fs => fs.writeFile('binary.pdf', pdf.bytes));

await nanpa.destroy();
```

## Editing parsed text with `astToText()`

`parse()` returns a document AST that can be inspected or edited. `astToText()` converts the current AST contents back into valid nanpa-linja-n source text, which can then be passed to the normal render methods. A separate parse call is not required for ordinary rendering; use this workflow when an application specifically needs to inspect or modify parsed content.

```js
import { NanpaLinjaN } from './src/node.js';

const nanpa = await NanpaLinjaN.create();
const parsed = await nanpa.parse('jan   pona [ jan  pona,, ]');

const bracket = parsed.ast.lines
  .flatMap(line => line.children || [])
  .find(segment => segment.kind === 'bracket');

bracket.value = ' jan  suno,, ';

const editedText = nanpa.astToText(parsed.ast);
console.log(editedText);
// jan   pona [ jan  suno,, ]

const png = await nanpa.renderToPng(editedText, {
  font: 'linjaPona',
  fontSize: 56,
});

await import('node:fs/promises').then(fs => fs.writeFile('edited.png', png.bytes));
await nanpa.destroy();
```

`astToText` is also a named export. Its optional `numericOutput` selector can re-serialize numeric spans identified by `parse()` while preserving the existing source-preserving default:

```js
import { astToText } from './src/node.js';

console.log(astToText(parsed.ast, { numericOutput: 'source' }));
console.log(astToText(parsed.ast, { numericOutput: 'properName' }));
console.log(astToText(parsed.ast, { numericOutput: '#~' }));
console.log(astToText(parsed.ast, {
  numericOutput: 'cartouche',
  parser: { abbreviateNumericCartouches: true },
}));
```

Supported values are `source`, `properName`, `#~`, and `cartouche`. `cartouche` respects the existing numeric-cartouche abbreviation flags, and `nasinNanpaPona: true` emits ordinary Toki Pona number words where the existing numeric rules permit that representation. If a requested representation is unavailable, the original numeric source is preserved.

Editable content normally includes `text.value`, `bracket.value`, `quote.value`, quote delimiters, image descriptor values and `rawUcsur.cps`. Source offsets and line/source-index fields are correspondence metadata and normally should not be edited. Whitespace retained in AST values is preserved; image expressions are emitted in a canonical valid form. Numeric metadata is additive and remains guarded by the original numeric source text, so stale metadata does not rewrite edited text.

## Parser-only API

`parseNumber` is available both as a named public export and through `NanpaParser.parseNumber()`. A created facade also exposes `nanpa.parseNumber()`.

```js
import { parseNumber, NanpaParser } from './src/node.js';

console.log(parseNumber('123.45', {
  numericMode: 'uniform',
  relaxedNanpaLinjanParsing: true,
}));

console.log(NanpaParser.parseNumber('123.45', {
  numericMode: 'uniform',
  relaxedNanpaLinjanParsing: true,
}));
```

## Advanced renderer API

```js
import {
  SitelenRenderer,
  NanpaParser,
  SitelenVectorExporter,
  createSitelenFontPairController,
} from './src/node-advanced.js';
```

These are the same canonical JavaScript classes exported by the browser reference. `src/node-advanced.js` installs the Node platform adapter first and then re-exports them.

## Production fonts

The canonical production fonts and licensing files are stored only in `resources/fonts.zip`. Font-pair and support-font filenames are read from `fonts/preloaded-font-pairs.manifest.json` inside that ZIP. The eight production font-pair keys are available through:

```js
const nanpa = await NanpaLinjaN.create();
console.log(nanpa.listFonts());
```

A font can be selected by key:

```js
await nanpa.renderToPng('123.45', { font: 'linjaPona' });
```

## External font directory

To test another copy of the production fonts:

```bash
export NANPA_FONT_DIR="/absolute/path/to/fonts"
./tools/export_visual_pngs.sh
./tools/export_cartouche_audit.sh
```

The directory may contain `preloaded-font-pairs.manifest.json`. If it does not, the bundled manifest is used and its font filenames are resolved against `NANPA_FONT_DIR`.

## Regression layers

`./tools/run_nodejs_regression.sh` runs all configured suites and does not stop on the first failure. The current qualification run contains **10 suites**:

1. **Canonical + Node wrapper source integrity** — verifies the canonical renderer, font controller, vector exporter, browser facade copy, advanced-entry copy, and Node platform adapter by SHA-256.
2. **Production font/assets** — checks the eight font pairs, file hashes, required cmap coverage and required OpenType features.
3. **Protocol v1.0.0 frozen corpus** — **1030/1030** parser/API/renderer checks.
4. **Node platform compatibility** — verifies the Node browser-service shim, including IndexedDB `keyPath`, `createIndex`, `get`, `getAll`, transaction completion, and font-controller hydration.
5. **Node renderer core** — **115** renderer/controller/vector/facade checks under the Node platform adapter.
6. **`astToText` / `parseNumber` API** — **23** pure serialization/API checks plus **12** real Node integration checks.
7. **Canonical syntax + font adapters** — **28/28** canonical syntax cases plus **5/5** adapter cases against the JavaScript authority.
8. **Canonical full renderer** — **254/254** branch-oriented semantic cases generated directly from the bundled canonical JavaScript renderer, covering syntax, aliases, `&`, `te/to/zz`, long glyphs, numeric scanning, brackets, quotes, images, options/flags, AST semantics, and all production adapter IDs.
9. **Production output coverage** — **76** output checks across fonts, numeric/ordinary cartouches, manual and UCSUR tally modes, mixed content, images, halo, PNG, SVG, PDF and advanced rendering entry points.
10. **Browser-to-Node parity** — **64/64** production-renderer cases against the frozen Chromium oracle, with **448 semantic checks** and **256 geometry groups** (2.1 px tolerance).

At the end, the runner prints one consolidated PASS/FAIL matrix and writes the complete stdout/stderr record to:

```text
test-output/nodejs-regression-report.txt
```

See `CONFORMANCE.md` for the parity model and exact acceptance criteria.


## Canonical JavaScript semantic corpora

The package now includes the same current JavaScript-derived conformance corpora used to qualify the other language reference implementations:

```text
conformance/canonical-syntax-v1.0.1-phase1/cases.json
conformance/full-renderer-canonical-v1.0.1/cases.json
```

The full-renderer corpus pins the exact canonical renderer SHA-256 and is executed directly against that unchanged renderer under the Node platform adapter. This is intentionally separate from the production facade/browser-parity suite: the semantic corpus verifies the renderer API and all parser/render flags, while the 64-case parity oracle verifies the complete production font-controller/facade behavior against Chromium.

## Canonical-source relationship

The canonical reference modules below are kept synchronized with the browser JavaScript reference; the font-resource-only changes replace hard-coded font paths with manifest-driven roles:

```text
src/advanced-browser-core.js     <- src/advanced.js
reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js
reference/sitelen-font-pair-controller.js
reference/sitelen-vector-exporter.js
```

The Node implementation does **not** translate or reimplement parser/cartouche/tally logic in another language. Instead, `src/node-platform.js` supplies the browser services that the unchanged JavaScript renderer expects: Canvas2D, font loading, DOM-compatible controls used by the renderer, fetch for local assets, in-memory IndexedDB/localStorage compatibility, and image/font primitives.

## Node-specific dependency

The Node canvas/font backend is:

```text
skia-canvas 3.0.8
```

It is pinned exactly in `package.json`.

## Generated files

Regression/audit output is written under `test-output/`. The release ZIP intentionally does not include `node_modules/` or generated output.
