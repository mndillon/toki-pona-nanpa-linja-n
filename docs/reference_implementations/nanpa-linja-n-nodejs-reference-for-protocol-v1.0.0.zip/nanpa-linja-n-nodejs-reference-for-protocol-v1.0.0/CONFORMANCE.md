# Node.js reference conformance

## Scope

The Node.js reference has three independent conformance targets:

1. **nanpa-linja-n Protocol v1.0.0 frozen conformance**.
2. **Canonical JavaScript renderer semantic conformance** across the current branch-oriented syntax/render corpus.
3. **Production-renderer behavioral parity with the canonical browser JavaScript facade/controller stack**.

Passing only the frozen protocol corpus is not sufficient to claim full compatibility. The release qualification requires all configured suites to complete successfully.

## Why Node parity is stronger than a translated port

The parser, renderer, render adapters, ordinary-cartouche logic, manual-tally ownership/geometry, font-pair controller, high-level facade and vector exporter are not translated. They are the canonical JavaScript sources themselves. Source hashes are verified before behavioral testing.

Only platform services are replaced:

- browser Canvas2D -> `skia-canvas`
- browser `FontFace` / `document.fonts` -> Node font registration
- browser asset fetch -> local-file-aware Node fetch
- browser DOM controls used by the renderer -> minimal Node DOM compatibility
- browser localStorage / IndexedDB -> in-memory compatibility stores

## Frozen protocol corpus

The active protocol fixture is:

```text
fixtures/nanpa-linja-n-regression-v1.0.2.json
```

The expected regression total is 1030 checks with zero failures.


## Canonical renderer semantic corpus

The current JavaScript-derived semantic corpora are:

```text
conformance/canonical-syntax-v1.0.1-phase1/cases.json
conformance/full-renderer-canonical-v1.0.1/cases.json
```

The authority file is the bundled canonical renderer:

```text
reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js
```

Its SHA-256 is pinned inside the conformance data. The Node qualification runs the unchanged `SitelenRenderer` directly under the Node platform adapter, mirroring the oracle-generation layer rather than injecting production font-controller defaults. Current acceptance is:

- canonical syntax: **28/28**
- canonical production font adapters: **5/5**
- canonical full-renderer semantic corpus: **254/254**

The 254-case corpus covers ordinary words, direct tokens and aliases, `te`/`to`/`zz`, raw UCSUR, compounds including `&`, long-glyph forms, bracket/cartouche forms, tally modes, quotes, numeric scanners and boundaries, date/time/telephone/hex/binary forms, parser/render options, Toki Pona numeric phrases, AST/newline/sentence behavior, inline images, and every production adapter ID.

## Production-renderer parity corpus

Cases are defined in:

```text
fixtures/nodejs-browser-parity-cases.json
```

The corresponding frozen browser oracle is:

```text
fixtures/nodejs-browser-parity-v1.json
```

The suite currently contains 64 deliberately broad production-renderer cases covering ordinary text, ordinary cartouches, manual and UCSUR tallies, numeric cartouches, abbreviation, signs, decimals, percentages, scientific notation, fractions, mixed fractions, time/date/telephone, hexadecimal/binary, quotes, aliases, parser modes, raw U+ notation, unknown text, multiline layout, line splitting, halo/fill, alignment/spacing, inline images and all eight production fonts.

Semantic render-plan data is compared exactly. Geometry is compared within the documented tolerance because Chromium Canvas and Skia raster/font metric implementations are not byte-for-byte identical even when the semantic render plan agrees.

## Manual tally acceptance

For each manual-tally production font, regression requires:

- `cartoucheTallyMode` routes to synthetic/manual tallies;
- U+F199E is absent from the shaped font run;
- the owner glyph is identified by the canonical renderer;
- the expected tally count is preserved;
- the manual-tally layout exists;
- the tally group centre matches the owner glyph centre;
- physical PNG rendering succeeds with and without halo.

For UCSUR-tally fonts, the expected U+F199E glyph count must remain in the shaped run.

## Output formats

The full regression covers:

- Canvas
- PNG
- SVG
- PDF

The visual audit separately writes physical PNGs for human inspection.


## Consolidated non-fail-fast runner

`./tools/run_nodejs_regression.sh` invokes the consolidated Node runner. It attempts every configured suite even if an earlier suite fails. Each suite's stdout/stderr and exit status are retained, followed by a single summary matrix. The report is always written to:

```text
test-output/nodejs-regression-report.txt
```

This is intended to support one-pass diagnosis: all known failures from a run are visible together rather than being hidden behind the first failing suite.

## Language purity

All semantically meaningful rendering output is produced by JavaScript/Node.js. The shell files under `tools/` are launchers only. No Python, Go, Rust, Dart or Java post-processing is used to create or alter renderer output.
