#!/usr/bin/env node
import assert from 'node:assert/strict';
import { installNodePlatform } from '../src/node-platform.js';

await installNodePlatform();
let checks = 0;
const pass = (cond, msg) => { assert.ok(cond, msg); checks++; };

function openDb(name) {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(name, 1);
    req.onupgradeneeded = () => {
      const store = req.result.createObjectStore('pairs', { keyPath: 'fontKey' });
      store.createIndex('label', 'label', { unique: false });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
function request(req) {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
function txDone(tx) {
  return new Promise((resolve, reject) => {
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}

const db = await openDb(`nanpa-node-platform-${process.pid}`);
pass(db.objectStoreNames.contains('pairs'), 'IndexedDB object store was not created');
{
  const tx = db.transaction('pairs', 'readwrite');
  const store = tx.objectStore('pairs');
  const putResult = await request(store.put({ fontKey: 'demo', label: 'Demo' }));
  pass(putResult === 'demo', 'keyPath put did not return fontKey');
  await txDone(tx);
}
{
  const tx = db.transaction('pairs', 'readonly');
  const store = tx.objectStore('pairs');
  const one = await request(store.get('demo'));
  const all = await request(store.getAll());
  pass(one?.fontKey === 'demo', 'IndexedDB get failed');
  pass(Array.isArray(all) && all.length === 1 && all[0]?.label === 'Demo', 'IndexedDB getAll failed');
  await txDone(tx);
}

db.close();

// Verify the production facade can fully initialize without the dynamic-font
// hydration warning that an incomplete IndexedDB shim used to emit.
const warnings = [];
const originalWarn = console.warn;
console.warn = (...args) => warnings.push(args.map(String).join(' '));
const { NanpaLinjaN } = await import('../src/node.js');
const nanpa = await NanpaLinjaN.create({ storageKeyPrefix: `nanpaPlatformRegression-${process.pid}` });
await new Promise(resolve => setTimeout(resolve, 20));
await nanpa.destroy();
console.warn = originalWarn;
pass(!warnings.some(x => /hydrate dynamic presets|records is not iterable/i.test(x)), `unexpected font-controller hydration warning: ${warnings.join(' | ')}`);

console.log(`Node platform compatibility checks: ${checks}/5 PASS`);
console.log('PASS');
