#!/usr/bin/env node
import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// The canonical renderer carries always-on diagnostic logging. Keep the
// regression output readable while still allowing warnings/errors through.
const originalLog = console.log;
const originalTable = console.table;
console.log = () => {};
console.table = () => {};
const { SitelenRenderer } = await import('../src/node.js');

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const corpusPath = path.join(root, 'conformance/full-renderer-canonical-v1.0.1/cases.json');
const data = JSON.parse(await fs.readFile(corpusPath, 'utf8'));
const failures = [];
let passed = 0;
const adapters = {
  nasinNanpa: 'identity',
  sitelenSeliKiwen: 'identity',
  fairfaxHd: 'identity',
  fairfaxPonaHd: 'identity',
  linjaPona: 'linja-pona-legacy-v1',
  linjaSike: 'linja-sike-legacy-v1',
  nasinSitelenPuMono: 'nasin-sitelen-pu-mono-v1',
  linjaLipamanka: 'linja-lipamanka-v1',
};

function eq(a, b) { return JSON.stringify(a) === JSON.stringify(b); }
function normArray(v) { return Array.isArray(v) ? v : []; }
function fail(id, message) { failures.push({ id, message }); }

function compareAst(actual, expected) {
  const errors = [];
  if (!actual || typeof actual !== 'object') return ['AST missing'];
  if (actual.type !== expected?.type) errors.push(`type got ${JSON.stringify(actual.type)} want ${JSON.stringify(expected?.type)}`);
  if (actual.normalizedInput !== expected?.normalizedInput) errors.push(`normalizedInput got ${JSON.stringify(actual.normalizedInput)} want ${JSON.stringify(expected?.normalizedInput)}`);
  const al = normArray(actual.lines), el = normArray(expected?.lines);
  if (al.length !== el.length) return [...errors, `line count got ${al.length} want ${el.length}`];
  for (let i = 0; i < al.length; i++) {
    for (const key of ['index','sourceLineIndex','sentenceIndexInSourceLine','sourceText']) {
      if (al[i]?.[key] !== el[i]?.[key]) errors.push(`line[${i}] ${key} got ${JSON.stringify(al[i]?.[key])} want ${JSON.stringify(el[i]?.[key])}`);
    }
    const ac = normArray(al[i]?.children), ec = normArray(el[i]?.children);
    if (ac.length !== ec.length) { errors.push(`line[${i}] child count got ${ac.length} want ${ec.length}`); continue; }
    for (let j = 0; j < ac.length; j++) {
      for (const key of ['kind','openQuote','closeQuote']) {
        const av = ac[j]?.[key] ?? null, ev = ec[j]?.[key] ?? null;
        if (av !== ev) errors.push(`line[${i}] child[${j}] ${key} got ${JSON.stringify(av)} want ${JSON.stringify(ev)}`);
      }
      // The canonical language-neutral oracle deliberately maps an image
      // segment's JavaScript value object into an `image` field and stores
      // value=null. Preserve that normalization here instead of changing the
      // Node AST, whose raw shape is already the canonical JavaScript AST.
      const actualValue = ac[j]?.kind === 'image' ? null : (ac[j]?.value ?? null);
      const expectedValue = ec[j]?.value ?? null;
      if (actualValue !== expectedValue) errors.push(`line[${i}] child[${j}] value got ${JSON.stringify(actualValue)} want ${JSON.stringify(expectedValue)}`);
      const ai = ac[j]?.image ?? ac[j]?.value;
      const ei = ec[j]?.image;
      if (ei != null) {
        if (!ai || typeof ai !== 'object') { errors.push(`line[${i}] child[${j}] missing image`); continue; }
        for (const key of ['src','w','h','alt','valign','wriggle','transparent']) {
          if ((ai?.[key] ?? null) !== (ei?.[key] ?? null)) errors.push(`line[${i}] child[${j}] image.${key} got ${JSON.stringify(ai?.[key] ?? null)} want ${JSON.stringify(ei?.[key] ?? null)}`);
        }
      }
    }
  }
  return errors;
}

function compareRun(actual, expected, randomCps) {
  const errors = [];
  const actualLiteral = Boolean(actual?._element?.isLiteralCartouche);
  const actualNumeric = Boolean(actual?._element?.isNumericCartouche);
  const checks = [
    ['kind', actual?.kind, expected?.kind],
    ['renderMode', actual?.renderMode, expected?.renderMode],
    ['fontRole', actual?.fontRole, expected?.fontRole],
    ['sourceText', actual?.sourceText ?? '', expected?.sourceText ?? ''],
    ['sourceKind', actual?.sourceKind ?? '', expected?.sourceKind ?? ''],
    ['renderAdapterId', actual?.renderAdapterId ?? '', expected?.renderAdapterId ?? ''],
    ['requestedRenderAdapterId', actual?.requestedRenderAdapterId ?? '', expected?.requestedRenderAdapterId ?? ''],
    ['isQuoted', Boolean(actual?.isQuoted), Boolean(expected?.isQuoted)],
    ['interpretedQuote', Boolean(actual?.interpretedQuote), Boolean(expected?.interpretedQuote)],
    ['isUnrecognized', Boolean(actual?.isUnrecognized), Boolean(expected?.isUnrecognized)],
    ['manualTallies', actual?.manualTallies ?? null, expected?.manualTallies ?? null],
    ['isNumericCartouche', actualNumeric, Boolean(expected?.isNumericCartouche)],
    ['isLiteralCartouche', actualLiteral, Boolean(expected?.isLiteralCartouche)],
    ['imageAlt', actual?.imageAlt ?? null, expected?.imageAlt ?? null],
    ['encodedText', actual?.encodedText ?? null, expected?.encodedText ?? null],
  ];
  if (!randomCps) {
    checks.push(
      ['canonicalCps', normArray(actual?.canonicalCps), normArray(expected?.canonicalCps)],
      ['canonicalFullCps', normArray(actual?.canonicalFullCps), normArray(expected?.canonicalFullCps)],
      ['renderCps', normArray(actual?.renderCps), normArray(expected?.renderCps)],
    );
  }
  for (const [key, av, ev] of checks) if (!eq(av, ev)) errors.push(`${key}: got ${JSON.stringify(av)} want ${JSON.stringify(ev)}`);
  return errors;
}

if (data.caseCount !== data.cases?.length) {
  originalLog(`corpus count mismatch: declared ${data.caseCount} actual ${data.cases?.length ?? 0}`);
  process.exit(1);
}
const authorityPath = path.join(root, data.authority.path);
const authorityHash = crypto.createHash('sha256').update(await fs.readFile(authorityPath)).digest('hex');
if (authorityHash !== data.authority.sha256) {
  originalLog(`authority hash mismatch: got ${authorityHash} want ${data.authority.sha256}`);
  process.exit(1);
}

const renderer = await SitelenRenderer.create({});
try {
  for (const tc of data.cases) {
    const errors = [];
    try {
      if (!tc.oracle?.ok) {
        errors.push(`oracle generation failed: ${JSON.stringify(tc.oracle?.error)}`);
      } else {
        const plan = await renderer.buildRenderPlan({
          input: tc.input,
          parser: tc.parser,
          fonts: { renderAdapterId: adapters[tc.font] || 'identity' },
        });
        if (tc.compareAst) errors.push(...compareAst(plan.ast, tc.oracle.ast).map(x => `AST ${x}`));
        const actualRuns = normArray(plan?.lines).flatMap(line => normArray(line?.runs));
        const expectedRuns = normArray(tc.oracle.runs);
        if (actualRuns.length !== expectedRuns.length) {
          errors.push(`run count got ${actualRuns.length} want ${expectedRuns.length}`);
        } else {
          for (let i = 0; i < actualRuns.length; i++) {
            errors.push(...compareRun(actualRuns[i], expectedRuns[i], Boolean(tc.randomCps)).map(x => `run[${i}] ${x}`));
          }
        }
      }
    } catch (error) {
      errors.push(`${error?.name || 'Error'}: ${error?.stack || error}`);
    }
    if (errors.length) for (const e of errors) fail(tc.id, e); else passed++;
  }
} finally {
  console.log = originalLog;
  console.table = originalTable;
}

originalLog(`Canonical full-renderer semantic corpus: ${passed}/${data.cases.length} PASS`);
if (failures.length) {
  originalLog(`FAILED CHECKS (${failures.length} across ${new Set(failures.map(x => x.id)).size} case(s)):`);
  for (const item of failures) originalLog(`[${item.id}] ${item.message}`);
  process.exit(1);
}
originalLog('CANONICAL FULL-RENDERER CONFORMANCE PASS');
