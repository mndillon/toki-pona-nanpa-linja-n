#!/usr/bin/env node
import assert from 'node:assert/strict';
import { astToText, parseNumber } from '../src/node-facade.js';

let pureChecks = 0;
function pass(name, fn) {
  fn();
  pureChecks++;
  console.log(`PASS astToText ${name}`);
}

pass('named astToText export exists', () => assert.equal(typeof astToText, 'function'));
pass('named parseNumber export exists', () => assert.equal(typeof parseNumber, 'function'));

pass('preserves spaces, tabs, blank lines, brackets, and quote delimiters', () => {
  const ast = {
    lines: [
      { sourceLineIndex: 0, children: [
        { kind: 'text', value: 'jan\t  pona ' },
        { kind: 'bracket', value: ' jan  pona,, ' },
        { kind: 'text', value: '  ' },
        { kind: 'quote', value: 'toki  pona', openQuote: '“', closeQuote: '”' },
      ] },
      { sourceLineIndex: 1, children: [] },
      { sourceLineIndex: 2, children: [{ kind: 'text', value: 'pini' }] },
    ],
  };
  assert.equal(astToText(ast), 'jan\t  pona [ jan  pona,, ]  “toki  pona”\n\npini');
});

pass('rejoins sentence-split AST lines sharing one physical source line', () => {
  const ast = { lines: [
    { sourceLineIndex: 0, sentenceIndexInSourceLine: 0, children: [{ kind: 'text', value: 'jan li pona.' }] },
    { sourceLineIndex: 0, sentenceIndexInSourceLine: 1, children: [{ kind: 'text', value: ' ona li pona.' }] },
    { sourceLineIndex: 1, children: [{ kind: 'text', value: 'pini' }] },
  ] };
  assert.equal(astToText(ast), 'jan li pona. ona li pona.\npini');
});

pass('serializes an edited bracket value', () => {
  const ast = { lines: [{ sourceLineIndex: 0, children: [{ kind: 'bracket', value: ' jan  pona,, ' }] }] };
  ast.lines[0].children[0].value = ' jan  suno,, ';
  assert.equal(astToText(ast), '[ jan  suno,, ]');
});

pass('serializes straight quotes with stored delimiters', () => {
  const ast = { lines: [{ children: [{ kind: 'quote', value: 'jan pona', openQuote: '"', closeQuote: '"' }] }] };
  assert.equal(astToText(ast), '"jan pona"');
});

pass('serializes image descriptors canonically', () => {
  const ast = { lines: [{ children: [{ kind: 'image', value: { src: 'a.png', w: '50', alt: 'test', valign: 'center', wriggle: 4, transparent: false } }] }] };
  assert.equal(astToText(ast), "img(src='a.png',w='50',alt='test',valign='center',wriggle=4,transparent=false)");
});

pass('serializes raw UCSUR codepoints', () => {
  const ast = { lines: [{ children: [{ kind: 'rawUcsur', cps: [0xF1900, 0x300C] }] }] };
  assert.equal(astToText(ast), 'U+F1900 U+300C');
});

pass('rejects invalid raw UCSUR codepoints', () => {
  const ast = { lines: [{ children: [{ kind: 'rawUcsur', cps: [0x110000] }] }] };
  assert.throws(() => astToText(ast), /Invalid rawUcsur code point/);
});

pass('rejects non-document AST values', () => {
  assert.throws(() => astToText({}), /expects a document AST/);
});

function makeNumericAst(value, structures, parserOptions = {}) {
  return {
    type: 'document',
    parserOptions: {
      numericMode: 'uniform',
      relaxedNanpaLinjanParsing: true,
      relaxedNanpaLinjanRendering: true,
      nanpaColonParsing: true,
      nanpaColonRendering: true,
      enableHexParsing: true,
      enableBinaryParsing: true,
      ...parserOptions,
    },
    lines: [{
      sourceLineIndex: 0,
      children: [{ kind: 'text', value, numericStructures: structures }],
    }],
  };
}

pass('public parseNumber returns canonical alternative representations', () => {
  const parsed = parseNumber('123');
  assert.equal(parsed?.displayValue, '123');
  assert.equal(parsed?.properName, 'Nanpa Watusen');
  assert.equal(parsed?.uniqueCode, '#~WTS');
  assert.deepEqual(parsed?.abbreviatedWords, ['nanpa', ':', 'wan', 'tu', 'seli', 'nanpa']);
});

pass('numericOutput source preserves numeric source exactly', () => {
  const ast = makeNumericAst('mi jo e 123', [{ index: 8, end: 11, sourceText: '123' }]);
  assert.equal(astToText(ast, { numericOutput: 'source' }), 'mi jo e 123');
});

pass('numericOutput properName emits nanpa-linja-n proper name', () => {
  const ast = makeNumericAst('mi jo e 123', [{ index: 8, end: 11, sourceText: '123' }]);
  assert.equal(astToText(ast, { numericOutput: 'properName' }), 'mi jo e Nanpa Watusen');
});

pass('numericOutput #~ emits numeric abbreviation when available', () => {
  const ast = makeNumericAst('mi jo e 123', [{ index: 8, end: 11, sourceText: '123' }]);
  assert.equal(astToText(ast, { numericOutput: '#~' }), 'mi jo e #~WTS');
});

pass('numericOutput #~ preserves source when representation is unavailable', () => {
  const ast = makeNumericAst('#ABC 0b1010', [
    { index: 0, end: 4, sourceText: '#ABC' },
    { index: 5, end: 11, sourceText: '0b1010' },
  ]);
  assert.equal(astToText(ast, { numericOutput: '#~' }), '#ABC 0b1010');
});

pass('numericOutput cartouche emits full cartouche by default', () => {
  const ast = makeNumericAst('123', [{ index: 0, end: 3, sourceText: '123' }]);
  assert.equal(astToText(ast, { numericOutput: 'cartouche' }), '[nanpa : wan ala tu uta seli e nanpa]');
});

pass('numericOutput cartouche respects numeric cartouche abbreviation flag', () => {
  const ast = makeNumericAst('123', [{ index: 0, end: 3, sourceText: '123' }]);
  assert.equal(
    astToText(ast, { numericOutput: 'cartouche', parser: { abbreviateNumericCartouches: true } }),
    '[nanpa : wan tu seli nanpa]'
  );
});

pass('nasinNanpaPona emits ordinary toki pona where applicable', () => {
  const ast = makeNumericAst('123', [{ index: 0, end: 3, sourceText: '123' }]);
  assert.equal(
    astToText(ast, { numericOutput: 'cartouche', parser: { nasinNanpaPona: true } }),
    'wan ale mute tu wan'
  );
});

pass('nasinNanpaPona takes precedence over #~ output where applicable', () => {
  const ast = makeNumericAst('123', [{ index: 0, end: 3, sourceText: '123' }]);
  assert.equal(
    astToText(ast, { numericOutput: '#~', parser: { nasinNanpaPona: true } }),
    'wan ale mute tu wan'
  );
});

pass('abbreviated cartouche respects valid mixed-fraction kin delimiter', () => {
  const ast = makeNumericAst('1+1/2', [{ index: 0, end: 5, sourceText: '1+1/2' }]);
  assert.equal(
    astToText(ast, {
      numericOutput: 'cartouche',
      parser: {
        abbreviateNumericCartouches: true,
        preserveNumericCartoucheBreaksInAbbreviation: true,
      },
    }),
    '[nanpa : wan kin wan o o tu nanpa]'
  );
});

pass('parseNumber rejects internal digit whitespace', () => {
  assert.equal(parseNumber('12 34'), null);
});

pass('multiple numeric structures are transformed without changing surrounding text', () => {
  const ast = makeNumericAst('a 123 b 45 c', [
    { index: 2, end: 5, sourceText: '123' },
    { index: 8, end: 10, sourceText: '45' },
  ]);
  assert.equal(astToText(ast, { numericOutput: '#~' }), 'a #~WTS b #~AL c');
});

pass('stale numeric metadata does not rewrite edited text', () => {
  const ast = makeNumericAst('124', [{ index: 0, end: 3, sourceText: '123' }]);
  assert.equal(astToText(ast, { numericOutput: 'properName' }), '124');
});

pass('rejects unsupported numericOutput values', () => {
  const ast = makeNumericAst('123', [{ index: 0, end: 3, sourceText: '123' }]);
  assert.throws(() => astToText(ast, { numericOutput: 'abbreviation' }), /Unsupported numericOutput mode/);
});

console.log(`Node.js astToText pure regression: ${pureChecks} PASS`);

const nodePublic = await import('../src/node.js');
assert.equal(typeof nodePublic.parseNumber, 'function', 'node package named parseNumber export');
assert.equal(nodePublic.parseNumber('123')?.uniqueCode, '#~WTS', 'node package named parseNumber result');

const { NanpaLinjaN } = nodePublic;
const nanpa = await NanpaLinjaN.create({ storageKeyPrefix: 'nanpaAstToTextRegression' });
let integrationChecks = 0;
function integrationPass(name, condition, actual = condition, expected = true) {
  assert.equal(condition, true, `${name}: ${JSON.stringify(actual)} != ${JSON.stringify(expected)}`);
  integrationChecks++;
  console.log(`PASS astToText integration ${name}`);
}

try {
  const source = 'jan   pona [ jan  pona,, ]';
  const parsed = await nanpa.parse(source);
  integrationPass('parse AST round-trips exact source spacing', nanpa.astToText(parsed.ast) === source, nanpa.astToText(parsed.ast), source);

  const bracket = parsed.ast.lines.flatMap((line) => line.children || []).find((segment) => segment.kind === 'bracket');
  assert.ok(bracket, 'expected bracket AST node');
  bracket.value = ' jan  suno,, ';
  const edited = nanpa.astToText(parsed.ast);
  integrationPass('edited AST produces edited source', edited === 'jan   pona [ jan  suno,, ]', edited, 'jan   pona [ jan  suno,, ]');

  const numericSource = 'toki&pona 123 zz';
  const numericParsed = await nanpa.parse(numericSource);
  const numericTextSegment = numericParsed.ast.lines.flatMap((line) => line.children || []).find((segment) =>
    segment.kind === 'text' && Array.isArray(segment.numericStructures) && segment.numericStructures.some((item) => item.sourceText === '123')
  );
  integrationPass('parse annotates numeric structure without changing text segment kind', !!numericTextSegment, numericTextSegment?.numericStructures, 'numericStructures containing 123');
  integrationPass('numericOutput source preserves parsed source', nanpa.astToText(numericParsed.ast, { numericOutput: 'source' }) === numericSource);
  integrationPass('numericOutput properName uses parsed numeric span', nanpa.astToText(numericParsed.ast, { numericOutput: 'properName' }) === 'toki&pona Nanpa Watusen zz');
  integrationPass('numericOutput #~ uses parsed numeric span', nanpa.astToText(numericParsed.ast, { numericOutput: '#~' }) === 'toki&pona #~WTS zz');
  integrationPass('numericOutput full cartouche uses parsed numeric span', nanpa.astToText(numericParsed.ast, {
    numericOutput: 'cartouche',
    parser: { abbreviateNumericCartouches: false },
  }) === 'toki&pona [nanpa : wan ala tu uta seli e nanpa] zz');
  integrationPass('numericOutput abbreviated cartouche uses existing flag', nanpa.astToText(numericParsed.ast, {
    numericOutput: 'cartouche',
    parser: { abbreviateNumericCartouches: true },
  }) === 'toki&pona [nanpa : wan tu seli nanpa] zz');
  integrationPass('nasinNanpaPona uses ordinary toki pona', nanpa.astToText(numericParsed.ast, {
    numericOutput: 'cartouche',
    parser: { nasinNanpaPona: true },
  }) === 'toki&pona wan ale mute tu wan zz');
  integrationPass('instance parseNumber is public', nanpa.parseNumber('123')?.uniqueCode === '#~WTS', nanpa.parseNumber('123')?.uniqueCode, '#~WTS');
  integrationPass('named parseNumber rejects internal digit whitespace', nodePublic.parseNumber('12 34') === null, nodePublic.parseNumber('12 34'), null);
  integrationPass('instance parseNumber rejects internal digit whitespace', nanpa.parseNumber('12 34') === null, nanpa.parseNumber('12 34'), null);

  const spacedNumericSource = '12 34';
  const spacedNumericParsed = await nanpa.parse(spacedNumericSource);
  const spacedNumericStructures = spacedNumericParsed.ast.lines
    .flatMap((line) => line.children || [])
    .flatMap((segment) => Array.isArray(segment.numericStructures) ? segment.numericStructures : []);
  integrationPass(
    'document parser treats internal digit whitespace as a token boundary',
    spacedNumericStructures.length === 2 &&
      spacedNumericStructures[0]?.sourceText === '12' &&
      spacedNumericStructures[1]?.sourceText === '34',
    spacedNumericStructures.map((item) => item.sourceText),
    ['12', '34']
  );

  const fallbackParsed = await nanpa.parse('#ABC 0b1010', { parser: { enableHexParsing: true, enableBinaryParsing: true } });
  integrationPass('unsupported #~ representations preserve original hex/binary source', nanpa.astToText(fallbackParsed.ast, { numericOutput: '#~' }) === '#ABC 0b1010');

  const png = await nanpa.renderToPng(edited, { font: 'linjaPona', fontSize: 56 });
  const signature = Array.from(png.bytes.slice(0, 8));
  integrationPass('edited astToText output renders through normal PNG API', JSON.stringify(signature) === JSON.stringify([137,80,78,71,13,10,26,10]), signature, [137,80,78,71,13,10,26,10]);
} finally {
  await nanpa.destroy();
}

console.log(`Node.js astToText integration: ${integrationChecks} PASS`);
