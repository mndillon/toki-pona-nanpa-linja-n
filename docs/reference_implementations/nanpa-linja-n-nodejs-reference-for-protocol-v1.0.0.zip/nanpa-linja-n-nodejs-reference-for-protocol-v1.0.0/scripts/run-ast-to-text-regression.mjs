#!/usr/bin/env node
import assert from 'node:assert/strict';
import { astToText } from '../src/node-facade.js';

let pureChecks = 0;
function pass(name, fn) {
  fn();
  pureChecks++;
  console.log(`PASS astToText ${name}`);
}

pass('preserves spaces, tabs, blank lines, brackets, and quote delimiters', () => {
  const ast = {
    lines: [
      { sourceLineIndex: 0, children: [
        { kind: 'text', value: 'jan\t  pona ' },
        { kind: 'bracket', value: ' jan  pona,, ' },
        { kind: 'text', value: '  ' },
        { kind: 'quote', value: 'toki  pona', openQuote: '“', closeQuote: '”' },
      ] },
      { sourceLineIndex: 1, children: [] },
      { sourceLineIndex: 2, children: [{ kind: 'text', value: 'pini' }] },
    ],
  };
  assert.equal(astToText(ast), 'jan\t  pona [ jan  pona,, ]  “toki  pona”\n\npini');
});

pass('rejoins sentence-split AST lines sharing one physical source line', () => {
  const ast = { lines: [
    { sourceLineIndex: 0, sentenceIndexInSourceLine: 0, children: [{ kind: 'text', value: 'jan li pona.' }] },
    { sourceLineIndex: 0, sentenceIndexInSourceLine: 1, children: [{ kind: 'text', value: ' ona li pona.' }] },
    { sourceLineIndex: 1, children: [{ kind: 'text', value: 'pini' }] },
  ] };
  assert.equal(astToText(ast), 'jan li pona. ona li pona.\npini');
});

pass('serializes an edited bracket value', () => {
  const ast = { lines: [{ sourceLineIndex: 0, children: [{ kind: 'bracket', value: ' jan  pona,, ' }] }] };
  ast.lines[0].children[0].value = ' jan  suno,, ';
  assert.equal(astToText(ast), '[ jan  suno,, ]');
});

pass('serializes straight quotes with their stored content', () => {
  const ast = { lines: [{ children: [{ kind: 'quote', value: 'jan pona', openQuote: '"', closeQuote: '"' }] }] };
  assert.equal(astToText(ast), '"jan pona"');
});

pass('serializes image descriptors canonically', () => {
  const ast = { lines: [{ children: [{ kind: 'image', value: { src: 'a.png', w: '50', alt: 'test', valign: 'center', wriggle: 4, transparent: false } }] }] };
  assert.equal(astToText(ast), "img(src='a.png',w='50',alt='test',valign='center',wriggle=4,transparent=false)");
});

pass('serializes raw UCSUR codepoints', () => {
  const ast = { lines: [{ children: [{ kind: 'rawUcsur', cps: [0xF1900, 0x300C] }] }] };
  assert.equal(astToText(ast), 'U+F1900 U+300C');
});

pass('rejects invalid raw UCSUR codepoints', () => {
  const ast = { lines: [{ children: [{ kind: 'rawUcsur', cps: [0x110000] }] }] };
  assert.throws(() => astToText(ast), /Invalid rawUcsur code point/);
});

pass('rejects non-document AST values', () => {
  assert.throws(() => astToText({}), /expects a document AST/);
});

console.log(`Node.js astToText regression: ${pureChecks}/8 PASS`);

const { NanpaLinjaN } = await import('../src/node.js');
const nanpa = await NanpaLinjaN.create({ storageKeyPrefix: 'nanpaAstToTextRegression' });
let integrationChecks = 0;
function integrationPass(name, condition, actual = condition, expected = true) {
  assert.equal(condition, true, `${name}: ${JSON.stringify(actual)} != ${JSON.stringify(expected)}`);
  integrationChecks++;
  console.log(`PASS astToText integration ${name}`);
}

try {
  const source = 'jan   pona [ jan  pona,, ]';
  const parsed = await nanpa.parse(source);
  integrationPass('parse AST round-trips exact source spacing', nanpa.astToText(parsed.ast) === source, nanpa.astToText(parsed.ast), source);

  const bracket = parsed.ast.lines.flatMap((line) => line.children || []).find((segment) => segment.kind === 'bracket');
  assert.ok(bracket, 'expected bracket AST node');
  bracket.value = ' jan  suno,, ';
  const edited = nanpa.astToText(parsed.ast);
  integrationPass('edited AST produces edited source', edited === 'jan   pona [ jan  suno,, ]', edited, 'jan   pona [ jan  suno,, ]');

  const png = await nanpa.renderToPng(edited, { font: 'linjaPona', fontSize: 56 });
  const signature = Array.from(png.bytes.slice(0, 8));
  integrationPass('edited astToText output renders through normal PNG API', JSON.stringify(signature) === JSON.stringify([137,80,78,71,13,10,26,10]), signature, [137,80,78,71,13,10,26,10]);
} finally {
  await nanpa.destroy();
}

console.log(`Node.js astToText integration: ${integrationChecks}/3 PASS`);
