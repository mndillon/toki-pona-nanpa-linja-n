#!/usr/bin/env node
import { spawnSync } from 'node:child_process';
import process from 'node:process';
process.env.TERM ||= 'dumb';

const stages = [
  ['canonical JavaScript source integrity', 'scripts/verify-reference-hashes.mjs'],
  ['production font/assets', 'scripts/verify-font-files.mjs'],
  ['frozen protocol v1.0.0 conformance', 'scripts/run-protocol-regression.mjs'],
  ['Node renderer core', 'scripts/run-node-render-regression.mjs'],
  ['astToText API', 'scripts/run-ast-to-text-regression.mjs'],
  ['production renderer/output coverage', 'scripts/run-production-output-regression.mjs'],
  ['frozen browser-to-Node production parity', 'scripts/run-browser-parity-regression.mjs'],
];

console.log('nanpa-linja-n Node.js full reference regression');
console.log('==============================================');
console.log(`Node.js: ${process.version}`);
console.log('');

for (const [label, script] of stages) {
  console.log(`--- ${label} ---`);
  const result = spawnSync(process.execPath, [script], {
    stdio: 'inherit',
    cwd: process.cwd(),
    env: process.env,
  });
  if (result.error) throw result.error;
  if (result.status !== 0) {
    console.error(`\nFAIL: ${label}`);
    process.exit(result.status || 1);
  }
  console.log('');
}

console.log('ALL CONFIGURED NODE.JS REFERENCE TESTS PASS');
