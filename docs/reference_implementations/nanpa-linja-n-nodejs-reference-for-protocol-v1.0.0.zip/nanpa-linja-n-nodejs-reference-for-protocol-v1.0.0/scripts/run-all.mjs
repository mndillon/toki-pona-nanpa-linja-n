#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import process from 'node:process';
import { fileURLToPath } from 'node:url';

process.env.TERM ||= 'dumb';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const outputDir = path.join(root, 'test-output');
const reportPath = path.join(outputDir, 'nodejs-regression-report.txt');
const filter = path.join(root, 'scripts/test-console-filter.mjs');

const stages = [
  ['canonical and Node wrapper source integrity', 'scripts/verify-reference-hashes.mjs'],
  ['production font/assets', 'scripts/verify-font-files.mjs'],
  ['frozen protocol v1.0.0 conformance', 'scripts/run-protocol-regression.mjs'],
  ['Node platform compatibility', 'scripts/run-node-platform-regression.mjs'],
  ['Node renderer core', 'scripts/run-node-render-regression.mjs'],
  ['astToText API', 'scripts/run-ast-to-text-regression.mjs'],
  ['canonical syntax + font adapters', 'scripts/run-canonical-syntax.mjs'],
  ['canonical full renderer', 'scripts/run-canonical-full-renderer.mjs'],
  ['production renderer/output coverage', 'scripts/run-production-output-regression.mjs'],
  ['frozen browser-to-Node production parity', 'scripts/run-browser-parity-regression.mjs'],
];

fs.mkdirSync(outputDir, { recursive: true });
const report = [];
const emit = (line = '') => { console.log(line); report.push(line); };

emit('nanpa-linja-n Node.js full reference regression');
emit('==============================================');
emit(`Node.js: ${process.version}`);
emit(`Platform: ${process.platform} ${process.arch}`);
emit(`Working directory: ${root}`);
emit(`Suites configured: ${stages.length}`);
emit('Execution mode: non-fail-fast; every configured suite is attempted');
emit('');

const results = [];
for (const [label, script] of stages) {
  emit(`--- ${label} ---`);
  const started = Date.now();
  const result = spawnSync(process.execPath, ['--import', filter, path.join(root, script)], {
    cwd: root,
    env: process.env,
    encoding: 'utf8',
    maxBuffer: 128 * 1024 * 1024,
  });
  const stdout = result.stdout || '';
  const stderr = result.stderr || '';
  if (stdout) {
    process.stdout.write(stdout);
    report.push(stdout.replace(/\n$/, ''));
  }
  if (stderr) {
    process.stderr.write(stderr);
    report.push(stderr.replace(/\n$/, ''));
  }
  const code = Number.isInteger(result.status) ? result.status : null;
  const ok = !result.error && code === 0;
  const elapsedMs = Date.now() - started;
  if (result.error) emit(`RUNNER ERROR: ${result.error.stack || result.error}`);
  if (result.signal) emit(`SIGNAL: ${result.signal}`);
  emit(`${ok ? 'PASS' : 'FAIL'}: ${label}${code == null ? '' : ` (exit ${code})`} [${elapsedMs} ms]`);
  emit('');
  results.push({ label, script, ok, code, signal: result.signal || null, error: result.error ? String(result.error.stack || result.error) : null, elapsedMs });
}

const failed = results.filter(x => !x.ok);
emit('=== CONSOLIDATED SUMMARY ===');
for (const item of results) emit(`${item.ok ? 'PASS' : 'FAIL'}: ${item.label}`);
emit(`configured suites: ${results.length}`);
emit(`passed suites: ${results.length - failed.length}`);
emit(`failed suites: ${failed.length}`);
if (failed.length) {
  emit('FAILED SUITES:');
  for (const item of failed) emit(` - ${item.label}: ${item.error || item.signal || `exit ${item.code}`}`);
  emit('NODE.JS REGRESSION FAILED');
} else {
  emit('ALL CONFIGURED NODE.JS REFERENCE TESTS PASS');
}
emit(`report: ${path.relative(root, reportPath)}`);

fs.writeFileSync(reportPath, report.join('\n') + '\n', 'utf8');
if (failed.length) process.exitCode = 1;
