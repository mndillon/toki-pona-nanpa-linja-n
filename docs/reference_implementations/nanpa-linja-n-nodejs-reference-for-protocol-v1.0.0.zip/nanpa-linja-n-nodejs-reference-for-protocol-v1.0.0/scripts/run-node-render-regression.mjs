#!/usr/bin/env node
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { installNodePlatform } from '../src/node-platform.js';
import { loadProductionManifest } from './lib/production-assets.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
await installNodePlatform();

globalThis.location.search = '?mode=core';
globalThis.__NANPA_REAL_VECTOR_WASM_URL__ = pathToFileURL(path.join(root, 'assets/wasm/sitelen_vector_wasm.js')).href;

const { manifest } = await loadProductionManifest(root, { required: true });
globalThis.__NANPA_PRODUCTION_MANIFEST__ = manifest;

for (const id of ['stage', 'human', 'nanpa-result-b64']) {
  const el = document.createElement(id === 'stage' ? 'div' : 'pre');
  el.setAttribute('id', id);
  document.body.appendChild(el);
}

await import('../test/node-core-harness.mjs');
const b64 = document.getElementById('nanpa-result-b64')?.textContent || '';
if (!b64) throw new Error('Node core harness emitted no result.');
const result = JSON.parse(Buffer.from(b64, 'base64').toString('utf8'));
console.log(`Node renderer core checks: ${result.checks}`);
console.log(`failures: ${result.failures?.length || 0}`);
for (const note of result.notes || []) console.log(`note: ${note}`);
if (result.status !== 'PASS') {
  for (const failure of result.failures || []) console.error(failure);
  process.exit(1);
}
console.log('PASS');
