#!/usr/bin/env node
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { NanpaLinjaN } from '../src/node.js';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const casesDoc=JSON.parse(await fs.readFile(path.join(root,'fixtures/nodejs-browser-parity-cases.json'),'utf8'));
const expectedDoc=JSON.parse(await fs.readFile(path.join(root,'fixtures/nodejs-browser-parity-v1.json'),'utf8'));
const expectedById=new Map(expectedDoc.cases.map(c=>[c.id,c]));
const tol=Number(expectedDoc.geometryTolerancePx ?? casesDoc.geometryTolerancePx ?? 2.1);
const round=(v)=>Number.isFinite(Number(v))?Math.round(Number(v)*1000)/1000:v;
const nums=(obj,keys)=>Object.fromEntries(keys.filter(k=>obj?.[k]!==undefined).map(k=>[k,round(obj[k])]));
const clean=(v)=>{if(v==null||typeof v==='string'||typeof v==='boolean')return v;if(typeof v==='number')return round(v);if(Array.isArray(v))return v.map(clean);if(typeof v==='object'){const o={};for(const [k,x] of Object.entries(v)){if(k==='_element'||k==='canvas'||k==='ast'||k==='linesElements'||typeof x==='function')continue;o[k]=clean(x)}return o;}return String(v)};
function normRun(r){const semanticKeys=['id','lineIndex','runIndex','kind','renderMode','fontRole','fontFamily','fontPx','sourceText','sourceStart','sourceEnd','sourceKind','sourceSegmentIndex','audioText','sourceTransform','encodedText','canonicalEncodedText','cps','canonicalCps','renderCps','canonicalFullCps','renderFullCps','canonicalToRenderSpans','renderAdapterId','requestedRenderAdapterId','longGlyphPresentation','audioSourceCps','audioSourceIndices','manualTallies','manualTallyLiftPx','manualTallySmallFontMaxPx','imageAlt','isQuoted','interpretedQuote','quoteOpenChar','quoteCloseChar','isUnrecognized','unknownDisplay','fillStyle','halo'];const semantic={};for(const k of semanticKeys)if(r?.[k]!==undefined)semantic[k]=clean(r[k]);const geometry={...nums(r,['xPx','drawXPx','yPx','baselineYPx','widthPx','heightPx','ascentPx','descentPx'])};if(Array.isArray(r?.audioGlyphLayout))geometry.audioGlyphLayout=clean(r.audioGlyphLayout);if(r?.manualTallyLayout)geometry.manualTallyLayout=clean(r.manualTallyLayout);return{semantic,geometry}}
function normPlan(p){return{semantic:{lineCount:(p?.lines||[]).length},geometry:{...nums(p,['widthPx','heightPx','paddingPx','lineGapPx'])},lines:(p?.lines||[]).map(l=>({semantic:clean(Object.fromEntries(['lineIndex','sourceLineIndex','sentenceIndexInSourceLine'].filter(k=>l?.[k]!==undefined).map(k=>[k,l[k]]))),geometry:nums(l,['xPx','yPx','widthPx','heightPx','baselineYPx','ascentPx','descentPx']),runs:(l.runs||[]).map(normRun)}))}}
function equal(a,b){return JSON.stringify(a)===JSON.stringify(b)}
function compareGeometry(actual,expected,path='geometry',failures=[]){
 if(typeof expected==='number'&&typeof actual==='number'){if(Math.abs(actual-expected)>tol)failures.push(`${path}: ${actual} vs ${expected} (>${tol}px)`);return failures;}
 if(Array.isArray(expected)){if(!Array.isArray(actual)){failures.push(`${path}: expected array`);return failures;}if(actual.length!==expected.length)failures.push(`${path}.length: ${actual.length} vs ${expected.length}`);for(let i=0;i<Math.min(actual.length,expected.length);i++)compareGeometry(actual[i],expected[i],`${path}[${i}]`,failures);return failures;}
 if(expected&&typeof expected==='object'){if(!actual||typeof actual!=='object'){failures.push(`${path}: expected object`);return failures;}for(const k of Object.keys(expected))compareGeometry(actual[k],expected[k],`${path}.${k}`,failures);return failures;}
 if(!equal(actual,expected))failures.push(`${path}: ${JSON.stringify(actual)} vs ${JSON.stringify(expected)}`);return failures;
}

const n=await NanpaLinjaN.create();
const failures=[]; let semanticChecks=0, geometryChecks=0;
try{
 for(const tc of casesDoc.cases){
  const exp=expectedById.get(tc.id); if(!exp){failures.push(`${tc.id}: missing expected fixture`);continue;}
  const options={font:tc.font||'nasinNanpa',fontSize:tc.fontSize||56,paddingPx:18};
  if(tc.parser)options.parser=tc.parser;if(tc.layout)options.layout=tc.layout;if(tc.paint)options.paint=tc.paint;if(tc.fonts)options.fonts=tc.fonts;
  const parsed=await n.parse(tc.input,options);const built=await n.buildRenderPlan(tc.input,options);
  const actual={id:tc.id,ast:clean(parsed.ast),plan:normPlan(built.plan),fontKey:built.fontKey,config:clean(built.config)};
  for(const key of ['ast','fontKey','config']){semanticChecks++;if(!equal(actual[key],exp[key]))failures.push(`${tc.id}.${key}: semantic mismatch`);}
  semanticChecks++;if(!equal(actual.plan.semantic,exp.plan.semantic))failures.push(`${tc.id}.plan.semantic: mismatch`);
  if(actual.plan.lines.length!==exp.plan.lines.length)failures.push(`${tc.id}.plan.lines.length: ${actual.plan.lines.length} vs ${exp.plan.lines.length}`);
  for(let li=0;li<Math.min(actual.plan.lines.length,exp.plan.lines.length);li++){
   const A=actual.plan.lines[li],E=exp.plan.lines[li];semanticChecks++;if(!equal(A.semantic,E.semantic))failures.push(`${tc.id}.line[${li}].semantic: mismatch`);
   if(A.runs.length!==E.runs.length)failures.push(`${tc.id}.line[${li}].runs.length: ${A.runs.length} vs ${E.runs.length}`);
   for(let ri=0;ri<Math.min(A.runs.length,E.runs.length);ri++){semanticChecks++;if(!equal(A.runs[ri].semantic,E.runs[ri].semantic))failures.push(`${tc.id}.line[${li}].run[${ri}].semantic: mismatch`);geometryChecks++;compareGeometry(A.runs[ri].geometry,E.runs[ri].geometry,`${tc.id}.line[${li}].run[${ri}].geometry`,failures)}
   geometryChecks++;compareGeometry(A.geometry,E.geometry,`${tc.id}.line[${li}].geometry`,failures);
  }
  geometryChecks++;compareGeometry(actual.plan.geometry,exp.plan.geometry,`${tc.id}.plan.geometry`,failures);
 }
}finally{await n.destroy();}
console.log(`browser parity cases: ${casesDoc.cases.length}/${expectedDoc.caseCount}`);
console.log(`semantic checks: ${semanticChecks}`);console.log(`geometry groups: ${geometryChecks} (tolerance ${tol}px)`);console.log(`failures: ${failures.length}`);
if(failures.length){for(const f of failures.slice(0,100))console.error(`FAIL ${f}`);if(failures.length>100)console.error(`... ${failures.length-100} more`);process.exit(1);}console.log('PASS');
