#!/usr/bin/env node
import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const originalLog = console.log;
const originalTable = console.table;
console.log = () => {};
console.table = () => {};
const { SitelenRenderer } = await import('../src/node.js');

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const corpusPath = path.join(root, 'conformance/canonical-syntax-v1.0.1-phase1/cases.json');
const referencePath = path.join(root, 'reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js');
const data = JSON.parse(await fs.readFile(corpusPath, 'utf8'));
const failures = [];
let passed = 0, adapterPassed = 0;
const adapters = { linjaPona: 'linja-pona-legacy-v1', linjaSike: 'linja-sike-legacy-v1' };
const cps = (values) => (values || []).map(v => typeof v === 'string' && /^U\+/i.test(v) ? Number.parseInt(v.slice(2),16) : Number(v));
const runsFrom = (plan) => (plan?.lines || []).flatMap(line => line.runs || []);
const eq = (a,b) => JSON.stringify(a) === JSON.stringify(b);
const fail = (id,msg) => failures.push(`${id}: ${msg}`);

const actualHash = crypto.createHash('sha256').update(await fs.readFile(referencePath)).digest('hex');
if (actualHash !== data.authority?.sha256) fail('authority', `hash mismatch got ${actualHash} want ${data.authority?.sha256}`);

const renderer = await SitelenRenderer.create({});
try {
  for (const tc of data.cases || []) {
    const local = [];
    try {
      const plan = await renderer.buildRenderPlan({ input: tc.input, parser: { mode: tc.rendererMode } });
      const runs = runsFrom(plan);
      if ('expectedNormalizedInput' in tc && plan.ast?.normalizedInput !== tc.expectedNormalizedInput) local.push(`normalizedInput got ${JSON.stringify(plan.ast?.normalizedInput)} want ${JSON.stringify(tc.expectedNormalizedInput)}`);
      if (tc.expectedRuns) {
        const got = runs.map(r => r.canonicalCps || []), want = tc.expectedRuns.map(cps);
        if (!eq(got,want)) local.push(`runs canonical cps got ${JSON.stringify(got)} want ${JSON.stringify(want)}`);
      } else {
        if (runs.length !== 1) local.push(`run count got ${runs.length} want 1`);
        else {
          const r = runs[0];
          const want = cps(tc.expectedCanonicalCodepoints);
          if (!eq(r.canonicalCps || [],want)) local.push(`canonical cps got ${JSON.stringify(r.canonicalCps || [])} want ${JSON.stringify(want)}`);
          if ('expectedSourceText' in tc && (r.sourceText ?? '') !== tc.expectedSourceText) local.push(`sourceText got ${JSON.stringify(r.sourceText)} want ${JSON.stringify(tc.expectedSourceText)}`);
          if ('expectedFontRole' in tc && r.fontRole !== tc.expectedFontRole) local.push(`fontRole got ${JSON.stringify(r.fontRole)} want ${JSON.stringify(tc.expectedFontRole)}`);
          if ('expectedRenderText' in tc) {
            const wantText = /^U\+/i.test(String(tc.expectedRenderText)) ? String.fromCodePoint(...cps([tc.expectedRenderText])) : tc.expectedRenderText;
            if ((r.encodedText ?? '') !== wantText) local.push(`renderText got ${JSON.stringify(r.encodedText ?? '')} want ${JSON.stringify(wantText)}`);
          }
        }
      }
    } catch (error) { local.push(`${error?.name || 'Error'}: ${error?.stack || error}`); }
    if (local.length) local.forEach(msg => fail(tc.id,msg)); else passed++;
  }

  for (const tc of data.fontAdapterCases || []) {
    const local = [];
    try {
      const plan = await renderer.buildRenderPlan({
        input: tc.input,
        parser: { mode: 'sitelen-pona-ascii-extended' },
        fonts: { renderAdapterId: adapters[tc.font] || 'identity' },
      });
      const runs = runsFrom(plan);
      if (runs.length !== 1) local.push(`run count got ${runs.length} want 1`);
      else {
        const r = runs[0];
        const renderText = r.renderCps ? String.fromCodePoint(...r.renderCps) : (r.encodedText ?? '');
        if ('expectedRenderText' in tc && renderText !== tc.expectedRenderText) local.push(`renderText got ${JSON.stringify(renderText)} want ${JSON.stringify(tc.expectedRenderText)}`);
        if ('expectedRenderCodepoints' in tc && !eq(r.renderCps || [],cps(tc.expectedRenderCodepoints))) local.push(`render cps got ${JSON.stringify(r.renderCps || [])} want ${JSON.stringify(cps(tc.expectedRenderCodepoints))}`);
        if (tc.mustDifferFromCanonicalCodepoints && eq(r.renderCps || [],r.canonicalCps || [])) local.push('render cps did not differ from canonical cps');
      }
    } catch (error) { local.push(`${error?.name || 'Error'}: ${error?.stack || error}`); }
    if (local.length) local.forEach(msg => fail(tc.id,msg)); else adapterPassed++;
  }
} finally {
  console.log = originalLog;
  console.table = originalTable;
}

originalLog(`Canonical syntax cases: ${passed}/${data.cases?.length || 0} PASS`);
originalLog(`Canonical font-adapter cases: ${adapterPassed}/${data.fontAdapterCases?.length || 0} PASS`);
if (failures.length) {
  originalLog(`FAILURES (${failures.length}):`);
  for (const item of failures) originalLog(` - ${item}`);
  process.exit(1);
}
originalLog('CANONICAL SYNTAX + FONT ADAPTER CONFORMANCE PASS');
