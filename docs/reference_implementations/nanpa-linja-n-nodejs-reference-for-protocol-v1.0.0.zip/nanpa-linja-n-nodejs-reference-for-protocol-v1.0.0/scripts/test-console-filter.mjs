// Loaded by the consolidated runner before each child test process. The bundled
// canonical renderer intentionally has always-on diagnostics; suppress only
// those diagnostics so the end-to-end report remains readable and actionable.
const originalLog = console.log.bind(console);
console.log = (...args) => {
  const first = String(args[0] ?? '');
  if (first.startsWith('[nanpa-debug:') || first === '[nanpa-debug] enabled' || first === '[nanpa-debug] disabled' || first === '[nanpa-debug] logs cleared') return;
  originalLog(...args);
};
console.table = () => {};
