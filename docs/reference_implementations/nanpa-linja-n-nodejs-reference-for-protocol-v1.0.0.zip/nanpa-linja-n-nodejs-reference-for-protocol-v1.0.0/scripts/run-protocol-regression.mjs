#!/usr/bin/env node
import fs from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";
import { NanpaParser as parser } from "../src/node.js";

const here = path.dirname(fileURLToPath(import.meta.url));
const defaultCorpus = path.resolve(here, "../fixtures/nanpa-linja-n-regression-v1.0.2.json");
const [corpusArg = defaultCorpus] = process.argv.slice(2);
const corpus = JSON.parse(await fs.readFile(path.resolve(corpusArg), "utf8"));

const failures = [];
let checks = 0;

function fail(id, message, actual, expected) {
  failures.push({ id, message, actual, expected });
}

function equal(a, b) {
  return JSON.stringify(a) === JSON.stringify(b);
}

function containsSubsequence(haystack, needle) {
  if (!Array.isArray(haystack) || !Array.isArray(needle)) return false;
  outer: for (let i = 0; i <= haystack.length - needle.length; i++) {
    for (let j = 0; j < needle.length; j++) {
      if (!equal(haystack[i + j], needle[j])) continue outer;
    }
    return true;
  }
  return false;
}

function assertResult(id, result, spec) {
  for (const [key, expected] of Object.entries(spec ?? {})) {
    if (["result", "notes", "equivalentToInput", "equivalentValue", "numericDomain"].includes(key)) continue;
    checks++;

    if (key === "accepted") {
      if ((result != null) !== Boolean(expected)) fail(id, key, result != null, expected);
      continue;
    }
    if (key === "requiredFields") {
      const missing = (expected ?? []).filter((name) => result == null || !(name in result));
      if (missing.length) fail(id, "requiredFields", missing, expected);
      continue;
    }
    if (key === "absentFields") {
      const present = (expected ?? []).filter((name) => result != null && (name in result));
      if (present.length) fail(id, "absentFields", present, expected);
      continue;
    }
    if (key === "properNameStartsWith") {
      if (typeof result?.properName !== "string" || !result.properName.startsWith(expected)) {
        fail(id, key, result?.properName, expected);
      }
      continue;
    }
    if (key === "tpWordsFirst") {
      if (result?.tpWords?.[0] !== expected) fail(id, key, result?.tpWords?.[0], expected);
      continue;
    }
    if (key === "tpWordsLast") {
      const actual = result?.tpWords?.at?.(-1);
      if (actual !== expected) fail(id, key, actual, expected);
      continue;
    }
    if (key === "tpWordsContainsSubsequence") {
      if (!containsSubsequence(result?.tpWords, expected)) fail(id, key, result?.tpWords, expected);
      continue;
    }
    if (key === "codepointsFirstInner") {
      if (result?.innerCodepoints?.[0] !== expected) fail(id, key, result?.innerCodepoints?.[0], expected);
      continue;
    }
    if (key === "codepointsLastInner") {
      const actual = result?.innerCodepoints?.at?.(-1);
      if (actual !== expected) fail(id, key, actual, expected);
      continue;
    }
    if (key === "cartoucheStart") {
      if (result?.codepoints?.[0] !== expected) fail(id, key, result?.codepoints?.[0], expected);
      continue;
    }
    if (key === "cartoucheEnd") {
      const actual = result?.codepoints?.at?.(-1);
      if (actual !== expected) fail(id, key, actual, expected);
      continue;
    }
    if (key === "resultType") {
      const actual = Array.isArray(result)
        ? (result.every((v) => Number.isInteger(v)) ? "array<int>" : result.every((v) => typeof v === "string") ? "array<string>" : "array")
        : result === null ? "null" : typeof result;
      if (actual !== expected) fail(id, key, actual, expected);
      continue;
    }
    if (key === "nonEmpty") {
      const actual = typeof result === "string" || Array.isArray(result) ? result.length > 0 : Boolean(result);
      if (actual !== expected) fail(id, key, actual, expected);
      continue;
    }
    if (key === "exact") {
      if (!equal(result, expected)) fail(id, key, result, expected);
      continue;
    }

    const actual = result?.[key];
    if (!equal(actual, expected)) fail(id, key, actual, expected);
  }
}

for (const test of corpus.parserCases ?? []) {
  const api = test.api ?? "parseNumber";
  const fn = parser[api];
  if (typeof fn !== "function") {
    checks++;
    fail(test.id, `missing API ${api}`, typeof fn, "function");
    continue;
  }
  let result;
  try {
    result = fn.call(parser, test.input, test.options ?? {});
  } catch (error) {
    checks++;
    fail(test.id, "API threw", String(error?.stack ?? error), "no throw");
    continue;
  }
  const accept = test.assert?.result === "accept";
  checks++;
  if ((result != null) !== accept) {
    fail(test.id, "accept/reject", result != null ? "accept" : "reject", test.assert?.result);
    continue;
  }
  if (result != null) assertResult(test.id, result, test.assert);
}

for (const test of [...(corpus.rendererCases ?? []), ...(corpus.apiCases ?? [])]) {
  const fn = parser[test.api];
  checks++;
  if (typeof fn !== "function") {
    fail(test.id, `missing API ${test.api}`, typeof fn, "function");
    continue;
  }
  let result;
  try {
    result = fn.call(parser, test.input, test.options ?? {});
  } catch (error) {
    fail(test.id, "API threw", String(error?.stack ?? error), "no throw");
    continue;
  }
  assertResult(test.id, result, test.assert);
}

for (const group of corpus.equivalenceGroups ?? []) {
  const api = group.api ?? "parseNumber";
  const fn = parser[api];
  if (typeof fn !== "function") {
    checks++;
    fail(group.id, `missing API ${api}`, typeof fn, "function");
    continue;
  }
  const options = group.options ?? {};
  const parsed = group.members.map((input) => ({ input, result: fn.call(parser, input, options) }));
  const base = parsed[0];
  for (const field of group.compare ?? []) {
    const expected = base?.result?.[field];
    for (const item of parsed.slice(1)) {
      checks++;
      const actual = item.result?.[field];
      if (!equal(actual, expected)) {
        fail(group.id, `${field}: ${base.input} vs ${item.input}`, actual, expected);
      }
    }
  }
}

console.log(`nanpa-linja-n regression checks: ${checks}`);
console.log(`failures: ${failures.length}`);
if (failures.length) {
  for (const item of failures.slice(0, 100)) {
    console.error(`\n[${item.id}] ${item.message}`);
    console.error("  actual:  ", JSON.stringify(item.actual));
    console.error("  expected:", JSON.stringify(item.expected));
  }
  if (failures.length > 100) console.error(`\n... ${failures.length - 100} more failure(s)`);
  process.exit(1);
}

console.log("PASS");
