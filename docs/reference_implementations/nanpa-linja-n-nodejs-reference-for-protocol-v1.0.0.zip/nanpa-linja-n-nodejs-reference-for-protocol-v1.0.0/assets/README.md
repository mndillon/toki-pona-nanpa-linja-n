# Production asset layout

The Node.js reference uses one canonical packaged font bundle plus the same vector WASM as the browser JavaScript reference.

```text
resources/
└── fonts.zip
    └── fonts/preloaded-font-pairs.manifest.json  (inside the ZIP)

assets/
└── wasm/
    ├── sitelen_vector_wasm.js
    └── sitelen_vector_wasm_bg.wasm
```

By default Node reads `resources/fonts.zip` directly using its built-in runtime APIs and materializes only manifest-referenced fonts into temporary files when required by `skia-canvas`. No external ZIP package or exploded production font directory is required.

For compatibility, `NANPA_FONT_DIR` may still be set to test an external unpacked copy of the same font set.
