# Production asset layout

The Node.js reference uses the same production font manifest and vector WASM as the canonical browser JavaScript reference.

```text
assets/
├── fonts/
│   ├── preloaded-font-pairs.manifest.json
│   ├── <base fonts referenced by the manifest>
│   ├── <companion fonts referenced by the manifest>
│   └── <literal-cartouche fonts referenced by the manifest, if any>
└── wasm/
    ├── sitelen_vector_wasm.js
    └── sitelen_vector_wasm_bg.wasm
```

By default these bundled files are used. To test an external font directory, set `NANPA_FONT_DIR` before starting Node or running the audit scripts.
