import { createRequire } from 'node:module';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const require = createRequire(import.meta.url);
const {
  Canvas,
  Image,
  ImageData,
  Path2D,
  DOMMatrix,
  DOMPoint,
  DOMRect,
  FontLibrary,
  CanvasRenderingContext2D,
} = require('skia-canvas');

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DEFAULT_FONT_DIR = path.join(ROOT, 'assets', 'fonts');
const DEFAULT_MANIFEST = path.join(DEFAULT_FONT_DIR, 'preloaded-font-pairs.manifest.json');
const DEFAULT_WASM = path.join(ROOT, 'assets', 'wasm', 'sitelen_vector_wasm.js');
const PATCH_FLAG = Symbol.for('nanpa-linja-n.node-platform.installed');
const fontAliases = globalThis.__NANPA_NODE_FONT_ALIASES__ || new Map();
globalThis.__NANPA_NODE_FONT_ALIASES__ = fontAliases;
const projectFontFamilies = globalThis.__NANPA_NODE_PROJECT_FONT_FAMILIES__ || new Set();
globalThis.__NANPA_NODE_PROJECT_FONT_FAMILIES__ = projectFontFamilies;
const temporaryFontFiles = globalThis.__NANPA_NODE_TEMP_FONT_FILES__ || new Set();
globalThis.__NANPA_NODE_TEMP_FONT_FILES__ = temporaryFontFiles;

function mimeFor(p) {
  const ext = path.extname(String(p || '')).toLowerCase();
  if (ext === '.json') return 'application/json';
  if (ext === '.wasm') return 'application/wasm';
  if (ext === '.js' || ext === '.mjs') return 'text/javascript';
  if (ext === '.svg') return 'image/svg+xml';
  if (ext === '.png') return 'image/png';
  if (ext === '.ttf') return 'font/ttf';
  if (ext === '.otf') return 'font/otf';
  if (ext === '.woff') return 'font/woff';
  if (ext === '.woff2') return 'font/woff2';
  return 'application/octet-stream';
}

function stripQuery(url) {
  const i = String(url).indexOf('?');
  return i >= 0 ? String(url).slice(0, i) : String(url);
}

class NodeElement {
  constructor(tagName = 'div', documentRef = null) {
    this.tagName = String(tagName).toUpperCase();
    this.ownerDocument = documentRef;
    this.style = {};
    this.attributes = {};
    this.children = [];
    this.classList = { add() {}, remove() {}, toggle() {}, contains() { return false; } };
    this.value = '';
    this.checked = false;
    this.disabled = false;
    this.textContent = '';
    this.files = [];
    this.href = '';
    this.download = '';
    this.name = '';
    this.id = '';
  }
  get options() { return this.children; }
  setAttribute(name, value) {
    const k = String(name);
    const v = String(value);
    this.attributes[k] = v;
    if (k === 'id') { this.id = v; this.ownerDocument?._elements?.set(v, this); }
    else if (k === 'value') this.value = v;
    else if (k === 'name') this.name = v;
    else if (k === 'href') this.href = v;
    else if (k === 'checked') this.checked = true;
  }
  getAttribute(name) { return this.attributes[String(name)] ?? null; }
  appendChild(child) { this.children.push(child); return child; }
  append(...children) { for (const child of children) this.appendChild(child); }
  remove() {}
  click() {}
  focus() {}
  select() {}
  addEventListener() {}
  removeEventListener() {}
  dispatchEvent() { return true; }
  setPointerCapture() {}
  releasePointerCapture() {}
  getBoundingClientRect() { return { left: 0, top: 0, right: 0, bottom: 0, width: 0, height: 0 }; }
  set innerHTML(html) {
    this._innerHTML = String(html ?? '');
    // The canonical renderer creates a fixed hidden UI scaffold at startup. Node
    // only needs the controls to exist; their event handlers are inert.
    const re = /<(canvas|input|select|textarea|button|a|div|label|option)([^>]*)>/gi;
    let m;
    let currentSelect = null;
    while ((m = re.exec(this._innerHTML))) {
      const tag = m[1].toLowerCase();
      const attrs = m[2] || '';
      const el = this.ownerDocument?.createElement(tag) || new NodeElement(tag, this.ownerDocument);
      const id = /\bid=["']([^"']+)["']/.exec(attrs)?.[1];
      const value = /\bvalue=["']([^"']*)["']/.exec(attrs)?.[1];
      const name = /\bname=["']([^"']+)["']/.exec(attrs)?.[1];
      if (id) {
        if (typeof el.setAttribute === 'function') el.setAttribute('id', id);
        else { el.id = id; this.ownerDocument?._elements?.set(id, el); }
      }
      if (value !== undefined) el.value = value;
      if (name) el.name = name;
      if (/\bchecked\b/i.test(attrs)) el.checked = true;
      if (/\bdisabled\b/i.test(attrs)) el.disabled = true;
      if (tag === 'select') currentSelect = el;
      else if (tag === 'option' && currentSelect) currentSelect.appendChild(el);
      this.children.push(el);
    }
  }
  get innerHTML() { return this._innerHTML || ''; }
}

class NodeDocument {
  constructor() {
    this._elements = new Map();
    this.body = new NodeElement('body', this);
    this.documentElement = new NodeElement('html', this);
    this.documentElement.dataset = {};
    this.fonts = null;
  }
  createElement(tagName) {
    const tag = String(tagName).toLowerCase();
    if (tag === 'canvas') {
      const canvas = new Canvas(1, 1);
      canvas.style = canvas.style || {};
      return canvas;
    }
    return new NodeElement(tag, this);
  }
  getElementById(id) { return this._elements.get(String(id)) || null; }
  querySelectorAll(selector) {
    const s = String(selector);
    if (/input\[name=["']?nlMode["']?\]/.test(s)) {
      return [...this._elements.values()].filter((el) => el?.name === 'nlMode');
    }
    return [];
  }
  querySelector(selector) {
    const s = String(selector);
    if (/input\[name=["']?nlMode["']?\]:checked/.test(s)) {
      return [...this._elements.values()].find((el) => el?.name === 'nlMode' && el.checked) || null;
    }
    if (s.startsWith('#')) return this.getElementById(s.slice(1));
    return null;
  }
}

function parseFontFaceSource(source) {
  const m = /url\(["']?(.*?)["']?\)/i.exec(String(source || ''));
  return m?.[1] || '';
}

async function urlToFontFile(url, format = '') {
  const raw = stripQuery(url);
  if (raw.startsWith('file:')) return fileURLToPath(raw);
  if (/^(blob:|data:|https?:)/i.test(raw)) {
    const response = await globalThis.fetch(raw);
    if (!response.ok) throw new Error(`Could not load font ${url}: ${response.status}`);
    const bytes = Buffer.from(await response.arrayBuffer());
    const ext = String(format || '').toLowerCase().includes('open') ? '.otf'
      : String(format || '').toLowerCase().includes('woff2') ? '.woff2'
      : String(format || '').toLowerCase().includes('woff') ? '.woff'
      : '.ttf';
    const filename = path.join(os.tmpdir(), `nanpa-node-font-${process.pid}-${Date.now()}-${Math.random().toString(36).slice(2)}${ext}`);
    await fs.writeFile(filename, bytes);
    temporaryFontFiles.add(filename);
    return filename;
  }
  return path.resolve(raw);
}

class NodeFontFace {
  constructor(family, source, descriptors = {}) {
    this.family = String(family || '');
    this.source = source;
    this.descriptors = descriptors || {};
    this.status = 'unloaded';
  }
  async load() {
    const url = parseFontFaceSource(this.source);
    if (!url) throw new Error(`Unsupported FontFace source for ${this.family}`);
    const format = /format\(["']?(.*?)["']?\)/i.exec(String(this.source || ''))?.[1] || '';
    const file = await urlToFontFile(url, format);
    FontLibrary.use(this.family, file);
    projectFontFamilies.add(this.family);
    const featureSettings = String(this.descriptors?.featureSettings || '');
    const ss = /["']ss(\d{2})["']\s+1/i.exec(featureSettings)?.[1];
    if (ss) fontAliases.set(this.family, `styleset(${Number(ss)})`);
    this.status = 'loaded';
    return this;
  }
}

function installContextFontFeatureBridge() {
  if (CanvasRenderingContext2D.prototype.__nanpaFontBridgeInstalled) return;
  const originalFont = Object.getOwnPropertyDescriptor(CanvasRenderingContext2D.prototype, 'font');
  if (!originalFont?.get || !originalFont?.set) return;
  const originalMeasureText = CanvasRenderingContext2D.prototype.measureText;
  const originalFillText = CanvasRenderingContext2D.prototype.fillText;
  const originalStrokeText = CanvasRenderingContext2D.prototype.strokeText;

  function projectMetrics(ctx, text) {
    const metrics = originalMeasureText.call(ctx, text);
    if (!ctx.__nanpaProjectFont) return { metrics, offsetX: 0 };
    const line = Array.isArray(metrics?.lines) && metrics.lines.length === 1 ? metrics.lines[0] : null;
    const shapedWidth = Number(line?.width);
    const offsetX = Number(line?.x);
    if (!Number.isFinite(shapedWidth) || shapedWidth <= 0 || !Number.isFinite(offsetX)) return { metrics, offsetX: 0 };
    // skia-canvas exposes the browser-equivalent shaped run in lines[0], while
    // TextMetrics.width/right include unshaped side advances for several sitelen
    // fonts. Chromium's Canvas metrics track the shaped run. Return a plain
    // TextMetrics-compatible record with those browser-equivalent horizontal metrics.
    const out = {};
    for (const key of [
      'actualBoundingBoxAscent','actualBoundingBoxDescent','fontBoundingBoxAscent','fontBoundingBoxDescent',
      'emHeightAscent','emHeightDescent','hangingBaseline','alphabeticBaseline','ideographicBaseline','lines'
    ]) {
      try { out[key] = metrics[key]; } catch {}
    }
    // Chromium and Skia agree on advance width. Skia exposes the shaped ink
    // run separately as lines[0] with an x offset; Chromium exposes the same
    // geometry through actualBoundingBoxLeft/Right. Preserve the advance width
    // (required for canonical prefix/glyph positioning) and translate only the
    // horizontal ink bounds.
    out.width = Number(metrics.width);
    out.actualBoundingBoxLeft = -offsetX;
    out.actualBoundingBoxRight = offsetX + shapedWidth;
    return { metrics: out, offsetX: 0 };
  }

  Object.defineProperty(CanvasRenderingContext2D.prototype, 'font', {
    configurable: true,
    enumerable: originalFont.enumerable,
    get: originalFont.get,
    set(value) {
      const text = String(value ?? '');
      originalFont.set.call(this, text);
      this.__nanpaProjectFont = [...projectFontFamilies].some((family) => text.includes(family));
      let variant = null;
      for (const [family, mappedVariant] of fontAliases.entries()) {
        if (text.includes(family)) { variant = mappedVariant; break; }
      }
      if (variant) {
        try { this.fontVariant = variant; } catch {}
      }
    },
  });
  CanvasRenderingContext2D.prototype.measureText = function measureTextNanpa(text) {
    return projectMetrics(this, text).metrics;
  };
  CanvasRenderingContext2D.prototype.fillText = function fillTextNanpa(text, x, y, maxWidth) {
    const { offsetX } = projectMetrics(this, text);
    return maxWidth === undefined
      ? originalFillText.call(this, text, Number(x) - offsetX, y)
      : originalFillText.call(this, text, Number(x) - offsetX, y, maxWidth);
  };
  CanvasRenderingContext2D.prototype.strokeText = function strokeTextNanpa(text, x, y, maxWidth) {
    const { offsetX } = projectMetrics(this, text);
    return maxWidth === undefined
      ? originalStrokeText.call(this, text, Number(x) - offsetX, y)
      : originalStrokeText.call(this, text, Number(x) - offsetX, y, maxWidth);
  };
  Object.defineProperty(CanvasRenderingContext2D.prototype, '__nanpaFontBridgeInstalled', { value: true });
}

function installCanvasBlobExport() {
  if (typeof Canvas.prototype.toBlob === 'function') return;
  Object.defineProperty(Canvas.prototype, 'toBlob', {
    configurable: true,
    value(callback, type = 'image/png', quality = undefined) {
      const mime = String(type || 'image/png').toLowerCase();
      const format = mime.includes('jpeg') || mime.includes('jpg') ? 'jpg'
        : mime.includes('webp') ? 'webp'
        : mime.includes('svg') ? 'svg'
        : mime.includes('pdf') ? 'pdf'
        : 'png';
      Promise.resolve(this.toBuffer(format, quality == null ? undefined : { quality }))
        .then((buffer) => callback(new Blob([buffer], { type: mime })))
        .catch(() => callback(null));
    },
  });
}


function createMemoryIndexedDb() {
  const databases = new Map();
  class MemoryDb {
    constructor(name) { this.name = name; this.stores = databases.get(name) || new Map(); databases.set(name, this.stores); }
    get objectStoreNames() { return { contains: (name) => this.stores.has(String(name)) }; }
    createObjectStore(name) { const key = String(name); if (!this.stores.has(key)) this.stores.set(key, new Map()); return this.stores.get(key); }
    transaction(name) {
      const db = this; const storeName = String(name);
      if (!db.stores.has(storeName)) db.stores.set(storeName, new Map());
      const tx = { oncomplete: null, onerror: null, objectStore() {
        const store = db.stores.get(storeName);
        return {
          get(key) { const req = { result: undefined, error: null, onsuccess: null, onerror: null }; queueMicrotask(() => { try { req.result = store.get(key); req.onsuccess?.({ target: req }); queueMicrotask(() => tx.oncomplete?.({ target: tx })); } catch (e) { req.error = e; req.onerror?.({ target: req }); tx.onerror?.({ target: tx }); } }); return req; },
          getAll() { const req = { result: undefined, error: null, onsuccess: null, onerror: null }; queueMicrotask(() => { try { req.result = [...store.values()]; req.onsuccess?.({ target: req }); queueMicrotask(() => tx.oncomplete?.({ target: tx })); } catch (e) { req.error = e; req.onerror?.({ target: req }); tx.onerror?.({ target: tx }); } }); return req; },
          put(value, key) { const req = { result: key, error: null, onsuccess: null, onerror: null }; queueMicrotask(() => { try { const effectiveKey = key ?? value?.key ?? value?.id; if (effectiveKey === undefined) throw new Error('Memory IndexedDB put requires a key'); store.set(effectiveKey, value); req.result = effectiveKey; req.onsuccess?.({ target: req }); queueMicrotask(() => tx.oncomplete?.({ target: tx })); } catch (e) { req.error = e; req.onerror?.({ target: req }); tx.onerror?.({ target: tx }); } }); return req; },
          delete(key) { const req = { result: undefined, error: null, onsuccess: null, onerror: null }; queueMicrotask(() => { try { store.delete(key); req.onsuccess?.({ target: req }); queueMicrotask(() => tx.oncomplete?.({ target: tx })); } catch (e) { req.error = e; req.onerror?.({ target: req }); tx.onerror?.({ target: tx }); } }); return req; },
          clear() { const req = { result: undefined, error: null, onsuccess: null, onerror: null }; queueMicrotask(() => { try { store.clear(); req.onsuccess?.({ target: req }); queueMicrotask(() => tx.oncomplete?.({ target: tx })); } catch (e) { req.error = e; req.onerror?.({ target: req }); tx.onerror?.({ target: tx }); } }); return req; },
        };
      } };
      return tx;
    }
    close() {}
  }
  return {
    open(name) {
      const key = String(name); const isNew = !databases.has(key);
      const req = { result: null, error: null, onupgradeneeded: null, onsuccess: null, onerror: null };
      queueMicrotask(() => {
        try { req.result = new MemoryDb(key); if (isNew) req.onupgradeneeded?.({ target: req }); queueMicrotask(() => req.onsuccess?.({ target: req })); }
        catch (e) { req.error = e; req.onerror?.({ target: req }); }
      });
      return req;
    },
  };
}

function installWindowAndDom() {
  const document = globalThis.document instanceof NodeDocument ? globalThis.document : new NodeDocument();
  globalThis.document = document;
  globalThis.window = globalThis;
  globalThis.Image = Image;
  globalThis.ImageData = globalThis.ImageData || ImageData;
  globalThis.Path2D = globalThis.Path2D || Path2D;
  globalThis.DOMMatrix = globalThis.DOMMatrix || DOMMatrix;
  globalThis.DOMPoint = globalThis.DOMPoint || DOMPoint;
  globalThis.DOMRect = globalThis.DOMRect || DOMRect;
  globalThis.FontFace = NodeFontFace;
  globalThis.CustomEvent = globalThis.CustomEvent || class CustomEvent {
    constructor(type, init = {}) { this.type = type; this.detail = init.detail; }
  };
  globalThis.localStorage = globalThis.localStorage || {
    _data: new Map(),
    getItem(k) { return this._data.has(String(k)) ? this._data.get(String(k)) : null; },
    setItem(k, v) { this._data.set(String(k), String(v)); },
    removeItem(k) { this._data.delete(String(k)); },
    clear() { this._data.clear(); },
  };
  globalThis.requestAnimationFrame = globalThis.requestAnimationFrame || ((fn) => setTimeout(() => fn(Date.now()), 0));
  globalThis.cancelAnimationFrame = globalThis.cancelAnimationFrame || ((id) => clearTimeout(id));
  globalThis.addEventListener = globalThis.addEventListener || (() => {});
  globalThis.removeEventListener = globalThis.removeEventListener || (() => {});
  globalThis.dispatchEvent = globalThis.dispatchEvent || (() => true);
  globalThis.innerWidth = globalThis.innerWidth || 1920;
  globalThis.innerHeight = globalThis.innerHeight || 1080;
  globalThis.location = globalThis.location || new URL(pathToFileURL(path.join(ROOT, 'index.html')).href);
  globalThis.alert = globalThis.alert || (() => {});
  globalThis.indexedDB = globalThis.indexedDB || createMemoryIndexedDb();
  // The canonical advanced render-run API falls back to this browser-global
  // helper when a run has no explicit fill style. The browser application
  // normally supplies it; Node provides the same default foreground here.
  globalThis.getFgHex = globalThis.getFgHex || (() => '#000000');
  document.fonts = {
    add() {},
    async load() { return [{}]; },
    ready: Promise.resolve(),
  };
}

function installFetch() {
  if (globalThis.__NANPA_NODE_FETCH_INSTALLED__) return;
  const nativeFetch = globalThis.fetch?.bind(globalThis);
  globalThis.fetch = async (resource, init) => {
    const raw = typeof resource === 'string' || resource instanceof URL
      ? String(resource)
      : String(resource?.url || resource);
    if (raw.startsWith('file:')) {
      try {
        const file = fileURLToPath(stripQuery(raw));
        const bytes = await fs.readFile(file);
        return new Response(bytes, { status: 200, headers: { 'content-type': mimeFor(file) } });
      } catch (error) {
        return new Response(String(error?.message || error), { status: 404 });
      }
    }
    if (raw.startsWith('./fonts/')) {
      const file = path.join(process.env.NANPA_FONT_DIR || DEFAULT_FONT_DIR, path.basename(stripQuery(raw)));
      try {
        const bytes = await fs.readFile(file);
        return new Response(bytes, { status: 200, headers: { 'content-type': mimeFor(file) } });
      } catch (error) {
        return new Response(String(error?.message || error), { status: 404 });
      }
    }
    if (!/^[a-zA-Z][a-zA-Z+.-]*:/.test(raw)) {
      let file;
      if (raw.startsWith('../fixtures/')) file = path.join(ROOT, 'fixtures', raw.slice('../fixtures/'.length));
      else if (raw.startsWith('../mock/')) file = path.join(ROOT, 'mock', raw.slice('../mock/'.length));
      else if (raw.startsWith('../assets/')) file = path.join(ROOT, 'assets', raw.slice('../assets/'.length));
      else file = path.resolve(ROOT, raw);
      try {
        const bytes = await fs.readFile(file);
        return new Response(bytes, { status: 200, headers: { 'content-type': mimeFor(file) } });
      } catch {}
    }
    if (!nativeFetch) throw new Error(`No fetch implementation for ${raw}`);
    return nativeFetch(resource, init);
  };
  globalThis.__NANPA_NODE_FETCH_INSTALLED__ = true;
}

async function installAssetOverrides({ fontDir = process.env.NANPA_FONT_DIR || DEFAULT_FONT_DIR } = {}) {
  const manifestPath = path.join(fontDir, 'preloaded-font-pairs.manifest.json');
  const effectiveManifest = await fs.stat(manifestPath).then(() => manifestPath).catch(() => DEFAULT_MANIFEST);
  const manifest = JSON.parse(await fs.readFile(effectiveManifest, 'utf8'));
  const assetUrls = {};
  for (const pair of manifest?.pairs || []) {
    const key = String(pair?.fontKey || '').trim();
    if (!key) continue;
    for (const [role, field] of [['base', 'baseUrl'], ['companion', 'companionUrl'], ['literalCartouche', 'literalCartoucheUrl']]) {
      const raw = pair?.[field];
      if (!raw) continue;
      const file = path.join(fontDir, path.basename(String(raw)));
      assetUrls[`${key}:${role}`] = pathToFileURL(file).href;
    }
  }
  globalThis.__NANPA_FONT_ASSET_URLS__ = assetUrls;
  globalThis.__NANPA_DEFAULT_MANIFEST_URL__ = pathToFileURL(effectiveManifest).href;
  globalThis.__NANPA_DEFAULT_VECTOR_WASM_URL__ = pathToFileURL(DEFAULT_WASM).href;
  return { manifest, manifestPath: effectiveManifest, fontDir };
}

export async function installNodePlatform(options = {}) {
  if (!globalThis[PATCH_FLAG]) {
    installContextFontFeatureBridge();
    installCanvasBlobExport();
    installWindowAndDom();
    installFetch();
    globalThis[PATCH_FLAG] = true;
  }
  return await installAssetOverrides(options);
}

export async function cleanupNodePlatformTemporaryFiles() {
  for (const file of [...temporaryFontFiles]) {
    try { await fs.unlink(file); } catch {}
    temporaryFontFiles.delete(file);
  }
}

export { Canvas, Image, FontLibrary, ROOT as NODE_REFERENCE_ROOT };
