import { installNodePlatform } from './node-platform.js';

await installNodePlatform();

const facade = await import('./node-facade.js');

export const {
  NanpaLinjaN,
  NanpaParser,
  SitelenRenderer,
  SitelenVectorExporter,
  createSitelenFontPairController,
  TEXT_FONT_OPTION_SITELEN,
  DEFAULT_FONT_KEY,
  DEFAULT_FONT_SIZE,
  DEFAULT_TEXT_FONT_OPTION,
  DEFAULT_PARSER_CONFIG,
  astToText,
  parseNumber,
} = facade;

export { installNodePlatform } from './node-platform.js';
export default facade.NanpaLinjaN;
