import { installNodePlatform } from './node-platform.js';
await installNodePlatform();
export { SitelenRenderer, NanpaParser } from '../reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js';
export { createSitelenFontPairController, TEXT_FONT_OPTION_SITELEN, TEXT_FONT_OPTION_NANPA_LINJA_N } from '../reference/sitelen-font-pair-controller.js';
export { SitelenVectorExporter } from '../reference/sitelen-vector-exporter.js';
