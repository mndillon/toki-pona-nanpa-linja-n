import { SitelenRenderer, NanpaParser } from '../reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js';
import {
  createSitelenFontPairController,
  TEXT_FONT_OPTION_SITELEN,
} from '../reference/sitelen-font-pair-controller.js';
import { SitelenVectorExporter } from '../reference/sitelen-vector-exporter.js';

export const DEFAULT_FONT_KEY = 'nasinNanpa';
export const DEFAULT_FONT_SIZE = 56;
export const DEFAULT_TEXT_FONT_OPTION = TEXT_FONT_OPTION_SITELEN;
export const DEFAULT_MANIFEST_URL = globalThis.__NANPA_DEFAULT_MANIFEST_URL__ || '';
export const DEFAULT_VECTOR_WASM_URL =
  globalThis.__NANPA_DEFAULT_VECTOR_WASM_URL__
  || new URL('../assets/wasm/sitelen_vector_wasm.js', import.meta.url).href;

export const DEFAULT_PARSER_CONFIG = Object.freeze({
  mode: 'sitelen-pona-ascii-extended',
  numericMode: 'uniform',
  relaxedNanpaLinjanParsing: true,
  relaxedNanpaLinjanRendering: true,
  nanpaColonParsing: true,
  nanpaColonRendering: true,
  enableHexParsing: true,
  enableBinaryParsing: true,
});

function clone(value) {
  return value == null ? value : structuredClone(value);
}

function cleanString(value, fallback = '') {
  const text = String(value ?? '').trim();
  return text || fallback;
}

function normalizeBoolean(value, fallback = false) {
  return typeof value === 'boolean' ? value : fallback;
}

function deepMerge(base = {}, extra = {}) {
  const out = clone(base) || {};
  for (const [key, value] of Object.entries(extra || {})) {
    if (
      value && typeof value === 'object' && !Array.isArray(value)
      && out[key] && typeof out[key] === 'object' && !Array.isArray(out[key])
    ) {
      out[key] = deepMerge(out[key], value);
    } else {
      out[key] = clone(value);
    }
  }
  return out;
}

function ensureArray(value) {
  return Array.isArray(value) ? value : [];
}

function normalizeFontAlias(value) {
  return String(value ?? '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '');
}

function startsWithXmlMime(type) {
  return String(type || '').toLowerCase().startsWith('image/svg+xml');
}

function byteArrayStartsWith(bytes, expected) {
  if (!(bytes instanceof Uint8Array) || bytes.length < expected.length) return false;
  for (let i = 0; i < expected.length; i++) {
    if (bytes[i] !== expected[i]) return false;
  }
  return true;
}

async function blobToUint8Array(blob) {
  const buf = await blob.arrayBuffer();
  return new Uint8Array(buf);
}

function resolveAssetOverrideUrl(pair, role) {
  const assetUrls = globalThis.__NANPA_FONT_ASSET_URLS__;
  if (!assetUrls || typeof assetUrls !== 'object') return null;
  const key = `${cleanString(pair?.fontKey)}:${cleanString(role)}`;
  return cleanString(assetUrls[key], '');
}

function buildSupportFontFaces(manifest, manifestUrl) {
  const assetUrls = globalThis.__NANPA_FONT_ASSET_URLS__;
  const out = {};
  for (const [role, record] of Object.entries(manifest?.supportFonts || {})) {
    const override = cleanString(assetUrls?.[`support:${role}`], '');
    let url = override;
    if (!url && cleanString(record?.url || record?.fontUrl)) url = new URL(String(record.url || record.fontUrl), manifestUrl).href;
    if (!url && cleanString(record?.filename) && cleanString(manifestUrl)) url = new URL(String(record.filename), manifestUrl).href;
    if (!url) continue;
    out[role] = {
      role,
      family: cleanString(record?.family),
      url,
      format: cleanString(record?.format),
      filename: cleanString(record?.filename),
      sample: cleanString(record?.sample),
    };
  }
  return out;
}

function resolveAssetUrl(rawUrl, manifestUrl, pair, role) {
  const override = resolveAssetOverrideUrl(pair, role);
  if (override) return override;
  if (!cleanString(rawUrl)) return '';
  return new URL(String(rawUrl), manifestUrl).href;
}

function makeFace({ family, url, format, sample }) {
  const out = {
    family: cleanString(family),
    url: cleanString(url),
    format: cleanString(format),
  };
  const normalizedSample = cleanString(sample);
  if (normalizedSample) out.sample = normalizedSample;
  return out.family && out.url ? out : null;
}

function pairToPreset(pair, manifestUrl, supportFonts = null) {
  const baseFace = makeFace({
    family: pair?.baseFamily,
    url: resolveAssetUrl(pair?.baseUrl, manifestUrl, pair, 'base'),
    format: pair?.baseFormat,
    sample: pair?.baseSample,
  });
  const companionFace = makeFace({
    family: pair?.companionFamily,
    url: resolveAssetUrl(pair?.companionUrl, manifestUrl, pair, 'companion'),
    format: pair?.companionFormat,
    sample: pair?.companionSample,
  });
  const literalCartoucheFace = makeFace({
    family: pair?.literalCartoucheFamily || pair?.literalCartoucheFontFamily,
    url: resolveAssetUrl(pair?.literalCartoucheUrl, manifestUrl, pair, 'literalCartouche'),
    format: pair?.literalCartoucheFormat,
    sample: pair?.literalCartoucheSample,
  });

  const faces = [baseFace, companionFace, literalCartoucheFace].filter(Boolean);
  const literalTextFace = supportFonts?.literalText;
  if (literalTextFace?.url) {
    faces.push({
      family: 'Patrick-Head-Font',
      url: literalTextFace.url,
      format: literalTextFace.format || 'truetype',
      sample: literalTextFace.sample || 'Hello',
    });
  }
  return {
    key: cleanString(pair?.fontKey),
    label: cleanString(pair?.label, cleanString(pair?.fontKey)),
    textFamily: cleanString(pair?.baseFamily || pair?.textFamily || pair?.fontKey),
    cartoucheFamily: cleanString(pair?.companionFamily || pair?.cartoucheFamily || `${pair?.fontKey}-nanpa-linja-n`),
    literalCartoucheFamily: cleanString(pair?.literalCartoucheFamily || pair?.literalCartoucheFontFamily || pair?.baseFamily || pair?.textFamily || pair?.fontKey),
    parserMode: cleanString(pair?.parserMode, DEFAULT_PARSER_CONFIG.mode),
    renderAdapterId: cleanString(pair?.renderAdapterId, 'identity'),
    renderAdapterSettings: clone(pair?.renderAdapterSettings || {}),
    settings: clone(pair?.settings || {}),
    faces,
    __pairRecord: clone(pair),
  };
}

function buildRegistryFromManifest(manifest, manifestUrl, supportFonts = null) {
  const registry = {};
  for (const pair of ensureArray(manifest?.pairs)) {
    const preset = pairToPreset(pair, manifestUrl, supportFonts);
    if (!preset.key) continue;
    registry[preset.key] = preset;
  }
  return registry;
}

async function fetchJson(url) {
  const res = await fetch(url, { cache: 'no-store' });
  if (!res.ok) throw new Error(`Could not load ${url}: ${res.status}`);
  return await res.json();
}

function registrySummary(registry) {
  return Object.values(registry || {}).map((preset) => ({
    key: preset.key,
    label: cleanString(preset.label, preset.key),
    textFamily: preset.textFamily,
    cartoucheFamily: preset.cartoucheFamily,
    literalCartoucheFamily: preset.literalCartoucheFamily,
    parserMode: preset.parserMode,
    renderAdapterId: preset.renderAdapterId || 'identity',
  }));
}

async function canvasToBlob(canvas, type = 'image/png', quality = undefined) {
  if (canvas && typeof canvas.toBlob === 'function') {
    const blob = await new Promise((resolve) => canvas.toBlob(resolve, type, quality));
    if (blob) return blob;
  }
  if (canvas && typeof canvas.toDataURL === 'function') {
    const dataUrl = canvas.toDataURL(type, quality);
    const comma = dataUrl.indexOf(',');
    const payload = comma >= 0 ? dataUrl.slice(comma + 1) : dataUrl;
    const bytes = Uint8Array.from(atob(payload), (c) => c.charCodeAt(0));
    return new Blob([bytes], { type });
  }
  throw new Error('Canvas export is not available in this browser environment.');
}


function quoteImageArgument(value) {
  const text = String(value ?? '');
  if (!text.includes("'")) return `'${text}'`;
  if (!text.includes('"')) return `"${text}"`;
  // The renderer's img(...) parser understands backslash-escaped quote
  // delimiters while scanning. This final fallback keeps the source valid;
  // callers that require literal quote characters in image metadata should
  // prefer values that do not contain both quote styles.
  return `"${text.replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"`;
}

function imageAstValueToText(value = {}) {
  const desc = (value && typeof value === 'object') ? value : {};
  const args = [];
  const src = String(desc.src ?? '');
  if (src) args.push(`src=${quoteImageArgument(src)}`);
  if (desc.w != null && String(desc.w) !== '') args.push(`w=${quoteImageArgument(desc.w)}`);
  if (desc.h != null && String(desc.h) !== '') args.push(`h=${quoteImageArgument(desc.h)}`);
  if (desc.alt != null) args.push(`alt=${quoteImageArgument(desc.alt)}`);
  if (desc.valign != null && String(desc.valign) !== '' && String(desc.valign) !== 'baseline') {
    args.push(`valign=${quoteImageArgument(desc.valign)}`);
  }
  if (desc.wriggle != null && Number(desc.wriggle) !== 8) {
    const wriggle = Number(desc.wriggle);
    args.push(`wriggle=${Number.isFinite(wriggle) ? String(wriggle) : quoteImageArgument(desc.wriggle)}`);
  }
  if (desc.transparent === false) args.push('transparent=false');
  return `img(${args.join(',')})`;
}

const NUMERIC_OUTPUT_MODES = Object.freeze(new Set(['source', 'properName', '#~', 'cartouche']));

function parserOptionsForTextConversion(ast, options = {}) {
  let parser = clone(DEFAULT_PARSER_CONFIG) || {};
  if (ast?.parserOptions && typeof ast.parserOptions === 'object') parser = deepMerge(parser, ast.parserOptions);
  if (options?.config?.parser && typeof options.config.parser === 'object') parser = deepMerge(parser, options.config.parser);
  if (options?.parser && typeof options.parser === 'object') parser = deepMerge(parser, options.parser);
  return parser;
}

function numericOutputModeFromOptions(options = {}) {
  const mode = String(options?.numericOutput ?? 'source');
  if (!NUMERIC_OUTPUT_MODES.has(mode)) {
    throw new RangeError(`Unsupported numericOutput mode: ${mode}`);
  }
  return mode;
}

function prefersAbbreviatedNumericCartouches(parser = {}) {
  return parser.abbreviateNumericCartouches === true ||
    parser.numericCartoucheAbbreviation === true ||
    parser.abbreviatedNumericCartouches === true;
}

function numericSourceToText(sourceText, numericOutput, parser) {
  const source = String(sourceText ?? '');
  if (numericOutput === 'source') return source;

  const parsed = NanpaParser.parseNumber(source, parser || {});
  if (!parsed) return source;

  if (
    parser?.nasinNanpaPona === true &&
    Array.isArray(parsed.nasinNanpaPonaWords) &&
    parsed.nasinNanpaPonaWords.length > 0
  ) {
    return parsed.nasinNanpaPonaWords.join(' ');
  }

  if (numericOutput === 'properName') {
    return parsed.properName != null && String(parsed.properName) !== ''
      ? String(parsed.properName)
      : source;
  }

  if (numericOutput === '#~') {
    const uniqueCode = String(parsed.uniqueCode ?? '');
    return uniqueCode.startsWith('#~') ? uniqueCode : source;
  }

  if (numericOutput === 'cartouche') {
    const abbreviated = prefersAbbreviatedNumericCartouches(parser);
    const words = abbreviated ? parsed.abbreviatedWords : parsed.tpWords;
    return Array.isArray(words) && words.length > 0
      ? `[${words.join(' ')}]`
      : source;
  }

  return source;
}

function applyNumericStructuresToSerializedSource(sourceText, segment, options = {}, ast = null) {
  const source = String(sourceText ?? '');
  const numericOutput = numericOutputModeFromOptions(options);
  if (numericOutput === 'source') return source;

  const structures = Array.isArray(segment?.numericStructures) ? segment.numericStructures : [];
  if (!structures.length) return source;
  const parser = parserOptionsForTextConversion(ast, options);

  const valid = structures
    .map((structure) => ({
      structure,
      index: Number(structure?.index),
      end: Number(structure?.end),
      sourceText: String(structure?.sourceText ?? ''),
    }))
    .filter(({ index, end, sourceText: expected }) =>
      Number.isInteger(index) && Number.isInteger(end) && index >= 0 && end > index && end <= source.length &&
      expected.length === (end - index) && source.slice(index, end) === expected
    )
    .sort((a, b) => a.index - b.index || a.end - b.end);

  if (!valid.length) return source;

  let output = '';
  let position = 0;
  for (const item of valid) {
    if (item.index < position) continue;
    output += source.slice(position, item.index);
    output += numericSourceToText(item.sourceText, numericOutput, parser);
    position = item.end;
  }
  output += source.slice(position);
  return output;
}

function astSegmentSourceText(segment) {
  if (!segment || typeof segment !== 'object') {
    throw new TypeError('AST segment must be an object.');
  }
  if (segment.kind === 'text') return String(segment.value ?? '');
  if (segment.kind === 'bracket') return `[${String(segment.value ?? '')}]`;
  if (segment.kind === 'quote') {
    const openQuote = String(segment.openQuote || '"');
    const defaultClose = openQuote === '“' ? '”' : '"';
    const closeQuote = String(segment.closeQuote || defaultClose);
    return `${openQuote}${String(segment.value ?? '')}${closeQuote}`;
  }
  if (segment.kind === 'image') return imageAstValueToText(segment.value);
  if (segment.kind === 'rawUcsur') {
    const cps = Array.isArray(segment.cps) ? segment.cps : [];
    return cps.map((cp) => {
      const n = Number(cp);
      if (!Number.isInteger(n) || n < 0 || n > 0x10FFFF || (n >= 0xD800 && n <= 0xDFFF)) {
        throw new TypeError(`Invalid rawUcsur code point: ${cp}`);
      }
      return `U+${n.toString(16).toUpperCase().padStart(4, '0')}`;
    }).join(' ');
  }
  throw new TypeError(`Unsupported AST segment kind: ${String(segment.kind)}`);
}

function astSegmentToText(segment, options = {}, ast = null) {
  const source = astSegmentSourceText(segment);
  return applyNumericStructuresToSerializedSource(source, segment, options, ast);
}

function astLineToText(line, options = {}, ast = null) {
  if (!line || typeof line !== 'object') throw new TypeError('AST line must be an object.');
  const children = Array.isArray(line.children) ? line.children : [];
  return children.map((segment) => astSegmentToText(segment, options, ast)).join('');
}

/**
 * Convert a document AST returned by parse() back into valid nanpa-linja-n text.
 *
 * With the default numericOutput='source', serialization remains source-preserving.
 * When numericOutput is explicitly set to 'properName', '#~', or 'cartouche', numeric spans identified by parse() are re-serialized through
 * NanpaParser.parseNumber() using the supplied parser options. Existing numeric
 * formatting flags (including nasinNanpaPona and cartouche abbreviation flags)
 * continue to determine the selected representation. If a requested representation
 * is unavailable, the exact numeric source text is preserved.
 */
export function astToText(ast, options = {}) {
  if (!ast || typeof ast !== 'object' || !Array.isArray(ast.lines)) {
    throw new TypeError('astToText() expects a document AST with a lines array.');
  }
  numericOutputModeFromOptions(options);
  let output = '';
  let havePrevious = false;
  let previousSourceLineIndex = null;

  for (let i = 0; i < ast.lines.length; i++) {
    const line = ast.lines[i];
    const currentText = astLineToText(line, options, ast);
    const rawSourceLineIndex = Number(line?.sourceLineIndex);
    const hasSourceLineIndex = Number.isInteger(rawSourceLineIndex) && rawSourceLineIndex >= 0;
    const currentSourceLineIndex = hasSourceLineIndex ? rawSourceLineIndex : i;

    if (havePrevious && currentSourceLineIndex !== previousSourceLineIndex) output += '\n';
    output += currentText;
    havePrevious = true;
    previousSourceLineIndex = currentSourceLineIndex;
  }
  return output;
}

export function parseNumber(input, options = {}) {
  let parser = clone(DEFAULT_PARSER_CONFIG) || {};
  if (options?.config?.parser && typeof options.config.parser === 'object') parser = deepMerge(parser, options.config.parser);
  if (options?.parser && typeof options.parser === 'object') parser = deepMerge(parser, options.parser);
  else if (options && typeof options === 'object' && !('config' in options)) parser = deepMerge(parser, options);
  return NanpaParser.parseNumber(input, parser);
}

function renderConfigFromOptions(baseConfig, options = {}) {
  let config = clone(baseConfig) || {};
  if (options.config) config = deepMerge(config, options.config);
  if (options.layout) config = deepMerge(config, { layout: options.layout });
  if (options.paint) config = deepMerge(config, { paint: options.paint });
  if (options.parser) config = deepMerge(config, { parser: options.parser });
  if (options.fonts) config = deepMerge(config, { fonts: options.fonts });
  if (Number.isFinite(Number(options.fontSize))) config = deepMerge(config, { layout: { fontPx: Number(options.fontSize) } });
  if (Number.isFinite(Number(options.paddingPx))) config = deepMerge(config, { layout: { paddingPx: Number(options.paddingPx) } });
  return config;
}

class NanpaLinjaNFacade {
  static async create(options = {}) {
    const instance = new NanpaLinjaNFacade(options);
    await instance.ready;
    return instance;
  }

  constructor(options = {}) {
    this.options = clone(options) || {};
    this.manifestUrl = cleanString(options.manifestUrl, cleanString(globalThis.__NANPA_DEFAULT_MANIFEST_URL__, DEFAULT_MANIFEST_URL));
    this.vectorWasmUrl = cleanString(options.vectorWasmUrl, cleanString(globalThis.__NANPA_DEFAULT_VECTOR_WASM_URL__, DEFAULT_VECTOR_WASM_URL));
    this.defaultFontKey = cleanString(options.defaultFont || options.defaultFontKey, DEFAULT_FONT_KEY);
    this.defaultTextFontOption = cleanString(options.defaultTextFontOption, DEFAULT_TEXT_FONT_OPTION);
    this.defaultFontSize = Number.isFinite(Number(options.defaultFontSize)) ? Math.max(8, Number(options.defaultFontSize)) : DEFAULT_FONT_SIZE;
    this.storageKeyPrefix = cleanString(options.storageKeyPrefix, 'nanpaFacade');
    this.baseRenderConfig = {
      layout: { fontPx: this.defaultFontSize },
      parser: clone(DEFAULT_PARSER_CONFIG),
    };
    if (options.baseRenderConfig) this.baseRenderConfig = deepMerge(this.baseRenderConfig, options.baseRenderConfig);
    this.registry = null;
    this.registryList = [];
    this.manifest = null;
    this.supportFonts = {};
    this.controller = null;
    this.renderer = null;
    this.vectorExporter = null;
    this._queue = Promise.resolve();
    this.ready = this.#initialize();
  }

  async #initialize() {
    if (!this.manifestUrl) throw new Error('Node font resources are not initialized. Import the package through src/node.js or call installNodePlatform() first.');
    this.manifest = await fetchJson(this.manifestUrl);
    this.supportFonts = buildSupportFontFaces(this.manifest, this.manifestUrl);
    this.registry = buildRegistryFromManifest(this.manifest, this.manifestUrl, this.supportFonts);
    if (!Object.keys(this.registry).length) throw new Error('No production font pairs were found in the manifest.');
    if (!this.registry[this.defaultFontKey]) this.defaultFontKey = Object.keys(this.registry)[0];
    this.registryList = registrySummary(this.registry);
    this.controller = createSitelenFontPairController({
      registry: this.registry,
      defaultPresetKey: this.defaultFontKey,
      defaultTextFontOption: this.defaultTextFontOption,
      storageKeyPrefix: this.storageKeyPrefix,
    });
    await this.controller.ready;
    this.controller.setActivePreset(this.defaultFontKey, { persist: false });
    if (typeof this.controller.setSelectedTextFontOption === 'function') {
      this.controller.setSelectedTextFontOption(this.defaultTextFontOption, { persist: false });
    }
    this.renderer = await SitelenRenderer.create({});
    return this;
  }

  get fonts() {
    return this.listFonts();
  }

  listFonts() {
    return clone(this.registryList) || [];
  }

  getFontInfo(font) {
    const key = this.normalizeFontKey(font);
    const info = this.registryList.find((entry) => entry.key === key);
    return info ? clone(info) : null;
  }

  normalizeFontKey(font) {
    const requested = cleanString(font, this.defaultFontKey);
    if (this.registry?.[requested]) return requested;
    const alias = normalizeFontAlias(requested);
    const entries = Object.values(this.registry || {});
    const match = entries.find((preset) => {
      const candidates = [preset.key, preset.label, preset.textFamily, preset.cartoucheFamily];
      return candidates.some((value) => normalizeFontAlias(value) === alias);
    });
    if (match?.key) return match.key;
    throw new Error(`Unknown production font key: ${requested}`);
  }

  async #withLock(fn) {
    const previous = this._queue;
    let release;
    this._queue = new Promise((resolve) => {
      release = resolve;
    });
    await previous;
    try {
      return await fn();
    } finally {
      release();
    }
  }

  async #ensureVectorExporter() {
    if (this.vectorExporter) return this.vectorExporter;
    this.vectorExporter = await SitelenVectorExporter.create({
      renderer: this.renderer,
      fontController: this.controller,
      wasmModuleUrl: this.vectorWasmUrl,
      supportFonts: this.supportFonts,
    });
    return this.vectorExporter;
  }

  async #resolveContext(options = {}) {
    await this.ready;
    const fontKey = this.normalizeFontKey(options.font || options.fontKey || this.defaultFontKey);
    const textFontOptionKey = cleanString(options.textFontOption, this.defaultTextFontOption);
    this.controller.setActivePreset(fontKey, { persist: false });
    if (typeof this.controller.setSelectedTextFontOption === 'function') {
      this.controller.setSelectedTextFontOption(textFontOptionKey, { persist: false });
    }
    const preset = this.controller.getPresetByKey(fontKey);
    if (!preset) throw new Error(`Could not resolve preset for font ${fontKey}`);
    const baseConfig = renderConfigFromOptions(this.baseRenderConfig, options);
    if (!baseConfig.parser) baseConfig.parser = {};
    baseConfig.parser.mode = cleanString(baseConfig.parser.mode, cleanString(preset.parserMode, DEFAULT_PARSER_CONFIG.mode));
    const config = this.controller.buildRendererConfig({
      textFontOptionKey,
      preset,
      baseConfig,
    });
    const fontPx = Number(config?.layout?.fontPx ?? this.defaultFontSize) || this.defaultFontSize;
    await this.controller.waitForConfiguredFonts(fontPx);
    return {
      fontKey,
      textFontOptionKey,
      preset,
      config,
    };
  }

  async parse(input, options = {}) {
    return await this.#withLock(async () => {
      const context = await this.#resolveContext(options);
      const parsed = await this.renderer.parseInput({
        input,
        parser: context.config.parser,
      });
      return {
        ...parsed,
        input,
        fontKey: context.fontKey,
        preset: clone(context.preset),
        config: clone(context.config),
      };
    });
  }

  astToText(ast, options = {}) {
    return astToText(ast, options);
  }

  parseNumber(input, options = {}) {
    let parser = clone(this.baseRenderConfig?.parser || DEFAULT_PARSER_CONFIG) || {};
    if (options?.config?.parser && typeof options.config.parser === 'object') parser = deepMerge(parser, options.config.parser);
    if (options?.parser && typeof options.parser === 'object') parser = deepMerge(parser, options.parser);
    else if (options && typeof options === 'object' && !('config' in options)) parser = deepMerge(parser, options);
    return NanpaParser.parseNumber(input, parser);
  }

  async buildRenderPlan(input, options = {}) {
    return await this.#withLock(async () => {
      const context = await this.#resolveContext(options);
      const plan = await this.renderer.buildRenderPlan({
        input,
        layout: context.config.layout,
        paint: context.config.paint,
        parser: context.config.parser,
        fonts: context.config.fonts,
      });
      return {
        input,
        plan,
        fontKey: context.fontKey,
        preset: clone(context.preset),
        config: clone(context.config),
      };
    });
  }

  async render(input, options = {}) {
    const format = cleanString(options.format, 'canvas').toLowerCase();
    if (format === 'canvas') return await this.renderToCanvas(input, options);
    if (format === 'png') return await this.renderToPng(input, options);
    if (format === 'svg') return await this.renderToSvg(input, options);
    if (format === 'pdf') return await this.renderToPdf(input, options);
    throw new Error(`Unsupported render format: ${format}`);
  }

  async renderToCanvas(input, options = {}) {
    return await this.#withLock(async () => {
      const context = await this.#resolveContext(options);
      const rendered = await this.renderer.renderTextToNewCanvas({
        input,
        layout: context.config.layout,
        paint: context.config.paint,
        parser: context.config.parser,
        fonts: context.config.fonts,
      });
      const includePlan = normalizeBoolean(options.includePlan, true);
      const plan = includePlan
        ? await this.renderer.buildRenderPlan({
            input,
            ast: rendered.ast,
            layout: context.config.layout,
            paint: context.config.paint,
            parser: context.config.parser,
            fonts: context.config.fonts,
          })
        : null;
      const canvas = rendered?.canvas || rendered;
      return {
        kind: 'canvas',
        input,
        canvas,
        width: Number(canvas?.width || 0),
        height: Number(canvas?.height || 0),
        ast: rendered?.ast || null,
        linesElements: rendered?.linesElements || null,
        plan,
        fontKey: context.fontKey,
        preset: clone(context.preset),
        config: clone(context.config),
      };
    });
  }

  async renderToPng(input, options = {}) {
    const canvasResult = await this.renderToCanvas(input, options);
    const blob = await canvasToBlob(canvasResult.canvas, 'image/png', options.quality);
    const bytes = await blobToUint8Array(blob);
    if (!byteArrayStartsWith(bytes, Uint8Array.from([137, 80, 78, 71, 13, 10, 26, 10]))) {
      throw new Error('PNG export did not produce a valid PNG signature.');
    }
    return {
      ...canvasResult,
      kind: 'png',
      blob,
      bytes,
    };
  }

  async renderToSvg(input, options = {}) {
    return await this.#withLock(async () => {
      const context = await this.#resolveContext(options);
      const exporter = await this.#ensureVectorExporter();
      const blob = await exporter.exportTextToSvgBlob({
        input,
        config: context.config,
        paddingPx: Number.isFinite(Number(options.paddingPx)) ? Number(options.paddingPx) : 18,
      });
      const svg = await blob.text();
      if (!startsWithXmlMime(blob.type) || !svg.includes('<svg')) {
        throw new Error('SVG export did not produce a valid SVG payload.');
      }
      return {
        kind: 'svg',
        input,
        blob,
        svg,
        fontKey: context.fontKey,
        preset: clone(context.preset),
        config: clone(context.config),
      };
    });
  }

  async renderToPdf(input, options = {}) {
    return await this.#withLock(async () => {
      const context = await this.#resolveContext(options);
      const exporter = await this.#ensureVectorExporter();
      const blob = await exporter.exportTextToPdfBlob({
        input,
        config: context.config,
        paddingPx: Number.isFinite(Number(options.paddingPx)) ? Number(options.paddingPx) : 18,
      });
      const bytes = await blobToUint8Array(blob);
      const header = new TextDecoder().decode(bytes.slice(0, 8));
      if (blob.type !== 'application/pdf' || !header.startsWith('%PDF-1.')) {
        throw new Error('PDF export did not produce a valid PDF payload.');
      }
      return {
        kind: 'pdf',
        input,
        blob,
        bytes,
        fontKey: context.fontKey,
        preset: clone(context.preset),
        config: clone(context.config),
      };
    });
  }

  async destroy() {
    if (this.controller?.destroy) this.controller.destroy();
    this.vectorExporter = null;
  }
}

export { NanpaParser, SitelenRenderer, SitelenVectorExporter, createSitelenFontPairController, TEXT_FONT_OPTION_SITELEN };
export const NanpaLinjaN = NanpaLinjaNFacade;
export default NanpaLinjaNFacade;
