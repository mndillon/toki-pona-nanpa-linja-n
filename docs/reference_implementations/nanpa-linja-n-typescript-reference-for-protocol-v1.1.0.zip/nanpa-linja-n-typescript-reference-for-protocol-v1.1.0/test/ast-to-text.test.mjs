import assert from 'node:assert/strict';
import { astToText, parseNumber } from '../dist/index.js';

let checks = 0;
function pass(name, fn) {
  fn();
  checks++;
  console.log(`PASS astToText ${name}`);
}

pass('named exports exist', () => {
  assert.equal(typeof astToText, 'function');
  assert.equal(typeof parseNumber, 'function');
});

pass('preserves spaces, tabs, blank lines, brackets, and quote delimiters', () => {
  const ast = {
    lines: [
      { sourceLineIndex: 0, children: [
        { kind: 'text', value: 'jan\t  pona ' },
        { kind: 'bracket', value: ' jan  pona,, ' },
        { kind: 'text', value: '  ' },
        { kind: 'quote', value: 'toki  pona', openQuote: '“', closeQuote: '”' },
      ] },
      { sourceLineIndex: 1, children: [] },
      { sourceLineIndex: 2, children: [{ kind: 'text', value: 'pini' }] },
    ],
  };
  assert.equal(astToText(ast), 'jan\t  pona [ jan  pona,, ]  “toki  pona”\n\npini');
});

pass('rejoins sentence-split AST lines sharing one physical source line', () => {
  const ast = { lines: [
    { sourceLineIndex: 0, sentenceIndexInSourceLine: 0, children: [{ kind: 'text', value: 'jan li pona.' }] },
    { sourceLineIndex: 0, sentenceIndexInSourceLine: 1, children: [{ kind: 'text', value: ' ona li pona.' }] },
    { sourceLineIndex: 1, children: [{ kind: 'text', value: 'pini' }] },
  ] };
  assert.equal(astToText(ast), 'jan li pona. ona li pona.\npini');
});

pass('serializes an edited bracket value', () => {
  const ast = { lines: [{ sourceLineIndex: 0, children: [{ kind: 'bracket', value: ' jan  pona,, ' }] }] };
  ast.lines[0].children[0].value = ' jan  suno,, ';
  assert.equal(astToText(ast), '[ jan  suno,, ]');
});

pass('serializes straight quotes with stored delimiters', () => {
  const ast = { lines: [{ children: [{ kind: 'quote', value: 'jan pona', openQuote: '"', closeQuote: '"' }] }] };
  assert.equal(astToText(ast), '"jan pona"');
});

pass('serializes image descriptors canonically', () => {
  const ast = { lines: [{ children: [{ kind: 'image', value: { src: 'a.png', w: '50', alt: 'test', valign: 'center', wriggle: 4, transparent: false } }] }] };
  assert.equal(astToText(ast), "img(src='a.png',w='50',alt='test',valign='center',wriggle=4,transparent=false)");
});

pass('serializes raw UCSUR codepoints', () => {
  const ast = { lines: [{ children: [{ kind: 'rawUcsur', cps: [0xF1900, 0x300C] }] }] };
  assert.equal(astToText(ast), 'U+F1900 U+300C');
});

pass('rejects invalid raw UCSUR codepoints', () => {
  const ast = { lines: [{ children: [{ kind: 'rawUcsur', cps: [0x110000] }] }] };
  assert.throws(() => astToText(ast), /Invalid rawUcsur code point/);
});

pass('rejects non-document AST values', () => {
  assert.throws(() => astToText({}), /expects a document AST/);
});

function makeNumericAst(value, structures, parserOptions = {}) {
  return {
    type: 'document',
    parserOptions: {
      numericMode: 'uniform',
      relaxedNanpaLinjanParsing: true,
      relaxedNanpaLinjanRendering: true,
      nanpaColonParsing: true,
      nanpaColonRendering: true,
      enableHexParsing: true,
      enableBinaryParsing: true,
      ...parserOptions,
    },
    lines: [{
      sourceLineIndex: 0,
      children: [{ kind: 'text', value, numericStructures: structures }],
    }],
  };
}

pass('public parseNumber returns canonical alternative representations', () => {
  const parsed = parseNumber('123');
  assert.equal(parsed?.displayValue, '123');
  assert.equal(parsed?.properName, 'Nanpa Watusen');
  assert.equal(parsed?.uniqueCode, '#~WTS');
  assert.equal(parsed?.abbreviatedWords, undefined);
});

pass('parseNumber rejects internal whitespace in digit-based numeric syntax', () => {
  for (const source of [
    '12 34',
    '12 .34',
    '12. 34',
    '12 %',
    '1 e8',
    '1 *10^8',
    '1* 10^8',
    '1 * 10 ^ 8',
    '1 /2',
    '1/ 2',
    '1 +1/2',
    '1+ 1/2',
    '2026- 09-20',
    '12: 30',
  ]) {
    assert.equal(parseNumber(source), null, source);
  }
});

pass('parseNumber permits outer whitespace around one complete numeric expression', () => {
  assert.equal(parseNumber('  1234  ')?.displayValue, '1234');
});

pass('proper-name and numeric-cartouche parsers retain intentional spaces', () => {
  const proper = parseNumber('Nanpa Wan Eke Tusenan Eke Lunumun');
  assert.equal(proper?.displayValue, '1,234,567');

  const cartouche = parseNumber('[nanpa : wan tu seli nanpa]', {
    abbreviateNumericCartouches: true,
  });
  assert.equal(cartouche?.displayValue, '123');
});

pass('numericOutput source preserves numeric source exactly', () => {
  const ast = makeNumericAst('mi jo e 123', [{ index: 8, end: 11, sourceText: '123' }]);
  assert.equal(astToText(ast, { numericOutput: 'source' }), 'mi jo e 123');
});

pass('numericOutput properName emits nanpa-linja-n proper name', () => {
  const ast = makeNumericAst('mi jo e 123', [{ index: 8, end: 11, sourceText: '123' }]);
  assert.equal(astToText(ast, { numericOutput: 'properName' }), 'mi jo e Nanpa Watusen');
});

pass('numericOutput #~ emits numeric abbreviation when available', () => {
  const ast = makeNumericAst('mi jo e 123', [{ index: 8, end: 11, sourceText: '123' }]);
  assert.equal(astToText(ast, { numericOutput: '#~' }), 'mi jo e #~WTS');
});

pass('numericOutput #~ preserves source when representation is unavailable', () => {
  const ast = makeNumericAst('#ABC 0b1010', [
    { index: 0, end: 4, sourceText: '#ABC' },
    { index: 5, end: 11, sourceText: '0b1010' },
  ]);
  assert.equal(astToText(ast, { numericOutput: '#~' }), '#ABC 0b1010');
});

pass('numericOutput cartouche emits abbreviated cartouche by v1.1 default', () => {
  const ast = makeNumericAst('123', [{ index: 0, end: 3, sourceText: '123' }], { abbreviateNumericCartouches: true });
  assert.equal(astToText(ast, { numericOutput: 'cartouche' }), '[nanpa : wan tu seli nanpa]');
});

pass('numericOutput cartouche can explicitly request the full cartouche', () => {
  const ast = makeNumericAst('123', [{ index: 0, end: 3, sourceText: '123' }]);
  assert.equal(astToText(ast, { numericOutput: 'cartouche', parser: { abbreviateNumericCartouches: false } }), '[nanpa : wan ala tu uta seli e nanpa]');
});

pass('numericOutput cartouche respects numeric cartouche abbreviation flag', () => {
  const ast = makeNumericAst('123', [{ index: 0, end: 3, sourceText: '123' }]);
  assert.equal(
    astToText(ast, { numericOutput: 'cartouche', parser: { abbreviateNumericCartouches: true } }),
    '[nanpa : wan tu seli nanpa]'
  );
});

pass('nasinNanpaPona emits ordinary toki pona where applicable', () => {
  const ast = makeNumericAst('123', [{ index: 0, end: 3, sourceText: '123' }]);
  assert.equal(
    astToText(ast, { numericOutput: 'cartouche', parser: { nasinNanpaPona: true } }),
    'wan ale mute tu wan'
  );
});

pass('nasinNanpaPona takes precedence over #~ output where applicable', () => {
  const ast = makeNumericAst('123', [{ index: 0, end: 3, sourceText: '123' }]);
  assert.equal(
    astToText(ast, { numericOutput: '#~', parser: { nasinNanpaPona: true } }),
    'wan ale mute tu wan'
  );
});

pass('abbreviated mixed-fraction cartouche preserves the kin delimiter', () => {
  const ast = makeNumericAst('1+1/2', [{ index: 0, end: 5, sourceText: '1+1/2' }]);
  assert.equal(
    astToText(ast, {
      numericOutput: 'cartouche',
      parser: {
        abbreviateNumericCartouches: true,
        preserveNumericCartoucheBreaksInAbbreviation: true,
      },
    }),
    '[nanpa : wan kin wan o o tu nanpa]'
  );
});

pass('multiple numeric structures are transformed without changing surrounding text', () => {
  const ast = makeNumericAst('a 123 b 45 c', [
    { index: 2, end: 5, sourceText: '123' },
    { index: 8, end: 10, sourceText: '45' },
  ]);
  assert.equal(astToText(ast, { numericOutput: '#~' }), 'a #~WTS b #~AL c');
});

pass('stale numeric metadata does not rewrite edited text', () => {
  const ast = makeNumericAst('124', [{ index: 0, end: 3, sourceText: '123' }]);
  assert.equal(astToText(ast, { numericOutput: 'properName' }), '124');
});

pass('rejects unsupported numericOutput values', () => {
  const ast = makeNumericAst('123', [{ index: 0, end: 3, sourceText: '123' }]);
  assert.throws(() => astToText(ast, { numericOutput: 'abbreviation' }), /Unsupported numericOutput mode/);
});

console.log(`TypeScript astToText regression: ${checks} PASS`);
