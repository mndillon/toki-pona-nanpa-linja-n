# nanpa-linja-n TypeScript reference implementation — Protocol v1.1.0

Version: **1.1.0**  
Protocol target: **nanpa-linja-n Protocol v1.1.0**  
Runtime requirement: **Node.js 20+** for the supplied qualification tooling.

This package is the strongly typed TypeScript reference facade over the exact canonical JavaScript parser/renderer used by the Protocol v1.1.0 JavaScript reference implementation. TypeScript supplies declarations, typed wrappers, runtime validation, package entry points, and TypeScript-specific conformance tests; parser/rendering semantics remain implemented by the bundled canonical JavaScript.

## Protocol v1.1.0 behavior

The bundled default parser configuration is:

```ts
{
  mode: "sitelen-pona-ascii-extended",
  numericMode: "uniform",
  relaxedNanpaLinjanParsing: true,
  relaxedNanpaLinjanRendering: true,
  nanpaColonParsing: true,
  nanpaColonRendering: true,
  abbreviateNumericCartouches: true,
  preserveNumericCartoucheBreaksInAbbreviation: false,
  breakLinesAtFullStops: false,
  interpretDoubleQuotesAsTeTo: false,
  numericCartoucheStartGlyph: null,
  enableHexParsing: false,
  enableBinaryParsing: false,
  enableBinaryRendering: false,
  nasinNanpaPona: false
}
```

Protocol-v1.1 functionality exposed through the typed facade includes:

- the full 35-operation `NanpaParser` API;
- `parseNumber()` and `astToText()` numeric transformations;
- `numericOutput: "source" | "properName" | "#~" | "cartouche"`;
- abbreviated numeric cartouches by default, with explicit full-cartouche output available;
- strict token boundaries for digit-based numeric syntax: whitespace terminates a numeric token;
- standard and extended sitelen pona ASCII parser modes;
- `&`, `-`, and `+` compound operators;
- optional quote interpretation through `interpretDoubleQuotesAsTeTo`;
- opt-in hexadecimal and binary parsing/rendering;
- date/time semantic openers and numeric-cartouche start-glyph control;
- public font render adapters with canonical-to-render codepoint mappings;
- synthetic U+300C/U+300D corner-bracket support where required by legacy fonts;
- per-font vulgar-fraction cartouche scale controls `¼`, `⅓`, `½`, `⅔`, `¾`;
- production font-pair settings, manual-tally modes, and current legacy-font adapters;
- PNG raster export plus vector SVG/PDF export.

The legacy automatic `ss12`/`ss13`/`ss14` cartouche-scaling route is not active in Protocol v1.1.0. Current production fonts use the v1.1 inline scaling/profile behavior.

## Main TypeScript API

```ts
import {
  NanpaLinjaN,
  NanpaParser,
  astToText,
  parseNumber,
  type NanpaParserOptions,
  type FontRenderAdapter,
} from "nanpa-linja-n-typescript";

const parsedNumber = parseNumber("123");
console.log(parsedNumber?.properName); // Nanpa Watusen

const nanpa = await NanpaLinjaN.create();
const parsed = await nanpa.parse("toki&pona 123");

console.log(nanpa.astToText(parsed.ast, {
  numericOutput: "properName",
}));

const png = await nanpa.renderToPng("123", {
  font: "linjaPona",
  fontSize: 56,
});

await nanpa.destroy();
```

### `parseNumber()`

The public numeric parser accepts direct parser options or the facade-style `{ parser, config }` wrapper.

```ts
parseNumber("123");
parseNumber("#ABC", { enableHexParsing: true });
parseNumber("0b10101", {
  enableBinaryParsing: true,
  enableBinaryRendering: true,
});
```

Hexadecimal and binary recognition are intentionally **off by default** in v1.1.0.

### `astToText()`

```ts
const parsed = await nanpa.parse("mi jo e 123");

nanpa.astToText(parsed.ast, { numericOutput: "source" });
nanpa.astToText(parsed.ast, { numericOutput: "properName" });
nanpa.astToText(parsed.ast, { numericOutput: "#~" });
nanpa.astToText(parsed.ast, { numericOutput: "cartouche" });
nanpa.astToText(parsed.ast, {
  numericOutput: "cartouche",
  parser: { abbreviateNumericCartouches: false },
});
```

The default `cartouche` serialization is abbreviated in Protocol v1.1.0.

## Render adapters

`SitelenRenderer` exposes the typed adapter surface:

```ts
SitelenRenderer.registerRenderAdapter(id, adapter);
SitelenRenderer.unregisterRenderAdapter(id);
SitelenRenderer.hasRenderAdapter(id);
SitelenRenderer.getDefaultRenderAdapterId();
```

Built-in production adapters include:

- `identity`
- `linja-pona-legacy-v1`
- `linja-sike-legacy-v1`
- `nasin-sitelen-pu-mono-v1`
- `linja-lipamanka-v1`

The TypeScript declaration includes `FontRenderAdapter`, `FontRenderAdapterContext`, `FontRenderAdapterResult`, `CanonicalToRenderSpan`, and synthetic-corner-bracket metadata.

## Production fonts

The exact user-supplied `fonts.zip` is preserved at:

```text
resources/fonts.zip
```

SHA-256:

```text
08d0409e0b180a6b90a0617fe557fd3e59a08dd26781d907ed5d772a9fefcae1
```

The runtime consumes the unpacked production tree under `runtime/assets/fonts/`. It contains the same supplied font bytes. The manifest-requested file:

```text
nanpa-linja-n-nasin-nanpa-liberation-sans-literal.ttf
```

is not present as a separately named file inside the supplied ZIP; the runtime therefore contains it as a byte-identical compatibility copy of the supplied `LiberationSans-Regular.ttf`. The qualification suite checks that identity explicitly.

The production manifest contains eight font pairs and Protocol-v1.1 render-adapter/settings metadata.

## Package entry points

```text
nanpa-linja-n-typescript
nanpa-linja-n-typescript/runtime
nanpa-linja-n-typescript/advanced
nanpa-linja-n-typescript/reference/renderer
nanpa-linja-n-typescript/reference/font-controller
nanpa-linja-n-typescript/reference/vector-exporter
```

The `/runtime` and `/reference/*` TypeScript wrappers are tested for exact export identity against the bundled canonical JavaScript modules.

## Build and test

From the extracted package directory:

```bash
node --version
tsc --version
npm test
```

No fail-fast behavior is used by the consolidated runner. Every configured suite is attempted and the report is written to:

```text
test-output/typescript-regression-report.txt
```

Useful individual commands:

```bash
npm run build
npm run typecheck
npm run test:types
npm run verify:runtime
npm run test:exports
npm run test:unit
npm run test:ast
npm run test:profile
npm run test:fonts
npm run test:protocol
npm run test:canonical-syntax
npm run test:canonical-renderer
npm run test:browser
```

See `TESTING.md` and `CONFORMANCE.md` for the qualification details.

## Vector-output requirement

The browser qualification does not merely verify MIME types. It checks that generated numeric SVG contains vector `<path>` output and contains no `<image>` or `data:image` raster fallback. Generated PDF is checked for the `%PDF-1.x` signature and for absence of `/Subtype /Image` raster Image XObjects in the tested generated output.

## Canonical bundled hashes

```text
canonical renderer:
fdeb3e3bfd46b9f86650fd411a2d1dfb2515580aa258aa8c11a002913631418c

JavaScript facade:
ea44f75ea40ef43eee6b82582e6c9f0aaa81b4dd58eba80da2528eac50ab04f0

font controller:
7829a6d174126cd5df67448cf6b47219c13121c965674e65fd237c7c2d8c42c0

vector exporter:
601ceafe5ce0f7b8919b23e027e636e3f7b5a0121b24fb9aeb7d6eea8c0d3b39

production manifest:
50b8a4b6cab0c27f2061f94e404a2af992cbf95c8097c58caa5e6b2dc4625f09

fonts.zip:
08d0409e0b180a6b90a0617fe557fd3e59a08dd26781d907ed5d772a9fefcae1
```

## Protocol documents

The package includes the v1.1 integrated profile material under `protocol/`, including the machine-readable `protocol.json` and `protocol/conformance/parser-renderer-profile-v1.1.0.json` used by the TypeScript profile regression.
