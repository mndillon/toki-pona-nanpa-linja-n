# TypeScript conformance — nanpa-linja-n Protocol v1.1.0

The TypeScript reference is a typed facade over the exact canonical JavaScript v1.1.0 behavioral implementation. Conformance therefore has two layers:

1. the bundled JavaScript runtime/reference modules must match the pinned v1.1.0 hashes; and
2. the TypeScript declarations, wrappers, facade and package entry points must expose that behavior without changing it.

## Qualification command

```bash
npm test
```

The runner is non-fail-fast and writes `test-output/typescript-regression-report.txt`.

## Current qualification result

The release qualification completed with **12/12 suites passing, 0 failures, 0 skipped**:

1. TypeScript build — PASS.
2. Bundled canonical JavaScript runtime/resource integrity — PASS.
3. TypeScript declaration/type surface — PASS.
4. Typed wrapper export identity/parity — PASS.
5. Typed facade unit tests — PASS.
6. `astToText` regression — **26/26 PASS**.
7. Protocol v1.1.0 integrated profile — **78 checks PASS**, including **16/16 NanpaParser profile smoke cases** and **8/8 production font-pair invariants**.
8. Production font resources — **8/8 pairs PASS**, **25 runtime font byte checks PASS**.
9. Frozen Core-v1 parser/API regression corpus — **1030 checks PASS**.
10. Canonical syntax — **28/28 PASS**; production font-adapter cases — **5/5 PASS**.
11. Canonical full-renderer semantic corpus — **254/254 PASS**.
12. Real browser production facade/output regression — PASS, including **16/16 `astToText`/`parseNumber` integration checks**.

## Protocol-v1.1 checks

The integrated profile asserts:

- the exact canonical JavaScript renderer SHA-256;
- the exact schema-2 production manifest SHA-256;
- the complete **35-operation `NanpaParser` surface**;
- the complete `SitelenRenderer` static surface;
- all built-in render adapters;
- Protocol v1.1.0 parser/facade defaults;
- abbreviated numeric-cartouche default behavior;
- hex/binary opt-in defaults;
- standard and extended ASCII parser modes;
- current no-legacy-automatic-`ss12`/`ss13`/`ss14` invariant;
- current per-font `cartoucheVulgarFractions: true` and `emulateLegacyCartoucheScaling: false` settings;
- the exact supplied `fonts.zip` bytes;
- the runtime literal-font compatibility alias.

## Vector quality

The real browser regression checks generated output, not only API availability:

- PNG has the correct PNG signature;
- SVG contains `<svg>` and vector `<path>` output;
- SVG contains no `<image>` raster element;
- SVG contains no `data:image` embedded raster fallback;
- PDF has a `%PDF-1.x` signature;
- the tested PDF contains no `/Subtype /Image` raster Image XObject.

## Current pinned hashes

```text
runtime/src/nanpa-linja-n.js
ea44f75ea40ef43eee6b82582e6c9f0aaa81b4dd58eba80da2528eac50ab04f0

runtime/reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js
fdeb3e3bfd46b9f86650fd411a2d1dfb2515580aa258aa8c11a002913631418c

runtime/reference/sitelen-font-pair-controller.js
7829a6d174126cd5df67448cf6b47219c13121c965674e65fd237c7c2d8c42c0

runtime/reference/sitelen-vector-exporter.js
601ceafe5ce0f7b8919b23e027e636e3f7b5a0121b24fb9aeb7d6eea8c0d3b39

runtime/assets/fonts/preloaded-font-pairs.manifest.json
50b8a4b6cab0c27f2061f94e404a2af992cbf95c8097c58caa5e6b2dc4625f09

resources/fonts.zip
08d0409e0b180a6b90a0617fe557fd3e59a08dd26781d907ed5d772a9fefcae1
```

The historical Core-v1 regression fixture remains frozen. Its historical reference hash is therefore intentionally not rewritten to masquerade as a newly generated v1.1 corpus.
