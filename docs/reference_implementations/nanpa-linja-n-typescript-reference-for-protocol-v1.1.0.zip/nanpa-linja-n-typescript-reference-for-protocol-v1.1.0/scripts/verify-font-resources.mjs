#!/usr/bin/env node
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { openZipBytes } from '../runtime/src/font-zip.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const zipBytes = await fs.readFile(path.join(root, 'resources/fonts.zip'));
const zip = openZipBytes(zipBytes);
const manifestBytes = await fs.readFile(path.join(root, 'runtime/assets/fonts/preloaded-font-pairs.manifest.json'));
const manifest = JSON.parse(manifestBytes.toString('utf8'));
const hash = b => crypto.createHash('sha256').update(b).digest('hex');
assert.equal(hash(zipBytes), '08d0409e0b180a6b90a0617fe557fd3e59a08dd26781d907ed5d772a9fefcae1');
assert.equal(hash(manifestBytes), '50b8a4b6cab0c27f2061f94e404a2af992cbf95c8097c58caa5e6b2dc4625f09');
assert.equal(manifest.schema, 2);
assert.equal(manifest.pairs.length, 8);

const aliasName = 'nanpa-linja-n-nasin-nanpa-liberation-sans-literal.ttf';
const aliasSource = 'LiberationSans-Regular.ttf';
let checked = 0;
async function verifyRuntimeFile(filename) {
  if (!filename) return;
  const runtimePath = path.join(root, 'runtime/assets/fonts', filename);
  const runtimeBytes = await fs.readFile(runtimePath);
  const zipEntry = `fonts/${filename}`;
  let sourceBytes;
  if (zip.has(zipEntry)) sourceBytes = await zip.bytesFor(zipEntry);
  else if (filename === aliasName && zip.has(`fonts/${aliasSource}`)) sourceBytes = await zip.bytesFor(`fonts/${aliasSource}`);
  else throw new Error(`fonts.zip missing ${zipEntry}`);
  assert.equal(hash(runtimeBytes), hash(sourceBytes), `${filename} runtime bytes differ from supplied fonts.zip source`);
  checked++;
}

for (const pair of manifest.pairs) {
  await verifyRuntimeFile(pair.baseFilename);
  await verifyRuntimeFile(pair.companionFilename);
  await verifyRuntimeFile(pair.literalCartoucheFilename || pair.literalCartoucheFileName);
  assert.equal(pair.settings?.cartoucheVulgarFractions, true, `${pair.fontKey}: cartoucheVulgarFractions`);
  assert.equal(pair.settings?.emulateLegacyCartoucheScaling, false, `${pair.fontKey}: emulateLegacyCartoucheScaling`);
}
for (const record of Object.values(manifest.supportFonts || {})) await verifyRuntimeFile(record?.filename);

console.log(`TypeScript production font resources: ${manifest.pairs.length}/8 pairs PASS`);
console.log(`Runtime font byte checks: ${checked} PASS`);
console.log(`supplied fonts.zip SHA-256: ${hash(zipBytes)}`);
