#!/usr/bin/env node
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { openZipBytes } from '../runtime/src/font-zip.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const zipBytes = await fs.readFile(path.join(root, 'resources/fonts.zip'));
const zip = openZipBytes(zipBytes);
const manifestBytes = await fs.readFile(path.join(root, 'runtime/assets/fonts/preloaded-font-pairs.manifest.json'));
const manifest = JSON.parse(manifestBytes.toString('utf8'));
const hash = b => crypto.createHash('sha256').update(b).digest('hex');
assert.equal(hash(zipBytes), '98638ca50ce9b39c6c9232f318db2a405f0df28fb0ffea29ceea2827012cdc17');
assert.equal(hash(manifestBytes), '0bfea2aaf3872cc7d272680bdc48b47e5570f5671e0c07717886314ecaf13d26');
assert.equal(manifest.schema, 2);
assert.equal(manifest.pairs.length, 8);

let checked = 0;
async function verifyRuntimeFile(filename) {
  if (!filename) return;
  const runtimePath = path.join(root, 'runtime/assets/fonts', filename);
  const runtimeBytes = await fs.readFile(runtimePath);
  const zipEntry = `fonts/${filename}`;
  if (!zip.has(zipEntry)) throw new Error(`fonts.zip missing ${zipEntry}`);
  const sourceBytes = await zip.bytesFor(zipEntry);
  assert.equal(hash(runtimeBytes), hash(sourceBytes), `${filename} runtime bytes differ from supplied fonts.zip source`);
  checked++;
}

for (const pair of manifest.pairs) {
  await verifyRuntimeFile(pair.baseFilename);
  await verifyRuntimeFile(pair.companionFilename);
  await verifyRuntimeFile(pair.literalCartoucheFilename || pair.literalCartoucheFileName);
  assert.equal(pair.settings?.cartoucheVulgarFractions, true, `${pair.fontKey}: cartoucheVulgarFractions`);
  assert.equal(pair.settings?.emulateLegacyCartoucheScaling, false, `${pair.fontKey}: emulateLegacyCartoucheScaling`);
}
for (const record of Object.values(manifest.supportFonts || {})) await verifyRuntimeFile(record?.filename);

console.log(`TypeScript production font resources: ${manifest.pairs.length}/8 pairs PASS`);
console.log(`Runtime font byte checks: ${checked} PASS`);
console.log(`supplied fonts.zip SHA-256: ${hash(zipBytes)}`);
