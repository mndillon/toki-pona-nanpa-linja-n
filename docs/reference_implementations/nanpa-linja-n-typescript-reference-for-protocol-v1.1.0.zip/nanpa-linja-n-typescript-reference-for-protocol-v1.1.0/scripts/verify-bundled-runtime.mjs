#!/usr/bin/env node
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const expected = {
  'runtime/src/nanpa-linja-n.js': 'ea44f75ea40ef43eee6b82582e6c9f0aaa81b4dd58eba80da2528eac50ab04f0',
  'runtime/src/advanced.js': '0fb4d306da2d24facb3342eef3ec55b3fe6870478594bdac8f47f1f66a49cfa2',
  'runtime/reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js': 'fdeb3e3bfd46b9f86650fd411a2d1dfb2515580aa258aa8c11a002913631418c',
  'runtime/reference/sitelen-font-pair-controller.js': '7829a6d174126cd5df67448cf6b47219c13121c965674e65fd237c7c2d8c42c0',
  'runtime/reference/sitelen-vector-exporter.js': '601ceafe5ce0f7b8919b23e027e636e3f7b5a0121b24fb9aeb7d6eea8c0d3b39',
  'resources/fonts.zip': '08d0409e0b180a6b90a0617fe557fd3e59a08dd26781d907ed5d772a9fefcae1',
  'runtime/assets/fonts/preloaded-font-pairs.manifest.json': '50b8a4b6cab0c27f2061f94e404a2af992cbf95c8097c58caa5e6b2dc4625f09',
  'runtime/assets/wasm/sitelen_vector_wasm.js': 'a5b22d3954d1f191ea2bced84cacebbb32f935a31bb06fb1f37d58f11b9ddb7d',
  'runtime/assets/wasm/sitelen_vector_wasm_bg.wasm': '77be5130d9453e1de68f7520d3bf40733d66d86ed2f9f99780805f25d0aa8da4',
};

let failed = 0;
for (const [rel, wanted] of Object.entries(expected)) {
  const data = await fs.readFile(path.join(root, rel));
  const actual = crypto.createHash('sha256').update(data).digest('hex');
  if (actual === wanted) console.log(`PASS ${rel} ${actual}`);
  else { console.error(`FAIL ${rel}\n  actual:   ${actual}\n  expected: ${wanted}`); failed++; }
}
if (failed) process.exit(1);
console.log('bundled Protocol v1.1.0 JavaScript runtime/resource hashes: PASS');
