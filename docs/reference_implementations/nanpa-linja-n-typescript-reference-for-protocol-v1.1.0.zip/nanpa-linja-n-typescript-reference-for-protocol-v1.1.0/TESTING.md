# Testing the TypeScript Protocol v1.1.0 reference

## Full qualification

```bash
npm test
```

The runner attempts all suites even if an earlier suite fails. The consolidated report is:

```text
test-output/typescript-regression-report.txt
```

## Individual suites

```bash
npm run build
npm run typecheck
npm run test:types
npm run verify:runtime
npm run test:exports
npm run test:unit
npm run test:ast
npm run test:profile
npm run test:fonts
npm run test:protocol
npm run test:canonical-syntax
npm run test:canonical-renderer
npm run test:browser
```

`test:browser` requires a Chromium/Chrome-compatible browser discoverable by the supplied browser-discovery helper. It exercises real font loading, canvas/PNG output, production render adapters, real SVG/PDF vector export, AST editing/serialization, `parseNumber`, and v1.1 numeric defaults.

For release verification, test the actual packaged ZIP from a fresh extraction rather than relying only on the working tree.
