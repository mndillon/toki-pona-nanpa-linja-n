# Release notes — TypeScript reference for Protocol v1.1.0

This release upgrades the TypeScript reference from its Protocol-v1.0-era bundled runtime to the canonical Protocol v1.1.0 JavaScript parser/renderer and production font profile.

Key changes:

- package/reference target updated to v1.1.0;
- exact completed JavaScript v1.1.0 parser/renderer bundled as the behavioral authority;
- TypeScript declarations expanded for parser modes, render-adapter contracts, canonical-to-render spans, synthetic corner brackets, v1.1 render-plan fields, spacing options, tally/scaling options and current parser flags;
- Protocol-v1.1 defaults adopted: abbreviated numeric cartouches, relaxed parse/render and nanpa-format defaults; hex and binary remain opt-in;
- production manifest/resources updated to the supplied `fonts.zip` and current eight-font profile;
- current legacy-font render adapters and vulgar-fraction cartouche scaling supported;
- canonical renderer corpus updated for the current outside-cartouche comma behavior;
- SVG/PDF qualification strengthened to reject raster fallback in tested generated numeric output;
- consolidated suite expanded with v1.1 profile and production-font byte verification.
