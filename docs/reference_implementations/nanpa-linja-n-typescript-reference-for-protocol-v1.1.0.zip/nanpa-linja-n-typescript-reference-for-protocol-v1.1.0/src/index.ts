import type {
  AstToTextOptions,
  CanvasRenderResult,
  FacadeParseResult,
  FacadeRenderPlanResult,
  NanpaLinjaNCreateOptions,
  NanpaLinjaNRuntime,
  NanpaLinjaNRuntimeConstructor,
  NanpaAdvancedRuntimeModule,
  NanpaLinjaNRuntimeModule,
  NanpaNumberConversionOptions,
  NanpaParseResult,
  NanpaParserOptions,
  NanpaParserRuntime,
  NanpaReferenceModule,
  NanpaRenderOptions,
  PdfRenderResult,
  PngRenderResult,
  ProductionFontInfo,
  ProductionFontKey,
  RenderResult,
  SitelenRendererRuntime,
  SitelenVectorExporterRuntimeConstructor,
  CreateSitelenFontPairController,
  DocumentAst,
  DocumentAstSegment,
  ImageAstDescriptor,
  SvgRenderResult,
} from "./types.js";

import {
  astToText as runtimeAstToText,
  parseNumber as runtimeParseNumber,
} from "./runtime.js";

export * from "./types.js";

function quoteImageArgument(value: unknown): string {
  const text = String(value ?? "");
  if (!text.includes("'")) return `'${text}'`;
  if (!text.includes('"')) return `"${text}"`;
  return `"${text.replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"`;
}

function imageAstValueToText(value: ImageAstDescriptor = {}): string {
  const desc = value && typeof value === "object" ? value : {};
  const args: string[] = [];
  const src = String(desc.src ?? "");
  if (src) args.push(`src=${quoteImageArgument(src)}`);
  if (desc.w != null && String(desc.w) !== "") args.push(`w=${quoteImageArgument(desc.w)}`);
  if (desc.h != null && String(desc.h) !== "") args.push(`h=${quoteImageArgument(desc.h)}`);
  if (desc.alt != null) args.push(`alt=${quoteImageArgument(desc.alt)}`);
  if (desc.valign != null && String(desc.valign) !== "" && String(desc.valign) !== "baseline") {
    args.push(`valign=${quoteImageArgument(desc.valign)}`);
  }
  if (desc.wriggle != null && Number(desc.wriggle) !== 8) {
    const wriggle = Number(desc.wriggle);
    args.push(`wriggle=${Number.isFinite(wriggle) ? String(wriggle) : quoteImageArgument(desc.wriggle)}`);
  }
  if (desc.transparent === false) args.push("transparent=false");
  return `img(${args.join(",")})`;
}

function astSegmentToText(segment: DocumentAstSegment): string {
  if (!segment || typeof segment !== "object") {
    throw new TypeError("AST segment must be an object.");
  }
  if (segment.kind === "text") return String(segment.value ?? "");
  if (segment.kind === "bracket") return `[${String(segment.value ?? "")}]`;
  if (segment.kind === "quote") {
    const openQuote = String(segment.openQuote || '"');
    const defaultClose = openQuote === "“" ? "”" : '"';
    const closeQuote = String(segment.closeQuote || defaultClose);
    return `${openQuote}${String(segment.value ?? "")}${closeQuote}`;
  }
  if (segment.kind === "image") return imageAstValueToText(segment.value);
  if (segment.kind === "rawUcsur") {
    const cps = Array.isArray(segment.cps) ? segment.cps : [];
    return cps.map((cp) => {
      const n = Number(cp);
      if (!Number.isInteger(n) || n < 0 || n > 0x10FFFF || (n >= 0xD800 && n <= 0xDFFF)) {
        throw new TypeError(`Invalid rawUcsur code point: ${cp}`);
      }
      return `U+${n.toString(16).toUpperCase().padStart(4, "0")}`;
    }).join(" ");
  }
  throw new TypeError(`Unsupported AST segment kind: ${String((segment as { kind?: unknown }).kind)}`);
}

function astLineToText(line: { children?: DocumentAstSegment[] }): string {
  if (!line || typeof line !== "object") throw new TypeError("AST line must be an object.");
  const children = Array.isArray(line.children) ? line.children : [];
  return children.map(astSegmentToText).join("");
}

/**
 * Convert a document AST returned by parse() back into valid nanpa-linja-n text.
 *
 * Current editable AST content is serialized; stale source offsets are ignored.
 * Whitespace retained in text/bracket/quote values is preserved. When
 * breakLinesAtFullStops created multiple AST lines for one physical source line,
 * sourceLineIndex is used to avoid inventing a newline. Image descriptors are
 * emitted in a canonical valid img(...) form.
 */
export function astToText(ast: DocumentAst, options: AstToTextOptions = {}): string {
  return runtimeAstToText(ast, options);
}

/**
 * Parse one numeric source form through the bundled canonical JavaScript parser.
 * Accepts either direct NanpaParser options or the facade-style { parser, config } wrapper.
 */
export function parseNumber(
  input: unknown,
  options: NanpaParserOptions | NanpaNumberConversionOptions = {},
): NanpaParseResult | null {
  return runtimeParseNumber(input, options);
}

const REQUIRED_CORE_METHODS = Object.freeze([
  "parseNumber",
  "encodeDecimal",
  "decimalToUcsurCodepoints",
  "properNameToUcsurCodepoints",
  "splitCapsToProperName",
  "capsToUniqueCode",
  "decodeCaps",
  "parseIdentifier",
  "capsToWords",
  "capsToCodepoints",
  "codepointsToWords",
] as const);

export const BUNDLED_RUNTIME_MODULE_URL = new URL(
  "../runtime/src/nanpa-linja-n.js",
  import.meta.url,
);

export const BUNDLED_RENDERER_MODULE_URL = new URL(
  "../runtime/reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js",
  import.meta.url,
);

export const BUNDLED_FONT_ZIP_URL = new URL(
  "../resources/fonts.zip",
  import.meta.url,
);

/** Bundled Protocol v1.1.0 production manifest used by the canonical runtime. */
export const BUNDLED_MANIFEST_URL = new URL(
  "../runtime/assets/fonts/preloaded-font-pairs.manifest.json",
  import.meta.url,
);

export const BUNDLED_VECTOR_WASM_URL = new URL(
  "../runtime/assets/wasm/sitelen_vector_wasm.js",
  import.meta.url,
);

export class NanpaRuntimeError extends Error {
  override name = "NanpaRuntimeError";
}

/**
 * Runtime validation for the canonical JavaScript NanpaParser object.
 * This does not reinterpret or duplicate any nanpa-linja-n parsing logic.
 */
export function assertNanpaParserRuntime(value: unknown): asserts value is NanpaParserRuntime {
  if (value == null || (typeof value !== "object" && typeof value !== "function")) {
    throw new NanpaRuntimeError("NanpaParser runtime is missing or is not an object.");
  }

  const candidate = value as Record<string, unknown>;
  const missing = REQUIRED_CORE_METHODS.filter((name) => typeof candidate[name] !== "function");
  if (missing.length > 0) {
    throw new NanpaRuntimeError(
      `NanpaParser runtime is missing required method${missing.length === 1 ? "" : "s"}: ${missing.join(", ")}`,
    );
  }
}

/**
 * Returns a typed, method-safe façade over the canonical JavaScript runtime.
 *
 * JavaScript methods such as decimalToUcsurCodepoints use `this.parseNumber`.
 * Every function is therefore bound back to the original runtime so that
 * destructuring a method cannot accidentally change its behaviour.
 */
export function bindNanpaParser(runtime: NanpaParserRuntime): NanpaParserRuntime {
  assertNanpaParserRuntime(runtime);
  const bound = new Map<PropertyKey, Function>();
  const facadeTarget = Object.create(null) as Record<PropertyKey, unknown>;

  return new Proxy(facadeTarget, {
    get(_target, property) {
      const value = Reflect.get(runtime as object, property, runtime as object);
      if (typeof value !== "function") return value;

      const existing = bound.get(property);
      if (existing) return existing;

      const fn = value.bind(runtime);
      bound.set(property, fn);
      return fn;
    },
    has(_target, property) {
      return property in (runtime as object);
    },
    ownKeys() {
      return Reflect.ownKeys(runtime as object);
    },
    getOwnPropertyDescriptor(_target, property) {
      const descriptor = Reflect.getOwnPropertyDescriptor(runtime as object, property);
      if (!descriptor) return undefined;
      return {
        configurable: true,
        enumerable: descriptor.enumerable ?? false,
        writable: "writable" in descriptor ? descriptor.writable ?? false : false,
        value: Reflect.get(runtime as object, property, runtime as object),
      };
    },
  }) as unknown as NanpaParserRuntime;
}

export function parserFromModule(module: NanpaReferenceModule): NanpaParserRuntime {
  const defaultExport = module.default;
  const parser =
    module.NanpaParser ??
    module.SitelenRenderer?.NanpaParser ??
    (defaultExport && typeof defaultExport === "object" ? defaultExport.NanpaParser : undefined);

  assertNanpaParserRuntime(parser);
  return bindNanpaParser(parser);
}

/** Load any compatible canonical JavaScript parser module and expose it with TypeScript types. */
export async function importNanpaParser(moduleSpecifier: string | URL): Promise<NanpaParserRuntime> {
  const specifier = moduleSpecifier instanceof URL ? moduleSpecifier.href : moduleSpecifier;
  const module = (await import(specifier)) as NanpaReferenceModule;
  return parserFromModule(module);
}

/** Load the parser from the JavaScript reference runtime bundled with this package. */
export async function importBundledNanpaParser(): Promise<NanpaParserRuntime> {
  return await importNanpaParser(BUNDLED_RENDERER_MODULE_URL);
}

/** Obtain a reference runtime that has already been loaded as a browser global. */
export function getGlobalNanpaParser(): NanpaParserRuntime {
  const globals = globalThis as typeof globalThis & {
    NanpaParser?: NanpaParserRuntime;
    SitelenRenderer?: SitelenRendererRuntime;
  };

  const parser = globals.NanpaParser ?? globals.SitelenRenderer?.NanpaParser;
  assertNanpaParserRuntime(parser);
  return bindNanpaParser(parser);
}

/** Narrow a runtime SitelenRenderer object without altering it. */
export function assertSitelenRendererRuntime(value: unknown): asserts value is SitelenRendererRuntime {
  if (value == null || typeof value !== "object") {
    throw new NanpaRuntimeError("SitelenRenderer runtime is missing or is not an object.");
  }
  const candidate = value as Record<string, unknown>;
  if (typeof candidate.create !== "function") {
    throw new NanpaRuntimeError("SitelenRenderer runtime is missing required method: create");
  }
  assertNanpaParserRuntime(candidate.NanpaParser);
}

function runtimeModuleUrl(value?: string | URL): string {
  if (value instanceof URL) return value.href;
  if (typeof value === "string" && value.trim()) return value;
  return BUNDLED_RUNTIME_MODULE_URL.href;
}

function assertNanpaLinjaNRuntimeConstructor(value: unknown): asserts value is NanpaLinjaNRuntimeConstructor {
  if (value == null || (typeof value !== "object" && typeof value !== "function")) {
    throw new NanpaRuntimeError("NanpaLinjaN JavaScript facade is missing.");
  }
  const candidate = value as Record<string, unknown>;
  if (typeof candidate.create !== "function") {
    throw new NanpaRuntimeError("NanpaLinjaN JavaScript facade is missing required method: create");
  }
}

/** Load the exact JavaScript production facade bundled with this TypeScript package. */
export async function importBundledRuntimeModule(
  moduleSpecifier: string | URL = BUNDLED_RUNTIME_MODULE_URL,
): Promise<NanpaLinjaNRuntimeModule> {
  const specifier = moduleSpecifier instanceof URL ? moduleSpecifier.href : moduleSpecifier;
  const module = (await import(specifier)) as NanpaLinjaNRuntimeModule;
  const ctor = module.NanpaLinjaN ?? module.default;
  assertNanpaLinjaNRuntimeConstructor(ctor);
  return module;
}

/** Load the bundled JavaScript advanced surface with complete TypeScript declarations. */
export async function importBundledAdvancedModule(
  moduleSpecifier?: string | URL,
): Promise<NanpaAdvancedRuntimeModule> {
  const target = moduleSpecifier ?? new URL("../runtime/src/advanced.js", import.meta.url);
  const specifier = target instanceof URL ? target.href : target;
  const module = (await import(specifier)) as NanpaAdvancedRuntimeModule;
  assertNanpaParserRuntime(module.NanpaParser);
  assertSitelenRendererRuntime(module.SitelenRenderer);
  if (typeof module.SitelenVectorExporter?.create !== "function") {
    throw new NanpaRuntimeError("SitelenVectorExporter runtime is missing required method: create");
  }
  if (typeof module.createSitelenFontPairController !== "function") {
    throw new NanpaRuntimeError("Font-pair controller runtime is missing required factory.");
  }
  return module;
}

/** Load the exact bundled JavaScript SitelenRenderer object without reimplementing it. */
export async function importBundledSitelenRenderer(): Promise<SitelenRendererRuntime> {
  return (await importBundledAdvancedModule()).SitelenRenderer;
}

/** Load the exact bundled JavaScript SitelenVectorExporter constructor. */
export async function importBundledSitelenVectorExporter(): Promise<SitelenVectorExporterRuntimeConstructor> {
  return (await importBundledAdvancedModule()).SitelenVectorExporter;
}

/** Load the exact bundled JavaScript font-pair-controller factory. */
export async function importBundledFontPairControllerFactory(): Promise<CreateSitelenFontPairController> {
  return (await importBundledAdvancedModule()).createSitelenFontPairController;
}

/**
 * Strongly typed façade over the bundled canonical JavaScript production renderer.
 *
 * Parsing/rendering behaviour remains implemented by the JavaScript reference.
 * This class adds TypeScript types and a package-local, self-contained loading path.
 */
export class NanpaLinjaN {
  readonly #runtime: NanpaLinjaNRuntime;

  private constructor(runtime: NanpaLinjaNRuntime) {
    this.#runtime = runtime;
  }

  static async create(options: NanpaLinjaNCreateOptions = {}): Promise<NanpaLinjaN> {
    const { runtimeModuleUrl: runtimeOverride, ...runtimeOptions } = options;
    const useBundledRuntime = runtimeOverride == null || String(runtimeOverride).trim() === "";
    if (useBundledRuntime && runtimeOptions.manifestUrl == null) {
      runtimeOptions.manifestUrl = BUNDLED_MANIFEST_URL.href;
    }
    if (useBundledRuntime && runtimeOptions.vectorWasmUrl == null) {
      runtimeOptions.vectorWasmUrl = BUNDLED_VECTOR_WASM_URL.href;
    }
    const module = await importBundledRuntimeModule(runtimeModuleUrl(runtimeOverride));
    const ctor = module.NanpaLinjaN ?? module.default;
    assertNanpaLinjaNRuntimeConstructor(ctor);
    const runtime = await ctor.create(runtimeOptions);
    return new NanpaLinjaN(runtime);
  }

  /** Escape hatch for advanced consumers that need the underlying canonical JS facade instance. */
  get rawRuntime(): NanpaLinjaNRuntime {
    return this.#runtime;
  }

  get fonts(): ProductionFontInfo[] {
    return this.#runtime.fonts;
  }

  listFonts(): ProductionFontInfo[] {
    return this.#runtime.listFonts();
  }

  getFontInfo(font: ProductionFontKey | string): ProductionFontInfo | null {
    return this.#runtime.getFontInfo(font);
  }

  normalizeFontKey(font?: ProductionFontKey | string): ProductionFontKey {
    return this.#runtime.normalizeFontKey(font);
  }

  async parse(input: string, options: NanpaRenderOptions = {}): Promise<FacadeParseResult> {
    return await this.#runtime.parse(input, options);
  }

  astToText(ast: DocumentAst, options: AstToTextOptions = {}): string {
    return this.#runtime.astToText(ast, options);
  }

  parseNumber(
    input: unknown,
    options: NanpaParserOptions | NanpaNumberConversionOptions = {},
  ): NanpaParseResult | null {
    return this.#runtime.parseNumber(input, options);
  }

  async buildRenderPlan(input: string, options: NanpaRenderOptions = {}): Promise<FacadeRenderPlanResult> {
    return await this.#runtime.buildRenderPlan(input, options);
  }

  async render(
    input: string,
    options?: NanpaRenderOptions & { format?: "canvas" },
  ): Promise<CanvasRenderResult>;
  async render(
    input: string,
    options: NanpaRenderOptions & { format: "png" },
  ): Promise<PngRenderResult>;
  async render(
    input: string,
    options: NanpaRenderOptions & { format: "svg" },
  ): Promise<SvgRenderResult>;
  async render(
    input: string,
    options: NanpaRenderOptions & { format: "pdf" },
  ): Promise<PdfRenderResult>;
  async render(input: string, options: NanpaRenderOptions = {}): Promise<RenderResult> {
    return await this.#runtime.render(input, options);
  }

  async renderToCanvas(input: string, options: NanpaRenderOptions = {}): Promise<CanvasRenderResult> {
    return await this.#runtime.renderToCanvas(input, options);
  }

  async renderToPng(input: string, options: NanpaRenderOptions = {}): Promise<PngRenderResult> {
    return await this.#runtime.renderToPng(input, options);
  }

  async renderToSvg(input: string, options: NanpaRenderOptions = {}): Promise<SvgRenderResult> {
    return await this.#runtime.renderToSvg(input, options);
  }

  async renderToPdf(input: string, options: NanpaRenderOptions = {}): Promise<PdfRenderResult> {
    return await this.#runtime.renderToPdf(input, options);
  }

  async destroy(): Promise<void> {
    await this.#runtime.destroy();
  }
}

export default NanpaLinjaN;
