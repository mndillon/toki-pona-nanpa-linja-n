export type NumericMode = "uniform" | "traditional";
export type NumericOutputMode = "source" | "properName" | "#~" | "cartouche";
export type ParserMode =
  | "standard-sitelen-pona-ascii-core"
  | "sitelen-pona-ascii-extended"
  | "sitelen-seli-kiwen"
  | (string & {});
export type CartoucheTallyMode = "ucsur" | "comma" | "manual" | (string & {});

export type DecimalSemanticStartGlyph = "nanpa" | "tenpo" | "suno" | "toki";
export type NumericStartGlyph = DecimalSemanticStartGlyph | "nasa" | "noka" | (string & {});
export type SemanticKind = "time" | "date" | (string & {});

/**
 * Options accepted by the canonical JavaScript NanpaParser.
 *
 * Known options are typed explicitly. The index signature is intentional:
 * the JavaScript reference implementation has accumulated compatibility and
 * renderer options over time, and the TypeScript facade must not reject a
 * valid future/reference-runtime option merely because its declaration has
 * not yet been updated.
 */
export interface NanpaParserOptions {
  mode?: ParserMode;
  numericMode?: NumericMode;
  mixedStyle?: "short" | "long" | (string & {});

  relaxedNanpaLinjanParsing?: boolean;
  relaxedNanpaLinjanRendering?: boolean;
  nanpaColonParsing?: boolean;
  nanpaColonRendering?: boolean;
  enableHexParsing?: boolean;
  enableBinaryParsing?: boolean;
  enableBinaryRendering?: boolean;
  numericCartoucheStartGlyph?: NumericStartGlyph | null;
  breakLinesAtFullStops?: boolean;
  interpretDoubleQuotesAsTeTo?: boolean;
  autoCartoucheStandaloneProperNames?: boolean;
  showUnknownText?: boolean;
  cartoucheCommaTallyMarks?: boolean;
  cartoucheTallyMode?: CartoucheTallyMode;
  cartoucheVulgarFractions?: boolean;
  emulateLegacyCartoucheScaling?: boolean;
  manualTallySmallFontLiftPx?: number | null;
  manualTallySmallFontMaxPx?: number;

  thousandsChar?: string;
  groupFractionTriplets?: boolean;
  fractionGroupSize?: number;

  intEneSep?: string;
  intGroupSep?: string;
  fracEneSep?: string;
  fracGroupSep?: string;

  abbreviateNumericCartouches?: boolean;
  numericCartoucheAbbreviation?: boolean;
  abbreviatedNumericCartouches?: boolean;
  preserveNumericCartoucheBreaksInAbbreviation?: boolean;
  nasinNanpaPona?: boolean;

  [key: string]: unknown;
}

export interface SplitCapsToProperNameOptions {
  titleCase?: boolean;
  relaxedNanpaLinjanParsing?: boolean;
  relaxedNanpaLinjanRendering?: boolean;
  nanpaColonRendering?: boolean;
}

export interface NanpaIdentifierResult {
  input: string;
  innerCodepoints: number[];
  codepoints: number[];
  words: string[];
  numericMode: NumericMode;
}

export interface NanpaCapsCodepointsResult {
  innerCodepoints: number[];
  codepoints: number[];
  words: string[];
  numericMode: NumericMode;
  isTimeLike: boolean;
}

export interface NanpaParseResult {
  input: string;
  caps: string | null;
  properName: string | null;
  uniqueCode: string;

  ucsurCodepoints: number[];
  hexCodepoints: string;
  hexWithCartouche: string;
  tpWords: string[];
  words: string[];
  displayValue: string;

  isTime: boolean;
  isDate: boolean;
  semanticKind?: SemanticKind | null;
  semanticStartGlyph?: NumericStartGlyph | null;
  isTimeLike: boolean;

  innerCodepoints: number[];
  codepoints: number[];
  numericMode: NumericMode;

  /** Hexadecimal/binary structured results. */
  kind?: "hex" | "binary" | (string & {});
  numberBase?: 2 | 16 | number;
  isHex?: boolean;
  isBinary?: boolean;
  hexDigits?: string;
  binaryDigits?: string;
  hexParts?: unknown[];
  binaryParts?: unknown[];
  abbreviatedUcsurCodepoints?: number[];
  abbreviatedWords?: string[];
  nasinNanpaPonaWords?: string[] | null;

  /** Permit reference-runtime extensions without weakening known fields. */
  [key: string]: unknown;
}

export interface NanpaParserRuntime {
  parseNumber(input: unknown, opts?: NanpaParserOptions): NanpaParseResult | null;
  encodeDecimal(input: unknown, opts?: NanpaParserOptions): string | null;
  decimalToUcsurCodepoints(input: unknown, opts?: NanpaParserOptions): number[];
  properNameToUcsurCodepoints(input: unknown, opts?: NanpaParserOptions): number[];
  splitCapsToProperName(caps: string, opts?: SplitCapsToProperNameOptions): string;
  capsToUniqueCode(caps: string, opts?: NanpaParserOptions): string;

  decodeCaps(caps: string, opts?: NanpaParserOptions): string | null;

  ucsurCodepointsToTpWords(codepoints: Iterable<number>): string[];
  codepointsToWords(codepoints: Iterable<number>): string[];
  tpWordsToText(words: Iterable<string>): string;
  parseTpWordsToCodepoints(input: unknown): number[];
  tpWordsToUcsurCodepoints(words: Iterable<string>): number[];

  codepointsToHex(codepoints: Iterable<number>): string;
  codepointsToHexWithCartouche(codepoints: Iterable<number>): string;
  parseHexCodepoints(input: unknown): number[];
  withCartoucheMarkers(codepoints: Iterable<number>): number[];
  stripCartoucheMarkers(codepoints: Iterable<number>): number[];

  isValidCaps(input: unknown): boolean;
  isValidProperName(input: unknown, opts?: NanpaParserOptions): boolean;
  isValidTimeOrDate(caps: string, opts?: NanpaParserOptions): boolean;
  isValidTime?(caps: string, opts?: NanpaParserOptions): boolean;
  isValidDate?(caps: string, opts?: NanpaParserOptions): boolean;

  tokenizeCaps(caps: string, opts?: NanpaParserOptions): string[];
  capsTokensToTpWords(tokens: Iterable<string>, opts?: NanpaParserOptions): string[];
  capsToWords(caps: string, opts?: NanpaParserOptions): string[];
  capsToCodepoints(caps: string, opts?: NanpaParserOptions): NanpaCapsCodepointsResult | null;
  parseIdentifier(input: unknown, opts?: NanpaParserOptions): NanpaIdentifierResult | null;

  normalizeVulgarFraction(input: unknown): string | null;
  normalizeTpWord(input: unknown): string;

  getSmallCodepointsSet(): Set<number>;
  getQuarterCodepointsSet(): Set<number>;
  getOneThirdCodepointsSet(): Set<number>;
  getTwoThirdsCodepointsSet(): Set<number>;
  getHalfCodepointsSet(): Set<number>;
  isAllowedTpUcsurCodepoint(codepoint: number): boolean;

  [key: string]: unknown;
}

export interface CanonicalToRenderSpan {
  canonicalIndex: number;
  renderStart: number;
  renderEnd: number;
}

export interface SyntheticCornerBracketInstruction extends CanonicalToRenderSpan {
  codepoint: 0x300C | 0x300D | number;
  side?: "left" | "right";
}

export interface FontRenderAdapterContext {
  canonicalCps: number[];
  renderAdapterId?: string;
  settings?: Record<string, unknown>;
  fontRole?: string;
  elementKind?: string;
  fontFamily?: string;
  sourceText?: string | null;
  sourceKind?: string | null;
  sourceSegmentIndex?: number | null;
  bypassRenderAdapter?: boolean;
  adaptRawUnicode?: boolean;
  isLiteral?: boolean;
  isLiteralCartouche?: boolean;
  [key: string]: unknown;
}

export interface FontRenderAdapterResult {
  renderCps: number[];
  canonicalToRenderSpans?: CanonicalToRenderSpan[];
  syntheticCornerBrackets?: SyntheticCornerBracketInstruction[];
  longGlyphPresentation?: "connected" | "decomposed" | null;
  [key: string]: unknown;
}

export type FontRenderAdapter = (context: FontRenderAdapterContext) => FontRenderAdapterResult | number[];

export interface SitelenRendererRuntime {
  NanpaParser: NanpaParserRuntime;
  create(config?: RendererConfig): Promise<RendererInstanceRuntime>;
  registerRenderAdapter(id: string, adapter: FontRenderAdapter): string;
  unregisterRenderAdapter(id: string): boolean;
  hasRenderAdapter(id: string): boolean;
  getDefaultRenderAdapterId(): string;
  [key: string]: unknown;
}

export interface NanpaReferenceModule {
  NanpaParser?: NanpaParserRuntime;
  SitelenRenderer?: SitelenRendererRuntime;
  default?: SitelenRendererRuntime | { NanpaParser?: NanpaParserRuntime };
  [key: string]: unknown;
}

export type ProductionFontKey =
  | "nasinNanpa"
  | "sitelenSeliKiwen"
  | "fairfaxHd"
  | "fairfaxPonaHd"
  | "linjaPona"
  | "linjaSike"
  | "nasinSitelenPuMono"
  | "linjaLipamanka"
  | (string & {});

export type RenderFormat = "canvas" | "png" | "svg" | "pdf";

export interface RendererLayoutOptions {
  fontPx?: number;
  paddingPx?: number;
  lineGapPx?: number;
  forceLineGapPx?: boolean;
  lineGapPxMode?: "exact" | (string & {});
  align?: "left" | "center" | "right" | (string & {});
  spacingPreset?: "default" | "compact" | "comfortable" | (string & {});
  glyphGapScale?: number;
  glyphGapMinPx?: number;
  glyphGapMaxPx?: number;
  cartoucheLeadGapScale?: number;
  cartouchePadScale?: number;
  cartouchePadMinPx?: number;
  lineGapScale?: number;
  lineGapMinPx?: number;
  lineGapMaxPx?: number;
  [key: string]: unknown;
}

export interface RendererPaintOptions {
  fillStyle?: string;
  halo?: { enabled?: boolean; color?: string; widthPx?: number; [key: string]: unknown };
  unknownText?: {
    style?: string;
    colorMode?: string;
    color?: string | null;
    lineWidthPx?: number;
    paddingPx?: number;
    dash?: boolean;
    [key: string]: unknown;
  };
  [key: string]: unknown;
}

export interface RendererFontOptions {
  renderAdapterId?: string;
  renderAdapterSettings?: Record<string, unknown>;
  roles?: Record<string, string>;
  settings?: Record<string, unknown>;
  cartoucheVulgarFractions?: boolean;
  emulateLegacyCartoucheScaling?: boolean;
  manualTallySmallFontLiftPx?: number | null;
  manualTallySmallFontMaxPx?: number;
  longPiHeadWidthScale?: number;
  [key: string]: unknown;
}

export interface RendererConfig {
  layout?: RendererLayoutOptions;
  paint?: RendererPaintOptions;
  parser?: NanpaParserOptions;
  fonts?: RendererFontOptions;
  [key: string]: unknown;
}

export interface ProductionFontInfo {
  key: ProductionFontKey;
  label: string;
  textFamily: string;
  cartoucheFamily: string;
  literalCartoucheFamily: string;
  parserMode: string;
  renderAdapterId: string;
  [key: string]: unknown;
}

export interface ProductionFontPreset extends ProductionFontInfo {
  renderAdapterSettings?: Record<string, unknown>;
  settings?: Record<string, unknown>;
  faces?: Array<Record<string, unknown>>;
  __pairRecord?: Record<string, unknown>;
}

export interface RenderPlanRun {
  id?: string;
  kind?: string;
  renderMode?: string;
  fontRole?: string;
  fontFamily?: string;
  renderAdapterId?: string;
  requestedRenderAdapterId?: string;
  longGlyphPresentation?: "connected" | "decomposed" | null;
  sourceText?: string | null;
  sourceStart?: number | null;
  sourceEnd?: number | null;
  sourceKind?: string | null;
  sourceSegmentIndex?: number | null;
  encodedText?: string | null;
  canonicalEncodedText?: string | null;
  cps?: number[] | null;
  canonicalCps?: number[] | null;
  canonicalFullCps?: number[] | null;
  renderCps?: number[] | null;
  renderFullCps?: number[] | null;
  canonicalToRenderSpans?: CanonicalToRenderSpan[] | null;
  syntheticCornerBrackets?: SyntheticCornerBracketInstruction[];
  audioSourceCps?: number[] | null;
  audioSourceIndices?: number[] | null;
  audioGlyphLayout?: Array<Record<string, unknown>> | null;
  manualTallies?: number[] | null;
  widthPx?: number;
  heightPx?: number;
  fontPx?: number;
  [key: string]: unknown;
}

export interface RenderPlanLine {
  runs?: RenderPlanRun[];
  [key: string]: unknown;
}

export interface RenderPlan {
  widthPx?: number;
  heightPx?: number;
  lines?: RenderPlanLine[];
  ast?: unknown;
  diagnostics?: unknown[];
  [key: string]: unknown;
}

export interface NanpaLinjaNCreateOptions {
  /** Optional unpacked production-manifest override. */
  manifestUrl?: string | URL;
  /** @deprecated Protocol v1.1.0 bundled runtime uses an unpacked manifest/assets tree. */
  fontZipUrl?: string | URL;
  /** @deprecated Kept in the TypeScript compatibility type only; ignored by the v1.1.0 bundled runtime. */
  fontZipManifestEntry?: string;
  vectorWasmUrl?: string | URL;
  defaultFont?: ProductionFontKey;
  defaultFontKey?: ProductionFontKey;
  defaultTextFontOption?: string;
  defaultFontSize?: number;
  storageKeyPrefix?: string;
  baseRenderConfig?: RendererConfig;

  /** Optional override for the bundled JavaScript facade module. */
  runtimeModuleUrl?: string | URL;
  [key: string]: unknown;
}

export interface NanpaRenderOptions {
  format?: RenderFormat;
  font?: ProductionFontKey;
  fontKey?: ProductionFontKey;
  fontSize?: number;
  paddingPx?: number;
  quality?: number;
  includePlan?: boolean;
  textFontOption?: string;
  config?: RendererConfig;
  layout?: RendererLayoutOptions;
  paint?: RendererPaintOptions;
  parser?: NanpaParserOptions;
  fonts?: RendererFontOptions;
  [key: string]: unknown;
}



export interface NanpaNumberConversionOptions {
  parser?: NanpaParserOptions;
  config?: RendererConfig;
  [key: string]: unknown;
}

export interface AstToTextOptions {
  numericOutput?: NumericOutputMode;
  parser?: NanpaParserOptions;
  config?: RendererConfig;
  [key: string]: unknown;
}

export interface NumericAstStructure {
  kind?: string;
  index: number;
  end: number;
  sourceText: string;
  semanticKind?: SemanticKind | null;
  semanticStartGlyph?: NumericStartGlyph | null;
  wholeSegment?: boolean;
  [key: string]: unknown;
}

export interface ImageAstDescriptor {
  src?: string;
  w?: string | number | null;
  h?: string | number | null;
  alt?: string | null;
  valign?: string | null;
  wriggle?: string | number | null;
  transparent?: boolean | null;
  [key: string]: unknown;
}

export interface TextAstSegment {
  kind: "text";
  value?: string;
  numericStructures?: NumericAstStructure[];
  [key: string]: unknown;
}

export interface BracketAstSegment {
  kind: "bracket";
  value?: string;
  numericStructures?: NumericAstStructure[];
  [key: string]: unknown;
}

export interface QuoteAstSegment {
  kind: "quote";
  value?: string;
  openQuote?: string;
  closeQuote?: string;
  [key: string]: unknown;
}

export interface ImageAstSegment {
  kind: "image";
  value?: ImageAstDescriptor;
  [key: string]: unknown;
}

export interface RawUcsurAstSegment {
  kind: "rawUcsur";
  cps?: number[];
  [key: string]: unknown;
}

export type DocumentAstSegment =
  | TextAstSegment
  | BracketAstSegment
  | QuoteAstSegment
  | ImageAstSegment
  | RawUcsurAstSegment;

export interface DocumentAstLine {
  children?: DocumentAstSegment[];
  sourceLineIndex?: number;
  sentenceIndexInSourceLine?: number;
  sourceText?: string;
  [key: string]: unknown;
}

export interface DocumentAst {
  lines: DocumentAstLine[];
  normalizedInput?: string;
  parserOptions?: NanpaParserOptions;
  [key: string]: unknown;
}

export interface FacadeContextResult {
  input: string;
  fontKey: ProductionFontKey;
  preset: ProductionFontPreset;
  config: RendererConfig;
}

export interface FacadeParseResult extends FacadeContextResult {
  ast: DocumentAst;
  diagnostics: unknown[];
  [key: string]: unknown;
}

export interface FacadeRenderPlanResult extends FacadeContextResult {
  plan: RenderPlan;
}

export interface CanvasRenderResult extends FacadeContextResult {
  kind: "canvas";
  canvas: HTMLCanvasElement;
  width: number;
  height: number;
  ast: unknown;
  linesElements: unknown;
  plan: RenderPlan | null;
}

export interface PngRenderResult extends Omit<CanvasRenderResult, "kind"> {
  kind: "png";
  blob: Blob;
  bytes: Uint8Array;
}

export interface SvgRenderResult extends FacadeContextResult {
  kind: "svg";
  blob: Blob;
  svg: string;
}

export interface PdfRenderResult extends FacadeContextResult {
  kind: "pdf";
  blob: Blob;
  bytes: Uint8Array;
}

export type RenderResult = CanvasRenderResult | PngRenderResult | SvgRenderResult | PdfRenderResult;

export interface NanpaLinjaNRuntime {
  readonly fonts: ProductionFontInfo[];
  listFonts(): ProductionFontInfo[];
  getFontInfo(font: ProductionFontKey | string): ProductionFontInfo | null;
  normalizeFontKey(font?: ProductionFontKey | string): ProductionFontKey;
  parse(input: string, options?: NanpaRenderOptions): Promise<FacadeParseResult>;
  astToText(ast: DocumentAst, options?: AstToTextOptions): string;
  parseNumber(input: unknown, options?: NanpaParserOptions | NanpaNumberConversionOptions): NanpaParseResult | null;
  buildRenderPlan(input: string, options?: NanpaRenderOptions): Promise<FacadeRenderPlanResult>;
  render(input: string, options?: NanpaRenderOptions): Promise<RenderResult>;
  renderToCanvas(input: string, options?: NanpaRenderOptions): Promise<CanvasRenderResult>;
  renderToPng(input: string, options?: NanpaRenderOptions): Promise<PngRenderResult>;
  renderToSvg(input: string, options?: NanpaRenderOptions): Promise<SvgRenderResult>;
  renderToPdf(input: string, options?: NanpaRenderOptions): Promise<PdfRenderResult>;
  destroy(): Promise<void>;
}

export interface NanpaLinjaNRuntimeConstructor {
  create(options?: NanpaLinjaNCreateOptions): Promise<NanpaLinjaNRuntime>;
}

export interface NanpaLinjaNRuntimeModule {
  DEFAULT_FONT_KEY: ProductionFontKey;
  DEFAULT_FONT_SIZE: number;
  DEFAULT_MANIFEST_URL: string;
  DEFAULT_PARSER_CONFIG: Readonly<NanpaParserOptions>;
  DEFAULT_TEXT_FONT_OPTION: string;
  DEFAULT_VECTOR_WASM_URL: string;

  NanpaLinjaN: NanpaLinjaNRuntimeConstructor;
  default?: NanpaLinjaNRuntimeConstructor;
  astToText(ast: DocumentAst, options?: AstToTextOptions): string;
  parseNumber(input: unknown, options?: NanpaParserOptions | NanpaNumberConversionOptions): NanpaParseResult | null;
  NanpaParser: NanpaParserRuntime;
  SitelenRenderer: SitelenRendererRuntime;
  SitelenVectorExporter: SitelenVectorExporterRuntimeConstructor;
  createSitelenFontPairController: CreateSitelenFontPairController;
  TEXT_FONT_OPTION_SITELEN: string;
  [key: string]: unknown;
}

export interface NanpaAdvancedRuntimeModule {
  NanpaParser: NanpaParserRuntime;
  SitelenRenderer: SitelenRendererRuntime;
  SitelenVectorExporter: SitelenVectorExporterRuntimeConstructor;
  createSitelenFontPairController: CreateSitelenFontPairController;
  TEXT_FONT_OPTION_SITELEN: string;
  TEXT_FONT_OPTION_NANPA_LINJA_N: string;
  [key: string]: unknown;
}

export interface RendererCanvasOptions {
  input?: string;
  canvas?: HTMLCanvasElement;
  x?: number;
  y?: number;
  layout?: RendererLayoutOptions;
  paint?: RendererPaintOptions;
  parser?: NanpaParserOptions;
  fonts?: RendererFontOptions;
  [key: string]: unknown;
}

export interface RendererUcsurOptions extends Omit<RendererCanvasOptions, "input"> {
  lines?: Iterable<Iterable<number>>;
}

export interface RendererCanvasResult {
  canvas: HTMLCanvasElement;
  ast: unknown;
  linesElements: unknown;
  [key: string]: unknown;
}

export interface RendererInstanceRuntime {
  readonly config: RendererConfig;
  parseInput(args?: { input?: string; parser?: NanpaParserOptions }): Promise<{ ast: unknown; diagnostics: unknown[] }>;
  buildRenderPlan(args: {
    input?: string;
    ast?: unknown;
    layout?: RendererLayoutOptions;
    paint?: RendererPaintOptions;
    parser?: NanpaParserOptions;
    fonts?: RendererFontOptions;
  }): Promise<RenderPlan>;
  renderRunToNewCanvas(args?: {
    run?: RenderPlanRun;
    supersampleScale?: number;
    downsample?: boolean;
  }): Promise<HTMLCanvasElement | RendererCanvasResult | unknown>;
  renderTextToNewCanvas(args?: RendererCanvasOptions): Promise<RendererCanvasResult>;
  renderTextToCanvas(args?: RendererCanvasOptions): Promise<RendererCanvasResult>;
  renderUcsurToNewCanvas(args?: RendererUcsurOptions): Promise<RendererCanvasResult>;
  renderUcsurToCanvas(args?: RendererUcsurOptions): Promise<RendererCanvasResult>;
  [key: string]: unknown;
}

export type TextFontOptionEntry = string | readonly [string, string] | { value: string; label?: string };

export interface FontPairControllerCreateOptions {
  registry: Record<string, ProductionFontPreset | Record<string, unknown>>;
  scriptSelect?: string | HTMLSelectElement | null;
  textFontSelect?: string | HTMLSelectElement | null;
  storageKeyPrefix?: string;
  defaultPresetKey?: string;
  defaultTextFontOption?: string;
  fontLoadSample?: string;
  onInvalidate?: (() => void) | null;
  indexedDbName?: string;
  indexedDbVersion?: number;
  indexedDbStoreName?: string;
  changeEventName?: string;
  dynamicLiteralOptions?: TextFontOptionEntry[] | null;
  getDynamicLiteralOptions?: ((context: Record<string, unknown>) => TextFontOptionEntry[] | null | undefined) | null;
  defaultDynamicLiteralOptions?: TextFontOptionEntry[] | null;
  dynamicTextFontOption?: string;
  getDefaultDynamicTextFontOption?: ((context: Record<string, unknown>) => string | null | undefined) | null;
  dynamicLiteralFace?: Record<string, unknown> | null;
  getDynamicLiteralFace?: ((context: Record<string, unknown>) => Record<string, unknown> | null | undefined) | null;
  mapDynamicPreset?: ((context: Record<string, unknown>) => ProductionFontPreset | Record<string, unknown> | null | undefined) | null;
  [key: string]: unknown;
}

export interface SitelenFontPairControllerRuntime {
  ready: Promise<SitelenFontPairControllerRuntime>;
  normalizeScriptPresetKey(key: unknown): string;
  normalizeTextFontOptionKey(key: unknown, preset?: ProductionFontPreset | null): string;
  getActivePreset(): ProductionFontPreset;
  getPresetByKey(key: unknown): ProductionFontPreset | null;
  getSelectedTextFontOptionKey(): string;
  getTextFontOptionsForPreset(preset?: ProductionFontPreset | null): Array<readonly [string, string]>;
  resolveLiteralFontFamily(optionKey?: string, preset?: ProductionFontPreset | null): string;
  resolveLiteralCartoucheFontFamily(preset?: ProductionFontPreset | null): string;
  buildFontRoles(args?: Record<string, unknown>): Record<string, string>;
  getPresetTallySettings(preset?: ProductionFontPreset | null): Record<string, unknown>;
  buildRendererParserConfig(args?: Record<string, unknown>): NanpaParserOptions;
  buildRendererConfig(args?: Record<string, unknown>): RendererConfig;
  uniqueConfiguredFontFamilies(args?: Record<string, unknown>): string[];
  ensureFamiliesLoaded(fontPx?: number, families?: Iterable<string>): Promise<unknown>;
  waitForConfiguredFonts(fontPx?: number): Promise<unknown>;
  fontsReadyForPx(fontPx?: number): Promise<unknown>;
  warmUpCanvasFonts(fontPx?: number, families?: Iterable<string>): unknown;
  warmUpCanvasFontsOnce(fontPx?: number): unknown;
  resetFontLoadState(): void;
  populateScriptSelectOptions(): void;
  populateTextSelectOptions(): void;
  saveScriptPresetToStorage(key: string): unknown;
  loadScriptPresetFromStorage(): string;
  saveTextFontOptionToStorage(key: string): unknown;
  loadTextFontOptionFromStorage(preset?: ProductionFontPreset | null): string;
  setActivePreset(key: string, options?: { persist?: boolean }): ProductionFontPreset | unknown;
  setSelectedTextFontOption(key: string, options?: { persist?: boolean }): unknown;
  applyStoredSelections(): unknown;
  wireControls(options?: { onChange?: ((...args: unknown[]) => void) | null }): unknown;
  getDb(): Promise<IDBDatabase | null>;
  listStoredFontPairs(): Promise<Array<Record<string, unknown>>>;
  getStoredFontPair(fontKey: string): Promise<Record<string, unknown> | null>;
  saveFontPairToIndexedDb(record: Record<string, unknown>): Promise<unknown>;
  syncPreloadedFontPairsFromManifest(options?: Record<string, unknown>): Promise<Record<string, unknown>>;
  removeStoredPair(fontKey: string): Promise<unknown>;
  hydrateDynamicPresetsFromDb(options?: { force?: boolean }): Promise<unknown>;
  listDynamicPresets(): ProductionFontPreset[];
  listBuiltInPresets(): ProductionFontPreset[];
  listKnownPairs(): Promise<Array<Record<string, unknown>>>;
  resolvePresetRecord(key: string): Promise<Record<string, unknown> | null>;
  registerRuntimePair(options: Record<string, unknown>): Promise<Record<string, unknown>>;
  saveRuntimePairToDb(fontKey: string): Promise<unknown>;
  registerPresetObject(key: string, preset: ProductionFontPreset | Record<string, unknown>, options?: { persist?: boolean }): Record<string, unknown>;
  getDynamicRegistrySnapshot(): Record<string, ProductionFontPreset>;
  getCombinedRegistrySnapshot(): Record<string, ProductionFontPreset>;
  hasPresetKey(key: unknown): boolean;
  destroy(): void;
  [key: string]: unknown;
}

export type CreateSitelenFontPairController = (
  options: FontPairControllerCreateOptions,
) => SitelenFontPairControllerRuntime;

export interface SitelenVectorExporterCreateOptions {
  renderer: RendererInstanceRuntime;
  fontController?: SitelenFontPairControllerRuntime | null;
  wasmModuleUrl?: string | URL;
  onStatus?: ((message: string) => void) | null;
  debug?: boolean;
  debugWasm?: boolean;
  [key: string]: unknown;
}

export interface VectorExportArgs {
  input?: string;
  config?: RendererConfig;
  paddingPx?: number;
  fallbackWidthPx?: number | null;
  fallbackHeightPx?: number | null;
  [key: string]: unknown;
}

export interface SitelenVectorExporterRuntime {
  readonly renderer: RendererInstanceRuntime;
  readonly fontController: SitelenFontPairControllerRuntime | null;
  readonly ready: Promise<unknown>;
  status(message: unknown): void;
  setDebug(enabled: unknown): boolean;
  setDebugWasm(enabled: unknown): boolean;
  getActiveLiteralCartoucheRuleClipScale(): unknown;
  setActiveLiteralCartoucheRuleClipScale(value: unknown, options?: { persist?: boolean }): Promise<unknown>;
  getActiveLiteralCartoucheRuleClipStrategy(): unknown;
  setActiveLiteralCartoucheRuleClipStrategy(value: unknown, options?: { persist?: boolean }): Promise<unknown>;
  getActiveLiteralCartoucheLeftCapClipRatio(): unknown;
  setActiveLiteralCartoucheLeftCapClipRatio(value: unknown, options?: { persist?: boolean }): Promise<unknown>;
  log(message: unknown, data?: unknown): void;
  warn(message: unknown, data?: unknown): void;
  buildPlan(args: { input: string; config?: RendererConfig }): Promise<RenderPlan>;
  exportTextToVectorDocument(args?: VectorExportArgs): Promise<unknown>;
  exportPlanToVectorDocument(args: { plan: RenderPlan; paddingPx?: number; fallbackWidthPx?: number | null; fallbackHeightPx?: number | null; debugWasm?: boolean; debug?: boolean }): Promise<unknown>;
  resolveFontBytesForRun(run: RenderPlanRun, options?: { debugWasm?: boolean; runIndex?: number | null }): Promise<Uint8Array | ArrayBuffer | unknown>;
  exportTextToSvgBlob(args?: VectorExportArgs): Promise<Blob>;
  exportTextToPdfBlob(args?: VectorExportArgs): Promise<Blob>;
  downloadSvg(args?: VectorExportArgs): Promise<unknown>;
  downloadPdf(args?: VectorExportArgs): Promise<unknown>;
  [key: string]: unknown;
}

export interface SitelenVectorExporterRuntimeConstructor {
  new (options: SitelenVectorExporterCreateOptions): SitelenVectorExporterRuntime;
  create(options: SitelenVectorExporterCreateOptions): Promise<SitelenVectorExporterRuntime>;
}
