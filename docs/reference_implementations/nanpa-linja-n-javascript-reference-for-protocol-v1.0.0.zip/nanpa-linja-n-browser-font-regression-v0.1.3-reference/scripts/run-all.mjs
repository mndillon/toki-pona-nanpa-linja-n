import {spawnSync} from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
const hasAssets=fs.existsSync(path.resolve('assets/fonts/preloaded-font-pairs.manifest.json'));
const steps=[
  ['reference hashes',['scripts/verify-reference-hashes.mjs']],
  ['fixtures',['scripts/validate-fixtures.mjs']],
  ['browser core',['scripts/run-browser-regression.mjs']]
];
if(hasAssets) steps.push(
  ['asset inspection',['scripts/inspect-assets.mjs']],
  ['font files',['scripts/verify-font-files.mjs']],
  ['browser fonts',['scripts/run-browser-regression.mjs','--fonts']],
  ['SVG goldens',['scripts/svg-goldens.mjs']]
); else console.log('NOTE: production font manifest not present; asset-dependent stages will be skipped.');
let failed=0;
for(const [name,args] of steps){
  console.log(`\n=== ${name} ===`);
  const r=spawnSync(process.execPath,args,{stdio:'inherit'});
  if(r.status!==0){failed++;console.error(`${name}: FAIL`);}
}
if(failed){console.error(`\n${failed} step(s) failed`);process.exitCode=1;}
else console.log('\nALL CONFIGURED TESTS PASS');
