import { SitelenRenderer } from '../reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js';
import { createSitelenFontPairController } from '../reference/sitelen-font-pair-controller.js';
import { SitelenVectorExporter } from '../reference/sitelen-vector-exporter.js';
import { NanpaLinjaN } from '../src/nanpa-linja-n.js';

const CP = { CART_START:0xF1990, CART_END:0xF1991 };
const params = new URLSearchParams(location.search);
const mode = params.get('mode') || 'core';
const human = document.querySelector('#human');
const resultEl = document.querySelector('#nanpa-result-b64');
const stage = document.querySelector('#stage');
const failures=[]; let checks=0; const notes=[];
function equal(a,b){return JSON.stringify(a)===JSON.stringify(b)}
function check(ok,id,field,actual,expected){checks++; if(!ok) failures.push({id,field,actual,expected});}
function cpLabel(v){ return Number.isFinite(Number(v)) ? `U+${Number(v).toString(16).toUpperCase().padStart(4,'0')}` : null; }
function flattenRuns(plan){return (plan?.lines||[]).flatMap(l=>l.runs||[]).filter(Boolean)}
function cartoucheRuns(plan){return flattenRuns(plan).filter(r=>String(r.kind||'').toLowerCase()==='cartouche' || String(r?._element?.type||'').toLowerCase()==='cartouche')}
function canonicalFull(run){ return run.canonicalFullCps || run?._element?.canonicalFullCps || null; }
function innerCps(run){
  let a=run.canonicalCps || run.cps || run?._element?.canonicalCps || run?._element?.cps || null;
  if(!Array.isArray(a)){ const f=canonicalFull(run); if(Array.isArray(f)) a=f.slice(1,-1); }
  if(Array.isArray(a) && a[0]===CP.CART_START && a[a.length-1]===CP.CART_END) a=a.slice(1,-1);
  return Array.isArray(a)?a.map(Number):[];
}
function merge(base,extra){ const out=structuredClone(base||{}); for(const [k,v] of Object.entries(extra||{})){ if(v && typeof v==='object' && !Array.isArray(v) && out[k] && typeof out[k]==='object' && !Array.isArray(out[k])) out[k]=merge(out[k],v); else out[k]=structuredClone(v); } return out; }
async function loadJson(url){ const r=await fetch(url,{cache:'no-store'}); if(!r.ok) throw new Error(`${url}: ${r.status}`); return r.json(); }

async function runRendererCases(){
  const fx=await loadJson('../fixtures/renderer-browser-cases.json');
  const renderer=await SitelenRenderer.create(fx.defaultConfig);
  for(const tc of fx.cases){
    let plan;
    try { plan=await renderer.buildRenderPlan({input:tc.input,...(tc.config||{})}); }
    catch(e){ failures.push({id:tc.id,field:'exception',actual:e?.stack||String(e),expected:'no exception'}); continue; }
    const runs=flattenRuns(plan); const carts=cartoucheRuns(plan); const ex=tc.expect||{};
    if(ex.cartoucheCount!=null) check(carts.length===ex.cartoucheCount,tc.id,'cartoucheCount',carts.length,ex.cartoucheCount);
    if(ex.minimumDrawableRuns!=null) check(runs.filter(r=>r.kind!=='gap').length>=ex.minimumDrawableRuns,tc.id,'minimumDrawableRuns',runs.length,`>=${ex.minimumDrawableRuns}`);
    if(ex.firstCartouche){
      const r=carts[0]; check(!!r,tc.id,'firstCartouche.present',!!r,true); if(!r) continue;
      const e=ex.firstCartouche; const inner=innerCps(r); const full=canonicalFull(r)||[];
      for(const key of ['fontRole','isNumericCartouche','isHexCartouche','isBinaryCartouche','numericBase']) if(e[key]!==undefined) check(equal(r[key]??r?._element?.[key],e[key]),tc.id,`firstCartouche.${key}`,r[key]??r?._element?.[key],e[key]);
      if(e.openerCp) check(cpLabel(inner[0])===e.openerCp,tc.id,'firstCartouche.openerCp',cpLabel(inner[0]),e.openerCp);
      if(e.closerCp) check(cpLabel(inner.at(-1))===e.closerCp,tc.id,'firstCartouche.closerCp',cpLabel(inner.at(-1)),e.closerCp);
      if(e.fullStartCp) check(cpLabel(full[0])===e.fullStartCp,tc.id,'firstCartouche.fullStartCp',cpLabel(full[0]),e.fullStartCp);
      if(e.fullEndCp) check(cpLabel(full.at(-1))===e.fullEndCp,tc.id,'firstCartouche.fullEndCp',cpLabel(full.at(-1)),e.fullEndCp);
    }
    if(ex.abbreviated){ const r=carts[0]; const src=r?.audioSourceCps||r?._element?.audioSourceCps; const shown=innerCps(r); check(Array.isArray(src)&&shown.length<=src.length,tc.id,'abbreviated.length',shown.length,Array.isArray(src)?`<=${src.length}`:'audioSourceCps array'); }
  }
}

async function runControllerCases(){
  const fx=await loadJson('../fixtures/font-controller-cases.json');
  const script=document.createElement('select'), text=document.createElement('select'); document.body.append(script,text);
  const p=fx.mockPreset; const c=createSitelenFontPairController({registry:{[p.key]:p},scriptSelect:script,textFontSelect:text,defaultPresetKey:p.key,defaultTextFontOption:'Arial',storageKeyPrefix:'nanpaRegression'});
  await c.ready;
  const roles=c.buildFontRoles({preset:p,textFontOptionKey:'Arial'});
  for(const [k,v] of Object.entries(fx.expect.roles)) check(roles[k]===v,'font-controller',`roles.${k}`,roles[k],v);
  const rc=c.buildRendererConfig({preset:p,baseConfig:{}});
  for(const [k,v] of Object.entries(fx.expect.parser)) check(rc.parser[k]===v,'font-controller',`parser.${k}`,rc.parser[k],v);
  check(rc.fonts.renderAdapterId===fx.expect.defaultRenderAdapterId,'font-controller','renderAdapterId',rc.fonts.renderAdapterId,fx.expect.defaultRenderAdapterId);
  c.destroy(); script.remove(); text.remove();
}

function mockFontController(){ const blob=new Blob([new TextEncoder().encode('mock font bytes')],{type:'application/octet-stream'}); const preset={key:'mock-vector',textFamily:'MockVector',cartoucheFamily:'MockVector',faces:[]}; return {getActivePreset:()=>preset,resolvePresetRecord:async()=>({pairRecord:{baseFamily:'MockVector',companionFamily:'MockVector',baseBlob:blob,companionBlob:blob}})}; }
async function runVectorMockCases(){
  const fx=await loadJson('../fixtures/vector-export-cases.json');
  const parser={mode:'uniform',numericMode:'uniform',relaxedNanpaLinjanParsing:true,relaxedNanpaLinjanRendering:true,nanpaColonParsing:true,nanpaColonRendering:true,enableHexParsing:true,enableBinaryParsing:true};
  const renderer=await SitelenRenderer.create({parser,fonts:{roles:{word:'MockVector',text:'MockVector',cartouche:'MockVector',number:'MockVector',date:'MockVector',time:'MockVector',literal:'MockVector',literalCartouche:'MockVector'}}});
  const exporter=await SitelenVectorExporter.create({renderer,fontController:mockFontController(),wasmModuleUrl:new URL('../mock/mock-vector-wasm.mjs',import.meta.url).href});
  const mock=await import('../mock/mock-vector-wasm.mjs');
  for(const tc of fx.cases){
    mock.resetCalls();
    const cfg={layout:{fontPx:tc.fontPx},parser,fonts:{roles:{word:'MockVector',text:'MockVector',cartouche:'MockVector',number:'MockVector',date:'MockVector',time:'MockVector',literal:'MockVector',literalCartouche:'MockVector'}}};
    const blob=await exporter.exportTextToSvgBlob({input:tc.input,config:cfg,paddingPx:4}); const svg=await blob.text();
    if(tc.expect?.svg){ check(String(blob.type||'').toLowerCase().startsWith('image/svg+xml'),'vector:'+tc.id,'blob.type',blob.type,'image/svg+xml[; parameters allowed]'); check(svg.includes('<svg'),'vector:'+tc.id,'svg tag',svg.includes('<svg'),true); const paths=(svg.match(/<path\b/g)||[]).length; check(paths>=tc.expect.minimumPaths,'vector:'+tc.id,'pathCount',paths,`>=${tc.expect.minimumPaths}`); }
    if(tc.expectOpenTypeFeatures){ const features=mock.calls.filter(c=>Array.isArray(c.openTypeFeatures)).flatMap(c=>c.openTypeFeatures); const uniq=[...new Set(features)]; check(equal(uniq,tc.expectOpenTypeFeatures),'vector:'+tc.id,'openTypeFeatures',uniq,tc.expectOpenTypeFeatures); }
  }
  const pdf=await exporter.exportTextToPdfBlob({input:'123.45',config:{layout:{fontPx:56},parser,fonts:{roles:{word:'MockVector',text:'MockVector',cartouche:'MockVector',number:'MockVector',date:'MockVector',time:'MockVector',literal:'MockVector',literalCartouche:'MockVector'}}}}); const head=await pdf.slice(0,8).text(); check(pdf.type==='application/pdf','vector:pdf','blob.type',pdf.type,'application/pdf'); check(head.startsWith('%PDF-1.'),'vector:pdf','header',head,'%PDF-1.x');
}

function productionManifest(){ return globalThis.__NANPA_PRODUCTION_MANIFEST__ || null; }
function productionAssetMeta(){ return Array.isArray(globalThis.__NANPA_FONT_ASSETS_META__) ? globalThis.__NANPA_FONT_ASSETS_META__ : []; }
function productionAssetUrls(){ return globalThis.__NANPA_FONT_ASSET_URLS__ || {}; }
function pairRegressionOptions(pair){ const r=(pair?.regression&&typeof pair.regression==='object')?pair.regression:{}; return {browser:r.browser!==false,vector:r.vector!==false}; }
const LEGACY_ASCII_ADAPTERS=new Set(['linja-pona-legacy-v1','linja-sike-legacy-v1']);
function runRenderFullCps(run){ const candidates=[run?.renderFullCps,run?._element?.renderFullCps,run?.renderCps,run?._element?.renderCps]; for(const v of candidates) if(Array.isArray(v)&&v.length) return v.map(Number); return []; }
function presetRegistryFromProduction(manifest){
  const r={}; const meta=productionAssetMeta(); const urls=productionAssetUrls();
  for(const pair of manifest?.pairs||[]){
    const key=String(pair?.fontKey||'').trim(); if(!key) continue;
    const faces=meta.filter(a=>a.pairKey===key).map(a=>({family:a.family,url:urls[a.id],format:a.format,sample:a.sample||undefined})).filter(f=>f.family&&f.url);
    r[key]={
      key,
      label:pair.label||key,
      textFamily:pair.baseFamily||pair.textFamily||key,
      cartoucheFamily:pair.companionFamily||pair.cartoucheFamily||`${key}-nanpa-linja-n`,
      literalCartoucheFamily:pair.literalCartoucheFamily||pair.literalCartoucheFontFamily||pair.baseFamily||pair.textFamily||key,
      parserMode:pair.parserMode||'sitelen-pona-ascii-extended',
      renderAdapterId:pair.renderAdapterId||'identity',
      renderAdapterSettings:{...(pair.renderAdapterSettings||{})},
      settings:{...(pair.settings||{})},
      faces,
      __pairRecord:{...pair}
    };
  }
  return r;
}
async function runAssetFontTests(){
  const manifest=productionManifest(); if(!manifest?.pairs?.length){ notes.push('production font manifest/assets not embedded: asset browser tests skipped'); return; }
  if(!globalThis.__NANPA_REAL_VECTOR_WASM_MODULE__){ check(false,'vector-wasm','module','missing','loaded production vector WASM module'); }
  else if(typeof globalThis.__NANPA_REAL_VECTOR_WASM_MODULE__.healthcheck==='function'){
    const health=String(globalThis.__NANPA_REAL_VECTOR_WASM_MODULE__.healthcheck());
    check(health.length>0,'vector-wasm','healthcheck',health,'non-empty');
  }
  const registry=presetRegistryFromProduction(manifest); const keys=Object.keys(registry); if(!keys.length){notes.push('production manifest has no usable font pairs');return;}
  const script=document.createElement('select'), text=document.createElement('select'); document.body.append(script,text);
  const c=createSitelenFontPairController({registry,scriptSelect:script,textFontSelect:text,defaultPresetKey:keys[0],defaultTextFontOption:'__active_text_family__',storageKeyPrefix:'nanpaAssetRegression'}); await c.ready;
  for(const key of keys){
    const pair=(manifest.pairs||[]).find(p=>p.fontKey===key)||{}; if(!pairRegressionOptions(pair).browser) continue;
    c.setActivePreset(key,{persist:false}); await c.waitForConfiguredFonts(56); const p=c.getActivePreset();
    for(const f of p.faces||[]){
      const sample=f.sample||String.fromCodePoint(0xF196C,0xF1954,0xF1990)+' Hello';
      const loaded=await document.fonts.load(`56px "${f.family}"`,sample);
      check(loaded.length>0,`font-assets:${key}`,`load:${f.family}`,loaded.length,'>0');
    }
    if(p.cartoucheFamily){
      for(const [suffix,px] of [['--nanpa-cartouche-ss12',18],['--nanpa-cartouche-ss13',29]]){
        const fam=p.cartoucheFamily+suffix; const loaded=await document.fonts.load(`${px}px "${fam}"`,String.fromCodePoint(0xF193D,0xF1990));
        check(loaded.length>0,`font-assets:${key}`,`alias:${fam}`,loaded.length,'>0');
      }
    }
    const parser={mode:p.parserMode||'sitelen-pona-ascii-extended',numericMode:'uniform',relaxedNanpaLinjanParsing:true,relaxedNanpaLinjanRendering:true,nanpaColonParsing:true,nanpaColonRendering:true,enableHexParsing:true,enableBinaryParsing:true};
    const renderer=await SitelenRenderer.create(c.buildRendererConfig({preset:p,baseConfig:{layout:{fontPx:56},parser}}));
    const probeInput='2026-09-13';
    const probePlan=await renderer.buildRenderPlan({input:probeInput});
    const probeCartouche=cartoucheRuns(probePlan)[0]||null;
    check(!!probeCartouche,`font-assets:${key}`,'adapter probe cartouche',!!probeCartouche,true);
    if(probeCartouche){
      const expectedAdapter=String(pair.renderAdapterId||'identity').trim()||'identity';
      const actualAdapter=String(probeCartouche.renderAdapterId||probeCartouche?._element?.renderAdapterId||'identity');
      check(actualAdapter===expectedAdapter,`font-assets:${key}`,'renderAdapterId',actualAdapter,expectedAdapter);
      const rendered=runRenderFullCps(probeCartouche);
      check(rendered.length>0,`font-assets:${key}`,'adapter render codepoints',rendered.length,'>0');
      check(!rendered.includes(0xFFFD),`font-assets:${key}`,'adapter replacement glyph',rendered.includes(0xFFFD),false);
      if(LEGACY_ASCII_ADAPTERS.has(expectedAdapter)){
        const canonical=canonicalFull(probeCartouche)||[];
        check(rendered.every(cp=>cp>=0x20&&cp<=0x7E),`font-assets:${key}`,'legacy adapter native ASCII',rendered.map(cpLabel),'all printable ASCII');
        check(!equal(rendered,canonical),`font-assets:${key}`,'legacy adapter translated canonical sequence',rendered.map(cpLabel),'different from canonicalFullCps');
      }
    }
    const renderedCanvas=await renderer.renderTextToNewCanvas({input:probeInput});
    const canvas=renderedCanvas?.canvas || renderedCanvas;
    check(!!canvas&&Number(canvas.width)>0&&Number(canvas.height)>0,`font-assets:${key}`,'canvas dimensions',canvas?{w:canvas.width,h:canvas.height}:null,'>0');
    const ctx=canvas?.getContext?.('2d')||null; let ink=0; if(ctx){ const d=ctx.getImageData(0,0,canvas.width,canvas.height).data; for(let i=3;i<d.length;i+=4) if(d[i]){ink++;if(ink>32)break;} }
    check(ink>0,`font-assets:${key}`,'canvas nonblank',ink,'>0');
  }
  c.destroy(); script.remove(); text.remove();
}


async function runFacadeCases(){
  const facade=await NanpaLinjaN.create({storageKeyPrefix:'nanpaFacadeRegression'});
  const fonts=facade.listFonts();
  const manifest=productionManifest();
  const expectedFonts=Array.isArray(manifest?.pairs)?manifest.pairs.length:8;
  check(Array.isArray(fonts),'facade','fonts.array',Array.isArray(fonts),true);
  check(fonts.length===expectedFonts,'facade','fonts.length',fonts.length,expectedFonts);
  check(fonts.some(f=>f.key==='linjaPona'),'facade','fonts.contains.linjaPona',fonts.map(f=>f.key), 'contains linjaPona');
  check(facade.getFontInfo('linja-pona')?.key==='linjaPona','facade','font alias resolution',facade.getFontInfo('linja-pona')?.key,'linjaPona');

  const astRoundTripSource='jan   pona [ jan  pona,, ]\n\n“toki pona”';
  const astRoundTripParsed=await facade.parse(astRoundTripSource);
  const astRoundTripText=facade.astToText(astRoundTripParsed.ast);
  check(astRoundTripText===astRoundTripSource,'facade','astToText.roundTrip',astRoundTripText,astRoundTripSource);

  const editedAst=structuredClone(astRoundTripParsed.ast);
  const editedBracket=editedAst.lines.flatMap(line=>line.children||[]).find(seg=>seg.kind==='bracket');
  check(!!editedBracket,'facade','astToText.edit.bracket.present',!!editedBracket,true);
  if(editedBracket) editedBracket.value=' jan  suno,, ';
  const editedText=facade.astToText(editedAst);
  const expectedEditedText='jan   pona [ jan  suno,, ]\n\n“toki pona”';
  check(editedText===expectedEditedText,'facade','astToText.edit.bracket',editedText,expectedEditedText);
  const editedCanvas=await facade.renderToCanvas(editedText,{font:'linjaPona'});
  check(Number(editedCanvas.width)>0&&Number(editedCanvas.height)>0,'facade','astToText.edit.renderable',editedCanvas?{w:editedCanvas.width,h:editedCanvas.height}:null,'>0');

  const sentenceSplitSource='jan li pona. ona   li pona.';
  const sentenceSplitParsed=await facade.parse(sentenceSplitSource,{parser:{breakLinesAtFullStops:true}});
  check(sentenceSplitParsed.ast.lines.length===2,'facade','astToText.sentenceSplit.lineCount',sentenceSplitParsed.ast.lines.length,2);
  check(facade.astToText(sentenceSplitParsed.ast)===sentenceSplitSource,'facade','astToText.sentenceSplit.roundTrip',facade.astToText(sentenceSplitParsed.ast),sentenceSplitSource);

  const imageSource="jan img(src='x.png', w=20, alt='x') pona";
  const imageParsed=await facade.parse(imageSource);
  const imageText=facade.astToText(imageParsed.ast);
  const imageReparsed=await facade.parse(imageText);
  const imageBefore=imageParsed.ast.lines.flatMap(line=>line.children||[]).find(seg=>seg.kind==='image')?.value||null;
  const imageAfter=imageReparsed.ast.lines.flatMap(line=>line.children||[]).find(seg=>seg.kind==='image')?.value||null;
  check(equal(imageAfter,imageBefore),'facade','astToText.image.semanticRoundTrip',imageAfter,imageBefore);

  const rawUcsurText=facade.astToText({type:'document',lines:[{type:'line',sourceLineIndex:0,children:[{kind:'rawUcsur',cps:[0xF1900,0xF1901]}]}]});
  check(rawUcsurText==='U+F1900 U+F1901','facade','astToText.rawUcsur',rawUcsurText,'U+F1900 U+F1901');

  const canvasResult=await facade.render('12:30');
  check(canvasResult.kind==='canvas','facade','render.default.kind',canvasResult.kind,'canvas');
  check(canvasResult.fontKey==='nasinNanpa','facade','render.default.fontKey',canvasResult.fontKey,'nasinNanpa');
  check(Number(canvasResult.width)>0&&Number(canvasResult.height)>0,'facade','render.default.canvas',canvasResult?{w:canvasResult.width,h:canvasResult.height}:null,'>0');
  check(!!canvasResult.plan,'facade','render.default.plan',!!canvasResult.plan,true);

  const lpPlan=await facade.buildRenderPlan('2026-09-13',{font:'linjaPona'});
  const lpCart=cartoucheRuns(lpPlan.plan)[0]||null;
  check(!!lpCart,'facade','linjaPona.plan.cartouche',!!lpCart,true);
  if(lpCart){
    const adapter=String(lpCart.renderAdapterId||lpCart?._element?.renderAdapterId||'identity');
    const rendered=runRenderFullCps(lpCart);
    check(adapter==='linja-pona-legacy-v1','facade','linjaPona.adapter',adapter,'linja-pona-legacy-v1');
    check(rendered.length>0,'facade','linjaPona.rendered.length',rendered.length,'>0');
    check(rendered.every(cp=>cp>=0x20&&cp<=0x7E),'facade','linjaPona.rendered.printableAscii',rendered.map(cpLabel),'all printable ASCII');
  }

  const pngResult=await facade.renderToPng('123.45',{font:'fairfaxHd'});
  const pngHead=Array.from(pngResult.bytes.slice(0,8));
  check(pngResult.kind==='png','facade','png.kind',pngResult.kind,'png');
  check(pngResult.blob.type==='image/png','facade','png.type',pngResult.blob.type,'image/png');
  check(equal(pngHead,[137,80,78,71,13,10,26,10]),'facade','png.signature',pngHead,[137,80,78,71,13,10,26,10]);

  if(globalThis.__NANPA_REAL_VECTOR_WASM_URL__){
    const svgResult=await facade.renderToSvg('#ABCDEF',{font:'linjaSike'});
    check(svgResult.kind==='svg','facade','svg.kind',svgResult.kind,'svg');
    check(String(svgResult.blob.type||'').toLowerCase().startsWith('image/svg+xml'),'facade','svg.type',svgResult.blob.type,'image/svg+xml[; parameters allowed]');
    check(svgResult.svg.includes('<svg'),'facade','svg.payload',svgResult.svg.includes('<svg'),true);

    const pdfResult=await facade.renderToPdf('0b10101',{font:'nasinNanpa'});
    const pdfHead=new TextDecoder().decode(pdfResult.bytes.slice(0,8));
    check(pdfResult.kind==='pdf','facade','pdf.kind',pdfResult.kind,'pdf');
    check(pdfResult.blob.type==='application/pdf','facade','pdf.type',pdfResult.blob.type,'application/pdf');
    check(pdfHead.startsWith('%PDF-1.'),'facade','pdf.header',pdfHead,'%PDF-1.x');
  } else {
    notes.push('facade SVG/PDF tests skipped: production vector WASM not embedded');
  }

  await facade.destroy();
}

async function runRealVectorGoldens(){
  const manifest=productionManifest();
  if(!manifest?.pairs?.length || !globalThis.__NANPA_REAL_VECTOR_WASM_URL__){ notes.push('production font/vector assets not embedded: SVG golden generation skipped'); return {}; }
  if(globalThis.__NANPA_REAL_VECTOR_WASM_MODULE__?.healthcheck){
    const health=String(globalThis.__NANPA_REAL_VECTOR_WASM_MODULE__.healthcheck());
    check(health.length>0,'vector-wasm','healthcheck',health,'non-empty');
  }
  const registry=presetRegistryFromProduction(manifest); const fx=await loadJson('../fixtures/svg-golden-cases.json'); const output={};
  for(const key of Object.keys(registry)){
    const pair=(manifest.pairs||[]).find(p=>p.fontKey===key)||{}; if(!pairRegressionOptions(pair).vector) continue;
    const fc=createSitelenFontPairController({registry,defaultPresetKey:key,storageKeyPrefix:`nanpaGolden-${key}`}); await fc.ready; fc.setActivePreset(key,{persist:false}); await fc.waitForConfiguredFonts(56); const preset=fc.getActivePreset();
    const parser={mode:preset.parserMode||'sitelen-pona-ascii-extended',numericMode:'uniform',relaxedNanpaLinjanParsing:true,relaxedNanpaLinjanRendering:true,nanpaColonParsing:true,nanpaColonRendering:true,enableHexParsing:true,enableBinaryParsing:true};
    const renderer=await SitelenRenderer.create(fc.buildRendererConfig({preset,baseConfig:{parser}}));
    const exporter=await SitelenVectorExporter.create({renderer,fontController:fc,wasmModuleUrl:globalThis.__NANPA_REAL_VECTOR_WASM_URL__});
    for(const tc of fx.cases){ const config=fc.buildRendererConfig({preset,baseConfig:{layout:{fontPx:tc.fontPx},parser}}); const blob=await exporter.exportTextToSvgBlob({input:tc.input,config,paddingPx:8}); output[`${key}--${tc.id}`]=(await blob.text()).replace(/\r\n/g,'\n').trim()+'\n'; }
    fc.destroy();
  }
  return output;
}

async function main(){
  try {
    if(mode==='core' || mode==='all'){ await runRendererCases(); await runControllerCases(); await runVectorMockCases(); await runFacadeCases(); }
    if(mode==='fonts' || mode==='all') await runAssetFontTests();
    let artifacts={}; if(mode==='svg-goldens') artifacts=await runRealVectorGoldens();
    const result={status:failures.length?'FAIL':'PASS',mode,checks,failures,notes,artifacts};
    human.textContent=`${result.status}: ${checks} checks, ${failures.length} failures\n`+failures.map(f=>`${f.id} ${f.field}: ${JSON.stringify(f.actual)} != ${JSON.stringify(f.expected)}`).join('\n')+(notes.length?'\n'+notes.join('\n'):'');
    resultEl.textContent=btoa(unescape(encodeURIComponent(JSON.stringify(result)))); document.documentElement.dataset.nanpaStatus=result.status; document.title=`nanpa ${result.status}`;
  } catch(e){ const result={status:'ERROR',mode,checks,failures:[...failures,{id:'harness',field:'exception',actual:e?.stack||String(e),expected:'no exception'}],notes,artifacts:{}}; human.textContent=result.failures.at(-1).actual; resultEl.textContent=btoa(unescape(encodeURIComponent(JSON.stringify(result)))); document.documentElement.dataset.nanpaStatus='ERROR'; document.title='nanpa ERROR'; }
}
await main();
