
## Developer facade (easy browser API)

A high-level browser ESM wrapper is exported from the package root:

```js
import { NanpaLinjaN } from './src/nanpa-linja-n.js';
// or: import { NanpaLinjaN } from 'nanpa-linja-n-browser-font-regression';

const nanpa = await NanpaLinjaN.create();

const canvasResult = await nanpa.renderToCanvas('[nanpa : tu wan nanpa]');
document.body.append(canvasResult.canvas);

const pngResult = await nanpa.renderToPng('2026-09-13', { font: 'linjaPona' });
const svgResult = await nanpa.renderToSvg('#ABCDEF', { font: 'linjaSike' });
const pdfResult = await nanpa.renderToPdf('0b10101');
```

The render methods accept source text directly. A separate call to `parse()` is **not** required before rendering.

### What `parse()` is for

`parse(input, options?)` converts nanpa-linja-n source text into a structured document AST and diagnostics without producing visual output. This is useful when an application wants to inspect, validate, or modify the document structure before rendering.

```js
const parsed = await nanpa.parse('jan   pona [ jan  pona,, ]');
console.log(parsed.ast);
```

The returned document AST has `lines`; each line has `children`. The source parser currently produces these editable child kinds:

- `text` — ordinary source text. Edit `segment.value`.
- `bracket` — the contents of `[ ... ]`, without the square brackets. Edit `segment.value`.
- `quote` — quoted text. Edit `segment.value`, `segment.openQuote`, or `segment.closeQuote`.
- `image` — an `img(...)` descriptor. Edit fields under `segment.value`, including `src`, `w`, `h`, `alt`, `valign`, `wriggle`, and `transparent`.

The renderer may also use the advanced `rawUcsur` AST kind, whose editable `cps` array contains Unicode code points.

Fields such as `type`, `kind`, `index`, `sourceStart`, `sourceEnd`, `sourceText`, `normalizedInput`, and `parserOptions` are structural or source metadata rather than the normal content-editing surface. `sourceLineIndex` is used by `astToText()` to preserve the original physical line structure when `breakLinesAtFullStops` split one source line into several AST lines.

### Edit an AST and turn it back into text

`astToText(ast)` converts the current AST contents back into valid nanpa-linja-n source text. Existing render methods can then render that text normally.

```js
const parsed = await nanpa.parse('jan   pona [ jan  pona,, ]');
const ast = parsed.ast;

const bracket = ast.lines
  .flatMap(line => line.children)
  .find(segment => segment.kind === 'bracket');

bracket.value = ' jan  suno,, ';

const editedText = nanpa.astToText(ast);
console.log(editedText);
// jan   pona [ jan  suno,, ]

const canvasResult = await nanpa.renderToCanvas(editedText, {
  font: 'linjaPona',
  fontSize: 56,
});

document.body.append(canvasResult.canvas);
```

For ordinary parsed text, `astToText()` preserves whitespace stored in the AST, including multiple spaces, tabs, blank lines, spaces inside cartouches, and the recorded quote delimiters. If `breakLinesAtFullStops: true` was used during parsing, pieces with the same `sourceLineIndex` are joined back onto the same physical source line.

`img(...)` is the main exception to exact lexical preservation: the parser stores an image descriptor rather than the exact original argument formatting, so `astToText()` emits a canonical valid `img(...)` expression with equivalent descriptor values. Parser normalization can also mean that a parse/serialize round-trip is not byte-for-byte identical to the original input; for example, CRLF input is normalized to LF.

After structural edits, source-offset metadata such as `sourceStart` and `sourceEnd` may no longer describe the edited text. If fresh source mappings are needed, serialize and parse again:

```js
const editedText = nanpa.astToText(ast);
const reparsed = await nanpa.parse(editedText);
```

### Facade methods

- `NanpaLinjaN.create(options?)`
- `instance.listFonts()` / `instance.fonts`
- `instance.getFontInfo(font)`
- `instance.parse(input, options?)`
- `instance.astToText(ast)`
- `instance.buildRenderPlan(input, options?)`
- `instance.render(input, { format: 'canvas' | 'png' | 'svg' | 'pdf', ... })`
- `instance.renderToCanvas(input, options?)`
- `instance.renderToPng(input, options?)`
- `instance.renderToSvg(input, options?)`
- `instance.renderToPdf(input, options?)`

A pure named `astToText(ast)` export is also available from `./src/nanpa-linja-n.js` for applications that want to serialize an AST without calling an instance method.

### Helpful options

- `font` / `fontKey`: production font pair key such as `nasinNanpa`, `linjaPona`, `linjaSike`, `fairfaxHd`
- `fontSize`: shorthand for `layout.fontPx`
- `paddingPx`: shorthand for `layout.paddingPx`
- `layout`, `paint`, `parser`, `fonts`, or full `config` for low-level pass-through control
- `manifestUrl` / `vectorWasmUrl` when overriding packaged production assets

The low-level reference modules are still available under `./reference/...`, and `./advanced` re-exports those lower-level entry points.

# v0.1.8 overlay

This overlay makes the expanded SVG baseline mandatory. The SVG fixture must contain exactly 8 full and 8 abbreviated cases. The runner fails unless it receives `production font pairs × 16` artifacts. With the current eight production pairs this is exactly 128 SVGs: 64 full + 64 abbreviated. A stale 64-artifact run can no longer report PASS.

Apply over the existing suite and run `npm run goldens:update`, then `npm run test:svg` and `npm test`.

# nanpa-linja-n browser/font regression suite v0.1.4

This suite verifies the pinned nanpa-linja-n JavaScript renderer, production font-pair controller, production vector exporter, the production font manifest, all referenced font files, browser font loading, canvas rendering, and real SVG vector output.

## v0.1.6 vector-WASM initialization fix

The embedded browser harness initializes the real wasm-bindgen vector module before calling `healthcheck()` or constructing a real `SitelenVectorExporter`. The `.wasm` bytes are injected directly through DevTools, so this remains compatible with Flatpak Chrome and does not depend on localhost access.


## Frozen JavaScript references

`npm run verify:references` must pass before any behavioral result is trusted.

The pinned reference hashes are:

- renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js — `935b6a3e664d1ef25f496b8f7af1f8e3cfd3082c64bcec46b2dabf09e3447a7c`
- sitelen-font-pair-controller.js — `b842c7a398ac6c563634e144a9f4b48793deb1be2482a6973d99c73afcfc150e`
- sitelen-vector-exporter.js — `8ca2471de24352e5deebce940343392ce55d9a7e2811bbf4a2844beb957bf206`

## Production asset layout

The suite deliberately uses the production font manifest directly:

```text
assets/
├── fonts/
│   ├── preloaded-font-pairs.manifest.json
│   └── ...font files referenced by that manifest...
└── wasm/
    ├── sitelen_vector_wasm.js
    └── sitelen_vector_wasm_bg.wasm
```

There is no separate regression-only font manifest.

## Recommended first run

```bash
npm run verify:references
npm run browser:which
npm run test:browser
npm run inspect:assets
npm run test:assets
```

`inspect:assets` resolves every production manifest URL to the local regression asset tree and reports missing files before Chromium starts.

Active language-neutral parser corpus: `fixtures/nanpa-linja-n-regression-v1.0.2.json` (1017 checks).

`test:assets` performs three stages:

1. validates every production manifest pair and every referenced local font file;
2. derives the required nanpa-linja-n UCSUR codepoint set from the 1017-check v1.0.2 parser corpus and checks every companion font for coverage;
3. verifies `ss12`, `ss13`, and `ss14` GSUB features in every companion font, then loads every production font pair through the real `FontFace`/`document.fonts` controller path and checks a non-blank renderer canvas for every pair.

A production pair may add an optional `regression` object to opt out of a test that truly does not apply:

```json
{
  "regression": {
    "checkNumericCoverage": false,
    "requiredOpenTypeFeatures": ["ss12", "ss13", "ss14"],
    "browser": true,
    "vector": true
  }
}
```

No existing production manifest field needs to be changed for the default behavior.

## SVG vector goldens

The first configured run intentionally does not invent an approved visual baseline. Once the asset tests pass, generate the candidate SVG set with:

```bash
npm run goldens:update
```

This runs the real production `sitelen_vector_wasm.js` + `sitelen_vector_wasm_bg.wasm` against every vector-enabled production font pair and every golden case. The matrix contains the same eight semantic/size cases in both full and abbreviated numeric-cartouche modes (16 cases per font pair; 128 artifacts for the current eight production pairs). Golden IDs are namespaced by `fontKey`; abbreviated IDs end in `-abbr`. The harness also builds a full comparison plan for every abbreviated case and fails if the abbreviated cartouche is not genuinely different and shorter.

After the generated SVGs have been reviewed and accepted, future runs use:

```bash
npm run test:svg
```

A change to either an SVG or the production font manifest is reported as a regression requiring deliberate review. Upgrading from v0.1.6 intentionally requires one deliberate `npm run goldens:update` to add the 64 new abbreviated artifacts while retaining the existing 64 full-cartouche cases.

## Full suite

```bash
npm test
```

The full suite runs reference hashes, JSON fixture validation, the 94-check core browser suite, production asset inspection, static font conformance, browser font tests, and approved SVG goldens. Before an SVG baseline has been approved, the SVG layer reports a clear SKIP rather than pretending it passed.

## Browser selection

```bash
npm run browser:which
```

Flatpak Chrome/Chromium-family browsers are supported. An explicit executable may be selected with `NANPA_CHROMIUM=/path/to/browser`.

## Offline behavior

The regression suite never downloads production fonts or WASM from the internet. Manifest URLs are mapped to files already present under `assets/fonts/`, and the browser receives those bytes via Blob URLs through the DevTools harness.

### Legacy render-adapter font coverage

`linja-pona-legacy-v1` and `linja-sike-legacy-v1` intentionally do not need a canonical UCSUR cmap for numeric cartouches. The renderer converts canonical codepoints to the fonts' native ASCII ligature syntax before shaping. For these two adapters, the static font-file test checks the required native ASCII input repertoire (`a e i j k l m n o p s t u w`, `[`, `]`, `_`, `:`) and the browser test verifies that the real render plan actually performs the translation without U+FFFD replacement glyphs. Other companion fonts continue to be checked against the canonical numeric/render UCSUR set.
