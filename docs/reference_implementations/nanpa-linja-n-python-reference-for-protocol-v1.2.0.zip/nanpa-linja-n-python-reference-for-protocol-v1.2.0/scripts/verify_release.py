#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, tomllib
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
MANIFEST=ROOT/'RELEASE-MANIFEST.json'
EXPECTED={
    'packageVersion':'1.2.0',
    'protocolVersion':'1.2.0',
    'canonicalJavaScriptSha256':'6bfcb77e5177eec4d923bbd24d60dbac211e574b62e128e6dbfc07f8e859d220',
    'fontsZipSha256':'50c0375469508e806d2a6bb1ce555fa81adb72f73a497ddf7d26e4150671b209',
    'parserRendererProfileSha256':'62d96529a5d857d6e146afc29433caf8709e9e28803e95d37ff3085468080a0f',
    'parserRendererRegressionSha256':'f926ed22ee2788bad6061e7f8df78a577b4ef03f75f348d9739225bbe3e10c89',
    'coreRegressionSha256':'e4baf51251861c114f5314fc2af05eb44e1b5dbcbdebdcd2678c868f5dbf306a',
}

def sha(path:Path)->str:return hashlib.sha256(path.read_bytes()).hexdigest()

def included(rel:Path)->bool:
    if rel.as_posix()=='RELEASE-MANIFEST.json':return False
    if '__pycache__' in rel.parts or 'test-output' in rel.parts or 'build' in rel.parts or 'dist' in rel.parts:return False
    if rel.suffix=='.pyc' or any(part.endswith('.egg-info') for part in rel.parts):return False
    return True

def fail(message:str):
    print('FAIL',message);raise SystemExit(1)

def main()->int:
    data=json.loads(MANIFEST.read_text(encoding='utf-8'))
    for key,value in EXPECTED.items():
        if data.get(key)!=value:fail(f'{key}: {data.get(key)!r} != {value!r}')
    project=tomllib.loads((ROOT/'pyproject.toml').read_text(encoding='utf-8'))
    if project.get('project',{}).get('version')!='1.2.0':fail('pyproject package version')
    protocol=json.loads((ROOT/'protocol/protocol.json').read_text(encoding='utf-8'))
    if protocol.get('protocolVersion')!='1.2.0':fail('protocol version')
    fixed={
      'reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js':EXPECTED['canonicalJavaScriptSha256'],
      'nanpa_linja_n/resources/fonts.zip':EXPECTED['fontsZipSha256'],
      'protocol/conformance/parser-renderer-profile-v1.2.0.json':EXPECTED['parserRendererProfileSha256'],
      'protocol/conformance/parser-renderer-regression-v1.2.0.json':EXPECTED['parserRendererRegressionSha256'],
      'tests/nanpa-linja-n-regression-v1.0.2.json':EXPECTED['coreRegressionSha256'],
    }
    for rel,want in fixed.items():
        got=sha(ROOT/rel)
        if got!=want:fail(f'{rel}: {got} != {want}')
    actual={p.relative_to(ROOT).as_posix():sha(p) for p in ROOT.rglob('*') if p.is_file() and included(p.relative_to(ROOT))}
    recorded=data.get('files',{})
    if set(actual)!=set(recorded):fail(f'file set differs; missing={sorted(set(recorded)-set(actual))} extra={sorted(set(actual)-set(recorded))}')
    bad=[rel for rel,digest in actual.items() if recorded.get(rel)!=digest]
    if bad:fail(f'hash mismatch: {bad}')
    summary=json.loads((ROOT/'validation-summary.json').read_text(encoding='utf-8'))
    if summary.get('packageVersion')!='1.2.0' or summary.get('protocolVersion')!='1.2.0':fail('validation summary identity')
    if summary.get('fullRegressionRun') is not False:fail('build release must record that full regression was not run')
    print('PASS release identity 1.2.0 / protocol 1.2.0')
    print('PASS canonical JavaScript',EXPECTED['canonicalJavaScriptSha256'])
    print('PASS supplied fonts.zip',EXPECTED['fontsZipSha256'])
    print('PASS Protocol v1.2 profile and parser regression authorities')
    print(f'PASS {len(actual)} release file hashes and exact file set')
    return 0

if __name__=='__main__':raise SystemExit(main())
