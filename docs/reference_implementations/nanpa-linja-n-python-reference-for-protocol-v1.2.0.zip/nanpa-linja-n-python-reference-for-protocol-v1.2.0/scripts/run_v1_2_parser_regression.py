#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from nanpa_linja_n import NanpaLinjaN

CORPUS=ROOT/'protocol'/'conformance'/'parser-renderer-regression-v1.2.0.json'

def cp_text(cp:int)->str:
    return f'U+{int(cp):04X}'

def semantic(plan):
    kinds=[]; cps=[]; literals=[]; classes=[]
    for run in plan.runs:
        kinds.append(run.kind)
        if run.kind=='text':
            literals.append(run.render_text)
        else:
            cps.extend(cp_text(cp) for cp in run.canonical_codepoints)
        if run.numeric_cartouche or run.font_role=='number':
            classes.append('number')
        elif run.font_role=='cartouche':
            source=str(run.source_text or '').strip()
            literal=(len(source)>=2 and source.startswith('"') and source.endswith('"') and not source.startswith('""'))
            classes.append('literal' if literal else 'ordinary')
    return {'elementKinds':kinds,'canonicalCodepoints':cps,'literalTexts':literals,'cartoucheClasses':classes}

def ast_summary(plan):
    lines=[]
    for line in plan.ast.lines:
        row={'sourceText':line.source_text,'segments':[]}
        if line.canonical_source_text is not None: row['canonicalSourceText']=line.canonical_source_text
        if line.source_encoding is not None: row['sourceEncoding']=line.source_encoding
        for seg in line.children:
            item={'kind':seg.kind}
            if seg.value is not None:item['value']=seg.value
            row['segments'].append(item)
        lines.append(row)
    return {'normalizedInput':plan.ast.normalized_input,'lineCount':len(lines),'lines':lines}

def main()->int:
    data=json.loads(CORPUS.read_text(encoding='utf-8'))
    n=NanpaLinjaN.create(); failures=[]; passed=0
    for case in data['cases']:
        cid=case['id']; options=case.get('parserOptions') or {}; expected=case['expected']; local=[]
        try:
            plan=n.build_full_render_plan(case['input'],{'font':'nasinNanpa','parser':options})
            if ast_summary(plan)!=expected['ast']:
                local.append(f'AST got {ast_summary(plan)!r} want {expected["ast"]!r}')
            got_sem=[semantic_line for semantic_line in []]
            # build one semantic summary per line, matching the normative corpus
            summaries=[]
            for line in plan.lines:
                class View: pass
                v=View(); v.runs=line.runs
                summaries.append(semantic(v))
            if summaries!=expected['semantic']:
                local.append(f'semantic got {summaries!r} want {expected["semantic"]!r}')
            equivalent=expected.get('equivalentCanonicalInput')
            if equivalent is not None:
                other=n.build_full_render_plan(equivalent,{'font':'nasinNanpa','parser':options})
                other_s=[]
                for line in other.lines:
                    class View: pass
                    v=View(); v.runs=line.runs
                    other_s.append(semantic(v))
                if summaries!=other_s:local.append('equivalentCanonicalInput semantic mismatch')
        except Exception as exc:
            local.append(f'{type(exc).__name__}: {exc}')
        if local:failures.append((cid,local))
        else:passed+=1

    protection_cases = [
        ('cartouche-protected', '[toki. pona]'),
        ('literal-cartouche-protected', '["toki. pona"]'),
        ('long-pi-protected', 'pi(toki. pona)'),
        ('brace-protected', '{toki. pona}'),
    ]
    protection_passed = 0
    protection_options = {
        'mode': 'sitelen-pona-ascii-extended',
        'breakLinesAtFullStops': True,
    }
    for pid, source in protection_cases:
        try:
            plan = n.build_full_render_plan(source, {'font':'nasinNanpa','parser':protection_options})
            got = [line.source_text for line in plan.ast.lines]
            if got != [source]:
                failures.append((pid, [f'protected full stop split unexpectedly: got {got!r} want {[source]!r}']))
            else:
                protection_passed += 1
        except Exception as exc:
            failures.append((pid, [f'{type(exc).__name__}: {exc}']))

    print(f'Protocol v1.2 parser/renderer regression: {passed}/{len(data["cases"])} PASS')
    print(f'breakLinesAtFullStops protected-region checks: {protection_passed}/{len(protection_cases)} PASS')
    if failures:
        for cid,errors in failures:
            print(f'[{cid}]')
            for error in errors:print(' -',error)
        return 1
    return 0

if __name__=='__main__':raise SystemExit(main())
