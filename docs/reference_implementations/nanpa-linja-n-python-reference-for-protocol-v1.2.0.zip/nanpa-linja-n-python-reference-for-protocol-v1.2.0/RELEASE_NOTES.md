# Python reference — Protocol v1.2.0

This release updates the native Python reference from Protocol v1.1.0 to Protocol v1.2.0 while preserving the frozen numeric Core and unrelated renderer code.

The v1.2 implementation adds the canonical JavaScript behavior for ordinary full-stop/middle-dot parsing, direct Common Sitelen Pona/UCSUR document-input normalization, and odd/even backslash quote escaping. Explicit textual `U+...` input remains the exact raw-codepoint path. The affected document lines expose `canonical_source_text` / `source_encoding` metadata in Python and `canonicalSourceText` / `sourceEncoding` compatibility properties.

The package embeds the supplied Protocol v1.2.0 authority files, the canonical JavaScript reference with SHA-256 `6bfcb77e5177eec4d923bbd24d60dbac211e574b62e128e6dbfc07f8e859d220`, and the supplied `fonts.zip` with SHA-256 `50c0375469508e806d2a6bb1ce555fa81adb72f73a497ddf7d26e4150671b209`.

The implementation remains native Python. JavaScript is retained only as a behavioral oracle and is not executed by the library at runtime.

Per the requested build workflow, the full regression gate was not run while producing this package. Syntax/build checks and focused migration smoke checks were performed; the complete downstream test suite remains bundled for independent qualification.
