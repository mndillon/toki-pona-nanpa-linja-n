# nanpa-linja-n Dart reference implementation

Independent Dart reference implementation targeting **nanpa-linja-n Protocol v1.0.0**, **conformance corpus v1.0.2**, and the separate **Production Rendering Profile** bundled with the protocol release.

The frozen Core-v1 parser and logical renderer remain pure Dart and unchanged. Version 0.2.0 adds a high-level production-rendering facade around that existing Core implementation. It does not call JavaScript, Node.js, Rust, Python, Flutter, or a browser at runtime.

## What 0.2.0 adds

The public `NanpaLinjaN` facade provides the same developer-level workflow as the other v1.0.0 reference implementations:

```text
ordinary input
    -> frozen Core-v1 parse/logical render
    -> production font adapter/profile
    -> native text shaping
    -> PNG / SVG / PDF bytes
```

The package bundles all eight production font pairs and automatically selects the required legacy adapter for `linjaPona` and `linjaSike`. Callers do not need to translate UCSUR into legacy font syntax or manually choose `ss12`/`ss13`.

## Requirements

- Dart SDK 3.3 or newer
- no third-party Dart package dependencies
- production graphical rendering requires the native Pango/HarfBuzz + Cairo + Fontconfig stack

On ordinary Linux desktop distributions those libraries are normally supplied by the system. Core-v1 parsing and logical rendering do not use the native graphical stack.

Flutter is not required.

## High-level production API

```dart
import 'dart:io';
import 'package:nanpa_linja_n/nanpa_linja_n.dart';

void main() {
  final nanpa = NanpaLinjaN.create();

  // Default production font (nasinNanpa), default PNG output.
  final rendered = nanpa.render('123.45');
  File('number.png').writeAsBytesSync(rendered.bytes);

  // Font-specific adapter selection is automatic.
  final png = nanpa.renderToPng('12:30', font: 'linjaPona');
  File('time.png').writeAsBytesSync(png);

  File('hex.svg').writeAsBytesSync(nanpa.renderToSvg('#ABCDEF'));
  File('binary.pdf').writeAsBytesSync(nanpa.renderToPdf('0b10101'));
}
```

Useful facade methods:

```text
NanpaLinjaN.create
parse
parseNumber
parseInput
astToText
buildRenderPlan
render
renderToPng
renderToSvg
renderToPdf
listFonts / fonts
getFontInfo
normalizeFontKey
```

The default production font is `nasinNanpa` and the default font size is 56 px. The production font keys are:

```text
nasinNanpa
sitelenSeliKiwen
fairfaxHd
fairfaxPonaHd
linjaPona
linjaSike
nasinSitelenPuMono
linjaLipamanka
```

The production renderer uses the companion font from the frozen font-pair manifest. The manifest's browser/CSS family alias is preserved as metadata, while the native backend uses the family name embedded in each hashed companion font so Fontconfig/Pango cannot silently resolve the browser alias to an unrelated fallback font.

## Core-v1 API remains available

Existing pure-Dart use is unchanged:

```dart
import 'package:nanpa_linja_n/nanpa_linja_n.dart';

void main() {
  final result = parseNumber('12:30');
  if (result == null) return;

  print(result.properName);
  print(result.tpWords);
  print(result.codepoints);

  final rendered = renderNumber('#ABCDEF');
  print(rendered?.unicodeText);
}
```

All 35 frozen Core-v1 operation names documented by `protocol/API.md` remain exposed. The original seven Core implementation files under `lib/src/` are release-integrity checked and were not modified by the production-rendering work.

## Full-document AST and `astToText()`

The Full Renderer API can parse ordinary source text into a document AST, let an application replace selected immutable AST records, then serialize the edited AST back into valid nanpa-linja-n source text:

```dart
final nanpa = NanpaLinjaN.create();
final ast = nanpa.parseInput('jan [pona]');

final line = ast.lines.first;
final editedChildren = <DocumentSegment>[
  for (final segment in line.children)
    if (segment.kind == 'bracket')
      DocumentSegment(
        kind: segment.kind,
        value: 'suno',
        image: segment.image,
        openQuote: segment.openQuote,
        closeQuote: segment.closeQuote,
        sourceStart: segment.sourceStart,
        sourceEnd: segment.sourceEnd,
      )
    else
      segment,
];

final editedAst = DocumentAst(
  normalizedInput: ast.normalizedInput,
  breakLinesAtFullStops: ast.breakLinesAtFullStops,
  lines: <DocumentLine>[
    DocumentLine(
      index: line.index,
      sourceLineIndex: line.sourceLineIndex,
      sentenceIndexInSourceLine: line.sentenceIndexInSourceLine,
      sourceText: line.sourceText,
      children: editedChildren,
    ),
  ],
);

final text = nanpa.astToText(editedAst); // jan [suno]
final png = nanpa.renderFullToPng(text);
```

Dart's AST classes are immutable, so editing means constructing replacement records rather than assigning directly to fields. The normal editable content is:

- `DocumentSegment.value` for `text`, `bracket`, and `quote` segments
- `DocumentSegment.openQuote` / `closeQuote` for quote delimiters
- the fields of a replacement `ImageDescriptor` for `image` segments (`src`, `width`, `height`, `alt`, `vAlign`, `wriggle`, `transparent`)
- `DocumentLine.children` when inserting, removing, or replacing segments
- `DocumentAst.lines` when inserting, removing, or replacing logical lines

`sourceStart`, `sourceEnd`, `index`, `sentenceIndexInSourceLine`, `sourceText`, and `normalizedInput` are parser/source metadata and normally should be retained from the original AST. `sourceLineIndex` is structurally significant to `astToText()`: AST lines with the same value are concatenated as pieces of the same physical input line, while a change in `sourceLineIndex` emits a newline.

Whitespace held in text/bracket/quote values, blank lines, and quote delimiters are retained. The parser normalizes CRLF/CR line endings to LF, and `img(...)` nodes retain their parsed descriptor rather than their exact lexical formatting, so images are emitted in a canonical equivalent form.

`astToText()` is additive: existing `parse`, `parseInput`, `buildRenderPlan`, and rendering methods do not route through it. `parseInput()` now records additive numeric-span metadata on existing text/bracket segments so a caller can request a numeric re-serialization without changing the established segment kinds.

Numeric re-serialization uses the existing full-renderer options:

```dart
final ast = nanpa.parseInput('mi jo e 123');

print(nanpa.astToText(ast));
// mi jo e 123

print(nanpa.astToText(
  ast,
  options: const FullRenderOptions(numericOutput: 'properName'),
));
// mi jo e Nanpa Watusen

print(nanpa.astToText(
  ast,
  options: const FullRenderOptions(numericOutput: '#~'),
));
// mi jo e #~WTS

print(nanpa.astToText(
  ast,
  options: const FullRenderOptions(
    numericOutput: 'cartouche',
    parser: FullParserOptions(abbreviateNumericCartouches: true),
  ),
));
// mi jo e [nanpa : wan tu seli nanpa]
```

The accepted `numericOutput` values are `source`, `properName`, `#~`, and `cartouche`. `source` is the default and preserves the previous serializer behavior. Cartouche output respects `abbreviateNumericCartouches` and `preserveNumericCartoucheBreaks`; `nasinNanpaPona: true` emits ordinary Toki Pona number words where that representation is applicable. If a requested representation is not defined (for example `#~` for a hexadecimal or binary source), the original numeric source is retained.

The package-level `parseNumber()` remains public and now exposes renderer-derived abbreviated words/codepoints for decimal/date/time inputs without modifying the frozen Core parser. The facade also provides `nanpa.parseNumber(...)` for the same enriched numeric result.

## Production rendering behavior

`buildRenderPlan()` is the cross-language semantic boundary. It records:

- canonical cartouche codepoints
- selected production font
- selected render adapter
- actual native render text/codepoints
- OpenType features
- full versus abbreviated cartouche selection

For native graphical output, Dart uses:

```text
Fontconfig -> production companion font registration
Pango/HarfBuzz -> shaping and OpenType features
Cairo -> PNG / SVG / PDF surface output
```

The size-dependent production features match the other references:

```text
<= 18 px  -> calt, liga, ccmp, ss12
19-29 px  -> calt, liga, ccmp, ss13
>= 30 px  -> calt, liga, ccmp
```

## Run the complete Dart regression

From the extracted package root:

```bash
./tools/run_dart_regression.sh
```

The release gate performs:

1. Dart SDK/version check
2. current Core source-integrity pin check
3. production font/manifest/profile validation
4. `dart pub get`
5. compiler checks for every shipped Dart entry point
6. 35-operation public API smoke plus baseline-whitespace assertions (**38 checks**)
7. current parser/renderer/API/equivalence regression (**1030 checks**)
8. logical renderer smoke checks
9. production render-plan conformance (**128/128 cases**)
10. native production rendering across all 8 fonts x 16 cases (**128/128 renders**)
11. dedicated `astToText()` / public `parseNumber()` regression (**28 checks**) plus parse/render integration (**5 checks**)
12. cross-font special-glyph and low-level re-render parity checks (`te`, `to`, `zz`, linja lipamanka `jaki`/`ko`, raw Unicode, unknown text, cartouche and number runs)
13. PNG, SVG and PDF output smoke checks

The mandatory regression intentionally uses `dart compile kernel` rather than making `dart analyze` an Analysis-Server/filesystem-watcher release gate.

Expected Core-v1 output includes:

```text
parser conformance: 320/320 PASS
renderer conformance: 15/15 PASS
API conformance: 9/9 PASS
equivalence comparisons: 75 (PASS)
current conformance checks: 1030
failures: 0
```

Expected production output additionally includes:

```text
Dart production render-plan conformance: 128/128 PASS
Dart production-font facade: 128/128 render cases PASS
Dart astToText regression: 28/28 PASS
Dart astToText parse/render integration: 5/5 PASS
Dart special-glyph regression: PASS
Dart PNG/SVG/PDF production rendering smoke checks: PASS
ALL CONFIGURED DART REFERENCE AND PRODUCTION-RENDERING TESTS PASS
```

## Repository layout

```text
lib/
  nanpa_linja_n.dart
  src/
    api.dart                    # Core-v1 baseline-pinned
    constants.dart              # Core-v1 baseline-pinned
    encoding.dart               # Core-v1 + current JS whitespace baseline
    model.dart                  # Core-v1 baseline-pinned
    options.dart                # Core-v1 baseline-pinned
    parser.dart                 # Core-v1 + current JS whitespace baseline
    renderer.dart               # Core-v1 logical renderer, baseline-pinned
    facade.dart                 # high-level production facade
    production_font_registry.dart
    production_font_adapters.dart
    native_production_renderer.dart

resources/fonts.zip             # canonical production font bundle (single source)
rendering/
  production-font-pairs.manifest.json
  font-golden-cases-v1.1.0.json
  facade-render-plan-goldens-v1.0.0.json

tools/
  check_core_source_integrity.py
  check_production_assets.py
  facade_plan_conformance.dart
  facade_rendering.dart
  run_dart_regression.sh
```

## Normative boundary

Core-v1 remains defined by `protocol/SPEC.md`, `protocol/API.md`, the frozen protocol JSON and the language-neutral conformance corpus. Graphical rendering is a separate Production Rendering Profile layered on top of Core-v1. The production facade does not modify protocol semantics.

See `CONFORMANCE-DART.md` and `VALIDATION-STATUS.txt` for the exact qualification status of this archive.
