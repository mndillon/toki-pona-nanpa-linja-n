import 'package:nanpa_linja_n/nanpa_linja_n.dart';

void main() {
  const options = ParseOptions();
  for (final input in <String>['123.45', '12:30', '2026-09-13', '#ABCDEF', '0b10101']) {
    final result = parseNumber(input, options);
    print('$input -> ${result?.properName}');
    print(result?.tpWords);
  }
}
