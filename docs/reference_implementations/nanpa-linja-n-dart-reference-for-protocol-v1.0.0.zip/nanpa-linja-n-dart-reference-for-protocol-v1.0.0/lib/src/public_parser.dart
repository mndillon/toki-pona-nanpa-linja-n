import 'constants.dart';
import 'model.dart';
import 'options.dart';
import 'renderer.dart';
import 'nasin_nanpa_pona.dart';

/// Public package-level numeric parser.
///
/// This keeps the frozen Core parser semantics intact while exposing the same
/// derived compact representation data used by the renderer. Hex and binary
/// retain their canonical compact data; decimal/date/time results gain the
/// computed abbreviated word/codepoint sequence when one is defined.
List<String> _canonicalDecimalAbbreviation(
  List<String> input, {
  bool preserveBreaks = false,
}) {
  if (input.isEmpty) return const <String>[];

  const startWords = <String>{
    'nanpa',
    'nasa',
    'noka',
    'tenpo',
    'suno',
    'toki',
  };
  const dropAfterOpening = <String>{
    'nanpa',
    'en',
    'e',
    'nena',
    'open',
    'ala',
    'ike',
    'uta',
  };

  final hasTraditionalFullPositiveOpening = input.length >= 4 &&
      startWords.contains(input[0]) &&
      input[1] == 'e' &&
      input[2] == 'nena' &&
      input[3] == 'en';
  final hasColonFullPositiveOpening = input.length >= 4 &&
      startWords.contains(input[0]) &&
      input[1] == ':' &&
      input[2] == 'nena' &&
      input[3] == 'en';
  final middle = input.length > 3
      ? input.sublist(2, input.length - 1)
      : const <String>[];
  final hasFullScaffoldingAfterOpening =
      middle.any((word) => word == 'e' || dropAfterOpening.contains(word));
  final hasAlreadyAbbreviatedPositiveOpening =
      !hasTraditionalFullPositiveOpening &&
          !hasColonFullPositiveOpening &&
          !hasFullScaffoldingAfterOpening &&
          input.length >= 3 &&
          startWords.contains(input[0]) &&
          input[1] == 'en';
  final hasAlreadyAbbreviatedColonPositiveOpening =
      !hasTraditionalFullPositiveOpening &&
          !hasColonFullPositiveOpening &&
          !hasFullScaffoldingAfterOpening &&
          input.length >= 4 &&
          startWords.contains(input[0]) &&
          input[1] == ':' &&
          input[2] == 'en';

  final out = <String>[];
  var keptOpeningHead = false;
  var i = 0;
  while (i < input.length) {
    final word = input[i];
    final isFinalNanpa = word == 'nanpa' && i == input.length - 1;

    if (!keptOpeningHead) {
      out.add(word);
      if ((i == 0 && startWords.contains(word)) || word == 'nanpa') {
        keptOpeningHead = true;
      }
      i++;
      continue;
    }

    if (isFinalNanpa) {
      out.add(word);
      i++;
      continue;
    }
    if (hasTraditionalFullPositiveOpening && i == 1) {
      out.add('en');
      i = 4;
      continue;
    }
    if (hasColonFullPositiveOpening && i == 2) {
      out.add('en');
      i = 4;
      continue;
    }
    if (hasAlreadyAbbreviatedPositiveOpening && i == 1) {
      out.add('en');
      i++;
      continue;
    }
    if (hasAlreadyAbbreviatedColonPositiveOpening && i == 2) {
      out.add('en');
      i++;
      continue;
    }
    if (preserveBreaks &&
        word == 'nena' &&
        i + 3 < input.length &&
        (input[i + 1] == 'e' || input[i + 1] == 'en') &&
        input[i + 2] == 'nena' &&
        (input[i + 3] == 'e' || input[i + 3] == 'en')) {
      out.add('e');
      i += 4;
      continue;
    }
    if (dropAfterOpening.contains(word)) {
      i++;
      continue;
    }
    out.add(word);
    i++;
  }
  return out;
}

ParseResult? parseNumber(
  Object? input, [
  ParseOptions options = const ParseOptions(),
]) {
  final rendered = renderNumber(input, options);
  if (rendered == null) return null;
  final parsed = rendered.parsed;

  if (parsed.kind == null) {
    final abbreviatedWords = _canonicalDecimalAbbreviation(
      parsed.tpWords,
      preserveBreaks:
          options.preserveNumericCartoucheBreaksInAbbreviation,
    );
    final abbreviatedCodepoints = wordsToCodepoints(abbreviatedWords);
    if (abbreviatedWords.isNotEmpty && abbreviatedCodepoints != null) {
      parsed.abbreviatedWords =
          List<String>.unmodifiable(abbreviatedWords);
      parsed.abbreviatedUcsurCodepoints =
          List<int>.unmodifiable(abbreviatedCodepoints);
    }
  } else {
    if (rendered.abbreviatedWords != null) {
      parsed.abbreviatedWords =
          List<String>.unmodifiable(rendered.abbreviatedWords!);
    }
    if (rendered.abbreviatedInnerCodepoints != null) {
      parsed.abbreviatedUcsurCodepoints =
          List<int>.unmodifiable(rendered.abbreviatedInnerCodepoints!);
    }
  }

  if (options.nasinNanpaPona) {
    final words = tryPlainDecimalToNasinNanpaPonaWords(parsed.displayValue);
    parsed.nasinNanpaPonaWords = words == null
        ? null
        : List<String>.unmodifiable(words);
  }
  return parsed;
}
