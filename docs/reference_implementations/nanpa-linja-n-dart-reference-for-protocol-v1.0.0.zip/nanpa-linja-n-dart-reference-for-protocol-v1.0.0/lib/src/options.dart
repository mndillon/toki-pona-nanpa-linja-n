enum NumericMode { uniform, traditional }
enum MixedStyle { short }
enum DecimalStartGlyph { nanpa, tenpo, suno, toki }

enum SemanticKind { time, date }

class ParseOptions {
  final bool enableBinaryParsing;
  final bool enableHexParsing;
  final MixedStyle mixedStyle;
  final NumericMode mode;
  final NumericMode numericMode;
  final bool nanpaColonParsing;
  final bool nanpaColonRendering;
  final bool relaxedNanpaLinjanParsing;
  final bool relaxedNanpaLinjanRendering;
  final bool abbreviateNumericCartouches;
  final bool preserveNumericCartoucheBreaksInAbbreviation;
  final DecimalStartGlyph? numericCartoucheStartGlyph;

  const ParseOptions({
    this.enableBinaryParsing = true,
    this.enableHexParsing = true,
    this.mixedStyle = MixedStyle.short,
    this.mode = NumericMode.uniform,
    this.numericMode = NumericMode.uniform,
    this.nanpaColonParsing = true,
    this.nanpaColonRendering = true,
    this.relaxedNanpaLinjanParsing = true,
    this.relaxedNanpaLinjanRendering = true,
    this.abbreviateNumericCartouches = false,
    this.preserveNumericCartoucheBreaksInAbbreviation = false,
    this.numericCartoucheStartGlyph,
  });

  factory ParseOptions.fromJson(Map<String, dynamic>? json) {
    final j = json ?? const <String, dynamic>{};
    NumericMode modeOf(dynamic v, NumericMode fallback) =>
        v == 'traditional' ? NumericMode.traditional :
        v == 'uniform' ? NumericMode.uniform : fallback;
    DecimalStartGlyph? glyphOf(dynamic v) {
      switch ('$v'.toLowerCase()) {
        case 'nanpa': return DecimalStartGlyph.nanpa;
        case 'tenpo': return DecimalStartGlyph.tenpo;
        case 'suno': return DecimalStartGlyph.suno;
        case 'toki': return DecimalStartGlyph.toki;
      }
      return null;
    }
    final parsedMode = modeOf(j['mode'], NumericMode.uniform);
    final numericMode = modeOf(j['numericMode'], parsedMode);
    return ParseOptions(
      enableBinaryParsing: j['enableBinaryParsing'] is bool ? j['enableBinaryParsing'] as bool : true,
      enableHexParsing: j['enableHexParsing'] is bool ? j['enableHexParsing'] as bool : true,
      mode: parsedMode,
      numericMode: numericMode,
      nanpaColonParsing: j['nanpaColonParsing'] is bool ? j['nanpaColonParsing'] as bool : true,
      nanpaColonRendering: j['nanpaColonRendering'] is bool ? j['nanpaColonRendering'] as bool : true,
      relaxedNanpaLinjanParsing: j['relaxedNanpaLinjanParsing'] is bool ? j['relaxedNanpaLinjanParsing'] as bool : true,
      relaxedNanpaLinjanRendering: j['relaxedNanpaLinjanRendering'] is bool ? j['relaxedNanpaLinjanRendering'] as bool : true,
      abbreviateNumericCartouches: j['abbreviateNumericCartouches'] == true || j['numericCartoucheAbbreviation'] == true || j['abbreviatedNumericCartouches'] == true,
      preserveNumericCartoucheBreaksInAbbreviation: j['preserveNumericCartoucheBreaksInAbbreviation'] == true || j['abbreviatedNumericCartoucheBreakAsEn'] == true,
      numericCartoucheStartGlyph: glyphOf(j['numericCartoucheStartGlyph']),
    );
  }

  ParseOptions copyWith({
    bool? enableBinaryParsing,
    bool? enableHexParsing,
    NumericMode? mode,
    NumericMode? numericMode,
    bool? nanpaColonParsing,
    bool? nanpaColonRendering,
    bool? relaxedNanpaLinjanParsing,
    bool? relaxedNanpaLinjanRendering,
    bool? abbreviateNumericCartouches,
    bool? preserveNumericCartoucheBreaksInAbbreviation,
    DecimalStartGlyph? numericCartoucheStartGlyph,
    bool clearNumericCartoucheStartGlyph = false,
  }) => ParseOptions(
    enableBinaryParsing: enableBinaryParsing ?? this.enableBinaryParsing,
    enableHexParsing: enableHexParsing ?? this.enableHexParsing,
    mixedStyle: mixedStyle,
    mode: mode ?? this.mode,
    numericMode: numericMode ?? this.numericMode,
    nanpaColonParsing: nanpaColonParsing ?? this.nanpaColonParsing,
    nanpaColonRendering: nanpaColonRendering ?? this.nanpaColonRendering,
    relaxedNanpaLinjanParsing: relaxedNanpaLinjanParsing ?? this.relaxedNanpaLinjanParsing,
    relaxedNanpaLinjanRendering: relaxedNanpaLinjanRendering ?? this.relaxedNanpaLinjanRendering,
    abbreviateNumericCartouches: abbreviateNumericCartouches ?? this.abbreviateNumericCartouches,
    preserveNumericCartoucheBreaksInAbbreviation: preserveNumericCartoucheBreaksInAbbreviation ?? this.preserveNumericCartoucheBreaksInAbbreviation,
    numericCartoucheStartGlyph: clearNumericCartoucheStartGlyph ? null : (numericCartoucheStartGlyph ?? this.numericCartoucheStartGlyph),
  );

  NumericMode get effectiveNumericMode =>
      (mode == NumericMode.traditional || numericMode == NumericMode.traditional)
          ? NumericMode.traditional
          : NumericMode.uniform;

  String get numericModeName => effectiveNumericMode.name;
}
