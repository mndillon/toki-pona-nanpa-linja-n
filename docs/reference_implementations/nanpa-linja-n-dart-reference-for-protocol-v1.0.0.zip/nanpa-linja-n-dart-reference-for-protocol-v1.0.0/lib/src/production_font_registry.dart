import 'dart:convert';
import 'dart:io';

import 'font_zip_bundle.dart';

const String defaultProductionFontKey = 'nasinNanpa';

// Native Pango/Fontconfig must address the family names embedded in the
// companion font files themselves. These values are font-asset metadata.
const Map<String, String> _nativeCompanionFamilies = <String, String>{
  'nasinNanpa': 'nasin-nanpa-nanpa-linja-n-good-kasi-nasin-e-en-ss1223',
  'sitelenSeliKiwen': 'sitelen seli kiwen juniko-nanpa-linja-n Ligature-nasin-e-en',
  'fairfaxHd': 'Fairfax HD-nanpa-linja-n-nasin-e-en',
  'fairfaxPonaHd': 'Fairfax Pona HD-nanpa-linja-n-nasin-e-en',
  'linjaPona': 'linja pona 4.9-nanpa-linja-n-nasin-e-en',
  'linjaSike': 'linja sike 5-nanpa-linja-n-nasin-e-en',
  'nasinSitelenPuMono': 'nasin-sitelen-pu-nanpa-linja-n-nasin-e-en',
  'linjaLipamanka': 'linja lipamanka-nanpa-linja-n-nasin-e-en',
};

String _normalizeAlias(String value) =>
    value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), '');

class ProductionSupportFontInfo {
  final String key;
  final String family;
  final String path;
  final String format;

  const ProductionSupportFontInfo({
    required this.key,
    required this.family,
    required this.path,
    required this.format,
  });
}

class ProductionFontInfo {
  final String key;
  final String label;
  final String parserMode;
  final String renderAdapterId;
  final String baseFamily;
  final String companionFamily;
  final String nativeCompanionFamily;
  final String basePath;
  final String companionPath;
  final String? literalCartouchePath;
  final Map<String, dynamic> renderAdapterSettings;
  final Map<String, dynamic> settings;

  const ProductionFontInfo({
    required this.key,
    required this.label,
    required this.parserMode,
    required this.renderAdapterId,
    required this.baseFamily,
    required this.companionFamily,
    required this.nativeCompanionFamily,
    required this.basePath,
    required this.companionPath,
    required this.literalCartouchePath,
    required this.renderAdapterSettings,
    required this.settings,
  });

  Map<String, dynamic> toJson() => <String, dynamic>{
        'key': key,
        'label': label,
        'parserMode': parserMode,
        'renderAdapterId': renderAdapterId,
        'baseFamily': baseFamily,
        'companionFamily': companionFamily,
        'nativeCompanionFamily': nativeCompanionFamily,
        'basePath': basePath,
        'companionPath': companionPath,
        'literalCartouchePath': literalCartouchePath,
        'renderAdapterSettings': renderAdapterSettings,
        'settings': settings,
      };
}

class ProductionFontRegistry {
  /// Materialized native-font directory. The packaged source is [bundleFile].
  final Directory assetRoot;
  final File bundleFile;
  final List<ProductionFontInfo> _fonts;
  final Map<String, ProductionFontInfo> _byKey;
  final Map<String, String> _aliases;
  final Map<String, ProductionSupportFontInfo> _supportFonts;

  ProductionFontRegistry._(
    this.assetRoot,
    this.bundleFile,
    this._fonts,
    this._byKey,
    this._aliases,
    this._supportFonts,
  );

  factory ProductionFontRegistry.load({String? assetRoot}) {
    final bundleFile = assetRoot == null
        ? discoverProductionFontBundle()
        : _bundleFromOverride(assetRoot);
    final bundle = ProductionFontZipBundle.open(bundleFile);
    final rawValue = jsonDecode(bundle.readText(productionFontManifestEntry));
    if (rawValue is! Map<String, dynamic> || rawValue['pairs'] is! List) {
      throw const FormatException('Invalid production-font manifest');
    }
    final raw = rawValue;

    String requiredString(Map<String, dynamic> node, String key) {
      final value = '${node[key] ?? ''}'.trim();
      if (value.isEmpty) throw FormatException('Font pair is missing $key');
      return value;
    }

    String entryName(String filename) => 'fonts/$filename';

    final requiredEntries = <String>{productionFontManifestEntry};
    for (final rawPair in raw['pairs'] as List) {
      if (rawPair is! Map) throw const FormatException('Font pair must be an object');
      final pair = Map<String, dynamic>.from(rawPair);
      requiredEntries.add(entryName(requiredString(pair, 'baseFilename')));
      requiredEntries.add(entryName(requiredString(pair, 'companionFilename')));
      final literal = '${pair['literalCartoucheFilename'] ?? ''}'.trim();
      if (literal.isNotEmpty) requiredEntries.add(entryName(literal));
    }
    final supportRaw = raw['supportFonts'];
    if (supportRaw != null && supportRaw is! Map) {
      throw const FormatException('manifest.supportFonts must be an object');
    }
    if (supportRaw is Map) {
      for (final rawNode in supportRaw.values) {
        if (rawNode is! Map) {
          throw const FormatException('supportFonts entries must be objects');
        }
        final node = Map<String, dynamic>.from(rawNode);
        final filename = '${node['filename'] ?? node['fileName'] ?? ''}'.trim();
        if (filename.isEmpty) {
          throw const FormatException('Support font is missing filename');
        }
        requiredEntries.add(entryName(filename));
      }
    }

    final materialized = bundle.materialize(requiredEntries);

    String filePath(String filename) {
      final file = File(
        '${materialized.path}${Platform.pathSeparator}$filename',
      ).absolute;
      if (!file.existsSync()) {
        throw FileSystemException('Production font asset was not found', file.path);
      }
      return file.path;
    }

    final fonts = <ProductionFontInfo>[];
    final byKey = <String, ProductionFontInfo>{};
    final aliases = <String, String>{};
    for (final rawPair in raw['pairs'] as List) {
      final pair = Map<String, dynamic>.from(rawPair as Map);
      final key = requiredString(pair, 'fontKey');
      if (byKey.containsKey(key)) {
        throw FormatException('Duplicate production font key: $key');
      }
      final baseFilename = requiredString(pair, 'baseFilename');
      final companionFilename = requiredString(pair, 'companionFilename');
      final literalFilename = '${pair['literalCartoucheFilename'] ?? ''}'.trim();
      final info = ProductionFontInfo(
        key: key,
        label: '${pair['label'] ?? key}',
        parserMode: '${pair['parserMode'] ?? 'sitelen-pona-ascii-extended'}',
        renderAdapterId: '${pair['renderAdapterId'] ?? 'identity'}'.trim().isEmpty
            ? 'identity'
            : '${pair['renderAdapterId'] ?? 'identity'}'.trim(),
        baseFamily: '${pair['baseFamily'] ?? key}',
        companionFamily: '${pair['companionFamily'] ?? '$key-nanpa-linja-n'}',
        nativeCompanionFamily: _nativeCompanionFamilies[key] ??
            (throw FormatException('No native companion family is pinned for $key')),
        basePath: filePath(baseFilename),
        companionPath: filePath(companionFilename),
        literalCartouchePath:
            literalFilename.isEmpty ? null : filePath(literalFilename),
        renderAdapterSettings: Map<String, dynamic>.from(
          (pair['renderAdapterSettings'] as Map?) ?? const <String, dynamic>{},
        ),
        settings: Map<String, dynamic>.from(
          (pair['settings'] as Map?) ?? const <String, dynamic>{},
        ),
      );
      fonts.add(info);
      byKey[key] = info;
      for (final candidate in <String>[
        info.key,
        info.label,
        info.baseFamily,
        info.companionFamily,
      ]) {
        final alias = _normalizeAlias(candidate);
        if (alias.isNotEmpty) aliases.putIfAbsent(alias, () => key);
      }
    }
    if (fonts.length != 8) {
      throw FormatException(
        'Production Rendering Profile requires 8 font pairs; found ${fonts.length}',
      );
    }

    final supportFonts = <String, ProductionSupportFontInfo>{};
    if (supportRaw is Map) {
      for (final entry in supportRaw.entries) {
        final node = Map<String, dynamic>.from(entry.value as Map);
        final filename = '${node['filename'] ?? node['fileName'] ?? ''}'.trim();
        supportFonts['${entry.key}'] = ProductionSupportFontInfo(
          key: '${entry.key}',
          family: '${node['family'] ?? entry.key}',
          path: filePath(filename),
          format: '${node['format'] ?? ''}',
        );
      }
    }

    return ProductionFontRegistry._(
      materialized,
      bundleFile.absolute,
      List<ProductionFontInfo>.unmodifiable(fonts),
      Map<String, ProductionFontInfo>.unmodifiable(byKey),
      Map<String, String>.unmodifiable(aliases),
      Map<String, ProductionSupportFontInfo>.unmodifiable(supportFonts),
    );
  }

  List<ProductionFontInfo> get fonts => _fonts;

  ProductionSupportFontInfo? supportFont(String key) => _supportFonts[key];

  String normalizeKey(String? requested) {
    final value = (requested ?? defaultProductionFontKey).trim();
    if (_byKey.containsKey(value)) return value;
    final key = _aliases[_normalizeAlias(value)];
    if (key != null) return key;
    throw ArgumentError.value(requested, 'font', 'Unknown production font');
  }

  ProductionFontInfo get(String? requested) => _byKey[normalizeKey(requested)]!;
}

File _bundleFromOverride(String value) {
  final direct = File(value).absolute;
  if (direct.existsSync() && direct.path.toLowerCase().endsWith('.zip')) {
    return direct;
  }
  final root = Directory(value).absolute;
  final candidates = <File>[
    File('${root.path}${Platform.pathSeparator}fonts.zip'),
    File(
      '${root.path}${Platform.pathSeparator}resources'
      '${Platform.pathSeparator}fonts.zip',
    ),
  ];
  for (final candidate in candidates) {
    if (candidate.existsSync()) return candidate.absolute;
  }
  throw FileSystemException(
    'nanpa-linja-n production font bundle was not found; assetRoot must resolve to fonts.zip',
    root.path,
  );
}

File discoverProductionFontBundle() {
  final starts = <Directory>{Directory.current.absolute};
  if (Platform.script.scheme == 'file') {
    starts.add(File.fromUri(Platform.script).absolute.parent);
  }

  for (final start in starts) {
    Directory? current = start;
    while (current != null) {
      final direct = File(
        '${current.path}${Platform.pathSeparator}resources'
        '${Platform.pathSeparator}fonts.zip',
      );
      if (direct.existsSync()) return direct.absolute;

      final packageConfig = File(
        '${current.path}${Platform.pathSeparator}.dart_tool'
        '${Platform.pathSeparator}package_config.json',
      );
      if (packageConfig.existsSync()) {
        try {
          final decoded = jsonDecode(packageConfig.readAsStringSync());
          if (decoded is Map && decoded['packages'] is List) {
            for (final p in decoded['packages'] as List) {
              if (p is Map && p['name'] == 'nanpa_linja_n') {
                final rawRoot = '${p['rootUri'] ?? ''}';
                if (rawRoot.isNotEmpty) {
                  final rootUri = packageConfig.uri.resolve(rawRoot);
                  if (rootUri.scheme == 'file') {
                    final packageRoot = Directory.fromUri(rootUri).absolute;
                    final candidate = File(
                      '${packageRoot.path}${Platform.pathSeparator}resources'
                      '${Platform.pathSeparator}fonts.zip',
                    );
                    if (candidate.existsSync()) return candidate.absolute;
                  }
                }
              }
            }
          }
        } catch (_) {
          // Continue walking: an unrelated/malformed package config is not fatal.
        }
      }

      final parent = current.parent;
      if (parent.path == current.path) break;
      current = parent;
    }
  }
  throw StateError(
    'Unable to locate nanpa-linja-n resources/fonts.zip. '
    'Pass assetRoot to NanpaLinjaN.create(assetRoot: ...) with a path that resolves to fonts.zip.',
  );
}
