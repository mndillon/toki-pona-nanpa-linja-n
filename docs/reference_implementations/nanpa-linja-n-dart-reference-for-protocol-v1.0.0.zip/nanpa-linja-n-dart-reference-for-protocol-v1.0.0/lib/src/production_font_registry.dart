import 'dart:convert';
import 'dart:io';

const String defaultProductionFontKey = 'nasinNanpa';

// The Production Rendering Profile manifest uses browser/CSS family aliases.
// Native Pango/Fontconfig must address the family names embedded in the
// companion font files themselves. These names are frozen by the hashed
// production assets and verified by tools/check_production_assets.py.
const Map<String, String> _nativeCompanionFamilies = <String, String>{
  'nasinNanpa': 'nasin-nanpa-linja-n Ligature v4.4 Long Fix-nasin-e-en',
  'sitelenSeliKiwen': 'sitelen seli kiwen juniko-nanpa-linja-n Ligature-nasin-e-en',
  'fairfaxHd': 'Fairfax HD-nanpa-linja-n-nasin-e-en',
  'fairfaxPonaHd': 'Fairfax Pona HD-nanpa-linja-n-nasin-e-en',
  'linjaPona': 'linja pona 4.9-nanpa-linja-n-nasin-e-en',
  'linjaSike': 'linja sike 5-nanpa-linja-n-nasin-e-en',
  'nasinSitelenPuMono': 'nasin-sitelen-pu-nanpa-linja-n-nasin-e-en',
  'linjaLipamanka': 'linja lipamanka-nanpa-linja-n-nasin-e-en',
};

String _normalizeAlias(String value) =>
    value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), '');

class ProductionFontInfo {
  final String key;
  final String label;
  final String parserMode;
  final String renderAdapterId;
  final String baseFamily;
  final String companionFamily;
  final String nativeCompanionFamily;
  final String basePath;
  final String companionPath;
  final String? literalCartouchePath;
  final Map<String, dynamic> renderAdapterSettings;
  final Map<String, dynamic> settings;

  const ProductionFontInfo({
    required this.key,
    required this.label,
    required this.parserMode,
    required this.renderAdapterId,
    required this.baseFamily,
    required this.companionFamily,
    required this.nativeCompanionFamily,
    required this.basePath,
    required this.companionPath,
    required this.literalCartouchePath,
    required this.renderAdapterSettings,
    required this.settings,
  });

  Map<String, dynamic> toJson() => <String, dynamic>{
        'key': key,
        'label': label,
        'parserMode': parserMode,
        'renderAdapterId': renderAdapterId,
        'baseFamily': baseFamily,
        'companionFamily': companionFamily,
        'nativeCompanionFamily': nativeCompanionFamily,
        'basePath': basePath,
        'companionPath': companionPath,
        'literalCartouchePath': literalCartouchePath,
        'renderAdapterSettings': renderAdapterSettings,
        'settings': settings,
      };
}

class ProductionFontRegistry {
  final Directory assetRoot;
  final List<ProductionFontInfo> _fonts;
  final Map<String, ProductionFontInfo> _byKey;
  final Map<String, String> _aliases;

  ProductionFontRegistry._(
    this.assetRoot,
    this._fonts,
    this._byKey,
    this._aliases,
  );

  factory ProductionFontRegistry.load({String? assetRoot}) {
    final root = assetRoot == null
        ? discoverProductionAssetRoot()
        : Directory(assetRoot).absolute;
    final manifestFile =
        File('${root.path}${Platform.pathSeparator}production-font-pairs.manifest.json');
    if (!manifestFile.existsSync()) {
      throw FileSystemException(
        'nanpa-linja-n production font manifest was not found',
        manifestFile.path,
      );
    }
    final raw = jsonDecode(manifestFile.readAsStringSync());
    if (raw is! Map<String, dynamic> || raw['pairs'] is! List) {
      throw const FormatException('Invalid production-font manifest');
    }

    final fonts = <ProductionFontInfo>[];
    final byKey = <String, ProductionFontInfo>{};
    final aliases = <String, String>{};

    String requiredString(Map<String, dynamic> pair, String key) {
      final value = '${pair[key] ?? ''}'.trim();
      if (value.isEmpty) {
        throw FormatException('Font pair is missing $key');
      }
      return value;
    }

    String filePath(String filename) {
      final file = File('${root.path}${Platform.pathSeparator}$filename').absolute;
      if (!file.existsSync()) {
        throw FileSystemException('Production font asset was not found', file.path);
      }
      return file.path;
    }

    for (final rawPair in raw['pairs'] as List) {
      if (rawPair is! Map) {
        throw const FormatException('Font pair must be an object');
      }
      final pair = Map<String, dynamic>.from(rawPair);
      final key = requiredString(pair, 'fontKey');
      if (byKey.containsKey(key)) {
        throw FormatException('Duplicate production font key: $key');
      }
      final baseFilename = requiredString(pair, 'baseFilename');
      final companionFilename = requiredString(pair, 'companionFilename');
      final literalFilename = '${pair['literalCartoucheFilename'] ?? ''}'.trim();
      final info = ProductionFontInfo(
        key: key,
        label: '${pair['label'] ?? key}',
        parserMode: '${pair['parserMode'] ?? 'sitelen-pona-ascii-extended'}',
        renderAdapterId: '${pair['renderAdapterId'] ?? 'identity'}'.trim().isEmpty
            ? 'identity'
            : '${pair['renderAdapterId'] ?? 'identity'}'.trim(),
        baseFamily: '${pair['baseFamily'] ?? key}',
        companionFamily: '${pair['companionFamily'] ?? '$key-nanpa-linja-n'}',
        nativeCompanionFamily: _nativeCompanionFamilies[key] ??
            (throw FormatException('No native companion family is pinned for $key')),
        basePath: filePath(baseFilename),
        companionPath: filePath(companionFilename),
        literalCartouchePath:
            literalFilename.isEmpty ? null : filePath(literalFilename),
        renderAdapterSettings: Map<String, dynamic>.from(
          (pair['renderAdapterSettings'] as Map?) ?? const <String, dynamic>{},
        ),
        settings: Map<String, dynamic>.from(
          (pair['settings'] as Map?) ?? const <String, dynamic>{},
        ),
      );
      fonts.add(info);
      byKey[key] = info;
      for (final candidate in <String>[
        info.key,
        info.label,
        info.baseFamily,
        info.companionFamily,
      ]) {
        final alias = _normalizeAlias(candidate);
        if (alias.isNotEmpty) aliases.putIfAbsent(alias, () => key);
      }
    }
    if (fonts.length != 8) {
      throw FormatException(
        'Production Rendering Profile requires 8 font pairs; found ${fonts.length}',
      );
    }
    return ProductionFontRegistry._(
      root,
      List<ProductionFontInfo>.unmodifiable(fonts),
      Map<String, ProductionFontInfo>.unmodifiable(byKey),
      Map<String, String>.unmodifiable(aliases),
    );
  }

  List<ProductionFontInfo> get fonts => _fonts;

  String normalizeKey(String? requested) {
    final value = (requested ?? defaultProductionFontKey).trim();
    if (_byKey.containsKey(value)) return value;
    final key = _aliases[_normalizeAlias(value)];
    if (key != null) return key;
    throw ArgumentError.value(requested, 'font', 'Unknown production font');
  }

  ProductionFontInfo get(String? requested) => _byKey[normalizeKey(requested)]!;
}

Directory discoverProductionAssetRoot() {
  final starts = <Directory>{Directory.current.absolute};
  if (Platform.script.scheme == 'file') {
    starts.add(File.fromUri(Platform.script).absolute.parent);
  }

  for (final start in starts) {
    Directory? current = start;
    while (current != null) {
      final direct = Directory(
        '${current.path}${Platform.pathSeparator}assets${Platform.pathSeparator}fonts',
      );
      final directManifest = File(
        '${direct.path}${Platform.pathSeparator}production-font-pairs.manifest.json',
      );
      if (directManifest.existsSync()) return direct.absolute;

      final packageConfig = File(
        '${current.path}${Platform.pathSeparator}.dart_tool${Platform.pathSeparator}package_config.json',
      );
      if (packageConfig.existsSync()) {
        try {
          final decoded = jsonDecode(packageConfig.readAsStringSync());
          if (decoded is Map && decoded['packages'] is List) {
            for (final p in decoded['packages'] as List) {
              if (p is Map && p['name'] == 'nanpa_linja_n') {
                final rawRoot = '${p['rootUri'] ?? ''}';
                if (rawRoot.isNotEmpty) {
                  final rootUri = packageConfig.uri.resolve(rawRoot);
                  if (rootUri.scheme == 'file') {
                    final packageRoot = Directory.fromUri(rootUri).absolute;
                    final candidate = Directory(
                      '${packageRoot.path}${Platform.pathSeparator}assets${Platform.pathSeparator}fonts',
                    );
                    final manifest = File(
                      '${candidate.path}${Platform.pathSeparator}production-font-pairs.manifest.json',
                    );
                    if (manifest.existsSync()) return candidate;
                  }
                }
              }
            }
          }
        } catch (_) {
          // Continue walking: an unrelated/malformed package config is not fatal.
        }
      }

      final parent = current.parent;
      if (parent.path == current.path) break;
      current = parent;
    }
  }
  throw StateError(
    'Unable to locate nanpa-linja-n production assets. '
    'Pass assetRoot to NanpaLinjaN.create(assetRoot: ...).',
  );
}
