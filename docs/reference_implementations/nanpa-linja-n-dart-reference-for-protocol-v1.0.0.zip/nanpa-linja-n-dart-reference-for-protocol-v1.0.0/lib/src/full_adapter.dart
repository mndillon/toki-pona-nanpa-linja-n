import 'dart:math' as math;

import 'constants.dart';
import 'full_types.dart';
import 'production_font_registry.dart';

class AdaptedOrdinary {
  final String text;
  final List<List<int>> canonicalSpans;
  const AdaptedOrdinary(this.text, this.canonicalSpans);
}

class OrdinaryCartouche {
  final List<int> inner;
  final List<int> manualTallies;
  final String tallyMode;
  const OrdinaryCartouche(this.inner, this.manualTallies, this.tallyMode);
  bool get hasManualTallies => manualTallies.any((n) => n > 0);
}

double _settingFloat(Map<String, dynamic> values, String key, double fallback) {
  final value = values[key];
  if (value is num) return value.toDouble();
  if (value is String) return double.tryParse(value) ?? fallback;
  return fallback;
}

String _settingString(
  Map<String, dynamic> values,
  String key,
  String fallback,
) {
  final value = '${values[key] ?? ''}'.trim();
  return value.isEmpty ? fallback : value;
}

String? _legacyOrdinaryWord(int cp, String kind) {
  switch (cp) {
    case middleDotCodepoint:
      return '.';
    case colonCodepoint:
      return ':';
    case 0x3000:
      return kind == 'linja-lipamanka' ? 'zz' : '  ';
    case 0xF1989:
      return kind == 'linja-lipamanka' ? 'ni<' : 'ni';
    case 0xF198A:
      return (kind == 'linja-sike' || kind == 'linja-lipamanka')
          ? 'ni^'
          : 'ni';
    case 0xF198B:
      return (kind == 'linja-sike' || kind == 'linja-lipamanka')
          ? 'ni>'
          : 'ni';
    case 0xF198C:
      return kind == 'linja-sike' ? 'sewi1' : 'sewi';
    case openQuoteCodepoint:
      if (kind == 'linja-lipamanka') return 'te';
      break;
    case closeQuoteCodepoint:
      if (kind == 'linja-lipamanka') return 'to';
      break;
  }
  final word = allCodepointWords[cp];
  if (word == null) return null;
  if (kind == 'linja-pona' &&
      <int>{0xF19A2, 0xF19A4, 0xF19A5, 0xF19A6}.contains(cp)) {
    return null;
  }
  if (kind == 'linja-lipamanka' &&
      (<int>{0xF19A4, 0xF19A5, 0xF19A6}.contains(cp) || cp > 0xF19A3)) {
    return null;
  }
  return word;
}

AdaptedOrdinary adaptOrdinaryCartouche(
  ProductionFontInfo font,
  List<int> inner,
) {
  final full = <int>[cartoucheStart, ...inner, cartoucheEnd];
  final adapterId = font.renderAdapterId.trim().isEmpty
      ? 'identity'
      : font.renderAdapterId.trim();

  AdaptedOrdinary identity() {
    final text = StringBuffer();
    final spans = <List<int>>[];
    var index = 0;
    for (final cp in full) {
      final start = index;
      text.writeCharCode(cp);
      index++;
      spans.add(<int>[start, index]);
    }
    return AdaptedOrdinary(text.toString(), spans);
  }

  if (adapterId == 'linja-pona-legacy-v1' ||
      adapterId == 'linja-sike-legacy-v1') {
    final kind = adapterId.startsWith('linja-sike')
        ? 'linja-sike'
        : 'linja-pona';
    var out = '[';
    final spans = List<List<int>>.generate(
      full.length,
      (_) => <int>[0, 0],
      growable: false,
    );
    spans[0] = <int>[0, 1];
    for (var i = 1; i < full.length - 1; i++) {
      final start = out.runes.length;
      out += '_${_legacyOrdinaryWord(full[i], kind) ?? '�'}';
      spans[i] = <int>[start, out.runes.length];
    }
    final start = out.runes.length;
    out += ']';
    spans[spans.length - 1] = <int>[start, out.runes.length];
    return AdaptedOrdinary(out, spans);
  }

  if (adapterId == 'nasin-sitelen-pu-mono-v1') {
    final replacement = font.renderAdapterSettings['unsupportedReplacementCodepoint']
            is num
        ? (font.renderAdapterSettings['unsupportedReplacementCodepoint'] as num)
            .round()
        : 0xFFFD;
    final values = <int>[];
    for (final cp in full) {
      if (cp == 0xF1989 || cp == 0xF198A || cp == 0xF198B) {
        values.add(0xF1941);
      } else if (cp == 0xF198C) {
        values.add(0xF195A);
      } else if (cp == middleDotCodepoint) {
        values.add('.'.codeUnitAt(0));
      } else if (cp == colonCodepoint) {
        values.add(':'.codeUnitAt(0));
      } else if ((cp >= 0xF1900 && cp <= 0xF1988) ||
          (cp >= 0xF19A0 && cp <= 0xF19A3) ||
          cp == cartoucheStart ||
          cp == cartoucheEnd ||
          cp == 0x3000 ||
          cp == openQuoteCodepoint ||
          cp == closeQuoteCodepoint) {
        values.add(cp);
      } else {
        values.add(replacement);
      }
    }
    final text = StringBuffer();
    final spans = <List<int>>[];
    var index = 0;
    for (final cp in values) {
      final start = index;
      text.writeCharCode(cp);
      index++;
      spans.add(<int>[start, index]);
    }
    return AdaptedOrdinary(text.toString(), spans);
  }

  if (adapterId == 'linja-lipamanka-v1') {
    bool needsLegacy(int cp) =>
        cp == middleDotCodepoint ||
        cp == colonCodepoint ||
        cp == tallyCodepoint ||
        cp == 0xF1989 ||
        cp == 0xF198A ||
        cp == 0xF198B ||
        cp == 0xF198C ||
        cp == openQuoteCodepoint ||
        cp == closeQuoteCodepoint ||
        cp == 0x3000 ||
        cp == 0xF19A4 ||
        cp == 0xF19A5 ||
        cp == 0xF19A6 ||
        cp > 0xF19A3;
    if (full.any(needsLegacy)) {
      var out = '[';
      final spans = List<List<int>>.generate(
        full.length,
        (_) => <int>[0, 0],
        growable: false,
      );
      spans[0] = <int>[0, 1];
      for (var i = 1; i < full.length - 1; i++) {
        if (i > 1) out += ' ';
        final start = out.runes.length;
        out += _legacyOrdinaryWord(full[i], 'linja-lipamanka') ?? '�';
        spans[i] = <int>[start, out.runes.length];
      }
      final start = out.runes.length;
      out += ']';
      spans[spans.length - 1] = <int>[start, out.runes.length];
      return AdaptedOrdinary(out, spans);
    }
  }
  return identity();
}

OrdinaryCartouche? parseOrdinaryCartoucheBody(
  String body,
  ProductionFontInfo font,
  FullParserOptions options,
) {
  final source = body.trim();
  if (source.isEmpty) return null;
  var mode = options.cartoucheTallyMode.trim().toLowerCase();
  if (mode.isEmpty) {
    mode = _settingString(font.settings, 'cartoucheTallyMode', 'ucsur')
        .toLowerCase();
  }
  if (!<String>{'manual', 'comma', 'ucsur'}.contains(mode)) mode = 'ucsur';

  final cps = <int>[];
  final tallies = <int>[];
  final current = StringBuffer();

  bool flush() {
    final token = current.toString().trim().toLowerCase();
    current.clear();
    if (token.isEmpty) return true;
    final cp = allWordCodepoints[token];
    if (cp == null) return false;
    if (cp == tallyCodepoint && mode == 'manual') {
      if (tallies.isNotEmpty) {
        tallies[tallies.length - 1] =
            math.min(8, tallies.last + 1).toInt();
      }
      return true;
    }
    cps.add(cp);
    tallies.add(0);
    return true;
  }

  for (final cp in source.runes) {
    final ch = String.fromCharCode(cp);
    if (RegExp(r'\s').hasMatch(ch)) {
      if (!flush()) return null;
    } else if (ch == '.' || ch == '·' || ch == ':') {
      if (!flush()) return null;
      cps.add(ch == ':' ? colonCodepoint : middleDotCodepoint);
      tallies.add(0);
    } else if (ch == ',') {
      if (!flush()) return null;
      if (!options.effectiveCommaTallyMarks) continue;
      switch (mode) {
        case 'manual':
          if (tallies.isNotEmpty) {
            tallies[tallies.length - 1] =
                math.min(8, tallies.last + 1).toInt();
          }
          break;
        case 'comma':
          cps.add(','.codeUnitAt(0));
          tallies.add(0);
          break;
        default:
          cps.add(tallyCodepoint);
          tallies.add(0);
          break;
      }
    } else {
      current.write(ch);
    }
  }
  if (!flush() || cps.isEmpty) return null;
  return OrdinaryCartouche(
    List<int>.unmodifiable(cps),
    List<int>.unmodifiable(tallies),
    mode,
  );
}

final RegExp _lettersOnly = RegExp(r'^[A-Za-z]+$');

List<int>? properNameCodepoints(String word) {
  if (!_lettersOnly.hasMatch(word)) return null;
  const allowed = 'aeijklmnostpuw';
  final lower = word.toLowerCase();
  for (final cp in lower.runes) {
    if (!allowed.contains(String.fromCharCode(cp))) return null;
  }
  final keys = allWordCodepoints.keys
      .where((w) => RegExp(r'^[a-z]+$').hasMatch(w))
      .toList(growable: false)
    ..sort();
  final bucket = <String, int>{};
  for (final key in keys) {
    bucket.putIfAbsent(key[0], () => allWordCodepoints[key]!);
  }
  final out = <int>[];
  for (var i = 0; i < lower.length; i++) {
    final cp = bucket[lower[i]];
    if (cp == null) return null;
    out.add(cp);
  }
  return out;
}

List<String> nasinNanpaPonaWords(String digits) {
  final number = int.tryParse(digits);
  if (number == null || number < 0) return const <String>[];
  final out = <String>[];
  void encode(int value) {
    if (value == 0) {
      out.add('ala');
      return;
    }
    var x = value;
    if (x >= 100) {
      final q = x ~/ 100;
      final r = x % 100;
      encode(q);
      out.add('ali');
      if (r > 0) encode(r);
      return;
    }
    while (x >= 20) {
      out.add('mute');
      x -= 20;
    }
    if (x >= 5) {
      out.add('luka');
      x -= 5;
    }
    while (x >= 2) {
      out.add('tu');
      x -= 2;
    }
    if (x > 0) out.add('wan');
  }
  encode(number);
  return out;
}

double manualTallyLift(
  ProductionFontInfo font,
  FullParserOptions options,
  double fontSize,
) {
  final maxPx = options.manualTallySmallFontMaxPx ??
      _settingFloat(font.settings, 'manualTallySmallFontMaxPx', 12);
  final lift = options.manualTallySmallFontLiftPx ??
      _settingFloat(font.settings, 'manualTallySmallFontLiftPx', 0);
  return fontSize <= maxPx ? math.max(0, lift) : 0;
}

List<String> fullOpenTypeFeaturesFor(double fontSize) {
  if (fontSize <= 18) return const <String>['ss12'];
  if (fontSize <= 29) return const <String>['ss13'];
  return const <String>[];
}

bool allRunesUcsur(String text) {
  if (text.isEmpty) return false;
  for (final cp in text.runes) {
    if (!((cp >= 0xF1900 && cp <= 0xF19FF) ||
        cp == openQuoteCodepoint ||
        cp == closeQuoteCodepoint)) {
      return false;
    }
  }
  return true;
}

String sanitizeRendererWord(String value) => value
    .toLowerCase()
    .replaceAll(RegExp(r'[^a-z0-9<>\^\.]'), '');
