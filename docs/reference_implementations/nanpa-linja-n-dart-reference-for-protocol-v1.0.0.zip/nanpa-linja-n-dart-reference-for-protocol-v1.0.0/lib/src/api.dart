import 'constants.dart';
import 'encoding.dart';
import 'model.dart';
import 'options.dart';
import 'parser.dart';


ParseOptions _normalizedParseOptions(ParseOptions options) {
  if (options.mode == NumericMode.traditional || options.numericMode == NumericMode.traditional) {
    return options.copyWith(mode: NumericMode.traditional, numericMode: NumericMode.traditional);
  }
  return options;
}

class SplitCapsOptions {
  final bool titleCase;
  final bool relaxedNanpaLinjanParsing;
  final bool relaxedNanpaLinjanRendering;
  final bool nanpaColonRendering;
  const SplitCapsOptions({this.titleCase=true,this.relaxedNanpaLinjanParsing=false,this.relaxedNanpaLinjanRendering=false,this.nanpaColonRendering=false});
  factory SplitCapsOptions.fromJson(Map<String,dynamic>? j)=>SplitCapsOptions(
    titleCase: (j?['titleCase'] is bool) ? j!['titleCase'] as bool : true,
    relaxedNanpaLinjanParsing:j?['relaxedNanpaLinjanParsing']==true,
    relaxedNanpaLinjanRendering:j?['relaxedNanpaLinjanRendering']==true,
    nanpaColonRendering:j?['nanpaColonRendering']==true,
  );
}

String? encodeDecimal(Object? value,[ParseOptions options=const ParseOptions()])=>encodeDecimalCaps(value,options);
List<int> decimalToUcsurCodepoints(Object? value,[ParseOptions options=const ParseOptions()])=>parseNumber(value,_normalizedParseOptions(options))?.ucsurCodepoints??<int>[];
List<int> properNameToUcsurCodepoints(Object? value,[ParseOptions options=const ParseOptions()])=>parseNumber(value,_normalizedParseOptions(options))?.ucsurCodepoints??<int>[];

String _repeat(String s,int n)=>List.filled(n,s).join();
String _titleWords(String s)=>s.trim().split(RegExp(r'\s+')).where((e)=>e.isNotEmpty).map((w)=>w.length==1?w.toUpperCase():'${w[0].toUpperCase()}${w.substring(1)}').join(' ');

String _magnitudeFragment(int count){
  if(count<=0)return'';if(count<=3)return'e${_repeat('ke',count)}';
  final sizes=<int>[2];var rem=count-2;while(rem>3){sizes.add(2);rem-=2;}sizes.add(rem);
  return [for(var i=0;i<sizes.length;i++)'${i==0?'e':''}${_repeat('ke',sizes[i])}'].join(' ');
}

String _relaxedOutputCaps(String caps){
  final s=caps.trim().toUpperCase();if(s.length<3||!s.startsWith('NE')||!s.endsWith('N'))return s;
  final end=s.length-1,b=StringBuffer();var i=0;
  while(i<end){if(i+2>end)return s;final p=s.substring(i,i+2);b.write(const {'WE':'WA','TE':'TU','LE':'LU','ME':'MU','PE':'PI','JE':'JO'}[p]??p);i+=2;}b.write('N');return b.toString();
}

String? _splitCapsLetters(String caps){
  final s0=caps.trim().toUpperCase();if(s0.isEmpty)return'';if(s0.length<3||!s0.startsWith('NE')||!s0.endsWith('N'))return null;
  final hasOk=s0.length>=3&&s0.substring(s0.length-3,s0.length-1)=='OK';final main=hasOk?'${s0.substring(0,s0.length-3)}N':s0;final end=main.length-1;if(end.isOdd)return null;
  final out=StringBuffer();var i=0;
  while(i<end){final pair=main.substring(i,i+2),next=i+4<=end?main.substring(i+2,i+4):null;
    if(pair=='NE'&&next=='NO'&&i==0){out.write('neno ');i+=4;continue;}
    if(pair=='NE'&&next=='NS'&&i==0){out.write('nene ');i+=4;continue;}
    if(pair=='NE'&&next=='NE'){out.write('n ene ');i+=4;continue;}
    if(pair=='NO'&&next=='NE'&&i>0){out.write('n one ');i+=4;continue;}
    if(pair=='NO'&&next=='KO'&&i>0){out.write('n oko${i+4<end?' ':''}');i+=4;continue;}
    if(pair=='NE'&&next=='KO'&&i>0){out.write('n eko${i+4<end?' ':''}');i+=4;continue;}
    if(pair=='NO'&&next=='NO'&&i>0){out.write('n o');var count=1,j=i;while(j+6<=end&&main.substring(j+4,j+6)=='NO'){count++;j+=2;}out.write(_repeat('no',count));if(i+2*count<end)out.write(' ');i+=2+2*count;continue;}
    if(pair=='NE'&&next=='KE'){out.write('n ');var count=1,j=i;while(j+6<=end&&main.substring(j+4,j+6)=='KE'){count++;j+=2;}out.write(_magnitudeFragment(count));if(i+2*count<end)out.write(' ');i+=2+2*count;continue;}
    if(pair=='OK'){if(i>0&&!out.toString().endsWith(' '))out.write(' ');if(i>0)out.write('n ');out.write('oke');}else{out.write(pair.toLowerCase());}i+=2;
  }
  final words=out.toString().split(RegExp(r'\s+')).where((w)=>w.isNotEmpty).toList();for(var x=0;x<words.length;){if(words[x]=='n'&&x>0){words[x-1]+='n';words.removeAt(x);}else{x++;}}
  var v=words.join(' ').trim();v+='n';if(hasOk)v+=' oken';return v;
}

String _splitFinalHundred(String v,bool relaxed){
  const strict=['weninin','teninin','seninin','naninin','leninin','nuninin','meninin','peninin','jeninin'];
  const rel=['waninin','tuninin','luninin','muninin','pininin','joninin'];final out=<String>[];
  for(final w in v.split(RegExp(r'\s+'))){final l=w.toLowerCase();final split=strict.any(l.endsWith)||(relaxed&&rel.any(l.endsWith));if(split&&l.endsWith('inin')&&w.length>4){out.add(w.substring(0,w.length-4));out.add(w.substring(w.length-4));}else{out.add(w);}}return out.join(' ');
}

String _colonProperFromLegacy(String v){var body=v.trim().toLowerCase();if(body.startsWith('ne'))body=body.substring(2).trimLeft();else if(body.startsWith('n ene'))body=body.substring(5).trimLeft();final w=body.split(RegExp(r'\s+')).where((x)=>x.isNotEmpty).toList();if(w.length>1&&(w[0]=='no'||w[0]=='ne')){w[0]+=w.removeAt(1);}return w.isEmpty?'':'Nanpa ${_titleWords(w.join(' '))}';}

String _canonicalizeScientificCaps(String caps)=>caps.trim().toUpperCase().replaceAll(RegExp(r'NEKO(?:WE|WA)NINEKO'),'NEKO');

String? splitCapsToProperName(String caps,[SplitCapsOptions options=const SplitCapsOptions()]){
  // This API accepts a CAPS label directly. Do not route it back through
  // parseNumber(): callers may deliberately request a strict output surface
  // for a CAPS string that itself uses relaxed digit syllables (and vice versa).
  // Match the canonical JavaScript helper by normalizing only the historical
  // scientific marker before applying output-rendering substitutions.
  final canonical=_canonicalizeScientificCaps(caps);
  final rendered=options.relaxedNanpaLinjanRendering?_relaxedOutputCaps(canonical):canonical;
  final raw0=_splitCapsLetters(rendered);
  if(raw0==null)return null;
  final raw=_splitFinalHundred(raw0,options.relaxedNanpaLinjanParsing||options.relaxedNanpaLinjanRendering);
  if(options.nanpaColonRendering){final alt=_colonProperFromLegacy(raw);return options.titleCase?alt:alt.toLowerCase();}
  return options.titleCase?_titleWords(raw):raw;
}

String? capsToUniqueCode(String caps,[ParseOptions options=const ParseOptions()])=>parseNumber(caps,options)?.uniqueCode;
String? decodeCaps(String caps,[ParseOptions options=const ParseOptions()])=>parseNumber(caps,options)?.displayValue;

List<String> ucsurCodepointsToTpWords(Iterable<int> cps)=>codepointsToWords(cps);
List<String> codepointsToWords(Iterable<int> cps)=>[for(final cp in cps)if(allCodepointWords[cp]!=null)allCodepointWords[cp]!];
String tpWordsToText(Iterable<String> words)=>words.join(' ');

String normalizeTpWord(Object? s)=>'$s'.toLowerCase().replaceAll(RegExp(r'[^a-z]'),'');
String _resolveWordKey(String raw){if(raw==':')return ':';final s=raw.toLowerCase();const aliases={'colon':'kolon','middle-dot':'.','tally':'koma'};return aliases[s]??s;}

List<int> parseTpWordsToCodepoints(Object? input){
  final raw='${input??''}'.trim();if(raw.isEmpty)return[];final parts=raw.split(RegExp(r'(?:\s+|(?=[·:])|(?<=[·:]))')).where((s)=>s.isNotEmpty&&s.trim().isNotEmpty);final out=<int>[];
  for(final p0 in parts){var p=p0.trim();if(p=='·')p='.';final key=_resolveWordKey(p);final cp=allWordCodepoints[key]??wordCodepoints[key];if(cp==null)throw FormatException('Invalid Toki Pona word "$p".');if(!isAllowedTpUcsurCodepoint(cp))throw FormatException('Disallowed code point U+${cp.toRadixString(16).toUpperCase()}');out.add(cp);}return stripCartoucheMarkers(out);
}
List<int> tpWordsToUcsurCodepoints(Iterable<String> words){final out=<int>[];for(final w in words){final key=_resolveWordKey(w);final cp=allWordCodepoints[key]??wordCodepoints[key];if(cp==null)throw FormatException('No UCSUR code point for word "$w"');out.add(cp);}return out;}

String codepointsToHex(Iterable<int> cps)=>cps.map((cp)=>cp.toRadixString(16).toUpperCase().padLeft(4,'0')).join(' ');
String codepointsToHexWithCartouche(Iterable<int> cps)=>codepointsToHex(withCartoucheMarkers(cps));
List<int> parseHexCodepoints(Object? input){
  final raw='${input??''}'.trim();if(raw.isEmpty)return[];final out=<int>[];
  if(RegExp(r'U\+',caseSensitive:false).hasMatch(raw)){
    var pos=0;for(final m in RegExp(r'U\+([0-9A-Fa-f]{1,6})(?![0-9A-Fa-f])',caseSensitive:false).allMatches(raw)){if(raw.substring(pos,m.start).trim().isNotEmpty)throw FormatException('Invalid text between Unicode code points');final cp=int.parse(m.group(1)!,radix:16);if(cp>0x10FFFF||(cp>=0xD800&&cp<=0xDFFF))throw FormatException('Invalid Unicode scalar');out.add(cp);pos=m.end;}if(raw.substring(pos).trim().isNotEmpty)throw FormatException('Invalid text after Unicode code points');
  }else{for(final x in raw.split(RegExp(r'\s+'))){final cp=int.tryParse(x,radix:16);if(cp==null||cp>0x10FFFF||(cp>=0xD800&&cp<=0xDFFF))throw FormatException('Invalid hexadecimal code point "$x"');out.add(cp);}}
  return stripCartoucheMarkers(out);
}
List<int> withCartoucheMarkers(Iterable<int> cps)=>[cartoucheStart,...cps,cartoucheEnd];
List<int> stripCartoucheMarkers(Iterable<int> cps){final a=cps.toList();return a.length>=2&&a.first==cartoucheStart&&a.last==cartoucheEnd?a.sublist(1,a.length-1):a;}

bool isValidCaps(Object? s,[ParseOptions options=const ParseOptions()]){
  if(s==null)return false;
  final v='$s'.trim();
  return v.isNotEmpty&&RegExp(r'^[A-Za-z]+[Nn]$').hasMatch(v)&&v.substring(0,2).toUpperCase()=='NE';
}
bool isValidProperName(Object? s,[ParseOptions options=const ParseOptions()]){
  if(s==null)return false;
  final v='$s'.trim();
  return RegExp(r'^[A-Za-z]+(?:\s+[A-Za-z]+)*$').hasMatch(v)&&parseNumber(v,options)!=null;
}

int? _capsDigit(String token){
  const digits=<String,int>{
    'NI':0,'WE':1,'WA':1,'TE':2,'TU':2,'SE':3,'NA':4,
    'LE':5,'LU':5,'NU':6,'ME':7,'MU':7,'PE':8,'PI':8,'JE':9,'JO':9,
  };
  return digits[token];
}

List<String>? _tryTokenizeCaps(String caps,ParseOptions options){
  try{return tokenizeCaps(caps,options);}catch(_){return null;}
}

class _TimeSegment {
  final String integer;
  final String? fraction;
  const _TimeSegment(this.integer,this.fraction);
}

List<_TimeSegment>? _decodeTimeCaps(String caps,ParseOptions options){
  final tokens=_tryTokenizeCaps(caps,options);
  if(tokens==null||tokens.length<2||tokens.first!='NE'||tokens.last!='N')return null;
  final finalIndex=tokens.length-1;
  var i=1;
  var negative=false;
  if(i<finalIndex&&tokens[i]=='NO'){negative=true;i++;}
  final segments=<_TimeSegment>[];
  while(i<finalIndex){
    final integer=StringBuffer();
    while(i<finalIndex){final d=_capsDigit(tokens[i]);if(d==null)break;integer.write(d);i++;}
    if(integer.isEmpty)return null;
    String? fraction;
    if(i+1<finalIndex&&tokens[i]=='NO'&&tokens[i+1]=='NE'){
      i+=2;final f=StringBuffer();
      while(i<finalIndex){final d=_capsDigit(tokens[i]);if(d==null)break;f.write(d);i++;}
      if(f.length<1||f.length>3)return null;fraction=f.toString();
    }
    segments.add(_TimeSegment(integer.toString(),fraction));
    if(i==finalIndex)break;
    if(i+1>=finalIndex||tokens[i]!='NE'||tokens[i+1]!='KE')return null;
    i+=2;
  }
  if(i!=finalIndex||segments.length<2||segments.length>4)return null;
  if(segments.take(segments.length-1).any((s)=>s.fraction!=null))return null;
  bool pair(_TimeSegment s)=>s.fraction==null&&RegExp(r'^[0-5]\d$').hasMatch(s.integer);
  bool seconds(_TimeSegment s)=>RegExp(r'^[0-5]\d$').hasMatch(s.integer)&&(s.fraction==null||RegExp(r'^\d{1,3}$').hasMatch(s.fraction!));
  if(segments.length==2){
    if(negative)return null;final h=segments[0],m=segments[1];
    final hv=int.tryParse(h.integer);
    return h.fraction==null&&RegExp(r'^\d{1,2}$').hasMatch(h.integer)&&hv!=null&&hv>=0&&hv<=59&&pair(m)?segments:null;
  }
  if(segments.length==3&&segments[2].fraction!=null){
    if(negative)return null;final h=segments[0],m=segments[1],sec=segments[2];final hv=int.tryParse(h.integer);
    return h.fraction==null&&RegExp(r'^\d{1,2}$').hasMatch(h.integer)&&hv!=null&&hv>=0&&hv<=59&&pair(m)&&seconds(sec)?segments:null;
  }
  if(segments.length==3){
    return segments[0].fraction==null&&RegExp(r'^\d+$').hasMatch(segments[0].integer)&&pair(segments[1])&&pair(segments[2])?segments:null;
  }
  return segments[0].fraction==null&&RegExp(r'^\d+$').hasMatch(segments[0].integer)&&pair(segments[1])&&pair(segments[2])&&seconds(segments[3])?segments:null;
}

bool _validMonthDay(String mmText,String ddText,{bool monthSpecific=false}){
  final mm=int.tryParse(mmText),dd=int.tryParse(ddText);if(mm==null||dd==null||mm<1||mm>12)return false;
  if(!monthSpecific)return dd>=1&&dd<=31;
  const maxDays=<int>[31,29,31,30,31,30,31,31,30,31,30,31];
  return dd>=1&&dd<=maxDays[mm-1];
}

bool _isFullDateCaps(String caps,ParseOptions options){
  final t=_tryTokenizeCaps(caps,options);if(t==null||t.first!='NE'||t.last!='N')return false;var i=1;
  String? read(){if(i>=t.length-1)return null;final d=_capsDigit(t[i]);if(d==null)return null;i++;return '$d';}
  final y1=read(),y2=read(),y3=read(),y4=read();if([y1,y2,y3,y4].any((x)=>x==null))return false;
  if(i+1>=t.length||t[i]!='NE'||t[i+1]!='KE')return false;i+=2;
  final m1=read(),m2=read();if(m1==null||m2==null)return false;
  if(i+1>=t.length||t[i]!='NE'||t[i+1]!='KE')return false;i+=2;
  final d1=read(),d2=read();if(d1==null||d2==null||i!=t.length-1)return false;
  return _validMonthDay('$m1$m2','$d1$d2');
}

bool isValidTime(Object? caps,[ParseOptions options=const ParseOptions()])=>caps!=null&&_decodeTimeCaps('$caps',options)!=null;
bool isValidDate(Object? caps,[ParseOptions options=const ParseOptions()])=>caps!=null&&_isFullDateCaps('$caps',options);
bool isValidTimeOrDate(Object? caps,[ParseOptions options=const ParseOptions()])=>isValidDate(caps,options)||isValidTime(caps,options);

List<String> tokenizeCaps(String caps,[ParseOptions options=const ParseOptions()]){
  final s=caps.trim().toUpperCase();
  if(s.isEmpty||!s.startsWith('NE')||!s.endsWith('N'))throw FormatException('Invalid nanpa caps');
  final out=<String>[];var i=0;final end=s.length-1;
  const prefixes=<String>['KEKEKE','KEKE','KO','KE','NONONO','NONO','NOKO','OK','NE','NS','NO'];
  final accepted=<String>{...strictDigits,if(options.relaxedNanpaLinjanParsing)...relaxedDigits};
  while(i<end){
    String? token;
    for(final candidate in prefixes){if(s.startsWith(candidate,i)){token=candidate;break;}}
    if(token!=null){out.add(token);i+=token.length;continue;}
    if(i+2<=end){final pair=s.substring(i,i+2);if(accepted.contains(pair)){out.add(pair);i+=2;continue;}}
    throw FormatException('Invalid nanpa caps token at $i');
  }
  out.add('N');return out;
}
List<String> capsTokensToTpWords(Iterable<String> tokens,[ParseOptions options=const ParseOptions()]){final caps=tokens.join();return capsToWords(caps,options);}

List<String> _replaceCapsSemanticSeparators(List<String> words,NumericMode mode){
  final out=<String>[];var i=0;
  while(i<words.length){
    final uniform=i+3<words.length&&words[i]=='nena'&&words[i+1]=='e'&&words[i+2]=='kulupu'&&words[i+3]=='e';
    final traditional=i+3<words.length&&words[i]=='nasa'&&words[i+1]=='esun'&&words[i+2]=='kulupu'&&words[i+3]=='esun';
    if(uniform||traditional){
      out.addAll(mode==NumericMode.traditional?const <String>['nasa','esun','kasi','esun']:const <String>['nena','e','kasi','e']);
      i+=4;continue;
    }
    out.add(words[i++]);
  }
  return out;
}

List<String> capsToWords(String caps,[ParseOptions options=const ParseOptions()]){
  final normalized=_normalizedParseOptions(options);
  final r=parseNumber(caps,normalized);if(r==null)return <String>[];
  var words=List<String>.of(r.tpWords);
  final date=isValidDate(caps,normalized);
  final time=!date&&isValidTime(caps,normalized);
  if(date||time){
    words=_replaceCapsSemanticSeparators(words,normalized.numericMode);
    if(words.isNotEmpty&&normalized.nanpaColonRendering){
      words[0]=normalized.numericCartoucheStartGlyph?.name??(date?'suno':'tenpo');
    }
  }
  return words;
}

CapsCodepointsResult? capsToCodepoints(String caps,[ParseOptions options=const ParseOptions()]){
  final normalized=_normalizedParseOptions(options);
  final words=capsToWords(caps,normalized);if(words.isEmpty)return null;
  final inner=tpWordsToUcsurCodepoints(words);
  final date=isValidDate(caps,normalized);final time=!date&&isValidTime(caps,normalized);
  return CapsCodepointsResult(innerCodepoints:inner,codepoints:withCartoucheMarkers(inner),words:words,numericMode:normalized.numericModeName,isTimeLike:date||time);
}
IdentifierResult? parseIdentifier(Object? input,[ParseOptions options=const ParseOptions()]){if(input==null)return null;final normalized=_normalizedParseOptions(options);final r=parseNumber(input,normalized);if(r==null||r.innerCodepoints.isEmpty)return null;return IdentifierResult(input:'$input',innerCodepoints:r.innerCodepoints,codepoints:withCartoucheMarkers(r.innerCodepoints),words:codepointsToWords(r.innerCodepoints),numericMode:normalized.numericModeName);}

Set<int> getSmallCodepointsSet()=>Set.unmodifiable(smallCodepoints);
Set<int> getQuarterCodepointsSet()=>Set.unmodifiable(quarterCodepoints);
Set<int> getOneThirdCodepointsSet()=>Set.unmodifiable(oneThirdCodepoints);
Set<int> getTwoThirdsCodepointsSet()=>Set.unmodifiable(twoThirdsCodepoints);
Set<int> getHalfCodepointsSet()=>Set.unmodifiable(halfCodepoints);
bool isAllowedTpUcsurCodepoint(Object? cp)=>cp is int&&((cp>=0xF1900&&cp<=0xF19A3)||cp==cartoucheStart||cp==cartoucheEnd);

/// Object-oriented facade mirroring the canonical NanpaParser namespace.
class NanpaParser {
  const NanpaParser();
  ParseResult? parseNumberValue(Object? input,[ParseOptions options=const ParseOptions()])=>parseNumber(input,options);
  String? encodeDecimalValue(Object? value,[ParseOptions options=const ParseOptions()])=>encodeDecimal(value,options);
  List<int> decimalToUcsurCodepointsValue(Object? value,[ParseOptions options=const ParseOptions()])=>decimalToUcsurCodepoints(value,options);
  List<int> properNameToUcsurCodepointsValue(Object? value,[ParseOptions options=const ParseOptions()])=>properNameToUcsurCodepoints(value,options);
}
