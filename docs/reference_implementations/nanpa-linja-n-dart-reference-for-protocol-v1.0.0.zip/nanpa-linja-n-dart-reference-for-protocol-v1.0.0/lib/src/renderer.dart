import 'api.dart';
import 'constants.dart';
import 'model.dart';
import 'options.dart';
import 'parser.dart';

/// Language-neutral logical renderer for nanpa-linja-n numeric output.
///
/// This is intentionally independent of Flutter/Canvas/font rasterization.
/// It produces the canonical semantic word/codepoint stream described by
/// Protocol v1.0.0. A UI may then shape these UCSUR code points with any
/// compatible sitelen pona / nanpa-linja-n font.
class RenderResult {
  final ParseResult parsed;
  final List<String> fullWords;
  final List<int> fullInnerCodepoints;
  final List<int> fullCodepoints;
  final List<String>? abbreviatedWords;
  final List<int>? abbreviatedInnerCodepoints;
  final List<int>? abbreviatedCodepoints;
  final bool abbreviated;
  final List<String> activeWords;
  final List<int> activeInnerCodepoints;
  final List<int> activeCodepoints;
  final String unicodeText;

  const RenderResult({
    required this.parsed,
    required this.fullWords,
    required this.fullInnerCodepoints,
    required this.fullCodepoints,
    required this.abbreviatedWords,
    required this.abbreviatedInnerCodepoints,
    required this.abbreviatedCodepoints,
    required this.abbreviated,
    required this.activeWords,
    required this.activeInnerCodepoints,
    required this.activeCodepoints,
    required this.unicodeText,
  });

  Map<String, dynamic> toJson() => <String, dynamic>{
        'accepted': true,
        'parsed': parsed.toJson(),
        'fullWords': fullWords,
        'fullInnerCodepoints': fullInnerCodepoints,
        'fullCodepoints': fullCodepoints,
        'abbreviatedWords': abbreviatedWords,
        'abbreviatedInnerCodepoints': abbreviatedInnerCodepoints,
        'abbreviatedCodepoints': abbreviatedCodepoints,
        'abbreviated': abbreviated,
        'activeWords': activeWords,
        'activeInnerCodepoints': activeInnerCodepoints,
        'activeCodepoints': activeCodepoints,
        'unicodeText': unicodeText,
      };
}

List<int> _wordsToCodepoints(List<String> words) {
  final out = <int>[];
  for (final word in words) {
    final cp = allWordCodepoints[word] ?? wordCodepoints[word];
    if (cp == null) {
      throw StateError('No canonical code point for renderer word "$word".');
    }
    out.add(cp);
  }
  return out;
}

/// Converts a full decimal/date/time word stream to the protocol's compact
/// cartouche surface. Hex and binary already provide their canonical compact
/// streams directly in [ParseResult.abbreviatedWords].
List<String> _abbreviateDecimalWords(
  List<String> words, {
  bool preserveBreaks = false,
}) {
  if (words.isEmpty) return const <String>[];
  final out = <String>[];
  var i = 0;

  // Keep decimal semantic opener and optional colon.
  out.add(words[i++]);
  if (i < words.length && words[i] == ':') out.add(words[i++]);

  bool has(List<String> needle) {
    if (i + needle.length > words.length) return false;
    for (var j = 0; j < needle.length; j++) {
      if (words[i + j] != needle[j]) return false;
    }
    return true;
  }

  void consume(int n) => i += n;

  final digitPatterns = <List<String>, String>{
    <String>['nena', 'ijo']: 'ijo',
    <String>['nasa', 'ijo']: 'ijo',
    <String>['wan', 'e']: 'wan',
    <String>['wan', 'esun']: 'wan',
    <String>['wan', 'ala']: 'wan',
    <String>['tu', 'e']: 'tu',
    <String>['tu', 'esun']: 'tu',
    <String>['tu', 'uta']: 'tu',
    <String>['seli', 'e']: 'seli',
    <String>['seli', 'esun']: 'seli',
    <String>['nena', 'awen']: 'awen',
    <String>['nasa', 'awen']: 'awen',
    <String>['luka', 'e']: 'luka',
    <String>['luka', 'esun']: 'luka',
    <String>['luka', 'uta']: 'luka',
    <String>['nena', 'utala']: 'utala',
    <String>['nasa', 'utala']: 'utala',
    <String>['mun', 'e']: 'mun',
    <String>['mun', 'esun']: 'mun',
    <String>['mun', 'uta']: 'mun',
    <String>['pipi', 'e']: 'pipi',
    <String>['pipi', 'esun']: 'pipi',
    <String>['pipi', 'ike']: 'pipi',
    <String>['jo', 'e']: 'jo',
    <String>['jo', 'esun']: 'jo',
    <String>['jo', 'open']: 'jo',
  };

  while (i < words.length) {
    // Closing nanpa/nasa/noka is preserved verbatim.
    if (i == words.length - 1) {
      out.add(words[i]);
      break;
    }

    if (has(const <String>['nena', 'e', 'nena', 'e'])) {
      if (preserveBreaks) out.add('e');
      consume(4);
      continue;
    }
    if (has(const <String>['nasa', 'esun', 'nasa', 'esun'])) {
      if (preserveBreaks) out.add('e');
      consume(4);
      continue;
    }
    if (has(const <String>['nena', 'e', 'kasi', 'e']) ||
        has(const <String>['nasa', 'esun', 'kasi', 'esun'])) {
      out.add('kasi');
      consume(4);
      continue;
    }
    if (has(const <String>['nena', 'e', 'kulupu', 'e']) ||
        has(const <String>['nasa', 'esun', 'kulupu', 'esun'])) {
      out.add('kulupu');
      consume(4);
      continue;
    }
    if (has(const <String>['nena', 'o', 'nena', 'e']) ||
        has(const <String>['nasa', 'o', 'nasa', 'esun'])) {
      out.add('o');
      consume(4);
      continue;
    }
    if (has(const <String>['nena', 'en'])) {
      out.add('en');
      consume(2);
      continue;
    }
    if (has(const <String>['nena', 'ona'])) {
      out.add('ona');
      consume(2);
      continue;
    }

    var matchedDigit = false;
    for (final entry in digitPatterns.entries) {
      if (has(entry.key)) {
        out.add(entry.value);
        consume(entry.key.length);
        matchedDigit = true;
        break;
      }
    }
    if (matchedDigit) continue;

    // Marker words (scientific/fraction/percent/magnitude) are meaningful
    // glyphs in their own right and are kept if no larger compact rule applies.
    out.add(words[i]);
    i++;
  }
  return out;
}

RenderResult? renderNumber(
  Object? input, [
  ParseOptions options = const ParseOptions(),
]) {
  final parsed = parseNumber(input, options);
  if (parsed == null) return null;

  final fullWords = List<String>.unmodifiable(parsed.tpWords);
  final fullInner = List<int>.unmodifiable(parsed.innerCodepoints);
  final fullCodepoints = List<int>.unmodifiable(parsed.codepoints);

  List<String>? abbreviatedWords;
  List<int>? abbreviatedInner;
  List<int>? abbreviatedCodepoints;

  if (parsed.abbreviatedWords != null) {
    abbreviatedWords = List<String>.unmodifiable(parsed.abbreviatedWords!);
    abbreviatedInner = List<int>.unmodifiable(
      parsed.abbreviatedUcsurCodepoints ?? _wordsToCodepoints(abbreviatedWords),
    );
    abbreviatedCodepoints = List<int>.unmodifiable(
      withCartoucheMarkers(abbreviatedInner),
    );
  } else if (parsed.caps != null && options.nanpaColonRendering) {
    abbreviatedWords = List<String>.unmodifiable(
      _abbreviateDecimalWords(
        fullWords,
        preserveBreaks: options.preserveNumericCartoucheBreaksInAbbreviation,
      ),
    );
    abbreviatedInner = List<int>.unmodifiable(_wordsToCodepoints(abbreviatedWords));
    abbreviatedCodepoints = List<int>.unmodifiable(
      withCartoucheMarkers(abbreviatedInner),
    );
  }

  final useAbbreviated = options.abbreviateNumericCartouches &&
      abbreviatedWords != null &&
      abbreviatedInner != null &&
      abbreviatedCodepoints != null;
  final activeWords = useAbbreviated ? abbreviatedWords : fullWords;
  final activeInner = useAbbreviated ? abbreviatedInner : fullInner;
  final activeCodepoints = useAbbreviated ? abbreviatedCodepoints : fullCodepoints;
  final unicodeText = String.fromCharCodes(activeCodepoints);

  return RenderResult(
    parsed: parsed,
    fullWords: fullWords,
    fullInnerCodepoints: fullInner,
    fullCodepoints: fullCodepoints,
    abbreviatedWords: abbreviatedWords,
    abbreviatedInnerCodepoints: abbreviatedInner,
    abbreviatedCodepoints: abbreviatedCodepoints,
    abbreviated: useAbbreviated,
    activeWords: List<String>.unmodifiable(activeWords),
    activeInnerCodepoints: List<int>.unmodifiable(activeInner),
    activeCodepoints: List<int>.unmodifiable(activeCodepoints),
    unicodeText: unicodeText,
  );
}

class NanpaRenderer {
  const NanpaRenderer();

  RenderResult? render(
    Object? input, [
    ParseOptions options = const ParseOptions(),
  ]) =>
      renderNumber(input, options);
}
