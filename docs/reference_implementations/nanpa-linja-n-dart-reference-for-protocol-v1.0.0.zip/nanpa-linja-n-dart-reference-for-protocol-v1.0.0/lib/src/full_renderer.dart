import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'constants.dart';
import 'api.dart' show tokenizeCaps;
import 'full_adapter.dart';
import 'full_document.dart';
import 'full_types.dart';
import 'model.dart';
import 'native_full_renderer.dart';
import 'native_production_renderer.dart'
    show ProductionOutputFormat, ProductionRgba;
import 'options.dart' show SemanticKind;
import 'parser.dart';
import 'production_font_adapters.dart';
import 'production_font_registry.dart';
import 'renderer.dart';

const Map<String, String> _nativeBaseFamilies = <String, String>{
  'nasinNanpa': 'nasin-nanpa-nanpa-linja-n',
  'sitelenSeliKiwen': 'sitelen seli kiwen juniko-latin-ligatures',
  'fairfaxHd': 'Fairfax HD',
  'fairfaxPonaHd': 'Fairfax Pona HD',
  'linjaPona': 'linja pona 4.9',
  'linjaSike': 'linja sike 5-cartouche-fix',
  'nasinSitelenPuMono': 'nasin-sitelen-pu',
  'linjaLipamanka': 'linja lipamanka-cartouche-fix',
};

final RegExp _integer = RegExp(r'^\+?[0-9]+$');
final RegExp _numericLike = RegExp(r'[0-9]');
const Map<String, String> _glyphInputAliases = <String, String>{
  'ni01': 'ni',
  'ni02': 'ni>',
  'ni03': 'ni^',
  'ni04': 'ni<',
  'sewi01': 'sewi',
  'sewi02': 'sewi^',
  'ale': 'ali',
};
final RegExp _rawUnicodeScan = RegExp(
  r'U\+[0-9A-Fa-f]{4,6}(?:[ \t]+U\+[0-9A-Fa-f]{4,6})*',
  caseSensitive: false,
);
final RegExp _sskSpecial = RegExp(
  r'(?:\{([^{}]+)\}\s*)?([A-Za-z][A-Za-z0-9_^<>]*)\(([^()]+)\)|([A-Za-z][A-Za-z0-9_^<>]*(?:[&+-][A-Za-z][A-Za-z0-9_^<>]*)+)|\{([^{}]+)\}\s*([A-Za-z][A-Za-z0-9_^<>]*)',
);
final RegExp _coreSpecial = RegExp(
  r'pi\(([^()]+)\)|([A-Za-z][A-Za-z0-9_^<>]*(?:[&+-][A-Za-z][A-Za-z0-9_^<>]*)+)|(\|)|(pi\s+\{[^{}]*\})',
  caseSensitive: false,
);
final RegExp _legacyLongPi = RegExp(
  r'pi\+__[A-Za-z][A-Za-z0-9^<>]*(?:__[A-Za-z][A-Za-z0-9^<>]*){0,2}|pi(?:\+\+\+|---)[ \t]*[A-Za-z][A-Za-z0-9_^<>]*[ \t]+[A-Za-z][A-Za-z0-9_^<>]*[ \t]+[A-Za-z][A-Za-z0-9_^<>]*|pi(?:\+\+|--)[ \t]*[A-Za-z][A-Za-z0-9_^<>]*[ \t]+[A-Za-z][A-Za-z0-9_^<>]*|pi\+[A-Za-z][A-Za-z0-9_^<>]*',
  caseSensitive: false,
);

ProductionRgba _parseHexColor(String value, ProductionRgba fallback) {
  var s = value.trim();
  if (!s.startsWith('#')) return fallback;
  s = s.substring(1);
  if (s.length == 3) {
    s = '${s[0]}${s[0]}${s[1]}${s[1]}${s[2]}${s[2]}';
  }
  if (s.length != 6) return fallback;
  final v = int.tryParse(s, radix: 16);
  if (v == null) return fallback;
  return ProductionRgba((v >> 16) & 0xff, (v >> 8) & 0xff, v & 0xff, 255);
}

FullRenderOptions _normalizedOptions(FullRenderOptions options) {
  final size = math.max(8.0, options.fontSize);
  return options.copyWith(
    font: options.font.trim().isEmpty ? defaultProductionFontKey : options.font,
    fontSize: size,
    paddingPx: options.paddingPx < 0 ? 0 : options.paddingPx,
  );
}

class _Graphic {
  final String text;
  final String family;
  final String fontPath;
  final List<String> features;
  final double width;
  final double height;
  final double baseline;
  final double originX;
  final double originY;
  final List<TallyGroup> tallyGroups;
  final Uint8List? imageBytes;
  final String imageHref;
  final bool unknownDecoration;
  final int? syntheticCornerCodepoint;

  const _Graphic({
    this.text = '',
    this.family = '',
    this.fontPath = '',
    this.features = const <String>[],
    required this.width,
    required this.height,
    required this.baseline,
    this.originX = 0,
    this.originY = 0,
    this.tallyGroups = const <TallyGroup>[],
    this.imageBytes,
    this.imageHref = '',
    this.unknownDecoration = false,
    this.syntheticCornerCodepoint,
  });
}

class _Logical {
  final FullRenderRun run;
  final _Graphic graphic;
  const _Logical(this.run, this.graphic);
}

class _Prepared {
  final FullRenderPlan plan;
  final List<_Logical> placed;
  const _Prepared(this.plan, this.placed);
}

class DartFullRenderer {
  final ProductionFontRegistry registry;
  final Map<String, FullRenderAdapter> runtimeAdapters;

  DartFullRenderer(
    this.registry, [
    Map<String, FullRenderAdapter>? runtimeAdapters,
  ]) : runtimeAdapters = runtimeAdapters ?? <String, FullRenderAdapter>{};

  void registerRenderAdapter(String id, FullRenderAdapter adapter) {
    runtimeAdapters[id] = adapter;
  }

  FullRenderAdapter? getRenderAdapter(String id) => runtimeAdapters[id];

  FullRenderAdapter? removeRenderAdapter(String id) => runtimeAdapters.remove(id);

  ProductionFontInfo _font(String key) => registry.get(key);

  List<NumericStructure> _numericStructuresForText(
    String text,
    FullRenderOptions options,
  ) {
    if (text.isEmpty || text.trim().isEmpty) return const <NumericStructure>[];

    // Numeric annotation must remain parser-only.  In particular, parseInput()
    // must not acquire a native font/Pango dependency merely because the AST
    // now records numeric spans.  This scanner mirrors the numeric branches of
    // _parseTextBase without measuring or adapting glyphs.
    final parser = options.parser.copyWith(nasinNanpaPona: false);
    final structures = <NumericStructure>[];
    final seen = <String>{};

    void add(int start, int end, RenderResult rendered) {
      if (start < 0 || end <= start || end > text.length) return;
      final source = text.substring(start, end);
      final key = '$start:$end:$source';
      if (!seen.add(key)) return;
      final parsed = rendered.parsed;
      structures.add(NumericStructure(
        kind: parsed.kind?.name ?? parsed.semanticKind?.name ?? 'number',
        index: start,
        end: end,
        sourceText: source,
        semanticKind: parsed.semanticKind?.name,
        semanticStartGlyph: parsed.semanticStartGlyph?.name,
      ));
    }

    void scan(String slice, int base) {
      if (slice.isEmpty || slice.trim().isEmpty) return;

      final phrase = _phraseRender(slice, parser);
      if (phrase != null) {
        add(base, base + slice.length, phrase);
        return;
      }

      final proper = _properNumericPrefix(slice, parser);
      if (proper != null) {
        add(base + proper.start, base + proper.end, proper.render);
        if (proper.end < slice.length) {
          scan(slice.substring(proper.end), base + proper.end);
        }
        return;
      }

      if (!parser.enableBinaryParsing && !parser.enableBinaryRendering) {
        final bm = RegExp(r'^0b([01]+)$', caseSensitive: false)
            .firstMatch(slice.trim());
        if (bm != null) {
          final offset = slice.indexOf(slice.trim());
          final digits = bm.group(1)!;
          final prefix = _numericParsed('0b', parser);
          final firstDigit = _numericParsed(digits.substring(0, 1), parser);
          if (prefix != null) {
            add(base + offset, base + offset + 2, prefix);
          }
          if (firstDigit != null) {
            add(base + offset + 2, base + offset + 3, firstDigit);
          }
          if (digits.length > 1) {
            final remainder = _numericParsed(digits.substring(1), parser);
            if (remainder != null) {
              add(
                base + offset + 3,
                base + offset + 2 + digits.length,
                remainder,
              );
            }
          }
          return;
        }
      }

      for (final match in RegExp(
        r'[^\s\u2010\u2011\u2012\u2013\u2014\u2212\uFE63\uFF0D]+',
      ).allMatches(slice)) {
        final token = match.group(0)!;
        final tokenStart = base + match.start;
        final tokenEnd = base + match.end;
        final numericCandidate = RegExp(
          r'[0-9¼½¾⅐⅑⅒⅓⅔⅕⅖⅗⅘⅙⅚⅛⅜⅝⅞]',
        ).hasMatch(token);
        if (numericCandidate) {
          final exact = _numericParsed(token, parser);
          if (exact != null) {
            add(tokenStart, tokenEnd, exact);
            continue;
          }
        }

        var a = 0;
        var b = token.length;
        final numericLike = RegExp(r'[0-9]').hasMatch(token);
        bool allowed(String ch) {
          final cc = ch.codeUnitAt(0);
          if ((cc >= 0x30 && cc <= 0x39) ||
              (cc >= 0x41 && cc <= 0x5A) ||
              (cc >= 0x61 && cc <= 0x7A)) {
            return true;
          }
          if ('#~^<>'.contains(ch)) return true;
          return numericLike && '.,_-'.contains(ch);
        }

        while (a < b && !allowed(token[a])) {
          a++;
        }
        while (b > a && !allowed(token[b - 1])) {
          b--;
        }
        while (b > a && ')]},.;:!?'.contains(token[b - 1])) {
          b--;
        }
        final core = token.substring(a, b);
        if (core.isEmpty || const <String>{'&', '+', '-'}.contains(core)) {
          continue;
        }

        final coreStart = tokenStart + a;
        final suffix = RegExp(r'^([A-Za-z^<>]+)([0-9]+)$').firstMatch(core);
        if (suffix != null &&
            !_glyphInputAliases.containsKey(core.toLowerCase()) &&
            _fullGlyphCp(suffix.group(1)!) != null) {
          final digits = suffix.group(2)!;
          final numeric = _numericParsed(digits, parser);
          if (numeric != null) {
            add(
              coreStart + suffix.group(1)!.length,
              tokenStart + b,
              numeric,
            );
            continue;
          }
        }

        final numeric = _numericParsed(core, parser);
        if (numeric != null) {
          add(coreStart, tokenStart + b, numeric);
        }
      }
    }

    scan(text, 0);
    structures.sort((a, b) {
      final byStart = a.index.compareTo(b.index);
      return byStart != 0 ? byStart : a.end.compareTo(b.end);
    });
    return List<NumericStructure>.unmodifiable(structures);
  }

  DocumentSegment _annotateNumericSegment(
    DocumentSegment segment,
    FullRenderOptions options,
  ) {
    var structures = const <NumericStructure>[];
    if (segment.kind == 'text') {
      structures = _numericStructuresForText(segment.value, options);
    } else if (segment.kind == 'bracket') {
      final source = '[${segment.value}]';
      final scanParser = options.parser.copyWith(nasinNanpaPona: false);
      final parsed = _numericParsed(source, scanParser)?.parsed;
      if (parsed != null) {
        structures = <NumericStructure>[
          NumericStructure(
            kind: parsed.kind?.name ?? parsed.semanticKind?.name ?? 'number',
            index: 0,
            end: source.length,
            sourceText: source,
            semanticKind: parsed.semanticKind?.name,
            semanticStartGlyph: parsed.semanticStartGlyph?.name,
            wholeSegment: true,
          ),
        ];
      }
    }
    if (structures.isEmpty) return segment;
    return DocumentSegment(
      kind: segment.kind,
      value: segment.value,
      image: segment.image,
      codepoints: segment.codepoints,
      openQuote: segment.openQuote,
      closeQuote: segment.closeQuote,
      sourceStart: segment.sourceStart,
      sourceEnd: segment.sourceEnd,
      numericStructures: structures,
    );
  }

  DocumentAst parseInput(String input, [FullRenderOptions? options]) {
    final opts = _normalizedOptions(options ?? const FullRenderOptions());
    final ast = parseFullDocument(input, opts.parser);
    final lines = <DocumentLine>[];
    for (final line in ast.lines) {
      lines.add(DocumentLine(
        index: line.index,
        sourceLineIndex: line.sourceLineIndex,
        sentenceIndexInSourceLine: line.sentenceIndexInSourceLine,
        sourceText: line.sourceText,
        children: List<DocumentSegment>.unmodifiable(
          line.children.map((segment) => _annotateNumericSegment(segment, opts)),
        ),
      ));
    }
    return DocumentAst(
      normalizedInput: ast.normalizedInput,
      breakLinesAtFullStops: ast.breakLinesAtFullStops,
      parserOptions: opts.parser,
      lines: List<DocumentLine>.unmodifiable(lines),
    );
  }

  _Graphic _measureGraphic({
    required String text,
    required String family,
    required String fontPath,
    required double fontSize,
    List<String> features = const <String>[],
    int pad = 0,
    double bottomExtra = 0,
    bool unknownDecoration = false,
  }) {
    final m = measureFullTextNative(
      text: text.isEmpty ? ' ' : text,
      family: family,
      fontPath: fontPath,
      fontSize: fontSize,
      features: features,
    );
    return _Graphic(
      text: text,
      family: family,
      fontPath: fontPath,
      features: List<String>.unmodifiable(features),
      width: math.max(1, m.inkWidth + 2 * pad).toDouble(),
      height: math.max(1, m.inkHeight + 2 * pad + bottomExtra).toDouble(),
      baseline: m.baseline - m.inkY + pad,
      originX: pad - m.inkX.toDouble(),
      originY: pad - m.inkY.toDouble(),
      unknownDecoration: unknownDecoration,
    );
  }

  List<int> _runes(String text) => text.runes.toList(growable: false);

  RenderResult? _numericParsed(String source, FullParserOptions options) {
    try {
      return renderNumber(source, options.numericOptions());
    } catch (_) {
      return null;
    }
  }

  int? _capsDigit(String token) {
    var i = strictDigits.indexOf(token);
    if (i >= 0) return i;
    i = relaxedDigits.indexOf(token);
    return i >= 0 ? i : null;
  }

  String _numericStartWord(RenderResult rendered, FullParserOptions options) {
    final explicit = (options.numericCartoucheStartGlyph ?? '').toLowerCase();
    if (const <String>{'nanpa', 'nasa', 'noka', 'tenpo', 'suno', 'toki'}
        .contains(explicit)) {
      return explicit;
    }
    final semanticStart = rendered.parsed.semanticStartGlyph?.name;
    if (semanticStart != null && semanticStart.isNotEmpty) return semanticStart;
    if (options.nanpaColonRendering) {
      if (rendered.parsed.isDate ||
          rendered.parsed.semanticKind == SemanticKind.date) {
        return 'suno';
      }
      if (rendered.parsed.isTime ||
          rendered.parsed.semanticKind == SemanticKind.time) {
        return 'tenpo';
      }
    }
    return 'nanpa';
  }

  List<String> _replaceTraditionalTimeSeparators(List<String> words) {
    final out = <String>[];
    var i = 0;
    while (i < words.length) {
      if (i + 3 < words.length &&
          words[i] == 'nasa' &&
          words[i + 1] == 'e' &&
          words[i + 2] == 'kulupu' &&
          words[i + 3] == 'e') {
        out.addAll(const <String>['nasa', 'e', 'kasi', 'e']);
        i += 4;
      } else {
        out.add(words[i++]);
      }
    }
    return out;
  }

  /// Rebuilds the full decimal/date/time cartouche using the canonical
  /// JavaScript traditional-mode token rules.  The frozen Core-v1 parser is
  /// intentionally not changed: its historical public output is regression
  /// pinned.  Full Renderer Profile parity therefore belongs in this bridge.
  List<int>? _traditionalFullCodepoints(
    RenderResult rendered,
    FullParserOptions options,
  ) {
    if (rendered.abbreviated ||
        rendered.parsed.isHex ||
        rendered.parsed.isBinary) {
      return null;
    }
    final caps = rendered.parsed.caps;
    if (caps == null || caps.isEmpty) return null;

    List<String> tokens;
    try {
      tokens = tokenizeCaps(caps, options.numericOptions());
    } catch (_) {
      return null;
    }
    if (tokens.isEmpty) return null;

    var hasPercent = false;
    final filtered = <String>[];
    for (final token in tokens) {
      if (token == 'OK') {
        hasPercent = true;
      } else {
        filtered.add(token);
      }
    }

    final words = <String>[];
    var afterStartingNe = false;
    var afterScientificMarker = false;
    var i = 0;
    final startWord = _numericStartWord(rendered, options);

    while (i < filtered.length) {
      final token = filtered[i];

      if (token == 'NE') {
        final next = i + 1 < filtered.length ? filtered[i + 1] : null;
        if (next == 'KO') {
          if (words.isEmpty) {
            words.addAll(<String>[
              startWord,
              options.nanpaColonRendering ? ':' : 'esun',
              'kala',
              'open',
            ]);
          } else {
            words.addAll(const <String>['nasa', 'e', 'kala', 'open']);
          }
          afterStartingNe = false;
          afterScientificMarker = true;
          i += 2;
          continue;
        }
        afterScientificMarker = false;
        if (words.isEmpty) {
          words.addAll(<String>[
            startWord,
            options.nanpaColonRendering ? ':' : 'esun',
          ]);
          afterStartingNe = true;
        } else {
          words.addAll(const <String>['nasa', 'e']);
          afterStartingNe = false;
        }
        i++;
        continue;
      }

      if (token == 'NS') {
        words.addAll(const <String>['nena', 'en']);
        afterStartingNe = false;
        afterScientificMarker = false;
        i++;
        continue;
      }

      final digit = _capsDigit(token);
      if (digit != null) {
        afterStartingNe = false;
        afterScientificMarker = false;
        if (options.relaxedNanpaLinjanRendering) {
          switch (digit) {
            case 1:
              words.addAll(const <String>['wan', 'ala']);
              i++;
              continue;
            case 2:
              words.addAll(const <String>['tu', 'uta']);
              i++;
              continue;
            case 5:
              words.addAll(const <String>['luka', 'uta']);
              i++;
              continue;
            case 7:
              words.addAll(const <String>['mun', 'uta']);
              i++;
              continue;
            case 8:
              words.addAll(const <String>['pipi', 'ike']);
              i++;
              continue;
            case 9:
              words.addAll(const <String>['jo', 'open']);
              i++;
              continue;
          }
        }
        switch (digit) {
          case 0:
            words.addAll(const <String>['nasa', 'ijo']);
            break;
          case 1:
            words.addAll(const <String>['wan', 'esun']);
            break;
          case 2:
            words.addAll(const <String>['tu', 'esun']);
            break;
          case 3:
            words.addAll(const <String>['seli', 'esun']);
            break;
          case 4:
            words.addAll(const <String>['nasa', 'awen']);
            break;
          case 5:
            words.addAll(const <String>['luka', 'esun']);
            break;
          case 6:
            words.addAll(const <String>['nasa', 'utala']);
            break;
          case 7:
            words.addAll(const <String>['mun', 'esun']);
            break;
          case 8:
            words.addAll(const <String>['pipi', 'esun']);
            break;
          case 9:
            words.addAll(const <String>['jo', 'esun']);
            break;
        }
        i++;
        continue;
      }

      if (token == 'NO') {
        if (afterStartingNe || afterScientificMarker) {
          words.addAll(const <String>['nasa', 'ona']);
          afterStartingNe = false;
          afterScientificMarker = false;
          i++;
          continue;
        }
        final next = i + 1 < filtered.length ? filtered[i + 1] : null;
        if (next == 'NE') {
          words.addAll(const <String>['ni', 'o', 'nasa', 'e']);
          afterStartingNe = false;
          i += 2;
          continue;
        }
        words.addAll(const <String>['ni', 'o']);
        afterStartingNe = false;
        i++;
        continue;
      }

      if (token == 'NONO') {
        words.addAll(const <String>['nena', 'o', 'nena', 'o']);
        afterStartingNe = false;
        i++;
        continue;
      }
      if (token == 'NOKO') {
        words.addAll(const <String>['nena', 'open', 'kin', 'open']);
        afterStartingNe = false;
        i++;
        continue;
      }
      if (token == 'NONONO') {
        words.addAll(const <String>['nasa', 'o', 'nasa', 'o', 'nasa', 'o']);
        afterStartingNe = false;
        i++;
        continue;
      }
      if (token == 'KE' || token == 'KEKE' || token == 'KEKEKE') {
        final count = token.length ~/ 2;
        for (var n = 0; n < count; n++) {
          words.addAll(const <String>['kulupu', 'e']);
        }
        afterStartingNe = false;
        i++;
        continue;
      }
      if (token == 'N') {
        words.add('nanpa');
        afterStartingNe = false;
        i++;
        continue;
      }

      return null;
    }

    var finalWords = words;
    if (rendered.parsed.isTime || rendered.parsed.isDate) {
      finalWords = _replaceTraditionalTimeSeparators(finalWords);
    }
    if (hasPercent) {
      final suffix = const <String>['noka', 'open', 'kipisi', 'e'];
      final at = finalWords.lastIndexOf('nanpa');
      final mutable = List<String>.from(finalWords);
      if (at >= 0) {
        mutable.insertAll(at, suffix);
      } else {
        mutable.addAll(suffix);
      }
      finalWords = mutable;
    }

    final inner = <int>[];
    for (final word in finalWords) {
      final cp = allWordCodepoints[word] ?? wordCodepoints[word];
      if (cp == null) return null;
      inner.add(cp);
    }
    return <int>[cartoucheStart, ...inner, cartoucheEnd];
  }

  void _patchExplicitPositive(List<int> full, String source) {
    if (!source.trimLeft().startsWith('+')) return;
    final nena = allWordCodepoints['nena'];
    final e = allWordCodepoints['e'];
    final en = allWordCodepoints['en'];
    final colon = allWordCodepoints['kolon'] ?? allWordCodepoints[':'];
    if (nena == null || e == null || en == null) return;

    // Match the canonical JavaScript full-renderer rule by position.  An
    // explicit leading plus is the semantic marker `nena en` immediately
    // after the numeric opener + separator.  Do not search/replace arbitrary
    // `nena e` pairs later in the number: those may be legitimate digits or
    // separators and changing them would regress numeric semantics.
    final offset = full.isNotEmpty && full.first == cartoucheStart ? 1 : 0;
    final starts = <int>{
      if (allWordCodepoints['nanpa'] != null) allWordCodepoints['nanpa']!,
      if (allWordCodepoints['nasa'] != null) allWordCodepoints['nasa']!,
      if (allWordCodepoints['noka'] != null) allWordCodepoints['noka']!,
      if (allWordCodepoints['tenpo'] != null) allWordCodepoints['tenpo']!,
      if (allWordCodepoints['suno'] != null) allWordCodepoints['suno']!,
      if (allWordCodepoints['toki'] != null) allWordCodepoints['toki']!,
    };
    if (full.length >= offset + 4 &&
        starts.contains(full[offset]) &&
        (full[offset + 1] == e ||
            (colon != null && full[offset + 1] == colon))) {
      full[offset + 2] = nena;
      full[offset + 3] = en;
      return;
    }

    // Compatibility fallback for a legacy Core stream that contains the old
    // nena+e marker but lacks a recognized opening separator.
    for (var i = offset; i + 1 < full.length; i++) {
      if (full[i] == nena && full[i + 1] == e) {
        full[i + 1] = en;
        return;
      }
    }
  }

  void _patchMixedStyleLong(List<int> full, String source, FullParserOptions options) {
    if (options.mixedStyle != 'long' || !source.contains('+') || !source.contains('/')) {
      return;
    }
    final nena = allWordCodepoints['nena'];
    final open = allWordCodepoints['open'];
    final kin = allWordCodepoints['kin'];
    final o = allWordCodepoints['o'];
    if (nena == null || open == null || kin == null || o == null) return;
    for (var i = 0; i + 3 < full.length; i++) {
      if (full[i] == nena &&
          full[i + 1] == open &&
          full[i + 2] == kin &&
          full[i + 3] == open) {
        full.replaceRange(
          i,
          i + 4,
          <int>[nena, o, nena, o, nena, o],
        );
        return;
      }
    }
  }

  List<int> _numericActive(
    RenderResult rendered,
    String source,
    FullParserOptions options,
  ) {
    final traditional =
        options.numericMode == 'traditional' || options.mode == 'traditional';
    final corrected = traditional
        ? _traditionalFullCodepoints(rendered, options)
        : null;
    final full = List<int>.from(corrected ?? rendered.activeCodepoints);
    _patchExplicitPositive(full, source);
    _patchMixedStyleLong(full, source, options);
    return full;
  }

  bool _syntheticCorner(ProductionFontInfo font, List<int> cps) =>
      cps.length == 1 &&
      (cps.first == openQuoteCodepoint || cps.first == closeQuoteCodepoint) &&
      '${font.renderAdapterSettings['cornerBracketMode'] ?? ''}'.toLowerCase() ==
          'synthetic';

  _Graphic _syntheticCornerGraphic(int cp, double fontSize) {
    final width = math.max(1.0, (fontSize * .36).ceilToDouble());
    final height = math.max(1.0, (fontSize * .76).ceilToDouble());
    final lift = cp == closeQuoteCodepoint ? 0.0 : math.max(4.0, fontSize * .18);
    final ascent = height * .82 + lift;
    return _Graphic(
      width: width,
      height: ascent + math.max(0.0, height - ascent + lift),
      baseline: ascent,
      syntheticCornerCodepoint: cp,
    );
  }

  _Logical _glyphLogical({
    required String source,
    required List<int> codepoints,
    required int start,
    required int end,
    required String sourceKind,
    required ProductionFontInfo font,
    required FullRenderOptions options,
    bool quoted = false,
    bool interpreted = false,
  }) {
    final canonical = List<int>.from(codepoints);
    final rawBypass = parseRawUnicodeSequence(source.trim()) != null;
    var render = rawBypass
        ? List<int>.from(canonical)
        : adaptFullWordRun(font, canonical);
    if (!rawBypass) {
      final adapter = runtimeAdapters[font.renderAdapterId];
      if (adapter != null) {
        render = List<int>.from(adapter(canonical, font, options.fontSize));
      }
    }
    final text = String.fromCharCodes(render);
    final synthetic = !rawBypass && _syntheticCorner(font, canonical);
    final family = _nativeBaseFamilies[font.key] ?? font.baseFamily;
    final graphic = synthetic
        ? _syntheticCornerGraphic(canonical.first, options.fontSize)
        : _measureGraphic(
            text: text,
            family: family,
            fontPath: font.basePath,
            fontSize: options.fontSize,
          );
    final run = FullRenderRun(
      kind: rawBypass || canonical.length > 1 || render.length > 1 ? 'run' : 'glyph',
      renderMode: synthetic ? 'synthetic-corner-bracket' : 'text',
      fontRole: 'word',
      canonicalCodepoints: List<int>.unmodifiable(canonical),
      renderCodepoints: List<int>.unmodifiable(render),
      renderText: text,
      renderAdapterId: rawBypass ? 'identity' : font.renderAdapterId,
      sourceText: source,
      sourceKind: sourceKind,
      sourceStart: start,
      sourceEnd: end,
      quoted: quoted,
      interpretedQuote: interpreted,
    );
    return _Logical(run, graphic);
  }

  _Logical _ideographicSpaceLogical({
    required String source,
    required int start,
    required int end,
    required String sourceKind,
    required ProductionFontInfo font,
    required FullRenderOptions options,
  }) =>
      _Logical(
        FullRenderRun(
          kind: 'text',
          renderMode: 'raster',
          fontRole: 'literal',
          renderText: String.fromCharCode(0x3000),
          renderAdapterId: 'identity',
          sourceText: source,
          sourceKind: sourceKind,
          sourceStart: start,
          sourceEnd: end,
        ),
        _Graphic(
          width: options.fontSize,
          height: 0,
          baseline: 0,
        ),
      );

  _Logical _literalCartoucheLogical({
    required String source,
    required List<int> inner,
    required int start,
    required int end,
    required String sourceKind,
    required ProductionFontInfo font,
    required FullRenderOptions options,
  }) {
    final full = <int>[cartoucheStart, ...inner, cartoucheEnd];
    final text = String.fromCharCodes(full);
    final path = font.literalCartouchePath ?? font.basePath;
    final family = _nativeBaseFamilies[font.key] ?? font.baseFamily;
    final graphic = _measureGraphic(
      text: text,
      family: family,
      fontPath: path,
      fontSize: options.fontSize,
      pad: 6,
    );
    return _Logical(
      FullRenderRun(
        kind: 'cartouche',
        renderMode: 'raster',
        fontRole: 'cartouche',
        openerCodepoint: cartoucheStart,
        closerCodepoint: cartoucheEnd,
        canonicalCodepoints: List<int>.unmodifiable(inner),
        renderCodepoints: List<int>.unmodifiable(full),
        renderText: text,
        renderAdapterId: 'identity',
        sourceText: source,
        sourceKind: sourceKind,
        sourceStart: start,
        sourceEnd: end,
      ),
      graphic,
    );
  }

  ProductionSupportFontInfo? _literalTextFont() =>
      registry.supportFont('literalText');

  _Logical _literalLogical({
    required String source,
    required int start,
    required int end,
    required String sourceKind,
    required ProductionFontInfo font,
    required FullRenderOptions options,
    bool quoted = false,
    bool interpreted = false,
    bool unknown = false,
    String? renderedText,
  }) {
    final rendered = renderedText ?? source;
    final support = _literalTextFont();
    final path = support?.path ?? font.basePath;
    var graphic = _measureGraphic(
      text: rendered.isEmpty ? ' ' : rendered,
      family: support?.family ?? (_nativeBaseFamilies[font.key] ?? font.baseFamily),
      fontPath: path,
      fontSize: options.fontSize,
      unknownDecoration: unknown,
    );
    if (unknown) {
      final pad = options.paint.unknownText.paddingPx < 0 ? 0 : options.paint.unknownText.paddingPx;
      graphic = _Graphic(
        text: graphic.text,
        family: graphic.family,
        fontPath: graphic.fontPath,
        features: graphic.features,
        width: graphic.width + 2 * pad,
        height: graphic.height + 2 * pad,
        baseline: graphic.baseline + pad,
        originX: graphic.originX + pad,
        originY: graphic.originY + pad,
        unknownDecoration: true,
      );
    }
    return _Logical(
      FullRenderRun(
        kind: 'text',
        renderMode: 'raster',
        fontRole: unknown && interpreted ? 'unknown' : 'literal',
        renderText: rendered,
        renderAdapterId: 'identity',
        sourceText: source,
        sourceKind: sourceKind,
        sourceStart: start,
        sourceEnd: end,
        quoted: quoted,
        interpretedQuote: interpreted,
        unrecognized: unknown,
      ),
      graphic,
    );
  }

  _Logical _numericLogical({
    required String source,
    required RenderResult rendered,
    required int start,
    required int end,
    required String sourceKind,
    required ProductionFontInfo font,
    required FullRenderOptions options,
  }) {
    final full = _numericActive(rendered, source, options.parser);
    final adapted = adaptProductionNumericCartouche(full, font.renderAdapterId);
    final features = fullOpenTypeFeaturesFor(options.fontSize);
    final graphic = _measureGraphic(
      text: adapted.text,
      family: font.nativeCompanionFamily,
      fontPath: font.companionPath,
      fontSize: options.fontSize,
      features: features,
      pad: 6,
    );
    final inner = full.length >= 2
        ? full.sublist(1, full.length - 1)
        : List<int>.from(full);
    final parsed = rendered.parsed;
    return _Logical(
      FullRenderRun(
        kind: 'cartouche',
        renderMode: 'raster',
        fontRole: 'number',
        numericCartouche: true,
        hexCartouche: parsed.isHex,
        binaryCartouche: parsed.isBinary,
        numericBase: parsed.numberBase ?? 10,
        openerCodepoint: inner.isEmpty ? null : inner.first,
        closerCodepoint: inner.isEmpty ? null : inner.last,
        canonicalCodepoints: List<int>.unmodifiable(inner),
        renderCodepoints: List<int>.unmodifiable(adapted.text.runes),
        renderText: adapted.text,
        renderAdapterId: font.renderAdapterId,
        sourceText: source,
        sourceKind: sourceKind,
        sourceStart: start,
        sourceEnd: end,
      ),
      graphic,
    );
  }

  int _byteIndexForRuneIndex(String text, int runeIndex) {
    if (runeIndex <= 0) return 0;
    final runes = text.runes.toList(growable: false);
    final end = math.min(runeIndex, runes.length);
    return utf8.encode(String.fromCharCodes(runes.sublist(0, end))).length;
  }

  _Logical _cartoucheLogical({
    required String source,
    required OrdinaryCartouche cartouche,
    required int start,
    required int end,
    required String sourceKind,
    required ProductionFontInfo font,
    required FullRenderOptions options,
  }) {
    final adapted = adaptOrdinaryCartouche(font, cartouche.inner);
    final family = _nativeBaseFamilies[font.key] ?? font.baseFamily;
    final extra = cartouche.hasManualTallies
        ? (options.fontSize * .34).ceilToDouble()
        : 0.0;
    var graphic = _measureGraphic(
      text: adapted.text,
      family: family,
      fontPath: font.basePath,
      fontSize: options.fontSize,
      pad: 6,
      bottomExtra: extra,
    );
    final groups = <TallyGroup>[];
    if (cartouche.hasManualTallies) {
      final bottom = graphic.height - extra - 6;
      final lift = manualTallyLift(font, options.parser, options.fontSize);
      final top = bottom - lift;
      final bot = top + options.fontSize * .10;
      final stroke = math.max(1.5, options.fontSize * .045);
      final gap = options.fontSize * .075;
      for (var i = 0; i < cartouche.manualTallies.length; i++) {
        final count = math.max(0, math.min(8, cartouche.manualTallies[i])).toInt();
        if (count == 0) continue;
        final span = adapted.canonicalSpans[i + 1];
        final left = graphic.originX +
            fullTextCaretXNative(
              text: adapted.text,
              family: family,
              fontPath: font.basePath,
              fontSize: options.fontSize,
              byteIndex: _byteIndexForRuneIndex(adapted.text, span[0]),
            );
        final right = graphic.originX +
            fullTextCaretXNative(
              text: adapted.text,
              family: family,
              fontPath: font.basePath,
              fontSize: options.fontSize,
              byteIndex: _byteIndexForRuneIndex(adapted.text, span[1]),
            );
        final center = (left + right) / 2;
        final total = count <= 1
            ? stroke
            : count * stroke + (count - 1) * gap;
        final first = center - total / 2 + stroke / 2;
        final centers = List<double>.generate(
          count,
          (k) => first + k * (stroke + gap),
          growable: false,
        );
        groups.add(TallyGroup(
          ownerIndex: i,
          count: count,
          ownerLeftPx: left,
          ownerRightPx: right,
          centerXPx: center,
          topYPx: top,
          bottomYPx: bot,
          strokeWidthPx: stroke,
          strokeCentersPx: centers,
        ));
      }
      graphic = _Graphic(
        text: graphic.text,
        family: graphic.family,
        fontPath: graphic.fontPath,
        features: graphic.features,
        width: graphic.width,
        height: graphic.height,
        baseline: graphic.baseline,
        originX: graphic.originX,
        originY: graphic.originY,
        tallyGroups: List<TallyGroup>.unmodifiable(groups),
      );
    }
    return _Logical(
      FullRenderRun(
        kind: 'cartouche',
        renderMode: 'raster',
        fontRole: 'cartouche',
        openerCodepoint: cartoucheStart,
        closerCodepoint: cartoucheEnd,
        canonicalCodepoints: List<int>.unmodifiable(cartouche.inner),
        renderCodepoints: List<int>.unmodifiable(adapted.text.runes),
        renderText: adapted.text,
        renderAdapterId: font.renderAdapterId,
        sourceText: source,
        sourceKind: sourceKind,
        sourceStart: start,
        sourceEnd: end,
        manualTallies: cartouche.hasManualTallies
            ? List<int>.unmodifiable(cartouche.manualTallies)
            : const <int>[],
      ),
      graphic,
    );
  }

  double _parseSize(String value, double base) {
    var s = value.trim().toLowerCase();
    if (s.isEmpty) return double.nan;
    var multiplier = 1.0;
    if (s.endsWith('em')) {
      multiplier = base;
      s = s.substring(0, s.length - 2);
    } else if (s.endsWith('px')) {
      s = s.substring(0, s.length - 2);
    }
    final parsed = double.tryParse(s);
    return parsed == null ? double.nan : parsed * multiplier;
  }

  List<double>? _pngDimensions(Uint8List bytes) {
    if (bytes.length < 24 ||
        bytes[0] != 0x89 ||
        bytes[1] != 0x50 ||
        bytes[2] != 0x4e ||
        bytes[3] != 0x47) {
      return null;
    }
    int u32(int at) =>
        (bytes[at] << 24) |
        (bytes[at + 1] << 16) |
        (bytes[at + 2] << 8) |
        bytes[at + 3];
    return <double>[u32(16).toDouble(), u32(20).toDouble()];
  }

  _Logical _imageLogical({
    required DocumentSegment segment,
    required ProductionFontInfo font,
    required FullRenderOptions options,
  }) {
    final descriptor = segment.image ?? const ImageDescriptor();
    Uint8List? raw;
    if (descriptor.src.startsWith('data:image/')) {
      raw = decodeDataImage(descriptor.src);
    } else if (descriptor.src.isNotEmpty) {
      try {
        raw = File(descriptor.src).readAsBytesSync();
      } catch (_) {
        raw = null;
      }
    }
    final dims = raw == null ? null : _pngDimensions(raw);
    var naturalW = dims?[0] ?? double.nan;
    var naturalH = dims?[1] ?? double.nan;
    var targetW = _parseSize(descriptor.width, options.fontSize);
    var targetH = _parseSize(descriptor.height, options.fontSize);
    if (targetW.isNaN && targetH.isNaN) targetH = options.fontSize;
    if (targetW.isNaN) {
      targetW = naturalW.isNaN || naturalH.isNaN || naturalH == 0
          ? targetH
          : targetH * naturalW / naturalH;
    }
    if (targetH.isNaN) {
      targetH = naturalW.isNaN || naturalH.isNaN || naturalW == 0
          ? targetW
          : targetW * naturalH / naturalW;
    }
    final baseline = descriptor.vAlign.toLowerCase() == 'center'
        ? targetH * .75
        : targetH;
    return _Logical(
      FullRenderRun(
        kind: 'cartouche',
        renderMode: 'raster',
        fontRole: 'cartouche',
        renderAdapterId: font.renderAdapterId,
        sourceKind: 'image',
        sourceStart: segment.sourceStart,
        sourceEnd: segment.sourceEnd,
        imageAlt: descriptor.alt,
      ),
      _Graphic(
        width: math.max(1, targetW),
        height: math.max(1, targetH),
        baseline: baseline,
        imageBytes: raw,
        imageHref: descriptor.src,
      ),
    );
  }

  String _normalizeFullGlyphKey(String raw) {
    var key = raw.trim().toLowerCase();
    key = _glyphInputAliases[key] ?? key;
    if (key == '·' || key == '.' || key == ':' || key == ',') return key;
    return sanitizeRendererWord(key);
  }

  int? _fullGlyphCp(String raw) {
    final key = _normalizeFullGlyphKey(raw);
    if (key == 'te') return openQuoteCodepoint;
    if (key == 'to') return closeQuoteCodepoint;
    if (key == 'zz') return 0x3000;
    if (key == 'ota' || key == '·') return middleDotCodepoint;
    if (key == ',') return tallyCodepoint;
    return allWordCodepoints[key];
  }

  bool _isDirectRenderCodepoint(int cp) =>
      (cp >= 0xF1900 && cp <= 0xF19FF) ||
      cp == openQuoteCodepoint ||
      cp == closeQuoteCodepoint;

  ({int cp, int width}) _codepointAt(String text, int index) {
    final first = text.codeUnitAt(index);
    if (first >= 0xD800 && first <= 0xDBFF && index + 1 < text.length) {
      final second = text.codeUnitAt(index + 1);
      if (second >= 0xDC00 && second <= 0xDFFF) {
        final cp = 0x10000 + ((first - 0xD800) << 10) + (second - 0xDC00);
        return (cp: cp, width: 2);
      }
    }
    return (cp: first, width: 1);
  }

  List<int>? _glyphExpressionCps(String expression) {
    final source = expression.trim();
    if (source.isEmpty || RegExp(r'\s').hasMatch(source)) return null;
    final matches = RegExp(r'[&+-]').allMatches(source).toList(growable: false);
    final words = source.split(RegExp(r'[&+-]'));
    if (words.length != matches.length + 1 || words.any((w) => w.isEmpty)) {
      return null;
    }
    final out = <int>[];
    for (var i = 0; i < words.length; i++) {
      final cp = _fullGlyphCp(words[i]);
      if (cp == null) return null;
      out.add(cp);
      if (i < matches.length) {
        final op = matches[i].group(0)!;
        out.add(op == '&'
            ? 0x200D
            : (op == '-' ? stackJoinerCodepoint : nestJoinerCodepoint));
      }
    }
    return out;
  }

  List<int>? _glyphWordsCps(String text) {
    final fields = text.trim().split(RegExp(r'\s+')).where((s) => s.isNotEmpty);
    final out = <int>[];
    var any = false;
    for (final field in fields) {
      any = true;
      final expr = _glyphExpressionCps(field);
      if (expr != null) {
        out.addAll(expr);
        continue;
      }
      final cp = _fullGlyphCp(field);
      if (cp == null) return null;
      out.add(cp);
    }
    return any ? out : null;
  }

  List<int>? _extendedGlyphCps(String left, String head, String right) {
    final headCp = _fullGlyphCp(head);
    if (headCp == null) return null;
    final out = <int>[];
    if (left.trim().isNotEmpty) {
      final cps = _glyphWordsCps(left);
      if (cps == null || cps.isEmpty) return null;
      out
        ..add(0xF199A)
        ..addAll(cps)
        ..add(0xF199B);
    }
    out.add(headCp);
    if (right.trim().isNotEmpty) {
      final cps = _glyphWordsCps(right);
      if (cps == null || cps.isEmpty) return null;
      out
        ..add(0xF1997)
        ..addAll(cps)
        ..add(0xF1998);
    }
    return out.length > 1 ? out : null;
  }

  String? _legacyLongPiInner(String source) {
    final s = source.trim();
    if (s.toLowerCase().startsWith('pi+__')) {
      final parts = s.substring(5).split('__');
      if (parts.isEmpty || parts.length > 3 || parts.any((x) => _fullGlyphCp(x) == null)) {
        return null;
      }
      return parts.join(' ');
    }
    final m = RegExp(r'^pi(\+{1,3}|-{2,3})(.*)$', caseSensitive: false)
        .firstMatch(s);
    if (m == null) return null;
    final expected = m.group(1)!.length;
    final words = m.group(2)!.trim().split(RegExp(r'\s+'));
    if (words.length != expected || words.any((w) => _fullGlyphCp(w) == null)) {
      return null;
    }
    return words.join(' ');
  }

  String? _normalizeExtendedLegacyCartouche(String body) {
    final s = body.trim();
    if (!s.startsWith('_')) return null;
    final words = <String>[];
    for (final raw in s.split('_')) {
      final part = raw.trim();
      if (part.isEmpty) continue;
      if (_fullGlyphCp(part) == null) return null;
      words.add(part);
    }
    return words.isEmpty ? null : words.join(' ');
  }

  String _unescapeFullQuoted(String raw) => raw
      .replaceAll(r'\"', '"')
      .replaceAll(r'\\', '\\')
      .replaceAll(r'\t', '    ')
      .replaceAll(r'\n', '\n');

  List<int> _lettersToFallbackGlyphCps(String source) {
    const banned = <String>{'ota', 'kolon', 'koma', 'te', 'to', 'zz'};
    final keys = allWordCodepoints.keys
        .where((k) => RegExp(r'^[a-z]+$').hasMatch(k) && !banned.contains(k))
        .toList()
      ..sort();
    final bucket = <String, int>{};
    for (final key in keys) {
      bucket.putIfAbsent(key[0], () => allWordCodepoints[key]!);
    }
    final out = <int>[];
    for (final rune in source.toLowerCase().runes) {
      final ch = String.fromCharCode(rune);
      final cp = bucket[ch];
      if (cp != null) out.add(cp);
    }
    return out;
  }

  RenderResult _directRender(ParseResult parsed) {
    final fullInner = List<int>.unmodifiable(parsed.innerCodepoints);
    final full = List<int>.unmodifiable(<int>[cartoucheStart, ...fullInner, cartoucheEnd]);
    final words = List<String>.unmodifiable(parsed.words);
    return RenderResult(
      parsed: parsed,
      fullWords: words,
      fullInnerCodepoints: fullInner,
      fullCodepoints: full,
      abbreviatedWords: null,
      abbreviatedInnerCodepoints: null,
      abbreviatedCodepoints: null,
      abbreviated: false,
      activeWords: words,
      activeInnerCodepoints: fullInner,
      activeCodepoints: full,
      unicodeText: String.fromCharCodes(full),
    );
  }

  RenderResult? _phraseRender(
    String source,
    FullParserOptions options, {
    bool abbreviatedOnly = false,
  }) {
    final t = source.trim();
    if (!RegExp(r'^[a-z]+(?:\s+[a-z]+)+$').hasMatch(t)) return null;
    final words = t.split(RegExp(r'\s+'));
    if (words.length < 3 || words.first != 'nanpa' || words.last != 'nanpa') {
      return null;
    }
    const digits = <String>{
      'ijo','wan','tu','seli','awen','luka','utala','mun','pipi','jo'
    };
    if (abbreviatedOnly) {
      if (!options.abbreviateNumericCartouches) return null;
      final positive = words.length >= 4 && words[1] == 'en';
      var hasDigit = false;
      for (var i = 0; i < words.length; i++) {
        final w = words[i];
        if (!allWordCodepoints.containsKey(w)) return null;
        final finalNanpa = w == 'nanpa' && i == words.length - 1;
        final positiveMarker = positive && i == 1 && w == 'en';
        if (i > 0 &&
            !finalNanpa &&
            !positiveMarker &&
            const <String>{'nanpa','en','e','nena','open','ala','ike','uta'}.contains(w)) {
          return null;
        }
        if (digits.contains(w)) hasDigit = true;
      }
      if (!hasDigit) return null;
      return _phraseWordsResult(t, words, options);
    }

    if (!const <String>{'e','en','esun'}.contains(words[1])) return null;
    if (words[1] == 'en') {
      const scaffold = <String>{'nanpa','en','e','nena','open','ala','ike','uta'};
      if (!words.sublist(2, words.length - 1).any(scaffold.contains)) return null;
    }
    var hasDigit = false;
    for (var i = 0; i < words.length; i++) {
      final w = words[i];
      if (!allWordCodepoints.containsKey(w)) return null;
      if (digits.contains(w)) hasDigit = true;
      if (i > 0 && digits.contains(words[i - 1]) && digits.contains(w)) return null;
    }
    if (!hasDigit) return null;
    final canonical = List<String>.from(words);
    final positive = canonical.length >= 5 &&
        canonical[0] == 'nanpa' && canonical[1] == 'e' &&
        canonical[2] == 'nena' && canonical[3] == 'en';
    if (options.nanpaColonRendering && canonical.length >= 3) canonical[1] = ':';
    for (var i = 2; i < canonical.length - 1; i++) {
      if (canonical[i] == 'en' && !(positive && i == 3)) canonical[i] = 'e';
    }
    return _phraseWordsResult(t, canonical, options);
  }

  RenderResult? _phraseWordsResult(
    String source,
    List<String> words,
    FullParserOptions options,
  ) {
    final cps = <int>[];
    for (final w in words) {
      final cp = allWordCodepoints[w];
      if (cp == null) return null;
      cps.add(cp);
    }
    final parsed = ParseResult(
      input: source,
      caps: null,
      properName: '',
      uniqueCode: '',
      ucsurCodepoints: List<int>.from(cps),
      hexCodepoints: '',
      hexWithCartouche: '',
      tpWords: List<String>.from(words),
      words: List<String>.from(words),
      displayValue: source,
      isTime: false,
      isDate: false,
      isTimeLike: false,
      innerCodepoints: List<int>.from(cps),
      codepoints: <int>[cartoucheStart, ...cps, cartoucheEnd],
      numericMode: options.numericMode,
      numberBase: 10,
    );
    return _directRender(parsed);
  }

  RenderResult? _mixedSpaceRender(String source, FullParserOptions options) {
    final m = RegExp(r'^([+-]?[0-9][0-9,]*)[ \t]+([0-9]+/[0-9]+)$')
        .firstMatch(source);
    if (m == null) return null;
    final whole = _numericParsed(m.group(1)!, options);
    final frac = _numericParsed(m.group(2)!, options);
    if (whole == null || frac == null) return null;
    final a = whole.activeInnerCodepoints;
    final b = frac.activeInnerCodepoints;
    if (a.length < 3 || b.length < 3) return null;
    final nena = allWordCodepoints['nena'];
    final e = allWordCodepoints['e'];
    if (nena == null || e == null) return null;
    final inner = <int>[
      a.first,
      if (a.length > 1) a[1],
      ...a.sublist(2, a.length - 1),
      nena,e,nena,e,
      ...b.sublist(2, b.length - 1),
      a.last,
    ];
    final words = inner.map((cp) => allCodepointWords[cp] ?? '').where((w) => w.isNotEmpty).toList();
    final parsed = ParseResult(
      input: source,
      caps: null,
      properName: '',
      uniqueCode: '',
      ucsurCodepoints: List<int>.from(inner),
      hexCodepoints: '',
      hexWithCartouche: '',
      tpWords: List<String>.from(words),
      words: List<String>.from(words),
      displayValue: source,
      isTime: false,
      isDate: false,
      isTimeLike: false,
      innerCodepoints: List<int>.from(inner),
      codepoints: <int>[cartoucheStart, ...inner, cartoucheEnd],
      numericMode: options.numericMode,
      numberBase: 10,
    );
    return _directRender(parsed);
  }

  ({int start, int end, RenderResult render})? _properNumericPrefix(
    String text,
    FullParserOptions options,
  ) {
    final words = RegExp(r'[A-Za-z]+').allMatches(text).toList(growable: false);
    if (words.isEmpty) return null;
    for (var i = 0; i < words.length; i++) {
      final first = words[i].group(0)!;
      if (first.isEmpty || first[0] != first[0].toUpperCase()) continue;
      final low = first.toLowerCase();
      final typed = options.nanpaColonParsing || options.nanpaColonRendering;
      final plausible = low.startsWith('ne') ||
          (options.enableHexParsing && low.startsWith('nasa')) ||
          ((options.enableBinaryParsing || options.enableBinaryRendering) &&
              low.startsWith('noka')) ||
          (typed &&
              (first == 'Nanpa' ||
                  first.startsWith('Nanpa') ||
                  first == 'Tenpo' ||
                  first == 'Suno' ||
                  first == 'Toki'));
      if (!plausible) continue;

      RenderResult? best;
      var bestEnd = -1;
      final start = words[i].start;
      for (var j = i; j < words.length && j < i + 31; j++) {
        if (j > i) {
          final between = text.substring(words[j - 1].end, words[j].start);
          final w = words[j].group(0)!;
          if (!RegExp(r'^[ \t]*$').hasMatch(between) ||
              w.isEmpty ||
              w[0] != w[0].toUpperCase()) {
            break;
          }
        }
        final candidate = text.substring(start, words[j].end);
        final parsed = _numericParsed(candidate, options);
        if (parsed != null) {
          best = parsed;
          bestEnd = words[j].end;
        }
      }
      if (best != null && bestEnd > start) {
        // A bare `Toki` claim must not steal the prefix of a longer proper-name
        // phrase.  This mirrors the JavaScript scanner's longest-prefix guard.
        if (first == 'Toki' && i + 1 < words.length && bestEnd < text.length) {
          var bestIndex = -1;
          for (var j = i; j < words.length; j++) {
            if (words[j].end == bestEnd) {
              bestIndex = j;
              break;
            }
          }
          if (bestIndex >= 0 &&
              bestIndex + 1 < words.length &&
              words[bestIndex + 1].group(0)!.isNotEmpty &&
              words[bestIndex + 1].group(0)![0] ==
                  words[bestIndex + 1].group(0)![0].toUpperCase() &&
              RegExp(r'^[ \t]*$').hasMatch(
                text.substring(words[bestIndex].end, words[bestIndex + 1].start),
              )) {
            continue;
          }
        }
        return (start: start, end: bestEnd, render: best);
      }
    }
    return null;
  }

  void _emitPunct({
    required String punct,
    required int sourceStart,
    required String kind,
    required List<_Logical> out,
    required ProductionFontInfo font,
    required FullRenderOptions options,
  }) {
    for (var i = 0; i < punct.length; i++) {
      final ch = punct[i];
      final cp = ch == '.' || ch == '·'
          ? middleDotCodepoint
          : (ch == ':' ? colonCodepoint : null);
      if (cp != null) {
        out.add(_glyphLogical(
          source: ch,
          codepoints: <int>[cp],
          start: sourceStart + i,
          end: sourceStart + i + 1,
          sourceKind: kind,
          font: font,
          options: options,
        ));
      }
    }
  }

  void _emitCore({
    required String core,
    required int start,
    required int end,
    required String kind,
    required List<_Logical> out,
    required ProductionFontInfo font,
    required FullRenderOptions options,
  }) {
    final key = _normalizeFullGlyphKey(core);
    if (key == 'zz') {
      out.add(_ideographicSpaceLogical(
        source: core,
        start: start,
        end: end,
        sourceKind: kind,
        font: font,
        options: options,
      ));
      return;
    }

    final aliasCp = _fullGlyphCp(key);
    if (_glyphInputAliases.containsKey(core.toLowerCase()) ||
        key == 'te' || key == 'to' || key == 'ota') {
      if (aliasCp != null) {
        out.add(_glyphLogical(
          source: core,
          codepoints: <int>[aliasCp],
          start: start,
          end: end,
          sourceKind: kind,
          font: font,
          options: options,
        ));
        return;
      }
    }

    final suffix = RegExp(r'^([A-Za-z^<>]+)([0-9]+)$').firstMatch(core);
    if (suffix != null && !_glyphInputAliases.containsKey(core.toLowerCase())) {
      final cp = _fullGlyphCp(suffix.group(1)!);
      if (cp != null) {
        out.add(_glyphLogical(
          source: suffix.group(1)!,
          codepoints: <int>[cp],
          start: start,
          end: start + suffix.group(1)!.length,
          sourceKind: kind,
          font: font,
          options: options,
        ));
        final numeric = _numericParsed(suffix.group(2)!, options.parser);
        if (numeric != null) {
          out.add(_numericLogical(
            source: suffix.group(2)!,
            rendered: numeric,
            start: start + suffix.group(1)!.length,
            end: end,
            sourceKind: kind,
            font: font,
            options: options,
          ));
          return;
        }
      }
    }

    final numeric = _numericParsed(core, options.parser);
    if (numeric != null) {
      if (options.parser.nasinNanpaPona && _integer.hasMatch(core)) {
        for (final word in nasinNanpaPonaWords(core.replaceFirst('+', ''))) {
          final cp = allWordCodepoints[word];
          if (cp != null) {
            out.add(_glyphLogical(
              source: core,
              codepoints: <int>[cp],
              start: start,
              end: end,
              sourceKind: kind,
              font: font,
              options: options,
            ));
          }
        }
      } else {
        out.add(_numericLogical(
          source: core,
          rendered: numeric,
          start: start,
          end: end,
          sourceKind: kind,
          font: font,
          options: options,
        ));
      }
      return;
    }

    if (options.parser.autoCartoucheStandaloneProperNames &&
        core.isNotEmpty && RegExp(r'^[A-Z]').hasMatch(core)) {
      final cps = properNameCodepoints(core);
      if (cps != null && cps.isNotEmpty) {
        out.add(_cartoucheLogical(
          source: core,
          cartouche: OrdinaryCartouche(cps, List<int>.filled(cps.length, 0), 'ucsur'),
          start: start,
          end: end,
          sourceKind: kind,
          font: font,
          options: options,
        ));
        return;
      }
    }

    final cp = _fullGlyphCp(core);
    if (cp != null) {
      if (cp == 0x3000) {
        out.add(_ideographicSpaceLogical(
          source: core,
          start: start,
          end: end,
          sourceKind: kind,
          font: font,
          options: options,
        ));
      } else if (key != ',') {
        out.add(_glyphLogical(
          source: core,
          codepoints: <int>[cp],
          start: start,
          end: end,
          sourceKind: kind,
          font: font,
          options: options,
        ));
      }
      return;
    }

    if (options.parser.showUnknownText) {
      var literal = core;
      var literalStart = start;
      var literalEnd = end;
      if (options.parser.effectiveRendererMode == 'standard-sitelen-pona-ascii-core' &&
          literal.length >= 2 && literal.startsWith("'") && literal.endsWith("'")) {
        literal = literal.substring(1, literal.length - 1);
        literalStart++;
        literalEnd--;
      }
      out.add(_literalLogical(
        source: literal,
        start: literalStart,
        end: literalEnd,
        sourceKind: kind,
        font: font,
        options: options,
        unknown: true,
      ));
    }
  }

  void _parseTextBase({
    required String text,
    required int base,
    required String kind,
    required List<_Logical> out,
    required ProductionFontInfo font,
    required FullRenderOptions options,
  }) {
    if (text.isEmpty || text.trim().isEmpty) return;

    final mixed = _mixedSpaceRender(text, options.parser);
    if (mixed != null) {
      out.add(_numericLogical(
        source: text,
        rendered: mixed,
        start: base,
        end: base + text.length,
        sourceKind: kind,
        font: font,
        options: options,
      ));
      return;
    }
    final phrase = _phraseRender(text, options.parser);
    if (phrase != null) {
      out.add(_numericLogical(
        source: text,
        rendered: phrase,
        start: base,
        end: base + text.length,
        sourceKind: kind,
        font: font,
        options: options,
      ));
      return;
    }
    final proper = _properNumericPrefix(text, options.parser);
    if (proper != null) {
      out.add(_numericLogical(
        source: text.substring(proper.start, proper.end),
        rendered: proper.render,
        start: base + proper.start,
        end: base + proper.end,
        sourceKind: kind,
        font: font,
        options: options,
      ));
      if (proper.end < text.length) {
        _parseTextBase(
          text: text.substring(proper.end),
          base: base + proper.end,
          kind: kind,
          out: out,
          font: font,
          options: options,
        );
      }
      return;
    }

    if (!options.parser.enableBinaryParsing &&
        !options.parser.enableBinaryRendering) {
      final bm = RegExp(r'^0b([01]+)$', caseSensitive: false)
          .firstMatch(text.trim());
      if (bm != null) {
        final offset = text.indexOf(text.trim());
        final digits = bm.group(1)!;
        final prefix = _numericParsed('0b', options.parser);
        final firstDigit = _numericParsed(digits.substring(0, 1), options.parser);
        if (prefix != null) {
          out.add(_numericLogical(
            source: '0b',
            rendered: prefix,
            start: base + offset,
            end: base + offset + 2,
            sourceKind: kind,
            font: font,
            options: options,
          ));
        }
        if (firstDigit != null) {
          out.add(_numericLogical(
            source: digits.substring(0, 1),
            rendered: firstDigit,
            start: base + offset + 2,
            end: base + offset + 3,
            sourceKind: kind,
            font: font,
            options: options,
          ));
        }
        if (digits.length > 1) {
          final remainder = _numericParsed(digits.substring(1), options.parser);
          if (remainder != null) {
            out.add(_numericLogical(
              source: digits.substring(1),
              rendered: remainder,
              start: base + offset + 3,
              end: base + offset + 2 + digits.length,
              sourceKind: kind,
              font: font,
              options: options,
            ));
          }
        }
        return;
      }
    }

    for (final match in RegExp(r'[^\s\u2010\u2011\u2012\u2013\u2014\u2212\uFE63\uFF0D]+')
        .allMatches(text)) {
      final token = match.group(0)!;
      final tokenStart = base + match.start;
      final tokenEnd = base + match.end;
      final numericCandidate = RegExp(r'[0-9¼½¾⅐⅑⅒⅓⅔⅕⅖⅗⅘⅙⅚⅛⅜⅝⅞]').hasMatch(token);
      if (numericCandidate && !(options.parser.nasinNanpaPona && RegExp(r'^\+?[0-9]+$').hasMatch(token))) {
        final exact = _numericParsed(token, options.parser);
        if (exact != null) {
          out.add(_numericLogical(source: token, rendered: exact, start: tokenStart,
              end: tokenEnd, sourceKind: kind, font: font, options: options));
          continue;
        }
      }
      var a = 0;
      var b = token.length;
      final numericLike = RegExp(r'[0-9]').hasMatch(token);
      bool allowed(String ch) {
        final cc = ch.codeUnitAt(0);
        if ((cc >= 0x30 && cc <= 0x39) ||
            (cc >= 0x41 && cc <= 0x5A) ||
            (cc >= 0x61 && cc <= 0x7A)) return true;
        if ('#~^<>'.contains(ch)) return true;
        return numericLike && '.,_-'.contains(ch);
      }
      while (a < b && !allowed(token[a])) {
        _emitPunct(punct: token[a], sourceStart: tokenStart + a, kind: kind,
            out: out, font: font, options: options);
        a++;
      }
      while (b > a && !allowed(token[b - 1])) b--;
      while (b > a && ')]},.;:!?'.contains(token[b - 1])) b--;
      final core = token.substring(a, b);
      if (core.isNotEmpty && !const <String>{'&','+','-'}.contains(core)) {
        _emitCore(core: core, start: tokenStart + a, end: tokenStart + b,
            kind: kind, out: out, font: font, options: options);
      }
      if (b < token.length) {
        _emitPunct(punct: token.substring(b), sourceStart: tokenStart + b,
            kind: kind, out: out, font: font, options: options);
      }
    }
  }

  void _parseSskLikeText({
    required String text,
    required int base,
    required String kind,
    required List<_Logical> out,
    required ProductionFontInfo font,
    required FullRenderOptions options,
  }) {
    var pos = 0;
    for (final m in _sskSpecial.allMatches(text)) {
      List<int>? cps;
      if (m.group(2) != null) {
        cps = _extendedGlyphCps(m.group(1) ?? '', m.group(2)!, m.group(3) ?? '');
      } else if (m.group(4) != null) {
        cps = _glyphExpressionCps(m.group(4)!);
      } else if (m.group(5) != null && m.group(6) != null) {
        cps = _extendedGlyphCps(m.group(5)!, m.group(6)!, '');
      }
      if (cps == null) continue;
      if (m.start > pos) {
        _parseTextBase(text: text.substring(pos, m.start), base: base + pos,
            kind: kind, out: out, font: font, options: options);
      }
      out.add(_glyphLogical(source: m.group(0)!, codepoints: cps,
          start: base + m.start, end: base + m.end, sourceKind: kind,
          font: font, options: options));
      pos = m.end;
    }
    if (pos < text.length) {
      _parseTextBase(text: text.substring(pos), base: base + pos,
          kind: kind, out: out, font: font, options: options);
    }
  }

  void _parseExtendedText({
    required String text,
    required int base,
    required String kind,
    required List<_Logical> out,
    required ProductionFontInfo font,
    required FullRenderOptions options,
  }) {
    var pos = 0;
    for (final m in _legacyLongPi.allMatches(text)) {
      if (m.start > pos) {
        _parseSskLikeText(text: text.substring(pos, m.start), base: base + pos,
            kind: kind, out: out, font: font, options: options);
      }
      final alias = m.group(0)!;
      final inner = _legacyLongPiInner(alias);
      final cps = inner == null ? null : _extendedGlyphCps('', 'pi', inner);
      if (cps != null) {
        out.add(_glyphLogical(source: alias, codepoints: cps,
            start: base + m.start, end: base + m.end, sourceKind: kind,
            font: font, options: options));
      } else {
        _parseSskLikeText(text: alias, base: base + m.start,
            kind: kind, out: out, font: font, options: options);
      }
      pos = m.end;
    }
    if (pos < text.length) {
      _parseSskLikeText(text: text.substring(pos), base: base + pos,
          kind: kind, out: out, font: font, options: options);
    }
  }

  void _parseStandardCoreText({
    required String text,
    required int base,
    required String kind,
    required List<_Logical> out,
    required ProductionFontInfo font,
    required FullRenderOptions options,
  }) {
    var pos = 0;
    for (final m in _coreSpecial.allMatches(text)) {
      if (m.start > pos) {
        _parseTextBase(text: text.substring(pos, m.start), base: base + pos,
            kind: kind, out: out, font: font, options: options);
      }
      List<int>? cps;
      if (m.group(1) != null) {
        final inner = _glyphWordsCps(m.group(1)!);
        final pi = allWordCodepoints['pi'];
        if (inner != null && pi != null) cps = <int>[pi, 0xF1997, ...inner, 0xF1998];
      } else if (m.group(2) != null) {
        cps = _glyphExpressionCps(m.group(2)!);
      } else if (m.group(3) == '|') {
        cps = <int>[0x3000];
      }
      if (cps != null) {
        final logical = _glyphLogical(source: m.group(0)!, codepoints: cps,
            start: base + m.start, end: base + m.end, sourceKind: kind,
            font: font, options: options);
        out.add(cps.length == 1 && cps.first == 0x3000
            ? _Logical(_copyRun(logical.run, kind: 'run'), logical.graphic)
            : logical);
      } else {
        _parseTextBase(text: m.group(0)!, base: base + m.start,
            kind: kind, out: out, font: font, options: options);
      }
      pos = m.end;
    }
    if (pos < text.length) {
      _parseTextBase(text: text.substring(pos), base: base + pos,
          kind: kind, out: out, font: font, options: options);
    }
  }

  FullRenderRun _copyRun(FullRenderRun run, {String? kind, bool? interpretedQuote}) =>
      FullRenderRun(
        id: run.id,
        lineIndex: run.lineIndex,
        runIndex: run.runIndex,
        kind: kind ?? run.kind,
        renderMode: run.renderMode,
        fontRole: run.fontRole,
        numericCartouche: run.numericCartouche,
        hexCartouche: run.hexCartouche,
        binaryCartouche: run.binaryCartouche,
        numericBase: run.numericBase,
        openerCodepoint: run.openerCodepoint,
        closerCodepoint: run.closerCodepoint,
        canonicalCodepoints: run.canonicalCodepoints,
        renderCodepoints: run.renderCodepoints,
        renderText: run.renderText,
        renderAdapterId: run.renderAdapterId,
        sourceText: run.sourceText,
        sourceKind: run.sourceKind,
        sourceStart: run.sourceStart,
        sourceEnd: run.sourceEnd,
        manualTallies: run.manualTallies,
        tallyGroups: run.tallyGroups,
        quoted: run.quoted,
        interpretedQuote: interpretedQuote ?? run.interpretedQuote,
        unrecognized: run.unrecognized,
        imageAlt: run.imageAlt,
        xPx: run.xPx,
        yPx: run.yPx,
        widthPx: run.widthPx,
        heightPx: run.heightPx,
        baselineYPx: run.baselineYPx,
      );

  void _parseTextNoRaw({
    required String text,
    required int base,
    required String kind,
    required List<_Logical> out,
    required ProductionFontInfo font,
    required FullRenderOptions options,
  }) {
    switch (options.parser.effectiveRendererMode) {
      case 'standard-sitelen-pona-ascii-core':
        _parseStandardCoreText(text: text, base: base, kind: kind, out: out,
            font: font, options: options);
        break;
      case 'sitelen-seli-kiwen':
        _parseSskLikeText(text: text, base: base, kind: kind, out: out,
            font: font, options: options);
        break;
      case 'sitelen-pona-ascii-extended':
        _parseExtendedText(text: text, base: base, kind: kind, out: out,
            font: font, options: options);
        break;
      default:
        _parseTextBase(text: text, base: base, kind: kind, out: out,
            font: font, options: options);
    }
  }

  void _parseText({
    required String text,
    required int base,
    required String kind,
    required List<_Logical> out,
    required ProductionFontInfo font,
    required FullRenderOptions options,
  }) {
    if (text.isEmpty || text.trim().isEmpty) return;

    // Actual UCSUR/codepoint input is accepted directly as well as U+XXXX
    // notation.  Split it at UTF-16 code-unit boundaries so source offsets
    // remain identical to JavaScript String offsets for supplementary UCSUR.
    var pos = 0;
    var ordinaryStart = 0;
    while (pos < text.length) {
      final current = _codepointAt(text, pos);
      if (!_isDirectRenderCodepoint(current.cp)) {
        pos += current.width;
        continue;
      }
      if (pos > ordinaryStart) {
        _parseTextNoDirect(
          text: text.substring(ordinaryStart, pos),
          base: base + ordinaryStart,
          kind: kind,
          out: out,
          font: font,
          options: options,
        );
      }
      final start = pos;
      final cps = <int>[];
      while (pos < text.length) {
        final next = _codepointAt(text, pos);
        if (!_isDirectRenderCodepoint(next.cp)) break;
        cps.add(next.cp);
        pos += next.width;
      }
      out.add(_glyphLogical(
        source: text.substring(start, pos),
        codepoints: cps,
        start: base + start,
        end: base + pos,
        sourceKind: kind,
        font: font,
        options: options,
      ));
      ordinaryStart = pos;
    }
    if (ordinaryStart < text.length) {
      _parseTextNoDirect(
        text: text.substring(ordinaryStart),
        base: base + ordinaryStart,
        kind: kind,
        out: out,
        font: font,
        options: options,
      );
    }
  }

  void _parseTextNoDirect({
    required String text,
    required int base,
    required String kind,
    required List<_Logical> out,
    required ProductionFontInfo font,
    required FullRenderOptions options,
  }) {
    if (text.isEmpty || text.trim().isEmpty) return;
    var pos = 0;
    for (final m in _rawUnicodeScan.allMatches(text)) {
      if (m.start > pos) {
        _parseTextNoRaw(text: text.substring(pos, m.start), base: base + pos,
            kind: kind, out: out, font: font, options: options);
      }
      final raw = m.group(0)!;
      final cps = parseRawUnicodeSequence(raw);
      if (cps != null) {
        out.add(_glyphLogical(source: raw, codepoints: cps,
            start: base + m.start, end: base + m.end, sourceKind: kind,
            font: font, options: options));
      } else {
        _parseTextNoRaw(text: raw, base: base + m.start, kind: kind,
            out: out, font: font, options: options);
      }
      pos = m.end;
    }
    if (pos < text.length) {
      _parseTextNoRaw(text: text.substring(pos), base: base + pos, kind: kind,
          out: out, font: font, options: options);
    }
  }

  void _parseBracket({
    required String body,
    required int sourceStart,
    required List<_Logical> out,
    required ProductionFontInfo font,
    required FullRenderOptions options,
  }) {
    final trimmed = body.trim();
    if (trimmed.isEmpty) return;
    if (trimmed.length >= 2 && trimmed.startsWith('"') && trimmed.endsWith('"')) {
      final literal = _unescapeFullQuoted(trimmed.substring(1, trimmed.length - 1));
      if (literal.isNotEmpty) {
        final inner = <int>[];
        for (final cp in literal.runes) {
          inner
            ..add(cp)
            ..add(0xF1992);
        }
        out.add(_literalCartoucheLogical(
          source: trimmed,
          inner: inner,
          start: sourceStart,
          end: sourceStart + body.length,
          sourceKind: 'bracket',
          font: font,
          options: options,
        ));
        return;
      }
    }
    var numeric = _numericParsed('[$trimmed]', options.parser);
    if (numeric != null) {
      out.add(_numericLogical(source: trimmed, rendered: numeric, start: sourceStart,
          end: sourceStart + body.length, sourceKind: 'bracket', font: font,
          options: options));
      return;
    }
    numeric = _numericParsed(trimmed, options.parser);
    if (numeric != null && !numeric.parsed.isHex && !numeric.parsed.isBinary) {
      out.add(_numericLogical(source: trimmed, rendered: numeric, start: sourceStart,
          end: sourceStart + body.length, sourceKind: 'bracket', font: font,
          options: options));
      return;
    }
    final phrase = _phraseRender(trimmed, options.parser);
    if (phrase != null) {
      out.add(_numericLogical(source: trimmed, rendered: phrase, start: sourceStart,
          end: sourceStart + body.length, sourceKind: 'bracket', font: font,
          options: options));
      return;
    }
    if (options.parser.abbreviateNumericCartouches) {
      final abbreviated = _phraseRender(trimmed, options.parser, abbreviatedOnly: true);
      if (abbreviated != null) {
        out.add(_numericLogical(source: trimmed, rendered: abbreviated,
            start: sourceStart, end: sourceStart + body.length,
            sourceKind: 'bracket', font: font, options: options));
        return;
      }
    }
    var ordinarySource = trimmed;
    if (options.parser.effectiveRendererMode == 'sitelen-pona-ascii-extended') {
      ordinarySource = _normalizeExtendedLegacyCartouche(trimmed) ?? ordinarySource;
    }
    if (!RegExp(r'[,.:·()]').hasMatch(ordinarySource)) {
      final cps = _glyphWordsCps(ordinarySource);
      if (cps != null) {
        out.add(_cartoucheLogical(source: trimmed,
            cartouche: OrdinaryCartouche(cps, List<int>.filled(cps.length, 0), 'ucsur'),
            start: sourceStart, end: sourceStart + body.length,
            sourceKind: 'bracket', font: font, options: options));
        return;
      }
    }
    final ordinary = parseOrdinaryCartoucheBody(ordinarySource, font, options.parser);
    if (ordinary != null) {
      out.add(_cartoucheLogical(source: trimmed, cartouche: ordinary,
          start: sourceStart, end: sourceStart + body.length,
          sourceKind: 'bracket', font: font, options: options));
      return;
    }
    final fallback = _lettersToFallbackGlyphCps(trimmed);
    if (fallback.isNotEmpty) {
      out.add(_cartoucheLogical(source: trimmed,
          cartouche: OrdinaryCartouche(fallback, List<int>.filled(fallback.length, 0), 'ucsur'),
          start: sourceStart, end: sourceStart + body.length,
          sourceKind: 'bracket', font: font, options: options));
    } else if (options.parser.showUnknownText) {
      out.add(_literalLogical(source: trimmed, start: sourceStart,
          end: sourceStart + body.length, sourceKind: 'bracket', font: font,
          options: options, unknown: true));
    }
  }

  void _parseQuote({
    required DocumentSegment segment,
    required List<_Logical> out,
    required ProductionFontInfo font,
    required FullRenderOptions options,
  }) {
    final q = segment.value
        .replaceAll(r'\"', '"')
        .replaceAll(r'\\', '\\')
        .replaceAll(r'\t', '    ')
        .replaceAll(r'\n', '\n');
    if (options.parser.interpretDoubleQuotesAsTeTo) {
      out.add(_glyphLogical(
        source: 'te',
        codepoints: const <int>[openQuoteCodepoint],
        start: segment.sourceStart,
        end: segment.sourceStart + 1,
        sourceKind: 'interpretedQuote',
        font: font,
        options: options,
        interpreted: true,
      ));
      final before = out.length;
      _parseText(
        text: q,
        base: segment.sourceStart + 1,
        kind: 'interpretedQuote',
        out: out,
        font: font,
        options: options,
      );
      for (var i = before; i < out.length; i++) {
        final old = out[i];
        out[i] = _Logical(
          FullRenderRun(
            id: old.run.id,
            lineIndex: old.run.lineIndex,
            runIndex: old.run.runIndex,
            kind: old.run.kind,
            renderMode: old.run.renderMode,
            fontRole: old.run.unrecognized ? 'unknown' : old.run.fontRole,
            numericCartouche: old.run.numericCartouche,
            hexCartouche: old.run.hexCartouche,
            binaryCartouche: old.run.binaryCartouche,
            numericBase: old.run.numericBase,
            openerCodepoint: old.run.openerCodepoint,
            closerCodepoint: old.run.closerCodepoint,
            canonicalCodepoints: old.run.canonicalCodepoints,
            renderCodepoints: old.run.renderCodepoints,
            renderText: old.run.renderText,
            renderAdapterId: old.run.renderAdapterId,
            sourceText: old.run.sourceText,
            sourceKind: old.run.sourceKind,
            sourceStart: old.run.sourceStart,
            sourceEnd: old.run.sourceEnd,
            manualTallies: old.run.manualTallies,
            tallyGroups: old.run.tallyGroups,
            quoted: old.run.quoted,
            interpretedQuote: true,
            unrecognized: old.run.unrecognized,
            imageAlt: old.run.imageAlt,
          ),
          old.graphic,
        );
      }
      out.add(_glyphLogical(
        source: 'to',
        codepoints: const <int>[closeQuoteCodepoint],
        start: math.max(segment.sourceStart + 1, segment.sourceEnd - 1),
        end: segment.sourceEnd,
        sourceKind: 'interpretedQuote',
        font: font,
        options: options,
        interpreted: true,
      ));
    } else {
      out.add(_literalLogical(
        source: segment.value,
        renderedText: q,
        start: segment.sourceStart,
        end: segment.sourceEnd,
        sourceKind: 'quote',
        font: font,
        options: options,
        quoted: true,
      ));
    }
  }

  _Prepared _prepare(String input, FullRenderOptions rawOptions) {
    final options = _normalizedOptions(rawOptions);
    final font = _font(options.font);
    final ast = parseFullDocument(input, options.parser);
    final logicalLines = <List<_Logical>>[];
    ParseResult? firstParsed;
    var anyAbbreviated = false;

    for (final line in ast.lines) {
      final runs = <_Logical>[];
      for (final segment in line.children) {
        switch (segment.kind) {
          case 'text':
            _parseText(
              text: segment.value,
              base: segment.sourceStart,
              kind: 'text',
              out: runs,
              font: font,
              options: options,
            );
            break;
          case 'bracket':
            _parseBracket(
              body: segment.value,
              sourceStart: segment.sourceStart,
              out: runs,
              font: font,
              options: options,
            );
            break;
          case 'quote':
            _parseQuote(
              segment: segment,
              out: runs,
              font: font,
              options: options,
            );
            break;
          case 'image':
            runs.add(_imageLogical(
              segment: segment,
              font: font,
              options: options,
            ));
            break;
        }
      }
      for (final logical in runs) {
        if (logical.run.numericCartouche) {
          final parsed = _numericParsed(logical.run.sourceText, options.parser);
          firstParsed ??= parsed?.parsed;
          anyAbbreviated = anyAbbreviated || options.parser.abbreviateNumericCartouches;
        }
      }
      logicalLines.add(runs);
    }

    final lineGap = options.layout.lineGap(options.fontSize);
    final pad = options.paddingPx.toDouble();
    final lineWidths = <double>[];
    final lineAscent = <double>[];
    final lineDescent = <double>[];
    var maxWidth = 0.0;
    for (final line in logicalLines) {
      var x = 0.0;
      var ascent = 0.0;
      var descent = 0.0;
      var first = true;
      for (final logical in line) {
        if (!first) {
          x += logical.run.fontRole == 'cartouche' || logical.run.numericCartouche
              ? options.layout.cartoucheLeadGap(options.fontSize)
              : options.layout.glyphGap(options.fontSize);
        }
        first = false;
        x += logical.graphic.width;
        ascent = math.max(ascent, logical.graphic.baseline);
        descent = math.max(
          descent,
          math.max(0, logical.graphic.height - logical.graphic.baseline),
        );
      }
      final h = math.max(options.fontSize, ascent + descent);
      if (line.isEmpty) {
        ascent = options.fontSize * .82;
        descent = h - ascent;
      }
      lineWidths.add(x);
      lineAscent.add(ascent);
      lineDescent.add(descent);
      maxWidth = math.max(maxWidth, x);
    }

    final width = math.max(1, (maxWidth + 2 * pad).ceil());
    var totalHeight = 2 * pad;
    for (var i = 0; i < logicalLines.length; i++) {
      totalHeight += math.max(
        options.fontSize,
        lineAscent[i] + lineDescent[i],
      );
    }
    totalHeight += lineGap * math.max(0, logicalLines.length - 1);
    final height = math.max(1, totalHeight.ceil());

    final allRuns = <FullRenderRun>[];
    final linePlans = <FullRenderLinePlan>[];
    final placed = <_Logical>[];
    var y = pad;
    for (var lineIndex = 0; lineIndex < logicalLines.length; lineIndex++) {
      final line = logicalLines[lineIndex];
      final lineWidth = lineWidths[lineIndex];
      final ascent = lineAscent[lineIndex];
      final descent = lineDescent[lineIndex];
      final lineHeight = math.max(options.fontSize, ascent + descent);
      var x = pad;
      switch (options.layout.align.toLowerCase()) {
        case 'center':
          x += (maxWidth - lineWidth) / 2;
          break;
        case 'right':
          x += maxWidth - lineWidth;
          break;
      }
      final lineStart = x;
      final lineRuns = <FullRenderRun>[];
      var first = true;
      for (var runIndex = 0; runIndex < line.length; runIndex++) {
        final logical = line[runIndex];
        if (!first) {
          x += logical.run.fontRole == 'cartouche' || logical.run.numericCartouche
              ? options.layout.cartoucheLeadGap(options.fontSize)
              : options.layout.glyphGap(options.fontSize);
        }
        first = false;
        final ty = y + ascent - logical.graphic.baseline;
        final tx = x;
        final groups = logical.graphic.tallyGroups
            .map((g) => g.shifted(tx, ty))
            .toList(growable: false);
        final run = logical.run.placed(
          id: 'L${lineIndex}R$runIndex',
          lineIndex: lineIndex,
          runIndex: runIndex,
          xPx: tx,
          yPx: ty,
          widthPx: logical.graphic.width,
          heightPx: logical.graphic.height,
          baselineYPx: y + ascent,
          tallyGroups: groups,
        );
        placed.add(_Logical(run, logical.graphic));
        allRuns.add(run);
        lineRuns.add(run);
        x += logical.graphic.width;
      }
      final sourceLine = ast.lines[lineIndex];
      linePlans.add(FullRenderLinePlan(
        lineIndex: lineIndex,
        sourceLineIndex: sourceLine.sourceLineIndex,
        sentenceIndexInSourceLine: sourceLine.sentenceIndexInSourceLine,
        xPx: lineStart,
        yPx: y,
        widthPx: lineWidth,
        heightPx: lineHeight,
        baselineYPx: y + ascent,
        ascentPx: ascent,
        descentPx: descent,
        runs: List<FullRenderRun>.unmodifiable(lineRuns),
      ));
      y += lineHeight;
      if (lineIndex + 1 < logicalLines.length) y += lineGap;
    }

    return _Prepared(
      FullRenderPlan(
        input: input,
        fontKey: font.key,
        abbreviated: anyAbbreviated,
        width: width,
        height: height,
        paddingPx: options.paddingPx,
        lineGapPx: lineGap,
        openTypeFeatures: fullOpenTypeFeaturesFor(options.fontSize),
        runs: List<FullRenderRun>.unmodifiable(allRuns),
        parsed: firstParsed,
        diagnostics: const <String>[],
        ast: ast,
        lines: List<FullRenderLinePlan>.unmodifiable(linePlans),
      ),
      List<_Logical>.unmodifiable(placed),
    );
  }

  FullRenderPlan buildRenderPlan(String input, [FullRenderOptions? options]) =>
      _prepare(input, options ?? const FullRenderOptions()).plan;

  NativeFullRenderedBytes _renderPrepared(
    _Prepared prepared,
    FullRenderOptions rawOptions,
    ProductionOutputFormat format,
  ) {
    final options = _normalizedOptions(rawOptions);
    final foreground = _parseHexColor(options.paint.fillStyle, ProductionRgba.black);
    final haloColor = _parseHexColor(
      options.paint.haloColor,
      const ProductionRgba(255, 255, 255, 255),
    );
    var haloWidth = options.paint.haloWidthPx;
    if (options.paint.haloEnabled && haloWidth <= 0) {
      haloWidth = math.max(
        2,
        math.min(24, (math.max(8, options.fontSize) * .10).round()),
      ).toDouble();
    }
    final operations = <NativeFullOp>[];
    for (final logical in prepared.placed) {
      final run = logical.run;
      final graphic = logical.graphic;
      if (graphic.imageBytes != null && graphic.imageBytes!.isNotEmpty) {
        operations.add(NativeFullImageOp(
          pngBytes: graphic.imageBytes!,
          x: run.xPx,
          y: run.yPx,
          width: graphic.width,
          height: graphic.height,
        ));
      } else {
        // Manual tally halos follow the browser reference: one rounded backing
        // per tally group is painted before the cartouche/text foreground. The
        // visible tally strokes are then painted on top with butt caps and no
        // per-line halo.
        if (options.paint.haloEnabled && haloWidth > 0) {
          final padX = haloWidth * .85;
          final padBottom = haloWidth * .85;
          final radius = math.max(
            1.25,
            math.min(haloWidth, options.fontSize * .045),
          ).toDouble();
          for (final group in run.tallyGroups) {
            if (group.strokeCentersPx.isEmpty) continue;
            final left = group.strokeCentersPx.first - group.strokeWidthPx / 2;
            final right = group.strokeCentersPx.last + group.strokeWidthPx / 2;
            operations.add(NativeFullRoundedRectOp(
              x: left - padX,
              y: group.topYPx,
              width: (right - left) + padX * 2,
              height: math.max(
                1,
                (group.bottomYPx - group.topYPx) + padBottom,
              ).toDouble(),
              radius: radius,
              color: haloColor,
            ));
          }
        }
        if (graphic.syntheticCornerCodepoint != null) {
          final cp = graphic.syntheticCornerCodepoint!;
          final stroke = math.max(2.5, options.fontSize * .065);
          final pad = stroke / 2;
          final left = run.xPx + pad;
          final right = run.xPx + graphic.width - pad;
          final top = run.yPx + pad;
          final bottom = run.yPx + graphic.height - pad;
          void line(double x1, double y1, double x2, double y2) {
            if (options.paint.haloEnabled && haloWidth > 0) {
              operations.add(NativeFullLineOp(
                x1: x1,
                y1: y1,
                x2: x2,
                y2: y2,
                width: stroke + haloWidth * 2,
                color: haloColor,
              ));
            }
            operations.add(NativeFullLineOp(
              x1: x1,
              y1: y1,
              x2: x2,
              y2: y2,
              width: stroke,
              color: foreground,
            ));
          }
          if (cp == openQuoteCodepoint) {
            line(left, bottom, left, top);
            line(left, top, right, top);
          } else {
            line(left, bottom, right, bottom);
            line(right, bottom, right, top);
          }
        } else if (graphic.text.isNotEmpty) {
          operations.add(NativeFullTextOp(
            text: graphic.text,
            family: graphic.family,
            fontPath: graphic.fontPath,
            fontSize: options.fontSize,
            features: graphic.features,
            x: run.xPx + graphic.originX,
            y: run.yPx + graphic.originY,
            color: foreground,
            halo: options.paint.haloEnabled,
            haloColor: haloColor,
            haloWidth: haloWidth,
          ));
        }
        for (final group in run.tallyGroups) {
          for (final center in group.strokeCentersPx) {
            operations.add(NativeFullLineOp(
              x1: center,
              y1: group.topYPx,
              x2: center,
              y2: group.bottomYPx,
              width: group.strokeWidthPx,
              color: foreground,
            ));
          }
        }
      }
      if (run.unrecognized && graphic.unknownDecoration) {
        operations.add(NativeFullRectOp(
          x: run.xPx,
          y: run.yPx,
          width: graphic.width,
          height: graphic.height,
          lineWidth: math.max(1, options.paint.unknownText.lineWidthPx),
          color: _parseHexColor(
            options.paint.unknownText.color,
            ProductionRgba.black,
          ),
        ));
      }
    }
    return renderFullNative(
      width: prepared.plan.width,
      height: prepared.plan.height,
      format: format,
      operations: operations,
    );
  }

  FullRenderResult render(
    String input, {
    ProductionOutputFormat format = ProductionOutputFormat.png,
    FullRenderOptions options = const FullRenderOptions(),
  }) {
    final prepared = _prepare(input, options);
    final native = _renderPrepared(prepared, options, format);
    return FullRenderResult(
      bytes: native.bytes,
      width: native.width,
      height: native.height,
      format: format.name,
      plan: prepared.plan,
    );
  }

  Uint8List renderToPng(String input, [FullRenderOptions? options]) => render(
        input,
        format: ProductionOutputFormat.png,
        options: options ?? const FullRenderOptions(),
      ).bytes;

  Uint8List renderToSvg(String input, [FullRenderOptions? options]) => render(
        input,
        format: ProductionOutputFormat.svg,
        options: options ?? const FullRenderOptions(),
      ).bytes;

  Uint8List renderToPdf(String input, [FullRenderOptions? options]) => render(
        input,
        format: ProductionOutputFormat.pdf,
        options: options ?? const FullRenderOptions(),
      ).bytes;

  FullCanvasResult renderToCanvas(String input, [FullRenderOptions? options]) {
    final opts = options ?? const FullRenderOptions();
    final prepared = _prepare(input, opts);
    final native = _renderPrepared(prepared, opts, ProductionOutputFormat.png);
    return FullCanvasResult(
      bytes: native.bytes,
      width: native.width,
      height: native.height,
      plan: opts.includePlan ? prepared.plan : null,
      fontKey: prepared.plan.fontKey,
    );
  }

  VectorDocument toVectorDocument(String input, [FullRenderOptions? options]) {
    final opts = options ?? const FullRenderOptions();
    final prepared = _prepare(input, opts);
    final elements = <VectorElement>[];
    for (final logical in prepared.placed) {
      final run = logical.run;
      final graphic = logical.graphic;
      if (graphic.imageHref.isNotEmpty) {
        elements.add(VectorElement(
          kind: 'image',
          runId: run.id,
          href: graphic.imageHref,
          x: run.xPx,
          y: run.yPx,
          width: graphic.width,
          height: graphic.height,
        ));
      } else if (graphic.syntheticCornerCodepoint != null) {
        final cp = graphic.syntheticCornerCodepoint!;
        final stroke = math.max(2.5, opts.fontSize * .065);
        final pad = stroke / 2;
        final left = run.xPx + pad;
        final right = run.xPx + graphic.width - pad;
        final top = run.yPx + pad;
        final bottom = run.yPx + graphic.height - pad;
        final path = cp == openQuoteCodepoint
            ? 'M ${left.toStringAsFixed(3)} ${bottom.toStringAsFixed(3)} L ${left.toStringAsFixed(3)} ${top.toStringAsFixed(3)} L ${right.toStringAsFixed(3)} ${top.toStringAsFixed(3)}'
            : 'M ${left.toStringAsFixed(3)} ${bottom.toStringAsFixed(3)} L ${right.toStringAsFixed(3)} ${bottom.toStringAsFixed(3)} L ${right.toStringAsFixed(3)} ${top.toStringAsFixed(3)}';
        elements.add(VectorElement(
          kind: 'path',
          runId: run.id,
          path: path,
          fill: opts.paint.fillStyle,
        ));
      } else if (graphic.text.isNotEmpty) {
        elements.add(VectorElement(
          kind: 'text',
          runId: run.id,
          text: graphic.text,
          fill: opts.paint.fillStyle,
          x: run.xPx + graphic.originX,
          y: run.yPx + graphic.originY,
          width: graphic.width,
          height: graphic.height,
        ));
      }
      for (final group in run.tallyGroups) {
        for (final center in group.strokeCentersPx) {
          elements.add(VectorElement(
            kind: 'path',
            runId: run.id,
            path: 'M ${center.toStringAsFixed(3)} '
                '${group.topYPx.toStringAsFixed(3)} L '
                '${center.toStringAsFixed(3)} '
                '${group.bottomYPx.toStringAsFixed(3)}',
            fill: opts.paint.fillStyle,
          ));
        }
      }
    }
    return VectorDocument(
      width: prepared.plan.width,
      height: prepared.plan.height,
      elements: List<VectorElement>.unmodifiable(elements),
      diagnostics: prepared.plan.diagnostics,
      plan: prepared.plan,
    );
  }

  FullCanvasResult renderRunToNewCanvas(
    FullRenderRun run, [
    FullRenderOptions? options,
  ]) {
    final opts = _normalizedOptions(options ?? const FullRenderOptions());
    final font = _font(opts.font);
    final rawBypass = parseRawUnicodeSequence(run.sourceText.trim()) != null;
    late _Graphic graphic;

    if (!rawBypass && _syntheticCorner(font, run.canonicalCodepoints)) {
      graphic = _syntheticCornerGraphic(
        run.canonicalCodepoints.first,
        opts.fontSize,
      );
    } else if (run.renderText.isNotEmpty) {
      String family;
      String path;
      List<String> features = const <String>[];
      var pad = 0;
      var bottomExtra = 0.0;
      switch (run.fontRole) {
        case 'number':
          family = font.nativeCompanionFamily;
          path = font.companionPath;
          features = fullOpenTypeFeaturesFor(opts.fontSize);
          pad = 6;
          break;
        case 'cartouche':
          family = _nativeBaseFamilies[font.key] ?? font.baseFamily;
          path = font.basePath;
          pad = 6;
          if (run.manualTallies.any((count) => count > 0)) {
            bottomExtra = (opts.fontSize * .34).ceilToDouble();
          }
          break;
        case 'literal':
        case 'unknown':
          final support = _literalTextFont();
          family = support?.family ?? (_nativeBaseFamilies[font.key] ?? font.baseFamily);
          path = support?.path ?? font.basePath;
          break;
        default:
          family = _nativeBaseFamilies[font.key] ?? font.baseFamily;
          path = font.basePath;
          break;
      }
      graphic = _measureGraphic(
        text: run.renderText,
        family: family,
        fontPath: path,
        fontSize: opts.fontSize,
        features: features,
        pad: pad,
        bottomExtra: bottomExtra,
        unknownDecoration: run.unrecognized,
      );
      if (run.unrecognized) {
        final unknownPad = math.max(0.0, opts.paint.unknownText.paddingPx);
        graphic = _Graphic(
          text: graphic.text,
          family: graphic.family,
          fontPath: graphic.fontPath,
          features: graphic.features,
          width: graphic.width + 2 * unknownPad,
          height: graphic.height + 2 * unknownPad,
          baseline: graphic.baseline + unknownPad,
          originX: graphic.originX + unknownPad,
          originY: graphic.originY + unknownPad,
          unknownDecoration: true,
        );
      }
    } else {
      final source = run.sourceText.isNotEmpty ? run.sourceText : run.renderText;
      return renderToCanvas(source, opts);
    }

    final x = opts.paddingPx.toDouble();
    final y = opts.paddingPx.toDouble();
    final shiftedGroups = run.tallyGroups
        .map((group) => group.shifted(x - run.xPx, y - run.yPx))
        .toList(growable: false);
    final placedRun = run.placed(
      id: run.id.isEmpty ? 'L0R0' : run.id,
      lineIndex: 0,
      runIndex: 0,
      xPx: x,
      yPx: y,
      widthPx: graphic.width,
      heightPx: graphic.height,
      baselineYPx: y + graphic.baseline,
      tallyGroups: shiftedGroups,
    );
    final width = math.max(1, (graphic.width + 2 * x).ceil());
    final height = math.max(1, (graphic.height + 2 * y).ceil());
    final source = run.sourceText.isNotEmpty ? run.sourceText : run.renderText;
    final ast = DocumentAst(
      normalizedInput: source,
      breakLinesAtFullStops: opts.parser.breakLinesAtFullStops,
      parserOptions: opts.parser,
      lines: <DocumentLine>[
        DocumentLine(
          index: 0,
          sourceLineIndex: 0,
          sentenceIndexInSourceLine: 0,
          sourceText: source,
          children: const <DocumentSegment>[],
        ),
      ],
    );
    final line = FullRenderLinePlan(
      lineIndex: 0,
      sourceLineIndex: 0,
      sentenceIndexInSourceLine: 0,
      xPx: x,
      yPx: y,
      widthPx: graphic.width,
      heightPx: graphic.height,
      baselineYPx: y + graphic.baseline,
      ascentPx: graphic.baseline,
      descentPx: math.max(0.0, graphic.height - graphic.baseline),
      runs: <FullRenderRun>[placedRun],
    );
    final plan = FullRenderPlan(
      input: source,
      fontKey: font.key,
      abbreviated: false,
      width: width,
      height: height,
      paddingPx: opts.paddingPx,
      lineGapPx: opts.layout.lineGap(opts.fontSize),
      openTypeFeatures: fullOpenTypeFeaturesFor(opts.fontSize),
      runs: <FullRenderRun>[placedRun],
      parsed: null,
      diagnostics: const <String>[],
      ast: ast,
      lines: <FullRenderLinePlan>[line],
    );
    final prepared = _Prepared(
      plan,
      <_Logical>[_Logical(placedRun, graphic)],
    );
    final native = _renderPrepared(prepared, opts, ProductionOutputFormat.png);
    return FullCanvasResult(
      bytes: native.bytes,
      width: native.width,
      height: native.height,
      plan: opts.includePlan ? plan : null,
      fontKey: font.key,
    );
  }

  FullCanvasResult renderTextToNewCanvas(
    String text, [
    FullRenderOptions? options,
  ]) =>
      renderToCanvas(text, options);

  FullCanvasResult renderTextToCanvas(
    String text, [
    FullRenderOptions? options,
  ]) =>
      renderToCanvas(text, options);

  String _ucsurSource(List<List<int>> lines) => lines
      .map((line) => line
          .map((cp) => 'U+${cp.toRadixString(16).toUpperCase().padLeft(4, '0')}')
          .join(' '))
      .join('\n');

  FullCanvasResult renderUcsurToNewCanvas(
    List<List<int>> lines, [
    FullRenderOptions? options,
  ]) =>
      renderToCanvas(_ucsurSource(lines), options);

  FullCanvasResult renderUcsurToCanvas(
    List<List<int>> lines, [
    FullRenderOptions? options,
  ]) =>
      renderToCanvas(_ucsurSource(lines), options);
}
