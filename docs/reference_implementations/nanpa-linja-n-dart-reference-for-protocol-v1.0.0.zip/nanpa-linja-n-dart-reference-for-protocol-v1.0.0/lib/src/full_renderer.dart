import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'constants.dart';
import 'api.dart' show tokenizeCaps;
import 'full_adapter.dart';
import 'full_document.dart';
import 'full_types.dart';
import 'model.dart';
import 'native_full_renderer.dart';
import 'native_production_renderer.dart'
    show ProductionOutputFormat, ProductionRgba;
import 'options.dart' show SemanticKind;
import 'parser.dart';
import 'production_font_adapters.dart';
import 'production_font_registry.dart';
import 'renderer.dart';

const Map<String, String> _nativeBaseFamilies = <String, String>{
  'nasinNanpa': 'nasin-nanpa',
  'sitelenSeliKiwen': 'sitelen seli kiwen juniko-latin-ligatures',
  'fairfaxHd': 'Fairfax HD',
  'fairfaxPonaHd': 'Fairfax Pona HD',
  'linjaPona': 'linja pona 4.9',
  'linjaSike': 'linja sike 5-cartouche-fix',
  'nasinSitelenPuMono': 'nasin-sitelen-pu',
  'linjaLipamanka': 'linja lipamanka-cartouche-fix',
};

final RegExp _integer = RegExp(r'^\+?[0-9]+$');
final RegExp _numericLike = RegExp(r'[0-9]');

ProductionRgba _parseHexColor(String value, ProductionRgba fallback) {
  var s = value.trim();
  if (!s.startsWith('#')) return fallback;
  s = s.substring(1);
  if (s.length == 3) {
    s = '${s[0]}${s[0]}${s[1]}${s[1]}${s[2]}${s[2]}';
  }
  if (s.length != 6) return fallback;
  final v = int.tryParse(s, radix: 16);
  if (v == null) return fallback;
  return ProductionRgba((v >> 16) & 0xff, (v >> 8) & 0xff, v & 0xff, 255);
}

FullRenderOptions _normalizedOptions(FullRenderOptions options) {
  final size = math.max(8.0, options.fontSize);
  return options.copyWith(
    font: options.font.trim().isEmpty ? defaultProductionFontKey : options.font,
    fontSize: size,
    paddingPx: options.paddingPx < 0 ? 0 : options.paddingPx,
  );
}

class _Graphic {
  final String text;
  final String family;
  final String fontPath;
  final List<String> features;
  final double width;
  final double height;
  final double baseline;
  final double originX;
  final double originY;
  final List<TallyGroup> tallyGroups;
  final Uint8List? imageBytes;
  final String imageHref;
  final bool unknownDecoration;

  const _Graphic({
    this.text = '',
    this.family = '',
    this.fontPath = '',
    this.features = const <String>[],
    required this.width,
    required this.height,
    required this.baseline,
    this.originX = 0,
    this.originY = 0,
    this.tallyGroups = const <TallyGroup>[],
    this.imageBytes,
    this.imageHref = '',
    this.unknownDecoration = false,
  });
}

class _Logical {
  final FullRenderRun run;
  final _Graphic graphic;
  const _Logical(this.run, this.graphic);
}

class _Prepared {
  final FullRenderPlan plan;
  final List<_Logical> placed;
  const _Prepared(this.plan, this.placed);
}

class DartFullRenderer {
  final ProductionFontRegistry registry;
  final Map<String, FullRenderAdapter> runtimeAdapters;

  DartFullRenderer(
    this.registry, [
    Map<String, FullRenderAdapter>? runtimeAdapters,
  ]) : runtimeAdapters = runtimeAdapters ?? <String, FullRenderAdapter>{};

  void registerRenderAdapter(String id, FullRenderAdapter adapter) {
    runtimeAdapters[id] = adapter;
  }

  FullRenderAdapter? getRenderAdapter(String id) => runtimeAdapters[id];

  FullRenderAdapter? removeRenderAdapter(String id) => runtimeAdapters.remove(id);

  ProductionFontInfo _font(String key) => registry.get(key);

  DocumentAst parseInput(String input, [FullRenderOptions? options]) =>
      parseFullDocument(input, (options ?? const FullRenderOptions()).parser);

  _Graphic _measureGraphic({
    required String text,
    required String family,
    required String fontPath,
    required double fontSize,
    List<String> features = const <String>[],
    int pad = 0,
    double bottomExtra = 0,
    bool unknownDecoration = false,
  }) {
    final m = measureFullTextNative(
      text: text.isEmpty ? ' ' : text,
      family: family,
      fontPath: fontPath,
      fontSize: fontSize,
      features: features,
    );
    return _Graphic(
      text: text,
      family: family,
      fontPath: fontPath,
      features: List<String>.unmodifiable(features),
      width: math.max(1, m.inkWidth + 2 * pad).toDouble(),
      height: math.max(1, m.inkHeight + 2 * pad + bottomExtra).toDouble(),
      baseline: m.baseline - m.inkY + pad,
      originX: pad - m.inkX.toDouble(),
      originY: pad - m.inkY.toDouble(),
      unknownDecoration: unknownDecoration,
    );
  }

  List<int> _runes(String text) => text.runes.toList(growable: false);

  RenderResult? _numericParsed(String source, FullParserOptions options) {
    try {
      return renderNumber(source, options.numericOptions());
    } catch (_) {
      return null;
    }
  }

  int? _capsDigit(String token) {
    var i = strictDigits.indexOf(token);
    if (i >= 0) return i;
    i = relaxedDigits.indexOf(token);
    return i >= 0 ? i : null;
  }

  String _numericStartWord(RenderResult rendered, FullParserOptions options) {
    final explicit = (options.numericCartoucheStartGlyph ?? '').toLowerCase();
    if (const <String>{'nanpa', 'nasa', 'noka', 'tenpo', 'suno', 'toki'}
        .contains(explicit)) {
      return explicit;
    }
    final semanticStart = rendered.parsed.semanticStartGlyph?.name;
    if (semanticStart != null && semanticStart.isNotEmpty) return semanticStart;
    if (options.nanpaColonRendering) {
      if (rendered.parsed.isDate ||
          rendered.parsed.semanticKind == SemanticKind.date) {
        return 'suno';
      }
      if (rendered.parsed.isTime ||
          rendered.parsed.semanticKind == SemanticKind.time) {
        return 'tenpo';
      }
    }
    return 'nanpa';
  }

  List<String> _replaceTraditionalTimeSeparators(List<String> words) {
    final out = <String>[];
    var i = 0;
    while (i < words.length) {
      if (i + 3 < words.length &&
          words[i] == 'nasa' &&
          words[i + 1] == 'e' &&
          words[i + 2] == 'kulupu' &&
          words[i + 3] == 'e') {
        out.addAll(const <String>['nasa', 'e', 'kasi', 'e']);
        i += 4;
      } else {
        out.add(words[i++]);
      }
    }
    return out;
  }

  /// Rebuilds the full decimal/date/time cartouche using the canonical
  /// JavaScript traditional-mode token rules.  The frozen Core-v1 parser is
  /// intentionally not changed: its historical public output is regression
  /// pinned.  Full Renderer Profile parity therefore belongs in this bridge.
  List<int>? _traditionalFullCodepoints(
    RenderResult rendered,
    FullParserOptions options,
  ) {
    if (rendered.abbreviated ||
        rendered.parsed.isHex ||
        rendered.parsed.isBinary) {
      return null;
    }
    final caps = rendered.parsed.caps;
    if (caps == null || caps.isEmpty) return null;

    List<String> tokens;
    try {
      tokens = tokenizeCaps(caps, options.numericOptions());
    } catch (_) {
      return null;
    }
    if (tokens.isEmpty) return null;

    var hasPercent = false;
    final filtered = <String>[];
    for (final token in tokens) {
      if (token == 'OK') {
        hasPercent = true;
      } else {
        filtered.add(token);
      }
    }

    final words = <String>[];
    var afterStartingNe = false;
    var afterScientificMarker = false;
    var i = 0;
    final startWord = _numericStartWord(rendered, options);

    while (i < filtered.length) {
      final token = filtered[i];

      if (token == 'NE') {
        final next = i + 1 < filtered.length ? filtered[i + 1] : null;
        if (next == 'KO') {
          if (words.isEmpty) {
            words.addAll(<String>[
              startWord,
              options.nanpaColonRendering ? ':' : 'esun',
              'kala',
              'open',
            ]);
          } else {
            words.addAll(const <String>['nasa', 'e', 'kala', 'open']);
          }
          afterStartingNe = false;
          afterScientificMarker = true;
          i += 2;
          continue;
        }
        afterScientificMarker = false;
        if (words.isEmpty) {
          words.addAll(<String>[
            startWord,
            options.nanpaColonRendering ? ':' : 'esun',
          ]);
          afterStartingNe = true;
        } else {
          words.addAll(const <String>['nasa', 'e']);
          afterStartingNe = false;
        }
        i++;
        continue;
      }

      if (token == 'NS') {
        words.addAll(const <String>['nena', 'en']);
        afterStartingNe = false;
        afterScientificMarker = false;
        i++;
        continue;
      }

      final digit = _capsDigit(token);
      if (digit != null) {
        afterStartingNe = false;
        afterScientificMarker = false;
        if (options.relaxedNanpaLinjanRendering) {
          switch (digit) {
            case 1:
              words.addAll(const <String>['wan', 'ala']);
              i++;
              continue;
            case 2:
              words.addAll(const <String>['tu', 'uta']);
              i++;
              continue;
            case 5:
              words.addAll(const <String>['luka', 'uta']);
              i++;
              continue;
            case 7:
              words.addAll(const <String>['mun', 'uta']);
              i++;
              continue;
            case 8:
              words.addAll(const <String>['pipi', 'ike']);
              i++;
              continue;
            case 9:
              words.addAll(const <String>['jo', 'open']);
              i++;
              continue;
          }
        }
        switch (digit) {
          case 0:
            words.addAll(const <String>['nasa', 'ijo']);
            break;
          case 1:
            words.addAll(const <String>['wan', 'esun']);
            break;
          case 2:
            words.addAll(const <String>['tu', 'esun']);
            break;
          case 3:
            words.addAll(const <String>['seli', 'esun']);
            break;
          case 4:
            words.addAll(const <String>['nasa', 'awen']);
            break;
          case 5:
            words.addAll(const <String>['luka', 'esun']);
            break;
          case 6:
            words.addAll(const <String>['nasa', 'utala']);
            break;
          case 7:
            words.addAll(const <String>['mun', 'esun']);
            break;
          case 8:
            words.addAll(const <String>['pipi', 'esun']);
            break;
          case 9:
            words.addAll(const <String>['jo', 'esun']);
            break;
        }
        i++;
        continue;
      }

      if (token == 'NO') {
        if (afterStartingNe || afterScientificMarker) {
          words.addAll(const <String>['nasa', 'ona']);
          afterStartingNe = false;
          afterScientificMarker = false;
          i++;
          continue;
        }
        final next = i + 1 < filtered.length ? filtered[i + 1] : null;
        if (next == 'NE') {
          words.addAll(const <String>['ni', 'o', 'nasa', 'e']);
          afterStartingNe = false;
          i += 2;
          continue;
        }
        words.addAll(const <String>['ni', 'o']);
        afterStartingNe = false;
        i++;
        continue;
      }

      if (token == 'NONO') {
        words.addAll(const <String>['nena', 'o', 'nena', 'o']);
        afterStartingNe = false;
        i++;
        continue;
      }
      if (token == 'NOKO') {
        words.addAll(const <String>['nena', 'open', 'kin', 'open']);
        afterStartingNe = false;
        i++;
        continue;
      }
      if (token == 'NONONO') {
        words.addAll(const <String>['nasa', 'o', 'nasa', 'o', 'nasa', 'o']);
        afterStartingNe = false;
        i++;
        continue;
      }
      if (token == 'KE' || token == 'KEKE' || token == 'KEKEKE') {
        final count = token.length ~/ 2;
        for (var n = 0; n < count; n++) {
          words.addAll(const <String>['kulupu', 'e']);
        }
        afterStartingNe = false;
        i++;
        continue;
      }
      if (token == 'N') {
        words.add('nanpa');
        afterStartingNe = false;
        i++;
        continue;
      }

      return null;
    }

    var finalWords = words;
    if (rendered.parsed.isTime || rendered.parsed.isDate) {
      finalWords = _replaceTraditionalTimeSeparators(finalWords);
    }
    if (hasPercent) {
      final suffix = const <String>['noka', 'open', 'kipisi', 'e'];
      final at = finalWords.lastIndexOf('nanpa');
      final mutable = List<String>.from(finalWords);
      if (at >= 0) {
        mutable.insertAll(at, suffix);
      } else {
        mutable.addAll(suffix);
      }
      finalWords = mutable;
    }

    final inner = <int>[];
    for (final word in finalWords) {
      final cp = allWordCodepoints[word] ?? wordCodepoints[word];
      if (cp == null) return null;
      inner.add(cp);
    }
    return <int>[cartoucheStart, ...inner, cartoucheEnd];
  }

  void _patchExplicitPositive(List<int> full, String source) {
    if (!source.trimLeft().startsWith('+')) return;
    final nena = allWordCodepoints['nena'];
    final e = allWordCodepoints['e'];
    final en = allWordCodepoints['en'];
    final colon = allWordCodepoints['kolon'] ?? allWordCodepoints[':'];
    if (nena == null || e == null || en == null) return;

    // Match the canonical JavaScript full-renderer rule by position.  An
    // explicit leading plus is the semantic marker `nena en` immediately
    // after the numeric opener + separator.  Do not search/replace arbitrary
    // `nena e` pairs later in the number: those may be legitimate digits or
    // separators and changing them would regress numeric semantics.
    final offset = full.isNotEmpty && full.first == cartoucheStart ? 1 : 0;
    final starts = <int>{
      if (allWordCodepoints['nanpa'] != null) allWordCodepoints['nanpa']!,
      if (allWordCodepoints['nasa'] != null) allWordCodepoints['nasa']!,
      if (allWordCodepoints['noka'] != null) allWordCodepoints['noka']!,
      if (allWordCodepoints['tenpo'] != null) allWordCodepoints['tenpo']!,
      if (allWordCodepoints['suno'] != null) allWordCodepoints['suno']!,
      if (allWordCodepoints['toki'] != null) allWordCodepoints['toki']!,
    };
    if (full.length >= offset + 4 &&
        starts.contains(full[offset]) &&
        (full[offset + 1] == e ||
            (colon != null && full[offset + 1] == colon))) {
      full[offset + 2] = nena;
      full[offset + 3] = en;
      return;
    }

    // Compatibility fallback for a legacy Core stream that contains the old
    // nena+e marker but lacks a recognized opening separator.
    for (var i = offset; i + 1 < full.length; i++) {
      if (full[i] == nena && full[i + 1] == e) {
        full[i + 1] = en;
        return;
      }
    }
  }

  void _patchMixedStyleLong(List<int> full, String source, FullParserOptions options) {
    if (options.mixedStyle != 'long' || !source.contains('+') || !source.contains('/')) {
      return;
    }
    final nena = allWordCodepoints['nena'];
    final open = allWordCodepoints['open'];
    final kin = allWordCodepoints['kin'];
    final o = allWordCodepoints['o'];
    if (nena == null || open == null || kin == null || o == null) return;
    for (var i = 0; i + 3 < full.length; i++) {
      if (full[i] == nena &&
          full[i + 1] == open &&
          full[i + 2] == kin &&
          full[i + 3] == open) {
        full.replaceRange(
          i,
          i + 4,
          <int>[nena, o, nena, o, nena, o],
        );
        return;
      }
    }
  }

  List<int> _numericActive(
    RenderResult rendered,
    String source,
    FullParserOptions options,
  ) {
    final traditional =
        options.numericMode == 'traditional' || options.mode == 'traditional';
    final corrected = traditional
        ? _traditionalFullCodepoints(rendered, options)
        : null;
    final full = List<int>.from(corrected ?? rendered.activeCodepoints);
    _patchExplicitPositive(full, source);
    _patchMixedStyleLong(full, source, options);
    return full;
  }

  _Logical _glyphLogical({
    required String source,
    required List<int> codepoints,
    required int start,
    required int end,
    required String sourceKind,
    required ProductionFontInfo font,
    required FullRenderOptions options,
    bool quoted = false,
    bool interpreted = false,
  }) {
    final canonical = List<int>.from(codepoints);
    var render = List<int>.from(canonical);
    final adapter = runtimeAdapters[font.renderAdapterId];
    if (adapter != null) {
      render = List<int>.from(adapter(render, font, options.fontSize));
    }
    final text = String.fromCharCodes(render);
    final family = _nativeBaseFamilies[font.key] ?? font.baseFamily;
    final graphic = _measureGraphic(
      text: text,
      family: family,
      fontPath: font.basePath,
      fontSize: options.fontSize,
    );
    final run = FullRenderRun(
      kind: canonical.length > 1 ? 'run' : 'glyph',
      renderMode: 'text',
      fontRole: 'word',
      canonicalCodepoints: List<int>.unmodifiable(canonical),
      renderCodepoints: List<int>.unmodifiable(render),
      renderText: text,
      renderAdapterId: font.renderAdapterId,
      sourceText: source,
      sourceKind: sourceKind,
      sourceStart: start,
      sourceEnd: end,
      quoted: quoted,
      interpretedQuote: interpreted,
    );
    return _Logical(run, graphic);
  }

  String _patrickHandPath(ProductionFontInfo font) {
    final sep = Platform.pathSeparator;
    final parent = File(font.basePath).absolute.parent.path;
    final path = '$parent${sep}PatrickHand-Regular.ttf';
    return File(path).existsSync() ? path : font.basePath;
  }

  _Logical _literalLogical({
    required String source,
    required int start,
    required int end,
    required String sourceKind,
    required ProductionFontInfo font,
    required FullRenderOptions options,
    bool quoted = false,
    bool interpreted = false,
    bool unknown = false,
  }) {
    final path = _patrickHandPath(font);
    var graphic = _measureGraphic(
      text: source.isEmpty ? ' ' : source,
      family: File(path).path.endsWith('PatrickHand-Regular.ttf')
          ? 'Patrick Hand'
          : (_nativeBaseFamilies[font.key] ?? font.baseFamily),
      fontPath: path,
      fontSize: options.fontSize,
      unknownDecoration: unknown,
    );
    if (unknown) {
      final pad = options.paint.unknownText.paddingPx < 0 ? 0 : options.paint.unknownText.paddingPx;
      graphic = _Graphic(
        text: graphic.text,
        family: graphic.family,
        fontPath: graphic.fontPath,
        features: graphic.features,
        width: graphic.width + 2 * pad,
        height: graphic.height + 2 * pad,
        baseline: graphic.baseline + pad,
        originX: graphic.originX + pad,
        originY: graphic.originY + pad,
        unknownDecoration: true,
      );
    }
    return _Logical(
      FullRenderRun(
        kind: 'text',
        renderMode: 'raster',
        fontRole: 'literal',
        renderText: source,
        renderAdapterId: font.renderAdapterId,
        sourceText: source,
        sourceKind: sourceKind,
        sourceStart: start,
        sourceEnd: end,
        quoted: quoted,
        interpretedQuote: interpreted,
        unrecognized: unknown,
      ),
      graphic,
    );
  }

  _Logical _numericLogical({
    required String source,
    required RenderResult rendered,
    required int start,
    required int end,
    required String sourceKind,
    required ProductionFontInfo font,
    required FullRenderOptions options,
  }) {
    final full = _numericActive(rendered, source, options.parser);
    final adapted = adaptProductionNumericCartouche(full, font.renderAdapterId);
    final features = fullOpenTypeFeaturesFor(options.fontSize);
    final graphic = _measureGraphic(
      text: adapted.text,
      family: font.nativeCompanionFamily,
      fontPath: font.companionPath,
      fontSize: options.fontSize,
      features: features,
      pad: 6,
    );
    final inner = full.length >= 2
        ? full.sublist(1, full.length - 1)
        : List<int>.from(full);
    final parsed = rendered.parsed;
    return _Logical(
      FullRenderRun(
        kind: 'cartouche',
        renderMode: 'raster',
        fontRole: 'number',
        numericCartouche: true,
        hexCartouche: parsed.isHex,
        binaryCartouche: parsed.isBinary,
        numericBase: parsed.numberBase ?? 10,
        openerCodepoint: inner.isEmpty ? null : inner.first,
        closerCodepoint: inner.isEmpty ? null : inner.last,
        canonicalCodepoints: List<int>.unmodifiable(inner),
        renderCodepoints: List<int>.unmodifiable(adapted.text.runes),
        renderText: adapted.text,
        renderAdapterId: font.renderAdapterId,
        sourceText: source,
        sourceKind: sourceKind,
        sourceStart: start,
        sourceEnd: end,
      ),
      graphic,
    );
  }

  int _byteIndexForRuneIndex(String text, int runeIndex) {
    if (runeIndex <= 0) return 0;
    final runes = text.runes.toList(growable: false);
    final end = math.min(runeIndex, runes.length);
    return utf8.encode(String.fromCharCodes(runes.sublist(0, end))).length;
  }

  _Logical _cartoucheLogical({
    required String source,
    required OrdinaryCartouche cartouche,
    required int start,
    required int end,
    required String sourceKind,
    required ProductionFontInfo font,
    required FullRenderOptions options,
  }) {
    final adapted = adaptOrdinaryCartouche(font, cartouche.inner);
    final family = _nativeBaseFamilies[font.key] ?? font.baseFamily;
    final extra = cartouche.hasManualTallies
        ? (options.fontSize * .34).ceilToDouble()
        : 0.0;
    var graphic = _measureGraphic(
      text: adapted.text,
      family: family,
      fontPath: font.basePath,
      fontSize: options.fontSize,
      pad: 6,
      bottomExtra: extra,
    );
    final groups = <TallyGroup>[];
    if (cartouche.hasManualTallies) {
      final bottom = graphic.height - extra - 6;
      final lift = manualTallyLift(font, options.parser, options.fontSize);
      final top = bottom - lift;
      final bot = top + options.fontSize * .10;
      final stroke = math.max(1.5, options.fontSize * .045);
      final gap = options.fontSize * .075;
      for (var i = 0; i < cartouche.manualTallies.length; i++) {
        final count = math.max(0, math.min(8, cartouche.manualTallies[i])).toInt();
        if (count == 0) continue;
        final span = adapted.canonicalSpans[i + 1];
        final left = graphic.originX +
            fullTextCaretXNative(
              text: adapted.text,
              family: family,
              fontPath: font.basePath,
              fontSize: options.fontSize,
              byteIndex: _byteIndexForRuneIndex(adapted.text, span[0]),
            );
        final right = graphic.originX +
            fullTextCaretXNative(
              text: adapted.text,
              family: family,
              fontPath: font.basePath,
              fontSize: options.fontSize,
              byteIndex: _byteIndexForRuneIndex(adapted.text, span[1]),
            );
        final center = (left + right) / 2;
        final total = count <= 1
            ? stroke
            : count * stroke + (count - 1) * gap;
        final first = center - total / 2 + stroke / 2;
        final centers = List<double>.generate(
          count,
          (k) => first + k * (stroke + gap),
          growable: false,
        );
        groups.add(TallyGroup(
          ownerIndex: i,
          count: count,
          ownerLeftPx: left,
          ownerRightPx: right,
          centerXPx: center,
          topYPx: top,
          bottomYPx: bot,
          strokeWidthPx: stroke,
          strokeCentersPx: centers,
        ));
      }
      graphic = _Graphic(
        text: graphic.text,
        family: graphic.family,
        fontPath: graphic.fontPath,
        features: graphic.features,
        width: graphic.width,
        height: graphic.height,
        baseline: graphic.baseline,
        originX: graphic.originX,
        originY: graphic.originY,
        tallyGroups: List<TallyGroup>.unmodifiable(groups),
      );
    }
    return _Logical(
      FullRenderRun(
        kind: 'cartouche',
        renderMode: 'raster',
        fontRole: 'cartouche',
        openerCodepoint: cartoucheStart,
        closerCodepoint: cartoucheEnd,
        canonicalCodepoints: List<int>.unmodifiable(cartouche.inner),
        renderCodepoints: List<int>.unmodifiable(adapted.text.runes),
        renderText: adapted.text,
        renderAdapterId: font.renderAdapterId,
        sourceText: source,
        sourceKind: sourceKind,
        sourceStart: start,
        sourceEnd: end,
        manualTallies: cartouche.hasManualTallies
            ? List<int>.unmodifiable(cartouche.manualTallies)
            : const <int>[],
      ),
      graphic,
    );
  }

  double _parseSize(String value, double base) {
    var s = value.trim().toLowerCase();
    if (s.isEmpty) return double.nan;
    var multiplier = 1.0;
    if (s.endsWith('em')) {
      multiplier = base;
      s = s.substring(0, s.length - 2);
    } else if (s.endsWith('px')) {
      s = s.substring(0, s.length - 2);
    }
    final parsed = double.tryParse(s);
    return parsed == null ? double.nan : parsed * multiplier;
  }

  List<double>? _pngDimensions(Uint8List bytes) {
    if (bytes.length < 24 ||
        bytes[0] != 0x89 ||
        bytes[1] != 0x50 ||
        bytes[2] != 0x4e ||
        bytes[3] != 0x47) {
      return null;
    }
    int u32(int at) =>
        (bytes[at] << 24) |
        (bytes[at + 1] << 16) |
        (bytes[at + 2] << 8) |
        bytes[at + 3];
    return <double>[u32(16).toDouble(), u32(20).toDouble()];
  }

  _Logical _imageLogical({
    required DocumentSegment segment,
    required ProductionFontInfo font,
    required FullRenderOptions options,
  }) {
    final descriptor = segment.image ?? const ImageDescriptor();
    Uint8List? raw;
    if (descriptor.src.startsWith('data:image/')) {
      raw = decodeDataImage(descriptor.src);
    } else if (descriptor.src.isNotEmpty) {
      try {
        raw = File(descriptor.src).readAsBytesSync();
      } catch (_) {
        raw = null;
      }
    }
    final dims = raw == null ? null : _pngDimensions(raw);
    var naturalW = dims?[0] ?? double.nan;
    var naturalH = dims?[1] ?? double.nan;
    var targetW = _parseSize(descriptor.width, options.fontSize);
    var targetH = _parseSize(descriptor.height, options.fontSize);
    if (targetW.isNaN && targetH.isNaN) targetH = options.fontSize;
    if (targetW.isNaN) {
      targetW = naturalW.isNaN || naturalH.isNaN || naturalH == 0
          ? targetH
          : targetH * naturalW / naturalH;
    }
    if (targetH.isNaN) {
      targetH = naturalW.isNaN || naturalH.isNaN || naturalW == 0
          ? targetW
          : targetW * naturalH / naturalW;
    }
    final baseline = descriptor.vAlign.toLowerCase() == 'center'
        ? targetH * .75
        : targetH;
    return _Logical(
      FullRenderRun(
        kind: 'cartouche',
        renderMode: 'raster',
        fontRole: 'cartouche',
        renderAdapterId: font.renderAdapterId,
        sourceKind: 'image',
        sourceStart: segment.sourceStart,
        sourceEnd: segment.sourceEnd,
        imageAlt: descriptor.alt,
      ),
      _Graphic(
        width: math.max(1, targetW),
        height: math.max(1, targetH),
        baseline: baseline,
        imageBytes: raw,
        imageHref: descriptor.src,
      ),
    );
  }

  void _emitCore({
    required String core,
    required int start,
    required int end,
    required String kind,
    required List<_Logical> out,
    required ProductionFontInfo font,
    required FullRenderOptions options,
  }) {
    if (allRunesUcsur(core)) {
      out.add(_glyphLogical(
        source: core,
        codepoints: _runes(core),
        start: start,
        end: end,
        sourceKind: kind,
        font: font,
        options: options,
      ));
      return;
    }

    final numeric = _numericParsed(core, options.parser);
    if (numeric != null) {
      if (options.parser.nasinNanpaPona && _integer.hasMatch(core)) {
        for (final word in nasinNanpaPonaWords(core.replaceFirst('+', ''))) {
          final cp = allWordCodepoints[word];
          if (cp != null) {
            out.add(_glyphLogical(
              source: core,
              codepoints: <int>[cp],
              start: start,
              end: end,
              sourceKind: kind,
              font: font,
              options: options,
            ));
          }
        }
      } else {
        out.add(_numericLogical(
          source: core,
          rendered: numeric,
          start: start,
          end: end,
          sourceKind: kind,
          font: font,
          options: options,
        ));
      }
      return;
    }

    final rendererMode = options.parser.effectiveRendererMode;
    if ((rendererMode == 'sitelen-pona-ascii-extended' ||
            rendererMode == 'sitelen-seli-kiwen') &&
        (core.contains('-') || core.contains('+'))) {
      final pieces = core.split(RegExp(r'([+-])'));
      // Dart split drops delimiters; recover them by scanning the original.
      final cps = <int>[];
      final token = StringBuffer();
      var ok = true;
      void flushToken() {
        if (!ok || token.isEmpty) return;
        final word = sanitizeRendererWord(token.toString());
        token.clear();
        final cp = allWordCodepoints[word];
        if (cp == null) {
          ok = false;
        } else {
          cps.add(cp);
        }
      }
      // Reference [pieces] so analyzer does not consider it accidental dead code.
      if (pieces.isNotEmpty) {
        for (final rune in core.runes) {
          final ch = String.fromCharCode(rune);
          if (ch == '-' || ch == '+') {
            flushToken();
            cps.add(ch == '-' ? stackJoinerCodepoint : nestJoinerCodepoint);
          } else {
            token.write(ch);
          }
        }
        flushToken();
      }
      if (ok && cps.isNotEmpty) {
        out.add(_glyphLogical(
          source: core,
          codepoints: cps,
          start: start,
          end: end,
          sourceKind: kind,
          font: font,
          options: options,
        ));
        return;
      }
    }

    if (options.parser.autoCartoucheStandaloneProperNames &&
        core.isNotEmpty &&
        RegExp(r'^[A-Z]').hasMatch(core)) {
      final cps = properNameCodepoints(core);
      if (cps != null && cps.isNotEmpty) {
        out.add(_cartoucheLogical(
          source: core,
          cartouche: OrdinaryCartouche(
            cps,
            List<int>.filled(cps.length, 0),
            'ucsur',
          ),
          start: start,
          end: end,
          sourceKind: kind,
          font: font,
          options: options,
        ));
        return;
      }
    }

    final cp = allWordCodepoints[sanitizeRendererWord(core)];
    if (cp != null) {
      out.add(_glyphLogical(
        source: core,
        codepoints: <int>[cp],
        start: start,
        end: end,
        sourceKind: kind,
        font: font,
        options: options,
      ));
      return;
    }

    if (options.parser.showUnknownText) {
      var literal = core;
      var literalStart = start;
      var literalEnd = end;
      if (rendererMode == 'standard-sitelen-pona-ascii-core' &&
          literal.length >= 2 &&
          literal.startsWith("'") &&
          literal.endsWith("'")) {
        literal = literal.substring(1, literal.length - 1);
        literalStart++;
        literalEnd--;
      }
      out.add(_literalLogical(
        source: literal,
        start: literalStart,
        end: literalEnd,
        sourceKind: kind,
        font: font,
        options: options,
        unknown: true,
      ));
    }
  }

  void _parseText({
    required String text,
    required int base,
    required String kind,
    required List<_Logical> out,
    required ProductionFontInfo font,
    required FullRenderOptions options,
  }) {
    if (text.isEmpty || text.trim().isEmpty) return;
    final trimmed = text.trim();
    final leading = text.indexOf(trimmed);
    final raw = parseRawUnicodeSequence(trimmed);
    if (raw != null) {
      out.add(_glyphLogical(
        source: trimmed,
        codepoints: raw,
        start: base + leading,
        end: base + leading + trimmed.length,
        sourceKind: kind,
        font: font,
        options: options,
      ));
      return;
    }

    final entireNumeric = _numericParsed(trimmed, options.parser);
    if (entireNumeric != null) {
      if (options.parser.nasinNanpaPona && _integer.hasMatch(trimmed)) {
        for (final word in nasinNanpaPonaWords(trimmed.replaceFirst('+', ''))) {
          final cp = allWordCodepoints[word];
          if (cp != null) {
            out.add(_glyphLogical(
              source: trimmed,
              codepoints: <int>[cp],
              start: base + leading,
              end: base + leading + trimmed.length,
              sourceKind: kind,
              font: font,
              options: options,
            ));
          }
        }
      } else {
        out.add(_numericLogical(
          source: trimmed,
          rendered: entireNumeric,
          start: base + leading,
          end: base + leading + trimmed.length,
          sourceKind: kind,
          font: font,
          options: options,
        ));
      }
      return;
    }

    for (final match in RegExp(r'\S+').allMatches(text)) {
      final token = match.group(0)!;
      var start = base + match.start;
      var end = base + match.end;
      var core = token;
      while (core.startsWith('(') || core.startsWith('{')) {
        core = core.substring(1);
        start++;
      }
      var trail = '';
      while (core.isNotEmpty && ').;:!?}'.contains(core[core.length - 1])) {
        final c = core[core.length - 1];
        if (c == '.' && _numericLike.hasMatch(core)) break;
        trail = '$c$trail';
        core = core.substring(0, core.length - 1);
        end--;
      }
      if (core.endsWith('.') &&
          core.length > 1 &&
          _numericLike.hasMatch(core.substring(0, core.length - 1))) {
        trail = '.$trail';
        core = core.substring(0, core.length - 1);
        end--;
      }
      if (core.isNotEmpty) {
        _emitCore(
          core: core,
          start: start,
          end: end,
          kind: kind,
          out: out,
          font: font,
          options: options,
        );
      }
      for (var j = 0; j < trail.length; j++) {
        final c = trail[j];
        final cp = c == '.'
            ? middleDotCodepoint
            : (c == ':' ? colonCodepoint : null);
        if (cp != null) {
          out.add(_glyphLogical(
            source: c,
            codepoints: <int>[cp],
            start: end + j,
            end: end + j + 1,
            sourceKind: kind,
            font: font,
            options: options,
          ));
        }
      }
    }
  }

  void _parseBracket({
    required String body,
    required int sourceStart,
    required List<_Logical> out,
    required ProductionFontInfo font,
    required FullRenderOptions options,
  }) {
    final trimmed = body.trim();
    final numeric = _numericParsed('[$trimmed]', options.parser);
    if (numeric != null) {
      out.add(_numericLogical(
        source: trimmed,
        rendered: numeric,
        start: sourceStart,
        end: sourceStart + body.length,
        sourceKind: 'bracket',
        font: font,
        options: options,
      ));
      return;
    }
    final ordinary = parseOrdinaryCartoucheBody(trimmed, font, options.parser);
    if (ordinary != null) {
      out.add(_cartoucheLogical(
        source: trimmed,
        cartouche: ordinary,
        start: sourceStart,
        end: sourceStart + body.length,
        sourceKind: 'bracket',
        font: font,
        options: options,
      ));
    } else if (options.parser.showUnknownText) {
      out.add(_literalLogical(
        source: trimmed,
        start: sourceStart,
        end: sourceStart + body.length,
        sourceKind: 'bracket',
        font: font,
        options: options,
        unknown: true,
      ));
    }
  }

  void _parseQuote({
    required DocumentSegment segment,
    required List<_Logical> out,
    required ProductionFontInfo font,
    required FullRenderOptions options,
  }) {
    final q = segment.value
        .replaceAll(r'\"', '"')
        .replaceAll(r'\\', '\\')
        .replaceAll(r'\t', '    ')
        .replaceAll(r'\n', '\n');
    if (options.parser.interpretDoubleQuotesAsTeTo) {
      out.add(_glyphLogical(
        source: 'te',
        codepoints: const <int>[openQuoteCodepoint],
        start: segment.sourceStart,
        end: segment.sourceStart + 1,
        sourceKind: 'interpretedQuote',
        font: font,
        options: options,
        interpreted: true,
      ));
      final before = out.length;
      _parseText(
        text: q,
        base: segment.sourceStart + 1,
        kind: 'interpretedQuote',
        out: out,
        font: font,
        options: options,
      );
      for (var i = before; i < out.length; i++) {
        final old = out[i];
        out[i] = _Logical(
          FullRenderRun(
            id: old.run.id,
            lineIndex: old.run.lineIndex,
            runIndex: old.run.runIndex,
            kind: old.run.kind,
            renderMode: old.run.renderMode,
            fontRole: old.run.fontRole,
            numericCartouche: old.run.numericCartouche,
            hexCartouche: old.run.hexCartouche,
            binaryCartouche: old.run.binaryCartouche,
            numericBase: old.run.numericBase,
            openerCodepoint: old.run.openerCodepoint,
            closerCodepoint: old.run.closerCodepoint,
            canonicalCodepoints: old.run.canonicalCodepoints,
            renderCodepoints: old.run.renderCodepoints,
            renderText: old.run.renderText,
            renderAdapterId: old.run.renderAdapterId,
            sourceText: old.run.sourceText,
            sourceKind: old.run.sourceKind,
            sourceStart: old.run.sourceStart,
            sourceEnd: old.run.sourceEnd,
            manualTallies: old.run.manualTallies,
            tallyGroups: old.run.tallyGroups,
            quoted: old.run.quoted,
            interpretedQuote: true,
            unrecognized: old.run.unrecognized,
            imageAlt: old.run.imageAlt,
          ),
          old.graphic,
        );
      }
      out.add(_glyphLogical(
        source: 'to',
        codepoints: const <int>[closeQuoteCodepoint],
        start: math.max(segment.sourceStart + 1, segment.sourceEnd - 1),
        end: segment.sourceEnd,
        sourceKind: 'interpretedQuote',
        font: font,
        options: options,
        interpreted: true,
      ));
    } else {
      out.add(_literalLogical(
        source: q,
        start: segment.sourceStart,
        end: segment.sourceEnd,
        sourceKind: 'quote',
        font: font,
        options: options,
        quoted: true,
      ));
    }
  }

  _Prepared _prepare(String input, FullRenderOptions rawOptions) {
    final options = _normalizedOptions(rawOptions);
    final font = _font(options.font);
    final ast = parseFullDocument(input, options.parser);
    final logicalLines = <List<_Logical>>[];
    ParseResult? firstParsed;
    var anyAbbreviated = false;

    for (final line in ast.lines) {
      final runs = <_Logical>[];
      for (final segment in line.children) {
        switch (segment.kind) {
          case 'text':
            _parseText(
              text: segment.value,
              base: segment.sourceStart,
              kind: 'text',
              out: runs,
              font: font,
              options: options,
            );
            break;
          case 'bracket':
            _parseBracket(
              body: segment.value,
              sourceStart: segment.sourceStart,
              out: runs,
              font: font,
              options: options,
            );
            break;
          case 'quote':
            _parseQuote(
              segment: segment,
              out: runs,
              font: font,
              options: options,
            );
            break;
          case 'image':
            runs.add(_imageLogical(
              segment: segment,
              font: font,
              options: options,
            ));
            break;
        }
      }
      for (final logical in runs) {
        if (logical.run.numericCartouche) {
          final parsed = _numericParsed(logical.run.sourceText, options.parser);
          firstParsed ??= parsed?.parsed;
          anyAbbreviated = anyAbbreviated || options.parser.abbreviateNumericCartouches;
        }
      }
      logicalLines.add(runs);
    }

    final lineGap = options.layout.lineGap(options.fontSize);
    final pad = options.paddingPx.toDouble();
    final lineWidths = <double>[];
    final lineAscent = <double>[];
    final lineDescent = <double>[];
    var maxWidth = 0.0;
    for (final line in logicalLines) {
      var x = 0.0;
      var ascent = 0.0;
      var descent = 0.0;
      var first = true;
      for (final logical in line) {
        if (!first) {
          x += logical.run.fontRole == 'cartouche' || logical.run.numericCartouche
              ? options.layout.cartoucheLeadGap(options.fontSize)
              : options.layout.glyphGap(options.fontSize);
        }
        first = false;
        x += logical.graphic.width;
        ascent = math.max(ascent, logical.graphic.baseline);
        descent = math.max(
          descent,
          math.max(0, logical.graphic.height - logical.graphic.baseline),
        );
      }
      final h = math.max(options.fontSize, ascent + descent);
      if (line.isEmpty) {
        ascent = options.fontSize * .82;
        descent = h - ascent;
      }
      lineWidths.add(x);
      lineAscent.add(ascent);
      lineDescent.add(descent);
      maxWidth = math.max(maxWidth, x);
    }

    final width = math.max(1, (maxWidth + 2 * pad).ceil());
    var totalHeight = 2 * pad;
    for (var i = 0; i < logicalLines.length; i++) {
      totalHeight += math.max(
        options.fontSize,
        lineAscent[i] + lineDescent[i],
      );
    }
    totalHeight += lineGap * math.max(0, logicalLines.length - 1);
    final height = math.max(1, totalHeight.ceil());

    final allRuns = <FullRenderRun>[];
    final linePlans = <FullRenderLinePlan>[];
    final placed = <_Logical>[];
    var y = pad;
    for (var lineIndex = 0; lineIndex < logicalLines.length; lineIndex++) {
      final line = logicalLines[lineIndex];
      final lineWidth = lineWidths[lineIndex];
      final ascent = lineAscent[lineIndex];
      final descent = lineDescent[lineIndex];
      final lineHeight = math.max(options.fontSize, ascent + descent);
      var x = pad;
      switch (options.layout.align.toLowerCase()) {
        case 'center':
          x += (maxWidth - lineWidth) / 2;
          break;
        case 'right':
          x += maxWidth - lineWidth;
          break;
      }
      final lineStart = x;
      final lineRuns = <FullRenderRun>[];
      var first = true;
      for (var runIndex = 0; runIndex < line.length; runIndex++) {
        final logical = line[runIndex];
        if (!first) {
          x += logical.run.fontRole == 'cartouche' || logical.run.numericCartouche
              ? options.layout.cartoucheLeadGap(options.fontSize)
              : options.layout.glyphGap(options.fontSize);
        }
        first = false;
        final ty = y + ascent - logical.graphic.baseline;
        final tx = x;
        final groups = logical.graphic.tallyGroups
            .map((g) => g.shifted(tx, ty))
            .toList(growable: false);
        final run = logical.run.placed(
          id: 'L${lineIndex}R$runIndex',
          lineIndex: lineIndex,
          runIndex: runIndex,
          xPx: tx,
          yPx: ty,
          widthPx: logical.graphic.width,
          heightPx: logical.graphic.height,
          baselineYPx: y + ascent,
          tallyGroups: groups,
        );
        placed.add(_Logical(run, logical.graphic));
        allRuns.add(run);
        lineRuns.add(run);
        x += logical.graphic.width;
      }
      final sourceLine = ast.lines[lineIndex];
      linePlans.add(FullRenderLinePlan(
        lineIndex: lineIndex,
        sourceLineIndex: sourceLine.sourceLineIndex,
        sentenceIndexInSourceLine: sourceLine.sentenceIndexInSourceLine,
        xPx: lineStart,
        yPx: y,
        widthPx: lineWidth,
        heightPx: lineHeight,
        baselineYPx: y + ascent,
        ascentPx: ascent,
        descentPx: descent,
        runs: List<FullRenderRun>.unmodifiable(lineRuns),
      ));
      y += lineHeight;
      if (lineIndex + 1 < logicalLines.length) y += lineGap;
    }

    return _Prepared(
      FullRenderPlan(
        input: input,
        fontKey: font.key,
        abbreviated: anyAbbreviated,
        width: width,
        height: height,
        paddingPx: options.paddingPx,
        lineGapPx: lineGap,
        openTypeFeatures: fullOpenTypeFeaturesFor(options.fontSize),
        runs: List<FullRenderRun>.unmodifiable(allRuns),
        parsed: firstParsed,
        diagnostics: const <String>[],
        ast: ast,
        lines: List<FullRenderLinePlan>.unmodifiable(linePlans),
      ),
      List<_Logical>.unmodifiable(placed),
    );
  }

  FullRenderPlan buildRenderPlan(String input, [FullRenderOptions? options]) =>
      _prepare(input, options ?? const FullRenderOptions()).plan;

  NativeFullRenderedBytes _renderPrepared(
    _Prepared prepared,
    FullRenderOptions rawOptions,
    ProductionOutputFormat format,
  ) {
    final options = _normalizedOptions(rawOptions);
    final foreground = _parseHexColor(options.paint.fillStyle, ProductionRgba.black);
    final haloColor = _parseHexColor(
      options.paint.haloColor,
      const ProductionRgba(255, 255, 255, 255),
    );
    var haloWidth = options.paint.haloWidthPx;
    if (options.paint.haloEnabled && haloWidth <= 0) {
      haloWidth = math.max(
        2,
        math.min(24, (math.max(8, options.fontSize) * .10).round()),
      ).toDouble();
    }
    final operations = <NativeFullOp>[];
    for (final logical in prepared.placed) {
      final run = logical.run;
      final graphic = logical.graphic;
      if (graphic.imageBytes != null && graphic.imageBytes!.isNotEmpty) {
        operations.add(NativeFullImageOp(
          pngBytes: graphic.imageBytes!,
          x: run.xPx,
          y: run.yPx,
          width: graphic.width,
          height: graphic.height,
        ));
      } else {
        // Manual tally halos follow the browser reference: one rounded backing
        // per tally group is painted before the cartouche/text foreground. The
        // visible tally strokes are then painted on top with butt caps and no
        // per-line halo.
        if (options.paint.haloEnabled && haloWidth > 0) {
          final padX = haloWidth * .85;
          final padBottom = haloWidth * .85;
          final radius = math.max(
            1.25,
            math.min(haloWidth, options.fontSize * .045),
          ).toDouble();
          for (final group in run.tallyGroups) {
            if (group.strokeCentersPx.isEmpty) continue;
            final left = group.strokeCentersPx.first - group.strokeWidthPx / 2;
            final right = group.strokeCentersPx.last + group.strokeWidthPx / 2;
            operations.add(NativeFullRoundedRectOp(
              x: left - padX,
              y: group.topYPx,
              width: (right - left) + padX * 2,
              height: math.max(
                1,
                (group.bottomYPx - group.topYPx) + padBottom,
              ).toDouble(),
              radius: radius,
              color: haloColor,
            ));
          }
        }
        if (graphic.text.isNotEmpty) {
          operations.add(NativeFullTextOp(
            text: graphic.text,
            family: graphic.family,
            fontPath: graphic.fontPath,
            fontSize: options.fontSize,
            features: graphic.features,
            x: run.xPx + graphic.originX,
            y: run.yPx + graphic.originY,
            color: foreground,
            halo: options.paint.haloEnabled,
            haloColor: haloColor,
            haloWidth: haloWidth,
          ));
        }
        for (final group in run.tallyGroups) {
          for (final center in group.strokeCentersPx) {
            operations.add(NativeFullLineOp(
              x1: center,
              y1: group.topYPx,
              x2: center,
              y2: group.bottomYPx,
              width: group.strokeWidthPx,
              color: foreground,
            ));
          }
        }
      }
      if (run.unrecognized && graphic.unknownDecoration) {
        operations.add(NativeFullRectOp(
          x: run.xPx,
          y: run.yPx,
          width: graphic.width,
          height: graphic.height,
          lineWidth: math.max(1, options.paint.unknownText.lineWidthPx),
          color: _parseHexColor(
            options.paint.unknownText.color,
            ProductionRgba.black,
          ),
        ));
      }
    }
    return renderFullNative(
      width: prepared.plan.width,
      height: prepared.plan.height,
      format: format,
      operations: operations,
    );
  }

  FullRenderResult render(
    String input, {
    ProductionOutputFormat format = ProductionOutputFormat.png,
    FullRenderOptions options = const FullRenderOptions(),
  }) {
    final prepared = _prepare(input, options);
    final native = _renderPrepared(prepared, options, format);
    return FullRenderResult(
      bytes: native.bytes,
      width: native.width,
      height: native.height,
      format: format.name,
      plan: prepared.plan,
    );
  }

  Uint8List renderToPng(String input, [FullRenderOptions? options]) => render(
        input,
        format: ProductionOutputFormat.png,
        options: options ?? const FullRenderOptions(),
      ).bytes;

  Uint8List renderToSvg(String input, [FullRenderOptions? options]) => render(
        input,
        format: ProductionOutputFormat.svg,
        options: options ?? const FullRenderOptions(),
      ).bytes;

  Uint8List renderToPdf(String input, [FullRenderOptions? options]) => render(
        input,
        format: ProductionOutputFormat.pdf,
        options: options ?? const FullRenderOptions(),
      ).bytes;

  FullCanvasResult renderToCanvas(String input, [FullRenderOptions? options]) {
    final opts = options ?? const FullRenderOptions();
    final prepared = _prepare(input, opts);
    final native = _renderPrepared(prepared, opts, ProductionOutputFormat.png);
    return FullCanvasResult(
      bytes: native.bytes,
      width: native.width,
      height: native.height,
      plan: opts.includePlan ? prepared.plan : null,
      fontKey: prepared.plan.fontKey,
    );
  }

  VectorDocument toVectorDocument(String input, [FullRenderOptions? options]) {
    final opts = options ?? const FullRenderOptions();
    final prepared = _prepare(input, opts);
    final elements = <VectorElement>[];
    for (final logical in prepared.placed) {
      final run = logical.run;
      final graphic = logical.graphic;
      if (graphic.imageHref.isNotEmpty) {
        elements.add(VectorElement(
          kind: 'image',
          runId: run.id,
          href: graphic.imageHref,
          x: run.xPx,
          y: run.yPx,
          width: graphic.width,
          height: graphic.height,
        ));
      } else if (graphic.text.isNotEmpty) {
        elements.add(VectorElement(
          kind: 'text',
          runId: run.id,
          text: graphic.text,
          fill: opts.paint.fillStyle,
          x: run.xPx + graphic.originX,
          y: run.yPx + graphic.originY,
          width: graphic.width,
          height: graphic.height,
        ));
      }
      for (final group in run.tallyGroups) {
        for (final center in group.strokeCentersPx) {
          elements.add(VectorElement(
            kind: 'path',
            runId: run.id,
            path: 'M ${center.toStringAsFixed(3)} '
                '${group.topYPx.toStringAsFixed(3)} L '
                '${center.toStringAsFixed(3)} '
                '${group.bottomYPx.toStringAsFixed(3)}',
            fill: opts.paint.fillStyle,
          ));
        }
      }
    }
    return VectorDocument(
      width: prepared.plan.width,
      height: prepared.plan.height,
      elements: List<VectorElement>.unmodifiable(elements),
      diagnostics: prepared.plan.diagnostics,
      plan: prepared.plan,
    );
  }

  FullCanvasResult renderRunToNewCanvas(
    FullRenderRun run, [
    FullRenderOptions? options,
  ]) {
    final opts = options ?? const FullRenderOptions();
    if (run.sourceText.isNotEmpty) return renderToCanvas(run.sourceText, opts);
    return renderToCanvas(run.renderText, opts);
  }

  FullCanvasResult renderTextToNewCanvas(
    String text, [
    FullRenderOptions? options,
  ]) =>
      renderToCanvas(text, options);

  FullCanvasResult renderTextToCanvas(
    String text, [
    FullRenderOptions? options,
  ]) =>
      renderToCanvas(text, options);

  String _ucsurSource(List<List<int>> lines) => lines
      .map((line) => line
          .map((cp) => 'U+${cp.toRadixString(16).toUpperCase().padLeft(4, '0')}')
          .join(' '))
      .join('\n');

  FullCanvasResult renderUcsurToNewCanvas(
    List<List<int>> lines, [
    FullRenderOptions? options,
  ]) =>
      renderToCanvas(_ucsurSource(lines), options);

  FullCanvasResult renderUcsurToCanvas(
    List<List<int>> lines, [
    FullRenderOptions? options,
  ]) =>
      renderToCanvas(_ucsurSource(lines), options);
}
