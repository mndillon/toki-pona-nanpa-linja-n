import 'dart:math' as math;
import 'dart:typed_data';

import 'model.dart';
import 'options.dart';
import 'production_font_registry.dart';

const int tallyCodepoint = 0xF199E;
const int middleDotCodepoint = 0xF199C;
const int colonCodepoint = 0xF199D;
const int stackJoinerCodepoint = 0xF1995;
const int nestJoinerCodepoint = 0xF1996;
const int openQuoteCodepoint = 0x300C;
const int closeQuoteCodepoint = 0x300D;

class FullParserOptions {
  final bool enableBinaryParsing;
  final bool enableHexParsing;
  final String mode;
  final String numericMode;
  final bool nanpaColonParsing;
  final bool nanpaColonRendering;
  final bool relaxedNanpaLinjanParsing;
  final bool relaxedNanpaLinjanRendering;
  final bool abbreviateNumericCartouches;
  final bool preserveNumericCartoucheBreaks;
  final String? numericCartoucheStartGlyph;
  final String rendererMode;
  final String mixedStyle;
  final bool breakLinesAtFullStops;
  final bool showUnknownText;
  final bool autoCartoucheStandaloneProperNames;
  final bool interpretDoubleQuotesAsTeTo;
  final bool cartoucheCommaTallyMarks;
  final bool? commaTallyMarks;
  final String cartoucheTallyMode;
  final double? manualTallySmallFontLiftPx;
  final double? manualTallySmallFontMaxPx;
  final bool nasinNanpaPona;

  const FullParserOptions({
    this.enableBinaryParsing = true,
    this.enableHexParsing = true,
    this.mode = 'uniform',
    this.numericMode = 'uniform',
    this.nanpaColonParsing = true,
    this.nanpaColonRendering = true,
    this.relaxedNanpaLinjanParsing = true,
    this.relaxedNanpaLinjanRendering = true,
    this.abbreviateNumericCartouches = false,
    this.preserveNumericCartoucheBreaks = false,
    this.numericCartoucheStartGlyph,
    this.rendererMode = 'sitelen-pona-ascii-extended',
    this.mixedStyle = 'short',
    this.breakLinesAtFullStops = false,
    this.showUnknownText = false,
    this.autoCartoucheStandaloneProperNames = true,
    this.interpretDoubleQuotesAsTeTo = false,
    this.cartoucheCommaTallyMarks = true,
    this.commaTallyMarks,
    this.cartoucheTallyMode = '',
    this.manualTallySmallFontLiftPx,
    this.manualTallySmallFontMaxPx,
    this.nasinNanpaPona = false,
  });

  factory FullParserOptions.fromMap(Map<String, dynamic>? raw) {
    final j = raw ?? const <String, dynamic>{};
    bool b(String key, bool fallback) =>
        j[key] is bool ? j[key] as bool : fallback;
    double? d(String key) => j[key] is num ? (j[key] as num).toDouble() : null;
    final rawMode = '${j['mode'] ?? 'uniform'}';
    final numeric = '${j['numericMode'] ?? ((rawMode == 'traditional' || rawMode == 'uniform') ? rawMode : 'uniform')}';
    final renderer = <String>{
      'standard-sitelen-pona-ascii-core',
      'sitelen-pona-ascii-extended',
      'sitelen-seli-kiwen',
    }.contains(rawMode)
        ? rawMode
        : '${j['rendererMode'] ?? 'sitelen-pona-ascii-extended'}';
    return FullParserOptions(
      enableBinaryParsing: b('enableBinaryParsing', true),
      enableHexParsing: b('enableHexParsing', true),
      mode: rawMode,
      numericMode: numeric,
      nanpaColonParsing: b('nanpaColonParsing', true),
      nanpaColonRendering: b('nanpaColonRendering', true),
      relaxedNanpaLinjanParsing: b('relaxedNanpaLinjanParsing', true),
      relaxedNanpaLinjanRendering: b('relaxedNanpaLinjanRendering', true),
      abbreviateNumericCartouches:
          b('abbreviateNumericCartouches', false) ||
              b('numericCartoucheAbbreviation', false) ||
              b('abbreviatedNumericCartouches', false),
      preserveNumericCartoucheBreaks:
          b('preserveNumericCartoucheBreaksInAbbreviation', false) ||
              b('preserveNumericCartoucheBreaks', false) ||
              b('abbreviatedNumericCartoucheBreakAsEn', false),
      numericCartoucheStartGlyph: j['numericCartoucheStartGlyph'] == null
          ? null
          : '${j['numericCartoucheStartGlyph']}',
      rendererMode: renderer,
      mixedStyle: '${j['mixedStyle'] ?? 'short'}',
      breakLinesAtFullStops: b('breakLinesAtFullStops', false),
      showUnknownText: b('showUnknownText', false),
      autoCartoucheStandaloneProperNames:
          b('autoCartoucheStandaloneProperNames', true),
      interpretDoubleQuotesAsTeTo: b('interpretDoubleQuotesAsTeTo', false),
      cartoucheCommaTallyMarks: b('cartoucheCommaTallyMarks', true),
      commaTallyMarks:
          j['commaTallyMarks'] is bool ? j['commaTallyMarks'] as bool : null,
      cartoucheTallyMode: '${j['cartoucheTallyMode'] ?? ''}',
      manualTallySmallFontLiftPx: d('manualTallySmallFontLiftPx'),
      manualTallySmallFontMaxPx: d('manualTallySmallFontMaxPx'),
      nasinNanpaPona: b('nasinNanpaPona', false),
    );
  }

  bool get effectiveCommaTallyMarks =>
      commaTallyMarks ?? cartoucheCommaTallyMarks;

  String get effectiveRendererMode {
    if (<String>{
      'standard-sitelen-pona-ascii-core',
      'sitelen-pona-ascii-extended',
      'sitelen-seli-kiwen',
    }.contains(mode)) {
      return mode;
    }
    return rendererMode;
  }

  ParseOptions numericOptions() {
    final traditional = numericMode == 'traditional' || mode == 'traditional';
    DecimalStartGlyph? start;
    switch ((numericCartoucheStartGlyph ?? '').toLowerCase()) {
      case 'nanpa':
        start = DecimalStartGlyph.nanpa;
        break;
      case 'tenpo':
        start = DecimalStartGlyph.tenpo;
        break;
      case 'suno':
        start = DecimalStartGlyph.suno;
        break;
      case 'toki':
        start = DecimalStartGlyph.toki;
        break;
    }
    return ParseOptions(
      enableBinaryParsing: enableBinaryParsing,
      enableHexParsing: enableHexParsing,
      mode: traditional ? NumericMode.traditional : NumericMode.uniform,
      numericMode: traditional ? NumericMode.traditional : NumericMode.uniform,
      nanpaColonParsing: nanpaColonParsing,
      nanpaColonRendering: nanpaColonRendering,
      relaxedNanpaLinjanParsing: relaxedNanpaLinjanParsing,
      relaxedNanpaLinjanRendering: relaxedNanpaLinjanRendering,
      abbreviateNumericCartouches: abbreviateNumericCartouches,
      preserveNumericCartoucheBreaksInAbbreviation:
          preserveNumericCartoucheBreaks,
      numericCartoucheStartGlyph: start,
    );
  }

  FullParserOptions copyWith({
    bool? enableBinaryParsing,
    bool? enableHexParsing,
    String? mode,
    String? numericMode,
    bool? nanpaColonParsing,
    bool? nanpaColonRendering,
    bool? relaxedNanpaLinjanParsing,
    bool? relaxedNanpaLinjanRendering,
    bool? abbreviateNumericCartouches,
    bool? preserveNumericCartoucheBreaks,
    String? numericCartoucheStartGlyph,
    bool clearNumericCartoucheStartGlyph = false,
    String? rendererMode,
    String? mixedStyle,
    bool? breakLinesAtFullStops,
    bool? showUnknownText,
    bool? autoCartoucheStandaloneProperNames,
    bool? interpretDoubleQuotesAsTeTo,
    bool? cartoucheCommaTallyMarks,
    bool? commaTallyMarks,
    bool clearCommaTallyMarks = false,
    String? cartoucheTallyMode,
    double? manualTallySmallFontLiftPx,
    double? manualTallySmallFontMaxPx,
    bool? nasinNanpaPona,
  }) =>
      FullParserOptions(
        enableBinaryParsing: enableBinaryParsing ?? this.enableBinaryParsing,
        enableHexParsing: enableHexParsing ?? this.enableHexParsing,
        mode: mode ?? this.mode,
        numericMode: numericMode ?? this.numericMode,
        nanpaColonParsing: nanpaColonParsing ?? this.nanpaColonParsing,
        nanpaColonRendering: nanpaColonRendering ?? this.nanpaColonRendering,
        relaxedNanpaLinjanParsing:
            relaxedNanpaLinjanParsing ?? this.relaxedNanpaLinjanParsing,
        relaxedNanpaLinjanRendering:
            relaxedNanpaLinjanRendering ?? this.relaxedNanpaLinjanRendering,
        abbreviateNumericCartouches:
            abbreviateNumericCartouches ?? this.abbreviateNumericCartouches,
        preserveNumericCartoucheBreaks: preserveNumericCartoucheBreaks ??
            this.preserveNumericCartoucheBreaks,
        numericCartoucheStartGlyph: clearNumericCartoucheStartGlyph
            ? null
            : (numericCartoucheStartGlyph ?? this.numericCartoucheStartGlyph),
        rendererMode: rendererMode ?? this.rendererMode,
        mixedStyle: mixedStyle ?? this.mixedStyle,
        breakLinesAtFullStops:
            breakLinesAtFullStops ?? this.breakLinesAtFullStops,
        showUnknownText: showUnknownText ?? this.showUnknownText,
        autoCartoucheStandaloneProperNames:
            autoCartoucheStandaloneProperNames ??
                this.autoCartoucheStandaloneProperNames,
        interpretDoubleQuotesAsTeTo:
            interpretDoubleQuotesAsTeTo ?? this.interpretDoubleQuotesAsTeTo,
        cartoucheCommaTallyMarks:
            cartoucheCommaTallyMarks ?? this.cartoucheCommaTallyMarks,
        commaTallyMarks:
            clearCommaTallyMarks ? null : (commaTallyMarks ?? this.commaTallyMarks),
        cartoucheTallyMode: cartoucheTallyMode ?? this.cartoucheTallyMode,
        manualTallySmallFontLiftPx:
            manualTallySmallFontLiftPx ?? this.manualTallySmallFontLiftPx,
        manualTallySmallFontMaxPx:
            manualTallySmallFontMaxPx ?? this.manualTallySmallFontMaxPx,
        nasinNanpaPona: nasinNanpaPona ?? this.nasinNanpaPona,
      );
}

class FullLayoutOptions {
  final String align;
  final String spacingPreset;
  final double? glyphGapScale;
  final double? glyphGapMinPx;
  final double? glyphGapMaxPx;
  final double? cartoucheLeadGapScale;
  final double? cartouchePadScale;
  final double? cartouchePadMinPx;
  final double? lineGapPx;
  final bool forceLineGapPx;

  const FullLayoutOptions({
    this.align = 'left',
    this.spacingPreset = 'default',
    this.glyphGapScale,
    this.glyphGapMinPx,
    this.glyphGapMaxPx,
    this.cartoucheLeadGapScale,
    this.cartouchePadScale,
    this.cartouchePadMinPx,
    this.lineGapPx,
    this.forceLineGapPx = false,
  });

  factory FullLayoutOptions.fromMap(Map<String, dynamic>? raw) {
    final j = raw ?? const <String, dynamic>{};
    double? d(String k) => j[k] is num ? (j[k] as num).toDouble() : null;
    return FullLayoutOptions(
      align: '${j['align'] ?? 'left'}',
      spacingPreset: '${j['spacingPreset'] ?? 'default'}',
      glyphGapScale: d('glyphGapScale'),
      glyphGapMinPx: d('glyphGapMinPx'),
      glyphGapMaxPx: d('glyphGapMaxPx'),
      cartoucheLeadGapScale: d('cartoucheLeadGapScale'),
      cartouchePadScale: d('cartouchePadScale'),
      cartouchePadMinPx: d('cartouchePadMinPx'),
      lineGapPx: d('lineGapPx'),
      forceLineGapPx: j['forceLineGapPx'] == true,
    );
  }

  double glyphGap(double px) {
    if (glyphGapScale != null) {
      var v = px * glyphGapScale!;
      if (glyphGapMinPx != null) v = math.max(v, glyphGapMinPx!);
      if (glyphGapMaxPx != null) v = math.min(v, glyphGapMaxPx!);
      return math.max(0, v);
    }
    switch (spacingPreset.toLowerCase()) {
      case 'compact':
        return math.max(2, px * .08);
      case 'comfortable':
        return math.max(6, px * .22);
      default:
        return math.max(4, px * .14);
    }
  }

  double cartoucheLeadGap(double px) => cartoucheLeadGapScale == null
      ? glyphGap(px)
      : math.max(0, px * cartoucheLeadGapScale!);

  double cartouchePad(double px) {
    var v = px * (cartouchePadScale ?? .12);
    if (cartouchePadMinPx != null) v = math.max(v, cartouchePadMinPx!);
    return math.max(0, v);
  }

  double lineGap(double px) {
    if (lineGapPx != null && (forceLineGapPx || lineGapPx! >= 0)) {
      return math.max(0, lineGapPx!);
    }
    switch (spacingPreset.toLowerCase()) {
      case 'compact':
        return math.max(8, px * .20);
      case 'comfortable':
        return math.max(18, px * .40);
      default:
        return 18;
    }
  }
}

class UnknownTextStyle {
  final String style;
  final String color;
  final double lineWidthPx;
  final double paddingPx;
  final List<double> dash;
  const UnknownTextStyle({
    this.style = 'outline-box',
    this.color = '#000000',
    this.lineWidthPx = 1.5,
    this.paddingPx = 2,
    this.dash = const <double>[],
  });

  factory UnknownTextStyle.fromMap(Map<String, dynamic>? raw) {
    final j = raw ?? const <String, dynamic>{};
    return UnknownTextStyle(
      style: '${j['style'] ?? 'outline-box'}',
      color: '${j['color'] ?? '#000000'}',
      lineWidthPx:
          j['lineWidthPx'] is num ? (j['lineWidthPx'] as num).toDouble() : 1.5,
      paddingPx:
          j['paddingPx'] is num ? (j['paddingPx'] as num).toDouble() : 2,
      dash: j['dash'] is List
          ? (j['dash'] as List)
              .whereType<num>()
              .map((e) => e.toDouble())
              .toList(growable: false)
          : const <double>[],
    );
  }
}

class FullPaintOptions {
  final String fillStyle;
  final UnknownTextStyle unknownText;
  final bool haloEnabled;
  final String haloColor;
  final double haloWidthPx;
  const FullPaintOptions({
    this.fillStyle = '#000000',
    this.unknownText = const UnknownTextStyle(),
    this.haloEnabled = false,
    this.haloColor = '#FFFFFF',
    this.haloWidthPx = 0,
  });

  factory FullPaintOptions.fromMap(Map<String, dynamic>? raw) {
    final j = raw ?? const <String, dynamic>{};
    final halo = j['halo'] is Map
        ? Map<String, dynamic>.from(j['halo'] as Map)
        : const <String, dynamic>{};
    final unknown = j['unknownText'] is Map
        ? Map<String, dynamic>.from(j['unknownText'] as Map)
        : const <String, dynamic>{};
    return FullPaintOptions(
      fillStyle: '${j['fillStyle'] ?? '#000000'}',
      unknownText: UnknownTextStyle.fromMap(unknown),
      haloEnabled: halo['enabled'] == true || j['haloEnabled'] == true,
      haloColor: '${halo['color'] ?? j['haloColor'] ?? '#FFFFFF'}',
      haloWidthPx: halo['widthPx'] is num
          ? (halo['widthPx'] as num).toDouble()
          : (j['haloWidthPx'] is num
              ? (j['haloWidthPx'] as num).toDouble()
              : 0),
    );
  }
}

class FullRenderOptions {
  final String font;
  final double fontSize;
  final int paddingPx;
  final FullParserOptions parser;
  final FullLayoutOptions layout;
  final FullPaintOptions paint;
  final bool includePlan;

  const FullRenderOptions({
    this.font = defaultProductionFontKey,
    this.fontSize = 56,
    this.paddingPx = 18,
    this.parser = const FullParserOptions(),
    this.layout = const FullLayoutOptions(),
    this.paint = const FullPaintOptions(),
    this.includePlan = true,
  });

  factory FullRenderOptions.fromMap(Map<String, dynamic>? raw) {
    final j = raw ?? const <String, dynamic>{};
    final parser = j['parser'] is Map
        ? Map<String, dynamic>.from(j['parser'] as Map)
        : const <String, dynamic>{};
    final layout = j['layout'] is Map
        ? Map<String, dynamic>.from(j['layout'] as Map)
        : const <String, dynamic>{};
    final paint = j['paint'] is Map
        ? Map<String, dynamic>.from(j['paint'] as Map)
        : const <String, dynamic>{};
    return FullRenderOptions(
      font: '${j['font'] ?? defaultProductionFontKey}',
      fontSize: j['fontSize'] is num
          ? (j['fontSize'] as num).toDouble()
          : (layout['fontPx'] is num
              ? (layout['fontPx'] as num).toDouble()
              : 56),
      paddingPx: j['paddingPx'] is num
          ? (j['paddingPx'] as num).round()
          : (layout['paddingPx'] is num
              ? (layout['paddingPx'] as num).round()
              : 18),
      parser: FullParserOptions.fromMap(parser),
      layout: FullLayoutOptions.fromMap(layout),
      paint: FullPaintOptions.fromMap(paint),
      includePlan: j['includePlan'] is bool ? j['includePlan'] as bool : true,
    );
  }

  FullRenderOptions copyWith({
    String? font,
    double? fontSize,
    int? paddingPx,
    FullParserOptions? parser,
    FullLayoutOptions? layout,
    FullPaintOptions? paint,
    bool? includePlan,
  }) =>
      FullRenderOptions(
        font: font ?? this.font,
        fontSize: fontSize ?? this.fontSize,
        paddingPx: paddingPx ?? this.paddingPx,
        parser: parser ?? this.parser,
        layout: layout ?? this.layout,
        paint: paint ?? this.paint,
        includePlan: includePlan ?? this.includePlan,
      );
}

class ImageDescriptor {
  final String src;
  final String width;
  final String height;
  final String alt;
  final String vAlign;
  final double wriggle;
  final bool transparent;
  const ImageDescriptor({
    this.src = '',
    this.width = '',
    this.height = '',
    this.alt = '',
    this.vAlign = 'baseline',
    this.wriggle = 8,
    this.transparent = true,
  });

  Map<String, dynamic> toJson() => <String, dynamic>{
        'src': src,
        'w': width,
        'h': height,
        'alt': alt,
        'vAlign': vAlign,
        'wriggle': wriggle,
        'transparent': transparent,
      };
}

class DocumentSegment {
  final String kind;
  final String value;
  final ImageDescriptor? image;
  final String openQuote;
  final String closeQuote;
  final int sourceStart;
  final int sourceEnd;
  const DocumentSegment({
    required this.kind,
    this.value = '',
    this.image,
    this.openQuote = '',
    this.closeQuote = '',
    required this.sourceStart,
    required this.sourceEnd,
  });

  Map<String, dynamic> toJson() {
    final out = <String, dynamic>{'kind': kind};
    if (image != null) {
      out['value'] = image!.toJson();
    } else {
      out['value'] = value;
    }
    if (openQuote.isNotEmpty) out['openQuote'] = openQuote;
    if (closeQuote.isNotEmpty) out['closeQuote'] = closeQuote;
    if (kind == 'quote') {
      out['sourceStart'] = sourceStart;
      out['sourceEnd'] = sourceEnd;
    }
    return out;
  }
}

class DocumentLine {
  final int index;
  final int sourceLineIndex;
  final int sentenceIndexInSourceLine;
  final String sourceText;
  final List<DocumentSegment> children;
  const DocumentLine({
    required this.index,
    required this.sourceLineIndex,
    required this.sentenceIndexInSourceLine,
    required this.sourceText,
    required this.children,
  });

  Map<String, dynamic> toJson() => <String, dynamic>{
        'type': 'line',
        'index': index,
        'sourceLineIndex': sourceLineIndex,
        'sentenceIndexInSourceLine': sentenceIndexInSourceLine,
        'sourceText': sourceText,
        'children': children.map((e) => e.toJson()).toList(),
      };
}

class DocumentAst {
  final String normalizedInput;
  final bool breakLinesAtFullStops;
  final List<DocumentLine> lines;
  const DocumentAst({
    required this.normalizedInput,
    required this.breakLinesAtFullStops,
    required this.lines,
  });

  Map<String, dynamic> toJson() => <String, dynamic>{
        'type': 'document',
        'normalizedInput': normalizedInput,
        'parserOptions': <String, dynamic>{
          'breakLinesAtFullStops': breakLinesAtFullStops,
        },
        'lines': lines.map((e) => e.toJson()).toList(),
      };
}

class TallyGroup {
  final int ownerIndex;
  final int count;
  final double ownerLeftPx;
  final double ownerRightPx;
  final double centerXPx;
  final double topYPx;
  final double bottomYPx;
  final double strokeWidthPx;
  final List<double> strokeCentersPx;
  const TallyGroup({
    required this.ownerIndex,
    required this.count,
    required this.ownerLeftPx,
    required this.ownerRightPx,
    required this.centerXPx,
    required this.topYPx,
    required this.bottomYPx,
    required this.strokeWidthPx,
    required this.strokeCentersPx,
  });

  TallyGroup shifted(double dx, double dy) => TallyGroup(
        ownerIndex: ownerIndex,
        count: count,
        ownerLeftPx: ownerLeftPx + dx,
        ownerRightPx: ownerRightPx + dx,
        centerXPx: centerXPx + dx,
        topYPx: topYPx + dy,
        bottomYPx: bottomYPx + dy,
        strokeWidthPx: strokeWidthPx,
        strokeCentersPx:
            strokeCentersPx.map((e) => e + dx).toList(growable: false),
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'ownerIndex': ownerIndex,
        'count': count,
        'ownerLeftPx': ownerLeftPx,
        'ownerRightPx': ownerRightPx,
        'centerXPx': centerXPx,
        'topYPx': topYPx,
        'bottomYPx': bottomYPx,
        'strokeWidthPx': strokeWidthPx,
        'strokeCentersPx': strokeCentersPx,
      };
}

class FullRenderRun {
  final String id;
  final int lineIndex;
  final int runIndex;
  final String kind;
  final String renderMode;
  final String fontRole;
  final bool numericCartouche;
  final bool hexCartouche;
  final bool binaryCartouche;
  final int numericBase;
  final int? openerCodepoint;
  final int? closerCodepoint;
  final List<int> canonicalCodepoints;
  final List<int> renderCodepoints;
  final String renderText;
  final String renderAdapterId;
  final String sourceText;
  final String sourceKind;
  final int sourceStart;
  final int sourceEnd;
  final List<int> manualTallies;
  final List<TallyGroup> tallyGroups;
  final bool quoted;
  final bool interpretedQuote;
  final bool unrecognized;
  final String imageAlt;
  final double xPx;
  final double yPx;
  final double widthPx;
  final double heightPx;
  final double baselineYPx;

  const FullRenderRun({
    this.id = '',
    this.lineIndex = 0,
    this.runIndex = 0,
    this.kind = 'glyph',
    this.renderMode = 'text',
    this.fontRole = 'word',
    this.numericCartouche = false,
    this.hexCartouche = false,
    this.binaryCartouche = false,
    this.numericBase = 10,
    this.openerCodepoint,
    this.closerCodepoint,
    this.canonicalCodepoints = const <int>[],
    this.renderCodepoints = const <int>[],
    this.renderText = '',
    this.renderAdapterId = 'identity',
    this.sourceText = '',
    this.sourceKind = 'text',
    this.sourceStart = 0,
    this.sourceEnd = 0,
    this.manualTallies = const <int>[],
    this.tallyGroups = const <TallyGroup>[],
    this.quoted = false,
    this.interpretedQuote = false,
    this.unrecognized = false,
    this.imageAlt = '',
    this.xPx = 0,
    this.yPx = 0,
    this.widthPx = 0,
    this.heightPx = 0,
    this.baselineYPx = 0,
  });

  FullRenderRun placed({
    required String id,
    required int lineIndex,
    required int runIndex,
    required double xPx,
    required double yPx,
    required double widthPx,
    required double heightPx,
    required double baselineYPx,
    List<TallyGroup>? tallyGroups,
  }) =>
      FullRenderRun(
        id: id,
        lineIndex: lineIndex,
        runIndex: runIndex,
        kind: kind,
        renderMode: renderMode,
        fontRole: fontRole,
        numericCartouche: numericCartouche,
        hexCartouche: hexCartouche,
        binaryCartouche: binaryCartouche,
        numericBase: numericBase,
        openerCodepoint: openerCodepoint,
        closerCodepoint: closerCodepoint,
        canonicalCodepoints: canonicalCodepoints,
        renderCodepoints: renderCodepoints,
        renderText: renderText,
        renderAdapterId: renderAdapterId,
        sourceText: sourceText,
        sourceKind: sourceKind,
        sourceStart: sourceStart,
        sourceEnd: sourceEnd,
        manualTallies: manualTallies,
        tallyGroups: tallyGroups ?? this.tallyGroups,
        quoted: quoted,
        interpretedQuote: interpretedQuote,
        unrecognized: unrecognized,
        imageAlt: imageAlt,
        xPx: xPx,
        yPx: yPx,
        widthPx: widthPx,
        heightPx: heightPx,
        baselineYPx: baselineYPx,
      );

  Map<String, dynamic> semanticJson() => <String, dynamic>{
        'id': id,
        'kind': kind,
        'renderMode': renderMode,
        'fontRole': fontRole,
        'numericCartouche': numericCartouche,
        'hexCartouche': hexCartouche,
        'binaryCartouche': binaryCartouche,
        'numericBase': numericBase,
        if (openerCodepoint != null) 'openerCodepoint': openerCodepoint,
        if (closerCodepoint != null) 'closerCodepoint': closerCodepoint,
        'canonicalCodepoints': canonicalCodepoints,
        'renderCodepoints': renderCodepoints,
        'renderText': renderText,
        'renderAdapterId': renderAdapterId,
        'sourceText': sourceText,
        'sourceKind': sourceKind,
        'sourceStart': sourceStart,
        'sourceEnd': sourceEnd,
        if (manualTallies.isNotEmpty) 'manualTallies': manualTallies,
        if (tallyGroups.isNotEmpty)
          'tallyGroups': tallyGroups.map((e) => e.toJson()).toList(),
        'quoted': quoted,
        'interpretedQuote': interpretedQuote,
        'unrecognized': unrecognized,
        if (imageAlt.isNotEmpty) 'imageAlt': imageAlt,
      };
}

class FullRenderLinePlan {
  final int lineIndex;
  final int sourceLineIndex;
  final int sentenceIndexInSourceLine;
  final double xPx;
  final double yPx;
  final double widthPx;
  final double heightPx;
  final double baselineYPx;
  final double ascentPx;
  final double descentPx;
  final List<FullRenderRun> runs;
  const FullRenderLinePlan({
    required this.lineIndex,
    required this.sourceLineIndex,
    required this.sentenceIndexInSourceLine,
    required this.xPx,
    required this.yPx,
    required this.widthPx,
    required this.heightPx,
    required this.baselineYPx,
    required this.ascentPx,
    required this.descentPx,
    required this.runs,
  });
}

class FullRenderPlan {
  final String input;
  final String fontKey;
  final bool abbreviated;
  final int width;
  final int height;
  final int paddingPx;
  final double lineGapPx;
  final List<String> openTypeFeatures;
  final List<FullRenderRun> runs;
  final ParseResult? parsed;
  final List<String> diagnostics;
  final DocumentAst ast;
  final List<FullRenderLinePlan> lines;
  const FullRenderPlan({
    required this.input,
    required this.fontKey,
    required this.abbreviated,
    required this.width,
    required this.height,
    required this.paddingPx,
    required this.lineGapPx,
    required this.openTypeFeatures,
    required this.runs,
    required this.parsed,
    required this.diagnostics,
    required this.ast,
    required this.lines,
  });

  int get lineCount => lines.length;
  int get cartoucheCount => runs
      .where((r) => r.numericCartouche || r.fontRole == 'cartouche')
      .length;
}

class FullCanvasResult {
  final Uint8List bytes;
  final int width;
  final int height;
  final FullRenderPlan? plan;
  final String fontKey;
  const FullCanvasResult({
    required this.bytes,
    required this.width,
    required this.height,
    required this.plan,
    required this.fontKey,
  });
}

class FullRenderResult {
  final Uint8List bytes;
  final int width;
  final int height;
  final String format;
  final FullRenderPlan plan;
  const FullRenderResult({
    required this.bytes,
    required this.width,
    required this.height,
    required this.format,
    required this.plan,
  });
}

class VectorElement {
  final String kind;
  final String runId;
  final String path;
  final String fill;
  final String href;
  final String text;
  final double x;
  final double y;
  final double width;
  final double height;
  const VectorElement({
    required this.kind,
    this.runId = '',
    this.path = '',
    this.fill = '',
    this.href = '',
    this.text = '',
    this.x = 0,
    this.y = 0,
    this.width = 0,
    this.height = 0,
  });
}

class VectorDocument {
  final int width;
  final int height;
  final List<VectorElement> elements;
  final List<String> diagnostics;
  final FullRenderPlan plan;
  const VectorDocument({
    required this.width,
    required this.height,
    required this.elements,
    required this.diagnostics,
    required this.plan,
  });
}

typedef FullRenderAdapter = List<int> Function(
  List<int> codepoints,
  ProductionFontInfo font,
  double fontSize,
);
