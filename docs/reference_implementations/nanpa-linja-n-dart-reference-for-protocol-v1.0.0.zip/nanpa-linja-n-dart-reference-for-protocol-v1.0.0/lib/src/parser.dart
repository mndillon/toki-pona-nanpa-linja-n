import 'constants.dart';
import 'encoding.dart';
import 'model.dart';
import 'options.dart';

class _CapsToken {
  final String kind;
  final int value;
  const _CapsToken(this.kind,[this.value=0]);
  @override bool operator==(Object other)=>other is _CapsToken&&other.kind==kind&&other.value==value;
  @override int get hashCode=>Object.hash(kind,value);
}

class _Meta {
  final SemanticKind? semanticKind;
  final DecimalStartGlyph? semanticStartGlyph;
  final String? displayOverride;
  final bool yearless;
  const _Meta({this.semanticKind,this.semanticStartGlyph,this.displayOverride,this.yearless=false});
}

class _BasePart {
  final String? digits;
  final String? delimiter;
  const _BasePart.digits(this.digits):delimiter=null;
  const _BasePart.delimiter([this.delimiter]):digits=null;
}

String _repeat(String s,int n)=>List.filled(n,s).join();
String _normalizeMinus(String s)=>s.replaceAll('−','-').replaceAll('‒','-').replaceAll('–','-').replaceAll('—','-');
String _title(String s)=>s.isEmpty?s:'${s[0].toUpperCase()}${s.substring(1)}';

int? _pairDigit(String pair,bool relaxed){
  const strict={'NI':0,'WE':1,'TE':2,'SE':3,'NA':4,'LE':5,'NU':6,'ME':7,'PE':8,'JE':9};
  const aliases={'WA':1,'TU':2,'LU':5,'MU':7,'PI':8,'JO':9};
  return strict[pair]??(relaxed?aliases[pair]:null);
}
String? _digitCaps(int d,bool relaxed)=>d<0||d>9?null:(relaxed?relaxedDigits[d]:strictDigits[d]);
String? _digitProper(int d,bool relaxed)=>_digitCaps(d,relaxed)?.toLowerCase();

List<_CapsToken>? _tokenizeCaps(String caps,bool relaxed){
  final s=caps.trim().toUpperCase();
  if(s.length<3||!s.startsWith('NE')||!s.endsWith('N'))return null;
  final out=<_CapsToken>[]; var i=0; final end=s.length-1;
  while(i<end){
    final rest=s.substring(i,end);
    if(rest.startsWith('KEKEKE')){out.add(const _CapsToken('ke',3));i+=6;continue;}
    if(rest.startsWith('KEKE')){out.add(const _CapsToken('ke',2));i+=4;continue;}
    if(rest.startsWith('NONONO')){out.add(const _CapsToken('nonono'));i+=6;continue;}
    if(rest.startsWith('NONO')){out.add(const _CapsToken('nono'));i+=4;continue;}
    if(rest.startsWith('NOKO')){out.add(const _CapsToken('noko'));i+=4;continue;}
    if(rest.startsWith('KO')){out.add(const _CapsToken('ko'));i+=2;continue;}
    if(rest.startsWith('KE')){out.add(const _CapsToken('ke',1));i+=2;continue;}
    if(rest.startsWith('OK')){out.add(const _CapsToken('ok'));i+=2;continue;}
    if(rest.startsWith('NE')){out.add(const _CapsToken('ne'));i+=2;continue;}
    if(rest.startsWith('NS')){out.add(const _CapsToken('ns'));i+=2;continue;}
    if(rest.startsWith('NO')){out.add(const _CapsToken('no'));i+=2;continue;}
    if(i+2<=end){final d=_pairDigit(s.substring(i,i+2),relaxed);if(d!=null){out.add(_CapsToken('digit',d));i+=2;continue;}}
    return null;
  }
  out.add(const _CapsToken('end'));
  return out;
}

String? _stripCapsBody(String caps){final s=caps.trim();return s.startsWith('NE')&&s.endsWith('N')&&s.length>=3?s.substring(2,s.length-1):null;}

void _appendDigitWords(List<String> out,int d,bool relaxed)=>out.addAll((relaxed?digitWordsRelaxed:digitWordsStrict)[d]!);

List<String> _replaceTimeSeparators(List<String> words){
  final out=<String>[];var i=0;
  while(i<words.length){
    if(i+4<=words.length&&words[i]=='nena'&&words[i+1]=='e'&&words[i+2]=='kulupu'&&words[i+3]=='e'){
      out.addAll(const ['nena','e','kasi','e']);i+=4;
    }else{out.add(words[i++]);}
  }
  return out;
}

String _startWord(_Meta meta,ParseOptions o){
  if(o.numericCartoucheStartGlyph!=null)return o.numericCartoucheStartGlyph!.name;
  if(meta.semanticStartGlyph!=null)return meta.semanticStartGlyph!.name;
  if(o.nanpaColonRendering){
    if(meta.semanticKind==SemanticKind.date)return 'suno';
    if(meta.semanticKind==SemanticKind.time)return 'tenpo';
  }
  return 'nanpa';
}

List<String>? _tokensToWords(List<_CapsToken> tokens,_Meta meta,ParseOptions o){
  if(tokens.isEmpty||tokens.first.kind!='ne'||tokens.last.kind!='end')return null;
  var out=<String>[];var afterStart=false,afterScientific=false;var i=0;
  while(i<tokens.length){final t=tokens[i];
    switch(t.kind){
      case 'ne':
        if(i+1<tokens.length&&tokens[i+1].kind=='ko'){
          if(out.isEmpty){out.addAll(['nanpa',o.nanpaColonRendering?':':'e','kala','open']);}
          else{out.addAll(const ['nena','e','kala','open']);}
          afterStart=false;afterScientific=true;i+=2;continue;
        }
        if(out.isEmpty){out.addAll(['nanpa',o.nanpaColonRendering?':':'e']);afterStart=true;}
        else{out.addAll(const ['nena','e']);afterStart=false;}
        afterScientific=false;i++;break;
      case 'ns':out.addAll(const ['nena','en']);afterStart=false;afterScientific=false;i++;break;
      case 'digit':_appendDigitWords(out,t.value,o.relaxedNanpaLinjanRendering);afterStart=false;afterScientific=false;i++;break;
      case 'no':
        if(afterStart||afterScientific){out.addAll(const ['nena','ona']);afterStart=false;afterScientific=false;i++;}
        else if(i+1<tokens.length&&tokens[i+1].kind=='ne'){out.addAll(const ['nena','o','nena','e']);i+=2;}
        else{out.addAll(const ['nena','o']);i++;}
        break;
      case 'nono':out.addAll(const ['nena','o','nena','o']);i++;break;
      case 'noko':out.addAll(const ['nena','open','kin','open']);i++;break;
      case 'nonono':out.addAll(const ['nena','o','nena','o','nena','o']);i++;break;
      case 'ke':for(var n=0;n<t.value;n++)out.addAll(const ['kulupu','e']);i++;break;
      case 'ko':i++;break;
      case 'ok':i++;break;
      case 'end':out.add('nanpa');i++;break;
      default:return null;
    }
  }
  if(meta.semanticKind!=null)out=_replaceTimeSeparators(out);
  if(tokens.any((t)=>t.kind=='ok')){
    var at=out.lastIndexOf('nanpa');if(at<0)at=out.length;
    out.insertAll(at,const ['nena','open','kipisi','e']);
  }
  if(out.isNotEmpty)out[0]=_startWord(meta,o);
  // Traditional rendering has a small set of alternate marker heads. Core v1
  // freezes the percent form explicitly; keep all other semantics unchanged.
  if(o.numericMode==NumericMode.traditional||o.mode==NumericMode.traditional){
    for(var j=0;j+3<out.length;j++){
      if(out[j]=='nena'&&out[j+1]=='open'&&out[j+2]=='kipisi'&&out[j+3]=='e')out[j]='noka';
    }
  }
  return out;
}

void _flushProper(List<String> words,StringBuffer prefix,List<int> digits,bool relaxed){
  if(digits.isEmpty)return;
  final splitTwo=digits.length>=3&&digits[digits.length-1]==0&&digits[digits.length-2]==0&&digits[digits.length-3]!=0;
  final firstLen=splitTwo?digits.length-2:digits.length;
  final b=StringBuffer(prefix.toString());
  for(var i=0;i<firstLen;i++)b.write(_digitProper(digits[i],relaxed));
  b.write('n');words.add(_title(b.toString()));if(splitTwo)words.add('Inin');
  prefix.clear();digits.clear();
}

List<String> _magnitudeProper(int n){if(n<=0)return[];if(n==1)return['Eke'];if(n==2)return['Ekeken'];if(n==3)return['Ekekeken'];if(n==4)return['Ekeke','Keken'];return[...List.filled(n-1,'Eke'),'Eken'];}

String? _tokensToProper(List<_CapsToken> tokens,_Meta meta,ParseOptions o){
  if(tokens.isEmpty||tokens.first.kind!='ne'||tokens.last.kind!='end')return null;
  final relaxed=o.relaxedNanpaLinjanRendering, words=<String>[], prefix=StringBuffer(),digits=<int>[];var i=1;var afterSci=false;
  while(i<tokens.length){final t=tokens[i];if(t.kind=='end')break;
    switch(t.kind){
      case 'ns':prefix.write('ne');i++;break;
      case 'no':
        if(digits.isEmpty&&(words.isEmpty||afterSci)){prefix.write('no');afterSci=false;i++;}
        else if(i+1<tokens.length&&tokens[i+1].kind=='ne'){_flushProper(words,prefix,digits,relaxed);words.add('One');i+=2;}
        else{_flushProper(words,prefix,digits,relaxed);words.add('On');i++;}
        break;
      case 'digit':digits.add(t.value);i++;break;
      case 'nono':_flushProper(words,prefix,digits,relaxed);words.add('Ono');i++;break;
      case 'noko':case 'nonono':_flushProper(words,prefix,digits,relaxed);words.add('Oko');i++;break;
      case 'ne':
        if(i+1<tokens.length&&tokens[i+1].kind=='ko'){_flushProper(words,prefix,digits,relaxed);words.add('Eko');afterSci=true;i+=2;}
        else if(i+1<tokens.length&&tokens[i+1].kind=='ne'){_flushProper(words,prefix,digits,relaxed);words.add('Ene');i+=2;}
        else if(i+1<tokens.length&&tokens[i+1].kind=='ke'){_flushProper(words,prefix,digits,relaxed);words.addAll(_magnitudeProper(tokens[i+1].value));i+=2;}
        else{i++;}
        break;
      case 'ke':_flushProper(words,prefix,digits,relaxed);words.addAll(_magnitudeProper(t.value));i++;break;
      case 'ko':i++;break;
      case 'ok':_flushProper(words,prefix,digits,relaxed);words.add('Oken');i++;break;
      default:return null;
    }
  }
  _flushProper(words,prefix,digits,relaxed);if(words.isEmpty)return null;
  final head=meta.semanticStartGlyph==DecimalStartGlyph.toki?'Toki':meta.semanticStartGlyph==DecimalStartGlyph.suno?'Suno':'Nanpa';
  return '$head ${words.join(' ')}';
}

String? _tokensToUnique(List<_CapsToken> tokens,bool yearless){
  final b=StringBuffer('#~');if(yearless)b.write('k');var i=1;
  while(i<tokens.length){final t=tokens[i];if(t.kind=='end')break;
    switch(t.kind){
      case'ns':b.write('e');i++;break;
      case'digit':b.write(digitUnique[t.value]);i++;break;
      case'no':b.write('o');i+=(i+1<tokens.length&&tokens[i+1].kind=='ne')?2:1;break;
      case'nono':b.write('oo');i++;break;
      case'noko':case'nonono':b.write('oko');i++;break;
      case'ne':
        if(i+1<tokens.length&&tokens[i+1].kind=='ko'){b.write('eko');i+=2;}
        else if(i+1<tokens.length&&tokens[i+1].kind=='ne'){b.write('ee');i+=2;}
        else if(i+1<tokens.length&&tokens[i+1].kind=='ke'){b.write(_repeat('k',tokens[i+1].value));i+=2;}
        else{i++;}break;
      case'ke':b.write(_repeat('k',t.value));i++;break;
      case'ko':b.write('ko');i++;break;
      case'ok':b.write('ok');i++;break;
      default:return null;
    }
  }
  return b.toString();
}

String? _tokensToDisplay(List<_CapsToken> tokens){
  final b=StringBuffer();var i=1;var sci=false;
  while(i<tokens.length){final t=tokens[i];if(t.kind=='end')break;
    switch(t.kind){
      case'ns':b.write('+');i++;break;
      case'digit':b.write(t.value);i++;break;
      case'no':
        if(b.isEmpty||sci){b.write('-');sci=false;i++;}
        else if(i+1<tokens.length&&tokens[i+1].kind=='ne'){b.write('.');i+=2;}
        else{b.write('-');i++;}break;
      case'nono':b.write('/');i++;break;
      case'noko':case'nonono':b.write('+');i++;break;
      case'ne':
        if(i+1<tokens.length&&tokens[i+1].kind=='ko'){b.write('e');sci=true;i+=2;}
        else if(i+1<tokens.length&&tokens[i+1].kind=='ne'){b.write(',');i+=2;}
        else if(i+1<tokens.length&&tokens[i+1].kind=='ke'){b.write(_repeat(',',tokens[i+1].value));i+=2;}
        else{i++;}break;
      case'ke':b.write(_repeat(',',t.value));i++;break;
      case'ko':i++;break;
      case'ok':b.write('%');i++;break;
      default:return null;
    }
  }
  return b.toString();
}

ParseResult? _buildDecimalFromCaps(String input,String caps,ParseOptions o,_Meta meta){
  final tokens=_tokenizeCaps(caps,true);if(tokens==null)return null;
  final words=_tokensToWords(tokens,meta,o);if(words==null)return null;
  final inner=wordsToCodepoints(words);if(inner==null)return null;
  final all=[cartoucheStart,...inner,cartoucheEnd];
  final proper=_tokensToProper(tokens,meta,o), unique=_tokensToUnique(tokens,meta.yearless);
  if(proper==null||unique==null)return null;
  final display=meta.displayOverride??_tokensToDisplay(tokens);if(display==null)return null;
  final isTime=meta.semanticKind==SemanticKind.time,isDate=meta.semanticKind==SemanticKind.date;
  return ParseResult(input:input.trim(),caps:caps,properName:proper,uniqueCode:unique,ucsurCodepoints:List.of(inner),hexCodepoints:cpsHex(inner),hexWithCartouche:cpsHex(all),tpWords:List.of(words),words:List.of(words),displayValue:display,isTime:isTime,isDate:isDate,isTimeLike:isTime||isDate,innerCodepoints:inner,codepoints:all,numericMode:o.numericModeName,semanticKind:meta.semanticKind,semanticStartGlyph:meta.semanticStartGlyph);
}

String _fractionDisplay(String s){final out=<String>[];for(var i=0;i<s.length;i+=3)out.add(s.substring(i,(i+3<s.length)?i+3:s.length));return out.join('_');}
String? _decimalDisplay(String source){
  var s=source.trim();var sign='';if(s.startsWith('+')||s.startsWith('-')){sign=s[0];s=s.substring(1);}var pct='';if(s.endsWith('%')){pct='%';s=s.substring(0,s.length-1);}
  var explicit=0;if(s.isNotEmpty){final p=magnitudePower(s[s.length-1]);if(p!=null){explicit=p;s=s.substring(0,s.length-1);}}
  final dots=s.split('.');if(dots.length>2)return null;final integerRaw=dots[0],frac=dots.length==2?dots[1]:null;final integer=integerRaw.isEmpty?'0':integerRaw;
  final groups=integer.split(',');if(groups.any((g)=>g.isEmpty||!RegExp(r'^\d+$').hasMatch(g)))return null;var trailing=0;if(groups.length>1){for(var i=groups.length-1;i>=0&&groups[i]=='000';i--)trailing++;if(trailing==groups.length)trailing=0;}
  final sig=groups.take(groups.length-trailing).join(',');var core=integerRaw.isEmpty?'0':sig;if(frac!=null){if(frac.isEmpty||!RegExp(r'^\d+$').hasMatch(frac))return null;core+='.${_fractionDisplay(frac)}';}
  final total=trailing+explicit;const suffix=['','K','M','B','T'];String d;
  if(total>0&&total<=4)d='$sign$core${suffix[total]}';else{d='$sign$core${_repeat(',000',trailing)}';if(explicit>0&&explicit<=4)d+=suffix[explicit];}
  return '$d$pct';
}

String? normalizeVulgarFraction(String source){
  const f={'¼':'1/4','½':'1/2','¾':'3/4','⅐':'1/7','⅑':'1/9','⅒':'1/10','⅓':'1/3','⅔':'2/3','⅕':'1/5','⅖':'2/5','⅗':'3/5','⅘':'4/5','⅙':'1/6','⅚':'5/6','⅛':'1/8','⅜':'3/8','⅝':'5/8','⅞':'7/8','↉':'0/3'};
  final hits=<MapEntry<String,String>>[];for(final e in f.entries){if(source.contains(e.key))hits.add(e);}if(hits.length>1)return null;
  if(hits.isEmpty)return source.replaceAll('⁄','/');final e=hits.single;if(!source.endsWith(e.key))return null;
  final before=source.substring(0,source.length-e.key.length);var sign='';var whole=before;if(whole.startsWith('-')||whole.startsWith('+')){sign=whole[0];whole=whole.substring(1);}if(whole.isNotEmpty&&!RegExp(r'^\d+$').hasMatch(whole))return null;
  return whole.isEmpty?'$sign${e.value}':'$sign$whole+${e.value}';
}

String? _coreCaps(String input,ParseOptions o)=>encodeDecimalCaps(input,o);
String? _buildCapsFromParts(List<String> parts,ParseOptions o,String marker){final b=StringBuffer('NE');for(var i=0;i<parts.length;i++){final c=_coreCaps(parts[i],o),body=c==null?null:_stripCapsBody(c);if(body==null)return null;b.write(body);if(i+1<parts.length)b.write(marker);}b.write('N');return b.toString();}

ParseResult? _parseFraction(String source,ParseOptions o){
  final n=normalizeVulgarFraction(source);if(n==null||!n.contains('/'))return null;final slash=n.indexOf('/');if(n.substring(slash+1).contains('/'))return null;final left=n.substring(0,slash),den=n.substring(slash+1);if(den.isEmpty)return null;
  final plus=left.lastIndexOf('+');String? whole;late String num;final mixed=plus>0;
  if(mixed){whole=left.substring(0,plus);num=left.substring(plus+1);if(num.isEmpty)return null;}else{num=left;}if(num.isEmpty)return null;
  final b=StringBuffer('NE');if(mixed){final a=_coreCaps(whole!,o),x=_stripCapsBody(a??'');if(x==null)return null;b.write(x);b.write('NOKO');}
  final nc=_coreCaps(num,o),nb=_stripCapsBody(nc??'');if(nb==null)return null;b.write(nb);b.write('NONO');final dc=_coreCaps(den,o),db=_stripCapsBody(dc??'');if(db==null)return null;b.write(db);b.write('N');
  final nd=_decimalDisplay(num),dd=_decimalDisplay(den);if(nd==null||dd==null)return null;String display;if(mixed){final wd=_decimalDisplay(whole!);if(wd==null)return null;display='$wd+$nd/$dd';}else{display='$nd/$dd';}
  return _buildDecimalFromCaps(source,b.toString(),o,_Meta(displayOverride:display));
}

ParseResult? _parseScientific(String source,ParseOptions o){
  final s=_normalizeMinus(source);String? mantissa,expRaw;
  final em=RegExp(r'[eE]').firstMatch(s);if(em!=null){if(RegExp(r'[eE]').allMatches(s).length!=1)return null;mantissa=s.substring(0,em.start);expRaw=s.substring(em.end);}
  else{for(final marker in ['*10^','*10+','*10-']){final i=s.indexOf(marker);if(i>=0){mantissa=s.substring(0,i);expRaw=s.substring(i+(marker=='*10^'?4:3));if(marker=='*10-'&&!expRaw.startsWith('-'))expRaw='-$expRaw';break;}}}
  if(mantissa==null||expRaw==null||mantissa.isEmpty||expRaw.isEmpty)return null;var neg=false;var exp=expRaw;if(exp.startsWith('-')){neg=true;exp=exp.substring(1);}else if(exp.startsWith('+'))exp=exp.substring(1);if(exp.isEmpty||!RegExp(r'^\d+$').hasMatch(exp))return null;
  final mc=_coreCaps(mantissa,o),ec=_coreCaps(exp,o),mb=_stripCapsBody(mc??''),eb=_stripCapsBody(ec??'');if(mb==null||eb==null)return null;final caps='NE${mb}NEKO${neg?'NO':''}${eb}N';final md=_decimalDisplay(mantissa);if(md==null)return null;
  return _buildDecimalFromCaps(source,caps,o,_Meta(displayOverride:'${md}e${neg?'-':''}$exp'));
}

bool _two(String v,int max)=>v.length==2&&RegExp(r'^\d\d$').hasMatch(v)&&int.parse(v)<=max;
ParseResult? _parseTime(String source,ParseOptions o){
  if(!source.contains(':'))return null;final s=_normalizeMinus(source);final signed=s.startsWith('-')||s.startsWith('+');final sign=signed?s[0]:'';final u=signed?s.substring(1):s;final p=u.split(':');final seg=<String>[];String? frac;var keepNeg=sign=='-';
  if(p.length==2){if(signed||p[0].isEmpty||p[0].length>2||!RegExp(r'^\d+$').hasMatch(p[0])||int.parse(p[0])>59||!_two(p[1],59))return null;seg.addAll(p);}
  else if(p.length==3){final dot=p[2].indexOf('.');if(dot>=0){if(signed)return null;final sec=p[2].substring(0,dot),f=p[2].substring(dot+1);if(p[0].isEmpty||p[0].length>2||!RegExp(r'^\d+$').hasMatch(p[0])||int.parse(p[0])>59||!_two(p[1],59)||!_two(sec,59)||f.isEmpty||f.length>3||!RegExp(r'^\d+$').hasMatch(f))return null;seg.addAll([p[0],p[1],sec]);frac=f;keepNeg=false;}else{if(p[0].isEmpty||!RegExp(r'^\d+$').hasMatch(p[0])||!_two(p[1],59)||!_two(p[2],59))return null;seg.addAll(p);if(seg.every((x)=>RegExp(r'^0+$').hasMatch(x)))keepNeg=false;}}
  else if(p.length==4){if(p[0].isEmpty||!RegExp(r'^\d+$').hasMatch(p[0])||!_two(p[1],59)||!_two(p[2],59))return null;var sec=p[3];final dot=sec.indexOf('.');if(dot>=0){final f=sec.substring(dot+1);sec=sec.substring(0,dot);if(f.isEmpty||f.length>3||!RegExp(r'^\d+$').hasMatch(f))return null;frac=f;}if(!_two(sec,59))return null;seg.addAll([p[0],p[1],p[2],sec]);if(seg.every((x)=>RegExp(r'^0+$').hasMatch(x))&&(frac==null||RegExp(r'^0+$').hasMatch(frac)))keepNeg=false;}
  else return null;
  final b=StringBuffer('NE');if(keepNeg)b.write('NO');for(var i=0;i<seg.length;i++){final c=_coreCaps(seg[i],o),body=_stripCapsBody(c??'');if(body==null)return null;b.write(body);if(i+1<seg.length)b.write('NEKE');}if(frac!=null){b.write('NONE');final c=_coreCaps(frac,o),body=_stripCapsBody(c??'');if(body==null)return null;b.write(body);}b.write('N');
  var display='${keepNeg?'-':''}${seg.join(',')}';if(frac!=null)display+='.$frac';return _buildDecimalFromCaps(source,b.toString(),o,_Meta(semanticKind:SemanticKind.time,displayOverride:display));
}

bool _validYearless(String m,String d){if(!RegExp(r'^\d{2}$').hasMatch(m)||!RegExp(r'^\d{2}$').hasMatch(d))return false;final mm=int.parse(m),dd=int.parse(d);const md=[0,31,29,31,30,31,30,31,31,30,31,30,31];return mm>=1&&mm<=12&&dd>=1&&dd<=md[mm];}
ParseResult? _parseDate(String source,ParseOptions o){
  String? rest;if(source.startsWith('--'))rest=source.substring(2);else if(source.startsWith('XXXX-'))rest=source.substring(5);if(rest!=null){final p=rest.split('-');if(p.length==2&&_validYearless(p[0],p[1])){final caps=_buildCapsFromParts(p,o,'NEKE');if(caps==null)return null;return _buildDecimalFromCaps(source,caps,o,_Meta(semanticKind:SemanticKind.date,displayOverride:'--${p[0]}-${p[1]}',yearless:true));}}
  final sep=source.contains('/')?'/':'-';final p=source.split(sep);if(p.length!=3||p[0].length!=4||p[1].length!=2||p[2].length!=2||p.any((x)=>!RegExp(r'^\d+$').hasMatch(x)))return null;final m=int.parse(p[1]),d=int.parse(p[2]);if(m<1||m>12||d<1||d>31)return null;final caps=_buildCapsFromParts(p,o,'NEKE');if(caps==null)return null;return _buildDecimalFromCaps(source,caps,o,_Meta(semanticKind:SemanticKind.date,displayOverride:p.join(',')));
}

ParseResult? _parseGroupedLoose(String source,ParseOptions o){
  if(source.contains(':')||source.contains('/')||source.startsWith('#')||source.startsWith('[')||!source.contains('-'))return null;final n=_normalizeMinus(source);String? sign;var rest=n;if(rest.startsWith('--')){sign='-';rest=rest.substring(2);}else if(rest.startsWith('+')){sign='+';rest=rest.substring(1);}else if(rest.startsWith('-')){sign='-';rest=rest.substring(1);}final g=rest.split('-');if(g.length<2||g.any((x)=>x.isEmpty||!RegExp(r'^\d+$').hasMatch(x)))return null;
  final first='${sign??''}${g[0]}';final b=StringBuffer('NE');final fc=_coreCaps(first,o),fb=_stripCapsBody(fc??'');if(fb==null)return null;b.write(fb);for(final x in g.skip(1)){b.write('NENE');final c=_coreCaps(x,o),bb=_stripCapsBody(c??'');if(bb==null)return null;b.write(bb);}b.write('N');return _buildDecimalFromCaps(source,b.toString(),o,_Meta(displayOverride:'${sign??''}${g.join(',')}'));
}

ParseResult? _parseNumberCode(String source,ParseOptions o){
  if(!source.startsWith('#~'))return null;final body=source.substring(2);if(body.isEmpty||RegExp(r'\s').hasMatch(body))return null;final ch=body.split('');var i=0;final b=StringBuffer('NE');
  const inv={'I':0,'W':1,'T':2,'S':3,'A':4,'L':5,'U':6,'M':7,'P':8,'J':9};
  if(ch.isNotEmpty&&ch[0].toLowerCase()=='e'){if(ch.length<2||!inv.containsKey(ch[1].toUpperCase()))return null;b.write('NS');i=1;}
  while(i<ch.length){final u=ch[i].toUpperCase();if(inv.containsKey(u)){b.write(strictDigits[inv[u]!]);i++;continue;}if(u=='K'){var n=0;while(i<ch.length&&ch[i].toLowerCase()=='k'){n++;i++;}b.write('NE');b.write(_repeat('KE',n));continue;}if(u=='O'){var n=0;final start=i;while(i<ch.length&&ch[i].toLowerCase()=='o'){n++;i++;}if(n==1&&start==0)b.write('NO');else if(n==1)b.write('NONE');else if(n==2)b.write('NONO');else if(n==3)b.write('NOKO');else return null;continue;}return null;}
  b.write('N');return _buildDecimalFromCaps(source,b.toString(),o,const _Meta());
}

String? _properNumericFragment(String word,bool first,bool relaxed){if(word.length<2||!word.endsWith('n'))return null;var core=word.substring(0,word.length-1).toLowerCase();final b=StringBuffer();if(first&&core.startsWith('ne')&&core.length>2){b.write('NS');core=core.substring(2);}else if(first&&core.startsWith('no')&&core.length>2){b.write('NO');core=core.substring(2);}while(core.isNotEmpty){if(core.length<2)return null;final pair=core.substring(0,2).toUpperCase();if(_pairDigit(pair,relaxed)==null)return null;b.write(pair);core=core.substring(2);}return b.toString();}
String? _properWordsToCaps(List<String> words,bool relaxed){if(words.isEmpty)return null;final b=StringBuffer('NE');var seen=false;for(final w0 in words){final w=w0.toLowerCase();switch(w){case'ene':b.write('NENE');break;case'eke':b.write('NEKE');break;case'one':b.write('NONE');break;case'ono':b.write('NONO');break;case'oko':b.write('NOKO');break;case'eko':b.write('NEKO');break;case'oken':b.write('OK');break;default:final f=_properNumericFragment(w,!seen,relaxed);if(f==null)return null;b.write(f);seen=true;}}if(!seen)return null;b.write('N');return _tokenizeCaps(b.toString(),relaxed)==null?null:b.toString();}

String? _legacyProperToCaps(String source,bool relaxed){
  final words=source.trim().split(RegExp(r'\s+'));if(words.isEmpty||words.any((w)=>w.isEmpty||!RegExp(r'^[A-Za-z]+$').hasMatch(w)))return null;final compact=words.join();if(!compact.endsWith('n')&&!compact.endsWith('N'))return null;var core=compact.substring(0,compact.length-1);if(core.length<2||core.length.isOdd)return null;var pct=false;if(core.toLowerCase().endsWith('noke')){pct=true;core=core.substring(0,core.length-4);if(core.length<2||core.length.isOdd)return null;}var caps=core.toUpperCase();if(!caps.startsWith('NE'))return null;final letters=source.split('').where((c)=>RegExp(r'[A-Za-z]').hasMatch(c));final allUpper=letters.every((c)=>c==c.toUpperCase());if(source.toLowerCase().startsWith('nene')&&!allUpper&&caps.startsWith('NENE'))caps='NENS${caps.substring(4)}';final out=pct?'${caps}OKN':'${caps}N';return _tokenizeCaps(out,relaxed)==null?null:out;
}

ParseResult? _parseProperName(String source,ParseOptions o){
  final w=source.trim().split(RegExp(r'\s+'));if(w.isEmpty)return null;String? head;List<String> body=w;if(['Nanpa','Toki','Tenpo','Suno'].contains(w[0])&&o.nanpaColonParsing){if(w.length<2)return null;head=w[0];body=w.sublist(1);}final caps=head==null?_legacyProperToCaps(source,o.relaxedNanpaLinjanParsing):_properWordsToCaps(body,o.relaxedNanpaLinjanParsing);if(caps==null)return null;final tok=_tokenizeCaps(caps,true),display=tok==null?null:_tokensToDisplay(tok);if(display==null)return null;
  if(head=='Toki')return _buildDecimalFromCaps(source,caps,o,_Meta(semanticStartGlyph:DecimalStartGlyph.toki,displayOverride:display));
  if(head=='Tenpo'){if(!display.contains(','))return null;return _buildDecimalFromCaps(source,caps,o,_Meta(semanticKind:SemanticKind.time,displayOverride:display));}
  if(head=='Suno'){
    if(!display.contains(',')){final n=int.tryParse(display);if(n==null||n<1||n>31)return null;return _buildDecimalFromCaps(source,caps,o,_Meta(semanticStartGlyph:DecimalStartGlyph.suno,displayOverride:display));}
    final g=display.split(',');if(g.length==2&&_validYearless(g[0],g[1]))return _buildDecimalFromCaps(source,caps,o,_Meta(semanticKind:SemanticKind.date,displayOverride:'--${g[0]}-${g[1]}',yearless:true));if(g.length==3)return _buildDecimalFromCaps(source,caps,o,_Meta(semanticKind:SemanticKind.date,displayOverride:display));return null;
  }
  return _buildDecimalFromCaps(source,caps,o,_Meta(displayOverride:display));
}

List<String>? _tokenizeBracket(String source){final s=source.trim();if(!s.startsWith('[')||!s.endsWith(']'))return null;final inner=s.substring(1,s.length-1);final out=<String>[];var cur='';for(final r in inner.runes){final c=String.fromCharCode(r);if(RegExp(r'[A-Za-z]').hasMatch(c)){cur+=c.toLowerCase();}else if(c==':'){if(cur.isNotEmpty){out.add(cur);cur='';}out.add(':');}else if(RegExp(r'\s').hasMatch(c)){if(cur.isNotEmpty){out.add(cur);cur='';}}else{return null;}}if(cur.isNotEmpty)out.add(cur);return out;}
int? _abbrevDigit(String w){final i=abbreviatedDigitWords.indexOf(w);return i<0?null:i;}
int? _fullPairDigit(String a,String b,bool relaxed){for(var d=0;d<10;d++){final p=(relaxed?digitWordsRelaxed:digitWordsStrict)[d]!;if(p[0]==a&&p[1]==b)return d;if(relaxed){final q=digitWordsStrict[d]!;if(q[0]==a&&q[1]==b)return d;}}return null;}

ParseResult? _parseTypedCartouche(String source,ParseOptions o){
  if(!o.nanpaColonParsing&&!o.nanpaColonRendering)return null;final t=_tokenizeBracket(source);if(t==null||t.length<3)return null;final head=t.first;if(!['nanpa','tenpo','suno','toki'].contains(head)||t.last!='nanpa')return null;final colon=t.length>1&&t[1]==':';if(!colon&&head!='suno')return null;final body=t.sublist(colon?2:1,t.length-1);if(body.isEmpty||body.any((w)=>w=='nanpa'||w=='nasin'))return null;
  var ab='NE',ai=0,aok=true,has=false;if(body.first=='en'){ab+='NS';ai=1;}while(ai<body.length&&aok){final w=body[ai];final d=_abbrevDigit(w);if(d!=null){ab+=strictDigits[d];has=true;}else{switch(w){case'e':ab+='NENE';break;case'o':case'ona':ab+='NO';break;case'kulupu':case'kasi':case'kolon':case':':ab+='NEKE';break;case'kala':ab+='NEKO';break;case'kin':ab+='NOKO';break;case'kipisi':if(ai+1==body.length){ab+='OK';}else{aok=false;}break;default:aok=false;}}ai++;}ab+='N';if(!has)aok=false;
  var full='NE',fi=0,fok=true,fhas=false;if(body.length>=2&&body[0]=='nena'&&body[1]=='en'){full+='NS';fi=2;}while(fi<body.length&&fok){if(fi+1<body.length){final d=_fullPairDigit(body[fi],body[fi+1],o.relaxedNanpaLinjanParsing);if(d!=null){final relaxedPair=[['wan','ala'],['tu','uta'],['luka','uta'],['mun','uta'],['pipi','ike'],['jo','open']].any((p)=>p[0]==body[fi]&&p[1]==body[fi+1]);full+=_digitCaps(d,relaxedPair)!;fhas=true;fi+=2;continue;}}
    if(fi+3<body.length&&body[fi]=='nena'&&body[fi+1]=='e'&&body[fi+2]=='nena'&&body[fi+3]=='e'){full+='NENE';fi+=4;continue;}
    if(fi+3<body.length&&body[fi]=='nena'&&body[fi+1]=='e'&&['kulupu','kasi'].contains(body[fi+2])&&body[fi+3]=='e'){full+='NEKE';fi+=4;continue;}
    if(fi+3<body.length&&body[fi]=='nena'&&body[fi+1]=='o'&&body[fi+2]=='nena'&&body[fi+3]=='e'){full+='NONE';fi+=4;continue;}fok=false;}
  full+='N';if(!fhas)fok=false;final caps=fok?full:(aok?ab:null);if(caps==null)return null;final toks=_tokenizeCaps(caps,true),disp=toks==null?null:_tokensToDisplay(toks);if(disp==null)return null;
  if(head=='toki')return _buildDecimalFromCaps(source,caps,o,_Meta(semanticStartGlyph:DecimalStartGlyph.toki,displayOverride:disp));
  if(head=='tenpo'){if(!disp.contains(','))return null;return _buildDecimalFromCaps(source,caps,o,_Meta(semanticKind:SemanticKind.time,displayOverride:disp));}
  if(head=='suno'){if(disp.contains(',')){final g=disp.split(',');if(g.length==2&&_validYearless(g[0],g[1]))return _buildDecimalFromCaps(source,caps,o,_Meta(semanticKind:SemanticKind.date,displayOverride:'--${g[0]}-${g[1]}',yearless:true));if(g.length==3)return _buildDecimalFromCaps(source,caps,o,_Meta(semanticKind:SemanticKind.date,displayOverride:disp));return null;}final n=int.tryParse(disp);if(n==null||n<1||n>31)return null;return _buildDecimalFromCaps(source,caps,o,_Meta(semanticStartGlyph:DecimalStartGlyph.suno,displayOverride:disp));}
  return _buildDecimalFromCaps(source,caps,o,_Meta(displayOverride:disp));
}

ParseResult? _parseCapsIdentifier(String source,ParseOptions o){if(source.length<3||source!=source.toUpperCase()||!source.startsWith('NE')||!source.endsWith('N')||_tokenizeCaps(source,o.relaxedNanpaLinjanParsing)==null)return null;return _buildDecimalFromCaps(source,source,o,const _Meta());}

String _partsDigits(List<_BasePart> p)=>p.where((x)=>x.digits!=null).map((x)=>x.digits!).join();
List<int>? _baseInner(List<String> words)=>wordsToCodepoints(words);

String? _binaryProperRun(String run,bool relaxed){final b=StringBuffer();for(final c in run.split('')){if(c=='0')b.write('ni');else if(c=='1')b.write(relaxed?'wa':'we');else return null;}return _title(b.toString());}
List<String>? _binaryWords(List<_BasePart> parts,bool abbreviated,bool relaxed){final w=<String>['noka',':'];for(final p in parts){if(p.digits!=null){for(final c in p.digits!.split('')){if(c!='0'&&c!='1')return null;final d=int.parse(c);if(abbreviated)w.add(d==0?'ijo':'wan');else _appendDigitWords(w,d,relaxed);}}else{w.addAll(abbreviated?const['e']:const['nena','e','nena','e']);}}w.add('noka');return w;}
ParseResult? _buildBinary(String source,List<_BasePart> parts,ParseOptions o){final digits=_partsDigits(parts);if(digits.isEmpty)return null;final proper=<String>['Noka'];for(final p in parts){if(p.digits!=null){final r=_binaryProperRun(p.digits!,o.relaxedNanpaLinjanRendering);if(r==null)return null;proper.add(r);}else{proper[proper.length-1]+='n';proper.add('Ene');}}proper[proper.length-1]+='n';final full=_binaryWords(parts,false,o.relaxedNanpaLinjanRendering),abbr=_binaryWords(parts,true,o.relaxedNanpaLinjanRendering);if(full==null||abbr==null)return null;final inner=_baseInner(full),ai=_baseInner(abbr);if(inner==null||ai==null)return null;final all=[cartoucheStart,...inner,cartoucheEnd];final canonical=StringBuffer('0b');for(final p in parts){canonical.write(p.digits??p.delimiter??':');}final bparts=parts.map((p)=>p.digits!=null?NumericPart.digits(p.digits):NumericPart.delimiter(p.delimiter)).toList();return ParseResult(input:source.trim(),caps:null,properName:proper.join(' '),uniqueCode:canonical.toString(),ucsurCodepoints:inner,hexCodepoints:cpsHex(inner),hexWithCartouche:cpsHex(all),tpWords:full,words:List.of(full),displayValue:canonical.toString(),isTime:false,isDate:false,isTimeLike:false,innerCodepoints:List.of(inner),codepoints:all,numericMode:o.numericModeName,kind:NumberKind.binary,numberBase:2,isBinary:true,binaryDigits:digits,binaryParts:bparts,abbreviatedUcsurCodepoints:ai,abbreviatedWords:abbr);}
ParseResult? _parseBinary(String source,ParseOptions o){if(!o.enableBinaryParsing)return null;if(source.startsWith('0b')){final body=source.substring(2);if(body.isEmpty||!['0','1'].contains(body[0]))return null;final parts=<_BasePart>[];var run='';for(final c in body.split('')){if(c=='0'||c=='1'){run+=c;}else{if(RegExp(r'\s|[A-Za-z2-9]').hasMatch(c))return null;if(run.isNotEmpty){parts.add(_BasePart.digits(run));run='';}parts.add(_BasePart.delimiter(c));}}if(run.isNotEmpty)parts.add(_BasePart.digits(run));if(parts.isEmpty||parts.first.digits==null)return null;return _buildBinary(source,parts,o);}if(source.startsWith('[')&&source.endsWith(']')){final t=_tokenizeBracket(source);if(t==null||t.length<4||t.first!='noka'||t.last!='noka')return null;final st=t.length>1&&t[1]==':'?2:1;var run='';for(final w in t.sublist(st,t.length-1)){if(w=='ijo')run+='0';else if(w=='wan')run+='1';else return null;}return run.isEmpty?null:_buildBinary(source,[_BasePart.digits(run)],o);}if(source.startsWith('Noka ')){final compact=source.split(RegExp(r'\s+')).join();if(!compact.toLowerCase().startsWith('noka')||!compact.endsWith('n'))return null;var body=compact.substring(4,compact.length-1).toUpperCase(),run='';final parts=<_BasePart>[];while(body.isNotEmpty){if(body.startsWith('NENE')){if(run.isEmpty)return null;parts.add(_BasePart.digits(run));parts.add(const _BasePart.delimiter());run='';body=body.substring(4);}else if(body.startsWith('NI')){run+='0';body=body.substring(2);}else if(body.startsWith('WE')||(o.relaxedNanpaLinjanParsing&&body.startsWith('WA'))){run+='1';body=body.substring(2);}else{return null;}}if(run.isNotEmpty)parts.add(_BasePart.digits(run));return _buildBinary(source,parts,o);}return null;}

List<int> _hexGroupSizes(int len){if(len<=0)return[];if(len<=3)return[len];final out=<int>[];var n=len;while(n>3){out.add(2);n-=2;}out.add(n);return out;}
List<String> _hexGroups(String run){final out=<String>[];var p=0;for(final n in _hexGroupSizes(run.length)){out.add(run.substring(p,p+n));p+=n;}return out;}
String? _hexSyllable(String d,bool relaxed){switch(d.toUpperCase()){case'0':return'ni';case'1':return relaxed?'wa':'we';case'2':return relaxed?'tu':'te';case'3':return'se';case'4':return'na';case'5':return relaxed?'lu':'le';case'6':return'nu';case'7':return relaxed?'mu':'me';case'8':return relaxed?'pi':'pe';case'9':return relaxed?'jo':'je';case'A':return'ja';case'B':return'la';case'C':return'ma';case'D':return'pa';case'E':return'si';case'F':return'ta';}return null;}
String? _hexAbbrev(String d){if(RegExp(r'^\d$').hasMatch(d))return abbreviatedDigitWords[int.parse(d)];return hexAbbreviatedWords[d.toUpperCase()];}
void _appendHexFull(List<String>w,String d,bool relaxed){final u=d.toUpperCase();switch(u){case'A':w.addAll(const['jan','ala']);return;case'B':w.addAll(const['lawa','ala']);return;case'C':w.addAll(const['ma','ala']);return;case'D':w.addAll(const['pakala','ala']);return;case'E':w.addAll(const['sike','ike']);return;case'F':w.addAll(const['tan','ala']);return;default:_appendDigitWords(w,int.parse(u),relaxed);return;}}
ParseResult? _buildHex(String source,List<_BasePart> parts,ParseOptions o){final digits=_partsDigits(parts);if(digits.isEmpty)return null;final full=<String>['nasa',':'],abbr=<String>['nasa',':'],proper=<String>['Nasa'];for(final p in parts){if(p.digits!=null){final groups=_hexGroups(p.digits!);for(var gi=0;gi<groups.length;gi++){final pb=StringBuffer();for(final d in groups[gi].split('')){_appendHexFull(full,d,o.relaxedNanpaLinjanRendering);final aw=_hexAbbrev(d),sy=_hexSyllable(d,o.relaxedNanpaLinjanRendering);if(aw==null||sy==null)return null;abbr.add(aw);pb.write(sy);}proper.add(_title(pb.toString()));if(gi+1<groups.length){full.addAll(const['nena','e','kule','e']);abbr.add('kule');proper[proper.length-1]+='n';proper.add('Eke');}}}else{full.addAll(const['nena','e','nena','e']);abbr.add('e');proper[proper.length-1]+='n';proper.add('Ene');}}
  proper[proper.length-1]+='n';full.add('nasa');abbr.add('nasa');final inner=_baseInner(full),ai=_baseInner(abbr);if(inner==null||ai==null)return null;final all=[cartoucheStart,...inner,cartoucheEnd];final canonical=StringBuffer('#');for(final p in parts)canonical.write(p.digits??p.delimiter??':');final hp=parts.map((p)=>p.digits!=null?NumericPart.digits(p.digits):NumericPart.delimiter(p.delimiter)).toList();return ParseResult(input:source.trim(),caps:null,properName:proper.join(' '),uniqueCode:canonical.toString(),ucsurCodepoints:inner,hexCodepoints:cpsHex(inner),hexWithCartouche:cpsHex(all),tpWords:full,words:List.of(full),displayValue:canonical.toString(),isTime:false,isDate:false,isTimeLike:false,innerCodepoints:List.of(inner),codepoints:all,numericMode:o.numericModeName,kind:NumberKind.hex,numberBase:16,isHex:true,hexDigits:digits,hexParts:hp,abbreviatedUcsurCodepoints:ai,abbreviatedWords:abbr);}
ParseResult? _parseHex(String source,ParseOptions o){if(!o.enableHexParsing)return null;if(source.startsWith('#')&&!source.startsWith('#~')){final body=source.substring(1);if(body.isEmpty||!RegExp(r'^[0-9A-Fa-f]').hasMatch(body))return null;final parts=<_BasePart>[];var run='';for(final c in body.split('')){if(RegExp(r'^[0-9A-Fa-f]$').hasMatch(c)){run+=c.toUpperCase();}else{if(RegExp(r'\s').hasMatch(c)||(RegExp(r'[A-Za-z]').hasMatch(c)&&!RegExp(r'[A-Fa-f]').hasMatch(c)))return null;if(run.isNotEmpty){parts.add(_BasePart.digits(run));run='';}parts.add(_BasePart.delimiter(c));}}if(run.isNotEmpty)parts.add(_BasePart.digits(run));return _buildHex(source,parts,o);}if(source.startsWith('[')&&source.endsWith(']')){final t=_tokenizeBracket(source);if(t==null||t.length<4||t.first!='nasa'||t.last!='nasa')return null;final st=t.length>1&&t[1]==':'?2:1;final body=t.sublist(st,t.length-1);var run='';final gen=<int>[];final parts=<_BasePart>[];bool flush(){if(run.isEmpty)return false;final groups=_hexGroups(run);var pos=0;final exp=<int>[];for(final g in groups.take(groups.length-1)){pos+=g.length;exp.add(pos);}if(gen.length!=exp.length)return false;for(var i=0;i<gen.length;i++)if(gen[i]!=exp[i])return false;parts.add(_BasePart.digits(run));run='';gen.clear();return true;}for(final w in body){if(w=='kule'){gen.add(run.length);}else if(w=='e'){if(!flush())return null;parts.add(const _BasePart.delimiter());}else{String? d;for(final x in '0123456789ABCDEF'.split('')){if(_hexAbbrev(x)==w){d=x;break;}}if(d==null)return null;run+=d;}}if(!flush())return null;return _buildHex(source,parts,o);}if(source.startsWith('Nasa ')){final compact=source.split(RegExp(r'\s+')).join();if(!compact.endsWith('n'))return null;var body=compact.substring(4,compact.length-1).toUpperCase(),run='';final gen=<int>[],parts=<_BasePart>[];bool flush(){if(run.isEmpty)return false;final groups=_hexGroups(run);var pos=0;final exp=<int>[];for(final g in groups.take(groups.length-1)){pos+=g.length;exp.add(pos);}if(gen.length!=exp.length)return false;for(var i=0;i<gen.length;i++)if(gen[i]!=exp[i])return false;parts.add(_BasePart.digits(run));run='';gen.clear();return true;}while(body.isNotEmpty){if(body.startsWith('NENE')){if(!flush())return null;parts.add(const _BasePart.delimiter());body=body.substring(4);continue;}if(body.startsWith('NEKE')){gen.add(run.length);body=body.substring(4);continue;}var matched=false;for(final d in '0123456789ABCDEF'.split('')){final a=_hexSyllable(d,o.relaxedNanpaLinjanParsing)!.toUpperCase(),strict=_hexSyllable(d,false)!.toUpperCase();if(body.startsWith(a)||body.startsWith(strict)){final z=body.startsWith(a)?a:strict;run+=d;body=body.substring(z.length);matched=true;break;}}if(!matched)return null;}if(run.isNotEmpty){if(!flush())return null;}return _buildHex(source,parts,o);}return null;}

ParseResult? _parseDecimalCore(String source,ParseOptions o){
  final s=source.trim();if(s.isEmpty)return null;
  // Strictly constrain the base grammar; extended syntaxes are handled first.
  if(!RegExp(r'^[+-]?(?:\d[\d,]*|\.\d+|\d[\d,]*\.\d+)(?:[KMBTkmbt]|%)?$').hasMatch(s))return null;
  final caps=encodeDecimalCaps(s,o);if(caps==null)return null;final display=_decimalDisplay(s);if(display==null)return null;final r=_buildDecimalFromCaps(source,caps,o,_Meta(displayOverride:display));if(r==null)return null;
  if(!o.nanpaColonRendering){
    // Legacy proper-name surface: the leading NE is part of the unheaded name.
    final modern=r.properName.startsWith('Nanpa ')?r.properName.substring(6):r.properName;
    if(s.startsWith('-'))r.properName='Neno $modern';
    else if(s.startsWith('+'))r.properName='Nene $modern';
    else{final parts=modern.split(' ');if(parts.isNotEmpty){parts[0]='Ne${parts[0].toLowerCase()}';r.properName=parts.join(' ');}}
  }
  return r;
}

/// Parse a nanpa-linja-n number according to Protocol v1.0.0.
ParseResult? parseNumber(Object? input,[ParseOptions options=const ParseOptions()]){
  if(input==null)return null;final source='$input'.trim();if(source.isEmpty)return null;
  return _parseBinary(source,options)??_parseHex(source,options)??_parseTypedCartouche(source,options)??_parseCapsIdentifier(source,options)??_parseProperName(source,options)??_parseNumberCode(source,options)??_parseDate(source,options)??_parseTime(source,options)??_parseScientific(source,options)??_parseFraction(source,options)??_parseGroupedLoose(source,options)??_parseDecimalCore(source,options);
}
