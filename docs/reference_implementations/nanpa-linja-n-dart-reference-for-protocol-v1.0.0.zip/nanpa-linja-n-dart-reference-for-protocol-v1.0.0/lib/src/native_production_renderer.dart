import 'dart:convert';
import 'dart:ffi';
import 'dart:io';
import 'dart:typed_data';

final class _PangoRectangle extends Struct {
  @Int32()
  external int x;

  @Int32()
  external int y;

  @Int32()
  external int width;

  @Int32()
  external int height;
}

typedef _MallocNative = Pointer<Void> Function(IntPtr);
typedef _MallocDart = Pointer<Void> Function(int);
typedef _FreeNative = Void Function(Pointer<Void>);
typedef _FreeDart = void Function(Pointer<Void>);

typedef _Ptr0Native = Pointer<Void> Function();
typedef _Ptr0Dart = Pointer<Void> Function();
typedef _Int0Native = Int32 Function();
typedef _Int0Dart = int Function();

typedef _PtrIntIntIntNative = Pointer<Void> Function(Int32, Int32, Int32);
typedef _PtrIntIntIntDart = Pointer<Void> Function(int, int, int);
typedef _PtrPtrNative = Pointer<Void> Function(Pointer<Void>);
typedef _PtrPtrDart = Pointer<Void> Function(Pointer<Void>);
typedef _VoidPtrNative = Void Function(Pointer<Void>);
typedef _VoidPtrDart = void Function(Pointer<Void>);
typedef _IntPtrNative = Int32 Function(Pointer<Void>);
typedef _IntPtrDart = int Function(Pointer<Void>);
typedef _VoidPtrIntNative = Void Function(Pointer<Void>, Int32);
typedef _VoidPtrIntDart = void Function(Pointer<Void>, int);
typedef _VoidPtrDoubleDoubleDoubleDoubleNative = Void Function(
  Pointer<Void>,
  Double,
  Double,
  Double,
  Double,
);
typedef _VoidPtrDoubleDoubleDoubleDoubleDart = void Function(
  Pointer<Void>,
  double,
  double,
  double,
  double,
);
typedef _VoidPtrDoubleDoubleNative = Void Function(Pointer<Void>, Double, Double);
typedef _VoidPtrDoubleDoubleDart = void Function(Pointer<Void>, double, double);

typedef _PtrCStringDoubleDoubleNative = Pointer<Void> Function(
  Pointer<Uint8>,
  Double,
  Double,
);
typedef _PtrCStringDoubleDoubleDart = Pointer<Void> Function(
  Pointer<Uint8>,
  double,
  double,
);
typedef _IntPtrCStringNative = Int32 Function(Pointer<Void>, Pointer<Uint8>);
typedef _IntPtrCStringDart = int Function(Pointer<Void>, Pointer<Uint8>);

typedef _VoidPtrCStringIntNative = Void Function(
  Pointer<Void>,
  Pointer<Uint8>,
  Int32,
);
typedef _VoidPtrCStringIntDart = void Function(Pointer<Void>, Pointer<Uint8>, int);
typedef _VoidPtrCStringNative = Void Function(Pointer<Void>, Pointer<Uint8>);
typedef _VoidPtrCStringDart = void Function(Pointer<Void>, Pointer<Uint8>);
typedef _VoidPtrDoubleNative = Void Function(Pointer<Void>, Double);
typedef _VoidPtrDoubleDart = void Function(Pointer<Void>, double);
typedef _VoidPtrPtrNative = Void Function(Pointer<Void>, Pointer<Void>);
typedef _VoidPtrPtrDart = void Function(Pointer<Void>, Pointer<Void>);
typedef _PtrCStringNative = Pointer<Void> Function(Pointer<Uint8>);
typedef _PtrCStringDart = Pointer<Void> Function(Pointer<Uint8>);
typedef _VoidPtrRectRectNative = Void Function(
  Pointer<Void>,
  Pointer<_PangoRectangle>,
  Pointer<_PangoRectangle>,
);
typedef _VoidPtrRectRectDart = void Function(
  Pointer<Void>,
  Pointer<_PangoRectangle>,
  Pointer<_PangoRectangle>,
);

class ProductionRgba {
  final int r;
  final int g;
  final int b;
  final int a;

  const ProductionRgba(this.r, this.g, this.b, [this.a = 255]);

  static const black = ProductionRgba(0, 0, 0, 255);
  static const transparent = ProductionRgba(0, 0, 0, 0);

  double get red => r.clamp(0, 255) / 255.0;
  double get green => g.clamp(0, 255) / 255.0;
  double get blue => b.clamp(0, 255) / 255.0;
  double get alpha => a.clamp(0, 255) / 255.0;
}

enum ProductionOutputFormat { png, svg, pdf }

class NativeRenderedBytes {
  final Uint8List bytes;
  final int width;
  final int height;
  final ProductionOutputFormat format;

  const NativeRenderedBytes({
    required this.bytes,
    required this.width,
    required this.height,
    required this.format,
  });
}

class _NativeTextBackend {
  static _NativeTextBackend? _instance;
  static _NativeTextBackend get instance => _instance ??= _NativeTextBackend._();

  late final DynamicLibrary _libc;
  late final DynamicLibrary _cairo;
  late final DynamicLibrary _pango;
  late final DynamicLibrary _pangoCairo;
  late final DynamicLibrary _pangoFt2;
  late final DynamicLibrary _fontconfig;
  late final DynamicLibrary _gobject;

  late final _MallocDart _malloc;
  late final _FreeDart _free;

  late final _PtrIntIntIntDart _cairoImageSurfaceCreate;
  late final _PtrCStringDoubleDoubleDart _cairoSvgSurfaceCreate;
  late final _PtrCStringDoubleDoubleDart _cairoPdfSurfaceCreate;
  late final _PtrPtrDart _cairoCreate;
  late final _VoidPtrDart _cairoDestroy;
  late final _VoidPtrDart _cairoSurfaceDestroy;
  late final _VoidPtrDart _cairoSurfaceFinish;
  late final _IntPtrCStringDart _cairoSurfaceWriteToPng;
  late final _IntPtrDart _cairoSurfaceStatus;
  late final _VoidPtrIntDart _cairoSetOperator;
  late final _VoidPtrDoubleDoubleDoubleDoubleDart _cairoSetSourceRgba;
  late final _VoidPtrDart _cairoPaint;
  late final _VoidPtrDoubleDoubleDart _cairoMoveTo;

  late final _PtrPtrDart _pangoCairoCreateLayout;
  late final _VoidPtrPtrDart _pangoCairoShowLayout;
  late final _Ptr0Dart _pangoCairoFontMapGetDefault;
  late final _VoidPtrDart _pangoFcFontMapConfigChanged;
  late final _Ptr0Dart _pangoFontDescriptionNew;
  late final _VoidPtrCStringDart _pangoFontDescriptionSetFamily;
  late final _VoidPtrDoubleDart _pangoFontDescriptionSetAbsoluteSize;
  late final _VoidPtrDart _pangoFontDescriptionFree;
  late final _VoidPtrCStringIntDart _pangoLayoutSetText;
  late final _VoidPtrPtrDart _pangoLayoutSetFontDescription;
  late final _Ptr0Dart _pangoAttrListNew;
  late final _PtrCStringDart _pangoAttrFontFeaturesNew;
  late final _VoidPtrPtrDart _pangoAttrListInsert;
  late final _VoidPtrPtrDart _pangoLayoutSetAttributes;
  late final _VoidPtrDart _pangoAttrListUnref;
  late final _VoidPtrRectRectDart _pangoLayoutGetPixelExtents;
  late final _VoidPtrDart _gObjectUnref;

  late final _Int0Dart _fcInit;
  late final _Ptr0Dart _fcConfigGetCurrent;
  late final _IntPtrCStringDart _fcConfigAppFontAddFile;
  late final _IntPtrDart _fcConfigBuildFonts;

  final Set<String> _registeredFonts = <String>{};

  _NativeTextBackend._() {
    _libc = _openLibrary(<String>[
      if (Platform.isLinux) 'libc.so.6',
      if (Platform.isMacOS) '/usr/lib/libSystem.B.dylib',
      if (Platform.isWindows) 'msvcrt.dll',
    ], 'C runtime');
    _cairo = _openLibrary(<String>[
      if (Platform.isLinux) 'libcairo.so.2',
      if (Platform.isMacOS) 'libcairo.2.dylib',
      if (Platform.isWindows) 'libcairo-2.dll',
    ], 'Cairo');
    _pango = _openLibrary(<String>[
      if (Platform.isLinux) 'libpango-1.0.so.0',
      if (Platform.isMacOS) 'libpango-1.0.0.dylib',
      if (Platform.isWindows) 'libpango-1.0-0.dll',
    ], 'Pango');
    _pangoCairo = _openLibrary(<String>[
      if (Platform.isLinux) 'libpangocairo-1.0.so.0',
      if (Platform.isMacOS) 'libpangocairo-1.0.0.dylib',
      if (Platform.isWindows) 'libpangocairo-1.0-0.dll',
    ], 'PangoCairo');
    _pangoFt2 = _openLibrary(<String>[
      if (Platform.isLinux) 'libpangoft2-1.0.so.0',
      if (Platform.isMacOS) 'libpangoft2-1.0.0.dylib',
      if (Platform.isWindows) 'libpangoft2-1.0-0.dll',
    ], 'PangoFT2');
    _fontconfig = _openLibrary(<String>[
      if (Platform.isLinux) 'libfontconfig.so.1',
      if (Platform.isMacOS) 'libfontconfig.1.dylib',
      if (Platform.isWindows) 'libfontconfig-1.dll',
    ], 'Fontconfig');
    _gobject = _openLibrary(<String>[
      if (Platform.isLinux) 'libgobject-2.0.so.0',
      if (Platform.isMacOS) 'libgobject-2.0.0.dylib',
      if (Platform.isWindows) 'libgobject-2.0-0.dll',
    ], 'GObject');

    _malloc = _libc.lookupFunction<_MallocNative, _MallocDart>('malloc');
    _free = _libc.lookupFunction<_FreeNative, _FreeDart>('free');

    _cairoImageSurfaceCreate = _cairo.lookupFunction<
        _PtrIntIntIntNative, _PtrIntIntIntDart>('cairo_image_surface_create');
    _cairoSvgSurfaceCreate = _cairo.lookupFunction<
        _PtrCStringDoubleDoubleNative,
        _PtrCStringDoubleDoubleDart>('cairo_svg_surface_create');
    _cairoPdfSurfaceCreate = _cairo.lookupFunction<
        _PtrCStringDoubleDoubleNative,
        _PtrCStringDoubleDoubleDart>('cairo_pdf_surface_create');
    _cairoCreate = _cairo.lookupFunction<_PtrPtrNative, _PtrPtrDart>('cairo_create');
    _cairoDestroy = _cairo.lookupFunction<_VoidPtrNative, _VoidPtrDart>('cairo_destroy');
    _cairoSurfaceDestroy = _cairo.lookupFunction<_VoidPtrNative, _VoidPtrDart>('cairo_surface_destroy');
    _cairoSurfaceFinish = _cairo.lookupFunction<_VoidPtrNative, _VoidPtrDart>('cairo_surface_finish');
    _cairoSurfaceWriteToPng = _cairo.lookupFunction<
        _IntPtrCStringNative, _IntPtrCStringDart>('cairo_surface_write_to_png');
    _cairoSurfaceStatus = _cairo.lookupFunction<_IntPtrNative, _IntPtrDart>('cairo_surface_status');
    _cairoSetOperator = _cairo.lookupFunction<_VoidPtrIntNative, _VoidPtrIntDart>('cairo_set_operator');
    _cairoSetSourceRgba = _cairo.lookupFunction<
        _VoidPtrDoubleDoubleDoubleDoubleNative,
        _VoidPtrDoubleDoubleDoubleDoubleDart>('cairo_set_source_rgba');
    _cairoPaint = _cairo.lookupFunction<_VoidPtrNative, _VoidPtrDart>('cairo_paint');
    _cairoMoveTo = _cairo.lookupFunction<
        _VoidPtrDoubleDoubleNative, _VoidPtrDoubleDoubleDart>('cairo_move_to');

    _pangoCairoCreateLayout = _pangoCairo.lookupFunction<
        _PtrPtrNative, _PtrPtrDart>('pango_cairo_create_layout');
    _pangoCairoShowLayout = _pangoCairo.lookupFunction<
        _VoidPtrPtrNative, _VoidPtrPtrDart>('pango_cairo_show_layout');
    _pangoCairoFontMapGetDefault = _pangoCairo.lookupFunction<
        _Ptr0Native, _Ptr0Dart>('pango_cairo_font_map_get_default');
    _pangoFcFontMapConfigChanged = _pangoFt2.lookupFunction<
        _VoidPtrNative, _VoidPtrDart>('pango_fc_font_map_config_changed');
    _pangoFontDescriptionNew = _pango.lookupFunction<_Ptr0Native, _Ptr0Dart>('pango_font_description_new');
    _pangoFontDescriptionSetFamily = _pango.lookupFunction<
        _VoidPtrCStringNative, _VoidPtrCStringDart>('pango_font_description_set_family');
    _pangoFontDescriptionSetAbsoluteSize = _pango.lookupFunction<
        _VoidPtrDoubleNative,
        _VoidPtrDoubleDart>('pango_font_description_set_absolute_size');
    _pangoFontDescriptionFree = _pango.lookupFunction<
        _VoidPtrNative, _VoidPtrDart>('pango_font_description_free');
    _pangoLayoutSetText = _pango.lookupFunction<
        _VoidPtrCStringIntNative, _VoidPtrCStringIntDart>('pango_layout_set_text');
    _pangoLayoutSetFontDescription = _pango.lookupFunction<
        _VoidPtrPtrNative, _VoidPtrPtrDart>('pango_layout_set_font_description');
    _pangoAttrListNew = _pango.lookupFunction<_Ptr0Native, _Ptr0Dart>('pango_attr_list_new');
    _pangoAttrFontFeaturesNew = _pango.lookupFunction<
        _PtrCStringNative, _PtrCStringDart>('pango_attr_font_features_new');
    _pangoAttrListInsert = _pango.lookupFunction<
        _VoidPtrPtrNative, _VoidPtrPtrDart>('pango_attr_list_insert');
    _pangoLayoutSetAttributes = _pango.lookupFunction<
        _VoidPtrPtrNative, _VoidPtrPtrDart>('pango_layout_set_attributes');
    _pangoAttrListUnref = _pango.lookupFunction<_VoidPtrNative, _VoidPtrDart>('pango_attr_list_unref');
    _pangoLayoutGetPixelExtents = _pango.lookupFunction<
        _VoidPtrRectRectNative,
        _VoidPtrRectRectDart>('pango_layout_get_pixel_extents');
    _gObjectUnref = _gobject.lookupFunction<_VoidPtrNative, _VoidPtrDart>('g_object_unref');

    _fcInit = _fontconfig.lookupFunction<_Int0Native, _Int0Dart>('FcInit');
    _fcConfigGetCurrent = _fontconfig.lookupFunction<_Ptr0Native, _Ptr0Dart>('FcConfigGetCurrent');
    _fcConfigAppFontAddFile = _fontconfig.lookupFunction<
        _IntPtrCStringNative, _IntPtrCStringDart>('FcConfigAppFontAddFile');
    _fcConfigBuildFonts = _fontconfig.lookupFunction<
        _IntPtrNative, _IntPtrDart>('FcConfigBuildFonts');

    if (_fcInit() == 0) {
      throw StateError('Fontconfig initialization failed');
    }
  }

  static DynamicLibrary _openLibrary(List<String> candidates, String label) {
    Object? last;
    for (final name in candidates) {
      if (name.isEmpty) continue;
      try {
        return DynamicLibrary.open(name);
      } catch (error) {
        last = error;
      }
    }
    throw UnsupportedError(
      'nanpa-linja-n production rendering requires $label. '
      'No supported native library was found on ${Platform.operatingSystem}. '
      'Last error: $last',
    );
  }

  Pointer<Uint8> _cString(String value) {
    final bytes = utf8.encode(value);
    final p = _malloc(bytes.length + 1).cast<Uint8>();
    if (p == nullptr) throw StateError('Native memory allocation failed');
    final buffer = p.asTypedList(bytes.length + 1);
    buffer.setRange(0, bytes.length, bytes);
    buffer[bytes.length] = 0;
    return p;
  }

  T _withCString<T>(String value, T Function(Pointer<Uint8>) fn) {
    final p = _cString(value);
    try {
      return fn(p);
    } finally {
      _free(p.cast<Void>());
    }
  }

  void registerFont(String path) {
    final absolute = File(path).absolute.path;
    if (_registeredFonts.contains(absolute)) return;
    if (!File(absolute).existsSync()) {
      throw FileSystemException('Production font asset does not exist', absolute);
    }
    final config = _fcConfigGetCurrent();
    if (config == nullptr) throw StateError('Fontconfig did not return a current configuration');
    final ok = _withCString<int>(absolute, (p) => _fcConfigAppFontAddFile(config, p));
    if (ok == 0) {
      throw StateError('Fontconfig failed to register production font: $absolute');
    }
    if (_fcConfigBuildFonts(config) == 0) {
      throw StateError('Fontconfig failed to rebuild its application font set');
    }
    // PangoCairo's default PangoFcFontMap caches Fontconfig state. Notify it
    // whenever a new application font is added so switching production font
    // pairs after the first render cannot resolve through a stale cache.
    final fontMap = _pangoCairoFontMapGetDefault();
    if (fontMap == nullptr) {
      throw StateError('PangoCairo did not return a default font map');
    }
    _pangoFcFontMapConfigChanged(fontMap);
    _registeredFonts.add(absolute);
  }

  _LayoutMetrics _measure({
    required String text,
    required String family,
    required int fontSize,
    required List<String> features,
  }) {
    final surface = _cairoImageSurfaceCreate(0, 1, 1); // CAIRO_FORMAT_ARGB32
    if (surface == nullptr) throw StateError('Cairo failed to create measurement surface');
    final cr = _cairoCreate(surface);
    if (cr == nullptr) {
      _cairoSurfaceDestroy(surface);
      throw StateError('Cairo failed to create measurement context');
    }
    try {
      final layout = _createLayout(
        cr: cr,
        text: text,
        family: family,
        fontSize: fontSize,
        features: features,
      );
      try {
        final ink = _malloc(sizeOf<_PangoRectangle>()).cast<_PangoRectangle>();
        if (ink == nullptr) throw StateError('Native memory allocation failed');
        try {
          _pangoLayoutGetPixelExtents(
            layout,
            ink,
            nullptr.cast<_PangoRectangle>(),
          );
          final r = ink.ref;
          return _LayoutMetrics(r.x, r.y, r.width, r.height);
        } finally {
          _free(ink.cast<Void>());
        }
      } finally {
        _gObjectUnref(layout);
      }
    } finally {
      _cairoDestroy(cr);
      _cairoSurfaceDestroy(surface);
    }
  }

  Pointer<Void> _createLayout({
    required Pointer<Void> cr,
    required String text,
    required String family,
    required int fontSize,
    required List<String> features,
  }) {
    final layout = _pangoCairoCreateLayout(cr);
    if (layout == nullptr) throw StateError('Pango failed to create a layout');
    final desc = _pangoFontDescriptionNew();
    if (desc == nullptr) {
      _gObjectUnref(layout);
      throw StateError('Pango failed to create a font description');
    }
    try {
      _withCString<void>(family, (p) => _pangoFontDescriptionSetFamily(desc, p));
      _pangoFontDescriptionSetAbsoluteSize(desc, fontSize * 1024.0);
      _pangoLayoutSetFontDescription(layout, desc);
      _withCString<void>(text, (p) => _pangoLayoutSetText(layout, p, -1));

      if (features.isNotEmpty) {
        final attrs = _pangoAttrListNew();
        if (attrs == nullptr) throw StateError('Pango failed to create an attribute list');
        try {
          final featureText = features.map((e) => '$e=1').join(',');
          final attr = _withCString<Pointer<Void>>(
            featureText,
            (p) => _pangoAttrFontFeaturesNew(p),
          );
          if (attr == nullptr) throw StateError('Pango rejected OpenType feature settings');
          _pangoAttrListInsert(attrs, attr); // ownership transfers to the list
          _pangoLayoutSetAttributes(layout, attrs);
        } finally {
          _pangoAttrListUnref(attrs);
        }
      }
      return layout;
    } catch (_) {
      _gObjectUnref(layout);
      rethrow;
    } finally {
      _pangoFontDescriptionFree(desc);
    }
  }

  NativeRenderedBytes render({
    required String text,
    required String family,
    required String fontPath,
    required int fontSize,
    required List<String> features,
    required int padding,
    required ProductionOutputFormat format,
    required ProductionRgba foreground,
    required ProductionRgba background,
  }) {
    registerFont(fontPath);
    final metrics = _measure(
      text: text,
      family: family,
      fontSize: fontSize,
      features: features,
    );
    final safePadding = padding < 0 ? 0 : padding;
    final width = (metrics.width <= 0 ? 1 : metrics.width) + safePadding * 2;
    final height = (metrics.height <= 0 ? 1 : metrics.height) + safePadding * 2;

    final tempDir = Directory.systemTemp.createTempSync('nanpa_linja_n_dart_');
    final extension = format.name;
    final target = File('${tempDir.path}${Platform.pathSeparator}render.$extension');
    Pointer<Void> surface = nullptr;
    Pointer<Void> cr = nullptr;
    try {
      switch (format) {
        case ProductionOutputFormat.png:
          surface = _cairoImageSurfaceCreate(0, width, height);
          break;
        case ProductionOutputFormat.svg:
          surface = _withCString<Pointer<Void>>(
            target.path,
            (p) => _cairoSvgSurfaceCreate(p, width.toDouble(), height.toDouble()),
          );
          break;
        case ProductionOutputFormat.pdf:
          surface = _withCString<Pointer<Void>>(
            target.path,
            (p) => _cairoPdfSurfaceCreate(p, width.toDouble(), height.toDouble()),
          );
          break;
      }
      if (surface == nullptr || _cairoSurfaceStatus(surface) != 0) {
        throw StateError('Cairo failed to create ${format.name.toUpperCase()} surface');
      }
      cr = _cairoCreate(surface);
      if (cr == nullptr) throw StateError('Cairo failed to create rendering context');

      // Paint the requested background with SOURCE so transparent output is deterministic.
      _cairoSetOperator(cr, 1); // CAIRO_OPERATOR_SOURCE
      _cairoSetSourceRgba(cr, background.red, background.green, background.blue, background.alpha);
      _cairoPaint(cr);
      _cairoSetOperator(cr, 2); // CAIRO_OPERATOR_OVER
      _cairoSetSourceRgba(cr, foreground.red, foreground.green, foreground.blue, foreground.alpha);

      final layout = _createLayout(
        cr: cr,
        text: text,
        family: family,
        fontSize: fontSize,
        features: features,
      );
      try {
        _cairoMoveTo(
          cr,
          (safePadding - metrics.x).toDouble(),
          (safePadding - metrics.y).toDouble(),
        );
        _pangoCairoShowLayout(cr, layout);
      } finally {
        _gObjectUnref(layout);
      }

      if (format == ProductionOutputFormat.png) {
        final status = _withCString<int>(
          target.path,
          (p) => _cairoSurfaceWriteToPng(surface, p),
        );
        if (status != 0) throw StateError('Cairo PNG encoding failed with status $status');
      }
      _cairoSurfaceFinish(surface);
      final bytes = target.readAsBytesSync();
      if (bytes.isEmpty) throw StateError('${format.name.toUpperCase()} renderer produced no bytes');
      return NativeRenderedBytes(
        bytes: Uint8List.fromList(bytes),
        width: width,
        height: height,
        format: format,
      );
    } finally {
      if (cr != nullptr) _cairoDestroy(cr);
      if (surface != nullptr) _cairoSurfaceDestroy(surface);
      try {
        tempDir.deleteSync(recursive: true);
      } catch (_) {}
    }
  }
}

class _LayoutMetrics {
  final int x;
  final int y;
  final int width;
  final int height;
  const _LayoutMetrics(this.x, this.y, this.width, this.height);
}

NativeRenderedBytes renderProductionTextNative({
  required String text,
  required String family,
  required String fontPath,
  required int fontSize,
  required List<String> features,
  required int padding,
  required ProductionOutputFormat format,
  ProductionRgba foreground = ProductionRgba.black,
  ProductionRgba background = ProductionRgba.transparent,
}) =>
    _NativeTextBackend.instance.render(
      text: text,
      family: family,
      fontPath: fontPath,
      fontSize: fontSize,
      features: features,
      padding: padding,
      format: format,
      foreground: foreground,
      background: background,
    );
