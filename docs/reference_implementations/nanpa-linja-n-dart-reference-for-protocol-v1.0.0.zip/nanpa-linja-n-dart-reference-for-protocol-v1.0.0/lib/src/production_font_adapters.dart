import 'constants.dart';

const int _colonCodepoint = 0xF199D;

const Set<String> _legacyAsciiAdapters = <String>{
  'linja-pona-legacy-v1',
  'linja-sike-legacy-v1',
};

class AdaptedProductionRun {
  final String text;
  final String adapterId;
  final List<int> canonicalCodepoints;
  final bool legacyAscii;

  const AdaptedProductionRun({
    required this.text,
    required this.adapterId,
    required this.canonicalCodepoints,
    required this.legacyAscii,
  });
}

AdaptedProductionRun adaptProductionNumericCartouche(
  Iterable<int> codepoints,
  String renderAdapterId,
) {
  final cps = List<int>.unmodifiable(codepoints.map((e) => e.toInt()));
  final adapterId = renderAdapterId.trim().isEmpty ? 'identity' : renderAdapterId.trim();
  if (_legacyAsciiAdapters.contains(adapterId)) {
    if (cps.length < 2 || cps.first != cartoucheStart || cps.last != cartoucheEnd) {
      throw ArgumentError('$adapterId requires a complete canonical cartouche');
    }
    final out = StringBuffer('[');
    for (final cp in cps.sublist(1, cps.length - 1)) {
      // The production legacy-linja syntax uses a literal ASCII colon inside
      // numeric cartouches.  The canonical UCSUR colon must not be rendered
      // as the Toki Pona word "kolon" here.
      final word = cp == _colonCodepoint ? ':' : allCodepointWords[cp];
      if (word == null) {
        throw StateError(
          '$adapterId has no legacy numeric encoding for '
          'U+${cp.toRadixString(16).toUpperCase().padLeft(4, '0')}',
        );
      }
      out
        ..write('_')
        ..write(word);
    }
    out.write(']');
    return AdaptedProductionRun(
      text: out.toString(),
      adapterId: adapterId,
      canonicalCodepoints: cps,
      legacyAscii: true,
    );
  }
  return AdaptedProductionRun(
    text: String.fromCharCodes(cps),
    adapterId: adapterId,
    canonicalCodepoints: cps,
    legacyAscii: false,
  );
}

List<String> productionOpenTypeFeaturesForSize(int fontSize) {
  final features = <String>['calt', 'liga', 'ccmp'];
  if (fontSize > 0 && fontSize <= 18) {
    features.add('ss12');
  } else if (fontSize <= 29) {
    features.add('ss13');
  }
  return List<String>.unmodifiable(features);
}
