import 'dart:convert';
import 'dart:ffi';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'native_production_renderer.dart'
    show ProductionOutputFormat, ProductionRgba;

final class _PangoRectangle extends Struct {
  @Int32()
  external int x;
  @Int32()
  external int y;
  @Int32()
  external int width;
  @Int32()
  external int height;
}

typedef _MallocNative = Pointer<Void> Function(IntPtr);
typedef _MallocDart = Pointer<Void> Function(int);
typedef _FreeNative = Void Function(Pointer<Void>);
typedef _FreeDart = void Function(Pointer<Void>);
typedef _Ptr0Native = Pointer<Void> Function();
typedef _Ptr0Dart = Pointer<Void> Function();
typedef _PtrIntIntIntNative = Pointer<Void> Function(Int32, Int32, Int32);
typedef _PtrIntIntIntDart = Pointer<Void> Function(int, int, int);
typedef _PtrPtrNative = Pointer<Void> Function(Pointer<Void>);
typedef _PtrPtrDart = Pointer<Void> Function(Pointer<Void>);
typedef _VoidPtrNative = Void Function(Pointer<Void>);
typedef _VoidPtrDart = void Function(Pointer<Void>);
typedef _IntPtrNative = Int32 Function(Pointer<Void>);
typedef _IntPtrDart = int Function(Pointer<Void>);
typedef _VoidPtrIntNative = Void Function(Pointer<Void>, Int32);
typedef _VoidPtrIntDart = void Function(Pointer<Void>, int);
typedef _VoidPtrDoubleNative = Void Function(Pointer<Void>, Double);
typedef _VoidPtrDoubleDart = void Function(Pointer<Void>, double);
typedef _VoidPtrDoubleDoubleNative = Void Function(Pointer<Void>, Double, Double);
typedef _VoidPtrDoubleDoubleDart = void Function(Pointer<Void>, double, double);
typedef _VoidPtrDoubleDoubleDoubleDoubleNative =
    Void Function(Pointer<Void>, Double, Double, Double, Double);
typedef _VoidPtrDoubleDoubleDoubleDoubleDart =
    void Function(Pointer<Void>, double, double, double, double);
typedef _PtrCStringDoubleDoubleNative =
    Pointer<Void> Function(Pointer<Uint8>, Double, Double);
typedef _PtrCStringDoubleDoubleDart =
    Pointer<Void> Function(Pointer<Uint8>, double, double);
typedef _IntPtrCStringNative = Int32 Function(Pointer<Void>, Pointer<Uint8>);
typedef _IntPtrCStringDart = int Function(Pointer<Void>, Pointer<Uint8>);
typedef _VoidPtrCStringIntNative =
    Void Function(Pointer<Void>, Pointer<Uint8>, Int32);
typedef _VoidPtrCStringIntDart =
    void Function(Pointer<Void>, Pointer<Uint8>, int);
typedef _VoidPtrCStringNative = Void Function(Pointer<Void>, Pointer<Uint8>);
typedef _VoidPtrCStringDart = void Function(Pointer<Void>, Pointer<Uint8>);
typedef _VoidPtrPtrNative = Void Function(Pointer<Void>, Pointer<Void>);
typedef _VoidPtrPtrDart = void Function(Pointer<Void>, Pointer<Void>);
typedef _PtrCStringNative = Pointer<Void> Function(Pointer<Uint8>);
typedef _PtrCStringDart = Pointer<Void> Function(Pointer<Uint8>);
typedef _VoidPtrRectRectNative = Void Function(
  Pointer<Void>,
  Pointer<_PangoRectangle>,
  Pointer<_PangoRectangle>,
);
typedef _VoidPtrRectRectDart = void Function(
  Pointer<Void>,
  Pointer<_PangoRectangle>,
  Pointer<_PangoRectangle>,
);
typedef _IntPtrNoArgNative = Int32 Function(Pointer<Void>);
typedef _IntPtrNoArgDart = int Function(Pointer<Void>);
typedef _VoidPtrIndexRectNative =
    Void Function(Pointer<Void>, Int32, Pointer<_PangoRectangle>);
typedef _VoidPtrIndexRectDart =
    void Function(Pointer<Void>, int, Pointer<_PangoRectangle>);
typedef _PtrCStringOnlyNative = Pointer<Void> Function(Pointer<Uint8>);
typedef _PtrCStringOnlyDart = Pointer<Void> Function(Pointer<Uint8>);
typedef _VoidPtrPtrDoubleDoubleNative =
    Void Function(Pointer<Void>, Pointer<Void>, Double, Double);
typedef _VoidPtrPtrDoubleDoubleDart =
    void Function(Pointer<Void>, Pointer<Void>, double, double);
typedef _VoidPtrFourDoubleNative =
    Void Function(Pointer<Void>, Double, Double, Double, Double);
typedef _VoidPtrFourDoubleDart =
    void Function(Pointer<Void>, double, double, double, double);
typedef _VoidPtrFiveDoubleNative =
    Void Function(Pointer<Void>, Double, Double, Double, Double, Double);
typedef _VoidPtrFiveDoubleDart =
    void Function(Pointer<Void>, double, double, double, double, double);
typedef _IntSurfaceNative = Int32 Function(Pointer<Void>);
typedef _IntSurfaceDart = int Function(Pointer<Void>);

class FullTextMetrics {
  final int inkX;
  final int inkY;
  final int inkWidth;
  final int inkHeight;
  final double baseline;
  const FullTextMetrics(
    this.inkX,
    this.inkY,
    this.inkWidth,
    this.inkHeight,
    this.baseline,
  );
}

sealed class NativeFullOp {
  const NativeFullOp();
}

class NativeFullTextOp extends NativeFullOp {
  final String text;
  final String family;
  final String fontPath;
  final double fontSize;
  final List<String> features;
  final double x;
  final double y;
  final ProductionRgba color;
  final bool halo;
  final ProductionRgba haloColor;
  final double haloWidth;
  const NativeFullTextOp({
    required this.text,
    required this.family,
    required this.fontPath,
    required this.fontSize,
    this.features = const <String>[],
    required this.x,
    required this.y,
    this.color = ProductionRgba.black,
    this.halo = false,
    this.haloColor = const ProductionRgba(255, 255, 255, 255),
    this.haloWidth = 0,
  });
}

class NativeFullLineOp extends NativeFullOp {
  final double x1;
  final double y1;
  final double x2;
  final double y2;
  final double width;
  final ProductionRgba color;
  final bool halo;
  final ProductionRgba haloColor;
  final double haloWidth;
  const NativeFullLineOp({
    required this.x1,
    required this.y1,
    required this.x2,
    required this.y2,
    required this.width,
    this.color = ProductionRgba.black,
    this.halo = false,
    this.haloColor = const ProductionRgba(255, 255, 255, 255),
    this.haloWidth = 0,
  });
}

class NativeFullRoundedRectOp extends NativeFullOp {
  final double x;
  final double y;
  final double width;
  final double height;
  final double radius;
  final ProductionRgba color;
  const NativeFullRoundedRectOp({
    required this.x,
    required this.y,
    required this.width,
    required this.height,
    required this.radius,
    required this.color,
  });
}

class NativeFullRectOp extends NativeFullOp {
  final double x;
  final double y;
  final double width;
  final double height;
  final double lineWidth;
  final ProductionRgba color;
  const NativeFullRectOp({
    required this.x,
    required this.y,
    required this.width,
    required this.height,
    this.lineWidth = 1,
    this.color = ProductionRgba.black,
  });
}

class NativeFullImageOp extends NativeFullOp {
  final Uint8List pngBytes;
  final double x;
  final double y;
  final double width;
  final double height;
  const NativeFullImageOp({
    required this.pngBytes,
    required this.x,
    required this.y,
    required this.width,
    required this.height,
  });
}

class NativeFullRenderedBytes {
  final Uint8List bytes;
  final int width;
  final int height;
  final ProductionOutputFormat format;
  const NativeFullRenderedBytes({
    required this.bytes,
    required this.width,
    required this.height,
    required this.format,
  });
}

class _FullLayoutHandle {
  final Pointer<Void> layout;
  final Pointer<Void> context;
  final Pointer<Void> fontMap;
  final Pointer<Void> config;
  const _FullLayoutHandle({
    required this.layout,
    required this.context,
    required this.fontMap,
    required this.config,
  });
}

class _NativeFullBackend {
  static _NativeFullBackend? _instance;
  static _NativeFullBackend get instance =>
      _instance ??= _NativeFullBackend._();

  late final DynamicLibrary _libc;
  late final DynamicLibrary _cairo;
  late final DynamicLibrary _pango;
  late final DynamicLibrary _pangoCairo;
  late final DynamicLibrary _pangoFt2;
  late final DynamicLibrary _fontconfig;
  late final DynamicLibrary _gobject;

  late final _MallocDart _malloc;
  late final _FreeDart _free;
  late final _PtrIntIntIntDart _cairoImageSurfaceCreate;
  late final _PtrCStringDoubleDoubleDart _cairoSvgSurfaceCreate;
  late final _PtrCStringDoubleDoubleDart _cairoPdfSurfaceCreate;
  late final _PtrCStringOnlyDart _cairoImageSurfaceCreateFromPng;
  late final _IntSurfaceDart _cairoImageSurfaceGetWidth;
  late final _IntSurfaceDart _cairoImageSurfaceGetHeight;
  late final _PtrPtrDart _cairoCreate;
  late final _VoidPtrDart _cairoDestroy;
  late final _VoidPtrDart _cairoSurfaceDestroy;
  late final _VoidPtrDart _cairoSurfaceFinish;
  late final _VoidPtrDart _cairoPaint;
  late final _VoidPtrDart _cairoStroke;
  late final _VoidPtrDart _cairoFill;
  late final _VoidPtrDart _cairoClosePath;
  late final _VoidPtrDart _cairoSave;
  late final _VoidPtrDart _cairoRestore;
  late final _IntPtrDart _cairoSurfaceStatus;
  late final _IntPtrCStringDart _cairoSurfaceWriteToPng;
  late final _VoidPtrIntDart _cairoSetOperator;
  late final _VoidPtrIntDart _cairoSetLineCap;
  late final _VoidPtrIntDart _cairoSetLineJoin;
  late final _VoidPtrDoubleDoubleDoubleDoubleDart _cairoSetSourceRgba;
  late final _VoidPtrDoubleDoubleDart _cairoMoveTo;
  late final _VoidPtrDoubleDoubleDart _cairoLineTo;
  late final _VoidPtrDoubleDoubleDart _cairoTranslate;
  late final _VoidPtrDoubleDoubleDart _cairoScale;
  late final _VoidPtrDoubleDart _cairoSetLineWidth;
  late final _VoidPtrPtrDoubleDoubleDart _cairoSetSourceSurface;
  late final _VoidPtrFourDoubleDart _cairoRectangle;
  late final _VoidPtrFiveDoubleDart _cairoArc;

  late final _VoidPtrPtrDart _pangoCairoShowLayout;
  late final _VoidPtrPtrDart _pangoCairoLayoutPath;
  late final _Ptr0Dart _pangoCairoFontMapNew;
  late final _PtrPtrDart _pangoFontMapCreateContext;
  late final _PtrPtrDart _pangoLayoutNew;
  late final _VoidPtrPtrDart _pangoFcFontMapSetConfig;
  late final _Ptr0Dart _pangoFontDescriptionNew;
  late final _VoidPtrCStringDart _pangoFontDescriptionSetFamily;
  late final _VoidPtrDoubleDart _pangoFontDescriptionSetAbsoluteSize;
  late final _VoidPtrDart _pangoFontDescriptionFree;
  late final _VoidPtrCStringIntDart _pangoLayoutSetText;
  late final _VoidPtrPtrDart _pangoLayoutSetFontDescription;
  late final _Ptr0Dart _pangoAttrListNew;
  late final _PtrCStringDart _pangoAttrFontFeaturesNew;
  late final _VoidPtrPtrDart _pangoAttrListInsert;
  late final _VoidPtrPtrDart _pangoLayoutSetAttributes;
  late final _VoidPtrDart _pangoAttrListUnref;
  late final _VoidPtrRectRectDart _pangoLayoutGetPixelExtents;
  late final _IntPtrNoArgDart _pangoLayoutGetBaseline;
  late final _VoidPtrIndexRectDart _pangoLayoutIndexToPos;
  late final _VoidPtrDart _gObjectUnref;

  late final _Ptr0Dart _fcConfigCreate;
  late final _IntPtrCStringDart _fcConfigAppFontAddFile;
  late final _IntPtrDart _fcConfigBuildFonts;
  late final _VoidPtrDart _fcConfigDestroy;

  _NativeFullBackend._() {
    _libc = _open(
      <String>[
        if (Platform.isLinux) 'libc.so.6',
        if (Platform.isMacOS) '/usr/lib/libSystem.B.dylib',
        if (Platform.isWindows) 'msvcrt.dll',
      ],
      'C runtime',
    );
    _cairo = _open(
      <String>[
        if (Platform.isLinux) 'libcairo.so.2',
        if (Platform.isMacOS) 'libcairo.2.dylib',
        if (Platform.isWindows) 'libcairo-2.dll',
      ],
      'Cairo',
    );
    _pango = _open(
      <String>[
        if (Platform.isLinux) 'libpango-1.0.so.0',
        if (Platform.isMacOS) 'libpango-1.0.0.dylib',
        if (Platform.isWindows) 'libpango-1.0-0.dll',
      ],
      'Pango',
    );
    _pangoCairo = _open(
      <String>[
        if (Platform.isLinux) 'libpangocairo-1.0.so.0',
        if (Platform.isMacOS) 'libpangocairo-1.0.0.dylib',
        if (Platform.isWindows) 'libpangocairo-1.0-0.dll',
      ],
      'PangoCairo',
    );
    _pangoFt2 = _open(
      <String>[
        if (Platform.isLinux) 'libpangoft2-1.0.so.0',
        if (Platform.isMacOS) 'libpangoft2-1.0.0.dylib',
        if (Platform.isWindows) 'libpangoft2-1.0-0.dll',
      ],
      'PangoFT2',
    );
    _fontconfig = _open(
      <String>[
        if (Platform.isLinux) 'libfontconfig.so.1',
        if (Platform.isMacOS) 'libfontconfig.1.dylib',
        if (Platform.isWindows) 'libfontconfig-1.dll',
      ],
      'Fontconfig',
    );
    _gobject = _open(
      <String>[
        if (Platform.isLinux) 'libgobject-2.0.so.0',
        if (Platform.isMacOS) 'libgobject-2.0.0.dylib',
        if (Platform.isWindows) 'libgobject-2.0-0.dll',
      ],
      'GObject',
    );

    _malloc = _libc.lookupFunction<_MallocNative, _MallocDart>('malloc');
    _free = _libc.lookupFunction<_FreeNative, _FreeDart>('free');
    _cairoImageSurfaceCreate = _cairo.lookupFunction<
        _PtrIntIntIntNative,
        _PtrIntIntIntDart>('cairo_image_surface_create');
    _cairoSvgSurfaceCreate = _cairo.lookupFunction<
        _PtrCStringDoubleDoubleNative,
        _PtrCStringDoubleDoubleDart>('cairo_svg_surface_create');
    _cairoPdfSurfaceCreate = _cairo.lookupFunction<
        _PtrCStringDoubleDoubleNative,
        _PtrCStringDoubleDoubleDart>('cairo_pdf_surface_create');
    _cairoImageSurfaceCreateFromPng = _cairo.lookupFunction<
        _PtrCStringOnlyNative,
        _PtrCStringOnlyDart>('cairo_image_surface_create_from_png');
    _cairoImageSurfaceGetWidth = _cairo.lookupFunction<
        _IntSurfaceNative,
        _IntSurfaceDart>('cairo_image_surface_get_width');
    _cairoImageSurfaceGetHeight = _cairo.lookupFunction<
        _IntSurfaceNative,
        _IntSurfaceDart>('cairo_image_surface_get_height');
    _cairoCreate =
        _cairo.lookupFunction<_PtrPtrNative, _PtrPtrDart>('cairo_create');
    _cairoDestroy =
        _cairo.lookupFunction<_VoidPtrNative, _VoidPtrDart>('cairo_destroy');
    _cairoSurfaceDestroy = _cairo.lookupFunction<_VoidPtrNative, _VoidPtrDart>(
        'cairo_surface_destroy');
    _cairoSurfaceFinish = _cairo.lookupFunction<_VoidPtrNative, _VoidPtrDart>(
        'cairo_surface_finish');
    _cairoSurfaceStatus = _cairo.lookupFunction<_IntPtrNative, _IntPtrDart>(
        'cairo_surface_status');
    _cairoSurfaceWriteToPng = _cairo.lookupFunction<
        _IntPtrCStringNative,
        _IntPtrCStringDart>('cairo_surface_write_to_png');
    _cairoSetOperator = _cairo.lookupFunction<_VoidPtrIntNative, _VoidPtrIntDart>(
        'cairo_set_operator');
    _cairoSetSourceRgba = _cairo.lookupFunction<
        _VoidPtrDoubleDoubleDoubleDoubleNative,
        _VoidPtrDoubleDoubleDoubleDoubleDart>('cairo_set_source_rgba');
    _cairoPaint =
        _cairo.lookupFunction<_VoidPtrNative, _VoidPtrDart>('cairo_paint');
    _cairoMoveTo = _cairo.lookupFunction<
        _VoidPtrDoubleDoubleNative,
        _VoidPtrDoubleDoubleDart>('cairo_move_to');
    _cairoLineTo = _cairo.lookupFunction<
        _VoidPtrDoubleDoubleNative,
        _VoidPtrDoubleDoubleDart>('cairo_line_to');
    _cairoSetLineWidth = _cairo.lookupFunction<
        _VoidPtrDoubleNative,
        _VoidPtrDoubleDart>('cairo_set_line_width');
    _cairoSetLineCap = _cairo.lookupFunction<_VoidPtrIntNative, _VoidPtrIntDart>(
        'cairo_set_line_cap');
    _cairoSetLineJoin = _cairo.lookupFunction<_VoidPtrIntNative, _VoidPtrIntDart>(
        'cairo_set_line_join');
    _cairoStroke =
        _cairo.lookupFunction<_VoidPtrNative, _VoidPtrDart>('cairo_stroke');
    _cairoFill =
        _cairo.lookupFunction<_VoidPtrNative, _VoidPtrDart>('cairo_fill');
    _cairoClosePath =
        _cairo.lookupFunction<_VoidPtrNative, _VoidPtrDart>('cairo_close_path');
    _cairoSave =
        _cairo.lookupFunction<_VoidPtrNative, _VoidPtrDart>('cairo_save');
    _cairoRestore =
        _cairo.lookupFunction<_VoidPtrNative, _VoidPtrDart>('cairo_restore');
    _cairoTranslate = _cairo.lookupFunction<
        _VoidPtrDoubleDoubleNative,
        _VoidPtrDoubleDoubleDart>('cairo_translate');
    _cairoScale = _cairo.lookupFunction<
        _VoidPtrDoubleDoubleNative,
        _VoidPtrDoubleDoubleDart>('cairo_scale');
    _cairoSetSourceSurface = _cairo.lookupFunction<
        _VoidPtrPtrDoubleDoubleNative,
        _VoidPtrPtrDoubleDoubleDart>('cairo_set_source_surface');
    _cairoRectangle = _cairo.lookupFunction<
        _VoidPtrFourDoubleNative,
        _VoidPtrFourDoubleDart>('cairo_rectangle');
    _cairoArc = _cairo.lookupFunction<
        _VoidPtrFiveDoubleNative,
        _VoidPtrFiveDoubleDart>('cairo_arc');

    _pangoCairoShowLayout = _pangoCairo.lookupFunction<
        _VoidPtrPtrNative,
        _VoidPtrPtrDart>('pango_cairo_show_layout');
    _pangoCairoLayoutPath = _pangoCairo.lookupFunction<
        _VoidPtrPtrNative,
        _VoidPtrPtrDart>('pango_cairo_layout_path');
    _pangoCairoFontMapNew = _pangoCairo.lookupFunction<_Ptr0Native, _Ptr0Dart>(
        'pango_cairo_font_map_new');
    _pangoFontMapCreateContext = _pango.lookupFunction<
        _PtrPtrNative,
        _PtrPtrDart>('pango_font_map_create_context');
    _pangoLayoutNew =
        _pango.lookupFunction<_PtrPtrNative, _PtrPtrDart>('pango_layout_new');
    _pangoFcFontMapSetConfig = _pangoFt2.lookupFunction<
        _VoidPtrPtrNative,
        _VoidPtrPtrDart>('pango_fc_font_map_set_config');
    _pangoFontDescriptionNew = _pango.lookupFunction<_Ptr0Native, _Ptr0Dart>(
        'pango_font_description_new');
    _pangoFontDescriptionSetFamily = _pango.lookupFunction<
        _VoidPtrCStringNative,
        _VoidPtrCStringDart>('pango_font_description_set_family');
    _pangoFontDescriptionSetAbsoluteSize = _pango.lookupFunction<
        _VoidPtrDoubleNative,
        _VoidPtrDoubleDart>('pango_font_description_set_absolute_size');
    _pangoFontDescriptionFree = _pango.lookupFunction<
        _VoidPtrNative,
        _VoidPtrDart>('pango_font_description_free');
    _pangoLayoutSetText = _pango.lookupFunction<
        _VoidPtrCStringIntNative,
        _VoidPtrCStringIntDart>('pango_layout_set_text');
    _pangoLayoutSetFontDescription = _pango.lookupFunction<
        _VoidPtrPtrNative,
        _VoidPtrPtrDart>('pango_layout_set_font_description');
    _pangoAttrListNew =
        _pango.lookupFunction<_Ptr0Native, _Ptr0Dart>('pango_attr_list_new');
    _pangoAttrFontFeaturesNew = _pango.lookupFunction<
        _PtrCStringNative,
        _PtrCStringDart>('pango_attr_font_features_new');
    _pangoAttrListInsert = _pango.lookupFunction<
        _VoidPtrPtrNative,
        _VoidPtrPtrDart>('pango_attr_list_insert');
    _pangoLayoutSetAttributes = _pango.lookupFunction<
        _VoidPtrPtrNative,
        _VoidPtrPtrDart>('pango_layout_set_attributes');
    _pangoAttrListUnref = _pango.lookupFunction<_VoidPtrNative, _VoidPtrDart>(
        'pango_attr_list_unref');
    _pangoLayoutGetPixelExtents = _pango.lookupFunction<
        _VoidPtrRectRectNative,
        _VoidPtrRectRectDart>('pango_layout_get_pixel_extents');
    _pangoLayoutGetBaseline = _pango.lookupFunction<
        _IntPtrNoArgNative,
        _IntPtrNoArgDart>('pango_layout_get_baseline');
    _pangoLayoutIndexToPos = _pango.lookupFunction<
        _VoidPtrIndexRectNative,
        _VoidPtrIndexRectDart>('pango_layout_index_to_pos');
    _gObjectUnref = _gobject.lookupFunction<_VoidPtrNative, _VoidPtrDart>(
        'g_object_unref');

    _fcConfigCreate = _fontconfig.lookupFunction<_Ptr0Native, _Ptr0Dart>(
        'FcConfigCreate');
    _fcConfigAppFontAddFile = _fontconfig.lookupFunction<
        _IntPtrCStringNative,
        _IntPtrCStringDart>('FcConfigAppFontAddFile');
    _fcConfigBuildFonts = _fontconfig.lookupFunction<_IntPtrNative, _IntPtrDart>(
        'FcConfigBuildFonts');
    _fcConfigDestroy = _fontconfig.lookupFunction<_VoidPtrNative, _VoidPtrDart>(
        'FcConfigDestroy');
  }

  static DynamicLibrary _open(List<String> names, String label) {
    Object? last;
    for (final name in names) {
      if (name.isEmpty) continue;
      try {
        return DynamicLibrary.open(name);
      } catch (e) {
        last = e;
      }
    }
    throw UnsupportedError(
      'nanpa-linja-n full rendering requires $label on '
      '${Platform.operatingSystem}; $last',
    );
  }

  Pointer<Uint8> _cString(String value) {
    final bytes = utf8.encode(value);
    final p = _malloc(bytes.length + 1).cast<Uint8>();
    if (p == nullptr) throw StateError('Native memory allocation failed');
    final b = p.asTypedList(bytes.length + 1);
    b.setRange(0, bytes.length, bytes);
    b[bytes.length] = 0;
    return p;
  }

  T _withCString<T>(String value, T Function(Pointer<Uint8>) fn) {
    final p = _cString(value);
    try {
      return fn(p);
    } finally {
      _free(p.cast<Void>());
    }
  }

  _FullLayoutHandle _createLayout(
    String text,
    String family,
    String fontPath,
    double fontSize,
    List<String> features,
  ) {
    final absolute = File(fontPath).absolute.path;
    if (!File(absolute).existsSync()) {
      throw FileSystemException('Font asset does not exist', absolute);
    }

    Pointer<Void> config = nullptr;
    Pointer<Void> fontMap = nullptr;
    Pointer<Void> context = nullptr;
    Pointer<Void> layout = nullptr;
    Pointer<Void> desc = nullptr;
    try {
      config = _fcConfigCreate();
      if (config == nullptr) {
        throw StateError('Fontconfig failed to create isolated configuration');
      }
      final added = _withCString<int>(
        absolute,
        (p) => _fcConfigAppFontAddFile(config, p),
      );
      if (added == 0 || _fcConfigBuildFonts(config) == 0) {
        throw StateError('Fontconfig failed to load $absolute');
      }
      fontMap = _pangoCairoFontMapNew();
      if (fontMap == nullptr) {
        throw StateError('PangoCairo failed to create isolated font map');
      }
      _pangoFcFontMapSetConfig(fontMap, config);
      context = _pangoFontMapCreateContext(fontMap);
      if (context == nullptr) {
        throw StateError('Pango failed to create isolated context');
      }
      layout = _pangoLayoutNew(context);
      if (layout == nullptr) {
        throw StateError('Pango failed to create isolated layout');
      }
      desc = _pangoFontDescriptionNew();
      if (desc == nullptr) {
        throw StateError('Pango failed to create font description');
      }
      _withCString<void>(
        family,
        (p) => _pangoFontDescriptionSetFamily(desc, p),
      );
      _pangoFontDescriptionSetAbsoluteSize(desc, fontSize * 1024.0);
      _pangoLayoutSetFontDescription(layout, desc);
      _withCString<void>(text, (p) => _pangoLayoutSetText(layout, p, -1));
      if (features.isNotEmpty) {
        final attrs = _pangoAttrListNew();
        if (attrs == nullptr) {
          throw StateError('Pango failed to create font feature attributes');
        }
        try {
          final featureString = features.map((e) => '$e=1').join(',');
          final attr = _withCString<Pointer<Void>>(
            featureString,
            (p) => _pangoAttrFontFeaturesNew(p),
          );
          if (attr == nullptr) {
            throw StateError('Pango rejected font features');
          }
          _pangoAttrListInsert(attrs, attr);
          _pangoLayoutSetAttributes(layout, attrs);
        } finally {
          _pangoAttrListUnref(attrs);
        }
      }
      return _FullLayoutHandle(
        layout: layout,
        context: context,
        fontMap: fontMap,
        config: config,
      );
    } catch (_) {
      if (layout != nullptr) _gObjectUnref(layout);
      if (context != nullptr) _gObjectUnref(context);
      if (fontMap != nullptr) _gObjectUnref(fontMap);
      if (config != nullptr) _fcConfigDestroy(config);
      rethrow;
    } finally {
      if (desc != nullptr) _pangoFontDescriptionFree(desc);
    }
  }

  void _destroyLayout(_FullLayoutHandle handle) {
    _gObjectUnref(handle.layout);
    _gObjectUnref(handle.context);
    _gObjectUnref(handle.fontMap);
    _fcConfigDestroy(handle.config);
  }

  FullTextMetrics measure(
    String text,
    String family,
    String fontPath,
    double fontSize,
    List<String> features,
  ) {
    final handle = _createLayout(text, family, fontPath, fontSize, features);
    try {
      final ink = _malloc(sizeOf<_PangoRectangle>()).cast<_PangoRectangle>();
      final logical = _malloc(sizeOf<_PangoRectangle>()).cast<_PangoRectangle>();
      if (ink == nullptr || logical == nullptr) {
        if (ink != nullptr) _free(ink.cast<Void>());
        if (logical != nullptr) _free(logical.cast<Void>());
        throw StateError('Native allocation failed');
      }
      try {
        _pangoLayoutGetPixelExtents(handle.layout, ink, logical);
        var r = ink.ref;
        if (r.width <= 0 || r.height <= 0) r = logical.ref;
        final baseline = _pangoLayoutGetBaseline(handle.layout) / 1024.0;
        return FullTextMetrics(
          r.x,
          r.y,
          math.max(1, r.width),
          math.max(1, r.height),
          baseline,
        );
      } finally {
        _free(ink.cast<Void>());
        _free(logical.cast<Void>());
      }
    } finally {
      _destroyLayout(handle);
    }
  }

  double caretX(
    String text,
    String family,
    String fontPath,
    double fontSize,
    List<String> features,
    int byteIndex,
  ) {
    final handle = _createLayout(text, family, fontPath, fontSize, features);
    try {
      final rect = _malloc(sizeOf<_PangoRectangle>()).cast<_PangoRectangle>();
      if (rect == nullptr) throw StateError('Native allocation failed');
      try {
        _pangoLayoutIndexToPos(handle.layout, byteIndex, rect);
        return rect.ref.x / 1024.0;
      } finally {
        _free(rect.cast<Void>());
      }
    } finally {
      _destroyLayout(handle);
    }
  }

  void _rgba(Pointer<Void> cr, ProductionRgba c) =>
      _cairoSetSourceRgba(cr, c.red, c.green, c.blue, c.alpha);

  NativeFullRenderedBytes render(
    int width,
    int height,
    ProductionOutputFormat format,
    List<NativeFullOp> ops,
    ProductionRgba background,
  ) {
    final w = math.max(1, width);
    final h = math.max(1, height);
    final dir = Directory.systemTemp.createTempSync('nanpa_linja_n_dart_full_');
    final target = File(
      '${dir.path}${Platform.pathSeparator}render.${format.name}',
    );
    Pointer<Void> surface = nullptr;
    Pointer<Void> cr = nullptr;
    try {
      switch (format) {
        case ProductionOutputFormat.png:
          surface = _cairoImageSurfaceCreate(0, w, h);
          break;
        case ProductionOutputFormat.svg:
          surface = _withCString<Pointer<Void>>(
            target.path,
            (p) => _cairoSvgSurfaceCreate(p, w.toDouble(), h.toDouble()),
          );
          break;
        case ProductionOutputFormat.pdf:
          surface = _withCString<Pointer<Void>>(
            target.path,
            (p) => _cairoPdfSurfaceCreate(p, w.toDouble(), h.toDouble()),
          );
          break;
      }
      if (surface == nullptr || _cairoSurfaceStatus(surface) != 0) {
        throw StateError('Cairo failed to create full ${format.name} surface');
      }
      cr = _cairoCreate(surface);
      if (cr == nullptr) throw StateError('Cairo failed to create full context');

      // CAIRO_OPERATOR_SOURCE then CAIRO_OPERATOR_OVER.
      _cairoSetOperator(cr, 1);
      _rgba(cr, background);
      _cairoPaint(cr);
      _cairoSetOperator(cr, 2);

      for (final op in ops) {
        if (op is NativeFullTextOp) {
          final handle = _createLayout(
            op.text,
            op.family,
            op.fontPath,
            op.fontSize,
            op.features,
          );
          try {
            _cairoMoveTo(cr, op.x, op.y);
            if (op.halo && op.haloWidth > 0) {
              _pangoCairoLayoutPath(cr, handle.layout);
              _rgba(cr, op.haloColor);
              _cairoSetLineWidth(cr, op.haloWidth * 2);
              _cairoSetLineJoin(cr, 1);
              _cairoStroke(cr);
              _cairoMoveTo(cr, op.x, op.y);
            }
            _rgba(cr, op.color);
            _pangoCairoShowLayout(cr, handle.layout);
          } finally {
            _destroyLayout(handle);
          }
        } else if (op is NativeFullRoundedRectOp) {
          final radius = math.max(
            0.0,
            math.min(op.radius, math.min(op.width / 2, op.height / 2)),
          ).toDouble();
          if (op.width > 0 && op.height > 0) {
            if (radius <= 0) {
              _cairoRectangle(cr, op.x, op.y, op.width, op.height);
            } else {
              final right = op.x + op.width;
              final bottom = op.y + op.height;
              _cairoMoveTo(cr, op.x + radius, op.y);
              _cairoLineTo(cr, right - radius, op.y);
              _cairoArc(cr, right - radius, op.y + radius, radius,
                  -math.pi / 2, 0);
              _cairoLineTo(cr, right, bottom - radius);
              _cairoArc(cr, right - radius, bottom - radius, radius,
                  0, math.pi / 2);
              _cairoLineTo(cr, op.x + radius, bottom);
              _cairoArc(cr, op.x + radius, bottom - radius, radius,
                  math.pi / 2, math.pi);
              _cairoLineTo(cr, op.x, op.y + radius);
              _cairoArc(cr, op.x + radius, op.y + radius, radius,
                  math.pi, math.pi * 1.5);
              _cairoClosePath(cr);
            }
            _rgba(cr, op.color);
            _cairoFill(cr);
          }
        } else if (op is NativeFullLineOp) {
          if (op.halo && op.haloWidth > 0) {
            _cairoMoveTo(cr, op.x1, op.y1);
            _cairoLineTo(cr, op.x2, op.y2);
            _rgba(cr, op.haloColor);
            _cairoSetLineWidth(cr, op.width + 2 * op.haloWidth);
            _cairoSetLineCap(cr, 1);
            _cairoStroke(cr);
          }
          _cairoMoveTo(cr, op.x1, op.y1);
          _cairoLineTo(cr, op.x2, op.y2);
          _rgba(cr, op.color);
          _cairoSetLineWidth(cr, op.width);
          _cairoSetLineCap(cr, 0);
          _cairoStroke(cr);
        } else if (op is NativeFullRectOp) {
          _cairoRectangle(cr, op.x, op.y, op.width, op.height);
          _rgba(cr, op.color);
          _cairoSetLineWidth(cr, op.lineWidth);
          _cairoStroke(cr);
        } else if (op is NativeFullImageOp) {
          final imageFile = File(
            '${dir.path}${Platform.pathSeparator}'
            'image_${DateTime.now().microsecondsSinceEpoch}.png',
          );
          imageFile.writeAsBytesSync(op.pngBytes, flush: true);
          final im = _withCString<Pointer<Void>>(
            imageFile.path,
            (p) => _cairoImageSurfaceCreateFromPng(p),
          );
          if (im == nullptr || _cairoSurfaceStatus(im) != 0) {
            if (im != nullptr) _cairoSurfaceDestroy(im);
            continue;
          }
          try {
            final iw = _cairoImageSurfaceGetWidth(im);
            final ih = _cairoImageSurfaceGetHeight(im);
            if (iw <= 0 || ih <= 0) continue;
            _cairoSave(cr);
            _cairoTranslate(cr, op.x, op.y);
            _cairoScale(cr, op.width / iw, op.height / ih);
            _cairoSetSourceSurface(cr, im, 0, 0);
            _cairoPaint(cr);
            _cairoRestore(cr);
          } finally {
            _cairoSurfaceDestroy(im);
          }
        }
      }

      if (format == ProductionOutputFormat.png) {
        final status = _withCString<int>(
          target.path,
          (p) => _cairoSurfaceWriteToPng(surface, p),
        );
        if (status != 0) {
          throw StateError('Cairo PNG encoding failed: $status');
        }
      }
      _cairoSurfaceFinish(surface);
      final bytes = target.readAsBytesSync();
      if (bytes.isEmpty) {
        throw StateError('${format.name.toUpperCase()} renderer produced no bytes');
      }
      return NativeFullRenderedBytes(
        bytes: Uint8List.fromList(bytes),
        width: w,
        height: h,
        format: format,
      );
    } finally {
      if (cr != nullptr) _cairoDestroy(cr);
      if (surface != nullptr) _cairoSurfaceDestroy(surface);
      try {
        dir.deleteSync(recursive: true);
      } catch (_) {
        // Best-effort cleanup.
      }
    }
  }
}

FullTextMetrics measureFullTextNative({
  required String text,
  required String family,
  required String fontPath,
  required double fontSize,
  List<String> features = const <String>[],
}) =>
    _NativeFullBackend.instance.measure(
      text,
      family,
      fontPath,
      fontSize,
      features,
    );

double fullTextCaretXNative({
  required String text,
  required String family,
  required String fontPath,
  required double fontSize,
  List<String> features = const <String>[],
  required int byteIndex,
}) =>
    _NativeFullBackend.instance.caretX(
      text,
      family,
      fontPath,
      fontSize,
      features,
      byteIndex,
    );

NativeFullRenderedBytes renderFullNative({
  required int width,
  required int height,
  required ProductionOutputFormat format,
  required List<NativeFullOp> operations,
  ProductionRgba background = ProductionRgba.transparent,
}) =>
    _NativeFullBackend.instance.render(
      width,
      height,
      format,
      operations,
      background,
    );
