# Conformance classes

## Core-v1

Required: independently pass the frozen language-neutral `nanpa-linja-n-regression-v1.0.2.json` corpus. The reference runners report **1017 checks**.

The corpus itself is byte-identical in the synchronized JavaScript/browser, TypeScript, Python, and Protocol v1.0.0 release. Its SHA-256 is recorded in `references/reference-implementations.json`.

## Binding-v1

Required: expose or document a one-to-one mapping for all 35 Core-v1 operations and their required result contracts. The TypeScript archive is a reference binding, not the definitive JavaScript browser/rendering environment.

## Production-Font-Profile-v1

Required: validate the frozen production manifest, referenced font assets, companion/native cmap contract, required render adapters, and `ss12`/`ss13`/`ss14` GSUB features.

## Visual-Regression-Certified-v1

Required: produce and approve all 128 implementation-specific artifacts for the 8×16 production matrix and compare future output against that implementation's approved baseline.

Frozen reference evidence:

- JavaScript: 128 SVG artifacts (64 full + 64 abbreviated), browser core 94 checks, browser font suite 90 checks;
- Python: 128 PNG artifacts (64 full + 64 abbreviated), font regression 211 checks;
- TypeScript: binding build/facade tests and 1017/1017 regression checks;
- Python semantic differential against the canonical JS runtime: 335 invocations, 0 mismatches (development evidence, not itself normative).

A product may claim only the conformance classes it actually runs.
