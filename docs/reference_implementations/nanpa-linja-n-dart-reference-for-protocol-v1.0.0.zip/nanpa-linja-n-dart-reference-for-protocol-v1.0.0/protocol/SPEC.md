# nanpa-linja-n Protocol v1.0.0

Status: **final**  
Semantic baseline: **2026-09-14**

## 1. Normative authority

nanpa-linja-n is defined by this protocol and its frozen language-neutral conformance corpus, not by any one source-code implementation.

The following files are normative for Core Protocol v1:

- `SPEC.md`
- `protocol.json`
- `conformance/nanpa-linja-n-regression-v1.0.2.json`
- `conformance/nanpa-linja-n-regression.schema.json`

The production rendering profile additionally uses:

- `RENDERING-PROFILE.md`
- `rendering/production-font-pairs.manifest.json`
- `rendering/font-golden-cases-v1.1.0.json`

The JavaScript/browser suite, TypeScript binding, and Python implementation pinned under `references/` are conformance evidence and reference implementations. They are **not normative**.

## 2. Canonical representations

Core Protocol v1 defines observable conversion through source input, nanpa-caps/structured numeric representation where applicable, canonical proper-name representation, semantic date/time metadata where applicable, starting-glyph selection, required closer, Toki Pona words, UCSUR codepoints, wrapped cartouche codepoints, and full/abbreviated representations.

The frozen conformance corpus is an external oracle. A conforming implementation MUST NOT generate expected values from its own output.

## 3. Decimal digit systems

### 3.1 Strict syllables

`0 NI, 1 WE, 2 TE, 3 SE, 4 NA, 5 LE, 6 NU, 7 ME, 8 PE, 9 JE`.

### 3.2 Relaxed syllables

`0 NI, 1 WA, 2 TU, 3 SE, 4 NA, 5 LU, 6 NU, 7 MU, 8 PI, 9 JO`.

Relaxed parsing accepts the protocol-defined aliases. Strict parsing rejects relaxed-only aliases. Relaxed rendering emits the representation asserted by the corpus.

## 4. Numeric namespaces and boundary invariants

- Decimal numeric cartouches may start with `nanpa`, `tenpo`, `suno`, or `toki` as defined below. Decimal numeric cartouches close with `nanpa`.
- Hexadecimal opens and closes with `nasa` only.
- Binary opens and closes with `noka` only.
- Single-integer `Suno` forms 1..31 are ordinary numeric values with source/default start glyph `suno`; they are not date objects.

Hexadecimal and binary remain distinct numeric namespaces at both boundaries.

## 5. Decimal starting-glyph model

A decimal value remains a **number** regardless of which permitted decimal starting glyph is used. The starting glyph is representation metadata and does not create a new numeric datatype.

The permitted decimal starting glyphs are:

- `nanpa`
- `tenpo`
- `suno`
- `toki`

Starting-glyph precedence is:

1. an explicit valid caller option such as `numericCartoucheStartGlyph`;
2. a source-provided/default starting glyph recorded by the parsed form, such as explicit `Toki`/`toki` or single-number `Suno`;
3. a semantic rendering default for recognized dates/times (`suno`/`tenpo`);
4. ordinary decimal default `nanpa`.

`semanticStartGlyph` records a source-provided/default starting glyph. It is not required merely because a recognized date or time renders with `suno` or `tenpo`.

Examples of decimal numeric boundaries include:

- `[nanpa : … nanpa]`
- `[tenpo : … nanpa]`
- `[suno : … nanpa]`
- `[toki : … nanpa]`

An explicit `Toki` proper-name form or `toki` cartouche therefore remains a numeric value whose source/default starting glyph is `toki`.

## 6. Semantic date/time classification

Recognized full dates and times use `semanticKind` for date/time behavior and render with `suno`/`tenpo` defaults.

Compatibility behavior is frozen by the corpus, including:

- signed two-field time (`-12:30`, `+12:30`) is not recognized as time;
- two-field time permits first fields 0..59, so `24:00` through `59:59` may be time while `60:00` is not;
- date-looking strings that fail date recognition may fall through to another numeric grammar;
- single-number `Suno` 1..31 is numeric, not a date object.

## 7. Yearless dates

Core v1 recognizes the yearless forms asserted by the corpus, including `--MM-DD` and `XXXX-MM-DD`, with the corpus-defined validation rules. Recognized yearless dates are dates and render with `suno` as the semantic decimal head and `nanpa` as closer.

## 8. Time and duration

The accepted two-, three-, and four-field forms, fractional-second limits, sign handling, and time/duration overlap are defined by the conformance corpus. Implementations MUST match those cases rather than substitute a generic external date/time grammar.

## 9. Hexadecimal and binary

Hexadecimal and binary are separate numeric namespaces. Their source forms, proper-name/cartouche forms, delimiters, canonical words, abbreviated words, and fixed opener/closer behavior are defined by the corpus and `protocol.json`.

## 10. Abbreviation

Full and abbreviated numeric cartouches are distinct protocol representations. Abbreviation MUST preserve the namespace boundary invariant and the `preserveNumericCartoucheBreaksInAbbreviation` behavior when enabled.

The production rendering profile contains eight full and eight corresponding abbreviated logical visual cases.

## 11. Public operations and result contracts

Core v1 freezes 35 language-neutral operation names corresponding to the public `NanpaParser` surface. Bindings may use idiomatic aliases but MUST document a one-to-one mapping.

Required result fields are declared by `outputContracts` in the v1.0.2 corpus.

## 12. Conformance

A Core-v1 conforming implementation MUST independently pass the byte-identical v1.0.2 language-neutral corpus. The current reference runners report:

- 311 parser cases;
- 15 renderer/public-output oracle cases;
- 9 auxiliary API cases;
- 8 equivalence groups;
- **1017 total checks**.

Passing a JS-vs-port differential is useful development evidence but is not a substitute for the independent corpus.

## 13. Canonical reference filename

The frozen reference packages use this renderer filename consistently:

`renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js`

Its SHA-256 is `935b6a3e664d1ef25f496b8f7af1f8e3cfd3082c64bcec46b2dabf09e3447a7c`. The filename MUST NOT be silently replaced by arbitrary aliases inside the v1 reference packages.

## 14. Versioning

Protocol versioning follows `VERSIONING.md`. Changing implementation code alone does not change the protocol. Observable behavior changes enter the protocol only through an explicit protocol release with updated normative artifacts and conformance vectors.
