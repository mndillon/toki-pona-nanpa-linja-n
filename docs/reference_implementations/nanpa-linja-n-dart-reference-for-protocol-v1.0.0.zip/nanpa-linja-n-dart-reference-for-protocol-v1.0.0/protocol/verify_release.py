#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/'release-manifest.json').read_text())
bad=[]
for item in manifest['bundledFiles']:
    p=root/item['path']
    if not p.is_file():
        bad.append((item['path'],'missing',item['sha256'])); continue
    got=hashlib.sha256(p.read_bytes()).hexdigest()
    if got != item['sha256']: bad.append((item['path'],got,item['sha256']))
if bad:
    for x in bad: print('FAIL',*x)
    sys.exit(1)

refs=json.loads((root/'references/reference-implementations.json').read_text())
proto=json.loads((root/'protocol.json').read_text())
if proto.get('protocolVersion') != '1.0.0' or proto.get('status') != 'final':
    print('FAIL protocol release identity'); sys.exit(1)
corpus_path=root/proto['core']['conformanceCorpus']
corpus=json.loads(corpus_path.read_text())
corpus_sha=hashlib.sha256(corpus_path.read_bytes()).hexdigest()
expected=refs['sharedConformanceCorpus']['sha256']
if corpus_sha != expected or corpus_sha != proto['core']['conformanceCorpusSha256']:
    print('FAIL corpus hash disagreement', corpus_sha, expected); sys.exit(1)
canon=refs['canonicalRenderer']
if corpus['suite'].get('referenceImplementation') != canon['filename']:
    print('FAIL corpus canonical renderer filename mismatch'); sys.exit(1)
if corpus['suite'].get('referenceImplementationSha256') != canon['sha256']:
    print('FAIL corpus canonical renderer hash mismatch'); sys.exit(1)

# Frozen semantic guard retained internally to protect the published v1 result contract.
def walk(v, path='$'):
    if isinstance(v, dict):
        for k,x in v.items():
            if k == 'isTelephone':
                raise ValueError(f'forbidden legacy result key at {path}.{k}')
            if k == 'semanticKind' and x == 'telephone':
                raise ValueError(f'forbidden legacy semantic value at {path}.{k}')
            walk(x, f'{path}.{k}')
    elif isinstance(v, list):
        for i,x in enumerate(v): walk(x, f'{path}[{i}]')
try: walk(corpus)
except ValueError as e:
    print('FAIL',e); sys.exit(1)

# Reference packages must agree on canonical runtime and corpus hashes.
for impl in refs['referenceImplementations']:
    if impl.get('canonicalJavaScriptFilename') != canon['filename']:
        print('FAIL reference filename mismatch',impl['id']); sys.exit(1)
    if impl.get('canonicalJavaScriptSha256') != canon['sha256']:
        print('FAIL reference renderer hash mismatch',impl['id']); sys.exit(1)
    if impl.get('conformanceCorpusSha256') != corpus_sha:
        print('FAIL reference corpus hash mismatch',impl['id']); sys.exit(1)

# Rendering evidence counts.
js_inv=json.loads((root/'references/javascript-goldens.sha256.json').read_text())
py_inv=json.loads((root/'references/python-goldens.sha256.json').read_text())
if js_inv.get('artifactCount') != 128 or py_inv.get('artifactCount') != 128:
    print('FAIL visual artifact count'); sys.exit(1)

print(f"PASS {len(manifest['bundledFiles'])} frozen bundled files")
print('PASS core semantic invariants')
print('PASS shared corpus:', corpus_sha)
print('PASS canonical renderer:', canon['filename'], canon['sha256'])
