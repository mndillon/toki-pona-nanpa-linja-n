# nanpa-linja-n Protocol v1.0.0

This directory is the frozen **nanpa-linja-n Protocol v1.0.0** release.

Start with `SPEC.md`, then `CONFORMANCE.md`, `RENDERING-PROFILE.md`, and `VERSIONING.md`.

## Core model

nanpa-linja-n defines numeric representations independently of any one implementation. Decimal numeric cartouches normally start with `nanpa`, but may explicitly use the permitted starting glyphs `tenpo`, `suno`, or `toki` where appropriate. Decimal numeric cartouches close with `nanpa`. Hexadecimal uses `nasa … nasa`; binary uses `noka … noka`.

Starting-glyph precedence is defined in `SPEC.md`. A valid caller-supplied starting-glyph override takes precedence over a source-provided/default starting glyph.

## Frozen evidence

- canonical renderer filename: `renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js`
- canonical renderer SHA-256: `935b6a3e664d1ef25f496b8f7af1f8e3cfd3082c64bcec46b2dabf09e3447a7c`
- shared conformance corpus: `nanpa-linja-n-regression-v1.0.2.json`
- shared corpus SHA-256: `3e139d2599ea23ade561a7ac07c390440856c66b008286fc60186a38049f9689`
- conformance checks: **1017**
- JavaScript visual baseline: **128 SVGs (64 full + 64 abbreviated)**
- Python visual baseline: **128 PNGs (64 full + 64 abbreviated)**

The reference implementation archives are non-normative and are pinned by SHA-256 under `references/reference-implementations.json`.

Run `python verify_release.py` from this directory to verify the frozen bundle. A successful verification confirms that the bundled protocol artifacts have not changed.
