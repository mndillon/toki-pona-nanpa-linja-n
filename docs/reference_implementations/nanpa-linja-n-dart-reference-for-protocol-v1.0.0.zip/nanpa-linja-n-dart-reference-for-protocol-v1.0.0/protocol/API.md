# Core v1 operation surface

The following 35 operation names are frozen for the language-neutral binding map. Language bindings may expose idiomatic aliases, but must document the mapping.

- `parseNumber`
- `encodeDecimal`
- `decimalToUcsurCodepoints`
- `properNameToUcsurCodepoints`
- `splitCapsToProperName`
- `capsToUniqueCode`
- `decodeCaps`
- `ucsurCodepointsToTpWords`
- `codepointsToWords`
- `tpWordsToText`
- `parseTpWordsToCodepoints`
- `tpWordsToUcsurCodepoints`
- `codepointsToHex`
- `codepointsToHexWithCartouche`
- `parseHexCodepoints`
- `withCartoucheMarkers`
- `stripCartoucheMarkers`
- `isValidCaps`
- `isValidProperName`
- `isValidTimeOrDate`
- `isValidTime`
- `isValidDate`
- `tokenizeCaps`
- `capsTokensToTpWords`
- `capsToWords`
- `capsToCodepoints`
- `parseIdentifier`
- `normalizeVulgarFraction`
- `normalizeTpWord`
- `getSmallCodepointsSet`
- `getQuarterCodepointsSet`
- `getOneThirdCodepointsSet`
- `getTwoThirdsCodepointsSet`
- `getHalfCodepointsSet`
- `isAllowedTpUcsurCodepoint`

Required result contracts are defined by `outputContracts` in `conformance/nanpa-linja-n-regression-v1.0.2.json`.

Starting-glyph behavior, including explicit `toki`, is defined by `SPEC.md` and the conformance corpus.
