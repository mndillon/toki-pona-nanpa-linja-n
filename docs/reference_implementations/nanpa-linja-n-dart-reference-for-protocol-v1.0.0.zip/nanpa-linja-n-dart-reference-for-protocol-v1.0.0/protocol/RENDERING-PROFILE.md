# Production Rendering Profile v1

This profile is layered on Core Protocol v1. It does not redefine numeric semantics or create application-level datatypes.

## Normative profile inputs

- `rendering/production-font-pairs.manifest.json`: eight production font pairs and adapter metadata.
- `rendering/font-golden-cases-v1.1.0.json`: sixteen logical cases, eight full and eight abbreviated.

## Font conformance

A production companion font must satisfy the profile-specific cmap/native-adapter contract and expose OpenType features `ss12`, `ss13`, and `ss14`. Legacy adapters such as `linja-pona-legacy-v1` and `linja-sike-legacy-v1` are tested against their native input contracts rather than incorrectly requiring canonical UCSUR cmap coverage.

## Visual cases

With eight production pairs, one implementation produces 128 reference artifacts: 64 full and 64 abbreviated. The size cases exercise default rendering at 56 px, `ss13` at 29 px, and `ss12` at 18 px. Presence of `ss14` is a font-conformance requirement; this visual matrix does not imply automatic ss14 selection.

The logical matrix includes decimal, date, time, `toki`-started decimal numeric, hexadecimal, binary, and size-specific decimal cases in both full and abbreviated forms.

## Frozen reference evidence

The definitive JavaScript suite supplies 128 approved SVG goldens. Its manifest is copied to `references/javascript-svg-goldens.manifest.json`, with an independently recomputed artifact inventory in `references/javascript-goldens.sha256.json`.

The Python reference supplies 128 approved PNG goldens. Its manifest is copied to `references/python-font-goldens.manifest.json`, with its artifact inventory in `references/python-goldens.sha256.json`.

## Cross-renderer rule

SVG and PNG bytes are not cross-renderer protocol values and MUST NOT be compared byte-for-byte. Each rendering implementation maintains its own approved baseline. The protocol freezes the semantic stream, font/profile selection, adapter behavior, and logical visual cases.

A rendering implementation may claim `Visual-Regression-Certified-v1` only for the exact renderer/font/profile combination represented by its approved baseline.
