# Versioning and freeze policy

Protocol versions use semantic versioning.

- **MAJOR**: any change that can alter acceptance/rejection, canonical caps/proper name, semantic classification, starting-glyph precedence, opener/closer, TP words, UCSUR/codepoints, abbreviation, required output fields, or default semantics for an already-valid v1 input.
- **MINOR**: a backward-compatible optional extension that does not alter existing v1 behavior when unused.
- **PATCH**: documentation, schema, metadata, or additional test-vector corrections that reveal no change to already-frozen behavior. A patch must not silently change an existing expected result.

Reference implementations are versioned independently from the protocol. Updating JavaScript, TypeScript, or Python does not alter the protocol unless a protocol release is made.

## Change procedure

1. Propose the behavior change in prose and machine-readable form.
2. Add or modify external conformance vectors.
3. Run every reference implementation against the proposed corpus.
4. Decide the required protocol version bump.
5. Regenerate the release manifest and SHA-256 inventory.
6. Freeze the new release.

No implementation becomes an oracle merely because it is newer.

After Protocol v1.0.0 is frozen, any change to observable behavior for an existing v1 input—including accepted syntax, semantic classification, starting-glyph precedence, required result fields, or encoded output—must follow this versioning policy rather than being introduced silently.
