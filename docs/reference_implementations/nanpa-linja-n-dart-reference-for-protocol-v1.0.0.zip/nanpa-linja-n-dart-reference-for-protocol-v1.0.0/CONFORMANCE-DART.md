# Dart reference conformance

Target:

```text
nanpa-linja-n Protocol v1.0.0
Conformance corpus v1.0.2
Frozen protocol checks: 1017
Core-v1 operations: 35
Production font pairs: 8
Production render cases: 128
```

## Authority order

1. `protocol/SPEC.md`
2. `protocol/API.md`
3. `protocol/CONFORMANCE.md`
4. frozen language-neutral conformance corpus
5. `protocol/RENDERING-PROFILE.md` for the separate production graphical profile
6. canonical/cross-language implementations only as diagnostic references

The Dart implementation must not redefine Core-v1 behavior.

## Qualification command

```bash
./tools/run_dart_regression.sh
```

A release is fully Dart-reference-qualified only when every mandatory command returns success, the frozen runner reports exactly 1017 checks with `failures: 0`, the production render-plan test reports 128/128, and the native production renderer reports 128/128 plus valid PNG/SVG/PDF outputs.

## Core-v1 integrity

The production-rendering update is additive. These seven original Core implementation files are pinned by SHA-256 and must remain byte-for-byte unchanged:

```text
lib/src/constants.dart
lib/src/encoding.dart
lib/src/model.dart
lib/src/options.dart
lib/src/parser.dart
lib/src/api.dart
lib/src/renderer.dart
```

`tools/check_core_source_integrity.py` enforces that invariant.

## Core-v1 runtime checks

The frozen Dart runner executes all parser cases, renderer/API golden assertions represented in the shared corpus, and all frozen equivalence comparisons. `api_surface_check.dart` additionally calls Core-v1 helpers not individually represented as corpus API cases. `renderer_smoke.dart` exercises the pure-Dart logical renderer.

The established Core-v1 baseline on Dart SDK 3.13.3 is:

```text
Core public API smoke: 35/35 PASS
parser conformance: 311/311 PASS
renderer conformance: 15/15 PASS
API conformance: 9/9 PASS
equivalence comparisons: 75/75 PASS
frozen protocol checks: 1017/1017 PASS
logical renderer smoke: PASS
```

## Production rendering qualification

Version 0.2.0 adds a supported `NanpaLinjaN` facade and native graphical renderer without changing the seven frozen Core files.

The package bundles the eight production font pairs specified by the frozen profile. Font binaries are checked against `protocol/references/font-assets.sha256.json` before runtime tests.

`facade_plan_conformance.dart` checks 128 cross-language render plans. Each plan verifies the canonical codepoints, font adapter, actual render text/codepoints, abbreviation mode and OpenType feature selection.

`facade_rendering.dart` then renders the full 8-font x 16-case matrix through the native Pango/HarfBuzz + Cairo + Fontconfig backend. It also checks automatic legacy adaptation and PNG/SVG/PDF convenience output.

The Production Rendering Profile is separate from Core-v1. A graphical failure does not redefine protocol parsing semantics; it means the Dart production-rendering facade is not qualified until corrected.

## Native runtime requirements

Graphical output dynamically loads the platform Pango, PangoCairo, Cairo, Fontconfig and GObject libraries. No third-party Dart package is required. The bundled production fonts are registered as application fonts at runtime; they do not need to be installed globally.

The frozen browser/CSS family aliases in the production manifest are retained as profile metadata. Native Pango rendering uses the actual family names embedded in the hashed companion font files. This prevents a browser-only alias from resolving to an unrelated fallback font in Fontconfig.

## Compiler qualification

`check_dart_compilation.sh` compiles every shipped Dart entry point to temporary kernel modules. The mandatory release regression does not depend on the Dart Analysis Server's filesystem watchers. `dart analyze` remains an optional developer lint.

## Current archive status

See `VALIDATION-STATUS.txt`. Source/profile/font/native-library validation can be performed without a Dart SDK, but that is not a substitute for the required native Dart compile/runtime gate. A fully qualified final release requires `./tools/run_dart_regression.sh` to pass on a machine with Dart and the native text stack available.
