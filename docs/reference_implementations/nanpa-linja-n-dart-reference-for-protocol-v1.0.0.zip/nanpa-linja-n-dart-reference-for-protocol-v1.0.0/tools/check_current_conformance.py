#!/usr/bin/env python3
import hashlib, json, pathlib, sys
root=pathlib.Path(__file__).resolve().parents[1]
errors=[]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
# Canonical syntax authority.
p=root/'conformance/canonical-syntax-v1.0.1-phase1/cases.json'
o=json.loads(p.read_text())
a=o['authority']; ap=root/a['canonicalJavaScript']
if not ap.is_file(): errors.append(f'missing canonical syntax authority: {ap}')
elif sha(ap)!=a['sha256']: errors.append(f'canonical syntax authority hash mismatch: {sha(ap)} != {a["sha256"]}')
# Canonical full renderer authority.
p=root/'conformance/full-renderer-canonical-v1.0.1/cases.json'
o=json.loads(p.read_text())
if o.get('caseCount') != len(o.get('cases',[])): errors.append('canonical full renderer caseCount mismatch')
a=o['authority']; ap=root/a['path']
if not ap.is_file(): errors.append(f'missing canonical full renderer authority: {ap}')
elif sha(ap)!=a['sha256']: errors.append(f'canonical full renderer authority hash mismatch: {sha(ap)} != {a["sha256"]}')
# Mixed-feature authority.
p=root/'references/javascript-composition-interactions-v1.json'
o=json.loads(p.read_text())
if o.get('caseCount') != len(o.get('cases',[])): errors.append('mixed-feature interaction caseCount mismatch')
a=o['authority']
for key,hkey in [('facadePath','facadeSha256'),('rendererPath','rendererSha256')]:
    ap=root/a[key]
    if not ap.is_file(): errors.append(f'missing mixed-feature authority: {ap}')
    elif sha(ap)!=a[hkey]: errors.append(f'{key} hash mismatch: {sha(ap)} != {a[hkey]}')
if errors:
    print('\n'.join('FAIL '+e for e in errors), file=sys.stderr); sys.exit(1)
print('Current JavaScript-derived conformance authority: PASS')
