#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
OUT="${1:-$ROOT/test-output/cartouche-audit}"
mkdir -p "$OUT"
dart run tools/visual_export.dart ordinary "$OUT"
python3 tools/make_cartouche_contacts.py "$OUT"
