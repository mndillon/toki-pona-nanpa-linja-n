#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, struct, sys



EXPECTED_NATIVE_FAMILIES = {
    'nasinNanpa': 'nasin-nanpa-linja-n Ligature v4.4 Long Fix-nasin-e-en',
    'sitelenSeliKiwen': 'sitelen seli kiwen juniko-nanpa-linja-n Ligature-nasin-e-en',
    'fairfaxHd': 'Fairfax HD-nanpa-linja-n-nasin-e-en',
    'fairfaxPonaHd': 'Fairfax Pona HD-nanpa-linja-n-nasin-e-en',
    'linjaPona': 'linja pona 4.9-nanpa-linja-n-nasin-e-en',
    'linjaSike': 'linja sike 5-nanpa-linja-n-nasin-e-en',
    'nasinSitelenPuMono': 'nasin-sitelen-pu-nanpa-linja-n-nasin-e-en',
    'linjaLipamanka': 'linja lipamanka-nanpa-linja-n-nasin-e-en',
}


def _embedded_family(path: Path) -> str:
    """Read preferred family (name ID 16) or family (ID 1) from SFNT."""
    data = path.read_bytes()
    if len(data) < 12:
        raise ValueError('truncated SFNT')
    num_tables = struct.unpack_from('>H', data, 4)[0]
    name_off = name_len = None
    for i in range(num_tables):
        off = 12 + i * 16
        if off + 16 > len(data):
            raise ValueError('truncated table directory')
        tag, _, table_off, table_len = struct.unpack_from('>4sIII', data, off)
        if tag == b'name':
            name_off, name_len = table_off, table_len
            break
    if name_off is None or name_off + 6 > len(data):
        raise ValueError('missing name table')
    _, count, string_offset = struct.unpack_from('>HHH', data, name_off)
    records = []
    for i in range(count):
        roff = name_off + 6 + i * 12
        if roff + 12 > len(data):
            break
        platform, encoding, language, name_id, length, offset = struct.unpack_from('>HHHHHH', data, roff)
        if name_id not in (1, 16):
            continue
        start = name_off + string_offset + offset
        raw = data[start:start + length]
        try:
            if platform in (0, 3):
                text = raw.decode('utf-16-be')
            elif platform == 1:
                text = raw.decode('mac_roman')
            else:
                continue
        except UnicodeDecodeError:
            continue
        if text:
            # Prefer Windows/Unicode English records but retain deterministic fallbacks.
            priority = (0 if name_id == 16 else 10) + (0 if platform in (0, 3) else 2) + (0 if language in (0, 0x0409) else 1)
            records.append((priority, name_id, text))
    if not records:
        raise ValueError('no family name record')
    records.sort(key=lambda r: r[0])
    return records[0][2]

root = Path(__file__).resolve().parent.parent
pins = json.loads((root / 'protocol/references/font-assets.sha256.json').read_text())
font_root = root / 'assets/fonts'
failures = []
for rec in pins['files']:
    path = font_root / rec['filename']
    if not path.is_file():
        failures.append(f"missing {rec['filename']}")
        continue
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if digest != rec['sha256']:
        failures.append(f"hash {rec['filename']}: {digest} != {rec['sha256']}")
    if len(data) != rec['bytes']:
        failures.append(f"size {rec['filename']}: {len(data)} != {rec['bytes']}")
manifest = json.loads((font_root / 'production-font-pairs.manifest.json').read_text())
if len(manifest.get('pairs', [])) != 8:
    failures.append(f"production pair count: {len(manifest.get('pairs', []))} != 8")
for pair in manifest.get('pairs', []):
    key = pair.get('fontKey')
    expected_family = EXPECTED_NATIVE_FAMILIES.get(key)
    if expected_family is None:
        failures.append(f'no pinned native family for {key}')
        continue
    try:
        actual_family = _embedded_family(font_root / pair['companionFilename'])
    except Exception as exc:
        failures.append(f'native family {key}: {exc}')
        continue
    if actual_family != expected_family:
        failures.append(f'native family {key}: {actual_family!r} != {expected_family!r}')
plans = json.loads((root / 'rendering/facade-render-plan-goldens-v1.0.0.json').read_text())
if len(plans.get('cases', [])) != 128:
    failures.append(f"render plan count: {len(plans.get('cases', []))} != 128")
if failures:
    print('Dart production asset validation FAIL')
    for f in failures:
        print(' -', f)
    sys.exit(1)
print(f"Dart production assets: {len(pins['files'])}/{len(pins['files'])} font hashes PASS; 8/8 pairs; 8/8 native families; 128 plan goldens")
