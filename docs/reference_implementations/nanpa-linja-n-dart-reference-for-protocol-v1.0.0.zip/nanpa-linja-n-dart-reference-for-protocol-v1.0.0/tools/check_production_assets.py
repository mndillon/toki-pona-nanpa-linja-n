#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, struct, sys, zipfile

EXPECTED_BUNDLE_SHA256 = 'e3c66bbb17c5559f6a87790ae1a9c57fbaaa81e2ec1c6f24cc954be5b3f76dc2'
EXPECTED_NATIVE_FAMILIES = {
    'nasinNanpa': 'nasin-nanpa-nanpa-linja-n-good-kasi-nasin-e-en-ss1223',
    'sitelenSeliKiwen': 'sitelen seli kiwen juniko-nanpa-linja-n Ligature-nasin-e-en',
    'fairfaxHd': 'Fairfax HD-nanpa-linja-n-nasin-e-en',
    'fairfaxPonaHd': 'Fairfax Pona HD-nanpa-linja-n-nasin-e-en',
    'linjaPona': 'linja pona 4.9-nanpa-linja-n-nasin-e-en',
    'linjaSike': 'linja sike 5-nanpa-linja-n-nasin-e-en',
    'nasinSitelenPuMono': 'nasin-sitelen-pu-nanpa-linja-n-nasin-e-en',
    'linjaLipamanka': 'linja lipamanka-nanpa-linja-n-nasin-e-en',
}


def _embedded_family(data: bytes) -> str:
    """Read preferred family (name ID 16) or family (ID 1) from SFNT bytes."""
    if len(data) < 12:
        raise ValueError('truncated SFNT')
    num_tables = struct.unpack_from('>H', data, 4)[0]
    name_off = None
    for i in range(num_tables):
        off = 12 + i * 16
        if off + 16 > len(data):
            raise ValueError('truncated table directory')
        tag, _, table_off, _ = struct.unpack_from('>4sIII', data, off)
        if tag == b'name':
            name_off = table_off
            break
    if name_off is None or name_off + 6 > len(data):
        raise ValueError('missing name table')
    _, count, string_offset = struct.unpack_from('>HHH', data, name_off)
    records = []
    for i in range(count):
        roff = name_off + 6 + i * 12
        if roff + 12 > len(data):
            break
        platform, _, language, name_id, length, offset = struct.unpack_from('>HHHHHH', data, roff)
        if name_id not in (1, 16):
            continue
        start = name_off + string_offset + offset
        raw = data[start:start + length]
        try:
            if platform in (0, 3):
                text = raw.decode('utf-16-be')
            elif platform == 1:
                text = raw.decode('mac_roman')
            else:
                continue
        except UnicodeDecodeError:
            continue
        if text:
            priority = (0 if name_id == 16 else 10) + (0 if platform in (0, 3) else 2) + (0 if language in (0, 0x0409) else 1)
            records.append((priority, text))
    if not records:
        raise ValueError('no family name record')
    records.sort(key=lambda r: r[0])
    return records[0][1]


root = Path(__file__).resolve().parent.parent
bundle = root / 'resources/fonts.zip'
pins = json.loads((root / 'protocol/references/font-assets.sha256.json').read_text())
failures = []

if not bundle.is_file():
    failures.append('missing resources/fonts.zip')
else:
    digest = hashlib.sha256(bundle.read_bytes()).hexdigest()
    if digest != EXPECTED_BUNDLE_SHA256:
        failures.append(f'fonts.zip hash: {digest} != {EXPECTED_BUNDLE_SHA256}')

if (root / 'assets/fonts').exists():
    failures.append('legacy assets/fonts directory still exists')
if (root / 'resources/fonts').exists():
    failures.append('exploded resources/fonts directory still exists')

if bundle.is_file():
    with zipfile.ZipFile(bundle) as zf:
        names = set(zf.namelist())
        manifest_entry = 'fonts/preloaded-font-pairs.manifest.json'
        if manifest_entry not in names:
            failures.append(f'missing {manifest_entry} in fonts.zip')
            manifest = {'pairs': []}
        else:
            manifest = json.loads(zf.read(manifest_entry))

        for rec in pins.get('files', []):
            entry = 'fonts/' + rec['filename']
            if entry not in names:
                failures.append(f"missing {rec['filename']}")
                continue
            data = zf.read(entry)
            got = hashlib.sha256(data).hexdigest()
            if got != rec['sha256']:
                failures.append(f"hash {rec['filename']}: {got} != {rec['sha256']}")
            if len(data) != rec['bytes']:
                failures.append(f"size {rec['filename']}: {len(data)} != {rec['bytes']}")

        pairs = manifest.get('pairs', [])
        if len(pairs) != 8:
            failures.append(f'production pair count: {len(pairs)} != 8')
        support = manifest.get('supportFonts', {})
        if not isinstance(support, dict) or len(support) != 4:
            failures.append(f'production support font count: {len(support) if isinstance(support, dict) else 0} != 4')

        referenced = set()
        for pair in pairs:
            key = pair.get('fontKey')
            for field in ('baseFilename', 'companionFilename', 'literalCartoucheFilename'):
                if pair.get(field):
                    referenced.add(pair[field])
            expected_family = EXPECTED_NATIVE_FAMILIES.get(key)
            if expected_family is None:
                failures.append(f'no pinned native family for {key}')
                continue
            try:
                actual_family = _embedded_family(zf.read('fonts/' + pair['companionFilename']))
            except Exception as exc:
                failures.append(f'native family {key}: {exc}')
                continue
            if actual_family != expected_family:
                failures.append(f'native family {key}: {actual_family!r} != {expected_family!r}')

        for node in support.values() if isinstance(support, dict) else ():
            if isinstance(node, dict) and node.get('filename'):
                referenced.add(node['filename'])
        pinned = {rec['filename'] for rec in pins.get('files', [])}
        if referenced != pinned:
            failures.append(
                f'manifest/pin inventory mismatch: referenced={len(referenced)} pinned={len(pinned)} '
                f'missingPins={sorted(referenced-pinned)} extraPins={sorted(pinned-referenced)}'
            )

repo_manifest = json.loads((root / 'rendering/production-font-pairs.manifest.json').read_text())
if bundle.is_file():
    with zipfile.ZipFile(bundle) as zf:
        internal_manifest = json.loads(zf.read('fonts/preloaded-font-pairs.manifest.json'))
    if repo_manifest != internal_manifest:
        failures.append('rendering/production-font-pairs.manifest.json differs from fonts.zip manifest')

plans = json.loads((root / 'rendering/facade-render-plan-goldens-v1.0.0.json').read_text())
if len(plans.get('cases', [])) != 128:
    failures.append(f"render plan count: {len(plans.get('cases', []))} != 128")

if failures:
    print('Dart production asset validation FAIL')
    for failure in failures:
        print(' -', failure)
    sys.exit(1)
print(
    f"Dart production assets: fonts.zip PASS; {len(pins.get('files', []))}/"
    f"{len(pins.get('files', []))} referenced font hashes PASS; "
    '8/8 pairs; 4/4 support fonts; 8/8 native families; 128 plan goldens'
)
