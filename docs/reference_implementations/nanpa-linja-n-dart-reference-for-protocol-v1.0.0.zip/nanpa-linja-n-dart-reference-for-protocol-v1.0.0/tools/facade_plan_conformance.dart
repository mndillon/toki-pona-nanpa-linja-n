import 'dart:convert';
import 'dart:io';

import 'package:nanpa_linja_n/nanpa_linja_n.dart';

bool _sameList(List<dynamic> a, List<dynamic> b) =>
    a.length == b.length &&
    List<int>.generate(a.length, (i) => i).every((i) => a[i] == b[i]);

void main() {
  final root = File.fromUri(Platform.script).parent.parent;
  final fixture = File(
    '${root.path}${Platform.pathSeparator}rendering${Platform.pathSeparator}facade-render-plan-goldens-v1.0.0.json',
  );
  final decoded = jsonDecode(fixture.readAsStringSync()) as Map<String, dynamic>;
  final cases = (decoded['cases'] as List).cast<Map>();
  final nanpa = NanpaLinjaN.create();
  final failures = <String>[];
  var passed = 0;

  for (final raw in cases) {
    final c = Map<String, dynamic>.from(raw);
    final plan = nanpa.buildRenderPlan(
      c['input'],
      font: c['fontKey'] as String,
      fontSize: c['fontPx'] as int,
      abbreviate: c['abbreviateNumericCartouches'] == true,
      preserveNumericCartoucheBreaks:
          c['preserveNumericCartoucheBreaksInAbbreviation'] != false,
    );
    final id = '${c['fontKey']}__${c['caseId']}';
    final expectedCanonical = (c['canonicalCodepoints'] as List).cast<int>();
    final expectedRender = (c['renderCodepoints'] as List).cast<int>();
    final expectedFeatures = (c['openTypeFeatures'] as List).cast<String>();
    final ok = plan.renderAdapterId == c['renderAdapterId'] &&
        plan.legacyAscii == c['legacyAscii'] &&
        plan.renderText == c['renderText'] &&
        _sameList(plan.canonicalCodepoints, expectedCanonical) &&
        _sameList(plan.renderCodepoints, expectedRender) &&
        _sameList(plan.openTypeFeatures, expectedFeatures);
    if (ok) {
      passed++;
    } else {
      failures.add(
        '$id mismatch: adapter=${plan.renderAdapterId} '
        'legacy=${plan.legacyAscii} features=${plan.openTypeFeatures} '
        'canonical=${plan.canonicalCodepoints} render=${plan.renderCodepoints}',
      );
    }
  }

  if (failures.isNotEmpty) {
    stderr.writeln('Dart production render-plan conformance failures:');
    for (final failure in failures) {
      stderr.writeln('  $failure');
    }
    exitCode = 1;
    return;
  }
  print('Dart production render-plan conformance: $passed/${cases.length} PASS');
}
