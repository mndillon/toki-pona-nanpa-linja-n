#!/usr/bin/env python3
from pathlib import Path
import hashlib
import sys

root = Path(__file__).resolve().parent.parent
pins_file = root / 'validation' / 'core-before.sha256'
failures = []
checked = 0
for line in pins_file.read_text(encoding='utf-8').splitlines():
    line = line.strip()
    if not line:
        continue
    digest, rel = line.split(None, 1)
    # lib/nanpa_linja_n.dart is intentionally changed only to export the new
    # additive production facade. The seven lib/src Core files remain frozen.
    if rel == 'lib/nanpa_linja_n.dart':
        continue
    path = root / rel
    if not path.is_file():
        failures.append(f'missing {rel}')
        continue
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    checked += 1
    if actual != digest:
        failures.append(f'{rel}: {actual} != {digest}')

if failures:
    print('Dart frozen Core source integrity FAIL')
    for failure in failures:
        print(' -', failure)
    sys.exit(1)
print(f'Dart frozen Core source integrity: {checked}/{checked} unchanged PASS')
