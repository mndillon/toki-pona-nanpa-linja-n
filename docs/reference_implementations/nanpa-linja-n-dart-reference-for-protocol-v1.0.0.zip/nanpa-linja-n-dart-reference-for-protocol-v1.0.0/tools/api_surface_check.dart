import 'package:nanpa_linja_n/nanpa_linja_n.dart';

void check(bool condition, String name) {
  if (!condition) throw StateError('$name failed');
}

void main() {
  const options = ParseOptions();
  const parser = NanpaParser();

  final decimal = parseNumber('123.45', options);
  check(decimal != null, 'parseNumber');
  check(parser.parseNumberValue('123.45', options) != null, 'NanpaParser.parseNumberValue');
  check(encodeDecimal('123.45', options) != null, 'encodeDecimal');
  check(decimalToUcsurCodepoints('123', options).isNotEmpty, 'decimalToUcsurCodepoints');
  check(properNameToUcsurCodepoints('Newan', options).isNotEmpty, 'properNameToUcsurCodepoints');

  final caps = decimal!.caps!;
  check(splitCapsToProperName(caps) != null, 'splitCapsToProperName');
  check(capsToUniqueCode(caps, options) != null, 'capsToUniqueCode');
  check(decodeCaps(caps, options) != null, 'decodeCaps');

  final inner = decimal.innerCodepoints;
  check(ucsurCodepointsToTpWords(inner).isNotEmpty, 'ucsurCodepointsToTpWords');
  check(codepointsToWords(inner).isNotEmpty, 'codepointsToWords');
  check(tpWordsToText(<String>['nanpa', ':']).isNotEmpty, 'tpWordsToText');
  check(parseTpWordsToCodepoints('nanpa : wan nanpa').isNotEmpty, 'parseTpWordsToCodepoints');
  check(tpWordsToUcsurCodepoints(<String>['nanpa', ':', 'wan', 'nanpa']).isNotEmpty, 'tpWordsToUcsurCodepoints');

  final hex = codepointsToHex(inner);
  check(hex.isNotEmpty, 'codepointsToHex');
  check(codepointsToHexWithCartouche(inner).isNotEmpty, 'codepointsToHexWithCartouche');
  check(parseHexCodepoints(hex).isNotEmpty, 'parseHexCodepoints');
  final wrapped = withCartoucheMarkers(inner);
  check(wrapped.length == inner.length + 2, 'withCartoucheMarkers');
  check(stripCartoucheMarkers(wrapped).length == inner.length, 'stripCartoucheMarkers');

  check(isValidCaps(caps), 'isValidCaps');
  check(isValidProperName(decimal.properName, options), 'isValidProperName');
  final time = parseNumber('12:30', options)!;
  check(time.caps != null && isValidTime(time.caps!, options), 'isValidTime');
  final date = parseNumber('2026-09-13', options)!;
  check(date.caps != null && isValidDate(date.caps!, options), 'isValidDate');
  check(isValidTimeOrDate(time.caps!, options), 'isValidTimeOrDate');

  final tokens = tokenizeCaps(caps, options);
  check(tokens.isNotEmpty, 'tokenizeCaps');
  check(capsTokensToTpWords(tokens, options).isNotEmpty, 'capsTokensToTpWords');
  check(capsToWords(caps, options).isNotEmpty, 'capsToWords');
  check(capsToCodepoints(caps, options) != null, 'capsToCodepoints');
  check(parseIdentifier('#~W', options) != null, 'parseIdentifier');

  check(normalizeVulgarFraction('½') == '1/2', 'normalizeVulgarFraction');
  check(normalizeTpWord('To-Ki!') == 'toki', 'normalizeTpWord');
  check(getSmallCodepointsSet().isNotEmpty, 'getSmallCodepointsSet');
  check(getQuarterCodepointsSet().isNotEmpty, 'getQuarterCodepointsSet');
  check(getOneThirdCodepointsSet().isNotEmpty, 'getOneThirdCodepointsSet');
  check(getTwoThirdsCodepointsSet().isNotEmpty, 'getTwoThirdsCodepointsSet');
  check(getHalfCodepointsSet().isNotEmpty, 'getHalfCodepointsSet');
  check(isAllowedTpUcsurCodepoint(0xF193D), 'isAllowedTpUcsurCodepoint');

  print('Dart Core-v1 public API smoke checks: 35/35 PASS');
}
