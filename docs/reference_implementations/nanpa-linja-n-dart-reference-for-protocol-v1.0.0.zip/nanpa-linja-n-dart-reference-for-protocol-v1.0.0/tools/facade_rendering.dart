import 'dart:convert';
import 'dart:io';

import 'package:nanpa_linja_n/nanpa_linja_n.dart';

bool _png(List<int> b) =>
    b.length >= 8 &&
    b[0] == 0x89 &&
    b[1] == 0x50 &&
    b[2] == 0x4E &&
    b[3] == 0x47 &&
    b[4] == 0x0D &&
    b[5] == 0x0A &&
    b[6] == 0x1A &&
    b[7] == 0x0A;

void check(bool condition, String name) {
  if (!condition) throw StateError('$name failed');
}

void main() {
  final root = File.fromUri(Platform.script).parent.parent;
  final nanpa = NanpaLinjaN.create();
  check(nanpa.listFonts().length == 8, '8 production fonts');
  check(nanpa.normalizeFontKey('linja-pona') == 'linjaPona', 'font alias');

  final defaultPng = nanpa.render('123.45');
  check(defaultPng.format == ProductionOutputFormat.png, 'default format PNG');
  check(_png(defaultPng.bytes), 'PNG signature');
  check(defaultPng.width > 0 && defaultPng.height > 0, 'PNG dimensions');

  final legacyPlan = nanpa.buildRenderPlan('12:30', font: 'linjaPona');
  check(legacyPlan.renderAdapterId == 'linja-pona-legacy-v1', 'linjaPona adapter');
  check(legacyPlan.legacyAscii, 'linjaPona legacy flag');
  check(legacyPlan.renderText.runes.every((cp) => cp >= 0x20 && cp <= 0x7E), 'linjaPona ASCII render text');
  check(_png(nanpa.renderToPng('12:30', font: 'linjaPona')), 'linjaPona PNG');

  final svg = nanpa.renderToSvg('#ABCDEF');
  final svgText = utf8.decode(svg, allowMalformed: true).toLowerCase();
  check(svgText.contains('<svg'), 'SVG payload');

  final pdf = nanpa.renderToPdf('0b10101');
  check(pdf.length >= 4 && ascii.decode(pdf.sublist(0, 4)) == '%PDF', 'PDF header');

  final casesFile = File(
    '${root.path}${Platform.pathSeparator}rendering${Platform.pathSeparator}font-golden-cases-v1.1.0.json',
  );
  final cases = ((jsonDecode(casesFile.readAsStringSync()) as Map<String, dynamic>)['cases'] as List).cast<Map>();
  var passed = 0;
  for (final font in nanpa.listFonts()) {
    for (final raw in cases) {
      final c = Map<String, dynamic>.from(raw);
      final result = nanpa.render(
        c['input'],
        font: font.key,
        fontSize: c['fontPx'] as int,
        abbreviate: c['abbreviateNumericCartouches'] == true,
        preserveNumericCartoucheBreaks:
            c['preserveNumericCartoucheBreaksInAbbreviation'] != false,
      );
      check(_png(result.bytes), '${font.key} ${c['id']} PNG signature');
      check(result.width > 0 && result.height > 0, '${font.key} ${c['id']} dimensions');
      passed++;
    }
  }
  print('Dart production-font facade: $passed/${nanpa.listFonts().length * cases.length} render cases PASS');
  print('Dart PNG/SVG/PDF production rendering smoke checks: PASS');
}
