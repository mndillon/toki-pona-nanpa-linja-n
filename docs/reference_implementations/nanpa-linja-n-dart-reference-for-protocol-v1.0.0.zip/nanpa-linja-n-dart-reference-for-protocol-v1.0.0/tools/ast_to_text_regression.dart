import 'package:nanpa_linja_n/nanpa_linja_n.dart';

void expect(bool condition, String name, List<String> failures) {
  if (!condition) failures.add(name);
}

DocumentAst replaceSegment(
  DocumentAst ast,
  bool Function(DocumentSegment segment) matches,
  DocumentSegment Function(DocumentSegment segment) replace,
) {
  var changed = false;
  final lines = <DocumentLine>[];
  for (final line in ast.lines) {
    final children = <DocumentSegment>[];
    for (final segment in line.children) {
      if (!changed && matches(segment)) {
        children.add(replace(segment));
        changed = true;
      } else {
        children.add(segment);
      }
    }
    lines.add(DocumentLine(
      index: line.index,
      sourceLineIndex: line.sourceLineIndex,
      sentenceIndexInSourceLine: line.sentenceIndexInSourceLine,
      sourceText: line.sourceText,
      children: List<DocumentSegment>.unmodifiable(children),
    ));
  }
  if (!changed) throw StateError('Requested AST segment was not found.');
  return DocumentAst(
    normalizedInput: ast.normalizedInput,
    breakLinesAtFullStops: ast.breakLinesAtFullStops,
    lines: List<DocumentLine>.unmodifiable(lines),
  );
}

DocumentSegment copySegment(
  DocumentSegment segment, {
  String? kind,
  String? value,
  ImageDescriptor? image,
  bool clearImage = false,
  String? openQuote,
  String? closeQuote,
}) =>
    DocumentSegment(
      kind: kind ?? segment.kind,
      value: value ?? segment.value,
      image: clearImage ? null : (image ?? segment.image),
      openQuote: openQuote ?? segment.openQuote,
      closeQuote: closeQuote ?? segment.closeQuote,
      sourceStart: segment.sourceStart,
      sourceEnd: segment.sourceEnd,
    );

bool sameImage(ImageDescriptor a, ImageDescriptor b) =>
    a.src == b.src &&
    a.width == b.width &&
    a.height == b.height &&
    a.alt == b.alt &&
    a.vAlign == b.vAlign &&
    a.wriggle == b.wriggle &&
    a.transparent == b.transparent;

void main() {
  final failures = <String>[];
  var checks = 0;

  void check(bool condition, String name) {
    checks++;
    expect(condition, name, failures);
  }

  const parser = FullParserOptions();

  // 1. Exact stored whitespace, blank lines, brackets, and straight quotes.
  const exactSource = 'jan   pona\t[ jan  pona,, ]\n\n"toki pona"';
  final exactAst = parseFullDocument(exactSource, parser);
  check(astToText(exactAst) == exactSource, 'exact whitespace/blank-line/quote round-trip');

  // 2. Curly quote delimiters are retained.
  const curlySource = 'jan “toki pona”';
  check(
    astToText(parseFullDocument(curlySource, parser)) == curlySource,
    'curly quote delimiter round-trip',
  );

  // 3. Sentence-split AST lines from one physical line are rejoined without a newline.
  const splitSource = 'jan. pona.\nmi.';
  final splitAst = parseFullDocument(
    splitSource,
    const FullParserOptions(breakLinesAtFullStops: true),
  );
  check(astToText(splitAst) == splitSource, 'breakLinesAtFullStops physical-line reconstruction');

  // 4. Edited bracket/cartouche content is serialized from current AST values.
  final bracketAst = parseFullDocument('jan [pona]', parser);
  final editedBracket = replaceSegment(
    bracketAst,
    (segment) => segment.kind == 'bracket',
    (segment) => copySegment(segment, value: 'suno'),
  );
  check(astToText(editedBracket) == 'jan [suno]', 'edited bracket serialization');

  // 5. Edited ordinary text is serialized from current AST values.
  final textAst = parseFullDocument('jan [pona]', parser);
  final editedText = replaceSegment(
    textAst,
    (segment) => segment.kind == 'text' && segment.value.startsWith('jan'),
    (segment) => copySegment(segment, value: 'meli '),
  );
  check(astToText(editedText) == 'meli [pona]', 'edited text serialization');

  // 6. Edited quote value and delimiters are respected.
  final quoteAst = parseFullDocument('jan "pona"', parser);
  final editedQuote = replaceSegment(
    quoteAst,
    (segment) => segment.kind == 'quote',
    (segment) => copySegment(
      segment,
      value: 'suno',
      openQuote: '“',
      closeQuote: '”',
    ),
  );
  check(astToText(editedQuote) == 'jan “suno”', 'edited quote serialization');

  // 7. img(...) lexical formatting is canonicalized, but descriptor semantics round-trip.
  const imageSource = "img(src='x.png', w='20',h=\"30\", alt='pic', valign='middle', wriggle=4, transparent=false)";
  final imageAst = parseFullDocument(imageSource, parser);
  final imageText = astToText(imageAst);
  final imageRoundTrip = parseFullDocument(imageText, parser);
  final firstImage = imageAst.lines.first.children.first.image;
  final secondImage = imageRoundTrip.lines.first.children.first.image;
  check(
    firstImage != null && secondImage != null && sameImage(firstImage, secondImage),
    'image semantic round-trip',
  );

  // 8. Unknown AST segment kinds fail instead of silently losing content.
  var rejectedUnknown = false;
  try {
    astToText(DocumentAst(
      normalizedInput: '',
      breakLinesAtFullStops: false,
      lines: const <DocumentLine>[
        DocumentLine(
          index: 0,
          sourceLineIndex: 0,
          sentenceIndexInSourceLine: 0,
          sourceText: '',
          children: <DocumentSegment>[
            DocumentSegment(kind: 'unknown', sourceStart: 0, sourceEnd: 0),
          ],
        ),
      ],
    ));
  } on ArgumentError {
    rejectedUnknown = true;
  }
  check(rejectedUnknown, 'unsupported segment rejection');

  if (failures.isNotEmpty) {
    for (final failure in failures) {
      print('FAIL $failure');
    }
    throw StateError('Dart astToText regression: ${checks - failures.length}/$checks PASS, ${failures.length} failure(s)');
  }

  print('Dart astToText regression: $checks/$checks PASS');

  // Native/full-renderer integration: edited AST -> text -> normal PNG renderer.
  final nanpa = NanpaLinjaN.create();
  final facadeAst = nanpa.parseInput('jan [pona]');
  final facadeEdited = replaceSegment(
    facadeAst,
    (segment) => segment.kind == 'bracket',
    (segment) => copySegment(segment, value: 'suno'),
  );
  final facadeText = nanpa.astToText(facadeEdited);
  final png = nanpa.renderFullToPng(facadeText);
  final pngOk = png.length >= 8 &&
      png[0] == 0x89 &&
      png[1] == 0x50 &&
      png[2] == 0x4E &&
      png[3] == 0x47;
  if (!pngOk) throw StateError('Dart astToText render integration failed');
  print('Dart astToText render integration: 1/1 PASS');
}
