#!/usr/bin/env python3
from pathlib import Path
import hashlib, sys
root=Path(__file__).resolve().parent.parent
pins=root/'validation'/'legacy-production-before.sha256'
fail=[]; count=0
for line in pins.read_text(encoding='utf-8').splitlines():
    if not line.strip(): continue
    digest, rel=line.split(None,1)
    p=root/rel
    if not p.is_file(): fail.append(f'missing {rel}'); continue
    actual=hashlib.sha256(p.read_bytes()).hexdigest(); count+=1
    if actual!=digest: fail.append(f'{rel}: {actual} != {digest}')
if fail:
    print('Dart legacy production rendering integrity FAIL')
    for x in fail: print(' -',x)
    sys.exit(1)
print(f'Dart legacy production rendering integrity: {count}/{count} unchanged PASS')
