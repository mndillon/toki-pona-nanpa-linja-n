import 'package:nanpa_linja_n/nanpa_linja_n.dart';

void check(bool condition, String name) {
  if (!condition) throw StateError('$name failed');
}

void main() {
  const renderer = NanpaRenderer();

  final time = renderer.render('12:30');
  check(time != null, 'time render');
  check(time!.activeWords.first == 'tenpo', 'time semantic opener');
  check(time.activeWords.last == 'nanpa', 'decimal closer');

  final hex = renderer.render('#ABCDEF');
  check(hex != null, 'hex render');
  check(hex!.fullWords.first == 'nasa' && hex.fullWords.last == 'nasa', 'hex paired marker');

  final binary = renderer.render('0b10101');
  check(binary != null, 'binary render');
  check(binary!.fullWords.first == 'noka' && binary.fullWords.last == 'noka', 'binary paired marker');

  final abbreviated = renderer.render(
    '#ABCDEF',
    const ParseOptions(abbreviateNumericCartouches: true),
  );
  check(abbreviated != null && abbreviated.abbreviated, 'abbreviated renderer selection');
  check(abbreviated!.activeWords.contains('kule'), 'hex compact grouping');
  check(abbreviated.unicodeText.isNotEmpty, 'renderer Unicode text');

  print('Dart logical renderer smoke checks: PASS');
}
