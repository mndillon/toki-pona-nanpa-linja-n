#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

targets=(
  "example.dart"
  "example_production.dart"
  "tools/api_surface_check.dart"
  "tools/run_dart_regression.dart"
  "tools/renderer_smoke.dart"
  "tools/facade_plan_conformance.dart"
  "tools/facade_rendering.dart"
  "tools/ast_to_text_regression.dart"
  "tools/full_renderer_profile.dart"
  "tools/visual_export.dart"
)

count=0
for target in "${targets[@]}"; do
  output="$TMP/$(basename "$target" .dart).dill"
  dart compile kernel "$target" -o "$output" >/dev/null
  count=$((count + 1))
done

echo "Dart compiler entry-point checks: ${count}/${#targets[@]} PASS"
