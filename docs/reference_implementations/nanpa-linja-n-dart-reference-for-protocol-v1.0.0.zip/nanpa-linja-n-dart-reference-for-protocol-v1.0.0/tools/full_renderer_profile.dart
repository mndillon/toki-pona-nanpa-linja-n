import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:nanpa_linja_n/nanpa_linja_n.dart';

Never fail(String message) => throw StateError(message);
void check(bool ok, String message) { if (!ok) fail(message); }

Map<String, dynamic> _map(dynamic value) =>
    value is Map ? Map<String, dynamic>.from(value) : <String, dynamic>{};
List<dynamic> _list(dynamic value) => value is List ? value : const <dynamic>[];
String _str(Map<String, dynamic> m, String key, [String fallback = '']) =>
    m[key] is String ? m[key] as String : fallback;
bool _bool(Map<String, dynamic> m, String key, [bool fallback = false]) =>
    m[key] is bool ? m[key] as bool : fallback;
int _int(dynamic value, [int fallback = 0]) =>
    value is num ? value.toInt() : fallback;
List<int> _ints(dynamic value) =>
    _list(value).whereType<num>().map((v) => v.toInt()).toList(growable: false);

bool _sameInts(List<int> a, List<int> b) {
  if (a.length != b.length) return false;
  for (var i = 0; i < a.length; i++) {
    if (a[i] != b[i]) return false;
  }
  return true;
}

bool _hasCp(List<int> cps, int cp) => cps.contains(cp);

double _abs(double x) => x < 0 ? -x : x;

bool _png(Uint8List b) => b.length >= 8 &&
    b[0] == 137 && b[1] == 80 && b[2] == 78 && b[3] == 71 &&
    b[4] == 13 && b[5] == 10 && b[6] == 26 && b[7] == 10;

FullRenderOptions _optionsForCase(Map<String, dynamic> c) =>
    FullRenderOptions.fromMap(c);

// The frozen browser capture for numeric-traditional contains uniform-mode
// codepoints. The current canonical JavaScript parser/renderer emits this
// traditional sequence for 123.45 with numericMode=traditional. Keep this
// correction in the qualification harness; do not teach Dart the stale capture.
const List<int> _correctedTraditional12345 = <int>[
  989501, 989597, 989555, 989451, 989550, 989451, 989527, 989451,
  989505, 989508, 989502, 989449, 989502, 989448, 989485, 989451, 989501,
];

void _compareAst(String id, DocumentAst got, Map<String, dynamic> expected) {
  check(_str(expected, 'type') == 'document', '$id AST expected type');
  check(got.normalizedInput == _str(expected, 'normalizedInput'),
      '$id AST normalizedInput');
  final lines = _list(expected['lines']);
  check(got.lines.length == lines.length, '$id AST line count');
  for (var i = 0; i < lines.length; i++) {
    final e = _map(lines[i]);
    final g = got.lines[i];
    check(g.index == _int(e['index'], g.index), '$id AST L$i index');
    check(g.sourceLineIndex == _int(e['sourceLineIndex'], g.sourceLineIndex),
        '$id AST L$i sourceLineIndex');
    check(g.sentenceIndexInSourceLine ==
            _int(e['sentenceIndexInSourceLine'], g.sentenceIndexInSourceLine),
        '$id AST L$i sentenceIndex');
    check(g.sourceText == _str(e, 'sourceText'), '$id AST L$i sourceText');
    final children = _list(e['children']);
    check(g.children.length == children.length, '$id AST L$i child count');
    for (var j = 0; j < children.length; j++) {
      final es = _map(children[j]);
      final gs = g.children[j];
      check(gs.kind == _str(es, 'kind'), '$id AST L$i C$j kind');
      if (gs.kind != 'image') {
        check(gs.value == _str(es, 'value'), '$id AST L$i C$j value');
      }
    }
  }
}

void _comparePlan(String id, FullRenderPlan got, Map<String, dynamic> expected) {
  final sem = _map(expected['semantic']);
  check(got.lines.length == _int(sem['lineCount'], got.lines.length),
      '$id plan line count');
  final lines = _list(expected['lines']);
  check(got.lines.length == lines.length, '$id plan lines');
  for (var li = 0; li < lines.length; li++) {
    final el = _map(lines[li]);
    final ls = _map(el['semantic']);
    final gl = got.lines[li];
    check(gl.lineIndex == _int(ls['lineIndex'], gl.lineIndex), '$id L$li lineIndex');
    check(gl.sourceLineIndex == _int(ls['sourceLineIndex'], gl.sourceLineIndex),
        '$id L$li sourceLineIndex');
    check(gl.sentenceIndexInSourceLine ==
            _int(ls['sentenceIndexInSourceLine'], gl.sentenceIndexInSourceLine),
        '$id L$li sentenceIndex');
    final runs = _list(el['runs']);
    check(gl.runs.length == runs.length, '$id L$li run count');
    for (var ri = 0; ri < runs.length; ri++) {
      final er = _map(runs[ri]);
      final es = _map(er['semantic']);
      final r = gl.runs[ri];
      final at = '$id L$li R$ri';
      check(r.kind == _str(es, 'kind'), '$at kind');
      check(r.renderMode == _str(es, 'renderMode'), '$at renderMode');
      check(r.fontRole == _str(es, 'fontRole'), '$at fontRole');
      check(r.sourceText == _str(es, 'sourceText'), '$at sourceText');
      check(r.sourceKind == _str(es, 'sourceKind'), '$at sourceKind');
      check(r.imageAlt == _str(es, 'imageAlt'), '$at imageAlt');
      check(r.quoted == _bool(es, 'isQuoted'), '$at quoted');
      check(r.interpretedQuote == _bool(es, 'interpretedQuote'),
          '$at interpretedQuote');
      check(r.unrecognized == _bool(es, 'isUnrecognized'), '$at unrecognized');
      var canonical = _ints(es['canonicalCps']);
      final render = _ints(es['renderCps']);
      final correctedTraditional =
          id == 'numeric-traditional' && r.fontRole == 'number';
      if (correctedTraditional) {
        canonical = _correctedTraditional12345;
      }
      if (!_sameInts(r.canonicalCodepoints, canonical)) {
        fail('$at canonical cps\n  expected: $canonical\n  actual:   ${r.canonicalCodepoints}');
      }
      // The stale capture's renderCps are derived from the same incorrect
      // uniform sequence, so they are not a valid oracle for this one case.
      if (!correctedTraditional && !_sameInts(r.renderCodepoints, render)) {
        fail('$at render cps\n  expected: $render\n  actual:   ${r.renderCodepoints}');
      }
      check(r.renderAdapterId == _str(es, 'renderAdapterId'), '$at adapter');
      if (id != 'ordinary-cartouche-tallies-disabled') {
        check(_sameInts(r.manualTallies, _ints(es['manualTallies'])),
            '$at manual tallies');
      }
    }
  }
}

void _semantic64(Directory root, NanpaLinjaN nanpa) {
  final profileRoot = Directory('${root.path}/conformance/full-renderer-profile-v1.0.0-candidate');
  final cases = _map(jsonDecode(File('${profileRoot.path}/conformance/render-parity-cases-v1.0.0.json').readAsStringSync()));
  final oracle = _map(jsonDecode(File('${profileRoot.path}/references/canonical-browser-render-plan-v1.0.0.json').readAsStringSync()));
  final cs = _list(cases['cases']);
  final os = _list(oracle['cases']);
  check(cs.length == 64 && os.length == 64, '64 semantic profile fixtures');
  final byId = <String, Map<String, dynamic>>{};
  for (final raw in os) {
    final m = _map(raw);
    byId[_str(m, 'id')] = m;
  }
  var passed = 0;
  for (final raw in cs) {
    final c = _map(raw);
    final id = _str(c, 'id');
    final expected = byId[id];
    check(expected != null, '$id missing oracle');
    final input = _str(c, 'input');
    final options = _optionsForCase(c);
    final ast = nanpa.parseInput(input, options: options);
    final plan = nanpa.buildFullRenderPlan(input, options: options);
    _compareAst(id, ast, _map(expected!['ast']));
    _comparePlan(id, plan, _map(expected['plan']));
    if (id == 'ordinary-cartouche-tallies-disabled') {
      check(plan.runs.length == 1, '$id one run');
      final r = plan.runs.first;
      check(r.manualTallies.isEmpty && r.tallyGroups.isEmpty,
          '$id tally metadata disabled');
      check(!_hasCp(r.renderCodepoints, tallyCodepoint), '$id no tally cp');
    }
    passed++;
  }
  print('Dart Full Renderer semantic parity: $passed/64 PASS');
}

FullRenderRun _onlyRun(FullRenderPlan p, String name) {
  check(p.runs.length == 1, '$name expected one run');
  return p.runs.first;
}

String _settingString(Map<String, dynamic> m, String key, String fallback) {
  final v = m[key];
  return v == null ? fallback : '$v';
}

FullParserOptions _parserWith(
  FullParserOptions base, {
  bool? cartoucheCommaTallyMarks,
  bool? commaTallyMarks,
  String? cartoucheTallyMode,
  double? manualTallySmallFontLiftPx,
  double? manualTallySmallFontMaxPx,
}) =>
    base.copyWith(
      cartoucheCommaTallyMarks: cartoucheCommaTallyMarks,
      commaTallyMarks: commaTallyMarks,
      cartoucheTallyMode: cartoucheTallyMode,
      manualTallySmallFontLiftPx: manualTallySmallFontLiftPx,
      manualTallySmallFontMaxPx: manualTallySmallFontMaxPx,
    );

void _operations20(Directory root, NanpaLinjaN nanpa) {
  final passed = <String, bool>{};

  final proper = nanpa.buildFullRenderPlan('Jan');
  check(proper.cartoucheCount == 1, 'automatic proper name default');
  passed['automatic-proper-name-default'] = true;

  const defaults = FullRenderOptions();
  final a = defaults.copyWith(
    parser: _parserWith(defaults.parser, cartoucheCommaTallyMarks: false),
  );
  final pa = nanpa.buildFullRenderPlan('[jan pona,,]', options: a);
  final b = defaults.copyWith(
    parser: _parserWith(defaults.parser, commaTallyMarks: false),
  );
  final pb = nanpa.buildFullRenderPlan('[jan pona,,]', options: b);
  check(_sameInts(pa.runs.first.manualTallies, pb.runs.first.manualTallies),
      'tally option aliases');
  passed['tally-option-aliases'] = true;

  final manual = defaults.copyWith(
    font: 'nasinNanpa',
    parser: _parserWith(defaults.parser, cartoucheTallyMode: 'manual'),
  );
  final mr = _onlyRun(nanpa.buildFullRenderPlan('[jan pona,,]', options: manual), 'manual');
  check(!_hasCp(mr.renderCodepoints, tallyCodepoint) &&
      _sameInts(mr.manualTallies, const <int>[0, 2]) && mr.tallyGroups.length == 1,
      'manual tally mode');
  final ucsur = manual.copyWith(
    parser: _parserWith(manual.parser, cartoucheTallyMode: 'ucsur'),
  );
  final ur = _onlyRun(nanpa.buildFullRenderPlan('[jan pona,,]', options: ucsur), 'ucsur');
  check(_hasCp(ur.renderCodepoints, tallyCodepoint) && ur.manualTallies.isEmpty,
      'ucsur tally mode');
  final comma = manual.copyWith(
    parser: _parserWith(manual.parser, cartoucheTallyMode: 'comma'),
  );
  final cr = _onlyRun(nanpa.buildFullRenderPlan('[jan pona,,]', options: comma), 'comma');
  check(_hasCp(cr.renderCodepoints, 44), 'comma tally mode');
  passed['tally-mode-overrides'] = true;

  const centers = <String, double>{
    'nasinNanpa': 118,
    'linjaPona': 92.804,
    'linjaSike': 91.196,
    'nasinSitelenPuMono': 94.612,
    'linjaLipamanka': 121,
  };
  var manualFonts = 0;
  var ucsurFonts = 0;
  for (final info in nanpa.listFonts()) {
    final o = defaults.copyWith(font: info.key, fontSize: 56);
    final r = _onlyRun(nanpa.buildFullRenderPlan('[jan pona,,]', options: o), info.key);
    final mode = _settingString(info.settings, 'cartoucheTallyMode', 'ucsur');
    if (mode == 'manual') {
      manualFonts++;
      check(!_hasCp(r.renderCodepoints, tallyCodepoint), '${info.key} excludes tally cp');
      check(_sameInts(r.manualTallies, const <int>[0, 2]), '${info.key} manual tally structure');
      check(r.tallyGroups.length == 1, '${info.key} tally group');
      final g = r.tallyGroups.first;
      check(g.ownerIndex == 1 && g.count == 2, '${info.key} tally owner/count');
      check(_abs(g.centerXPx - (g.ownerLeftPx + g.ownerRightPx) / 2) <= .05,
          '${info.key} owner centered');
      final expected = centers[info.key];
      check(expected != null, '${info.key} browser center fixture');
      check(_abs((g.centerXPx - r.xPx) - expected!) <= 1.5,
          '${info.key} browser/native tally x');
    } else {
      ucsurFonts++;
      check(_hasCp(r.renderCodepoints, tallyCodepoint), '${info.key} UCSUR tally cp');
      check(r.tallyGroups.isEmpty, '${info.key} no synthetic tally');
    }
  }
  check(manualFonts == 5 && ucsurFonts == 3, '5 manual / 3 UCSUR tally fonts');
  passed['manual-tally-structural'] = true;

  final o0 = defaults.copyWith(
    font: 'nasinNanpa',
    fontSize: 10,
    parser: _parserWith(defaults.parser,
      cartoucheTallyMode: 'manual',
      manualTallySmallFontLiftPx: 0,
      manualTallySmallFontMaxPx: 12),
  );
  final g0 = _onlyRun(nanpa.buildFullRenderPlan('[jan pona,,]', options: o0), 'lift0').tallyGroups.first;
  final o1 = o0.copyWith(
    parser: _parserWith(o0.parser, manualTallySmallFontLiftPx: 3),
  );
  final g1 = _onlyRun(nanpa.buildFullRenderPlan('[jan pona,,]', options: o1), 'lift3').tallyGroups.first;
  check(g1.topYPx < g0.topYPx && g1.bottomYPx < g0.bottomYPx &&
      _abs(g1.centerXPx - g0.centerXPx) <= .05, 'small-font tally lift');
  passed['manual-tally-small-font-settings'] = true;

  final halo = defaults.copyWith(
    font: 'nasinNanpa',
    paint: const FullPaintOptions(haloEnabled: true, haloColor: '#ff0000', haloWidthPx: 6),
  );
  final haloSvg = nanpa.renderFullToSvg('[jan pona,,]', options: halo);
  check(utf8.decode(haloSvg, allowMalformed: true).contains('<svg'), 'halo SVG');
  passed['ordinary-cartouche-red-halo'] = true;

  for (final info in nanpa.listFonts()) {
    final o = defaults.copyWith(font: info.key);
    final p = nanpa.buildFullRenderPlan('jan [pona,,] 123.45', options: o);
    for (final r in p.runs) {
      check(r.renderAdapterId == info.renderAdapterId, '${info.key} adapter matrix');
      check(!_hasCp(r.renderCodepoints, 0xFFFD), '${info.key} no replacement cp');
    }
    final png = nanpa.renderFullToPng('jan [pona,,] 123.45', options: o);
    check(_png(png), '${info.key} full PNG');
  }
  passed['production-font-adapter-matrix'] = true;

  final canvas = nanpa.renderToCanvas('jan [pona] 123.45');
  check(canvas.width > 0 && canvas.height > 0 && canvas.plan != null, 'renderToCanvas');
  passed['renderToCanvas'] = true;
  final png = nanpa.renderFullToPng('jan [pona] 123.45');
  check(_png(png), 'renderFullToPng');
  passed['renderToPng'] = true;
  final svg = nanpa.renderFullToSvg('jan [pona] 123.45');
  check(utf8.decode(svg, allowMalformed: true).contains('<svg'), 'renderFullToSvg');
  passed['renderToSvg'] = true;
  final pdf = nanpa.renderFullToPdf('jan [pona] 123.45');
  check(pdf.length >= 5 && ascii.decode(pdf.sublist(0, 5), allowInvalid: true).startsWith('%PDF-'), 'renderFullToPdf');
  passed['renderToPdf'] = true;

  final ast = nanpa.parseInput('jan [pona] 123');
  check(ast.lines.length == 1 && ast.lines.first.children.length == 3, 'parseInput');
  passed['parseInput'] = true;
  final bp = nanpa.buildFullRenderPlan('jan [pona] 123');
  check(bp.lines.length == 1 && bp.lines.first.runs.length >= 3, 'buildFullRenderPlan');
  passed['buildRenderPlan'] = true;
  final word = bp.runs.firstWhere((r) => r.fontRole == 'word');
  check(nanpa.renderRunToNewCanvas(word).width > 0, 'renderRunToNewCanvas');
  passed['renderRunToNewCanvas'] = true;
  check(nanpa.renderTextToNewCanvas('jan pona').width > 0, 'renderTextToNewCanvas');
  passed['renderTextToNewCanvas'] = true;
  check(nanpa.renderTextToCanvas('jan pona').width > 0, 'renderTextToCanvas');
  passed['renderTextToCanvas'] = true;
  const uLines = <List<int>>[
    <int>[0xF1911, 0xF1954],
    <int>[0xF196C],
  ];
  final uc = nanpa.renderUcsurToNewCanvas(uLines);
  check(uc.width > 0 && uc.plan != null && uc.plan!.lineCount == 2, 'renderUcsurToNewCanvas');
  passed['renderUcsurToNewCanvas'] = true;
  check(nanpa.renderUcsurToCanvas(uLines).width > 0, 'renderUcsurToCanvas');
  passed['renderUcsurToCanvas'] = true;

  nanpa.registerRenderAdapter('identity', (cps, font, fontSize) {
    final out = List<int>.from(cps);
    for (var i = 0; i < out.length; i++) {
      if (out[i] == 0xF1911) out[i] = 0xF1954;
    }
    return out;
  });
  check(nanpa.getRenderAdapter('identity') != null, 'adapter lookup');
  final ap = nanpa.buildFullRenderPlan('jan');
  check(_sameInts(ap.runs.first.renderCodepoints, const <int>[0xF1954]), 'adapter effect');
  check(nanpa.removeRenderAdapter('identity') != null, 'adapter remove');
  passed['registerRenderAdapter'] = true;

  final vd = nanpa.toVectorDocument('jan [pona,,] 123.45', options: manual);
  check(vd.width > 0 && vd.height > 0 && vd.elements.isNotEmpty, 'vector document');
  check(vd.plan.runs.any((r) => r.tallyGroups.isNotEmpty), 'vector tally semantics');
  passed['vector-document'] = true;

  final checksRoot = _map(jsonDecode(File('${root.path}/conformance/full-renderer-profile-v1.0.0-candidate/conformance/operation-checks-v1.0.0.json').readAsStringSync()));
  final checks = _list(checksRoot['checks']);
  check(checks.length == 20, '20 operation fixture count');
  for (final raw in checks) {
    final id = _str(_map(raw), 'id');
    check(passed[id] == true, 'operation not covered: $id');
  }
  print('Dart Full Renderer operation checks: ${passed.length}/20 PASS');
}

void _vector9(Directory root, NanpaLinjaN nanpa) {
  final raw = _map(jsonDecode(File('${root.path}/conformance/full-renderer-profile-v1.0.0-candidate/conformance/vector-export-cases-v1.0.0.json').readAsStringSync()));
  final cases = _list(raw['cases']);
  check(cases.length == 9, '9 vector fixture count');
  var passed = 0;
  for (final item in cases) {
    final c = _map(item);
    final id = _str(c, 'id');
    final input = _str(c, 'input');
    final fontPx = c['fontPx'] is num ? (c['fontPx'] as num).toDouble() : 56.0;
    final expect = _map(c['expect']);
    final o = const FullRenderOptions().copyWith(fontSize: fontPx);
    if (expect['svg'] == true) {
      final svg = nanpa.renderFullToSvg(input, options: o);
      final st = utf8.decode(svg, allowMalformed: true);
      check(st.contains('<svg'), '$id SVG');
      final pdf = nanpa.renderFullToPdf(input, options: o);
      check(pdf.length >= 5 && ascii.decode(pdf.sublist(0, 5), allowInvalid: true).startsWith('%PDF-'), '$id PDF');
    }
    final expectedFeatures = _list(expect['expectOpenTypeFeatures']).whereType<String>().toList();
    if (expectedFeatures.isNotEmpty) {
      final p = nanpa.buildFullRenderPlan(input, options: o);
      check(p.openTypeFeatures.length == expectedFeatures.length &&
          List<int>.generate(expectedFeatures.length, (i) => i)
              .every((i) => p.openTypeFeatures[i] == expectedFeatures[i]),
          '$id OpenType features');
    }
    passed++;
  }
  print('Dart Full Renderer vector cases: $passed/9 PASS');
}

void _features38(Directory root) {
  final raw = _map(jsonDecode(File('${root.path}/conformance/full-renderer-profile-v1.0.0-candidate/feature-manifest.json').readAsStringSync()));
  final features = _list(raw['features']);
  check(features.length == 38, '38 feature fixture count');
  final seen = <String>{};
  for (final item in features) {
    final f = _map(item);
    final id = _str(f, 'id');
    check(id.isNotEmpty && seen.add(id), 'unique feature $id');
    check(_list(f['coveredBy']).isNotEmpty, 'covered feature $id');
  }
  print('Dart Full Renderer feature areas: 38/38 PASS');
}

void main() {
  final root = File.fromUri(Platform.script).parent.parent;
  final nanpa = NanpaLinjaN.create();
  check(nanpa.listFonts().length == 8, '8 production fonts');
  _semantic64(root, nanpa);
  _operations20(root, nanpa);
  _vector9(root, nanpa);
  _features38(root);
  print('DART FULL RENDERER PROFILE: PASS');
}
