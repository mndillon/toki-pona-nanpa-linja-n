#!/usr/bin/env bash
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

REPORT_DIR="$ROOT/test-output"
REPORT="$REPORT_DIR/dart-regression-report.txt"
mkdir -p "$REPORT_DIR"
: > "$REPORT"

passed=0
failed=0
skipped=0
suite_names=()
suite_status=()

stamp() {
  date -u '+%Y-%m-%dT%H:%M:%SZ'
}

emit() {
  printf '%s\n' "$*" | tee -a "$REPORT"
}

run_suite() {
  local name="$1"
  shift
  suite_names+=("$name")
  emit ""
  emit "=== $name ==="
  emit "START $(stamp)"
  set +e
  "$@" > >(tee -a "$REPORT") 2> >(tee -a "$REPORT" >&2)
  local rc=$?
  set -u
  if [[ $rc -eq 0 ]]; then
    ((passed+=1))
    suite_status+=("PASS")
    emit "RESULT PASS ($name)"
  else
    ((failed+=1))
    suite_status+=("FAIL")
    emit "RESULT FAIL ($name) exit=$rc"
  fi
  emit "END $(stamp)"
  return 0
}

run_environment() {
  local rc=0
  echo "Working directory: $ROOT"
  echo "Dart executable: $(command -v dart || echo '<not found>')"
  if command -v dart >/dev/null 2>&1; then
    dart --version || rc=1
  else
    echo "FAIL: dart executable not found" >&2
    rc=127
  fi
  python3 --version || rc=1
  return "$rc"
}

run_suite "environment" run_environment
run_suite "current JavaScript-derived conformance authority" python3 tools/check_current_conformance.py
run_suite "core source integrity" python3 tools/check_core_source_integrity.py
run_suite "legacy rendering integrity" python3 tools/check_legacy_rendering_integrity.py
run_suite "production assets" python3 tools/check_production_assets.py
run_suite "dart pub get" dart pub get
run_suite "Dart compilation" ./tools/check_dart_compilation.sh
run_suite "API surface" dart run tools/api_surface_check.dart
run_suite "current protocol regression" dart run tools/run_dart_regression.dart
run_suite "renderer smoke" dart run tools/renderer_smoke.dart
run_suite "facade plan conformance" dart run tools/facade_plan_conformance.dart
run_suite "facade rendering" dart run tools/facade_rendering.dart
run_suite "astToText" dart run tools/ast_to_text_regression.dart
run_suite "special glyphs and low-level rerender parity" dart run tools/special_glyph_regression.dart
run_suite "canonical syntax and production adapters" dart run tools/canonical_syntax_regression.dart
run_suite "canonical full renderer" dart run tools/canonical_full_renderer_regression.dart
run_suite "mixed-feature JavaScript interactions" dart run tools/composition_interaction_regression.dart
run_suite "legacy full renderer profile" dart run tools/full_renderer_profile.dart

emit ""
emit "=== CONSOLIDATED SUMMARY ==="
for ((i=0; i<${#suite_names[@]}; i++)); do
  emit "${suite_status[$i]}: ${suite_names[$i]}"
done
emit ""
emit "configured suites: ${#suite_names[@]}"
emit "passed suites: $passed"
emit "failed suites: $failed"
emit "skipped suites: $skipped"
emit "report: $REPORT"

if [[ $failed -eq 0 ]]; then
  emit "ALL CONFIGURED DART TESTS PASS"
  exit 0
fi

emit "DART REGRESSION FAILED: $failed suite(s) failed; all configured suites were attempted."
exit 1
