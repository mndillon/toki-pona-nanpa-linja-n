#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

echo "nanpa-linja-n Dart reference regression"
echo "========================================"
dart --version
python3 tools/check_core_source_integrity.py
python3 tools/check_legacy_rendering_integrity.py
python3 tools/check_production_assets.py
dart pub get
./tools/check_dart_compilation.sh
dart run tools/api_surface_check.dart
dart run tools/run_dart_regression.dart
dart run tools/renderer_smoke.dart
dart run tools/facade_plan_conformance.dart
dart run tools/facade_rendering.dart

echo "=== astToText ==="
dart run tools/ast_to_text_regression.dart

dart run tools/full_renderer_profile.dart

echo "ALL CONFIGURED DART FULL REFERENCE TESTS PASS"
