package assets

import (
	"embed"
	"fmt"
)

// ProductionFS embeds the frozen Production Rendering Profile font assets.
//
//go:embed fonts/*
var ProductionFS embed.FS

func ReadFont(name string) ([]byte, error) {
	b, err := ProductionFS.ReadFile("fonts/" + name)
	if err != nil {
		return nil, fmt.Errorf("embedded production font %q: %w", name, err)
	}
	return b, nil
}

func Manifest() ([]byte, error) {
	return ProductionFS.ReadFile("fonts/preloaded-font-pairs.manifest.json")
}
