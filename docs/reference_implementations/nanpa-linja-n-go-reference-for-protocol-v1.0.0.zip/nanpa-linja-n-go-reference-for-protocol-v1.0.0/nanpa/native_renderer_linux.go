//go:build linux && cgo

package nanpa

/*
#include <stdlib.h>
#include <stdint.h>
#include <dlfcn.h>

#cgo linux LDFLAGS: -ldl

typedef void cairo_surface_t;
typedef void cairo_t;
typedef void PangoLayout;
typedef void PangoFontDescription;
typedef void PangoAttrList;
typedef void PangoAttribute;
typedef void PangoFontMap;
typedef void FcConfig;
typedef unsigned char FcChar8;
typedef struct { int x; int y; int width; int height; } PangoRectangle;

typedef cairo_surface_t* (*fn_cairo_image_surface_create)(int,int,int);
typedef cairo_surface_t* (*fn_cairo_file_surface_create)(const char*,double,double);
typedef cairo_t* (*fn_cairo_create)(cairo_surface_t*);
typedef void (*fn_void_ptr)(void*);
typedef int (*fn_int_surface)(cairo_surface_t*);
typedef int (*fn_write_png)(cairo_surface_t*,const char*);
typedef void (*fn_cairo_set_operator)(cairo_t*,int);
typedef void (*fn_cairo_set_rgba)(cairo_t*,double,double,double,double);
typedef void (*fn_cairo_move_to)(cairo_t*,double,double);
typedef PangoLayout* (*fn_pango_create_layout)(cairo_t*);
typedef void (*fn_pango_show_layout)(cairo_t*,PangoLayout*);
typedef PangoFontMap* (*fn_pango_fontmap_default)(void);
typedef PangoFontDescription* (*fn_pango_desc_new)(void);
typedef void (*fn_pango_desc_family)(PangoFontDescription*,const char*);
typedef void (*fn_pango_desc_size)(PangoFontDescription*,double);
typedef void (*fn_pango_layout_text)(PangoLayout*,const char*,int);
typedef void (*fn_pango_layout_desc)(PangoLayout*,const PangoFontDescription*);
typedef PangoAttrList* (*fn_pango_attr_list_new)(void);
typedef PangoAttribute* (*fn_pango_attr_features_new)(const char*);
typedef void (*fn_pango_attr_insert)(PangoAttrList*,PangoAttribute*);
typedef void (*fn_pango_layout_attrs)(PangoLayout*,PangoAttrList*);
typedef void (*fn_pango_extents)(PangoLayout*,PangoRectangle*,PangoRectangle*);
typedef int (*fn_fc_init)(void);
typedef FcConfig* (*fn_fc_current)(void);
typedef int (*fn_fc_add)(FcConfig*,const FcChar8*);
typedef int (*fn_fc_build)(FcConfig*);

static fn_cairo_image_surface_create p_cairo_image_surface_create;
static fn_cairo_file_surface_create p_cairo_svg_surface_create;
static fn_cairo_file_surface_create p_cairo_pdf_surface_create;
static fn_cairo_create p_cairo_create;
static fn_void_ptr p_cairo_destroy;
static fn_void_ptr p_cairo_surface_destroy;
static fn_void_ptr p_cairo_surface_finish;
static fn_int_surface p_cairo_surface_status;
static fn_write_png p_cairo_surface_write_to_png;
static fn_cairo_set_operator p_cairo_set_operator;
static fn_cairo_set_rgba p_cairo_set_source_rgba;
static fn_void_ptr p_cairo_paint;
static fn_cairo_move_to p_cairo_move_to;
static fn_pango_create_layout p_pango_cairo_create_layout;
static fn_pango_show_layout p_pango_cairo_show_layout;
static fn_pango_fontmap_default p_pango_cairo_font_map_get_default;
static fn_void_ptr p_pango_fc_font_map_config_changed;
static fn_pango_desc_new p_pango_font_description_new;
static fn_pango_desc_family p_pango_font_description_set_family;
static fn_pango_desc_size p_pango_font_description_set_absolute_size;
static fn_void_ptr p_pango_font_description_free;
static fn_pango_layout_text p_pango_layout_set_text;
static fn_pango_layout_desc p_pango_layout_set_font_description;
static fn_pango_attr_list_new p_pango_attr_list_new;
static fn_pango_attr_features_new p_pango_attr_font_features_new;
static fn_pango_attr_insert p_pango_attr_list_insert;
static fn_pango_layout_attrs p_pango_layout_set_attributes;
static fn_void_ptr p_pango_attr_list_unref;
static fn_pango_extents p_pango_layout_get_pixel_extents;
static fn_void_ptr p_g_object_unref;
static fn_fc_init p_FcInit;
static fn_fc_current p_FcConfigGetCurrent;
static fn_fc_add p_FcConfigAppFontAddFile;
static fn_fc_build p_FcConfigBuildFonts;

static int nl_loaded = 0;
static void *h_cairo = NULL;
static void *h_pango = NULL;
static void *h_pangocairo = NULL;
static void *h_pangoft2 = NULL;
static void *h_fontconfig = NULL;
static void *h_gobject = NULL;

static void *nl_open(const char *name) { return dlopen(name, RTLD_LAZY | RTLD_LOCAL); }
#define NL_SYM_H(var, handle, name) do { var = (__typeof__(var))dlsym(handle, name); if (!(var)) return -100; } while(0)

static int nl_load(void) {
    if (nl_loaded) return 0;
    h_cairo = nl_open("libcairo.so.2"); if (!h_cairo) return -101;
    h_pango = nl_open("libpango-1.0.so.0"); if (!h_pango) return -102;
    h_pangocairo = nl_open("libpangocairo-1.0.so.0"); if (!h_pangocairo) return -103;
    h_pangoft2 = nl_open("libpangoft2-1.0.so.0"); if (!h_pangoft2) return -104;
    h_fontconfig = nl_open("libfontconfig.so.1"); if (!h_fontconfig) return -105;
    h_gobject = nl_open("libgobject-2.0.so.0"); if (!h_gobject) return -106;
    NL_SYM_H(p_cairo_image_surface_create, h_cairo, "cairo_image_surface_create");
    NL_SYM_H(p_cairo_svg_surface_create, h_cairo, "cairo_svg_surface_create");
    NL_SYM_H(p_cairo_pdf_surface_create, h_cairo, "cairo_pdf_surface_create");
    NL_SYM_H(p_cairo_create, h_cairo, "cairo_create");
    NL_SYM_H(p_cairo_destroy, h_cairo, "cairo_destroy");
    NL_SYM_H(p_cairo_surface_destroy, h_cairo, "cairo_surface_destroy");
    NL_SYM_H(p_cairo_surface_finish, h_cairo, "cairo_surface_finish");
    NL_SYM_H(p_cairo_surface_status, h_cairo, "cairo_surface_status");
    NL_SYM_H(p_cairo_surface_write_to_png, h_cairo, "cairo_surface_write_to_png");
    NL_SYM_H(p_cairo_set_operator, h_cairo, "cairo_set_operator");
    NL_SYM_H(p_cairo_set_source_rgba, h_cairo, "cairo_set_source_rgba");
    NL_SYM_H(p_cairo_paint, h_cairo, "cairo_paint");
    NL_SYM_H(p_cairo_move_to, h_cairo, "cairo_move_to");
    NL_SYM_H(p_pango_cairo_create_layout, h_pangocairo, "pango_cairo_create_layout");
    NL_SYM_H(p_pango_cairo_show_layout, h_pangocairo, "pango_cairo_show_layout");
    NL_SYM_H(p_pango_cairo_font_map_get_default, h_pangocairo, "pango_cairo_font_map_get_default");
    NL_SYM_H(p_pango_fc_font_map_config_changed, h_pangoft2, "pango_fc_font_map_config_changed");
    NL_SYM_H(p_pango_font_description_new, h_pango, "pango_font_description_new");
    NL_SYM_H(p_pango_font_description_set_family, h_pango, "pango_font_description_set_family");
    NL_SYM_H(p_pango_font_description_set_absolute_size, h_pango, "pango_font_description_set_absolute_size");
    NL_SYM_H(p_pango_font_description_free, h_pango, "pango_font_description_free");
    NL_SYM_H(p_pango_layout_set_text, h_pango, "pango_layout_set_text");
    NL_SYM_H(p_pango_layout_set_font_description, h_pango, "pango_layout_set_font_description");
    NL_SYM_H(p_pango_attr_list_new, h_pango, "pango_attr_list_new");
    NL_SYM_H(p_pango_attr_font_features_new, h_pango, "pango_attr_font_features_new");
    NL_SYM_H(p_pango_attr_list_insert, h_pango, "pango_attr_list_insert");
    NL_SYM_H(p_pango_layout_set_attributes, h_pango, "pango_layout_set_attributes");
    NL_SYM_H(p_pango_attr_list_unref, h_pango, "pango_attr_list_unref");
    NL_SYM_H(p_pango_layout_get_pixel_extents, h_pango, "pango_layout_get_pixel_extents");
    NL_SYM_H(p_g_object_unref, h_gobject, "g_object_unref");
    NL_SYM_H(p_FcInit, h_fontconfig, "FcInit");
    NL_SYM_H(p_FcConfigGetCurrent, h_fontconfig, "FcConfigGetCurrent");
    NL_SYM_H(p_FcConfigAppFontAddFile, h_fontconfig, "FcConfigAppFontAddFile");
    NL_SYM_H(p_FcConfigBuildFonts, h_fontconfig, "FcConfigBuildFonts");
    if (!p_FcInit()) return -107;
    nl_loaded = 1;
    return 0;
}

static int nl_register_font(const char *path) {
    int l = nl_load(); if (l != 0) return l;
    FcConfig *config = p_FcConfigGetCurrent();
    if (!config) return -2;
    if (!p_FcConfigAppFontAddFile(config, (const FcChar8*)path)) return -3;
    if (!p_FcConfigBuildFonts(config)) return -4;
    PangoFontMap *fontmap = p_pango_cairo_font_map_get_default();
    if (!fontmap) return -5;
    p_pango_fc_font_map_config_changed(fontmap);
    return 0;
}

static PangoLayout *nl_layout(cairo_t *cr, const char *text, const char *family, int font_size, const char *features) {
    PangoLayout *layout = p_pango_cairo_create_layout(cr);
    if (!layout) return NULL;
    PangoFontDescription *desc = p_pango_font_description_new();
    if (!desc) { p_g_object_unref(layout); return NULL; }
    p_pango_font_description_set_family(desc, family);
    p_pango_font_description_set_absolute_size(desc, (double)font_size * 1024.0);
    p_pango_layout_set_font_description(layout, desc);
    p_pango_layout_set_text(layout, text, -1);
    p_pango_font_description_free(desc);
    if (features && features[0]) {
        PangoAttrList *attrs = p_pango_attr_list_new();
        if (!attrs) { p_g_object_unref(layout); return NULL; }
        PangoAttribute *attr = p_pango_attr_font_features_new(features);
        if (!attr) { p_pango_attr_list_unref(attrs); p_g_object_unref(layout); return NULL; }
        p_pango_attr_list_insert(attrs, attr);
        p_pango_layout_set_attributes(layout, attrs);
        p_pango_attr_list_unref(attrs);
    }
    return layout;
}

static int nl_measure(const char *text, const char *family, int font_size, const char *features, PangoRectangle *out) {
    int l = nl_load(); if (l != 0) return l;
    cairo_surface_t *surface = p_cairo_image_surface_create(0, 1, 1);
    if (!surface || p_cairo_surface_status(surface) != 0) return -10;
    cairo_t *cr = p_cairo_create(surface);
    if (!cr) { p_cairo_surface_destroy(surface); return -11; }
    PangoLayout *layout = nl_layout(cr, text, family, font_size, features);
    if (!layout) { p_cairo_destroy(cr); p_cairo_surface_destroy(surface); return -12; }
    PangoRectangle ink = {0,0,0,0};
    PangoRectangle logical = {0,0,0,0};
    p_pango_layout_get_pixel_extents(layout, &ink, &logical);
    *out = ink;
    if (out->width <= 0 || out->height <= 0) *out = logical;
    p_g_object_unref(layout);
    p_cairo_destroy(cr);
    p_cairo_surface_destroy(surface);
    if (out->width <= 0 || out->height <= 0) return -13;
    return 0;
}

static int nl_render_file(const char *text, const char *family, int font_size, const char *features,
                          int padding, int format, const char *filename,
                          double fr, double fg, double fb, double fa,
                          double br, double bg, double bb, double ba,
                          int *out_width, int *out_height) {
    PangoRectangle metrics;
    int m = nl_measure(text, family, font_size, features, &metrics);
    if (m != 0) return m;
    if (padding < 0) padding = 0;
    int width = metrics.width + padding * 2;
    int height = metrics.height + padding * 2;
    if (width < 1) width = 1; if (height < 1) height = 1;
    cairo_surface_t *surface = NULL;
    if (format == 0) surface = p_cairo_image_surface_create(0, width, height);
    else if (format == 1) surface = p_cairo_svg_surface_create(filename, (double)width, (double)height);
    else if (format == 2) surface = p_cairo_pdf_surface_create(filename, (double)width, (double)height);
    else return -20;
    if (!surface || p_cairo_surface_status(surface) != 0) { if (surface) p_cairo_surface_destroy(surface); return -21; }
    cairo_t *cr = p_cairo_create(surface);
    if (!cr) { p_cairo_surface_destroy(surface); return -22; }
    p_cairo_set_operator(cr, 1);
    p_cairo_set_source_rgba(cr, br,bg,bb,ba);
    p_cairo_paint(cr);
    p_cairo_set_operator(cr, 2);
    p_cairo_set_source_rgba(cr, fr,fg,fb,fa);
    PangoLayout *layout = nl_layout(cr, text, family, font_size, features);
    if (!layout) { p_cairo_destroy(cr); p_cairo_surface_destroy(surface); return -23; }
    p_cairo_move_to(cr, (double)(padding - metrics.x), (double)(padding - metrics.y));
    p_pango_cairo_show_layout(cr, layout);
    p_g_object_unref(layout);
    int status = 0;
    if (format == 0) status = p_cairo_surface_write_to_png(surface, filename);
    p_cairo_surface_finish(surface);
    p_cairo_destroy(cr);
    p_cairo_surface_destroy(surface);
    if (status != 0) return -24;
    *out_width = width; *out_height = height;
    return 0;
}
*/
import "C"

import (
	"fmt"
	"os"
	"strings"
	"sync"
	"unsafe"
)

var nativeFontMu sync.Mutex
var nativeRegisteredFonts = map[string]bool{}

func ProductionNativeRenderingAvailable() bool { return true }

func nativeRegisterFont(path string) error {
	nativeFontMu.Lock()
	defer nativeFontMu.Unlock()
	if nativeRegisteredFonts[path] {
		return nil
	}
	cpath := C.CString(path)
	defer C.free(unsafe.Pointer(cpath))
	if status := int(C.nl_register_font(cpath)); status != 0 {
		return fmt.Errorf("Fontconfig production-font registration failed (%d): %s", status, path)
	}
	nativeRegisteredFonts[path] = true
	return nil
}

func nativeRenderProductionText(text, family, fontPath string, fontSize int, features []string, padding int, format OutputFormat, fg, bg RGBA) ([]byte, int, int, error) {
	if err := nativeRegisterFont(fontPath); err != nil {
		return nil, 0, 0, err
	}
	temp, err := os.CreateTemp("", "nanpa_linja_n_go_render_*."+string(format))
	if err != nil {
		return nil, 0, 0, err
	}
	path := temp.Name()
	_ = temp.Close()
	defer os.Remove(path)
	ct := C.CString(text)
	defer C.free(unsafe.Pointer(ct))
	cf := C.CString(family)
	defer C.free(unsafe.Pointer(cf))
	cp := C.CString(path)
	defer C.free(unsafe.Pointer(cp))
	featureText := make([]string, 0, len(features))
	for _, f := range features {
		featureText = append(featureText, f+"=1")
	}
	cfeatures := C.CString(strings.Join(featureText, ","))
	defer C.free(unsafe.Pointer(cfeatures))
	formatCode := 0
	if format == OutputSVG {
		formatCode = 1
	} else if format == OutputPDF {
		formatCode = 2
	} else if format != OutputPNG {
		return nil, 0, 0, fmt.Errorf("unsupported production output format: %s", format)
	}
	var width, height C.int
	toFloat := func(v uint8) C.double { return C.double(float64(v) / 255.0) }
	status := int(C.nl_render_file(ct, cf, C.int(fontSize), cfeatures, C.int(padding), C.int(formatCode), cp,
		toFloat(fg.R), toFloat(fg.G), toFloat(fg.B), toFloat(fg.A),
		toFloat(bg.R), toFloat(bg.G), toFloat(bg.B), toFloat(bg.A), &width, &height))
	if status != 0 {
		return nil, 0, 0, fmt.Errorf("native Pango/Cairo production rendering failed (%d) for %s", status, family)
	}
	bytes, err := os.ReadFile(path)
	if err != nil {
		return nil, 0, 0, err
	}
	if len(bytes) == 0 {
		return nil, 0, 0, fmt.Errorf("%s renderer produced no bytes", format)
	}
	return bytes, int(width), int(height), nil
}
