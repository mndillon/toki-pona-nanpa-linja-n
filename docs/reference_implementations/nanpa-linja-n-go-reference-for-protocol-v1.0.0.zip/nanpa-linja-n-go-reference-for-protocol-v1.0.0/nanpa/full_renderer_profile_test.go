package nanpa

import (
	"bytes"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"image"
	"os"
	"path/filepath"
	"reflect"
	"testing"
)

type profileCase struct {
	ID       string         `json:"id"`
	Input    string         `json:"input"`
	Font     string         `json:"font"`
	FontSize float64        `json:"fontSize"`
	Parser   map[string]any `json:"parser"`
	Layout   map[string]any `json:"layout"`
	Paint    map[string]any `json:"paint"`
}

type profileCaseRoot struct {
	Cases []profileCase `json:"cases"`
}
type profileOracleCase struct {
	ID   string         `json:"id"`
	AST  map[string]any `json:"ast"`
	Plan map[string]any `json:"plan"`
}
type profileOracleRoot struct {
	Cases []profileOracleCase `json:"cases"`
}

func loadJSONTest(t *testing.T, path string, out any) {
	t.Helper()
	b, e := os.ReadFile(path)
	if e != nil {
		t.Fatal(e)
	}
	if e = json.Unmarshal(b, out); e != nil {
		t.Fatal(e)
	}
}
func boolv(m map[string]any, k string, d bool) bool {
	if v, ok := m[k].(bool); ok {
		return v
	}
	return d
}
func strv(m map[string]any, k, d string) string {
	if v, ok := m[k].(string); ok {
		return v
	}
	return d
}
func numv(m map[string]any, k string, d float64) float64 {
	if v, ok := m[k].(float64); ok {
		return v
	}
	return d
}
func ptrnum(m map[string]any, k string, cur *float64) *float64 {
	if v, ok := m[k].(float64); ok {
		x := v
		return &x
	}
	return cur
}
func optionsForProfileCase(c profileCase) FullRenderOptions {
	o := DefaultFullRenderOptions()
	if c.Font != "" {
		o.Font = c.Font
	}
	if c.FontSize != 0 {
		o.FontSize = c.FontSize
	}
	p := c.Parser
	o.Parser.EnableBinaryParsing = boolv(p, "enableBinaryParsing", o.Parser.EnableBinaryParsing)
	o.Parser.EnableHexParsing = boolv(p, "enableHexParsing", o.Parser.EnableHexParsing)
	o.Parser.Mode = strv(p, "mode", o.Parser.Mode)
	o.Parser.NumericMode = strv(p, "numericMode", o.Parser.NumericMode)
	o.Parser.NanpaColonParsing = boolv(p, "nanpaColonParsing", o.Parser.NanpaColonParsing)
	o.Parser.NanpaColonRendering = boolv(p, "nanpaColonRendering", o.Parser.NanpaColonRendering)
	o.Parser.RelaxedNanpaLinjanParsing = boolv(p, "relaxedNanpaLinjanParsing", o.Parser.RelaxedNanpaLinjanParsing)
	o.Parser.RelaxedNanpaLinjanRendering = boolv(p, "relaxedNanpaLinjanRendering", o.Parser.RelaxedNanpaLinjanRendering)
	o.Parser.AbbreviateNumericCartouches = boolv(p, "abbreviateNumericCartouches", o.Parser.AbbreviateNumericCartouches)
	o.Parser.PreserveNumericCartoucheBreaks = boolv(p, "preserveNumericCartoucheBreaksInAbbreviation", o.Parser.PreserveNumericCartoucheBreaks)
	o.Parser.NumericCartoucheStartGlyph = strv(p, "numericCartoucheStartGlyph", o.Parser.NumericCartoucheStartGlyph)
	o.Parser.RendererMode = strv(p, "rendererMode", o.Parser.RendererMode)
	o.Parser.MixedStyle = strv(p, "mixedStyle", o.Parser.MixedStyle)
	o.Parser.BreakLinesAtFullStops = boolv(p, "breakLinesAtFullStops", o.Parser.BreakLinesAtFullStops)
	o.Parser.ShowUnknownText = boolv(p, "showUnknownText", o.Parser.ShowUnknownText)
	o.Parser.AutoCartoucheStandaloneProperNames = boolv(p, "autoCartoucheStandaloneProperNames", o.Parser.AutoCartoucheStandaloneProperNames)
	o.Parser.InterpretDoubleQuotesAsTeTo = boolv(p, "interpretDoubleQuotesAsTeTo", o.Parser.InterpretDoubleQuotesAsTeTo)
	o.Parser.CartoucheCommaTallyMarks = boolv(p, "cartoucheCommaTallyMarks", o.Parser.CartoucheCommaTallyMarks)
	o.Parser.CartoucheTallyMode = strv(p, "cartoucheTallyMode", o.Parser.CartoucheTallyMode)
	o.Parser.ManualTallySmallFontLiftPx = ptrnum(p, "manualTallySmallFontLiftPx", o.Parser.ManualTallySmallFontLiftPx)
	o.Parser.ManualTallySmallFontMaxPx = ptrnum(p, "manualTallySmallFontMaxPx", o.Parser.ManualTallySmallFontMaxPx)
	o.Parser.NasinNanpaPona = boolv(p, "nasinNanpaPona", o.Parser.NasinNanpaPona)
	l := c.Layout
	o.Layout.Align = strv(l, "align", o.Layout.Align)
	o.Layout.SpacingPreset = strv(l, "spacingPreset", o.Layout.SpacingPreset)
	o.Layout.GlyphGapScale = ptrnum(l, "glyphGapScale", o.Layout.GlyphGapScale)
	o.Layout.GlyphGapMinPx = ptrnum(l, "glyphGapMinPx", o.Layout.GlyphGapMinPx)
	o.Layout.GlyphGapMaxPx = ptrnum(l, "glyphGapMaxPx", o.Layout.GlyphGapMaxPx)
	o.Layout.CartoucheLeadGapScale = ptrnum(l, "cartoucheLeadGapScale", o.Layout.CartoucheLeadGapScale)
	o.Layout.CartouchePadScale = ptrnum(l, "cartouchePadScale", o.Layout.CartouchePadScale)
	o.Layout.CartouchePadMinPx = ptrnum(l, "cartouchePadMinPx", o.Layout.CartouchePadMinPx)
	o.Layout.LineGapPx = ptrnum(l, "lineGapPx", o.Layout.LineGapPx)
	o.Layout.ForceLineGapPx = boolv(l, "forceLineGapPx", o.Layout.ForceLineGapPx)
	pa := c.Paint
	o.Paint.FillStyle = strv(pa, "fillStyle", o.Paint.FillStyle)
	if u, ok := pa["unknownText"].(map[string]any); ok {
		o.Paint.UnknownText.Style = strv(u, "style", o.Paint.UnknownText.Style)
		o.Paint.UnknownText.Color = strv(u, "color", o.Paint.UnknownText.Color)
		o.Paint.UnknownText.LineWidthPx = numv(u, "lineWidthPx", o.Paint.UnknownText.LineWidthPx)
		o.Paint.UnknownText.PaddingPx = numv(u, "paddingPx", o.Paint.UnknownText.PaddingPx)
		if a, ok := u["dash"].([]any); ok {
			o.Paint.UnknownText.Dash = nil
			for _, x := range a {
				if f, ok := x.(float64); ok {
					o.Paint.UnknownText.Dash = append(o.Paint.UnknownText.Dash, f)
				}
			}
		}
	}
	if h, ok := pa["halo"].(map[string]any); ok {
		o.Paint.HaloEnabled = boolv(h, "enabled", o.Paint.HaloEnabled)
		o.Paint.HaloColor = strv(h, "color", o.Paint.HaloColor)
		o.Paint.HaloWidthPx = numv(h, "widthPx", o.Paint.HaloWidthPx)
	}
	return o
}
func anyInt(a any, d int) int {
	if f, ok := a.(float64); ok {
		return int(f)
	}
	return d
}
func intsAny(a any) []int {
	xs, ok := a.([]any)
	if !ok {
		return nil
	}
	r := make([]int, 0, len(xs))
	for _, v := range xs {
		if f, ok := v.(float64); ok {
			r = append(r, int(f))
		}
	}
	return r
}
func stringsEqualInt(a, b []int) bool {
	if len(a) != len(b) {
		return false
	}
	if len(a) == 0 {
		return true
	}
	return reflect.DeepEqual(a, b)
}

var correctedTraditional12345 = []int{989501, 989597, 989555, 989451, 989550, 989451, 989527, 989451, 989505, 989508, 989502, 989449, 989502, 989448, 989485, 989451, 989501}

func compareProfileAST(t *testing.T, cid string, g DocumentAST, e map[string]any) {
	t.Helper()
	if g.Type != strv(e, "type", "") {
		t.Fatalf("%s AST type got %q", cid, g.Type)
	}
	if g.NormalizedInput != strv(e, "normalizedInput", "") {
		t.Fatalf("%s AST normalized input got %q want %q", cid, g.NormalizedInput, strv(e, "normalizedInput", ""))
	}
	ls, _ := e["lines"].([]any)
	if len(g.Lines) != len(ls) {
		t.Fatalf("%s AST line count %d want %d", cid, len(g.Lines), len(ls))
	}
	for i, x := range ls {
		em := x.(map[string]any)
		gl := g.Lines[i]
		if gl.Index != anyInt(em["index"], gl.Index) || gl.SourceLineIndex != anyInt(em["sourceLineIndex"], gl.SourceLineIndex) || gl.SentenceIndexInSourceLine != anyInt(em["sentenceIndexInSourceLine"], gl.SentenceIndexInSourceLine) || gl.SourceText != strv(em, "sourceText", "") {
			t.Fatalf("%s AST line %d metadata mismatch got %#v expected %#v", cid, i, gl, em)
		}
		ecs, _ := em["children"].([]any)
		if len(gl.Children) != len(ecs) {
			t.Fatalf("%s AST child count L%d %d want %d", cid, i, len(gl.Children), len(ecs))
		}
		for j, y := range ecs {
			es := y.(map[string]any)
			gs := gl.Children[j]
			if gs.Kind != strv(es, "kind", "") {
				t.Fatalf("%s AST segment kind %d/%d got %s want %s", cid, i, j, gs.Kind, strv(es, "kind", ""))
			}
			if gs.Kind != "image" && gs.Value != strv(es, "value", "") {
				t.Fatalf("%s AST segment value %d/%d got %q want %q", cid, i, j, gs.Value, strv(es, "value", ""))
			}
		}
	}
}
func compareProfilePlan(t *testing.T, cid string, g FullRenderPlan, e map[string]any) {
	t.Helper()
	sem, _ := e["semantic"].(map[string]any)
	if len(g.Lines) != anyInt(sem["lineCount"], len(g.Lines)) {
		t.Fatalf("%s line count", cid)
	}
	els, _ := e["lines"].([]any)
	if len(g.Lines) != len(els) {
		t.Fatalf("%s plan lines %d want %d", cid, len(g.Lines), len(els))
	}
	for li, x := range els {
		el := x.(map[string]any)
		ls, _ := el["semantic"].(map[string]any)
		gl := g.Lines[li]
		if gl.LineIndex != anyInt(ls["lineIndex"], gl.LineIndex) || gl.SourceLineIndex != anyInt(ls["sourceLineIndex"], gl.SourceLineIndex) || gl.SentenceIndexInSourceLine != anyInt(ls["sentenceIndexInSourceLine"], gl.SentenceIndexInSourceLine) {
			t.Fatalf("%s line %d metadata", cid, li)
		}
		ers, _ := el["runs"].([]any)
		if len(gl.Runs) != len(ers) {
			t.Fatalf("%s L%d run count %d want %d", cid, li, len(gl.Runs), len(ers))
		}
		for ri, y := range ers {
			er := y.(map[string]any)
			es, _ := er["semantic"].(map[string]any)
			r := gl.Runs[ri]
			at := fmt.Sprintf("%s L%dR%d", cid, li, ri)
			checks := [][2]string{{r.Kind, strv(es, "kind", "")}, {r.RenderMode, strv(es, "renderMode", "")}, {r.FontRole, strv(es, "fontRole", "")}, {r.SourceText, strv(es, "sourceText", "")}, {r.SourceKind, strv(es, "sourceKind", "")}, {r.ImageAlt, strv(es, "imageAlt", "")}}
			for _, p := range checks {
				if p[0] != p[1] {
					t.Fatalf("%s semantic got %q want %q", at, p[0], p[1])
				}
			}
			if r.Quoted != boolv(es, "isQuoted", false) || r.InterpretedQuote != boolv(es, "interpretedQuote", false) || r.Unrecognized != boolv(es, "isUnrecognized", false) {
				t.Fatalf("%s bool semantic", at)
			}
			ec := intsAny(es["canonicalCps"])
			erender := intsAny(es["renderCps"])
			if cid == "numeric-traditional" && r.FontRole == "number" {
				ec = correctedTraditional12345
				erender = nil
			}
			if !stringsEqualInt(r.CanonicalCodepoints, ec) {
				t.Fatalf("%s canonical cps got %v want %v", at, r.CanonicalCodepoints, ec)
			}
			if !(cid == "numeric-traditional" && r.FontRole == "number") && !stringsEqualInt(r.RenderCodepoints, erender) {
				t.Fatalf("%s render cps got %v want %v", at, r.RenderCodepoints, erender)
			}
			if r.RenderAdapterID != strv(es, "renderAdapterId", "") {
				t.Fatalf("%s adapter got %q want %q", at, r.RenderAdapterID, strv(es, "renderAdapterId", ""))
			}
			if cid != "ordinary-cartouche-tallies-disabled" && !stringsEqualInt(r.ManualTallies, intsAny(es["manualTallies"])) {
				t.Fatalf("%s tallies got %v want %v", at, r.ManualTallies, intsAny(es["manualTallies"]))
			}
		}
	}
}

func TestFullRendererProfileBrowserSemantic64(t *testing.T) {
	if !fullNativeAvailable() {
		t.Skip("full native renderer requires Linux+cgo")
	}
	root := filepath.Join("..", "conformance", "full-renderer-profile-v1.0.0-candidate")
	var cr profileCaseRoot
	var or profileOracleRoot
	loadJSONTest(t, filepath.Join(root, "conformance", "render-parity-cases-v1.0.0.json"), &cr)
	loadJSONTest(t, filepath.Join(root, "references", "canonical-browser-render-plan-v1.0.0.json"), &or)
	if len(cr.Cases) != 64 || len(or.Cases) != 64 {
		t.Fatalf("case counts %d/%d", len(cr.Cases), len(or.Cases))
	}
	om := map[string]profileOracleCase{}
	for _, x := range or.Cases {
		om[x.ID] = x
	}
	n, e := CreateNanpaLinjaN()
	if e != nil {
		t.Fatal(e)
	}
	defer n.Close()
	for _, c := range cr.Cases {
		t.Run(c.ID, func(t *testing.T) {
			x, ok := om[c.ID]
			if !ok {
				t.Fatal("missing oracle")
			}
			o := optionsForProfileCase(c)
			ast := n.ParseInput(c.Input, o)
			p, e := n.BuildFullRenderPlan(c.Input, o)
			if e != nil {
				t.Fatal(e)
			}
			compareProfileAST(t, c.ID, ast, x.AST)
			compareProfilePlan(t, c.ID, p, x.Plan)
			if c.ID == "ordinary-cartouche-tallies-disabled" {
				if len(p.Runs) != 1 || len(p.Runs[0].ManualTallies) != 0 || len(p.Runs[0].TallyGroups) != 0 {
					t.Fatal("disabled tallies retained")
				}
				for _, cp := range p.Runs[0].RenderCodepoints {
					if cp == TallyCodepoint {
						t.Fatal("disabled tally codepoint")
					}
				}
			}
		})
	}
}

func onlyProfileRun(t *testing.T, p FullRenderPlan) FullRenderRun {
	t.Helper()
	if len(p.Runs) != 1 {
		t.Fatalf("expected one run, got %d", len(p.Runs))
	}
	return p.Runs[0]
}

func hasCP(xs []int, cp int) bool {
	for _, x := range xs {
		if x == cp {
			return true
		}
	}
	return false
}

func TestFullRendererProfileOperationChecks20(t *testing.T) {
	if !fullNativeAvailable() {
		t.Skip("full native renderer requires Linux+cgo")
	}
	n, err := CreateNanpaLinjaN()
	if err != nil {
		t.Fatal(err)
	}
	defer n.Close()
	passed := map[string]bool{}

	p, err := n.BuildFullRenderPlan("Jan")
	if err != nil {
		t.Fatal(err)
	}
	if p.CartoucheCount() != 1 {
		t.Fatal("automatic proper name default")
	}
	passed["automatic-proper-name-default"] = true

	a := DefaultFullRenderOptions()
	a.Parser.CartoucheCommaTallyMarks = false
	pa, _ := n.BuildFullRenderPlan("[jan pona,,]", a)
	b := DefaultFullRenderOptions()
	f := false
	b.Parser.CommaTallyMarks = &f
	pb, _ := n.BuildFullRenderPlan("[jan pona,,]", b)
	if !reflect.DeepEqual(pa.Runs[0].ManualTallies, pb.Runs[0].ManualTallies) {
		t.Fatal("tally aliases differ")
	}
	passed["tally-option-aliases"] = true

	m := DefaultFullRenderOptions()
	m.Font = "nasinNanpa"
	m.Parser.CartoucheTallyMode = "manual"
	mp, _ := n.BuildFullRenderPlan("[jan pona,,]", m)
	mr := onlyProfileRun(t, mp)
	if hasCP(mr.RenderCodepoints, TallyCodepoint) || !reflect.DeepEqual(mr.ManualTallies, []int{0, 2}) || len(mr.TallyGroups) != 1 {
		t.Fatal("manual mode")
	}
	u := m
	u.Parser.CartoucheTallyMode = "ucsur"
	up, _ := n.BuildFullRenderPlan("[jan pona,,]", u)
	ur := onlyProfileRun(t, up)
	if !hasCP(ur.RenderCodepoints, TallyCodepoint) || len(ur.ManualTallies) != 0 {
		t.Fatal("ucsur mode")
	}
	c := m
	c.Parser.CartoucheTallyMode = "comma"
	cp, _ := n.BuildFullRenderPlan("[jan pona,,]", c)
	cr := onlyProfileRun(t, cp)
	if !hasCP(cr.RenderCodepoints, int(',')) {
		t.Fatal("comma mode")
	}
	passed["tally-mode-overrides"] = true

	manual, ucsur := 0, 0
	browserCenters := map[string]float64{"nasinNanpa": 118, "linjaPona": 92.804, "linjaSike": 91.196, "nasinSitelenPuMono": 94.612, "linjaLipamanka": 121}
	for _, info := range n.ListFonts() {
		o := DefaultFullRenderOptions()
		o.Font = info.Key
		o.FontSize = 56
		fp, e := n.BuildFullRenderPlan("[jan pona,,]", o)
		if e != nil {
			t.Fatal(e)
		}
		r := onlyProfileRun(t, fp)
		mode := settingString(info.Settings, "cartoucheTallyMode", "ucsur")
		if mode == "manual" {
			manual++
			if hasCP(r.RenderCodepoints, TallyCodepoint) || !reflect.DeepEqual(r.ManualTallies, []int{0, 2}) || len(r.TallyGroups) != 1 {
				t.Fatalf("%s manual tally structure", info.Key)
			}
			g := r.TallyGroups[0]
			if g.OwnerIndex != 1 || g.Count != 2 || absf(g.CenterXPx-(g.OwnerLeftPx+g.OwnerRightPx)/2) > .05 {
				t.Fatalf("%s tally owner geometry", info.Key)
			}
			if absf((g.CenterXPx-r.XPx)-browserCenters[info.Key]) > 1.5 {
				t.Fatalf("%s browser/native tally x", info.Key)
			}
		} else {
			ucsur++
			if !hasCP(r.RenderCodepoints, TallyCodepoint) || len(r.TallyGroups) != 0 {
				t.Fatalf("%s UCSUR tally", info.Key)
			}
		}
	}
	if manual != 5 || ucsur != 3 {
		t.Fatalf("tally font modes %d/%d", manual, ucsur)
	}
	passed["manual-tally-structural"] = true

	zero := 0.0
	max := 12.0
	three := 3.0
	o0 := DefaultFullRenderOptions()
	o0.Font = "nasinNanpa"
	o0.FontSize = 10
	o0.Parser.CartoucheTallyMode = "manual"
	o0.Parser.ManualTallySmallFontLiftPx = &zero
	o0.Parser.ManualTallySmallFontMaxPx = &max
	p0, _ := n.BuildFullRenderPlan("[jan pona,,]", o0)
	g0 := onlyProfileRun(t, p0).TallyGroups[0]
	o1 := o0
	o1.Parser.ManualTallySmallFontLiftPx = &three
	p1, _ := n.BuildFullRenderPlan("[jan pona,,]", o1)
	g1 := onlyProfileRun(t, p1).TallyGroups[0]
	if !(g1.TopYPx < g0.TopYPx && g1.BottomYPx < g0.BottomYPx) || absf(g1.CenterXPx-g0.CenterXPx) > .05 {
		t.Fatal("small font tally lift")
	}
	passed["manual-tally-small-font-settings"] = true

	h := DefaultFullRenderOptions()
	h.Font = "nasinNanpa"
	h.Paint.HaloEnabled = true
	h.Paint.HaloColor = "#ff0000"
	h.Paint.HaloWidthPx = 6
	hsvg, e := n.RenderFullToSVG("[jan pona,,]", h)
	if e != nil || len(hsvg) < 100 || !bytes.Contains(hsvg, []byte("<svg")) {
		t.Fatal("halo SVG")
	}
	passed["ordinary-cartouche-red-halo"] = true

	for _, info := range n.ListFonts() {
		o := DefaultFullRenderOptions()
		o.Font = info.Key
		fp, e := n.BuildFullRenderPlan("jan [pona,,] 123.45", o)
		if e != nil {
			t.Fatal(e)
		}
		for _, r := range fp.Runs {
			if r.RenderAdapterID != info.RenderAdapterID {
				t.Fatalf("%s adapter %s want %s", info.Key, r.RenderAdapterID, info.RenderAdapterID)
			}
			if hasCP(r.RenderCodepoints, 0xFFFD) {
				t.Fatalf("%s replacement glyph", info.Key)
			}
		}
		png, e := n.RenderFullToPNG("jan [pona,,] 123.45", o)
		if e != nil || len(png) < 100 {
			t.Fatalf("%s native PNG", info.Key)
		}
	}
	passed["production-font-adapter-matrix"] = true

	canvas, e := n.RenderToCanvas("jan [pona] 123.45")
	if e != nil || canvas.Width() <= 0 || canvas.Height() <= 0 || canvas.Plan == nil {
		t.Fatal("canvas")
	}
	passed["renderToCanvas"] = true
	png, e := n.RenderFullToPNG("jan [pona] 123.45")
	if e != nil || len(png) < 8 || !bytes.Equal(png[:8], []byte{137, 80, 78, 71, 13, 10, 26, 10}) {
		t.Fatal("PNG")
	}
	passed["renderToPng"] = true
	svg, e := n.RenderFullToSVG("jan [pona] 123.45")
	if e != nil || !bytes.Contains(svg, []byte("<svg")) {
		t.Fatal("SVG")
	}
	passed["renderToSvg"] = true
	pdf, e := n.RenderFullToPDF("jan [pona] 123.45")
	if e != nil || !bytes.HasPrefix(pdf, []byte("%PDF-")) {
		t.Fatal("PDF")
	}
	passed["renderToPdf"] = true

	ast := n.ParseInput("jan [pona] 123")
	if len(ast.Lines) != 1 || len(ast.Lines[0].Children) != 3 {
		t.Fatalf("parseInput children %d", len(ast.Lines[0].Children))
	}
	passed["parseInput"] = true
	bp, e := n.BuildFullRenderPlan("jan [pona] 123")
	if e != nil || len(bp.Lines) != 1 || len(bp.Lines[0].Runs) < 3 {
		t.Fatal("build plan")
	}
	passed["buildRenderPlan"] = true
	var wr FullRenderRun
	found := false
	for _, r := range bp.Runs {
		if r.FontRole == "word" {
			wr = r
			found = true
			break
		}
	}
	if !found {
		t.Fatal("word run")
	}
	rc, e := n.RenderRunToNewCanvas(wr)
	if e != nil || rc.Width() <= 0 {
		t.Fatal("run canvas")
	}
	passed["renderRunToNewCanvas"] = true
	tc, e := n.RenderTextToNewCanvas("jan pona")
	if e != nil || tc.Width() <= 0 {
		t.Fatal("text new canvas")
	}
	passed["renderTextToNewCanvas"] = true
	target := image.NewRGBA(image.Rect(0, 0, 400, 200))
	if _, e = n.RenderTextToCanvas(target, 5, 5, "jan pona"); e != nil {
		t.Fatal(e)
	}
	passed["renderTextToCanvas"] = true
	ul := [][]int{{wordToCP["jan"], wordToCP["pona"]}, {wordToCP["toki"]}}
	uc, e := n.RenderUcsurToNewCanvas(ul)
	if e != nil || uc.Width() <= 0 || uc.Plan == nil || uc.Plan.LineCount() != 2 {
		t.Fatal("ucsur new canvas")
	}
	passed["renderUcsurToNewCanvas"] = true
	ut := image.NewRGBA(image.Rect(0, 0, 500, 300))
	if _, e = n.RenderUcsurToCanvas(ut, 3, 3, ul); e != nil {
		t.Fatal(e)
	}
	passed["renderUcsurToCanvas"] = true

	n.RegisterRenderAdapter("identity", func(cps []int, _ ProductionFontInfo, _ float64) []int {
		out := append([]int(nil), cps...)
		for i, cp := range out {
			if cp == wordToCP["jan"] {
				out[i] = wordToCP["pona"]
			}
		}
		return out
	})
	if _, ok := n.GetRenderAdapter("identity"); !ok {
		t.Fatal("adapter lookup")
	}
	ap, _ := n.BuildFullRenderPlan("jan")
	if !reflect.DeepEqual(ap.Runs[0].RenderCodepoints, []int{wordToCP["pona"]}) {
		t.Fatal("adapter effect")
	}
	if _, ok := n.RemoveRenderAdapter("identity"); !ok {
		t.Fatal("adapter remove")
	}
	passed["registerRenderAdapter"] = true
	vd, e := n.ToVectorDocument("jan [pona,,] 123.45", m)
	if e != nil || vd.Width <= 0 || vd.Height <= 0 || len(vd.Elements) == 0 {
		t.Fatal("vector document")
	}
	hasT := false
	for _, r := range vd.Plan.Runs {
		if len(r.TallyGroups) > 0 {
			hasT = true
		}
	}
	if !hasT {
		t.Fatal("vector tally semantics")
	}
	passed["vector-document"] = true

	root := filepath.Join("..", "conformance", "full-renderer-profile-v1.0.0-candidate", "conformance", "operation-checks-v1.0.0.json")
	var raw struct {
		Checks []struct {
			ID string `json:"id"`
		} `json:"checks"`
	}
	loadJSONTest(t, root, &raw)
	if len(raw.Checks) != 20 {
		t.Fatalf("operation count %d", len(raw.Checks))
	}
	for _, x := range raw.Checks {
		if !passed[x.ID] {
			t.Fatalf("operation not covered: %s", x.ID)
		}
	}
}

func absf(x float64) float64 {
	if x < 0 {
		return -x
	}
	return x
}

func TestFullRendererProfileVectorCases9(t *testing.T) {
	if !fullNativeAvailable() {
		t.Skip("full native renderer requires Linux+cgo")
	}
	n, e := CreateNanpaLinjaN()
	if e != nil {
		t.Fatal(e)
	}
	defer n.Close()
	root := filepath.Join("..", "conformance", "full-renderer-profile-v1.0.0-candidate", "conformance", "vector-export-cases-v1.0.0.json")
	var v struct {
		Cases []struct {
			ID, Input string
			FontPx    float64        `json:"fontPx"`
			Expect    map[string]any `json:"expect"`
		} `json:"cases"`
	}
	loadJSONTest(t, root, &v)
	if len(v.Cases) != 9 {
		t.Fatalf("vector count %d", len(v.Cases))
	}
	for _, c := range v.Cases {
		t.Run(c.ID, func(t *testing.T) {
			o := DefaultFullRenderOptions()
			o.FontSize = c.FontPx
			if yes, _ := c.Expect["svg"].(bool); yes {
				svg, e := n.RenderFullToSVG(c.Input, o)
				if e != nil || !bytes.Contains(svg, []byte("<svg")) || !bytes.Contains(svg, []byte("<path")) {
					t.Fatalf("SVG: %v", e)
				}
				pdf, e := n.RenderFullToPDF(c.Input, o)
				if e != nil || !bytes.HasPrefix(pdf, []byte("%PDF-")) {
					t.Fatalf("PDF: %v", e)
				}
			}
			if a, ok := c.Expect["expectOpenTypeFeatures"].([]any); ok {
				want := make([]string, 0, len(a))
				for _, x := range a {
					want = append(want, x.(string))
				}
				p, e := n.BuildFullRenderPlan(c.Input, o)
				if e != nil {
					t.Fatal(e)
				}
				if !reflect.DeepEqual(p.OpenTypeFeatures, want) {
					t.Fatalf("features %v want %v", p.OpenTypeFeatures, want)
				}
			}
		})
	}
}

func TestFullRendererProfileFeatureManifest38(t *testing.T) {
	if !fullNativeAvailable() {
		t.Skip("full native renderer requires Linux+cgo")
	}
	root := filepath.Join("..", "conformance", "full-renderer-profile-v1.0.0-candidate")
	var f struct {
		Features []struct {
			ID        string   `json:"id"`
			CoveredBy []string `json:"coveredBy"`
		} `json:"features"`
	}
	loadJSONTest(t, filepath.Join(root, "feature-manifest.json"), &f)
	if len(f.Features) != 38 {
		t.Fatalf("feature count %d", len(f.Features))
	}
	seen := map[string]bool{}
	for _, x := range f.Features {
		if x.ID == "" || seen[x.ID] {
			t.Fatalf("bad feature id %q", x.ID)
		}
		seen[x.ID] = true
		if len(x.CoveredBy) == 0 {
			t.Fatalf("feature %s uncovered", x.ID)
		}
	}
}

func TestFullRendererProfileMetadata(t *testing.T) {
	root := filepath.Join("..", "conformance", "full-renderer-profile-v1.0.0-candidate")
	var p struct {
		Profile             string                            `json:"profile"`
		ProfileVersion      string                            `json:"profileVersion"`
		TargetsProtocol     string                            `json:"targetsProtocol"`
		SemanticParityCases int                               `json:"semanticParityCases"`
		FeatureCount        int                               `json:"featureCount"`
		CanonicalRenderer   struct{ Filename, SHA256 string } `json:"canonicalRenderer"`
	}
	loadJSONTest(t, filepath.Join(root, "profile.json"), &p)
	if p.Profile != "nanpa-linja-n-full-renderer-profile" || p.ProfileVersion != "1.0.0-candidate" || p.TargetsProtocol != "1.0.0" || p.SemanticParityCases != 64 || p.FeatureCount != 38 {
		t.Fatalf("unexpected profile metadata: %#v", p)
	}
	b, err := os.ReadFile(filepath.Join("..", "reference", p.CanonicalRenderer.Filename))
	if err != nil {
		t.Fatal(err)
	}
	sum := fmt.Sprintf("%x", sha256.Sum256(b))
	if sum != p.CanonicalRenderer.SHA256 {
		t.Fatalf("canonical renderer SHA-256 %s want %s", sum, p.CanonicalRenderer.SHA256)
	}
}
