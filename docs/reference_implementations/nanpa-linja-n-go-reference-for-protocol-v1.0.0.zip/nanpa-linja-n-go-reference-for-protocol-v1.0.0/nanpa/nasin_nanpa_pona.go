package nanpa

import (
	"regexp"
	"strconv"
	"strings"
)

var plainDecimalNasinNanpaPonaRE = regexp.MustCompile(`^(-)?(?:(0|[1-9][0-9]*|[1-9][0-9]{0,2}(?:,[0-9]{3})+)(?:\.([0-9]+))?|\.([0-9]+))$`)

func nasinNanpaPonaBase100GroupWords(group int) []string {
	if group < 0 || group > 99 {
		return nil
	}
	words := []string{}
	for group >= 20 {
		words = append(words, "mute")
		group -= 20
	}
	for group >= 5 {
		words = append(words, "luka")
		group -= 5
	}
	for group >= 2 {
		words = append(words, "tu")
		group -= 2
	}
	if group == 1 {
		words = append(words, "wan")
	}
	return words
}

func nasinNanpaPonaGroupedDigitsWords(groups []string) []string {
	words := []string{}
	for i, group := range groups {
		if group == "" || len(group) > 2 {
			return nil
		}
		value, err := strconv.Atoi(group)
		if err != nil {
			return nil
		}
		groupWords := nasinNanpaPonaBase100GroupWords(value)
		if groupWords == nil {
			return nil
		}
		words = append(words, groupWords...)
		if i+1 < len(groups) {
			words = append(words, "ale")
		}
	}
	return words
}

func splitBase100Right(digits string) []string {
	groups := []string{}
	for end := len(digits); end > 0; end -= 2 {
		start := end - 2
		if start < 0 {
			start = 0
		}
		groups = append([]string{digits[start:end]}, groups...)
	}
	return groups
}

func splitBase100Left(digits string) []string {
	value := digits
	if len(value)%2 != 0 {
		value += "0"
	}
	groups := make([]string, 0, len(value)/2)
	for i := 0; i < len(value); i += 2 {
		groups = append(groups, value[i:i+2])
	}
	return groups
}

// tryPlainDecimalToNasinNanpaPonaWords mirrors the current JavaScript baseline
// conversion used by parseNumber()/astToText(). Non-plain decimal structures
// return nil so callers preserve the requested nanpa-linja-n representation.
func tryPlainDecimalToNasinNanpaPonaWords(value string) []string {
	raw := strings.TrimSpace(value)
	for _, dash := range []string{"−", "‒", "–", "—"} {
		raw = strings.ReplaceAll(raw, dash, "-")
	}
	m := plainDecimalNasinNanpaPonaRE.FindStringSubmatch(raw)
	if m == nil {
		return nil
	}
	negative := m[1] != ""
	integerDigits := m[2]
	if integerDigits == "" {
		integerDigits = "0"
	}
	integerDigits = strings.ReplaceAll(integerDigits, ",", "")
	fractionDigits := m[3]
	if fractionDigits == "" {
		fractionDigits = m[4]
	}
	fractionDigits = strings.TrimRight(fractionDigits, "0")
	if integerDigits == "0" && fractionDigits == "" {
		return []string{"ala"}
	}

	integerWords := []string{"ala"}
	if integerDigits != "0" {
		integerWords = nasinNanpaPonaGroupedDigitsWords(splitBase100Right(integerDigits))
	}
	if integerWords == nil {
		return nil
	}
	words := []string{}
	if negative {
		words = append(words, "weka")
	}
	words = append(words, integerWords...)
	if fractionDigits != "" {
		fractionWords := nasinNanpaPonaGroupedDigitsWords(splitBase100Left(fractionDigits))
		if fractionWords == nil {
			return nil
		}
		words = append(words, "ala")
		words = append(words, fractionWords...)
	}
	return words
}
