package nanpa

import (
	"encoding/base64"
	"fmt"
	"net/url"
	"regexp"
	"strconv"
	"strings"
	"unicode"
	"unicode/utf8"
)

var fullAliases = [][2]string{
	{"'cartouche-start'", "["}, {"'cartouche-end'", "]"}, {"'zw-joiner'", "&"}, {"'stack-joiner'", "-"}, {"'nesting-joiner'", "+"},
	{"'ideographic-space'", " zz "}, {"'long-start'", "("}, {"'long-end'", ")"}, {"'left-bracket'", " te "}, {"'right-bracket'", " to "},
	{"'middle-dot'", "."}, {"'colon'", ":"}, {"'tally'", ","},
}

func normalizeDocument(s string, p FullParserOptions) string {
	out := s
	if effectiveRendererMode(p) != "standard-sitelen-pona-ascii-core" {
		for _, a := range fullAliases {
			out = strings.ReplaceAll(out, a[0], a[1])
		}
	}
	out = strings.ReplaceAll(out, "\r\n", "\n")
	return strings.ReplaceAll(out, "\r", "\n")
}

func sentenceStop(s string, i int) bool {
	prev, next := byte(0), byte(0)
	if i > 0 {
		prev = s[i-1]
	}
	if i+1 < len(s) {
		next = s[i+1]
	}
	numeric := next >= '0' && next <= '9' && ((prev >= '0' && prev <= '9') || i == 0 || unicode.IsSpace(rune(prev)) || strings.ContainsRune("+-(,:=", rune(prev)))
	return !numeric
}

func splitFullStops(line string) []string {
	out := []string{}
	start := 0
	square, paren, brace := 0, 0, 0
	var quote byte
	for i := 0; i < len(line); i++ {
		ch := line[i]
		if quote != 0 {
			if ch == '\\' {
				i++
				continue
			}
			if (quote == '"' && ch == '"') || (quote == 0xE2 && strings.HasPrefix(line[i:], "”")) {
				quote = 0
			}
			continue
		}
		if ch == '"' {
			quote = '"'
			continue
		}
		switch ch {
		case '[':
			square++
		case ']':
			if square > 0 {
				square--
			}
		case '(':
			paren++
		case ')':
			if paren > 0 {
				paren--
			}
		case '{':
			brace++
		case '}':
			if brace > 0 {
				brace--
			}
		}
		if ch == '.' && square == 0 && paren == 0 && brace == 0 && sentenceStop(line, i) {
			piece := line[start : i+1]
			if strings.TrimSpace(piece) != "" {
				out = append(out, piece)
			}
			start = i + 1
		}
	}
	rest := strings.TrimSpace(line[start:])
	if rest != "" || len(out) == 0 {
		out = append(out, rest)
	}
	return out
}

func splitArgs(s string) []string {
	var out []string
	start := 0
	var quote rune
	esc := false
	rr := []rune(s)
	for i, r := range rr {
		if esc {
			esc = false
			continue
		}
		if r == '\\' {
			esc = true
			continue
		}
		if quote != 0 {
			if r == quote {
				quote = 0
			}
			continue
		}
		if r == '\'' || r == '"' {
			quote = r
			continue
		}
		if r == ',' {
			out = append(out, strings.TrimSpace(string(rr[start:i])))
			start = i + 1
		}
	}
	out = append(out, strings.TrimSpace(string(rr[start:])))
	return out
}
func stripQuotes(s string) string {
	s = strings.TrimSpace(s)
	if len(s) >= 2 && ((s[0] == '\'' && s[len(s)-1] == '\'') || (s[0] == '"' && s[len(s)-1] == '"')) {
		return s[1 : len(s)-1]
	}
	return s
}

func parseImageArgs(arg string) ImageDescriptor {
	d := ImageDescriptor{VAlign: "baseline", Wriggle: 8, Transparent: true}
	for _, part := range splitArgs(arg) {
		if part == "" {
			continue
		}
		kv := strings.SplitN(part, "=", 2)
		if len(kv) != 2 {
			continue
		}
		k := strings.ToLower(strings.TrimSpace(kv[0]))
		v := stripQuotes(kv[1])
		switch k {
		case "src":
			d.Src = v
		case "w", "width":
			d.W = v
		case "h", "height":
			d.H = v
		case "alt":
			d.Alt = v
		case "valign":
			d.VAlign = v
		case "wriggle":
			if x, e := strconv.ParseFloat(v, 64); e == nil {
				d.Wriggle = x
			}
		case "transparent":
			d.Transparent = !(strings.EqualFold(v, "false") || v == "0" || strings.EqualFold(v, "no"))
		}
	}
	return d
}

func segments(line string) []DocumentSegment {
	out := []DocumentSegment{}
	i, start := 0, 0
	push := func(a, b int) {
		if b > a {
			out = append(out, DocumentSegment{Kind: "text", Value: line[a:b], SourceStart: a, SourceEnd: b})
		}
	}
	for i < len(line) {
		ch := line[i]
		if ch == '[' {
			j := strings.IndexByte(line[i+1:], ']')
			if j < 0 {
				break
			}
			j += i + 1
			push(start, i)
			out = append(out, DocumentSegment{Kind: "bracket", Value: line[i+1 : j], SourceStart: i, SourceEnd: j + 1})
			i = j + 1
			start = i
			continue
		}
		if ch == '"' {
			j := i + 1
			found := -1
			for j < len(line) {
				if line[j] == '"' && (j == 0 || line[j-1] != '\\') {
					found = j
					break
				}
				j++
			}
			if found < 0 {
				break
			}
			push(start, i)
			out = append(out, DocumentSegment{Kind: "quote", Value: line[i+1 : found], OpenQuote: "\"", CloseQuote: "\"", SourceStart: i, SourceEnd: found + 1})
			i = found + 1
			start = i
			continue
		}
		if strings.HasPrefix(line[i:], "“") {
			j := i + len("“")
			found := -1
			closeLen := len("”")
			for j < len(line) {
				if strings.HasPrefix(line[j:], "”") || line[j] == '"' {
					found = j
					if line[j] == '"' {
						closeLen = 1
					}
					break
				}
				_, n := utf8.DecodeRuneInString(line[j:])
				j += n
			}
			if found < 0 {
				break
			}
			push(start, i)
			out = append(out, DocumentSegment{Kind: "quote", Value: line[i+len("“") : found], OpenQuote: "“", CloseQuote: line[found : found+closeLen], SourceStart: i, SourceEnd: found + closeLen})
			i = found + closeLen
			start = i
			continue
		}
		if strings.HasPrefix(line[i:], "img(") {
			j := i + 4
			depth := 1
			var quote byte
			esc := false
			for j < len(line) {
				c := line[j]
				if esc {
					esc = false
					j++
					continue
				}
				if c == '\\' {
					esc = true
					j++
					continue
				}
				if quote != 0 {
					if c == quote {
						quote = 0
					}
					j++
					continue
				}
				if c == '\'' || c == '"' {
					quote = c
					j++
					continue
				}
				if c == '(' {
					depth++
				} else if c == ')' {
					depth--
					if depth == 0 {
						break
					}
				}
				j++
			}
			if j >= len(line) {
				break
			}
			push(start, i)
			d := parseImageArgs(line[i+4 : j])
			out = append(out, DocumentSegment{Kind: "image", Image: &d, SourceStart: i, SourceEnd: j + 1})
			i = j + 1
			start = i
			continue
		}
		_, n := utf8.DecodeRuneInString(line[i:])
		i += n
	}
	push(start, len(line))
	return out
}

func quoteImageArgument(value string) string {
	if !strings.Contains(value, "'") {
		return "'" + value + "'"
	}
	if !strings.Contains(value, "\"") {
		return "\"" + value + "\""
	}
	escaped := strings.ReplaceAll(value, "\\", "\\\\")
	escaped = strings.ReplaceAll(escaped, "\"", "\\\"")
	return "\"" + escaped + "\""
}

func imageDescriptorToText(d *ImageDescriptor) string {
	if d == nil {
		return "img()"
	}
	args := make([]string, 0, 7)
	if d.Src != "" {
		args = append(args, "src="+quoteImageArgument(d.Src))
	}
	if d.W != "" {
		args = append(args, "w="+quoteImageArgument(d.W))
	}
	if d.H != "" {
		args = append(args, "h="+quoteImageArgument(d.H))
	}
	if d.Alt != "" {
		args = append(args, "alt="+quoteImageArgument(d.Alt))
	}
	if d.VAlign != "" && d.VAlign != "baseline" {
		args = append(args, "valign="+quoteImageArgument(d.VAlign))
	}
	if d.Wriggle != 8 {
		args = append(args, "wriggle="+strconv.FormatFloat(d.Wriggle, 'g', -1, 64))
	}
	if !d.Transparent {
		args = append(args, "transparent=false")
	}
	return "img(" + strings.Join(args, ",") + ")"
}

func documentSegmentToText(seg DocumentSegment) (string, error) {
	switch seg.Kind {
	case "text":
		return seg.Value, nil
	case "bracket":
		return "[" + seg.Value + "]", nil
	case "quote":
		open := seg.OpenQuote
		if open == "" {
			open = "\""
		}
		close := seg.CloseQuote
		if close == "" {
			if open == "“" {
				close = "”"
			} else {
				close = "\""
			}
		}
		return open + seg.Value + close, nil
	case "image":
		return imageDescriptorToText(seg.Image), nil
	default:
		return "", fmt.Errorf("unsupported AST segment kind %q", seg.Kind)
	}
}

// AstToText converts a full-document AST back into valid nanpa-linja-n source text.
// It serializes the AST's current segment values rather than NormalizedInput or
// SourceText. SourceLineIndex is used to reconstruct physical lines when
// BreakLinesAtFullStops split one source line into multiple AST lines.
func AstToText(ast DocumentAST) (string, error) {
	var out strings.Builder
	havePrevious := false
	previousSourceLineIndex := 0
	for i, line := range ast.Lines {
		currentSourceLineIndex := line.SourceLineIndex
		if currentSourceLineIndex < 0 {
			currentSourceLineIndex = i
		}
		if havePrevious && currentSourceLineIndex != previousSourceLineIndex {
			out.WriteByte('\n')
		}
		for _, seg := range line.Children {
			text, err := documentSegmentToText(seg)
			if err != nil {
				return "", err
			}
			out.WriteString(text)
		}
		havePrevious = true
		previousSourceLineIndex = currentSourceLineIndex
	}
	return out.String(), nil
}

func ParseDocument(input string, p FullParserOptions) DocumentAST {
	normalized := normalizeDocument(input, p)
	lines := []DocumentLine{}
	for sli, source := range strings.Split(normalized, "\n") {
		rendered := []string{source}
		if p.BreakLinesAtFullStops {
			rendered = splitFullStops(source)
		}
		for si, s := range rendered {
			lines = append(lines, DocumentLine{Index: len(lines), SourceLineIndex: sli, SentenceIndexInSourceLine: si, SourceText: s, Children: segments(s)})
		}
	}
	return DocumentAST{Type: "document", NormalizedInput: normalized, BreakLinesAtFullStops: p.BreakLinesAtFullStops, Lines: lines}
}

var rawUnicodeRE = regexp.MustCompile(`(?i)^U\+([0-9a-f]{4,6})$`)

func parseRawUnicodeSequence(text string) ([]int, bool) {
	toks := strings.Fields(strings.TrimSpace(text))
	if len(toks) == 0 {
		return nil, false
	}
	out := make([]int, 0, len(toks))
	for _, t := range toks {
		m := rawUnicodeRE.FindStringSubmatch(t)
		if m == nil {
			return nil, false
		}
		v, _ := strconv.ParseInt(m[1], 16, 32)
		if v > 0x10FFFF {
			return nil, false
		}
		out = append(out, int(v))
	}
	return out, true
}

func decodeDataImage(src string) ([]byte, error) {
	if !strings.HasPrefix(src, "data:image/") {
		return nil, fmt.Errorf("not data image")
	}
	i := strings.IndexByte(src, ',')
	if i < 0 {
		return nil, fmt.Errorf("invalid data URI")
	}
	meta, data := src[:i], src[i+1:]
	if strings.Contains(meta, ";base64") {
		return base64.StdEncoding.DecodeString(data)
	}
	u, err := url.QueryUnescape(data)
	if err != nil {
		return nil, err
	}
	return []byte(u), nil
}
