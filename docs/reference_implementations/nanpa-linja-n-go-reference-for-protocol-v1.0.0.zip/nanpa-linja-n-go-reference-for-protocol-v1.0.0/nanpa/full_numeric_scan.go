package nanpa

import (
	"regexp"
	"sort"
	"strings"
	"unicode"
	"unicode/utf8"
)

// fullNumericHit is the additive whole-text scanner result used by the full
// renderer. The frozen Core parser remains a complete-value parser.
type fullNumericHit struct {
	Start, End int
	Kind       string
	Parsed     *ParseResult
}

func fullHitPriority(kind string) int {
	switch kind {
	case "hex", "binary":
		return 6
	case "date":
		return 5
	case "decimal", "time":
		return 4
	case "tpPhrase":
		return 3
	case "code":
		return 2
	default:
		return 1
	}
}

func (n *NanpaLinjaN) fullNumericParse(source string, p FullParserOptions) (*ParseResult, bool) {
	if r, ok := n.numericFullParse(source, p); ok {
		return r, true
	}
	o := p.numericOptions()
	if p.EnableBinaryParsing || p.EnableBinaryRendering {
		if sem, ok := parseBinaryProper(source, o); ok {
			if r, err := makeHexBinaryResult(source, sem, o); err == nil {
				return r, true
			}
		}
	}
	if p.EnableHexParsing {
		if sem, ok := parseHexProper(source, p.RelaxedNanpaLinjanParsing); ok {
			if r, err := makeHexBinaryResult(source, sem, o); err == nil {
				return r, true
			}
		}
	}
	return nil, false
}

var fullNumericDigitWords = map[string]bool{
	"ijo": true, "wan": true, "tu": true, "seli": true, "awen": true,
	"luka": true, "utala": true, "mun": true, "pipi": true, "jo": true,
}

var relaxedPhraseFollowers = map[string]string{
	"wan": "ala", "pipi": "ike", "tu": "uta", "luka": "uta", "mun": "uta", "jo": "open",
}

func phraseWordAllowed(words []string, i int, p FullParserOptions) bool {
	w := words[i]
	if w == "nasin" {
		return false
	}
	if _, ok := wordToCP[w]; !ok {
		return false
	}
	if w == "open" && i > 0 && words[i-1] == "jo" {
		return p.RelaxedNanpaLinjanParsing
	}
	if w != "ala" && w != "ike" && w != "uta" {
		return true
	}
	if !p.RelaxedNanpaLinjanParsing || i <= 2 || i >= len(words)-1 || i == 0 {
		return false
	}
	return relaxedPhraseFollowers[words[i-1]] == w
}

func hasAdjacentPhraseDigits(words []string) bool {
	for i := 1; i < len(words); i++ {
		if fullNumericDigitWords[words[i-1]] && fullNumericDigitWords[words[i]] {
			return true
		}
	}
	return false
}

func equalWordsAt(words []string, i int, pat []string) bool {
	if i+len(pat) > len(words) {
		return false
	}
	for j := range pat {
		if words[i+j] != pat[j] {
			return false
		}
	}
	return true
}

func canonicalizeScientificPhraseWords(words []string) []string {
	type repl struct{ old, new []string }
	patterns := []repl{
		{[]string{"nena", "e", "kala", "open", "wan", "e", "nena", "ijo", "nena", "e", "kala", "open"}, []string{"nena", "e", "kala", "open"}},
		{[]string{"nena", "e", "kala", "open", "wan", "ala", "nena", "ijo", "nena", "e", "kala", "open"}, []string{"nena", "e", "kala", "open"}},
		{[]string{"nena", "en", "kala", "open", "wan", "en", "nena", "ijo", "nena", "en", "kala", "open"}, []string{"nena", "e", "kala", "open"}},
		{[]string{"nena", "en", "kala", "open", "wan", "ala", "nena", "ijo", "nena", "en", "kala", "open"}, []string{"nena", "e", "kala", "open"}},
		{[]string{"nasa", "e", "kala", "open", "wan", "esun", "nasa", "ijo", "nasa", "e", "kala", "open"}, []string{"nasa", "e", "kala", "open"}},
		{[]string{"nasa", "e", "kala", "open", "wan", "ala", "nasa", "ijo", "nasa", "e", "kala", "open"}, []string{"nasa", "e", "kala", "open"}},
	}
	out := []string{}
	for i := 0; i < len(words); {
		matched := false
		for _, p := range patterns {
			if equalWordsAt(words, i, p.old) {
				out = append(out, p.new...)
				i += len(p.old)
				matched = true
				break
			}
		}
		if !matched {
			out = append(out, words[i])
			i++
		}
	}
	return out
}

func canonicalPhraseWords(input []string, p FullParserOptions) ([]string, bool) {
	words := make([]string, 0, len(input))
	for _, w := range input {
		w = strings.ToLower(strings.TrimSpace(w))
		if w != "" {
			words = append(words, w)
		}
	}
	if len(words) < 3 || words[0] != "nanpa" || words[len(words)-1] != "nanpa" {
		return nil, false
	}
	if words[1] != "e" && words[1] != "en" && words[1] != "esun" {
		return nil, false
	}
	for i := range words {
		if !phraseWordAllowed(words, i, p) {
			return nil, false
		}
	}
	if hasAdjacentPhraseDigits(words) {
		return nil, false
	}
	canonical := canonicalizeScientificPhraseWords(words)
	if len(canonical) >= 6 && canonical[0] == "nanpa" && canonical[1] == "en" && canonical[2] == "nena" && canonical[3] == "en" {
		canonical = append([]string{"nanpa", "e"}, canonical[4:]...)
	}
	positive := len(canonical) >= 5 && canonical[0] == "nanpa" && canonical[1] == "e" && canonical[2] == "nena" && canonical[3] == "en"
	for i, w := range canonical {
		if w == "en" && !(positive && i == 3) {
			canonical[i] = "e"
		}
	}
	hasDigit := false
	for _, w := range canonical[2 : len(canonical)-1] {
		if fullNumericDigitWords[w] {
			hasDigit = true
			break
		}
	}
	if !hasDigit {
		return nil, false
	}
	// A bare legacy [nanpa en <digits> nanpa] is reserved for the explicit
	// positive abbreviated grammar. It is a full phrase only when its payload
	// contains full-form scaffolding.
	if words[1] == "en" {
		hasScaffolding := false
		for _, w := range words[2 : len(words)-1] {
			switch w {
			case "nanpa", "en", "e", "nena", "open", "ala", "ike", "uta":
				hasScaffolding = true
			}
		}
		if !hasScaffolding {
			return nil, false
		}
	}
	return canonical, true
}

func phraseWordsToCodepoints(words []string, p FullParserOptions) ([]int, bool) {
	source := append([]string(nil), words...)
	positive := len(source) >= 4 && source[0] == "nanpa" && source[1] == "e" && source[2] == "nena" && source[3] == "en"
	if p.NanpaColonRendering && len(source) >= 3 && source[0] == "nanpa" && (source[1] == "e" || source[1] == "en" || source[1] == "esun") {
		source = append([]string{"nanpa", ":"}, source[2:]...)
	}
	cps := make([]int, 0, len(source))
	for _, w := range source {
		cp, ok := wordToCP[w]
		if !ok {
			return nil, false
		}
		cps = append(cps, cp)
	}
	if p.numericOptions().normalizedMode() == "uniform" {
		cps = uniformize(cps)
	}
	// Keep the frozen Core uniformizer unchanged.  The canonical full renderer
	// retains `en` specifically for the explicit positive marker.
	if positive && len(cps) >= 4 && cps[2] == wordToCP["nena"] {
		cps[3] = wordToCP["en"]
	}
	return cps, true
}

func phraseResultFromCps(source string, cps []int, words []string, p FullParserOptions) *ParseResult {
	inner := append([]int(nil), cps...)
	return &ParseResult{
		Input: source, UcsurCodepoints: inner, InnerCodepoints: append([]int(nil), inner...), Codepoints: withMarkers(inner),
		TpWords: append([]string(nil), words...), Words: append([]string(nil), words...), NumericMode: p.numericOptions().normalizedMode(),
	}
}

func newPhraseParseResult(words []string, p FullParserOptions) (*ParseResult, bool) {
	canonical, ok := canonicalPhraseWords(words, p)
	if !ok {
		return nil, false
	}
	cps, ok := phraseWordsToCodepoints(canonical, p)
	if !ok {
		return nil, false
	}
	return phraseResultFromCps(strings.Join(words, " "), cps, canonical, p), true
}

func abbreviatedPhraseResult(words []string, p FullParserOptions) (*ParseResult, bool) {
	if len(words) < 3 || words[0] != "nanpa" || words[len(words)-1] != "nanpa" {
		return nil, false
	}
	positive := len(words) >= 4 && words[1] == "en"
	cps := make([]int, 0, len(words))
	hasDigit := false
	for i, w := range words {
		if w == "nasin" || w == "ala" || w == "ike" || w == "uta" {
			return nil, false
		}
		cp, ok := wordToCP[w]
		if !ok {
			return nil, false
		}
		finalNanpa := w == "nanpa" && i == len(words)-1
		positiveMarker := positive && i == 1 && w == "en"
		if i > 0 && !finalNanpa && !positiveMarker {
			switch w {
			case "nanpa", "en", "e", "nena", "open", "ala", "ike", "uta":
				return nil, false
			}
		}
		if fullNumericDigitWords[w] {
			hasDigit = true
		}
		cps = append(cps, cp)
	}
	if !hasDigit {
		return nil, false
	}
	return phraseResultFromCps(strings.Join(words, " "), cps, words, p), true
}

type fullWordPos struct {
	Raw        string
	Start, End int
}

func asciiWordPositions(s string) []fullWordPos {
	re := regexp.MustCompile(`[A-Za-z]+`)
	idx := re.FindAllStringIndex(s, -1)
	out := make([]fullWordPos, 0, len(idx))
	for _, m := range idx {
		out = append(out, fullWordPos{s[m[0]:m[1]], m[0], m[1]})
	}
	return out
}

func horizontalOnly(s string, a, b int) bool {
	if a > b || a < 0 || b > len(s) {
		return false
	}
	for _, r := range s[a:b] {
		if r != ' ' && r != '\t' {
			return false
		}
	}
	return true
}

func (n *NanpaLinjaN) scanProperNameHits(s string, p FullParserOptions) []fullNumericHit {
	words := asciiWordPositions(s)
	var hits []fullNumericHit
	for i := 0; i < len(words); i++ {
		first := words[i]
		if first.Raw == "" || !unicode.IsUpper(rune(first.Raw[0])) {
			continue
		}
		low := strings.ToLower(first.Raw)
		colon := p.NanpaColonParsing || p.NanpaColonRendering
		startsLegacy := strings.HasPrefix(low, "ne")
		startsHex := p.EnableHexParsing && strings.HasPrefix(low, "nasa")
		startsBin := (p.EnableBinaryParsing || p.EnableBinaryRendering) && strings.HasPrefix(low, "noka")
		startsTyped := colon && (first.Raw == "Nanpa" || strings.HasPrefix(first.Raw, "Nanpa") || first.Raw == "Tenpo" || first.Raw == "Suno" || first.Raw == "Toki")
		if !startsLegacy && !startsHex && !startsBin && !startsTyped {
			continue
		}
		best := -1
		var bestParsed *ParseResult
		max := i + 30
		if max >= len(words) {
			max = len(words) - 1
		}
		if startsTyped && !startsHex && !startsBin && max > i+20 {
			max = i + 20
		}
		for j := i; j <= max; j++ {
			if j > i && (!unicode.IsUpper(rune(words[j].Raw[0])) || !horizontalOnly(s, words[j-1].End, words[j].Start)) {
				break
			}
			raw := s[first.Start:words[j].End]
			if r, ok := n.fullNumericParse(raw, p); ok {
				best, bestParsed = j, r
			}
		}
		if first.Raw == "Toki" && best >= 0 && best+1 < len(words) && unicode.IsUpper(rune(words[best+1].Raw[0])) && horizontalOnly(s, words[best].End, words[best+1].Start) {
			best, bestParsed = -1, nil
		}
		if best >= 0 && bestParsed != nil {
			kind := "name"
			if bestParsed.IsHex != nil && *bestParsed.IsHex {
				kind = "hex"
			}
			if bestParsed.IsBinary != nil && *bestParsed.IsBinary {
				kind = "binary"
			}
			hits = append(hits, fullNumericHit{first.Start, words[best].End, kind, bestParsed})
			i = best
		}
	}
	return hits
}

func scanTpPhraseHits(s string, p FullParserOptions) []fullNumericHit {
	type tok struct {
		norm           string
		start, wordEnd int
		trail          string
	}
	re := regexp.MustCompile(`\S+`)
	wordRE := regexp.MustCompile(`^([A-Za-z]+)([)\]},.;:!?]*)$`)
	var toks []tok
	for _, m := range re.FindAllStringIndex(s, -1) {
		raw := s[m[0]:m[1]]
		mm := wordRE.FindStringSubmatch(raw)
		w, trail := "", ""
		if mm != nil {
			w, trail = strings.ToLower(mm[1]), mm[2]
		}
		toks = append(toks, tok{w, m[0], m[0] + len(w), trail})
	}
	var hits []fullNumericHit
	for i := 0; i+2 < len(toks); i++ {
		if toks[i].norm != "nanpa" {
			continue
		}
		x := toks[i+1].norm
		if x != "e" && x != "en" && x != "esun" {
			continue
		}
		best := -1
		var parsed *ParseResult
		for j := i + 2; j < len(toks); j++ {
			if toks[j].norm != "nanpa" {
				continue
			}
			words := make([]string, 0, j-i+1)
			good := true
			for k := i; k <= j; k++ {
				if toks[k].norm == "" || (k < j && toks[k].trail != "") {
					good = false
					break
				}
				words = append(words, toks[k].norm)
			}
			if good {
				if r, ok := newPhraseParseResult(words, p); ok {
					best, parsed = j, r
				}
			}
		}
		if best >= 0 {
			hits = append(hits, fullNumericHit{toks[i].start, toks[best].wordEnd, "tpPhrase", parsed})
			i = best
		}
	}
	return hits
}

func (n *NanpaLinjaN) scanGlyphNumericSuffixHits(s string, p FullParserOptions) []fullNumericHit {
	// Match the canonical browser boundary rule exactly: the combined glyph+digit
	// token must not be embedded in a larger [A-Za-z0-9^<>] token.
	re := regexp.MustCompile(`[A-Za-z^<>]+[0-9]+`)
	var out []fullNumericHit
	for _, m := range re.FindAllStringIndex(s, -1) {
		if m[0] > 0 {
			r, _ := utf8.DecodeLastRuneInString(s[:m[0]])
			if unicode.IsLetter(r) || unicode.IsDigit(r) || strings.ContainsRune("^<>", r) {
				continue
			}
		}
		if m[1] < len(s) {
			r, _ := utf8.DecodeRuneInString(s[m[1]:])
			if unicode.IsLetter(r) || unicode.IsDigit(r) || strings.ContainsRune("^<>", r) {
				continue
			}
		}
		raw := s[m[0]:m[1]]
		if _, exact := glyphInputAliases[strings.ToLower(raw)]; exact {
			continue
		}
		split := len(raw)
		for split > 0 && raw[split-1] >= '0' && raw[split-1] <= '9' {
			split--
		}
		glyph, digits := raw[:split], raw[split:]
		if _, ok := fullGlyphCP(normalizeFullGlyphKey(glyph)); !ok {
			continue
		}
		if r, ok := n.fullNumericParse(digits, p); ok {
			out = append(out, fullNumericHit{m[0] + split, m[1], "decimal", r})
		}
	}
	return out
}

// exhaustiveNumericCandidateHits mirrors the browser renderer's whole-segment
// numeric scanner at the semantic boundary: it asks the frozen numeric parser
// to validate every plausible complete numeric span, then the canonical greedy
// filter below selects the longest/highest-priority non-overlapping hits.
// This avoids maintaining a second, lossy mini-grammar in regular expressions.
func (n *NanpaLinjaN) exhaustiveNumericCandidateHits(s string, p FullParserOptions) []fullNumericHit {
	if s == "" {
		return nil
	}
	// Byte indexes are safe because every slice boundary below is taken from a
	// UTF-8 rune boundary. The parser itself accepts Unicode vulgar fractions
	// and Unicode minus/dash variants.
	bounds := []int{0}
	for i := range s {
		if i != 0 {
			bounds = append(bounds, i)
		}
	}
	if bounds[len(bounds)-1] != len(s) {
		bounds = append(bounds, len(s))
	}

	isWordRune := func(r rune) bool {
		return unicode.IsLetter(r) || unicode.IsDigit(r) || r == '_'
	}
	prevRune := func(pos int) (rune, bool) {
		if pos <= 0 {
			return 0, false
		}
		r, _ := utf8.DecodeLastRuneInString(s[:pos])
		return r, true
	}
	nextRune := func(pos int) (rune, bool) {
		if pos >= len(s) {
			return 0, false
		}
		r, _ := utf8.DecodeRuneInString(s[pos:])
		return r, true
	}
	plausibleStart := func(pos int) bool {
		if pos >= len(s) {
			return false
		}
		r, _ := utf8.DecodeRuneInString(s[pos:])
		if unicode.IsDigit(r) || strings.ContainsRune("+-#.", r) {
			return true
		}
		if _, ok := vulgarFractions[r]; ok {
			return true
		}
		// XXXX-MM-DD year placeholder.
		if r == 'X' || r == 'x' {
			return true
		}
		return false
	}
	boundaryStart := func(pos int) bool {
		if pos == 0 {
			return true
		}
		r, ok := prevRune(pos)
		return !ok || !isWordRune(r)
	}
	boundaryEnd := func(pos int) bool {
		if pos == len(s) {
			return true
		}
		r, ok := nextRune(pos)
		return !ok || !isWordRune(r)
	}
	badTerminal := func(raw string) bool {
		raw = strings.TrimSpace(raw)
		if raw == "" {
			return true
		}
		r, _ := utf8.DecodeLastRuneInString(raw)
		// The browser scanner strips sentence punctuation before parsing.
		return strings.ContainsRune(").,;:!?]}", r)
	}

	var out []fullNumericHit
	seen := map[[2]int]bool{}
	for bi, a := range bounds[:len(bounds)-1] {
		if !plausibleStart(a) || !boundaryStart(a) {
			continue
		}
		// Numeric source spans are intentionally bounded. This keeps the scanner
		// linear enough for normal document use while being far longer than any
		// protocol form used by the canonical renderer.
		for bj := bi + 1; bj < len(bounds); bj++ {
			b := bounds[bj]
			if b-a > 512 {
				break
			}
			if !boundaryEnd(b) {
				continue
			}
			raw := strings.TrimSpace(s[a:b])
			if raw == "" || raw == "+" || raw == "-" || badTerminal(raw) {
				continue
			}
			// Preserve exact source offsets when trimming horizontal whitespace.
			leftTrim := len(s[a:b]) - len(strings.TrimLeft(s[a:b], " \t\r\n"))
			rightTrim := len(s[a:b]) - len(strings.TrimRight(s[a:b], " \t\r\n"))
			start, end := a+leftTrim, b-rightTrim
			if start >= end || !boundaryStart(start) || !boundaryEnd(end) {
				continue
			}
			raw = s[start:end]
			if strings.IndexFunc(raw, unicode.IsSpace) >= 0 {
				// Canonical decimal/date/time scanners do not consume across ordinary
				// whitespace. The one intentional decimal exception is a mixed number
				// written as "8 1/2" (or a vulgar-fraction equivalent).
				mixedSpace := regexp.MustCompile(`^[+-]?[0-9][0-9,]*[ \t]+(?:[0-9]+/[0-9]+|[¼½¾⅐-⅞])$`).MatchString(raw)
				if !mixedSpace {
					continue
				}
			}
			if r, ok := n.fullNumericParse(raw, p); ok {
				kind := "decimal"
				if r.IsDate {
					kind = "date"
				}
				if r.IsTime {
					kind = "time"
				}
				if r.IsHex != nil && *r.IsHex {
					kind = "hex"
				}
				if r.IsBinary != nil && *r.IsBinary {
					kind = "binary"
				}
				if strings.HasPrefix(raw, "#~") && kind == "decimal" {
					kind = "code"
				}
				key := [2]int{start, end}
				if !seen[key] {
					seen[key] = true
					out = append(out, fullNumericHit{start, end, kind, r})
				}
			}
		}
	}
	return out
}

func protectedAliasSpans(s string) [][2]int {
	var out [][2]int
	re := regexp.MustCompile(`[A-Za-z0-9^<>]+`)
	for _, m := range re.FindAllStringIndex(s, -1) {
		if _, ok := glyphInputAliases[strings.ToLower(s[m[0]:m[1]])]; ok {
			out = append(out, [2]int{m[0], m[1]})
		}
	}
	return out
}

func overlapsAny(a, b int, spans [][2]int) bool {
	for _, s := range spans {
		if a < s[1] && b > s[0] {
			return true
		}
	}
	return false
}

func (n *NanpaLinjaN) scanCanonicalNumericHits(s string, p FullParserOptions) []fullNumericHit {
	var all []fullNumericHit
	// When binary parsing/rendering is disabled the canonical browser no longer
	// reserves 0b... as a binary token. Its ordinary decimal scanner then sees
	// the leading "0b" as a magnitude-suffixed decimal; the first following
	// digit is separately claimed at the letter boundary and the remaining
	// digits form the final decimal hit. Preserve that somewhat surprising but
	// observable fallback rather than hiding the entire token as unknown text.
	if !p.EnableBinaryParsing && !p.EnableBinaryRendering {
		re := regexp.MustCompile(`0b([01]+)`)
		for _, m := range re.FindAllStringSubmatchIndex(s, -1) {
			if m[0] > 0 {
				r, _ := utf8.DecodeLastRuneInString(s[:m[0]])
				if unicode.IsLetter(r) || unicode.IsDigit(r) || r == '_' {
					continue
				}
			}
			prefixEnd := m[0] + 2
			if r, ok := n.fullNumericParse(s[m[0]:prefixEnd], p); ok {
				all = append(all, fullNumericHit{m[0], prefixEnd, "decimal", r})
			}
			digitStart, digitEnd := m[2], m[3]
			if digitEnd > digitStart {
				firstEnd := digitStart + 1
				if r, ok := n.fullNumericParse(s[digitStart:firstEnd], p); ok {
					all = append(all, fullNumericHit{digitStart, firstEnd, "decimal", r})
				}
				if firstEnd < digitEnd {
					if r, ok := n.fullNumericParse(s[firstEnd:digitEnd], p); ok {
						all = append(all, fullNumericHit{firstEnd, digitEnd, "decimal", r})
					}
				}
			}
		}
	}
	all = append(all, n.scanGlyphNumericSuffixHits(s, p)...)
	all = append(all, n.scanProperNameHits(s, p)...)
	all = append(all, scanTpPhraseHits(s, p)...)
	aliases := protectedAliasSpans(s)
	for _, h := range n.exhaustiveNumericCandidateHits(s, p) {
		if !overlapsAny(h.Start, h.End, aliases) {
			all = append(all, h)
		}
	}
	sort.SliceStable(all, func(i, j int) bool {
		if all[i].Start != all[j].Start {
			return all[i].Start < all[j].Start
		}
		li, lj := all[i].End-all[i].Start, all[j].End-all[j].Start
		if li != lj {
			return li > lj
		}
		return fullHitPriority(all[i].Kind) > fullHitPriority(all[j].Kind)
	})
	out := make([]fullNumericHit, 0, len(all))
	lastEnd := -1
	for _, h := range all {
		if h.Start < lastEnd {
			continue
		}
		out = append(out, h)
		lastEnd = h.End
	}
	return out
}
