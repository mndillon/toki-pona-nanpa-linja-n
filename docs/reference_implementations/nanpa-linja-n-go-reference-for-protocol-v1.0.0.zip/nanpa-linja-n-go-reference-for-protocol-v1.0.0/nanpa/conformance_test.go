package nanpa

import (
	"encoding/json"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
)

type corpusCase struct {
	ID, Category string
	Input        any
	Options      map[string]any
	Assert       map[string]any
}
type corpus struct {
	ParserCases   []corpusCase `json:"parserCases"`
	RendererCases []corpusCase `json:"rendererCases"`
}

func loadCorpus(t *testing.T) corpus {
	t.Helper()
	p := filepath.Join("..", "testdata", "nanpa-linja-n-regression-v1.0.2.json")
	b, e := os.ReadFile(p)
	if e != nil {
		t.Fatal(e)
	}
	var c corpus
	if e = json.Unmarshal(b, &c); e != nil {
		t.Fatal(e)
	}
	return c
}
func optsFrom(m map[string]any) Options {
	b, _ := json.Marshal(m)
	var o Options
	_ = json.Unmarshal(b, &o)
	return o
}
func resultMap(r *ParseResult) map[string]any {
	b, _ := json.Marshal(r)
	var m map[string]any
	_ = json.Unmarshal(b, &m)
	return m
}
func normalize(v any) any { b, _ := json.Marshal(v); var x any; _ = json.Unmarshal(b, &x); return x }

func checkCase(t *testing.T, tc corpusCase) {
	t.Helper()
	o := optsFrom(tc.Options)
	r, e := ParseNumber(tc.Input, o)
	wantReject := tc.Assert["result"] == "reject" || tc.Assert["accepted"] == false
	if wantReject {
		if e == nil {
			t.Fatalf("%s: expected reject, got %#v", tc.ID, r)
		}
		return
	}
	if e != nil {
		t.Fatalf("%s: expected accept: %v", tc.ID, e)
	}
	got := resultMap(r)
	for k, w := range tc.Assert {
		switch k {
		case "result", "accepted", "notes":
			continue
		case "absentFields":
			for _, raw := range w.([]any) {
				if _, ok := got[raw.(string)]; ok {
					t.Errorf("%s: field %s should be absent", tc.ID, raw)
				}
			}
		case "tpWordsFirst":
			if len(r.TpWords) == 0 || r.TpWords[0] != w {
				t.Errorf("%s: tpWordsFirst got %v want %v", tc.ID, first(r.TpWords), w)
			}
		case "tpWordsLast":
			if len(r.TpWords) == 0 || r.TpWords[len(r.TpWords)-1] != w {
				t.Errorf("%s tpWordsLast got %v want %v", tc.ID, last(r.TpWords), w)
			}
		case "properNameStartsWith":
			if len(r.ProperName) < len(w.(string)) || r.ProperName[:len(w.(string))] != w.(string) {
				t.Errorf("%s proper prefix got %q want %q", tc.ID, r.ProperName, w)
			}
		case "equivalentValue", "equivalentToInput":
			rr, ee := ParseNumber(w, o)
			if ee != nil {
				t.Errorf("%s equivalent %v rejects: %v", tc.ID, w, ee)
				continue
			}
			if r.DisplayValue != rr.DisplayValue && !(strings.TrimPrefix(r.DisplayValue, "+") == strings.TrimPrefix(rr.DisplayValue, "+")) {
				t.Errorf("%s value not equivalent got %v other %v", tc.ID, r.DisplayValue, rr.DisplayValue)
			}
		case "tpWordsContainsSubsequence":
			want := w.([]any)
			found := false
			for i := 0; i+len(want) <= len(r.TpWords); i++ {
				ok := true
				for j, x := range want {
					if r.TpWords[i+j] != x.(string) {
						ok = false
						break
					}
				}
				if ok {
					found = true
					break
				}
			}
			if !found {
				t.Errorf("%s missing subsequence %v in %v", tc.ID, w, r.TpWords)
			}
		case "codepointsFirstInner":
			if len(r.InnerCodepoints) == 0 || r.InnerCodepoints[0] != int(w.(float64)) {
				t.Errorf("%s first inner", tc.ID)
			}
		case "codepointsLastInner":
			if len(r.InnerCodepoints) == 0 || r.InnerCodepoints[len(r.InnerCodepoints)-1] != int(w.(float64)) {
				t.Errorf("%s last inner", tc.ID)
			}
		case "cartoucheStart":
			if len(r.Codepoints) == 0 || r.Codepoints[0] != int(w.(float64)) {
				t.Errorf("%s cart start", tc.ID)
			}
		case "cartoucheEnd":
			if len(r.Codepoints) == 0 || r.Codepoints[len(r.Codepoints)-1] != int(w.(float64)) {
				t.Errorf("%s cart end", tc.ID)
			}
		default:
			gv, ok := got[k]
			if !ok {
				if w == nil {
					continue
				}
				t.Errorf("%s: missing field %s wanted %v", tc.ID, k, w)
				continue
			}
			if !reflect.DeepEqual(normalize(gv), normalize(w)) {
				t.Errorf("%s: %s got %#v want %#v", tc.ID, k, gv, w)
			}
		}
	}
}
func first(a []string) any {
	if len(a) == 0 {
		return nil
	}
	return a[0]
}
func last(a []string) any {
	if len(a) == 0 {
		return nil
	}
	return a[len(a)-1]
}

func TestParserConformance(t *testing.T) {
	c := loadCorpus(t)
	for _, tc := range c.ParserCases {
		t.Run(tc.ID, func(t *testing.T) { checkCase(t, tc) })
	}
}
func TestRendererConformance(t *testing.T) {
	c := loadCorpus(t)
	for _, tc := range c.RendererCases {
		t.Run(tc.ID, func(t *testing.T) { checkCase(t, tc) })
	}
}

type fullCorpus struct {
	ApiCases []struct {
		ID, API string
		Input   any
		Options map[string]any
		Assert  map[string]any
	} `json:"apiCases"`
	EquivalenceGroups []struct {
		ID      string
		Members []string
		Compare []string
		Options map[string]any
	} `json:"equivalenceGroups"`
}

func loadFullCorpus(t *testing.T) fullCorpus {
	t.Helper()
	b, e := os.ReadFile(filepath.Join("..", "testdata", "nanpa-linja-n-regression-v1.0.2.json"))
	if e != nil {
		t.Fatal(e)
	}
	var c fullCorpus
	if e = json.Unmarshal(b, &c); e != nil {
		t.Fatal(e)
	}
	return c
}
func TestAPICases(t *testing.T) {
	c := loadFullCorpus(t)
	for _, tc := range c.ApiCases {
		t.Run(tc.ID, func(t *testing.T) {
			o := optsFrom(tc.Options)
			var v any
			var e error
			switch tc.API {
			case "encodeDecimal":
				v, e = EncodeDecimal(tc.Input.(string), o)
			case "decimalToUcsurCodepoints":
				v, e = DecimalToUcsurCodepoints(tc.Input.(string), o)
			case "properNameToUcsurCodepoints":
				v, e = ProperNameToUcsurCodepoints(tc.Input.(string), o)
			case "splitCapsToProperName":
				title, _ := tc.Options["titleCase"].(bool)
				v, e = SplitCapsToProperName(tc.Input.(string), title, o)
			case "capsToWords":
				v, e = CapsToWords(tc.Input.(string), o)
			case "capsToCodepoints":
				v, e = CapsToCodepoints(tc.Input.(string), o)
			case "parseIdentifier":
				v, e = ParseIdentifier(tc.Input.(string), o)
			case "codepointsToWords":
				xs := tc.Input.([]any)
				a := make([]int, len(xs))
				for i, x := range xs {
					a[i] = int(x.(float64))
				}
				v = CodepointsToWords(a)
			default:
				t.Fatalf("unsupported api %s", tc.API)
			}
			if e != nil {
				t.Fatal(e)
			}
			if ex, ok := tc.Assert["exact"]; ok && !reflect.DeepEqual(normalize(v), normalize(ex)) {
				t.Fatalf("got %#v want %#v", v, ex)
			}
			if ne, ok := tc.Assert["nonEmpty"].(bool); ok && ne {
				rv := reflect.ValueOf(v)
				if (rv.Kind() == reflect.String || rv.Kind() == reflect.Array || rv.Kind() == reflect.Slice || rv.Kind() == reflect.Map) && rv.Len() == 0 {
					t.Fatalf("empty result")
				}
			}
			if req, ok := tc.Assert["requiredFields"].([]any); ok {
				b, _ := json.Marshal(v)
				var m map[string]any
				_ = json.Unmarshal(b, &m)
				for _, r := range req {
					if _, ok := m[r.(string)]; !ok {
						t.Errorf("missing %s", r)
					}
				}
			}
		})
	}
}
func TestEquivalenceGroups(t *testing.T) {
	c := loadFullCorpus(t)
	for _, g := range c.EquivalenceGroups {
		t.Run(g.ID, func(t *testing.T) {
			o := optsFrom(g.Options)
			base, e := ParseNumber(g.Members[0], o)
			if e != nil {
				t.Fatal(e)
			}
			bm := resultMap(base)
			for _, member := range g.Members[1:] {
				r, e := ParseNumber(member, o)
				if e != nil {
					t.Fatalf("%s: %v", member, e)
				}
				rm := resultMap(r)
				for _, f := range g.Compare {
					if !reflect.DeepEqual(normalize(bm[f]), normalize(rm[f])) {
						t.Errorf("%s field %s got %#v want %#v", member, f, rm[f], bm[f])
					}
				}
			}
		})
	}
}
