package nanpa

import (
	"fmt"
	"regexp"
	"strconv"
	"strings"
)

type decodedTime struct {
	hasDays, negativeInput, negative, isZero bool
	day, hh, mm, ss, frac                    string
}

func decodeTimeCaps(caps string, opts Options) (decodedTime, bool) {
	t, e := tokenizeCaps(strings.ToUpper(strings.TrimSpace(caps)), opts)
	if e != nil || len(t) < 2 || t[0] != "NE" || t[len(t)-1] != "N" {
		return decodedTime{}, false
	}
	final := len(t) - 1
	i := 1
	negIn := false
	if i < final && t[i] == "NO" {
		negIn = true
		i++
	}
	type seg struct{ i, f string }
	ss := []seg{}
	for i < final {
		in := ""
		for i < final {
			d, ok := digitTokenToChar[t[i]]
			if !ok {
				break
			}
			in += d
			i++
		}
		if in == "" {
			return decodedTime{}, false
		}
		fr := ""
		hasFr := false
		if i+1 < final && t[i] == "NO" && t[i+1] == "NE" {
			i += 2
			hasFr = true
			for i < final {
				d, ok := digitTokenToChar[t[i]]
				if !ok {
					break
				}
				fr += d
				i++
			}
			if len(fr) < 1 || len(fr) > 3 {
				return decodedTime{}, false
			}
		}
		if !hasFr {
			fr = ""
		}
		ss = append(ss, seg{in, fr})
		if i == final {
			break
		}
		if i+1 >= final || t[i] != "NE" || t[i+1] != "KE" {
			return decodedTime{}, false
		}
		i += 2
	}
	if i != final || len(ss) < 2 || len(ss) > 4 {
		return decodedTime{}, false
	}
	for _, s := range ss[:len(ss)-1] {
		if s.f != "" {
			return decodedTime{}, false
		}
	}
	pair := func(s seg) bool {
		return s.f == "" && len(s.i) == 2 && s.i[0] >= '0' && s.i[0] <= '5' && allDigits(s.i)
	}
	seconds := func(s seg) bool {
		return len(s.i) == 2 && s.i[0] >= '0' && s.i[0] <= '5' && allDigits(s.i) && (s.f == "" || (len(s.f) >= 1 && len(s.f) <= 3 && allDigits(s.f)))
	}
	zeroState := func(day seg, others []seg) (bool, bool) {
		x := day.i
		for _, s := range others {
			x += s.i + s.f
		}
		z := !strings.ContainsAny(x, "123456789")
		return negIn && !z, z
	}
	if len(ss) == 2 {
		if negIn || ss[0].f != "" || len(ss[0].i) > 2 || !allDigits(ss[0].i) || !pair(ss[1]) {
			return decodedTime{}, false
		}
		h, _ := strconv.Atoi(ss[0].i)
		if h > 59 {
			return decodedTime{}, false
		}
		return decodedTime{hh: ss[0].i, mm: ss[1].i, isZero: h == 0 && ss[1].i == "00"}, true
	}
	if len(ss) == 3 && ss[2].f != "" {
		if negIn || ss[0].f != "" || len(ss[0].i) > 2 || !allDigits(ss[0].i) || !pair(ss[1]) || !seconds(ss[2]) {
			return decodedTime{}, false
		}
		h, _ := strconv.Atoi(ss[0].i)
		if h > 59 {
			return decodedTime{}, false
		}
		z := !strings.ContainsAny(ss[0].i+ss[1].i+ss[2].i+ss[2].f, "123456789")
		return decodedTime{hh: ss[0].i, mm: ss[1].i, ss: ss[2].i, frac: ss[2].f, isZero: z}, true
	}
	if len(ss) == 3 {
		if ss[0].f != "" || !allDigits(ss[0].i) || !pair(ss[1]) || !pair(ss[2]) {
			return decodedTime{}, false
		}
		n, z := zeroState(ss[0], ss[1:])
		return decodedTime{hasDays: true, negativeInput: negIn, negative: n, isZero: z, day: ss[0].i, hh: ss[1].i, mm: ss[2].i}, true
	}
	if ss[0].f != "" || !allDigits(ss[0].i) || !pair(ss[1]) || !pair(ss[2]) || !seconds(ss[3]) {
		return decodedTime{}, false
	}
	n, z := zeroState(ss[0], ss[1:])
	return decodedTime{hasDays: true, negativeInput: negIn, negative: n, isZero: z, day: ss[0].i, hh: ss[1].i, mm: ss[2].i, ss: ss[3].i, frac: ss[3].f}, true
}
func normalizeTimeNegativeZeroCaps(c string, opts Options) string {
	d, ok := decodeTimeCaps(c, opts)
	if !ok || !d.negativeInput || !d.isZero {
		return c
	}
	t, e := tokenizeCaps(c, opts)
	if e != nil {
		return c
	}
	if len(t) > 1 && t[0] == "NE" && t[1] == "NO" {
		t = append(t[:1], t[2:]...)
	}
	return strings.Join(t, "")
}
func validTime(c string, opts Options) bool { _, ok := decodeTimeCaps(c, opts); return ok }
func decodeDateCaps(c string, opts Options) (string, string, bool) {
	t, e := tokenizeCaps(strings.ToUpper(strings.TrimSpace(c)), opts)
	if e != nil || len(t) < 2 || t[0] != "NE" || t[len(t)-1] != "N" {
		return "", "", false
	}
	i := 1
	read := func() (string, bool) {
		if i >= len(t)-1 {
			return "", false
		}
		d, ok := digitTokenToChar[t[i]]
		if !ok {
			return "", false
		}
		i++
		return d, true
	}
	y := ""
	for k := 0; k < 4; k++ {
		d, ok := read()
		if !ok {
			return "", "", false
		}
		y += d
	}
	if i+1 >= len(t) || t[i] != "NE" || t[i+1] != "KE" {
		return "", "", false
	}
	i += 2
	m1, ok := read()
	if !ok {
		return "", "", false
	}
	m2, ok := read()
	if !ok {
		return "", "", false
	}
	if i+1 >= len(t) || t[i] != "NE" || t[i+1] != "KE" {
		return "", "", false
	}
	i += 2
	d1, ok := read()
	if !ok {
		return "", "", false
	}
	d2, ok := read()
	if !ok {
		return "", "", false
	}
	if i != len(t)-1 {
		return "", "", false
	}
	mm, dd := m1+m2, d1+d2
	mi, _ := strconv.Atoi(mm)
	di, _ := strconv.Atoi(dd)
	if mi < 1 || mi > 12 || di < 1 || di > 31 {
		return "", "", false
	}
	_ = y
	return mm, dd, true
}
func decodeYearlessDateCaps(c string, opts Options) (string, string, bool) {
	t, e := tokenizeCaps(strings.ToUpper(strings.TrimSpace(c)), opts)
	if e != nil || len(t) < 2 || t[0] != "NE" || t[len(t)-1] != "N" {
		return "", "", false
	}
	i := 1
	read := func() (string, bool) {
		if i >= len(t)-1 {
			return "", false
		}
		d, ok := digitTokenToChar[t[i]]
		if !ok {
			return "", false
		}
		i++
		return d, true
	}
	m1, ok := read()
	if !ok {
		return "", "", false
	}
	m2, ok := read()
	if !ok {
		return "", "", false
	}
	if i+1 >= len(t) || t[i] != "NE" || t[i+1] != "KE" {
		return "", "", false
	}
	i += 2
	d1, ok := read()
	if !ok {
		return "", "", false
	}
	d2, ok := read()
	if !ok {
		return "", "", false
	}
	if i != len(t)-1 {
		return "", "", false
	}
	mm, dd := m1+m2, d1+d2
	if !validYearless(mm, dd) {
		return "", "", false
	}
	return mm, dd, true
}
func validDate(c string, opts Options) bool       { _, _, ok := decodeDateCaps(c, opts); return ok }
func validTimeOrDate(c string, opts Options) bool { return validDate(c, opts) || validTime(c, opts) }
func dayOfMonthCaps(c string, opts Options) bool {
	t, e := tokenizeCaps(c, opts)
	if e != nil || len(t) < 3 || t[0] != "NE" || t[len(t)-1] != "N" {
		return false
	}
	x := ""
	for _, q := range t[1 : len(t)-1] {
		d, ok := digitTokenToChar[q]
		if !ok {
			return false
		}
		x += d
	}
	v, e := strconv.Atoi(x)
	return e == nil && v >= 1 && v <= 31
}

func normalizeStartGlyph(s string) string {
	switch strings.ToLower(strings.TrimSpace(s)) {
	case "nanpa", "tenpo", "suno", "toki":
		return strings.ToLower(strings.TrimSpace(s))
	}
	return ""
}
func resolveStartGlyph(req, def string) string {
	if x := normalizeStartGlyph(req); x != "" {
		return x
	}
	return def
}

func uniformize(cps []int) []int {
	a := append([]int{}, cps...)
	if len(a) == 0 {
		return a
	}
	starts := map[int]bool{wordToCP["nanpa"]: true, wordToCP["nasa"]: true, wordToCP["noka"]: true, wordToCP["tenpo"]: true, wordToCP["suno"]: true, wordToCP["toki"]: true}
	positive := len(a) >= 4 && starts[a[0]] && a[1] == wordToCP["e"] && a[2] == wordToCP["nena"] && a[3] == wordToCP["en"]
	toNena := map[int]bool{wordToCP["nasa"]: true, wordToCP["nasin"]: true, wordToCP["ni"]: true, wordToCP["nimi"]: true, wordToCP["noka"]: true, wordToCP["nena"]: true}
	toE := map[int]bool{wordToCP["e"]: true, wordToCP["en"]: true, wordToCP["esun"]: true}
	for i, cp := range a {
		if i == 0 && starts[cp] {
			continue
		}
		if cp == wordToCP["nanpa"] {
			if i != 0 && i != len(a)-1 {
				a[i] = wordToCP["nena"]
			}
			continue
		}
		if toNena[cp] {
			a[i] = wordToCP["nena"]
		} else if toE[cp] {
			if positive && i == 3 {
				a[i] = wordToCP["en"]
			} else {
				a[i] = wordToCP["e"]
			}
		}
	}
	return a
}

func capsTokensToTpWords(tokens []string, opts Options, semanticKind, semanticStart string) ([]string, error) {
	if len(tokens) == 0 {
		return []string{}, nil
	}
	uniform := opts.normalizedMode() == "uniform"
	eWord := "esun"
	nWord := "nasa"
	decimalN := "ni"
	if uniform {
		eWord = "e"
		nWord = "nena"
		decimalN = "nena"
	}
	def := "nanpa"
	if opts.NanpaColonRendering {
		if semanticKind == "date" {
			def = "suno"
		} else if semanticKind == "time" {
			def = "tenpo"
		}
	}
	explicit := normalizeStartGlyph(semanticStart)
	if explicit != "" {
		def = explicit
	}
	start := resolveStartGlyph(opts.NumericCartoucheStartGlyph, def)
	out := []string{}
	afterStart, afterSci := false, false
	for i := 0; i < len(tokens); i++ {
		t := tokens[i]
		if t == "NE" {
			next := ""
			if i+1 < len(tokens) {
				next = tokens[i+1]
			}
			if next == "KO" {
				if len(out) == 0 {
					if opts.NanpaColonRendering {
						out = append(out, start, ":", "kala", "open")
					} else {
						out = append(out, start, eWord, "kala", "open")
					}
				} else {
					out = append(out, nWord, "e", "kala", "open")
				}
				afterStart = false
				afterSci = true
				i++
				continue
			}
			afterSci = false
			if len(out) == 0 {
				if opts.NanpaColonRendering {
					out = append(out, start, ":")
				} else {
					out = append(out, start, eWord)
				}
				afterStart = true
			} else {
				out = append(out, nWord, "e")
				afterStart = false
			}
			continue
		}
		if t == "NS" {
			out = append(out, "nena", "en")
			afterStart, afterSci = false, false
			continue
		}
		if _, ok := digitTokenToChar[t]; ok {
			afterStart, afterSci = false, false
			if opts.RelaxedNanpaLinjanRendering {
				if w, ok := relaxedRenderWords[t]; ok {
					out = append(out, w...)
					continue
				}
			}
			st := t
			if x, ok := relaxedToStrict[t]; ok {
				st = x
			}
			w := digitTokenToWord[st]
			if st == "NI" || st == "NA" || st == "NU" {
				out = append(out, nWord, w)
			} else {
				out = append(out, w, eWord)
			}
			continue
		}
		if t == "NO" {
			if afterStart || afterSci {
				out = append(out, nWord, "ona")
				afterStart, afterSci = false, false
				continue
			}
			next := ""
			if i+1 < len(tokens) {
				next = tokens[i+1]
			}
			if next == "NE" {
				out = append(out, decimalN, "o", nWord, "e")
				i++
			} else {
				out = append(out, decimalN, "o")
			}
			afterStart = false
			continue
		}
		switch t {
		case "NONO":
			out = append(out, "nena", "o", "nena", "o")
		case "NOKO":
			out = append(out, "nena", "open", "kin", "open")
		case "NONONO":
			out = append(out, nWord, "o", nWord, "o", nWord, "o")
		case "KE":
			out = append(out, "kulupu", "e")
		case "KEKE":
			out = append(out, "kulupu", "e", "kulupu", "e")
		case "KEKEKE":
			out = append(out, "kulupu", "e", "kulupu", "e", "kulupu", "e")
		case "N":
			out = append(out, "nanpa")
		default:
			return nil, fmt.Errorf("unknown token %s", t)
		}
		afterStart = false
	}
	return out, nil
}
func replaceTimeSeparators(words []string, mode string) []string {
	n := "nasa"
	if mode == "uniform" {
		n = "nena"
	}
	pat := []string{n, "e", "kulupu", "e"}
	out := []string{}
	for i := 0; i < len(words); {
		match := i+4 <= len(words)
		if match {
			for k := 0; k < 4; k++ {
				if words[i+k] != pat[k] {
					match = false
					break
				}
			}
		}
		if match {
			out = append(out, n, "e", "kasi", "e")
			i += 4
		} else {
			out = append(out, words[i])
			i++
		}
	}
	return out
}
func capsToInnerCodepoints(caps string, opts Options, isTime bool, semanticKind, semanticStart string) ([]int, error) {
	c := canonicalizeScientificCaps(caps)
	if isTime && validTime(c, opts) {
		c = normalizeTimeNegativeZeroCaps(c, opts)
	}
	t, e := tokenizeCaps(c, opts)
	if e != nil || !hasDigitToken(t) {
		return nil, fmt.Errorf("invalid caps")
	}
	hasPct := false
	base := []string{}
	for _, x := range t {
		if x == "OK" {
			hasPct = true
		} else {
			base = append(base, x)
		}
	}
	words, e := capsTokensToTpWords(base, opts, semanticKind, semanticStart)
	if e != nil {
		return nil, e
	}
	if isTime {
		words = replaceTimeSeparators(words, opts.normalizedMode())
	}
	cps, e := tpWordsToCodepoints(words)
	if e != nil {
		return nil, e
	}
	if opts.normalizedMode() == "uniform" {
		cps = uniformize(cps)
	}
	if hasPct {
		suffix := []string{"nena", "open", "kipisi", "e"}
		if opts.normalizedMode() == "traditional" {
			suffix = []string{"noka", "open", "kipisi", "e"}
		}
		sc, _ := tpWordsToCodepoints(suffix)
		idx := -1
		for i := len(cps) - 1; i >= 0; i-- {
			if cps[i] == wordToCP["nanpa"] {
				idx = i
				break
			}
		}
		if idx >= 0 {
			cps = append(cps[:idx], append(sc, cps[idx:]...)...)
		} else {
			cps = append(cps, sc...)
		}
	}
	return cps, nil
}

func nanpaColonProperNameFromLegacy(raw, semanticStart string) string {
	body := strings.ToLower(strings.TrimSpace(raw))
	if body == "" {
		return ""
	}
	if strings.HasPrefix(body, "ne") {
		body = strings.TrimSpace(body[2:])
	} else if strings.HasPrefix(body, "n ene") {
		body = strings.TrimSpace(body[2:])
	}
	w := strings.Fields(body)
	if len(w) > 1 && (w[0] == "no" || w[0] == "ne") {
		w[0] += w[1]
		w = append(w[:1], w[2:]...)
	}
	for i, x := range w {
		w[i] = strings.ToUpper(x[:1]) + x[1:]
	}
	head := "Nanpa"
	if normalizeStartGlyph(semanticStart) == "toki" {
		head = "Toki"
	} else if normalizeStartGlyph(semanticStart) == "suno" {
		head = "Suno"
	}
	if len(w) == 0 {
		return ""
	}
	return head + " " + strings.Join(w, " ")
}

func nanpaColonProperNameToCaps(raw string, opts Options) (string, bool) {
	if !opts.nanpaColonParsing() {
		return "", false
	}
	s := strings.TrimSpace(raw)
	if s == "" {
		return "", false
	}
	var rem string
	if m := regexp.MustCompile(`^Nanpa([a-z]+)((?:[ \t]+[A-Z][a-z]*)*)$`).FindStringSubmatch(s); m != nil {
		rem = m[1] + strings.Join(strings.Fields(m[2]), "")
	} else if regexp.MustCompile(`^Nanpa(?:[ \t]+[A-Z][a-z]*)+$`).MatchString(s) {
		f := strings.Fields(s)
		rem = strings.Join(f[1:], "")
	} else {
		return "", false
	}
	if rem == "" || !strings.HasSuffix(strings.ToLower(rem), "n") {
		return "", false
	}
	core := rem[:len(rem)-1]
	if len(core) < 2 || len(core)%2 != 0 {
		return "", false
	}
	pct := false
	if strings.HasSuffix(strings.ToLower(core), "noke") {
		pct = true
		core = core[:len(core)-4]
		if len(core) < 2 || len(core)%2 != 0 {
			return "", false
		}
	}
	body := strings.ToUpper(core)
	if strings.HasPrefix(body, "NE") {
		body = "NS" + body[2:]
	}
	c := "NE" + body
	if pct {
		c += "OKN"
	} else {
		c += "N"
	}
	t, e := tokenizeCaps(c, opts)
	return c, e == nil && hasDigitToken(t)
}

type typedInfo struct{ caps, head, kind, dateKind, startGlyph string }

func typedNumericProper(raw string, opts Options) (typedInfo, bool) {
	if !opts.nanpaColonParsing() {
		return typedInfo{}, false
	}
	s := strings.TrimSpace(raw)
	if !regexp.MustCompile(`^Toki(?:[ \t]+[A-Z][a-z]*)+$`).MatchString(s) {
		return typedInfo{}, false
	}
	f := strings.Fields(s)
	c, ok := nanpaColonProperNameToCaps("Nanpa "+strings.Join(f[1:], " "), opts)
	if !ok {
		return typedInfo{}, false
	}
	return typedInfo{caps: c, head: "toki", startGlyph: "toki"}, true
}
func typedDateTimeProper(raw string, opts Options) (typedInfo, bool) {
	if !opts.nanpaColonParsing() {
		return typedInfo{}, false
	}
	s := strings.TrimSpace(raw)
	if !regexp.MustCompile(`^(?:Tenpo|Suno)(?:[ \t]+[A-Z][a-z]*)+$`).MatchString(s) {
		return typedInfo{}, false
	}
	f := strings.Fields(s)
	c, ok := nanpaColonProperNameToCaps("Nanpa "+strings.Join(f[1:], " "), opts)
	if !ok {
		return typedInfo{}, false
	}
	if f[0] == "Tenpo" {
		if !validTime(c, opts) {
			return typedInfo{}, false
		}
		return typedInfo{caps: c, head: "tenpo", kind: "time"}, true
	}
	_, _, full := decodeDateCaps(c, opts)
	_, _, year := decodeYearlessDateCaps(c, opts)
	if full || year {
		dk := "full"
		if year && !full {
			dk = "yearless"
		}
		return typedInfo{caps: c, head: "suno", kind: "date", dateKind: dk}, true
	}
	if dayOfMonthCaps(c, opts) {
		return typedInfo{caps: c, head: "suno", startGlyph: "suno"}, true
	}
	return typedInfo{}, false
}

func properNameToCaps(raw string, opts Options) (string, typedInfo, bool) {
	s := strings.TrimSpace(raw)
	if s == "" {
		return "", typedInfo{}, false
	}
	if t, ok := typedNumericProper(s, opts); ok {
		return t.caps, t, true
	}
	if t, ok := typedDateTimeProper(s, opts); ok {
		return t.caps, t, true
	}
	if c, ok := nanpaColonProperNameToCaps(s, opts); ok {
		return c, typedInfo{}, true
	}
	if !regexp.MustCompile(`^[A-Za-z]+(?:\s+[A-Za-z]+)*$`).MatchString(s) {
		return "", typedInfo{}, false
	}
	compact := strings.Join(strings.Fields(s), "")
	if !strings.HasSuffix(strings.ToLower(compact), "n") {
		return "", typedInfo{}, false
	}
	core := compact[:len(compact)-1]
	if len(core) < 2 || len(core)%2 != 0 {
		return "", typedInfo{}, false
	}
	pct := false
	if strings.HasSuffix(strings.ToLower(core), "noke") {
		pct = true
		core = core[:len(core)-4]
		if len(core) < 2 || len(core)%2 != 0 {
			return "", typedInfo{}, false
		}
	}
	cc := strings.ToUpper(core)
	if !strings.HasPrefix(cc, "NE") {
		return "", typedInfo{}, false
	}
	if strings.HasPrefix(strings.ToLower(s), "nene") && strings.HasPrefix(cc, "NENE") {
		cc = "NENS" + cc[4:]
	}
	c := cc + "N"
	if pct {
		c = cc + "OKN"
	}
	if _, e := tokenizeCaps(c, opts); e != nil {
		return "", typedInfo{}, false
	}
	return c, typedInfo{}, true
}

func parseNumberCode(raw string, opts Options) (typedInfo, bool) {
	s := strings.Join(strings.Fields(strings.TrimSpace(raw)), "")
	if len(s) < 2 || !strings.EqualFold(s[:2], "#~") {
		return typedInfo{}, false
	}
	bodyRaw := s[2:]
	if bodyRaw == "" {
		return typedInfo{}, false
	}
	year := strings.HasPrefix(bodyRaw, "k")
	if year {
		bodyRaw = bodyRaw[1:]
		if bodyRaw == "" {
			return typedInfo{}, false
		}
	}
	plus := false
	if strings.HasPrefix(bodyRaw, "+") {
		plus = true
		bodyRaw = bodyRaw[1:]
		if bodyRaw == "" {
			return typedInfo{}, false
		}
	}
	body := strings.ToUpper(bodyRaw)
	if !regexp.MustCompile(`^[A-Z]+$`).MatchString(body) {
		return typedInfo{}, false
	}
	lead := 0
	for lead < len(body) && body[lead] == 'E' {
		lead++
	}
	if plus {
		if lead >= len(body) || codeLetterToToken[body[0]] == "" {
			return typedInfo{}, false
		}
	} else if lead == 1 {
		if len(body) < 2 || codeLetterToToken[body[1]] == "" {
			return typedInfo{}, false
		}
		plus = true
		body = body[1:]
	} else if lead > 1 && lead%2 == 1 {
		return typedInfo{}, false
	}
	pct := false
	if strings.HasSuffix(body, "OK") {
		pct = true
		body = body[:len(body)-2]
		if body == "" {
			return typedInfo{}, false
		}
	}
	t := []string{"NE"}
	if plus {
		t = append(t, "NS")
	}
	legacy := strings.Index(body, "KOWIKO")
	legacyOK := legacy > 0 && body[legacy-1] != 'O' && legacy+6 < len(body)
	ensureNE := func() {
		if t[len(t)-1] != "NE" {
			t = append(t, "NE")
		}
	}
	for i := 0; i < len(body); {
		ch := body[i]
		if strings.HasPrefix(body[i:], "OKO") {
			t = append(t, "NOKO")
			i += 3
			continue
		}
		if ch == 'E' {
			j := i
			for j < len(body) && body[j] == 'E' {
				j++
			}
			count := j - i
			for k := 0; k < count/2; k++ {
				t = append(t, "NE", "NE")
			}
			if count%2 == 1 {
				idx := j - 1
				if !strings.HasPrefix(body[j:], "KO") || idx <= 0 || j+2 >= len(body) {
					return typedInfo{}, false
				}
				t = append(t, "NE", "KO")
				i = j + 2
			} else {
				i = j
			}
			continue
		}
		if legacyOK && strings.HasPrefix(body[i:], "KO") && (i == legacy || i == legacy+4) {
			ensureNE()
			t = append(t, "KO")
			i += 2
			continue
		}
		if ch == 'O' {
			j := i
			for j < len(body) && body[j] == 'O' {
				j++
			}
			n := j - i
			if n < 1 || n > 3 {
				return typedInfo{}, false
			}
			if n == 1 {
				if i == 0 || t[len(t)-1] == "KO" {
					t = append(t, "NO")
				} else {
					t = append(t, "NO", "NE")
				}
			} else {
				t = append(t, strings.Repeat("NO", n))
			}
			i = j
			continue
		}
		if ch == 'K' {
			j := i
			for j < len(body) && body[j] == 'K' {
				j++
			}
			ensureNE()
			t = append(t, strings.Repeat("KE", j-i))
			i = j
			continue
		}
		p := codeLetterToToken[ch]
		if p == "" {
			return typedInfo{}, false
		}
		t = append(t, p)
		i++
	}
	if pct {
		t = append(t, "OK")
	}
	t = append(t, "N")
	c := canonicalizeScientificCaps(strings.Join(t, ""))
	strict := Options{RelaxedNanpaLinjanParsing: true}
	if _, e := tokenizeCaps(c, strict); e != nil {
		return typedInfo{}, false
	}
	if year {
		if plus || pct {
			return typedInfo{}, false
		}
		if _, _, ok := decodeYearlessDateCaps(c, strict); !ok {
			return typedInfo{}, false
		}
		return typedInfo{caps: c, kind: "date", dateKind: "yearless"}, true
	}
	return typedInfo{caps: c}, true
}

var abbrevWordToCode = map[string]string{"ijo": "I", "wan": "W", "tu": "T", "seli": "S", "awen": "A", "luka": "L", "utala": "U", "mun": "M", "pipi": "P", "jo": "J"}

func tokenizeTypedCartouche(raw string) ([]string, bool) {
	s := strings.TrimSpace(raw)
	if s == "" {
		return nil, false
	}
	open, close := strings.HasPrefix(s, "["), strings.HasSuffix(s, "]")
	if open != close {
		return nil, false
	}
	if open {
		s = strings.TrimSpace(s[1 : len(s)-1])
	}
	out := []string{}
	for i := 0; i < len(s); {
		if s[i] == ' ' || s[i] == '\t' || s[i] == '\r' || s[i] == '\n' {
			i++
			continue
		}
		if s[i] == ':' {
			out = append(out, ":")
			i++
			continue
		}
		if (s[i] >= 'A' && s[i] <= 'Z') || (s[i] >= 'a' && s[i] <= 'z') {
			j := i + 1
			for j < len(s) && ((s[j] >= 'A' && s[j] <= 'Z') || (s[j] >= 'a' && s[j] <= 'z')) {
				j++
			}
			out = append(out, strings.ToLower(s[i:j]))
			i = j
			continue
		}
		return nil, false
	}
	return out, true
}
func parseTypedCartouche(raw string, opts Options) (typedInfo, bool) {
	if !opts.nanpaColonParsing() {
		return typedInfo{}, false
	}
	t, ok := tokenizeTypedCartouche(raw)
	if !ok || len(t) < 3 {
		return typedInfo{}, false
	}
	head := t[0]
	if head != "nanpa" && head != "tenpo" && head != "suno" && head != "toki" {
		return typedInfo{}, false
	}
	if t[len(t)-1] != "nanpa" {
		return typedInfo{}, false
	}
	colon := len(t) > 1 && t[1] == ":"
	if !colon && head != "suno" {
		return typedInfo{}, false
	}
	body := t[1 : len(t)-1]
	if colon {
		body = t[2 : len(t)-1]
	}
	if len(body) == 0 {
		return typedInfo{}, false
	}
	for _, w := range body {
		if w == "nanpa" || w == "nasin" {
			return typedInfo{}, false
		}
	}
	tryAbbrev := func() (string, bool) {
		i := 0
		positive := false
		if len(body) > 0 && body[0] == "en" {
			positive = true
			i = 1
		}
		var b strings.Builder
		hasDigit := false
		for ; i < len(body); i++ {
			w := body[i]
			if d := abbrevWordToCode[w]; d != "" {
				b.WriteString(d)
				hasDigit = true
				continue
			}
			switch w {
			case "e":
				b.WriteString("EE")
			case "o", "ona":
				b.WriteString("O")
			case "kulupu", "kasi", "kolon", ":":
				b.WriteString("K")
			case "kala":
				b.WriteString("EKO")
			case "kin":
				b.WriteString("OKO")
			case "kipisi":
				if i == len(body)-1 {
					b.WriteString("OK")
				} else {
					return "", false
				}
			default:
				return "", false
			}
		}
		if !hasDigit || b.Len() == 0 {
			return "", false
		}
		p := "#~"
		if positive {
			p += "+"
		}
		info, ok := parseNumberCode(p+b.String(), opts)
		return info.caps, ok
	}
	tryFull := func() (string, bool) {
		letters := strings.Builder{}
		for _, w := range body {
			if w == ":" {
				letters.WriteString("K")
				continue
			}
			if _, ok := wordToCP[w]; !ok {
				return "", false
			}
			letters.WriteByte(strings.ToUpper(w)[0])
		}
		c := "NE" + letters.String() + "N"
		if len(body) > 1 && body[0] == "nena" && body[1] == "en" && strings.HasPrefix(c, "NENE") {
			c = "NENS" + c[4:]
		}
		if strings.HasSuffix(c, "NOKEN") {
			c = c[:len(c)-5] + "OKN"
		}
		tt, e := tokenizeCaps(c, opts)
		return c, e == nil && hasDigitToken(tt)
	}
	prefer := opts.AbbreviateNumericCartouches
	form := ""
	var c string
	if prefer {
		if c, ok = tryAbbrev(); ok {
			form = "abbreviated"
		} else if c, ok = tryFull(); ok {
			form = "full"
		}
	} else {
		if c, ok = tryFull(); ok {
			form = "full"
		} else if c, ok = tryAbbrev(); ok {
			form = "abbreviated"
		}
	}
	if !ok {
		return typedInfo{}, false
	}
	if head == "suno" {
		full := validDate(c, opts)
		_, _, year := decodeYearlessDateCaps(c, opts)
		dom := dayOfMonthCaps(c, opts)
		if !full && !year && !dom && prefer && form == "abbreviated" {
			if fc, fok := tryFull(); fok {
				c = fc
				form = "full"
				full = validDate(c, opts)
				_, _, year = decodeYearlessDateCaps(c, opts)
				dom = dayOfMonthCaps(c, opts)
			}
		}
		if full || year {
			dk := "full"
			if year && !full {
				dk = "yearless"
			}
			return typedInfo{caps: c, head: head, kind: "date", dateKind: dk}, true
		}
		if dom {
			return typedInfo{caps: c, head: head, startGlyph: "suno"}, true
		}
		return typedInfo{}, false
	}
	if head == "tenpo" {
		if !validTime(c, opts) {
			return typedInfo{}, false
		}
		return typedInfo{caps: c, head: head, kind: "time"}, true
	}
	x := typedInfo{caps: c, head: head}
	if head == "toki" {
		x.startGlyph = "toki"
	}
	return x, true
}
