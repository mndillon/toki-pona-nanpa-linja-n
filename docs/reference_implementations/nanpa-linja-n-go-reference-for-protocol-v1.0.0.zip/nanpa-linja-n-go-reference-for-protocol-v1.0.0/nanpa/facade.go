package nanpa

import (
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync"

	productionassets "nanpa-linja-n.com/resources"
)

const (
	ReferenceImplementationVersion = "0.3.0"
	DefaultProductionFontSize      = 56
	DefaultProductionPadding       = 4
)

func DefaultProductionOptions() Options {
	return Options{
		Mode: "uniform", MixedStyle: "short",
		RelaxedNanpaLinjanParsing:   true,
		RelaxedNanpaLinjanRendering: true,
		NanpaColonParsing:           true,
		NanpaColonRendering:         true,
		EnableHexParsing:            true,
		EnableBinaryParsing:         true,
		EnableBinaryRendering:       true,
	}
}

type RGBA struct{ R, G, B, A uint8 }

var Black = RGBA{0, 0, 0, 255}
var Transparent = RGBA{0, 0, 0, 0}

type OutputFormat string

const (
	OutputPNG OutputFormat = "png"
	OutputSVG OutputFormat = "svg"
	OutputPDF OutputFormat = "pdf"
)

type RenderOptions struct {
	Font                           string
	FontSize                       int
	Abbreviate                     bool
	PreserveNumericCartoucheBreaks bool
	OuterPadding                   int
	Foreground                     RGBA
	Background                     RGBA
	ParserOptions                  Options
}

func DefaultRenderOptions() RenderOptions {
	return RenderOptions{
		Font:                           DefaultProductionFontKey,
		FontSize:                       DefaultProductionFontSize,
		PreserveNumericCartoucheBreaks: true,
		OuterPadding:                   DefaultProductionPadding,
		Foreground:                     Black,
		Background:                     Transparent,
		ParserOptions:                  DefaultProductionOptions(),
	}
}

type RenderPlan struct {
	Input                          string
	Parsed                         *ParseResult
	Font                           ProductionFontInfo
	CanonicalCodepoints            []int
	RenderText                     string
	RenderCodepoints               []int
	RenderAdapterID                string
	LegacyASCII                    bool
	FontSize                       int
	OuterPadding                   int
	OpenTypeFeatures               []string
	Abbreviated                    bool
	PreserveNumericCartoucheBreaks bool
}

type RenderResult struct {
	Bytes  []byte
	Width  int
	Height int
	Format OutputFormat
	Plan   RenderPlan
}

func (r RenderResult) Save(path string) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil && filepath.Dir(path) != "." {
		return err
	}
	return os.WriteFile(path, r.Bytes, 0o644)
}

type NanpaLinjaN struct {
	registry      *ProductionFontRegistry
	tempDir       string
	materialized  map[string]string
	closed        bool
	fullAdapterMu sync.RWMutex
	fullAdapters  map[string]RenderAdapter
}

func CreateNanpaLinjaN() (*NanpaLinjaN, error) {
	registry, err := loadProductionFontRegistry()
	if err != nil {
		return nil, err
	}
	tempDir, err := os.MkdirTemp("", "nanpa_linja_n_go_fonts_")
	if err != nil {
		return nil, fmt.Errorf("create production font temp dir: %w", err)
	}
	n := &NanpaLinjaN{registry: registry, tempDir: tempDir, materialized: map[string]string{}, fullAdapters: map[string]RenderAdapter{}}
	runtime.SetFinalizer(n, func(x *NanpaLinjaN) { _ = x.Close() })
	return n, nil
}

func (n *NanpaLinjaN) Close() error {
	if n == nil || n.closed {
		return nil
	}
	n.closed = true
	runtime.SetFinalizer(n, nil)
	return os.RemoveAll(n.tempDir)
}

func (n *NanpaLinjaN) ListFonts() []ProductionFontInfo { return n.registry.List() }
func (n *NanpaLinjaN) GetFontInfo(font string) (ProductionFontInfo, error) {
	return n.registry.Get(font)
}

func (n *NanpaLinjaN) Parse(input string, opts Options) (*ParseResult, error) {
	return ParseNumber(input, opts)
}

func normalizeRenderOptions(opts RenderOptions) RenderOptions {
	if strings.TrimSpace(opts.Font) == "" {
		opts.Font = DefaultProductionFontKey
	}
	if opts.FontSize == 0 {
		opts.FontSize = DefaultProductionFontSize
	}
	if opts.FontSize < 8 {
		opts.FontSize = 8
	}
	if opts.OuterPadding < 0 {
		opts.OuterPadding = 0
	}
	// A zero-valued foreground is ambiguous in Go. Treat the all-zero struct as the
	// facade default black rather than invisible output. Transparent backgrounds remain zero.
	if opts.Foreground == (RGBA{}) {
		opts.Foreground = Black
	}
	// Preserve existing callers that construct RenderOptions{}.
	if opts.ParserOptions == (Options{}) {
		opts.ParserOptions = DefaultProductionOptions()
	}
	return opts
}

func resolveRenderOptions(options []RenderOptions) RenderOptions {
	if len(options) == 0 {
		return DefaultRenderOptions()
	}
	return normalizeRenderOptions(options[0])
}

func (n *NanpaLinjaN) BuildRenderPlan(input string, options ...RenderOptions) (RenderPlan, error) {
	opts := resolveRenderOptions(options)
	font, err := n.registry.Get(opts.Font)
	if err != nil {
		return RenderPlan{}, err
	}
	parseOpts := opts.ParserOptions
	parseOpts.AbbreviateNumericCartouches = false
	parseOpts.PreserveNumericCartoucheBreaksInAbbreviation = opts.PreserveNumericCartoucheBreaks
	parsed, err := ParseNumber(input, parseOpts)
	if err != nil {
		return RenderPlan{}, err
	}
	full := productionCanonicalCodepoints(parsed)
	if len(full) < 3 || full[0] != CartoucheStart || full[len(full)-1] != CartoucheEnd {
		return RenderPlan{}, fmt.Errorf("parsed value did not produce a complete canonical numeric cartouche")
	}
	active := full
	if opts.Abbreviate {
		active, err = abbreviateProductionCartouche(full, opts.PreserveNumericCartoucheBreaks)
		if err != nil {
			return RenderPlan{}, err
		}
	}
	text, legacy, err := adaptProductionCartouche(active, font.RenderAdapterID)
	if err != nil {
		return RenderPlan{}, err
	}
	renderCP := make([]int, 0, len([]rune(text)))
	for _, r := range text {
		renderCP = append(renderCP, int(r))
	}
	return RenderPlan{
		Input: input, Parsed: parsed, Font: font, CanonicalCodepoints: active,
		RenderText: text, RenderCodepoints: renderCP, RenderAdapterID: font.RenderAdapterID,
		LegacyASCII: legacy, FontSize: opts.FontSize, OuterPadding: opts.OuterPadding,
		OpenTypeFeatures: productionOpenTypeFeatures(opts.FontSize), Abbreviated: opts.Abbreviate,
		PreserveNumericCartoucheBreaks: opts.PreserveNumericCartoucheBreaks,
	}, nil
}

func productionCanonicalCodepoints(parsed *ParseResult) []int {
	out := append([]int(nil), parsed.Codepoints...)
	// Core-v1 preserves the historical parser representation for dates, while
	// the Production Rendering Profile renders date separators with kasi.
	if parsed.IsDate || (parsed.SemanticStartGlyph != nil && *parsed.SemanticStartGlyph == "suno") {
		for i, cp := range out {
			if cp == 0xF191F { // kulupu
				out[i] = 0xF1917 // kasi
			}
		}
	}
	// The production telephone form is [toki : nena en ... nanpa]. The frozen
	// Core parser retains nena e internally, so normalize only this render head.
	if len(out) >= 6 && out[0] == CartoucheStart && out[1] == cpToki && out[2] == cpColon && out[3] == cpNena && out[4] == cpE {
		out[4] = cpEn
	}
	return out
}

func (n *NanpaLinjaN) materializeCompanion(font ProductionFontInfo) (string, error) {
	if p, ok := n.materialized[font.CompanionFilename]; ok {
		return p, nil
	}
	if n.closed {
		return "", fmt.Errorf("NanpaLinjaN facade is closed")
	}
	b, err := productionassets.ReadFont(font.CompanionFilename)
	if err != nil {
		return "", err
	}
	path := filepath.Join(n.tempDir, font.CompanionFilename)
	if err := os.WriteFile(path, b, 0o600); err != nil {
		return "", err
	}
	n.materialized[font.CompanionFilename] = path
	return path, nil
}

func (n *NanpaLinjaN) Render(input string, format OutputFormat, options ...RenderOptions) (RenderResult, error) {
	opts := resolveRenderOptions(options)
	plan, err := n.BuildRenderPlan(input, opts)
	if err != nil {
		return RenderResult{}, err
	}
	fontPath, err := n.materializeCompanion(plan.Font)
	if err != nil {
		return RenderResult{}, err
	}
	bytes, w, h, err := nativeRenderProductionText(plan.RenderText, plan.Font.NativeCompanionFamily, fontPath,
		plan.FontSize, plan.OpenTypeFeatures, plan.OuterPadding, format,
		opts.Foreground, opts.Background)
	if err != nil {
		return RenderResult{}, err
	}
	return RenderResult{Bytes: bytes, Width: w, Height: h, Format: format, Plan: plan}, nil
}
func (n *NanpaLinjaN) RenderToPNG(input string, options ...RenderOptions) ([]byte, error) {
	r, e := n.Render(input, OutputPNG, options...)
	return r.Bytes, e
}
func (n *NanpaLinjaN) RenderToSVG(input string, options ...RenderOptions) ([]byte, error) {
	r, e := n.Render(input, OutputSVG, options...)
	return r.Bytes, e
}
func (n *NanpaLinjaN) RenderToPDF(input string, options ...RenderOptions) ([]byte, error) {
	r, e := n.Render(input, OutputPDF, options...)
	return r.Bytes, e
}

const (
	cpNanpa = 0xF193D
	cpNasa  = 0xF193E
	cpNoka  = 0xF1943
	cpTenpo = 0xF196B
	cpSuno  = 0xF1964
	cpToki  = 0xF196C
	cpColon = 0xF199D
	cpNena  = 0xF1940
	cpE     = 0xF1909
	cpEn    = 0xF190A
	cpOpen  = 0xF1947
	cpAla   = 0xF1902
	cpIke   = 0xF190D
	cpUta   = 0xF1970
)

func isProductionHead(cp int) bool {
	return cp == cpNanpa || cp == cpNasa || cp == cpNoka || cp == cpTenpo || cp == cpSuno || cp == cpToki
}
func isProductionDrop(cp int) bool {
	return cp == cpNanpa || cp == cpEn || cp == cpE || cp == cpNena || cp == cpOpen || cp == cpAla || cp == cpIke || cp == cpUta
}

func abbreviateProductionCartouche(full []int, preserve bool) ([]int, error) {
	if len(full) < 3 || full[0] != CartoucheStart || full[len(full)-1] != CartoucheEnd {
		return nil, fmt.Errorf("cannot abbreviate incomplete cartouche")
	}
	chars := full[1 : len(full)-1]
	if len(chars) == 0 {
		return append([]int(nil), full...), nil
	}
	traditionalFullPositive := len(chars) >= 4 && isProductionHead(chars[0]) && chars[1] == cpE && chars[2] == cpNena && chars[3] == cpEn
	colonFullPositive := len(chars) >= 4 && isProductionHead(chars[0]) && chars[1] == cpColon && chars[2] == cpNena && chars[3] == cpEn
	fullPositive := traditionalFullPositive || colonFullPositive
	fullScaffoldingAfterOpening := false
	if len(chars) > 3 {
		for _, cp := range chars[2 : len(chars)-1] {
			if cp == cpE || isProductionDrop(cp) {
				fullScaffoldingAfterOpening = true
				break
			}
		}
	}
	alreadyAbbrPositive := !fullPositive && !fullScaffoldingAfterOpening && len(chars) >= 3 && isProductionHead(chars[0]) && chars[1] == cpEn
	alreadyAbbrColonPositive := !fullPositive && !fullScaffoldingAfterOpening && len(chars) >= 4 && isProductionHead(chars[0]) && chars[1] == cpColon && chars[2] == cpEn
	outInner := make([]int, 0, len(chars))
	keptHead := false
	for i := 0; i < len(chars); {
		ch := chars[i]
		finalNanpa := ch == cpNanpa && i == len(chars)-1
		if !keptHead {
			outInner = append(outInner, ch)
			if (i == 0 && isProductionHead(ch)) || ch == cpNanpa {
				keptHead = true
			}
			i++
			continue
		}
		if finalNanpa {
			outInner = append(outInner, ch)
			i++
			continue
		}
		if traditionalFullPositive && i == 1 {
			outInner = append(outInner, cpEn)
			i = 4
			continue
		}
		if colonFullPositive && i == 2 {
			outInner = append(outInner, cpEn)
			i = 4
			continue
		}
		if alreadyAbbrPositive && i == 1 {
			outInner = append(outInner, cpEn)
			i++
			continue
		}
		if alreadyAbbrColonPositive && i == 2 {
			outInner = append(outInner, cpEn)
			i++
			continue
		}
		if preserve && ch == cpNena && i+3 < len(chars) && (chars[i+1] == cpE || chars[i+1] == cpEn) && chars[i+2] == cpNena && (chars[i+3] == cpE || chars[i+3] == cpEn) {
			outInner = append(outInner, cpE)
			i += 4
			continue
		}
		if !isProductionDrop(ch) {
			outInner = append(outInner, ch)
		}
		i++
	}
	out := make([]int, 0, len(outInner)+2)
	out = append(out, CartoucheStart)
	out = append(out, outInner...)
	out = append(out, CartoucheEnd)
	if len(out) >= len(full) {
		return nil, fmt.Errorf("abbreviated cartouche is not shorter than full cartouche")
	}
	return out, nil
}
