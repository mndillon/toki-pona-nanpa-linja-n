package nanpa

import (
	"reflect"
	"testing"
)

func fullPlanForSyntax(t *testing.T, n *NanpaLinjaN, input string, mode string) FullRenderPlan {
	t.Helper()
	o := DefaultFullRenderOptions()
	if mode != "" {
		o.Parser.Mode = mode
		o.Parser.RendererMode = mode
	}
	p, err := n.BuildFullRenderPlan(input, o)
	if err != nil {
		t.Fatalf("%q: %v", input, err)
	}
	return p
}

func nonEmptyRuns(p FullRenderPlan) []FullRenderRun { return p.Runs }

func requireSingleCanonical(t *testing.T, n *NanpaLinjaN, input, mode string, want []int) FullRenderRun {
	t.Helper()
	p := fullPlanForSyntax(t, n, input, mode)
	if len(p.Runs) != 1 {
		t.Fatalf("%q: got %d runs: %#v", input, len(p.Runs), p.Runs)
	}
	if !reflect.DeepEqual(p.Runs[0].CanonicalCodepoints, want) {
		t.Fatalf("%q: canonical=%#v want=%#v", input, p.Runs[0].CanonicalCodepoints, want)
	}
	return p.Runs[0]
}

func TestCanonicalFullRendererSyntaxBranches(t *testing.T) {
	if !fullNativeAvailable() {
		t.Skip("full native renderer requires Linux+cgo")
	}
	n, err := CreateNanpaLinjaN()
	if err != nil {
		t.Fatal(err)
	}
	defer n.Close()

	t.Run("extended-compounds", func(t *testing.T) {
		mode := "sitelen-pona-ascii-extended"
		requireSingleCanonical(t, n, "toki&pona", mode, []int{wordToCP["toki"], 0x200D, wordToCP["pona"]})
		requireSingleCanonical(t, n, "toki-pona", mode, []int{wordToCP["toki"], StackJoinerCodepoint, wordToCP["pona"]})
		requireSingleCanonical(t, n, "toki+pona", mode, []int{wordToCP["toki"], NestJoinerCodepoint, wordToCP["pona"]})
		requireSingleCanonical(t, n, "luka&luka&luka&luka", mode, []int{wordToCP["luka"], 0x200D, wordToCP["luka"], 0x200D, wordToCP["luka"], 0x200D, wordToCP["luka"]})
	})

	t.Run("standard-core", func(t *testing.T) {
		mode := "standard-sitelen-pona-ascii-core"
		requireSingleCanonical(t, n, "toki&pona", mode, []int{wordToCP["toki"], 0x200D, wordToCP["pona"]})
		requireSingleCanonical(t, n, "pi(telo lete)", mode, []int{wordToCP["pi"], 0xF1997, wordToCP["telo"], wordToCP["lete"], 0xF1998})
		r := requireSingleCanonical(t, n, "|", mode, []int{0x3000})
		if r.SourceText != "|" {
			t.Fatalf("standard | source=%q", r.SourceText)
		}
	})

	t.Run("extended-long-glyphs", func(t *testing.T) {
		mode := "sitelen-pona-ascii-extended"
		requireSingleCanonical(t, n, "pi(telo lete)", mode, []int{wordToCP["pi"], 0xF1997, wordToCP["telo"], wordToCP["lete"], 0xF1998})
		requireSingleCanonical(t, n, "{telo}lon", mode, []int{0xF199A, wordToCP["telo"], 0xF199B, wordToCP["lon"]})
		requireSingleCanonical(t, n, "{telo}lon(lete)", mode, []int{0xF199A, wordToCP["telo"], 0xF199B, wordToCP["lon"], 0xF1997, wordToCP["lete"], 0xF1998})
		requireSingleCanonical(t, n, "pi+telo", mode, []int{wordToCP["pi"], 0xF1997, wordToCP["telo"], 0xF1998})
		requireSingleCanonical(t, n, "pi++telo lete", mode, []int{wordToCP["pi"], 0xF1997, wordToCP["telo"], wordToCP["lete"], 0xF1998})
		requireSingleCanonical(t, n, "pi+__telo__lete", mode, []int{wordToCP["pi"], 0xF1997, wordToCP["telo"], wordToCP["lete"], 0xF1998})
	})

	t.Run("literal-helpers-and-alternates", func(t *testing.T) {
		mode := "sitelen-pona-ascii-extended"
		requireSingleCanonical(t, n, "te", mode, []int{0x300C})
		requireSingleCanonical(t, n, "to", mode, []int{0x300D})
		p := fullPlanForSyntax(t, n, "zz", mode)
		if len(p.Runs) != 1 || p.Runs[0].RenderText != "\u3000" || p.Runs[0].SourceText != "zz" {
			t.Fatalf("zz: %#v", p.Runs)
		}
		cases := map[string]int{"ni01": 0xF1941, "ni02": 0xF198B, "ni03": 0xF198A, "ni04": 0xF1989, "sewi01": 0xF195A, "sewi02": 0xF198C, "·": 0xF199C}
		for input, cp := range cases {
			requireSingleCanonical(t, n, input, mode, []int{cp})
		}
	})

	t.Run("early-aliases", func(t *testing.T) {
		mode := "sitelen-pona-ascii-extended"
		p := fullPlanForSyntax(t, n, "toki'zw-joiner'pona", mode)
		if p.AST.NormalizedInput != "toki&pona" {
			t.Fatalf("normalized=%q", p.AST.NormalizedInput)
		}
		if len(p.Runs) != 1 || !reflect.DeepEqual(p.Runs[0].CanonicalCodepoints, []int{wordToCP["toki"], 0x200D, wordToCP["pona"]}) {
			t.Fatalf("alias runs=%#v", p.Runs)
		}
		p = fullPlanForSyntax(t, n, "'left-bracket' jan 'right-bracket'", mode)
		if len(p.Runs) != 3 || p.Runs[0].CanonicalCodepoints[0] != 0x300C || p.Runs[2].CanonicalCodepoints[0] != 0x300D {
			t.Fatalf("corner aliases=%#v", p.Runs)
		}
	})

	t.Run("mixed-raw-ucsur", func(t *testing.T) {
		mode := "sitelen-pona-ascii-extended"
		p := fullPlanForSyntax(t, n, "jan U+F1954 toki", mode)
		if len(p.Runs) != 3 {
			t.Fatalf("raw runs=%#v", p.Runs)
		}
		want := [][]int{{wordToCP["jan"]}, {wordToCP["pona"]}, {wordToCP["toki"]}}
		for i := range want {
			if !reflect.DeepEqual(p.Runs[i].CanonicalCodepoints, want[i]) {
				t.Fatalf("raw %d=%#v", i, p.Runs[i])
			}
		}
	})

	t.Run("cartouche-syntax", func(t *testing.T) {
		mode := "sitelen-pona-ascii-extended"
		r := requireSingleCanonical(t, n, "[toki&pona]", mode, []int{wordToCP["toki"], 0x200D, wordToCP["pona"]})
		if r.FontRole != "cartouche" {
			t.Fatalf("compound cartouche role=%q", r.FontRole)
		}
		r = requireSingleCanonical(t, n, "[_jan_pona]", mode, []int{wordToCP["jan"], wordToCP["pona"]})
		if r.FontRole != "cartouche" {
			t.Fatalf("legacy cartouche role=%q", r.FontRole)
		}
		r = requireSingleCanonical(t, n, "[\"HELLO\"]", mode, []int{'H', 0xF1992, 'E', 0xF1992, 'L', 0xF1992, 'L', 0xF1992, 'O', 0xF1992})
		if r.FontRole != "cartouche" {
			t.Fatalf("literal cartouche role=%q", r.FontRole)
		}
	})
}

func TestCanonicalProductionWordAdaptersActuallyApply(t *testing.T) {
	if !fullNativeAvailable() {
		t.Skip("full native renderer requires Linux+cgo")
	}
	n, err := CreateNanpaLinjaN()
	if err != nil {
		t.Fatal(err)
	}
	defer n.Close()

	for _, font := range []string{"linjaPona", "linjaSike"} {
		t.Run(font+"-word", func(t *testing.T) {
			o := DefaultFullRenderOptions()
			o.Font = font
			p, err := n.BuildFullRenderPlan("jan", o)
			if err != nil {
				t.Fatal(err)
			}
			if len(p.Runs) != 1 {
				t.Fatalf("runs=%#v", p.Runs)
			}
			if p.Runs[0].RenderText != "jan" {
				t.Fatalf("render=%q cps=%#v", p.Runs[0].RenderText, p.Runs[0].RenderCodepoints)
			}
			if reflect.DeepEqual(p.Runs[0].RenderCodepoints, p.Runs[0].CanonicalCodepoints) {
				t.Fatalf("adapter ID present but transform did not run")
			}
		})
		t.Run(font+"-compound", func(t *testing.T) {
			o := DefaultFullRenderOptions()
			o.Font = font
			p, err := n.BuildFullRenderPlan("toki&pona", o)
			if err != nil {
				t.Fatal(err)
			}
			if len(p.Runs) != 1 || p.Runs[0].RenderText != "toki-pona" {
				t.Fatalf("runs=%#v", p.Runs)
			}
		})
	}

	t.Run("raw-ucsur-bypasses-adapter", func(t *testing.T) {
		o := DefaultFullRenderOptions()
		o.Font = "linjaPona"
		p, err := n.BuildFullRenderPlan("U+F1911", o)
		if err != nil {
			t.Fatal(err)
		}
		if len(p.Runs) != 1 || p.Runs[0].RenderText != string(rune(wordToCP["jan"])) {
			t.Fatalf("raw run=%#v", p.Runs)
		}
	})
}
