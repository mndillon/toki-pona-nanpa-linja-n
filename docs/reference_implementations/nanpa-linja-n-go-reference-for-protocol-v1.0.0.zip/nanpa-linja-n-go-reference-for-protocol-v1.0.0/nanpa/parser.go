package nanpa

import (
	"fmt"
	"strings"
)

func boolp(v bool) *bool    { return &v }
func intp(v int) *int       { return &v }
func strp(v string) *string { return &v }

func parserWordsFromCps(cps []int) []string {
	out := make([]string, 0, len(cps))
	for _, cp := range cps {
		if cp == wordToCP[":"] {
			out = append(out, ":")
			continue
		}
		if w, ok := cpToWord[cp]; ok {
			out = append(out, w)
		}
	}
	return out
}

func wordsToCpsMust(words []string) []int {
	cps, _ := tpWordsToCodepoints(words)
	return cps
}

func makeHexBinaryResult(input string, s semantic, opts Options) (*ParseResult, error) {
	isHex := s.kind == "hex"
	var full, abbr []string
	var proper, unique, digits string
	base := 2
	if isHex {
		full = hexWords(s, opts, false)
		abbr = hexWords(s, opts, true)
		proper = hexProper(s, opts)
		unique = semanticCanonical(s, "#")
		digits = s.digits
		base = 16
	} else {
		full = binaryWords(s, opts, false)
		abbr = binaryWords(s, opts, true)
		proper = binaryProper(s, opts)
		unique = semanticCanonical(s, "0b")
		digits = s.digits
	}
	words := full
	if opts.AbbreviateNumericCartouches {
		words = abbr
	}
	inner := wordsToCpsMust(words)
	abbrevCps := wordsToCpsMust(abbr)
	codepoints := withMarkers(inner)
	kind := s.kind
	r := &ParseResult{
		Input: input, Kind: &kind, NumberBase: intp(base), IsHex: boolp(isHex), IsBinary: boolp(!isHex),
		Caps: nil, ProperName: proper, UniqueCode: unique, DisplayValue: unique,
		UcsurCodepoints: inner, AbbreviatedUcsurCodepoints: abbrevCps,
		HexCodepoints: codepointsToHex(inner), HexWithCartouche: codepointsToHex(codepoints),
		TpWords: full, AbbreviatedWords: abbr, Words: words,
		IsTime: false, IsDate: false, IsTimeLike: false,
		InnerCodepoints: inner, Codepoints: codepoints, NumericMode: opts.normalizedMode(),
	}
	if isHex {
		r.HexDigits = digits
		r.HexParts = s.parts
	} else {
		r.BinaryDigits = digits
		r.BinaryParts = s.parts
	}
	return r, nil
}

func parseDecimalInput(input string, opts Options) (typedInfo, string, error) {
	s := strings.TrimSpace(input)
	if s == "" {
		return typedInfo{}, "", fmt.Errorf("empty")
	}

	// Public typed cartouches are deliberately narrower than renderer bracket syntax.
	if strings.HasPrefix(s, "[") || strings.HasSuffix(s, "]") {
		if t, ok := parseTypedCartouche(s, opts); ok {
			return t, t.caps, nil
		}
		return typedInfo{}, "", fmt.Errorf("invalid typed cartouche")
	}

	if t, ok := typedNumericProper(s, opts); ok {
		return t, t.caps, nil
	}
	if t, ok := typedDateTimeProper(s, opts); ok {
		return t, t.caps, nil
	}

	// Exact structured date/time spellings have precedence over loose numeric fallback.
	if c, ok := dateStringToCaps(s, opts); ok {
		p, _ := parseDateParts(s)
		dk := "full"
		if p.yearless {
			dk = "yearless"
		}
		t := typedInfo{caps: c, kind: "date", dateKind: dk}
		return t, c, nil
	}
	if c, ok := timeStringToCaps(s, opts); ok {
		t := typedInfo{caps: c, kind: "time"}
		return t, c, nil
	}

	if c, t, ok := properNameToCaps(s, opts); ok {
		return t, c, nil
	}
	if t, ok := parseNumberCode(s, opts); ok {
		return t, t.caps, nil
	}

	c, err := DecimalStringToCaps(s, opts)
	if err != nil {
		return typedInfo{}, "", err
	}
	return typedInfo{caps: c}, c, nil
}

func ParseNumber(input any, opts Options) (*ParseResult, error) {
	s, ok := input.(string)
	if !ok {
		return nil, fmt.Errorf("input must be string")
	}

	if opts.EnableBinaryParsing || opts.EnableBinaryRendering {
		if sem, ok := parseCompleteBinary(s, opts); ok {
			return makeHexBinaryResult(s, sem, opts)
		}
	}
	if opts.EnableHexParsing {
		if sem, ok := parseCompleteHex(s, opts); ok {
			return makeHexBinaryResult(s, sem, opts)
		}
	}

	ti, caps, err := parseDecimalInput(s, opts)
	if err != nil {
		return nil, err
	}
	caps = canonicalizeScientificCaps(caps)
	isTime := ti.kind == "time"
	isDate := ti.kind == "date"
	if isTime {
		caps = normalizeTimeNegativeZeroCaps(caps, opts)
	}

	// Typed semantic forms decide date/time classification. For ordinary legacy/proper/caps
	// inputs, retain the reference parser's inference when the caps themselves are unambiguous.
	if ti.kind == "" {
		if validDate(caps, opts) {
			isDate = true
		}
		if validTime(caps, opts) {
			isTime = true
		}
		// Ordinary decimal 1230-like caps must not be reclassified solely by shape; only
		// explicitly structured source forms/proper names provide semantic classification.
		// The source grammars above set kind where that classification is intended.
		isDate, isTime = false, false
	}

	toks, err := tokenizeCaps(caps, opts)
	if err != nil || !hasDigitToken(toks) {
		return nil, fmt.Errorf("invalid numeric caps")
	}
	semanticKind := ti.kind
	semanticStart := ti.startGlyph
	inner, err := capsToInnerCodepoints(caps, opts, isTime, semanticKind, semanticStart)
	if err != nil {
		return nil, err
	}
	words := parserWordsFromCps(inner)

	renderCaps, err := capsForOutputRendering(caps, opts)
	if err != nil {
		return nil, err
	}
	rawProper, err := splitCapsRaw(renderCaps)
	if err != nil {
		return nil, err
	}
	ro := opts
	ro.RelaxedNanpaLinjanParsing = opts.RelaxedNanpaLinjanParsing || opts.RelaxedNanpaLinjanRendering
	rawProper = splitFinalHundredIninWords(rawProper, ro)
	proper := titleWords(rawProper)
	if opts.NanpaColonRendering {
		proper = nanpaColonProperNameFromLegacy(rawProper, semanticStart)
	}

	display, err := DecodeCaps(caps)
	if err != nil {
		return nil, err
	}
	if ti.dateKind == "yearless" {
		if mm, dd, ok := decodeYearlessDateCaps(caps, opts); ok {
			display = "--" + mm + "-" + dd
		}
	}
	var nasinNanpaPonaWords []string
	if opts.NasinNanpaPona {
		nasinNanpaPonaWords = tryPlainDecimalToNasinNanpaPonaWords(display)
	}
	unique := capsToUniqueCode(caps, opts)
	if ti.dateKind == "yearless" {
		unique = "#~k" + strings.TrimPrefix(unique, "#~")
	}
	cps := withMarkers(inner)
	var abbreviatedWords []string
	var abbreviatedUcsurCodepoints []int
	if abbreviated, abbrevErr := abbreviateProductionCartouche(cps, opts.PreserveNumericCartoucheBreaksInAbbreviation); abbrevErr == nil && len(abbreviated) >= 2 {
		abbreviatedUcsurCodepoints = append([]int(nil), abbreviated[1:len(abbreviated)-1]...)
		abbreviatedWords = parserWordsFromCps(abbreviatedUcsurCodepoints)
	}
	var sk, ss *string
	if semanticKind != "" {
		sk = strp(semanticKind)
	}
	if semanticStart != "" {
		ss = strp(semanticStart)
	}
	return &ParseResult{
		Input: s, Caps: &caps, ProperName: proper, UniqueCode: unique, DisplayValue: display,
		UcsurCodepoints: inner, AbbreviatedUcsurCodepoints: abbreviatedUcsurCodepoints, HexCodepoints: codepointsToHex(inner), HexWithCartouche: codepointsToHex(cps),
		TpWords: words, AbbreviatedWords: abbreviatedWords, Words: words, NasinNanpaPonaWords: nasinNanpaPonaWords, IsTime: isTime, IsDate: isDate, SemanticKind: sk, SemanticStartGlyph: ss,
		IsTimeLike: isTime, InnerCodepoints: inner, Codepoints: cps, NumericMode: opts.normalizedMode(),
	}, nil
}

// Frozen Core-v1 public helpers.
func EncodeDecimal(input string, opts Options) (string, error) {
	return DecimalStringToCaps(input, opts)
}
func DecimalToUcsurCodepoints(input string, opts Options) ([]int, error) {
	r, e := ParseNumber(input, opts)
	if e != nil {
		return nil, e
	}
	return r.InnerCodepoints, nil
}
func ProperNameToUcsurCodepoints(input string, opts Options) ([]int, error) {
	r, e := ParseNumber(input, opts)
	if e != nil {
		return nil, e
	}
	return r.InnerCodepoints, nil
}
func SplitCapsToProperName(caps string, titleCase bool, opts Options) (string, error) {
	return splitCapsToProperName(caps, titleCase, opts)
}
func CapsToUniqueCode(caps string, opts Options) string      { return capsToUniqueCode(caps, opts) }
func UcsurCodepointsToTpWords(cps []int) []string            { return codepointsToWords(cps) }
func CodepointsToWords(cps []int) []string                   { return codepointsToWords(cps) }
func TpWordsToText(words []string) string                    { return strings.Join(words, " ") }
func TpWordsToUcsurCodepoints(words []string) ([]int, error) { return tpWordsToCodepoints(words) }
func CodepointsToHex(cps []int) string                       { return codepointsToHex(cps) }
func CodepointsToHexWithCartouche(cps []int) string          { return codepointsToHex(withMarkers(cps)) }
func WithCartoucheMarkers(cps []int) []int                   { return withMarkers(cps) }
func StripCartoucheMarkers(cps []int) []int {
	if len(cps) >= 2 && cps[0] == CartoucheStart && cps[len(cps)-1] == CartoucheEnd {
		return append([]int{}, cps[1:len(cps)-1]...)
	}
	return append([]int{}, cps...)
}
func IsValidCaps(caps string, opts Options) bool {
	t, e := tokenizeCaps(caps, opts)
	return e == nil && hasDigitToken(t)
}
func IsValidProperName(s string, opts Options) bool         { _, _, ok := properNameToCaps(s, opts); return ok }
func IsValidTimeOrDate(c string, opts Options) bool         { return validTimeOrDate(c, opts) }
func IsValidTime(c string, opts Options) bool               { return validTime(c, opts) }
func IsValidDate(c string, opts Options) bool               { return validDate(c, opts) }
func TokenizeCaps(c string, opts Options) ([]string, error) { return tokenizeCaps(c, opts) }
func CapsTokensToTpWords(tokens []string, opts Options) ([]string, error) {
	return capsTokensToTpWords(tokens, opts, "", "")
}
func CapsToWords(c string, opts Options) ([]string, error) {
	c = canonicalizeScientificCaps(c)
	isDate := validDate(c, opts)
	isTime := !isDate && validTime(c, opts)
	if isTime {
		c = normalizeTimeNegativeZeroCaps(c, opts)
	}
	t, e := tokenizeCaps(c, opts)
	if e != nil {
		return nil, e
	}
	hasPct := false
	base := make([]string, 0, len(t))
	for _, q := range t {
		if q == "OK" {
			hasPct = true
		} else {
			base = append(base, q)
		}
	}
	kind := ""
	if isDate {
		kind = "date"
	} else if isTime {
		kind = "time"
	}
	w, e := capsTokensToTpWords(base, opts, kind, "")
	if e != nil {
		return nil, e
	}
	if isDate || isTime {
		w = replaceTimeSeparators(w, opts.normalizedMode())
	}
	if hasPct {
		suffix := []string{"nena", "open", "kipisi", "e"}
		if opts.normalizedMode() == "traditional" {
			suffix = []string{"noka", "open", "kipisi", "e"}
		}
		idx := -1
		for i := len(w) - 1; i >= 0; i-- {
			if w[i] == "nanpa" {
				idx = i
				break
			}
		}
		if idx >= 0 {
			w = append(w[:idx], append(suffix, w[idx:]...)...)
		} else {
			w = append(w, suffix...)
		}
	}
	return w, nil
}
func CapsToCodepoints(c string, opts Options) (CapsCodepointsResult, error) {
	isDate := validDate(c, opts)
	isTime := !isDate && validTime(c, opts)
	kind := ""
	if isDate {
		kind = "date"
	} else if isTime {
		kind = "time"
	}
	inner, e := capsToInnerCodepoints(c, opts, isDate || isTime, kind, "")
	if e != nil {
		return CapsCodepointsResult{}, e
	}
	w := parserWordsFromCps(inner)
	return CapsCodepointsResult{InnerCodepoints: inner, Codepoints: withMarkers(inner), Words: w, NumericMode: opts.normalizedMode(), IsTimeLike: isDate || isTime}, nil
}
func ParseIdentifier(s string, opts Options) (IdentifierResult, error) {
	r, e := ParseNumber(s, opts)
	if e != nil {
		return IdentifierResult{}, e
	}
	return IdentifierResult{Input: s, InnerCodepoints: r.InnerCodepoints, Codepoints: r.Codepoints, Words: r.Words, NumericMode: r.NumericMode}, nil
}
func NormalizeTpWord(s string) string { return normalizeTpWord(s) }
func GetSmallCodepointsSet() []int {
	return []int{wordToCP["nanpa"], wordToCP["nena"], wordToCP["ni"], wordToCP["nasa"], wordToCP["e"], wordToCP["esun"], wordToCP["en"]}
}
func GetQuarterCodepointsSet() []int  { return append(GetSmallCodepointsSet(), wordToCP["open"]) }
func GetOneThirdCodepointsSet() []int { return []int{wordToCP["kasi"]} }
func GetTwoThirdsCodepointsSet() []int {
	return []int{wordToCP["ona"], wordToCP["o"], wordToCP["kulupu"], wordToCP["kin"]}
}
func GetHalfCodepointsSet() []int           { return []int{wordToCP["kala"]} }
func IsAllowedTpUcsurCodepoint(cp int) bool { _, ok := cpToWord[cp]; return ok }

var tpWordInputAliases = map[string]string{"ni01": "ni", "ni02": "ni>", "ni03": "ni^", "ni04": "ni<", "sewi01": "sewi", "sewi02": "sewi^"}

func ParseTpWordsToCodepoints(input string) ([]int, error) {
	raw := strings.TrimSpace(input)
	if raw == "" {
		return []int{}, nil
	}
	normalized := strings.NewReplacer("·", " · ", ":", " : ").Replace(raw)
	fields := strings.Fields(normalized)
	cps := make([]int, 0, len(fields))
	for _, part := range fields {
		key := strings.ToLower(strings.TrimSpace(part))
		if a := tpWordInputAliases[key]; a != "" {
			key = a
		}
		cp, ok := wordToCP[key]
		if !ok {
			return nil, fmt.Errorf("invalid Toki Pona word %q", part)
		}
		if !IsAllowedTpUcsurCodepoint(cp) && cp != CartoucheStart && cp != CartoucheEnd {
			return nil, fmt.Errorf("disallowed code point U+%X", cp)
		}
		cps = append(cps, cp)
	}
	return StripCartoucheMarkers(cps), nil
}

func ParseHexCodepoints(input string) ([]int, error) {
	raw := strings.TrimSpace(input)
	if raw == "" {
		return []int{}, nil
	}
	fields := strings.Fields(raw)
	out := []int{}
	for _, f := range fields {
		x := f
		if strings.HasPrefix(strings.ToUpper(x), "U+") {
			x = x[2:]
		}
		if x == "" || len(x) > 6 {
			return nil, fmt.Errorf("invalid codepoint %q", f)
		}
		var cp int
		for _, r := range x {
			cp <<= 4
			switch {
			case r >= '0' && r <= '9':
				cp += int(r - '0')
			case r >= 'a' && r <= 'f':
				cp += int(r-'a') + 10
			case r >= 'A' && r <= 'F':
				cp += int(r-'A') + 10
			default:
				return nil, fmt.Errorf("invalid codepoint %q", f)
			}
		}
		if cp < 0 || cp > 0x10FFFF || (cp >= 0xD800 && cp <= 0xDFFF) {
			return nil, fmt.Errorf("invalid Unicode scalar U+%X", cp)
		}
		out = append(out, cp)
	}
	return StripCartoucheMarkers(out), nil
}
