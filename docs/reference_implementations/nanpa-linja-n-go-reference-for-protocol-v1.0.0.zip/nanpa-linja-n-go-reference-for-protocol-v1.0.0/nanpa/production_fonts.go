package nanpa

import (
	"encoding/json"
	"fmt"
	"strings"

	productionassets "nanpa-linja-n.com/assets"
)

const DefaultProductionFontKey = "nasinNanpa"

var nativeCompanionFamilies = map[string]string{
	"nasinNanpa":         "nasin-nanpa-linja-n Ligature v4.4 Long Fix-nasin-e-en",
	"sitelenSeliKiwen":   "sitelen seli kiwen juniko-nanpa-linja-n Ligature-nasin-e-en",
	"fairfaxHd":          "Fairfax HD-nanpa-linja-n-nasin-e-en",
	"fairfaxPonaHd":      "Fairfax Pona HD-nanpa-linja-n-nasin-e-en",
	"linjaPona":          "linja pona 4.9-nanpa-linja-n-nasin-e-en",
	"linjaSike":          "linja sike 5-nanpa-linja-n-nasin-e-en",
	"nasinSitelenPuMono": "nasin-sitelen-pu-nanpa-linja-n-nasin-e-en",
	"linjaLipamanka":     "linja lipamanka-nanpa-linja-n-nasin-e-en",
}

type productionManifest struct {
	Schema int              `json:"schema"`
	Pairs  []productionPair `json:"pairs"`
}

type productionPair struct {
	FontKey                  string         `json:"fontKey"`
	Label                    string         `json:"label"`
	Rev                      string         `json:"rev"`
	ParserMode               string         `json:"parserMode"`
	RenderAdapterID          string         `json:"renderAdapterId"`
	RenderAdapterSettings    map[string]any `json:"renderAdapterSettings"`
	Settings                 map[string]any `json:"settings"`
	BaseFamily               string         `json:"baseFamily"`
	CompanionFamily          string         `json:"companionFamily"`
	LiteralCartoucheFamily   string         `json:"literalCartoucheFamily"`
	BaseFilename             string         `json:"baseFilename"`
	CompanionFilename        string         `json:"companionFilename"`
	LiteralCartoucheFilename string         `json:"literalCartoucheFilename"`
}

type ProductionFontInfo struct {
	Key                      string
	Label                    string
	Revision                 string
	ParserMode               string
	RenderAdapterID          string
	RenderAdapterSettings    map[string]any
	Settings                 map[string]any
	BaseFamily               string
	CompanionFamily          string
	LiteralCartoucheFamily   string
	NativeCompanionFamily    string
	BaseFilename             string
	CompanionFilename        string
	LiteralCartoucheFilename string
}

type ProductionFontRegistry struct {
	fonts   []ProductionFontInfo
	byKey   map[string]int
	aliases map[string]string
}

func loadProductionFontRegistry() (*ProductionFontRegistry, error) {
	raw, err := productionassets.Manifest()
	if err != nil {
		return nil, err
	}
	var doc productionManifest
	if err := json.Unmarshal(raw, &doc); err != nil {
		return nil, fmt.Errorf("invalid production font manifest: %w", err)
	}
	if doc.Schema != 2 {
		return nil, fmt.Errorf("unsupported production font manifest schema: %d", doc.Schema)
	}
	if len(doc.Pairs) != 8 {
		return nil, fmt.Errorf("production profile requires 8 font pairs; found %d", len(doc.Pairs))
	}
	r := &ProductionFontRegistry{byKey: map[string]int{}, aliases: map[string]string{}}
	for _, p := range doc.Pairs {
		adapter := strings.TrimSpace(p.RenderAdapterID)
		if adapter == "" {
			adapter = "identity"
		}
		native := nativeCompanionFamilies[p.FontKey]
		if native == "" {
			return nil, fmt.Errorf("no native companion family pinned for %s", p.FontKey)
		}
		// Verify embedded runtime files while constructing the registry.
		if _, err := productionassets.ReadFont(p.CompanionFilename); err != nil {
			return nil, err
		}
		info := ProductionFontInfo{
			Key: p.FontKey, Label: p.Label, Revision: p.Rev, ParserMode: p.ParserMode,
			RenderAdapterID: adapter, RenderAdapterSettings: cloneAnyMap(p.RenderAdapterSettings), Settings: cloneAnyMap(p.Settings),
			BaseFamily: p.BaseFamily, CompanionFamily: p.CompanionFamily, LiteralCartoucheFamily: p.LiteralCartoucheFamily,
			NativeCompanionFamily: native, BaseFilename: p.BaseFilename,
			CompanionFilename: p.CompanionFilename, LiteralCartoucheFilename: p.LiteralCartoucheFilename,
		}
		r.byKey[info.Key] = len(r.fonts)
		r.fonts = append(r.fonts, info)
		for _, alias := range []string{info.Key, info.Label, info.BaseFamily, info.CompanionFamily, info.NativeCompanionFamily} {
			n := normalizeFontAlias(alias)
			if n != "" {
				if _, ok := r.aliases[n]; !ok {
					r.aliases[n] = info.Key
				}
			}
		}
	}
	return r, nil
}

func cloneAnyMap(in map[string]any) map[string]any {
	if len(in) == 0 {
		return map[string]any{}
	}
	out := make(map[string]any, len(in))
	for k, v := range in {
		out[k] = v
	}
	return out
}

func normalizeFontAlias(s string) string {
	var b strings.Builder
	for _, r := range strings.ToLower(strings.TrimSpace(s)) {
		if (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') {
			b.WriteRune(r)
		}
	}
	return b.String()
}

func (r *ProductionFontRegistry) List() []ProductionFontInfo {
	return append([]ProductionFontInfo(nil), r.fonts...)
}

func (r *ProductionFontRegistry) Get(requested string) (ProductionFontInfo, error) {
	if requested == "" {
		requested = DefaultProductionFontKey
	}
	if i, ok := r.byKey[requested]; ok {
		return r.fonts[i], nil
	}
	key, ok := r.aliases[normalizeFontAlias(requested)]
	if !ok {
		return ProductionFontInfo{}, fmt.Errorf("unknown production font: %s", requested)
	}
	return r.fonts[r.byKey[key]], nil
}
