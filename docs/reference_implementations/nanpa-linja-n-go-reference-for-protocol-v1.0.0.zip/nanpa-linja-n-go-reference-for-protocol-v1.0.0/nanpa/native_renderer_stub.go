//go:build !linux || !cgo

package nanpa

import "fmt"

func ProductionNativeRenderingAvailable() bool { return false }

func nativeRenderProductionText(text, family, fontPath string, fontSize int, features []string, padding int, format OutputFormat, fg, bg RGBA) ([]byte, int, int, error) {
	return nil, 0, 0, fmt.Errorf("production graphical rendering requires Linux with cgo plus PangoCairo, PangoFT2, Cairo and Fontconfig; BuildRenderPlan remains available")
}
