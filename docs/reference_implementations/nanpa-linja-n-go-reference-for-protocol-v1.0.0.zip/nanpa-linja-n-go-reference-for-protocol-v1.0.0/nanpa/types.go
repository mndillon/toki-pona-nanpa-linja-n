package nanpa

type Options struct {
	Mode                                         string `json:"mode,omitempty"`
	NumericMode                                  string `json:"numericMode,omitempty"`
	MixedStyle                                   string `json:"mixedStyle,omitempty"`
	RelaxedNanpaLinjanParsing                    bool   `json:"relaxedNanpaLinjanParsing,omitempty"`
	RelaxedNanpaLinjanRendering                  bool   `json:"relaxedNanpaLinjanRendering,omitempty"`
	NanpaColonParsing                            bool   `json:"nanpaColonParsing,omitempty"`
	NanpaColonRendering                          bool   `json:"nanpaColonRendering,omitempty"`
	EnableHexParsing                             bool   `json:"enableHexParsing,omitempty"`
	EnableBinaryParsing                          bool   `json:"enableBinaryParsing,omitempty"`
	EnableBinaryRendering                        bool   `json:"enableBinaryRendering,omitempty"`
	AbbreviateNumericCartouches                  bool   `json:"abbreviateNumericCartouches,omitempty"`
	PreserveNumericCartoucheBreaksInAbbreviation bool   `json:"preserveNumericCartoucheBreaksInAbbreviation,omitempty"`
	NumericCartoucheStartGlyph                   string `json:"numericCartoucheStartGlyph,omitempty"`
	NasinNanpaPona                               bool   `json:"nasinNanpaPona,omitempty"`
}

func (o Options) normalizedMode() string {
	if o.Mode == "traditional" || o.NumericMode == "traditional" {
		return "traditional"
	}
	return "uniform"
}
func (o Options) nanpaColonParsing() bool { return o.NanpaColonParsing || o.NanpaColonRendering }
func (o Options) mixedStyle() string {
	if o.MixedStyle == "long" {
		return "long"
	}
	return "short"
}

type NumericPart struct {
	Kind   string  `json:"kind"`
	Digits string  `json:"digits,omitempty"`
	Char   *string `json:"char,omitempty"`
}

type ParseResult struct {
	Input                      string        `json:"input"`
	Kind                       *string       `json:"kind,omitempty"`
	NumberBase                 *int          `json:"numberBase,omitempty"`
	IsHex                      *bool         `json:"isHex,omitempty"`
	IsBinary                   *bool         `json:"isBinary,omitempty"`
	Caps                       *string       `json:"caps"`
	ProperName                 string        `json:"properName"`
	UniqueCode                 string        `json:"uniqueCode"`
	DisplayValue               string        `json:"displayValue"`
	HexDigits                  string        `json:"hexDigits,omitempty"`
	BinaryDigits               string        `json:"binaryDigits,omitempty"`
	HexParts                   []NumericPart `json:"hexParts,omitempty"`
	BinaryParts                []NumericPart `json:"binaryParts,omitempty"`
	UcsurCodepoints            []int         `json:"ucsurCodepoints"`
	AbbreviatedUcsurCodepoints []int         `json:"abbreviatedUcsurCodepoints,omitempty"`
	HexCodepoints              string        `json:"hexCodepoints"`
	HexWithCartouche           string        `json:"hexWithCartouche"`
	TpWords                    []string      `json:"tpWords"`
	AbbreviatedWords           []string      `json:"abbreviatedWords,omitempty"`
	NasinNanpaPonaWords        []string      `json:"nasinNanpaPonaWords,omitempty"`
	Words                      []string      `json:"words"`
	IsTime                     bool          `json:"isTime"`
	IsDate                     bool          `json:"isDate"`
	SemanticKind               *string       `json:"semanticKind"`
	SemanticStartGlyph         *string       `json:"semanticStartGlyph"`
	IsTimeLike                 bool          `json:"isTimeLike"`
	InnerCodepoints            []int         `json:"innerCodepoints"`
	Codepoints                 []int         `json:"codepoints"`
	NumericMode                string        `json:"numericMode"`
}

type IdentifierResult struct {
	Input           string   `json:"input"`
	InnerCodepoints []int    `json:"innerCodepoints"`
	Codepoints      []int    `json:"codepoints"`
	Words           []string `json:"words"`
	NumericMode     string   `json:"numericMode"`
}

type CapsCodepointsResult struct {
	InnerCodepoints []int    `json:"innerCodepoints"`
	Codepoints      []int    `json:"codepoints"`
	Words           []string `json:"words"`
	NumericMode     string   `json:"numericMode"`
	IsTimeLike      bool     `json:"isTimeLike"`
}
