package nanpa

import (
	"fmt"
	"strings"
)

const productionColon = 0xF199D

func adaptProductionCartouche(codepoints []int, adapterID string) (string, bool, error) {
	if adapterID == "" {
		adapterID = "identity"
	}
	legacy := adapterID == "linja-pona-legacy-v1" || adapterID == "linja-sike-legacy-v1"
	if !legacy {
		var b strings.Builder
		for _, cp := range codepoints {
			if cp < 0 || cp > 0x10FFFF {
				return "", false, fmt.Errorf("invalid Unicode scalar U+%X", cp)
			}
			b.WriteRune(rune(cp))
		}
		return b.String(), false, nil
	}
	if len(codepoints) < 2 || codepoints[0] != CartoucheStart || codepoints[len(codepoints)-1] != CartoucheEnd {
		return "", true, fmt.Errorf("%s: numeric render input is not a complete canonical cartouche", adapterID)
	}
	var b strings.Builder
	b.WriteByte('[')
	for _, cp := range codepoints[1 : len(codepoints)-1] {
		b.WriteByte('_')
		if cp == productionColon {
			b.WriteByte(':')
			continue
		}
		word, ok := cpToWord[cp]
		if !ok {
			return "", true, fmt.Errorf("%s: no legacy numeric encoding for U+%04X", adapterID, cp)
		}
		b.WriteString(word)
	}
	b.WriteByte(']')
	return b.String(), true, nil
}

func productionOpenTypeFeatures(fontSize int) []string {
	features := []string{"calt", "liga", "ccmp"}
	if fontSize > 0 && fontSize <= 18 {
		features = append(features, "ss12")
	} else if fontSize <= 29 {
		features = append(features, "ss13")
	}
	return features
}
