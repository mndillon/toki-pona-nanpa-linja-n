package nanpa

import (
	"bytes"
	"image"
	_ "image/png"
	"math"
	"testing"
)

func closeFloat(a, b float64) bool { return math.Abs(a-b) < 0.001 }

func TestLegacyAdapterSyntheticCornerBrackets(t *testing.T) {
	n, err := CreateNanpaLinjaN()
	if err != nil {
		t.Fatal(err)
	}
	defer n.Close()

	for _, fontKey := range []string{"linjaPona", "linjaSike"} {
		t.Run(fontKey, func(t *testing.T) {
			o := DefaultFullRenderOptions()
			o.Font = fontKey
			o.FontSize = 56

			plan, err := n.BuildFullRenderPlan("te tomo to", o)
			if err != nil {
				t.Fatal(err)
			}
			if len(plan.Runs) != 3 {
				t.Fatalf("runs=%d want 3", len(plan.Runs))
			}
			openRun, closeRun := plan.Runs[0], plan.Runs[2]
			for _, tc := range []struct {
				name string
				run  FullRenderRun
				cp   int
			}{
				{"open", openRun, OpenQuoteCodepoint},
				{"close", closeRun, CloseQuoteCodepoint},
			} {
				t.Run(tc.name, func(t *testing.T) {
					if tc.run.RenderMode != "synthetic-corner-bracket" {
						t.Fatalf("render mode=%q want synthetic-corner-bracket", tc.run.RenderMode)
					}
					if tc.run.RenderAdapterID != map[string]string{"linjaPona": "linja-pona-legacy-v1", "linjaSike": "linja-sike-legacy-v1"}[fontKey] {
						t.Fatalf("adapter=%q", tc.run.RenderAdapterID)
					}
					if len(tc.run.CanonicalCodepoints) != 1 || tc.run.CanonicalCodepoints[0] != tc.cp {
						t.Fatalf("canonical=%v want U+%04X", tc.run.CanonicalCodepoints, tc.cp)
					}
					if len(tc.run.RenderCodepoints) != 1 || tc.run.RenderCodepoints[0] != tc.cp {
						t.Fatalf("render cps=%v want U+%04X", tc.run.RenderCodepoints, tc.cp)
					}
					if !closeFloat(tc.run.WidthPx, 21) || !closeFloat(tc.run.HeightPx, 43) {
						t.Fatalf("geometry %.3fx%.3f want 21x43", tc.run.WidthPx, tc.run.HeightPx)
					}
				})
			}

			// The JS baseline raises U+300C above the baseline while U+300D
			// straddles it. Verify the same measured placement contract.
			if !(openRun.YPx < closeRun.YPx) {
				t.Fatalf("opening bracket y=%.3f should be above closing bracket y=%.3f", openRun.YPx, closeRun.YPx)
			}

			png, err := n.RenderFullToPNG("te tomo to", o)
			if err != nil {
				t.Fatal(err)
			}
			im, _, err := image.Decode(bytes.NewReader(png))
			if err != nil {
				t.Fatalf("decode png: %v", err)
			}
			for _, run := range []FullRenderRun{openRun, closeRun} {
				minX := int(math.Floor(run.XPx))
				maxX := int(math.Ceil(run.XPx + run.WidthPx))
				minY := int(math.Floor(run.YPx))
				maxY := int(math.Ceil(run.YPx + run.HeightPx))
				ink := false
				for y := minY; y < maxY && !ink; y++ {
					for x := minX; x < maxX; x++ {
						if x < im.Bounds().Min.X || x >= im.Bounds().Max.X || y < im.Bounds().Min.Y || y >= im.Bounds().Max.Y {
							continue
						}
						_, _, _, a := im.At(x, y).RGBA()
						if a != 0 {
							ink = true
							break
						}
					}
				}
				if !ink {
					t.Fatalf("synthetic bracket %q produced no PNG ink", run.SourceText)
				}
			}

			vec, err := n.ToVectorDocument("te tomo to", o)
			if err != nil {
				t.Fatal(err)
			}
			pathCount := 0
			for _, el := range vec.Elements {
				if el.Kind == "path" && (el.RunID == openRun.ID || el.RunID == closeRun.ID) {
					pathCount++
				}
			}
			if pathCount != 2 {
				t.Fatalf("synthetic vector bracket paths=%d want 2", pathCount)
			}
		})
	}
}

func TestSyntheticCornerBracketsDoNotChangeRawUnicodeOrOtherProfiles(t *testing.T) {
	n, err := CreateNanpaLinjaN()
	if err != nil {
		t.Fatal(err)
	}
	defer n.Close()

	o := DefaultFullRenderOptions()
	o.Font = "linjaPona"
	plan, err := n.BuildFullRenderPlan("U+300C U+300D", o)
	if err != nil {
		t.Fatal(err)
	}
	if len(plan.Runs) != 1 {
		t.Fatalf("raw runs=%d want 1 grouped raw-UCSUR run", len(plan.Runs))
	}
	for _, run := range plan.Runs {
		if run.RenderMode == "synthetic-corner-bracket" {
			t.Fatalf("raw unicode run %q must bypass synthetic adapter presentation", run.SourceText)
		}
		if run.RenderAdapterID != "identity" {
			t.Fatalf("raw unicode adapter=%q want identity", run.RenderAdapterID)
		}
	}

	o = DefaultFullRenderOptions()
	o.Font = "nasinNanpa"
	plan, err = n.BuildFullRenderPlan("te tomo to", o)
	if err != nil {
		t.Fatal(err)
	}
	if len(plan.Runs) != 3 {
		t.Fatalf("nasinNanpa runs=%d want 3", len(plan.Runs))
	}
	if plan.Runs[0].RenderMode == "synthetic-corner-bracket" || plan.Runs[2].RenderMode == "synthetic-corner-bracket" {
		t.Fatal("synthetic corner brackets must remain limited to manifest-configured legacy profiles")
	}
}
