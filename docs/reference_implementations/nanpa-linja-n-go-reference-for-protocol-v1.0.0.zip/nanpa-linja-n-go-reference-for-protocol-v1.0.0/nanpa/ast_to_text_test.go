package nanpa

import (
	"bytes"
	"reflect"
	"testing"
)

func TestAstToTextRegression(t *testing.T) {
	n, err := CreateNanpaLinjaN()
	if err != nil {
		t.Fatal(err)
	}
	defer n.Close()

	passed := 0
	run := func(name string, fn func(t *testing.T)) {
		t.Run(name, func(t *testing.T) {
			fn(t)
			passed++
		})
	}

	run("round-trip whitespace blank lines and quotes", func(t *testing.T) {
		source := "jan   pona [ jan  pona,, ]\n\n“toki pona”"
		got, err := n.AstToText(n.ParseInput(source))
		if err != nil {
			t.Fatal(err)
		}
		if got != source {
			t.Fatalf("got %q want %q", got, source)
		}
	})

	run("breakLinesAtFullStops physical-line reconstruction", func(t *testing.T) {
		source := "jan li pona. ona   li pona."
		o := DefaultFullRenderOptions()
		o.Parser.BreakLinesAtFullStops = true
		ast := n.ParseInput(source, o)
		if len(ast.Lines) != 2 {
			t.Fatalf("AST lines %d want 2", len(ast.Lines))
		}
		got, err := n.AstToText(ast)
		if err != nil {
			t.Fatal(err)
		}
		if got != source {
			t.Fatalf("got %q want %q", got, source)
		}
	})

	run("edited bracket value", func(t *testing.T) {
		source := "jan   pona [ jan  pona,, ]"
		ast := n.ParseInput(source)
		found := false
		for li := range ast.Lines {
			for si := range ast.Lines[li].Children {
				seg := &ast.Lines[li].Children[si]
				if seg.Kind == "bracket" {
					seg.Value = " jan  suno,, "
					found = true
				}
			}
		}
		if !found {
			t.Fatal("bracket segment not found")
		}
		got, err := n.AstToText(ast)
		if err != nil {
			t.Fatal(err)
		}
		want := "jan   pona [ jan  suno,, ]"
		if got != want {
			t.Fatalf("got %q want %q", got, want)
		}
	})

	run("edited quote value and delimiters", func(t *testing.T) {
		ast := n.ParseInput(`jan "pona"`)
		found := false
		for li := range ast.Lines {
			for si := range ast.Lines[li].Children {
				seg := &ast.Lines[li].Children[si]
				if seg.Kind == "quote" {
					seg.Value = "toki"
					seg.OpenQuote = "“"
					seg.CloseQuote = "”"
					found = true
				}
			}
		}
		if !found {
			t.Fatal("quote segment not found")
		}
		got, err := n.AstToText(ast)
		if err != nil {
			t.Fatal(err)
		}
		if got != "jan “toki”" {
			t.Fatalf("got %q", got)
		}
	})

	run("image descriptor semantic round-trip", func(t *testing.T) {
		source := "jan img(src='x.png', w=20, h='30', alt='x', valign='middle', wriggle=6) pona"
		before := n.ParseInput(source)
		var want *ImageDescriptor
		for _, line := range before.Lines {
			for _, seg := range line.Children {
				if seg.Kind == "image" && seg.Image != nil {
					copy := *seg.Image
					want = &copy
				}
			}
		}
		if want == nil {
			t.Fatal("image segment not found")
		}
		text, err := n.AstToText(before)
		if err != nil {
			t.Fatal(err)
		}
		after := n.ParseInput(text)
		var got *ImageDescriptor
		for _, line := range after.Lines {
			for _, seg := range line.Children {
				if seg.Kind == "image" && seg.Image != nil {
					copy := *seg.Image
					got = &copy
				}
			}
		}
		if !reflect.DeepEqual(got, want) {
			t.Fatalf("image round-trip got %#v want %#v; serialized %q", got, want, text)
		}
	})

	run("parser newline normalization is retained", func(t *testing.T) {
		ast := n.ParseInput("jan\r\npona\r\ntoki")
		got, err := n.AstToText(ast)
		if err != nil {
			t.Fatal(err)
		}
		if got != "jan\npona\ntoki" {
			t.Fatalf("got %q", got)
		}
	})

	run("package function matches facade method", func(t *testing.T) {
		ast := n.ParseInput("jan [pona]")
		methodText, err := n.AstToText(ast)
		if err != nil {
			t.Fatal(err)
		}
		functionText, err := AstToText(ast)
		if err != nil {
			t.Fatal(err)
		}
		if functionText != methodText || functionText != "jan [pona]" {
			t.Fatalf("function %q method %q", functionText, methodText)
		}
	})

	run("unsupported segment kind is rejected", func(t *testing.T) {
		ast := DocumentAST{Type: "document", Lines: []DocumentLine{{SourceLineIndex: 0, Children: []DocumentSegment{{Kind: "unsupported"}}}}}
		if _, err := n.AstToText(ast); err == nil {
			t.Fatal("expected unsupported segment error")
		}
	})

	if passed != 8 {
		t.Fatalf("Go AstToText regression: %d/8 PASS", passed)
	}
	t.Logf("Go AstToText regression: %d/8 PASS", passed)
}

func TestAstToTextRenderIntegration(t *testing.T) {
	if !fullNativeAvailable() {
		t.Skip("full native renderer requires Linux+cgo")
	}
	n, err := CreateNanpaLinjaN()
	if err != nil {
		t.Fatal(err)
	}
	defer n.Close()

	ast := n.ParseInput("jan [pona,,] 123.45")
	for li := range ast.Lines {
		for si := range ast.Lines[li].Children {
			seg := &ast.Lines[li].Children[si]
			if seg.Kind == "bracket" {
				seg.Value = "suno,,"
			}
		}
	}
	text, err := n.AstToText(ast)
	if err != nil {
		t.Fatal(err)
	}
	png, err := n.RenderFullToPNG(text)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.HasPrefix(png, []byte{137, 80, 78, 71, 13, 10, 26, 10}) {
		t.Fatal("edited AST text did not render as PNG")
	}
	t.Log("Go AstToText render integration: 1/1 PASS")
}
