package nanpa

import (
	"fmt"
	"regexp"
	"strconv"
	"strings"
	"unicode/utf8"
)

var vulgarFractions = map[rune][2]int{
	'¼': {1, 4}, '½': {1, 2}, '¾': {3, 4}, '⅐': {1, 7}, '⅑': {1, 9}, '⅒': {1, 10}, '⅓': {1, 3}, '⅔': {2, 3}, '⅕': {1, 5}, '⅖': {2, 5}, '⅗': {3, 5}, '⅘': {4, 5}, '⅙': {1, 6}, '⅚': {5, 6}, '⅛': {1, 8}, '⅜': {3, 8}, '⅝': {5, 8}, '⅞': {7, 8}, '↉': {0, 3},
}

func NormalizeVulgarFraction(raw string) (string, error) {
	s := strings.TrimSpace(strings.ReplaceAll(raw, "⁄", "/"))
	if s == "" {
		return s, nil
	}
	found := false
	for _, r := range s {
		if _, ok := vulgarFractions[r]; ok {
			found = true
			break
		}
	}
	if !found {
		return s, nil
	}
	last, _ := utf8.DecodeLastRuneInString(s)
	f, ok := vulgarFractions[last]
	if !ok {
		return "", fmt.Errorf("vulgar fraction must be final")
	}
	rest := strings.TrimSuffix(s, string(last))
	tail := rest
	if len(tail) > 0 {
		tail = tail[1:]
	}
	if strings.ContainsAny(tail, "-+") {
		return "", fmt.Errorf("sign only at start")
	}
	prefix := strings.TrimSpace(rest)
	if prefix == "" {
		return fmt.Sprintf("%d/%d", f[0], f[1]), nil
	}
	sign := ""
	if strings.HasPrefix(prefix, "-") || strings.HasPrefix(prefix, "+") {
		sign = prefix[:1]
		prefix = strings.TrimSpace(prefix[1:])
	}
	if prefix == "" {
		return fmt.Sprintf("%s%d/%d", sign, f[0], f[1]), nil
	}
	return fmt.Sprintf("%s%s+%d/%d", sign, prefix, f[0], f[1]), nil
}
func normalizeLooseSeparators(raw string) string {
	r := strings.NewReplacer("−", "-", "‒", "-", "–", "-", "—", "-").Replace(raw)
	neg := strings.HasPrefix(r, "-")
	if neg {
		r = r[1:]
	}
	r = strings.Join(strings.Fields(r), " ")
	for strings.Contains(r, "--") {
		r = strings.ReplaceAll(r, "--", "-")
	}
	if neg {
		r = "-" + r
	}
	return strings.TrimSpace(r)
}
func groupFractionDigitsOnly(s string, size int) string {
	idx := strings.IndexByte(s, '.')
	if idx < 0 {
		return s
	}
	left, right := s[:idx], s[idx+1:]
	i := 0
	for i < len(right) && right[i] >= '0' && right[i] <= '9' {
		i++
	}
	digits, suffix := right[:i], right[i:]
	if len(digits) <= size || strings.Contains(digits, "_") {
		return s
	}
	groups := []string{}
	for j := 0; j < len(digits); j += size {
		e := j + size
		if e > len(digits) {
			e = len(digits)
		}
		groups = append(groups, digits[j:e])
	}
	return left + "." + strings.Join(groups, "_") + suffix
}

func NumberStringToCaps(s string, opts Options) (string, error) {
	raw := normalizeLooseSeparators(s)
	if raw == "" {
		return "", fmt.Errorf("empty")
	}
	raw = groupFractionDigitsOnly(raw, 3)
	leadingPlus := false
	if strings.HasPrefix(raw, "+") {
		leadingPlus = true
		raw = strings.TrimSpace(raw[1:])
		if raw == "" {
			return "", fmt.Errorf("missing after plus")
		}
	}
	encodeSegment := func(segment string, initial, plus bool) (string, error) {
		return encodeNumberSegment(segment, initial, plus, opts)
	}
	stripN := func(s string) (string, error) {
		if !strings.HasSuffix(s, "N") {
			return "", fmt.Errorf("segment")
		}
		return s[:len(s)-1], nil
	}
	if strings.Contains(raw, "+") {
		parts := strings.SplitN(raw, "+", 2)
		if !strings.Contains(parts[1], "/") {
			return "", fmt.Errorf("mixed")
		}
		fr := strings.SplitN(parts[1], "/", 2)
		l, e := encodeSegment(parts[0], true, leadingPlus)
		if e != nil {
			return "", e
		}
		n, e := encodeSegment(fr[0], false, false)
		if e != nil {
			return "", e
		}
		d, e := encodeSegment(fr[1], false, false)
		if e != nil {
			return "", e
		}
		l, _ = stripN(l)
		n, _ = stripN(n)
		sep := "NOKO"
		if opts.mixedStyle() == "long" {
			sep = "NONONO"
		}
		return l + sep + n + "NONO" + d, nil
	}
	if strings.Contains(raw, "/") {
		parts := strings.SplitN(raw, "/", 2)
		n, e := encodeSegment(parts[0], true, leadingPlus)
		if e != nil {
			return "", e
		}
		d, e := encodeSegment(parts[1], false, false)
		if e != nil {
			return "", e
		}
		n, _ = stripN(n)
		return n + "NONO" + d, nil
	}
	return encodeSegment(raw, true, leadingPlus)
}

func encodeNumberSegment(segment string, initial, leadingPlus bool, opts Options) (string, error) {
	seg := strings.TrimSpace(segment)
	if seg == "" {
		return "", fmt.Errorf("empty segment")
	}
	if strings.HasPrefix(strings.ToUpper(seg), "N") {
		seg = strings.TrimSpace(seg[1:])
		if seg == "" {
			return "", fmt.Errorf("missing N body")
		}
	}
	out := []string{}
	if initial {
		out = append(out, "NE")
	}
	if initial && leadingPlus {
		out = append(out, "NS")
	}
	pushNene := func() {
		n := len(out)
		if n >= 2 && out[n-2] == "NE" && out[n-1] == "NE" {
			return
		}
		out = append(out, "NE", "NE")
	}
	if strings.HasPrefix(seg, "-") {
		if strings.HasPrefix(seg, "-.") {
			seg = "-0." + seg[2:]
		}
		out = append(out, "NO")
		seg = strings.TrimSpace(seg[1:])
	}
	mag := 0
	if seg != "" {
		last := strings.ToUpper(seg[len(seg)-1:])
		switch last {
		case "K":
			mag = 1
		case "M":
			mag = 2
		case "B":
			mag = 3
		case "T":
			mag = 4
		}
		if mag > 0 {
			seg = strings.TrimSpace(seg[:len(seg)-1])
			if seg == "" {
				return "", fmt.Errorf("missing magnitude body")
			}
		}
	}
	if strings.Count(seg, ".") > 1 {
		return "", fmt.Errorf("multiple decimals")
	}
	ip, fp, hasDec := seg, "", false
	if idx := strings.IndexByte(seg, '.'); idx >= 0 {
		ip, fp, hasDec = seg[:idx], seg[idx+1:], true
	}
	ip = strings.TrimSpace(ip)
	if ip == "" {
		ip = "0"
	}
	if strings.ContainsAny(ip, " -") {
		ip2 := strings.Trim(strings.Join(strings.Fields(ip), " "), " -")
		if ip2 == "" {
			ip2 = "0"
		}
		for i := 0; i < len(ip2); i++ {
			ch := ip2[i]
			if ch >= '0' && ch <= '9' {
				t, e := digitToken(ch, opts)
				if e != nil {
					return "", e
				}
				out = append(out, t)
			} else if ch == ' ' || ch == '-' {
				pushNene()
			} else if ch == ',' {
				out = append(out, "NE", "KE")
			} else {
				return "", fmt.Errorf("bad integer char")
			}
		}
	} else {
		groups := strings.Split(ip, ",")
		for _, g := range groups {
			if g == "" || !allDigits(g) {
				return "", fmt.Errorf("bad group %q", g)
			}
		}
		trailing := 0
		for k := len(groups) - 1; k >= 1; k-- {
			if len(groups[k]) == 3 && groups[k] == "000" {
				trailing++
			} else {
				break
			}
		}
		for i := 0; i < len(groups[0]); i++ {
			t, _ := digitToken(groups[0][i], opts)
			out = append(out, t)
		}
		lastNon := len(groups) - trailing
		for idx := 1; idx < lastNon; idx++ {
			out = append(out, "NE", "KE")
			for i := 0; i < len(groups[idx]); i++ {
				t, _ := digitToken(groups[idx][i], opts)
				out = append(out, t)
			}
		}
		if trailing > 0 {
			out = append(out, "NE", strings.Repeat("KE", trailing))
		}
	}
	if hasDec {
		out = append(out, "NO", "NE")
		if fp == "" {
			return "", fmt.Errorf("missing fraction")
		}
		for i := 0; i < len(fp); i++ {
			ch := fp[i]
			if ch >= '0' && ch <= '9' {
				t, _ := digitToken(ch, opts)
				out = append(out, t)
			} else if strings.ContainsRune("_, -", rune(ch)) {
				pushNene()
			} else {
				return "", fmt.Errorf("bad fraction char")
			}
		}
	}
	if mag > 0 {
		out = append(out, "NE", strings.Repeat("KE", mag))
	}
	out = append(out, "N")
	return strings.Join(out, ""), nil
}
func allDigits(s string) bool {
	if s == "" {
		return false
	}
	for i := 0; i < len(s); i++ {
		if s[i] < '0' || s[i] > '9' {
			return false
		}
	}
	return true
}

var sciE = regexp.MustCompile(`^\s*([+-]?(?:(?:\d[\d, _-]*)(?:\.\d[\d, _-]*)?|(?:\.\d[\d, _-]*)))\s*[eE]\s*([+-]?\d+)\s*$`)
var sciCaret = regexp.MustCompile(`^\s*([+-]?(?:(?:\d[\d, _-]*)(?:\.\d[\d, _-]*)?|(?:\.\d[\d, _-]*)))\s*\*\s*10\s*\^\s*([+-]?\d+)\s*$`)
var sciNoCaret = regexp.MustCompile(`^\s*([+-]?(?:(?:\d[\d, _-]*)(?:\.\d[\d, _-]*)?|(?:\.\d[\d, _-]*)))\s*\*\s*10\s*([+-]\d+)\s*$`)

func tryScientific(raw string, opts Options) (string, bool) {
	r := strings.NewReplacer("−", "-", "‒", "-", "–", "-", "—", "-").Replace(strings.TrimSpace(raw))
	var m []string
	for _, re := range []*regexp.Regexp{sciE, sciCaret, sciNoCaret} {
		m = re.FindStringSubmatch(r)
		if m != nil {
			break
		}
	}
	if m == nil {
		return "", false
	}
	mant, exp := strings.TrimSpace(m[1]), strings.TrimSpace(m[2])
	exp = strings.TrimPrefix(exp, "+")
	if !regexp.MustCompile(`^-?\d+$`).MatchString(exp) {
		return "", false
	}
	mc, e := NumberStringToCaps(mant, opts)
	if e != nil {
		return "", false
	}
	eo := opts
	ec, e := NumberStringToCaps(exp, eo)
	if e != nil {
		return "", false
	}
	if !strings.HasSuffix(mc, "N") || !strings.HasPrefix(ec, "NE") || !strings.HasSuffix(ec, "N") {
		return "", false
	}
	caps := mc[:len(mc)-1] + "NEKO" + ec[2:len(ec)-1] + "N"
	if _, e = tokenizeCaps(caps, opts); e != nil {
		return "", false
	}
	return caps, true
}

func DecimalStringToCaps(raw string, opts Options) (string, error) {
	s := strings.TrimSpace(raw)
	pct := strings.HasSuffix(s, "%")
	if pct {
		s = strings.TrimSpace(strings.TrimSuffix(s, "%"))
	}
	norm, e := NormalizeVulgarFraction(s)
	if e != nil {
		return "", e
	}
	var caps string
	if c, ok := tryScientific(norm, opts); ok {
		caps = c
	} else if looksLikeCaps(norm) {
		caps = strings.ToUpper(norm)
	} else {
		caps, e = NumberStringToCaps(norm, opts)
		if e != nil {
			return "", e
		}
	}
	if pct {
		caps = caps[:len(caps)-1] + "OKN"
	}
	if _, e = tokenizeCaps(caps, opts); e != nil {
		return "", e
	}
	return caps, nil
}

func normalizeDateTime(s string) string {
	return strings.NewReplacer("‐", "-", "‑", "-", "‒", "-", "–", "-", "—", "-", "−", "-", "﹣", "-", "－", "-", "⁄", "/", "∕", "/", "／", "/", "：", ":").Replace(strings.Join(strings.Fields(strings.TrimSpace(s)), ""))
}

type timeParts struct {
	hasDays, negative     bool
	day, hh, mm, ss, frac string
}

func parseTimeParts(raw string) (timeParts, bool) {
	s := strings.TrimSpace(raw)
	if s == "" || strings.IndexFunc(s, func(r rune) bool { return r == ' ' || r == '\t' || r == '\n' || r == '\r' }) >= 0 {
		return timeParts{}, false
	}
	f := strings.Split(s, ":")
	if len(f) < 2 || len(f) > 4 {
		return timeParts{}, false
	}
	reFirst := regexp.MustCompile(`^([+-]?)(\d+)$`)
	m := reFirst.FindStringSubmatch(f[0])
	if m == nil {
		return timeParts{}, false
	}
	sign, first := m[1], m[2]
	pair := func(x string) bool { return len(x) == 2 && x[0] >= '0' && x[0] <= '5' && allDigits(x) }
	parseSec := func(x string) (string, string, bool) {
		mm := regexp.MustCompile(`^([0-5]\d)(?:\.(\d{1,3}))?$`).FindStringSubmatch(x)
		if mm == nil {
			return "", "", false
		}
		return mm[1], mm[2], true
	}
	nonzero := func(v ...string) bool { return strings.ContainsAny(strings.Join(v, ""), "123456789") }
	if len(f) == 2 {
		if sign != "" || len(first) < 1 || len(first) > 2 || !allDigits(first) || !pair(f[1]) {
			return timeParts{}, false
		}
		h, _ := strconv.Atoi(first)
		if h > 59 {
			return timeParts{}, false
		}
		return timeParts{hh: first, mm: f[1]}, true
	}
	if len(f) == 3 {
		ss, fr, ok := parseSec(f[2])
		if ok && fr != "" {
			if sign != "" || len(first) > 2 || !allDigits(first) || !pair(f[1]) {
				return timeParts{}, false
			}
			h, _ := strconv.Atoi(first)
			if h > 59 {
				return timeParts{}, false
			}
			return timeParts{hh: first, mm: f[1], ss: ss, frac: fr}, true
		}
		if !pair(f[1]) || !pair(f[2]) {
			return timeParts{}, false
		}
		return timeParts{hasDays: true, negative: sign == "-" && nonzero(first, f[1], f[2]), day: first, hh: f[1], mm: f[2]}, true
	}
	if !pair(f[1]) || !pair(f[2]) {
		return timeParts{}, false
	}
	ss, fr, ok := parseSec(f[3])
	if !ok {
		return timeParts{}, false
	}
	return timeParts{hasDays: true, negative: sign == "-" && nonzero(first, f[1], f[2], ss, fr), day: first, hh: f[1], mm: f[2], ss: ss, frac: fr}, true
}
func encodeDigitsOnly(s string, opts Options) (string, error) {
	if !allDigits(s) {
		return "", fmt.Errorf("digits only")
	}
	var b strings.Builder
	for i := 0; i < len(s); i++ {
		t, e := digitToken(s[i], opts)
		if e != nil {
			return "", e
		}
		b.WriteString(t)
	}
	return b.String(), nil
}
func validYearless(mm, dd string) bool {
	if len(mm) != 2 || len(dd) != 2 || !allDigits(mm) || !allDigits(dd) {
		return false
	}
	m, _ := strconv.Atoi(mm)
	d, _ := strconv.Atoi(dd)
	max := []int{0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}
	return m >= 1 && m <= 12 && d >= 1 && d <= max[m]
}

type dateParts struct {
	yyyy, mm, dd string
	yearless     bool
}

func parseDateParts(raw string) (dateParts, bool) {
	t := strings.TrimSpace(raw)
	if t != "" && !strings.ContainsAny(t, " \t\r\n") {
		if m := regexp.MustCompile(`^--(\d{2})-(\d{2})$`).FindStringSubmatch(t); m != nil && validYearless(m[1], m[2]) {
			return dateParts{mm: m[1], dd: m[2], yearless: true}, true
		}
		if m := regexp.MustCompile(`^XXXX-(\d{2})-(\d{2})$`).FindStringSubmatch(t); m != nil && validYearless(m[1], m[2]) {
			return dateParts{mm: m[1], dd: m[2], yearless: true}, true
		}
	}
	s := normalizeDateTime(raw)
	m := regexp.MustCompile(`^(\d{4})([/-])(\d{2})([/-])(\d{2})$`).FindStringSubmatch(s)
	if m == nil || m[2] != m[4] {
		return dateParts{}, false
	}
	mo, _ := strconv.Atoi(m[3])
	d, _ := strconv.Atoi(m[5])
	if mo < 1 || mo > 12 || d < 1 || d > 31 {
		return dateParts{}, false
	}
	return dateParts{yyyy: m[1], mm: m[3], dd: m[5]}, true
}
func dateStringToCaps(raw string, opts Options) (string, bool) {
	p, ok := parseDateParts(raw)
	if !ok {
		return "", false
	}
	c := "NE"
	if !p.yearless {
		y, _ := encodeDigitsOnly(p.yyyy, opts)
		c += y + "NEKE"
	}
	m, _ := encodeDigitsOnly(p.mm, opts)
	d, _ := encodeDigitsOnly(p.dd, opts)
	c += m + "NEKE" + d + "N"
	if _, e := tokenizeCaps(c, opts); e != nil {
		return "", false
	}
	return c, true
}
func timeStringToCaps(raw string, opts Options) (string, bool) {
	p, ok := parseTimeParts(raw)
	if !ok {
		return "", false
	}
	c := "NE"
	if p.negative {
		c += "NO"
	}
	if p.hasDays {
		x, _ := encodeDigitsOnly(p.day, opts)
		c += x + "NEKE"
	}
	h, _ := encodeDigitsOnly(p.hh, opts)
	m, _ := encodeDigitsOnly(p.mm, opts)
	c += h + "NEKE" + m
	if p.ss != "" {
		x, _ := encodeDigitsOnly(p.ss, opts)
		c += "NEKE" + x
		if p.frac != "" {
			f, _ := encodeDigitsOnly(p.frac, opts)
			c += "NONE" + f
		}
	}
	c += "N"
	if _, e := tokenizeCaps(c, opts); e != nil {
		return "", false
	}
	return c, true
}
