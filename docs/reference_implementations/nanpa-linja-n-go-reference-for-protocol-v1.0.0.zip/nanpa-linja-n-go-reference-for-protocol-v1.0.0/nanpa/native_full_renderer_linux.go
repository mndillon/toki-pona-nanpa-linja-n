//go:build linux && cgo

package nanpa

/*
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <dlfcn.h>

#cgo linux LDFLAGS: -ldl

typedef void cairo_surface_t;
typedef void cairo_t;
typedef void PangoLayout;
typedef void PangoFontDescription;
typedef void PangoAttrList;
typedef void PangoAttribute;
typedef void PangoFontMap;
typedef void PangoContext;
typedef void FcConfig;
typedef unsigned char FcChar8;
typedef struct { int x; int y; int width; int height; } PangoRectangle;

typedef cairo_surface_t* (*fn_cairo_image_surface_create)(int,int,int);
typedef cairo_surface_t* (*fn_cairo_file_surface_create)(const char*,double,double);
typedef cairo_surface_t* (*fn_cairo_png_surface)(const char*);
typedef int (*fn_cairo_image_dim)(cairo_surface_t*);
typedef cairo_t* (*fn_cairo_create)(cairo_surface_t*);
typedef void (*fn_void_ptr)(void*);
typedef int (*fn_int_surface)(cairo_surface_t*);
typedef int (*fn_write_png)(cairo_surface_t*,const char*);
typedef void (*fn_cairo_set_operator)(cairo_t*,int);
typedef void (*fn_cairo_set_rgba)(cairo_t*,double,double,double,double);
typedef void (*fn_cairo_move_to)(cairo_t*,double,double);
typedef void (*fn_cairo_line_to)(cairo_t*,double,double);
typedef void (*fn_cairo_set_double)(cairo_t*,double);
typedef void (*fn_cairo_set_int)(cairo_t*,int);
typedef void (*fn_cairo_source_surface)(cairo_t*,cairo_surface_t*,double,double);
typedef void (*fn_cairo_translate)(cairo_t*,double,double);
typedef void (*fn_cairo_scale)(cairo_t*,double,double);
typedef void (*fn_cairo_rect)(cairo_t*,double,double,double,double);
typedef void (*fn_cairo_arc)(cairo_t*,double,double,double,double,double);
typedef void (*fn_cairo_close)(cairo_t*);
typedef PangoLayout* (*fn_pango_create_layout)(cairo_t*);
typedef void (*fn_pango_show_layout)(cairo_t*,PangoLayout*);
typedef void (*fn_pango_layout_path)(cairo_t*,PangoLayout*);
typedef PangoFontDescription* (*fn_pango_desc_new)(void);
typedef void (*fn_pango_desc_family)(PangoFontDescription*,const char*);
typedef void (*fn_pango_desc_size)(PangoFontDescription*,double);
typedef void (*fn_pango_layout_text)(PangoLayout*,const char*,int);
typedef void (*fn_pango_layout_desc)(PangoLayout*,const PangoFontDescription*);
typedef PangoAttrList* (*fn_pango_attr_list_new)(void);
typedef PangoAttribute* (*fn_pango_attr_features_new)(const char*);
typedef void (*fn_pango_attr_insert)(PangoAttrList*,PangoAttribute*);
typedef void (*fn_pango_layout_attrs)(PangoLayout*,PangoAttrList*);
typedef void (*fn_pango_extents)(PangoLayout*,PangoRectangle*,PangoRectangle*);
typedef int (*fn_pango_baseline)(PangoLayout*);
typedef void (*fn_pango_index_to_pos)(PangoLayout*,int,PangoRectangle*);
typedef PangoFontMap* (*fn_pango_fontmap_new)(void);
typedef PangoContext* (*fn_pango_fontmap_context)(PangoFontMap*);
typedef PangoLayout* (*fn_pango_layout_new)(PangoContext*);
typedef void (*fn_pango_fc_set_config)(PangoFontMap*,FcConfig*);
typedef FcConfig* (*fn_fc_create)(void);
typedef int (*fn_fc_add)(FcConfig*,const FcChar8*);
typedef int (*fn_fc_build)(FcConfig*);
typedef void (*fn_fc_destroy)(FcConfig*);

static void *fh_cairo=NULL,*fh_pango=NULL,*fh_pangocairo=NULL,*fh_pangoft2=NULL,*fh_fontconfig=NULL,*fh_gobject=NULL;
static int full_loaded=0;
static fn_cairo_image_surface_create f_cairo_image_surface_create;
static fn_cairo_file_surface_create f_cairo_svg_surface_create,f_cairo_pdf_surface_create;
static fn_cairo_png_surface f_cairo_image_surface_create_from_png;
static fn_cairo_image_dim f_cairo_image_surface_get_width,f_cairo_image_surface_get_height;
static fn_cairo_create f_cairo_create;
static fn_void_ptr f_cairo_destroy,f_cairo_surface_destroy,f_cairo_surface_finish,f_cairo_paint,f_cairo_stroke,f_cairo_fill,f_cairo_save,f_cairo_restore;
static fn_int_surface f_cairo_surface_status;
static fn_write_png f_cairo_surface_write_to_png;
static fn_cairo_set_operator f_cairo_set_operator;
static fn_cairo_set_rgba f_cairo_set_source_rgba;
static fn_cairo_move_to f_cairo_move_to;
static fn_cairo_line_to f_cairo_line_to;
static fn_cairo_set_double f_cairo_set_line_width;
static fn_cairo_set_int f_cairo_set_line_cap,f_cairo_set_line_join;
static fn_cairo_source_surface f_cairo_set_source_surface;
static fn_cairo_translate f_cairo_translate;
static fn_cairo_scale f_cairo_scale;
static fn_cairo_rect f_cairo_rectangle;
static fn_cairo_arc f_cairo_arc;
static fn_cairo_close f_cairo_close_path;
static fn_pango_create_layout f_pango_cairo_create_layout;
static fn_pango_show_layout f_pango_cairo_show_layout;
static fn_pango_layout_path f_pango_cairo_layout_path;
static fn_pango_desc_new f_pango_font_description_new;
static fn_pango_desc_family f_pango_font_description_set_family;
static fn_pango_desc_size f_pango_font_description_set_absolute_size;
static fn_void_ptr f_pango_font_description_free,f_pango_attr_list_unref,f_g_object_unref;
static fn_pango_layout_text f_pango_layout_set_text;
static fn_pango_layout_desc f_pango_layout_set_font_description;
static fn_pango_attr_list_new f_pango_attr_list_new;
static fn_pango_attr_features_new f_pango_attr_font_features_new;
static fn_pango_attr_insert f_pango_attr_list_insert;
static fn_pango_layout_attrs f_pango_layout_set_attributes;
static fn_pango_extents f_pango_layout_get_pixel_extents;
static fn_pango_baseline f_pango_layout_get_baseline;
static fn_pango_index_to_pos f_pango_layout_index_to_pos;
static fn_pango_fontmap_new f_pango_cairo_font_map_new;
static fn_pango_fontmap_context f_pango_font_map_create_context;
static fn_pango_layout_new f_pango_layout_new;
static fn_pango_fc_set_config f_pango_fc_font_map_set_config;
static fn_fc_create f_FcConfigCreate;
static fn_fc_add f_FcConfigAppFontAddFile;
static fn_fc_build f_FcConfigBuildFonts;
static fn_fc_destroy f_FcConfigDestroy;

static void* f_open(const char*n){return dlopen(n,RTLD_LAZY|RTLD_LOCAL);}
#define FSYM(v,h,n) do{ *(void**)(&v)=dlsym(h,n); if(!(v)) return -1; }while(0)
static int f_load(){
 if(full_loaded)return 0;
 fh_cairo=f_open("libcairo.so.2"); if(!fh_cairo)return -101;
 fh_pango=f_open("libpango-1.0.so.0"); if(!fh_pango)return -102;
 fh_pangocairo=f_open("libpangocairo-1.0.so.0"); if(!fh_pangocairo)return -103;
 fh_pangoft2=f_open("libpangoft2-1.0.so.0"); if(!fh_pangoft2)return -104;
 fh_fontconfig=f_open("libfontconfig.so.1"); if(!fh_fontconfig)return -105;
 fh_gobject=f_open("libgobject-2.0.so.0"); if(!fh_gobject)return -106;
 FSYM(f_cairo_image_surface_create,fh_cairo,"cairo_image_surface_create");
 FSYM(f_cairo_svg_surface_create,fh_cairo,"cairo_svg_surface_create");FSYM(f_cairo_pdf_surface_create,fh_cairo,"cairo_pdf_surface_create");
 FSYM(f_cairo_image_surface_create_from_png,fh_cairo,"cairo_image_surface_create_from_png");FSYM(f_cairo_image_surface_get_width,fh_cairo,"cairo_image_surface_get_width");FSYM(f_cairo_image_surface_get_height,fh_cairo,"cairo_image_surface_get_height");
 FSYM(f_cairo_create,fh_cairo,"cairo_create");FSYM(f_cairo_destroy,fh_cairo,"cairo_destroy");FSYM(f_cairo_surface_destroy,fh_cairo,"cairo_surface_destroy");FSYM(f_cairo_surface_finish,fh_cairo,"cairo_surface_finish");FSYM(f_cairo_surface_status,fh_cairo,"cairo_surface_status");FSYM(f_cairo_surface_write_to_png,fh_cairo,"cairo_surface_write_to_png");
 FSYM(f_cairo_set_operator,fh_cairo,"cairo_set_operator");FSYM(f_cairo_set_source_rgba,fh_cairo,"cairo_set_source_rgba");FSYM(f_cairo_paint,fh_cairo,"cairo_paint");FSYM(f_cairo_move_to,fh_cairo,"cairo_move_to");FSYM(f_cairo_line_to,fh_cairo,"cairo_line_to");FSYM(f_cairo_set_line_width,fh_cairo,"cairo_set_line_width");FSYM(f_cairo_set_line_cap,fh_cairo,"cairo_set_line_cap");FSYM(f_cairo_set_line_join,fh_cairo,"cairo_set_line_join");FSYM(f_cairo_stroke,fh_cairo,"cairo_stroke");FSYM(f_cairo_fill,fh_cairo,"cairo_fill");FSYM(f_cairo_save,fh_cairo,"cairo_save");FSYM(f_cairo_restore,fh_cairo,"cairo_restore");FSYM(f_cairo_set_source_surface,fh_cairo,"cairo_set_source_surface");FSYM(f_cairo_translate,fh_cairo,"cairo_translate");FSYM(f_cairo_scale,fh_cairo,"cairo_scale");FSYM(f_cairo_rectangle,fh_cairo,"cairo_rectangle");FSYM(f_cairo_arc,fh_cairo,"cairo_arc");FSYM(f_cairo_close_path,fh_cairo,"cairo_close_path");
 FSYM(f_pango_cairo_create_layout,fh_pangocairo,"pango_cairo_create_layout");FSYM(f_pango_cairo_show_layout,fh_pangocairo,"pango_cairo_show_layout");FSYM(f_pango_cairo_layout_path,fh_pangocairo,"pango_cairo_layout_path");FSYM(f_pango_cairo_font_map_new,fh_pangocairo,"pango_cairo_font_map_new");
 FSYM(f_pango_font_description_new,fh_pango,"pango_font_description_new");FSYM(f_pango_font_description_set_family,fh_pango,"pango_font_description_set_family");FSYM(f_pango_font_description_set_absolute_size,fh_pango,"pango_font_description_set_absolute_size");FSYM(f_pango_font_description_free,fh_pango,"pango_font_description_free");FSYM(f_pango_font_map_create_context,fh_pango,"pango_font_map_create_context");FSYM(f_pango_layout_new,fh_pango,"pango_layout_new");FSYM(f_pango_layout_set_text,fh_pango,"pango_layout_set_text");FSYM(f_pango_layout_set_font_description,fh_pango,"pango_layout_set_font_description");FSYM(f_pango_attr_list_new,fh_pango,"pango_attr_list_new");FSYM(f_pango_attr_font_features_new,fh_pango,"pango_attr_font_features_new");FSYM(f_pango_attr_list_insert,fh_pango,"pango_attr_list_insert");FSYM(f_pango_layout_set_attributes,fh_pango,"pango_layout_set_attributes");FSYM(f_pango_attr_list_unref,fh_pango,"pango_attr_list_unref");FSYM(f_pango_layout_get_pixel_extents,fh_pango,"pango_layout_get_pixel_extents");FSYM(f_pango_layout_get_baseline,fh_pango,"pango_layout_get_baseline");FSYM(f_pango_layout_index_to_pos,fh_pango,"pango_layout_index_to_pos");FSYM(f_pango_fc_font_map_set_config,fh_pangoft2,"pango_fc_font_map_set_config");FSYM(f_FcConfigCreate,fh_fontconfig,"FcConfigCreate");FSYM(f_FcConfigAppFontAddFile,fh_fontconfig,"FcConfigAppFontAddFile");FSYM(f_FcConfigBuildFonts,fh_fontconfig,"FcConfigBuildFonts");FSYM(f_FcConfigDestroy,fh_fontconfig,"FcConfigDestroy");FSYM(f_g_object_unref,fh_gobject,"g_object_unref");
 full_loaded=1;return 0;
}
typedef struct {PangoLayout*l;PangoContext*ctx;PangoFontMap*map;FcConfig*cfg;} full_layout;
static full_layout* f_layout(const char*text,const char*family,const char*fontpath,double size,const char*features){
 full_layout*h=(full_layout*)calloc(1,sizeof(full_layout));if(!h)return NULL;
 h->cfg=f_FcConfigCreate();if(!h->cfg)goto fail;
 if(!f_FcConfigAppFontAddFile(h->cfg,(const FcChar8*)fontpath))goto fail;
 if(!f_FcConfigBuildFonts(h->cfg))goto fail;
 h->map=f_pango_cairo_font_map_new();if(!h->map)goto fail;
 f_pango_fc_font_map_set_config(h->map,h->cfg);
 h->ctx=f_pango_font_map_create_context(h->map);if(!h->ctx)goto fail;
 h->l=f_pango_layout_new(h->ctx);if(!h->l)goto fail;
 PangoFontDescription*d=f_pango_font_description_new();if(!d)goto fail;f_pango_font_description_set_family(d,family);f_pango_font_description_set_absolute_size(d,size*1024.0);f_pango_layout_set_font_description(h->l,d);f_pango_layout_set_text(h->l,text,-1);f_pango_font_description_free(d);
 if(features&&features[0]){PangoAttrList*a=f_pango_attr_list_new();PangoAttribute*x=f_pango_attr_font_features_new(features);if(a&&x){f_pango_attr_list_insert(a,x);f_pango_layout_set_attributes(h->l,a);}if(a)f_pango_attr_list_unref(a);}return h;
 fail: if(h->l)f_g_object_unref(h->l);if(h->ctx)f_g_object_unref(h->ctx);if(h->map)f_g_object_unref(h->map);if(h->cfg)f_FcConfigDestroy(h->cfg);free(h);return NULL;
}
static void f_layout_free(full_layout*h){if(!h)return;if(h->l)f_g_object_unref(h->l);if(h->ctx)f_g_object_unref(h->ctx);if(h->map)f_g_object_unref(h->map);if(h->cfg)f_FcConfigDestroy(h->cfg);free(h);}
static int f_measure(const char*text,const char*family,const char*fontpath,double size,const char*features,int*ix,int*iy,int*iw,int*ih,double*baseline){
 int z=f_load();if(z)return z;full_layout*h=f_layout(text,family,fontpath,size,features);if(!h)return -11;PangoRectangle ink={0},logical={0};f_pango_layout_get_pixel_extents(h->l,&ink,&logical);if(ink.width<=0||ink.height<=0)ink=logical;*ix=ink.x;*iy=ink.y;*iw=ink.width>0?ink.width:1;*ih=ink.height>0?ink.height:1;*baseline=(double)f_pango_layout_get_baseline(h->l)/1024.0;f_layout_free(h);return 0;
}
static int f_caret(const char*text,const char*family,const char*fontpath,double size,const char*features,int byte_index,double*outx){int z=f_load();if(z)return z;full_layout*h=f_layout(text,family,fontpath,size,features);if(!h)return -11;PangoRectangle r={0};f_pango_layout_index_to_pos(h->l,byte_index,&r);*outx=(double)r.x/1024.0;f_layout_free(h);return 0;}

typedef struct {cairo_surface_t*s;cairo_t*cr;int format;char*filename;} full_surface;
static full_surface* f_begin(int width,int height,int format,const char*filename,double br,double bg,double bb,double ba){if(f_load())return NULL;full_surface*h=(full_surface*)calloc(1,sizeof(full_surface));if(!h)return NULL;h->format=format;h->filename=strdup(filename);if(format==0)h->s=f_cairo_image_surface_create(0,width,height);else if(format==1)h->s=f_cairo_svg_surface_create(filename,width,height);else h->s=f_cairo_pdf_surface_create(filename,width,height);if(!h->s||f_cairo_surface_status(h->s)!=0){free(h->filename);free(h);return NULL;}h->cr=f_cairo_create(h->s);f_cairo_set_operator(h->cr,1);f_cairo_set_source_rgba(h->cr,br,bg,bb,ba);f_cairo_paint(h->cr);f_cairo_set_operator(h->cr,2);return h;}
static int f_draw_text(full_surface*h,const char*text,const char*family,const char*fontpath,double size,const char*features,double ox,double oy,double fr,double fg,double fb,double fa,int halo,double hr,double hg,double hb,double ha,double hw){if(!h)return -1;full_layout*l=f_layout(text,family,fontpath,size,features);if(!l)return -2;f_cairo_move_to(h->cr,ox,oy);if(halo&&hw>0){f_pango_cairo_layout_path(h->cr,l->l);f_cairo_set_source_rgba(h->cr,hr,hg,hb,ha);f_cairo_set_line_width(h->cr,2*hw);f_cairo_set_line_join(h->cr,1);f_cairo_stroke(h->cr);f_cairo_move_to(h->cr,ox,oy);}f_cairo_set_source_rgba(h->cr,fr,fg,fb,fa);f_pango_cairo_show_layout(h->cr,l->l);f_layout_free(l);return 0;}
static int f_draw_line(full_surface*h,double x1,double y1,double x2,double y2,double width,double fr,double fg,double fb,double fa,int halo,double hr,double hg,double hb,double ha,double hw){if(!h)return -1;if(halo&&hw>0){f_cairo_move_to(h->cr,x1,y1);f_cairo_line_to(h->cr,x2,y2);f_cairo_set_source_rgba(h->cr,hr,hg,hb,ha);f_cairo_set_line_width(h->cr,width+2*hw);f_cairo_set_line_cap(h->cr,1);f_cairo_stroke(h->cr);}f_cairo_move_to(h->cr,x1,y1);f_cairo_line_to(h->cr,x2,y2);f_cairo_set_source_rgba(h->cr,fr,fg,fb,fa);f_cairo_set_line_width(h->cr,width);f_cairo_set_line_cap(h->cr,1);f_cairo_stroke(h->cr);return 0;}
static int f_draw_butt_line(full_surface*h,double x1,double y1,double x2,double y2,double width,double r,double g,double b,double a){if(!h)return -1;f_cairo_move_to(h->cr,x1,y1);f_cairo_line_to(h->cr,x2,y2);f_cairo_set_source_rgba(h->cr,r,g,b,a);f_cairo_set_line_width(h->cr,width);f_cairo_set_line_cap(h->cr,0);f_cairo_stroke(h->cr);return 0;}
static double f_dmax(double a,double b){return a>b?a:b;}
static double f_dmin(double a,double b){return a<b?a:b;}
static void f_corner_path(full_surface*h,int is_right,double x,double baseline,double fontpx,double runw,double runh,double strokew){double rw=f_dmax(runw,fontpx*0.36),rh=f_dmax(runh,fontpx*0.76),pad=f_dmax(0.5,strokew*0.5),xl=x+pad,xr=x+rw-pad,yt=baseline-rh*0.82;if(!is_right)yt-=f_dmax(4.0,fontpx*0.18);double yb=yt+rh,arm=f_dmax(fontpx*0.26,f_dmin(rw*0.82,fontpx*0.48));if(is_right){f_cairo_move_to(h->cr,xr-arm+strokew*0.5,yb-strokew*0.5);f_cairo_line_to(h->cr,xr-strokew*0.5,yb-strokew*0.5);f_cairo_line_to(h->cr,xr-strokew*0.5,yt+strokew*0.5);}else{f_cairo_move_to(h->cr,xl+strokew*0.5,yb-strokew*0.5);f_cairo_line_to(h->cr,xl+strokew*0.5,yt+strokew*0.5);f_cairo_line_to(h->cr,xl+arm-strokew*0.5,yt+strokew*0.5);}}
static int f_draw_corner_bracket(full_surface*h,int is_right,double x,double baseline,double fontpx,double runw,double runh,double fr,double fg,double fb,double fa,int halo,double hr,double hg,double hb,double ha,double hw){if(!h)return -1;double sw=fontpx<=12.0?f_dmax(1.0,fontpx*0.065):f_dmax(2.5,fontpx*0.065);f_cairo_set_line_cap(h->cr,0);f_cairo_set_line_join(h->cr,0);if(halo&&hw>0){f_corner_path(h,is_right,x,baseline,fontpx,runw,runh,sw);f_cairo_set_source_rgba(h->cr,hr,hg,hb,ha);f_cairo_set_line_width(h->cr,sw+2.0*hw);f_cairo_stroke(h->cr);}f_corner_path(h,is_right,x,baseline,fontpx,runw,runh,sw);f_cairo_set_source_rgba(h->cr,fr,fg,fb,fa);f_cairo_set_line_width(h->cr,sw);f_cairo_stroke(h->cr);return 0;}
static int f_fill_rounded_rect(full_surface*h,double x,double y,double w,double he,double radius,double r,double g,double b,double a){if(!h)return -1;if(w<=0||he<=0)return 0;double rr=radius;if(rr<0)rr=0;if(rr>w/2)rr=w/2;if(rr>he/2)rr=he/2;if(rr<=0){f_cairo_rectangle(h->cr,x,y,w,he);}else{const double pi=3.14159265358979323846;f_cairo_move_to(h->cr,x+rr,y);f_cairo_line_to(h->cr,x+w-rr,y);f_cairo_arc(h->cr,x+w-rr,y+rr,rr,-pi/2,0);f_cairo_line_to(h->cr,x+w,y+he-rr);f_cairo_arc(h->cr,x+w-rr,y+he-rr,rr,0,pi/2);f_cairo_line_to(h->cr,x+rr,y+he);f_cairo_arc(h->cr,x+rr,y+he-rr,rr,pi/2,pi);f_cairo_line_to(h->cr,x,y+rr);f_cairo_arc(h->cr,x+rr,y+rr,rr,pi,3*pi/2);f_cairo_close_path(h->cr);}f_cairo_set_source_rgba(h->cr,r,g,b,a);f_cairo_fill(h->cr);return 0;}
static int f_draw_rect(full_surface*h,double x,double y,double w,double he,double width,double r,double g,double b,double a){if(!h)return -1;f_cairo_rectangle(h->cr,x,y,w,he);f_cairo_set_source_rgba(h->cr,r,g,b,a);f_cairo_set_line_width(h->cr,width);f_cairo_stroke(h->cr);return 0;}
static int f_draw_image(full_surface*h,const char*filename,double x,double y,double w,double he){if(!h)return -1;cairo_surface_t*im=f_cairo_image_surface_create_from_png(filename);if(!im||f_cairo_surface_status(im)!=0){if(im)f_cairo_surface_destroy(im);return -2;}int iw=f_cairo_image_surface_get_width(im),ih=f_cairo_image_surface_get_height(im);if(iw<=0||ih<=0){f_cairo_surface_destroy(im);return -3;}f_cairo_save(h->cr);f_cairo_translate(h->cr,x,y);f_cairo_scale(h->cr,w/iw,he/ih);f_cairo_set_source_surface(h->cr,im,0,0);f_cairo_paint(h->cr);f_cairo_restore(h->cr);f_cairo_surface_destroy(im);return 0;}
static int f_end(full_surface*h){if(!h)return -1;int status=0;if(h->format==0)status=f_cairo_surface_write_to_png(h->s,h->filename);f_cairo_surface_finish(h->s);f_cairo_destroy(h->cr);f_cairo_surface_destroy(h->s);free(h->filename);free(h);return status;}
*/
import "C"

import (
	"fmt"
	"os"
	"strings"
	"unsafe"
)

type fullTextMetrics struct {
	InkX, InkY, InkW, InkH int
	Baseline               float64
}

func fullNativeAvailable() bool { return true }
func featureString(features []string) string {
	p := make([]string, 0, len(features))
	for _, f := range features {
		p = append(p, f+"=1")
	}
	return strings.Join(p, ",")
}
func nativeFullMeasure(text, family, fontPath string, size float64, features []string) (fullTextMetrics, error) {
	ct := C.CString(text)
	defer C.free(unsafe.Pointer(ct))
	cf := C.CString(family)
	defer C.free(unsafe.Pointer(cf))
	cfeat := C.CString(featureString(features))
	defer C.free(unsafe.Pointer(cfeat))
	cp := C.CString(fontPath)
	defer C.free(unsafe.Pointer(cp))
	var x, y, w, h C.int
	var b C.double
	z := int(C.f_measure(ct, cf, cp, C.double(size), cfeat, &x, &y, &w, &h, &b))
	if z != 0 {
		return fullTextMetrics{}, fmt.Errorf("Pango full measure failed (%d)", z)
	}
	return fullTextMetrics{int(x), int(y), int(w), int(h), float64(b)}, nil
}
func nativeFullCaretX(text, family, fontPath string, size float64, features []string, byteIndex int) (float64, error) {
	ct := C.CString(text)
	defer C.free(unsafe.Pointer(ct))
	cf := C.CString(family)
	defer C.free(unsafe.Pointer(cf))
	cfeat := C.CString(featureString(features))
	defer C.free(unsafe.Pointer(cfeat))
	cp := C.CString(fontPath)
	defer C.free(unsafe.Pointer(cp))
	var x C.double
	z := int(C.f_caret(ct, cf, cp, C.double(size), cfeat, C.int(byteIndex), &x))
	if z != 0 {
		return 0, fmt.Errorf("Pango caret failed (%d)", z)
	}
	return float64(x), nil
}

type nativeFullSurface struct {
	h      *C.full_surface
	path   string
	format OutputFormat
}

func rgbaD(c RGBA) (C.double, C.double, C.double, C.double) {
	return C.double(float64(c.R) / 255), C.double(float64(c.G) / 255), C.double(float64(c.B) / 255), C.double(float64(c.A) / 255)
}
func newNativeFullSurface(width, height int, format OutputFormat, bg RGBA) (*nativeFullSurface, error) {
	f, err := os.CreateTemp("", "nanpa_linja_n_go_full_*."+string(format))
	if err != nil {
		return nil, err
	}
	path := f.Name()
	_ = f.Close()
	code := 0
	if format == OutputSVG {
		code = 1
	} else if format == OutputPDF {
		code = 2
	} else if format != OutputPNG {
		return nil, fmt.Errorf("unsupported full format %s", format)
	}
	cp := C.CString(path)
	defer C.free(unsafe.Pointer(cp))
	br, bg1, bb, ba := rgbaD(bg)
	h := C.f_begin(C.int(width), C.int(height), C.int(code), cp, br, bg1, bb, ba)
	if h == nil {
		os.Remove(path)
		return nil, fmt.Errorf("failed to create native full-render surface")
	}
	return &nativeFullSurface{h: h, path: path, format: format}, nil
}
func (s *nativeFullSurface) drawText(text, family, fontPath string, size float64, features []string, ox, oy float64, fg RGBA, halo bool, hc RGBA, hw float64) error {
	ct := C.CString(text)
	defer C.free(unsafe.Pointer(ct))
	cf := C.CString(family)
	defer C.free(unsafe.Pointer(cf))
	cfeat := C.CString(featureString(features))
	defer C.free(unsafe.Pointer(cfeat))
	cp := C.CString(fontPath)
	defer C.free(unsafe.Pointer(cp))
	fr, fg1, fb, fa := rgbaD(fg)
	hr, hg, hb, ha := rgbaD(hc)
	hv := 0
	if halo {
		hv = 1
	}
	z := int(C.f_draw_text(s.h, ct, cf, cp, C.double(size), cfeat, C.double(ox), C.double(oy), fr, fg1, fb, fa, C.int(hv), hr, hg, hb, ha, C.double(hw)))
	if z != 0 {
		return fmt.Errorf("native full draw text failed (%d)", z)
	}
	return nil
}
func (s *nativeFullSurface) drawLine(x1, y1, x2, y2, w float64, fg RGBA, halo bool, hc RGBA, hw float64) error {
	fr, fg1, fb, fa := rgbaD(fg)
	hr, hg, hb, ha := rgbaD(hc)
	hv := 0
	if halo {
		hv = 1
	}
	z := int(C.f_draw_line(s.h, C.double(x1), C.double(y1), C.double(x2), C.double(y2), C.double(w), fr, fg1, fb, fa, C.int(hv), hr, hg, hb, ha, C.double(hw)))
	if z != 0 {
		return fmt.Errorf("draw line failed %d", z)
	}
	return nil
}
func (s *nativeFullSurface) drawButtLine(x1, y1, x2, y2, w float64, c RGBA) error {
	r, g, b, a := rgbaD(c)
	z := int(C.f_draw_butt_line(s.h, C.double(x1), C.double(y1), C.double(x2), C.double(y2), C.double(w), r, g, b, a))
	if z != 0 {
		return fmt.Errorf("draw butt line failed %d", z)
	}
	return nil
}
func (s *nativeFullSurface) drawSyntheticCornerBracket(cp int, x, baseline, fontPx, widthPx, heightPx float64, fg RGBA, halo bool, hc RGBA, hw float64) error {
	if cp != OpenQuoteCodepoint && cp != CloseQuoteCodepoint {
		return fmt.Errorf("unsupported synthetic corner bracket U+%04X", cp)
	}
	fr, fg1, fb, fa := rgbaD(fg)
	hr, hg, hb, ha := rgbaD(hc)
	hv := 0
	if halo {
		hv = 1
	}
	isRight := 0
	if cp == CloseQuoteCodepoint {
		isRight = 1
	}
	z := int(C.f_draw_corner_bracket(s.h, C.int(isRight), C.double(x), C.double(baseline), C.double(fontPx), C.double(widthPx), C.double(heightPx), fr, fg1, fb, fa, C.int(hv), hr, hg, hb, ha, C.double(hw)))
	if z != 0 {
		return fmt.Errorf("draw synthetic corner bracket failed %d", z)
	}
	return nil
}
func (s *nativeFullSurface) fillRoundedRect(x, y, w, h, radius float64, c RGBA) error {
	r, g, b, a := rgbaD(c)
	z := int(C.f_fill_rounded_rect(s.h, C.double(x), C.double(y), C.double(w), C.double(h), C.double(radius), r, g, b, a))
	if z != 0 {
		return fmt.Errorf("fill rounded rect failed %d", z)
	}
	return nil
}
func (s *nativeFullSurface) drawRect(x, y, w, h, lw float64, c RGBA) error {
	r, g, b, a := rgbaD(c)
	z := int(C.f_draw_rect(s.h, C.double(x), C.double(y), C.double(w), C.double(h), C.double(lw), r, g, b, a))
	if z != 0 {
		return fmt.Errorf("draw rect failed %d", z)
	}
	return nil
}
func (s *nativeFullSurface) drawImage(path string, x, y, w, h float64) error {
	cp := C.CString(path)
	defer C.free(unsafe.Pointer(cp))
	z := int(C.f_draw_image(s.h, cp, C.double(x), C.double(y), C.double(w), C.double(h)))
	if z != 0 {
		return fmt.Errorf("draw image failed %d", z)
	}
	return nil
}
func (s *nativeFullSurface) finish() ([]byte, error) {
	if s.h == nil {
		return nil, fmt.Errorf("surface closed")
	}
	z := int(C.f_end(s.h))
	s.h = nil
	defer os.Remove(s.path)
	if z != 0 {
		return nil, fmt.Errorf("native full finish failed %d", z)
	}
	return os.ReadFile(s.path)
}
