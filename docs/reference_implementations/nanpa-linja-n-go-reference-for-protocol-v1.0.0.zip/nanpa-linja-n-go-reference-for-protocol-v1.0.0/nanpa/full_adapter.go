package nanpa

import (
	"fmt"
	"math"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"unicode"
)

type adaptedOrdinary struct {
	Text           string
	CanonicalSpans [][2]int
}
type ordinaryCartouche struct {
	Inner         []int
	ManualTallies []int
	TallyMode     string
}

func (o ordinaryCartouche) hasManualTallies() bool {
	for _, n := range o.ManualTallies {
		if n > 0 {
			return true
		}
	}
	return false
}

func anySettingFloat(m map[string]any, key string, def float64) float64 {
	if v, ok := m[key]; ok {
		switch x := v.(type) {
		case float64:
			return x
		case int:
			return float64(x)
		case jsonNumberLike:
			if f, e := strconv.ParseFloat(string(x), 64); e == nil {
				return f
			}
		}
	}
	return def
}

type jsonNumberLike string

func settingString(m map[string]any, key, def string) string {
	if v, ok := m[key]; ok {
		if s, ok := v.(string); ok && strings.TrimSpace(s) != "" {
			return s
		}
	}
	return def
}
func settingBool(m map[string]any, key string, def bool) bool {
	if v, ok := m[key]; ok {
		if b, ok := v.(bool); ok {
			return b
		}
	}
	return def
}

func legacyOrdinaryWord(cp int, kind string) (string, bool) {
	switch cp {
	case MiddleDotCodepoint:
		return ".", true
	case ColonCodepoint:
		return ":", true
	case 0x3000:
		if kind == "linja-lipamanka" {
			return "zz", true
		}
		return "  ", true
	case 0xF1989:
		if kind == "linja-lipamanka" {
			return "ni<", true
		}
		return "ni", true
	case 0xF198A:
		if kind == "linja-sike" || kind == "linja-lipamanka" {
			return "ni^", true
		}
		return "ni", true
	case 0xF198B:
		if kind == "linja-sike" || kind == "linja-lipamanka" {
			return "ni>", true
		}
		return "ni", true
	case 0xF198C:
		if kind == "linja-sike" {
			return "sewi1", true
		}
		return "sewi", true
	case OpenQuoteCodepoint:
		if kind == "linja-lipamanka" {
			return "te", true
		}
	case CloseQuoteCodepoint:
		if kind == "linja-lipamanka" {
			return "to", true
		}
	}
	w, ok := cpToWord[cp]
	if !ok {
		return "", false
	}
	if kind == "linja-pona" && (cp == 0xF19A2 || cp == 0xF19A4 || cp == 0xF19A5 || cp == 0xF19A6) {
		return "", false
	}
	if kind == "linja-lipamanka" && (cp == 0xF19A4 || cp == 0xF19A5 || cp == 0xF19A6 || cp > 0xF19A3) {
		return "", false
	}
	return w, true
}

func adaptOrdinary(font ProductionFontInfo, inner []int) adaptedOrdinary {
	full := make([]int, 0, len(inner)+2)
	full = append(full, CartoucheStart)
	full = append(full, inner...)
	full = append(full, CartoucheEnd)
	rid := font.RenderAdapterID
	if rid == "" {
		rid = "identity"
	}
	identity := func() adaptedOrdinary {
		var b strings.Builder
		sp := make([][2]int, len(full))
		idx := 0
		for i, cp := range full {
			st := idx
			b.WriteRune(rune(cp))
			idx += utf8RuneLen(cp)
			sp[i] = [2]int{st, idx}
		}
		return adaptedOrdinary{b.String(), sp}
	}
	if rid == "linja-pona-legacy-v1" || rid == "linja-sike-legacy-v1" {
		kind := "linja-pona"
		if strings.HasPrefix(rid, "linja-sike") {
			kind = "linja-sike"
		}
		out := "["
		sp := make([][2]int, len(full))
		sp[0] = [2]int{0, 1}
		for i, cp := range full[1 : len(full)-1] {
			st := len([]rune(out))
			w, ok := legacyOrdinaryWord(cp, kind)
			if !ok {
				w = "�"
			}
			out += "_" + w
			sp[i+1] = [2]int{st, len([]rune(out))}
		}
		st := len([]rune(out))
		out += "]"
		sp[len(sp)-1] = [2]int{st, len([]rune(out))}
		return adaptedOrdinary{out, sp}
	}
	if rid == "nasin-sitelen-pu-mono-v1" {
		vals := make([]int, len(full))
		replacement := 0xFFFD
		if v, ok := font.RenderAdapterSettings["unsupportedReplacementCodepoint"].(float64); ok {
			replacement = int(v)
		}
		for i, cp := range full {
			switch {
			case cp == 0xF1989 || cp == 0xF198A || cp == 0xF198B:
				vals[i] = 0xF1941
			case cp == 0xF198C:
				vals[i] = 0xF195A
			case cp == MiddleDotCodepoint:
				vals[i] = '.'
			case cp == ColonCodepoint:
				vals[i] = ':'
			case (cp >= 0xF1900 && cp <= 0xF1988) || (cp >= 0xF19A0 && cp <= 0xF19A3) || cp == CartoucheStart || cp == CartoucheEnd || cp == 0x3000 || cp == OpenQuoteCodepoint || cp == CloseQuoteCodepoint:
				vals[i] = cp
			default:
				vals[i] = replacement
			}
		}
		var b strings.Builder
		sp := make([][2]int, len(vals))
		idx := 0
		for i, cp := range vals {
			st := idx
			b.WriteRune(rune(cp))
			idx++
			sp[i] = [2]int{st, idx}
		}
		return adaptedOrdinary{b.String(), sp}
	}
	if rid == "linja-lipamanka-v1" {
		needs := func(cp int) bool {
			return cp == MiddleDotCodepoint || cp == ColonCodepoint || cp == TallyCodepoint || cp == 0xF1989 || cp == 0xF198A || cp == 0xF198B || cp == 0xF198C || cp == OpenQuoteCodepoint || cp == CloseQuoteCodepoint || cp == 0x3000 || cp == 0xF19A4 || cp == 0xF19A5 || cp == 0xF19A6 || cp > 0xF19A3
		}
		any := false
		for _, cp := range full {
			if needs(cp) {
				any = true
				break
			}
		}
		if any {
			out := "["
			sp := make([][2]int, len(full))
			sp[0] = [2]int{0, 1}
			for i, cp := range full[1 : len(full)-1] {
				if i > 0 {
					out += " "
				}
				st := len([]rune(out))
				w, ok := legacyOrdinaryWord(cp, "linja-lipamanka")
				if !ok {
					w = "�"
				}
				out += w
				sp[i+1] = [2]int{st, len([]rune(out))}
			}
			st := len([]rune(out))
			out += "]"
			sp[len(sp)-1] = [2]int{st, len([]rune(out))}
			return adaptedOrdinary{out, sp}
		}
	}
	return identity()
}
func utf8RuneLen(cp int) int { return 1 }

func parseOrdinaryBody(body string, font ProductionFontInfo, p FullParserOptions) (ordinaryCartouche, bool) {
	body = strings.TrimSpace(body)
	if body == "" {
		return ordinaryCartouche{}, false
	}
	mode := strings.ToLower(strings.TrimSpace(p.CartoucheTallyMode))
	if mode == "" {
		mode = strings.ToLower(settingString(font.Settings, "cartoucheTallyMode", "ucsur"))
	}
	if mode != "manual" && mode != "comma" && mode != "ucsur" {
		mode = "ucsur"
	}
	cps := []int{}
	tallies := []int{}
	var cur strings.Builder
	flush := func() bool {
		if cur.Len() == 0 {
			return true
		}
		tok := strings.ToLower(strings.TrimSpace(cur.String()))
		cur.Reset()
		if tok == "" {
			return true
		}
		cp, ok := wordToCP[tok]
		if !ok {
			return false
		}
		if cp == TallyCodepoint && mode == "manual" {
			if len(cps) > 0 {
				tallies[len(tallies)-1] = minInt(8, tallies[len(tallies)-1]+1)
			}
			return true
		}
		cps = append(cps, cp)
		tallies = append(tallies, 0)
		return true
	}
	for _, ch := range body {
		switch {
		case unicode.IsSpace(ch):
			if !flush() {
				return ordinaryCartouche{}, false
			}
		case ch == '.' || ch == '·' || ch == ':':
			if !flush() {
				return ordinaryCartouche{}, false
			}
			if ch == ':' {
				cps = append(cps, ColonCodepoint)
			} else {
				cps = append(cps, MiddleDotCodepoint)
			}
			tallies = append(tallies, 0)
		case ch == ',':
			if !flush() {
				return ordinaryCartouche{}, false
			}
			if !effectiveCommaTallyMarks(p) {
				continue
			}
			switch mode {
			case "manual":
				if len(cps) > 0 {
					tallies[len(tallies)-1] = minInt(8, tallies[len(tallies)-1]+1)
				}
			case "comma":
				cps = append(cps, int(','))
				tallies = append(tallies, 0)
			default:
				cps = append(cps, TallyCodepoint)
				tallies = append(tallies, 0)
			}
		default:
			cur.WriteRune(ch)
		}
	}
	if !flush() || len(cps) == 0 {
		return ordinaryCartouche{}, false
	}
	return ordinaryCartouche{cps, tallies, mode}, true
}
func minInt(a, b int) int {
	if a < b {
		return a
	}
	return b
}

var lettersOnly = regexp.MustCompile(`^[A-Za-z]+$`)

func properNameCodepoints(word string) ([]int, bool) {
	if !lettersOnly.MatchString(word) {
		return nil, false
	}
	allowed := "aeijklmnostpuw"
	for _, c := range strings.ToLower(word) {
		if !strings.ContainsRune(allowed, c) {
			return nil, false
		}
	}
	keys := make([]string, 0, len(wordToCP))
	for w := range wordToCP {
		if regexp.MustCompile(`^[a-z]+$`).MatchString(w) {
			keys = append(keys, w)
		}
	}
	sort.Strings(keys)
	bucket := map[byte]int{}
	for _, w := range keys {
		if _, ok := bucket[w[0]]; !ok {
			bucket[w[0]] = wordToCP[w]
		}
	}
	out := []int{}
	for i := 0; i < len(word); i++ {
		cp, ok := bucket[strings.ToLower(word)[i]]
		if !ok {
			return nil, false
		}
		out = append(out, cp)
	}
	return out, true
}

// lettersToFallbackGlyphCps mirrors the canonical renderer's final bracket
// fallback: strip non-letters, then choose a valid Toki Pona glyph from the
// bucket for each Latin initial. The JavaScript authority chooses randomly;
// this reference uses a stable first member so tests and render plans remain
// reproducible while preserving the same accepted letter buckets.
func lettersToFallbackGlyphCps(source string) []int {
	banned := map[string]bool{"ota": true, "kolon": true, "koma": true, "te": true, "to": true, "zz": true}
	keys := make([]string, 0, len(wordToCP))
	for w := range wordToCP {
		if banned[w] || !regexp.MustCompile(`^[a-z]+$`).MatchString(w) {
			continue
		}
		keys = append(keys, w)
	}
	sort.Strings(keys)
	bucket := map[byte]int{}
	for _, w := range keys {
		if _, ok := bucket[w[0]]; !ok {
			bucket[w[0]] = wordToCP[w]
		}
	}
	out := []int{}
	for i := 0; i < len(source); i++ {
		b := source[i]
		if b >= 'A' && b <= 'Z' {
			b += 'a' - 'A'
		}
		if b < 'a' || b > 'z' {
			continue
		}
		if cp, ok := bucket[b]; ok {
			out = append(out, cp)
		}
	}
	return out
}

func nnpWords(digits string) []string {
	n, err := strconv.Atoi(digits)
	if err != nil || n < 0 {
		return nil
	}
	out := []string{}
	var enc func(int)
	enc = func(x int) {
		if x == 0 {
			out = append(out, "ala")
			return
		}
		if x >= 100 {
			q, r := x/100, x%100
			enc(q)
			out = append(out, "ali")
			if r > 0 {
				enc(r)
			}
			return
		}
		for x >= 20 {
			out = append(out, "mute")
			x -= 20
		}
		if x >= 5 {
			out = append(out, "luka")
			x -= 5
		}
		for x >= 2 {
			out = append(out, "tu")
			x -= 2
		}
		if x > 0 {
			out = append(out, "wan")
		}
	}
	enc(n)
	return out
}

func manualTallyLift(font ProductionFontInfo, p FullParserOptions, px float64) float64 {
	maxv := settingFloat(font.Settings, "manualTallySmallFontMaxPx", 12)
	if p.ManualTallySmallFontMaxPx != nil {
		maxv = *p.ManualTallySmallFontMaxPx
	}
	lift := settingFloat(font.Settings, "manualTallySmallFontLiftPx", 0)
	if p.ManualTallySmallFontLiftPx != nil {
		lift = *p.ManualTallySmallFontLiftPx
	}
	if px <= maxv {
		return math.Max(0, lift)
	}
	return 0
}
func settingFloat(m map[string]any, key string, def float64) float64 {
	if v, ok := m[key]; ok {
		switch x := v.(type) {
		case float64:
			return x
		case float32:
			return float64(x)
		case int:
			return float64(x)
		case int64:
			return float64(x)
		case string:
			if f, e := strconv.ParseFloat(x, 64); e == nil {
				return f
			}
		}
	}
	return def
}

func openTypeFeaturesFor(px float64) []string {
	if px <= 18 {
		return []string{"ss12"}
	}
	if px <= 29 {
		return []string{"ss13"}
	}
	return nil
}
func allRunesUcsur(s string) bool {
	if s == "" {
		return false
	}
	for _, r := range s {
		cp := int(r)
		if !((cp >= 0xF1900 && cp <= 0xF19FF) || cp == OpenQuoteCodepoint || cp == CloseQuoteCodepoint) {
			return false
		}
	}
	return true
}
func sanitizeWord(s string) string {
	var b strings.Builder
	for _, r := range strings.ToLower(s) {
		if (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') || strings.ContainsRune("<>^.", r) {
			b.WriteRune(r)
		}
	}
	return b.String()
}
func intPtr(v int) *int { return &v }
func validateScalar(cp int) error {
	if cp < 0 || cp > 0x10FFFF {
		return fmt.Errorf("invalid scalar U+%X", cp)
	}
	return nil
}

// splitFullCanonicalCells mirrors the canonical JavaScript full-renderer cell
// decomposition used by the built-in production-font adapters. Joiners stay
// attached to their owning glyph cell; long/cartouche extension controls are
// control-only cells.
type fullCanonicalCell struct {
	Cps         []int
	ControlOnly bool
}

func fullAdapterControlOnly(cp int) bool {
	switch cp {
	case 0xF1992, 0xF1993, 0xF1994, 0xF1997, 0xF1998, 0xF1999, 0xF199A, 0xF199B:
		return true
	default:
		return false
	}
}

func fullAdapterJoiner(cp int) bool {
	return cp == 0x200D || cp == StackJoinerCodepoint || cp == NestJoinerCodepoint
}

func splitFullCanonicalCells(cps []int, start, end int) []fullCanonicalCell {
	var cells []fullCanonicalCell
	for i := start; i < end; {
		cp := cps[i]
		if fullAdapterControlOnly(cp) {
			cells = append(cells, fullCanonicalCell{Cps: []int{cp}, ControlOnly: true})
			i++
			continue
		}
		cell := []int{cp}
		i++
		for i+1 < end && fullAdapterJoiner(cps[i]) {
			cell = append(cell, cps[i], cps[i+1])
			i += 2
		}
		cells = append(cells, fullCanonicalCell{Cps: cell})
	}
	return cells
}

func fullLegacyWordEncoding(cp int, kind string, font ProductionFontInfo) string {
	// The shared cartouche helper already contains the production word aliases
	// and alternative-glyph fallback rules used by the canonical renderer.
	if cp == OpenQuoteCodepoint || cp == CloseQuoteCodepoint {
		if mode, _ := font.RenderAdapterSettings["cornerBracketMode"].(string); strings.EqualFold(mode, "synthetic") {
			return string(rune(cp))
		}
	}
	if w, ok := legacyOrdinaryWord(cp, kind); ok {
		return w
	}
	return "�"
}

func appendFullLegacyCell(b *strings.Builder, cell fullCanonicalCell, kind string, font ProductionFontInfo) {
	if cell.ControlOnly || len(cell.Cps) == 0 {
		return
	}
	for i := 0; i < len(cell.Cps); {
		b.WriteString(fullLegacyWordEncoding(cell.Cps[i], kind, font))
		i++
		if i < len(cell.Cps) {
			joiner := cell.Cps[i]
			op := "-"
			if kind == "linja-lipamanka" {
				switch joiner {
				case StackJoinerCodepoint:
					op = "+"
				case NestJoinerCodepoint:
					op = "-"
				default:
					if v, ok := font.RenderAdapterSettings["genericCompoundOperator"].(string); ok && v != "" {
						op = v[:1]
					}
				}
			}
			b.WriteString(op)
			i++
		}
	}
}

func findFullCurrentLong(cps []int) (head, start, end int, ok bool) {
	start = -1
	for i, cp := range cps {
		if cp == 0xF1997 {
			start = i
			break
		}
	}
	if start <= 0 {
		return 0, 0, 0, false
	}
	end = -1
	for i := start + 1; i < len(cps); i++ {
		if cps[i] == 0xF1998 {
			end = i
			break
		}
	}
	if end < 0 {
		return 0, 0, 0, false
	}
	return start - 1, start, end, true
}

func hasFullReverseLong(cps []int) bool {
	for _, cp := range cps {
		if cp == 0xF199A || cp == 0xF199B {
			return true
		}
	}
	return false
}

func adaptLegacyFullWordRun(font ProductionFontInfo, cps []int, kind string) []int {
	if head, start, end, ok := findFullCurrentLong(cps); ok && !hasFullReverseLong(cps) && cps[head] == wordToCP["pi"] {
		cells := splitFullCanonicalCells(cps, start+1, end)
		var usable []fullCanonicalCell
		for _, c := range cells {
			if !c.ControlOnly {
				usable = append(usable, c)
			}
		}
		maxCells := 3
		if v, ok := font.RenderAdapterSettings["maxLongPiCells"].(float64); ok && int(v) > 0 {
			maxCells = int(v)
		}
		if len(usable) >= 1 && len(usable) <= maxCells {
			var b strings.Builder
			b.WriteString("pi")
			if kind == "linja-pona" {
				b.WriteString(strings.Repeat("+", len(usable)))
				for i, c := range usable {
					if i > 0 {
						b.WriteByte(' ')
					}
					appendFullLegacyCell(&b, c, kind, font)
				}
			} else {
				b.WriteByte('+')
				for _, c := range usable {
					b.WriteString("__")
					appendFullLegacyCell(&b, c, kind, font)
				}
			}
			return runesToInts(b.String())
		}
	}

	var b strings.Builder
	for _, cell := range splitFullCanonicalCells(cps, 0, len(cps)) {
		appendFullLegacyCell(&b, cell, kind, font)
	}
	return runesToInts(b.String())
}

func adaptNasinSitelenPuMonoFullRun(font ProductionFontInfo, cps []int) []int {
	replacement := 0xFFFD
	if v, ok := font.RenderAdapterSettings["unsupportedReplacementCodepoint"].(float64); ok {
		replacement = int(v)
	}
	out := make([]int, 0, len(cps))
	for _, cp := range cps {
		if fullAdapterJoiner(cp) || fullAdapterControlOnly(cp) {
			continue
		}
		switch {
		case cp == 0xF1989 || cp == 0xF198A || cp == 0xF198B:
			out = append(out, 0xF1941)
		case cp == 0xF198C:
			out = append(out, 0xF195A)
		case cp == MiddleDotCodepoint:
			out = append(out, '.')
		case cp == ColonCodepoint:
			out = append(out, ':')
		case (cp >= 0xF1900 && cp <= 0xF1988) || (cp >= 0xF19A0 && cp <= 0xF19A3) || cp == CartoucheStart || cp == CartoucheEnd || cp == 0x3000 || cp == OpenQuoteCodepoint || cp == CloseQuoteCodepoint:
			out = append(out, cp)
		default:
			out = append(out, replacement)
		}
	}
	return out
}

func lipamankaFullNeedsTranslation(cps []int, font ProductionFontInfo) bool {
	// Mirror canonical linjaLipamankaAdapter semantics exactly. Current long
	// controls are supported natively for pi/lon and do not by themselves force
	// ASCII translation; reverse-long controls always do.
	for _, cp := range cps {
		if fullAdapterJoiner(cp) || cp == MiddleDotCodepoint || cp == ColonCodepoint || cp == TallyCodepoint || cp == 0xF1989 || cp == 0xF198A || cp == 0xF198B || cp == 0xF198C || cp == OpenQuoteCodepoint || cp == CloseQuoteCodepoint || cp == 0x3000 || cp >= 0xF19A4 {
			return true
		}
	}
	if hasFullReverseLong(cps) {
		return true
	}
	if head, _, _, ok := findFullCurrentLong(cps); ok {
		return cps[head] != wordToCP["pi"] && cps[head] != wordToCP["lon"]
	}
	return false
}

func adaptLinjaLipamankaFullRun(font ProductionFontInfo, cps []int) []int {
	if !lipamankaFullNeedsTranslation(cps, font) {
		return append([]int(nil), cps...)
	}
	if head, start, end, ok := findFullCurrentLong(cps); ok && !hasFullReverseLong(cps) && (cps[head] == wordToCP["pi"] || cps[head] == wordToCP["lon"]) {
		var b strings.Builder
		b.WriteString(fullLegacyWordEncoding(cps[head], "linja-lipamanka", font))
		b.WriteByte('(')
		cells := splitFullCanonicalCells(cps, start+1, end)
		first := true
		for _, c := range cells {
			if c.ControlOnly {
				continue
			}
			if !first {
				b.WriteByte(' ')
			}
			first = false
			appendFullLegacyCell(&b, c, "linja-lipamanka", font)
		}
		b.WriteByte(')')
		return runesToInts(b.String())
	}
	var b strings.Builder
	for _, c := range splitFullCanonicalCells(cps, 0, len(cps)) {
		appendFullLegacyCell(&b, c, "linja-lipamanka", font)
	}
	return runesToInts(b.String())
}

func adaptBuiltinFullWordRun(font ProductionFontInfo, cps []int) []int {
	switch font.RenderAdapterID {
	case "linja-pona-legacy-v1":
		return adaptLegacyFullWordRun(font, cps, "linja-pona")
	case "linja-sike-legacy-v1":
		return adaptLegacyFullWordRun(font, cps, "linja-sike")
	case "nasin-sitelen-pu-mono-v1":
		return adaptNasinSitelenPuMonoFullRun(font, cps)
	case "linja-lipamanka-v1":
		return adaptLinjaLipamankaFullRun(font, cps)
	default:
		return append([]int(nil), cps...)
	}
}
