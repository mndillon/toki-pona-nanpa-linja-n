package nanpa

import (
	"bytes"
	"image"
	"testing"
)

func TestFullRendererMixedDocumentAndFormats(t *testing.T) {
	if !fullNativeAvailable() {
		t.Skip("full native renderer requires Linux+cgo")
	}
	n, err := CreateNanpaLinjaN()
	if err != nil {
		t.Fatal(err)
	}
	defer n.Close()
	p, err := n.BuildFullRenderPlan(`mi toki e ni: [jan pona,,] 123.45 "Hello"`)
	if err != nil {
		t.Fatal(err)
	}
	roles := map[string]bool{}
	for _, r := range p.Runs {
		roles[r.FontRole] = true
	}
	for _, r := range []string{"word", "cartouche", "number", "literal"} {
		if !roles[r] {
			t.Fatalf("missing role %s: %#v", r, roles)
		}
	}
	if p.LineCount() != 1 {
		t.Fatalf("line count %d", p.LineCount())
	}
	c, err := n.RenderToCanvas(`jan [pona,,] 123.45`)
	if err != nil {
		t.Fatal(err)
	}
	if c.Width() <= 0 || c.Height() <= 0 || c.Plan == nil {
		t.Fatalf("bad canvas %#v", c)
	}
	png, err := n.RenderFullToPNG(`jan [pona,,] 123.45`)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.HasPrefix(png, []byte{137, 80, 78, 71, 13, 10, 26, 10}) {
		t.Fatal("bad PNG")
	}
	svg, err := n.RenderFullToSVG(`jan [pona,,] 123.45`)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Contains(svg, []byte("<svg")) {
		t.Fatal("bad SVG")
	}
	pdf, err := n.RenderFullToPDF(`jan [pona,,] 123.45`)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.HasPrefix(pdf, []byte("%PDF-")) {
		t.Fatal("bad PDF")
	}
}

func TestFullRendererManualTallies(t *testing.T) {
	if !fullNativeAvailable() {
		t.Skip("full native renderer requires Linux+cgo")
	}
	n, err := CreateNanpaLinjaN()
	if err != nil {
		t.Fatal(err)
	}
	defer n.Close()
	expected := map[string]float64{"nasinNanpa": 118.000, "linjaPona": 92.804, "linjaSike": 91.196, "nasinSitelenPuMono": 94.612, "linjaLipamanka": 121.000}
	for font, want := range expected {
		t.Run(font, func(t *testing.T) {
			o := DefaultFullRenderOptions()
			o.Font = font
			p, err := n.BuildFullRenderPlan("[jan pona,,]", o)
			if err != nil {
				t.Fatal(err)
			}
			if len(p.Runs) != 1 {
				t.Fatalf("runs %d", len(p.Runs))
			}
			r := p.Runs[0]
			for _, cp := range r.RenderCodepoints {
				if cp == TallyCodepoint {
					t.Fatalf("manual tally entered font run")
				}
			}
			if len(r.ManualTallies) != 2 || r.ManualTallies[0] != 0 || r.ManualTallies[1] != 2 {
				t.Fatalf("tallies %#v", r.ManualTallies)
			}
			if len(r.TallyGroups) != 1 {
				t.Fatalf("groups %#v", r.TallyGroups)
			}
			got := r.TallyGroups[0].CenterXPx - r.XPx
			t.Logf("center %.3f want %.3f", got, want)
			if d := got - want; d > 1.5 || d < -1.5 {
				t.Fatalf("center %.3f want %.3f", got, want)
			}
		})
	}
}

func TestFullRendererUCSURTallyFonts(t *testing.T) {
	if !fullNativeAvailable() {
		t.Skip("full native renderer requires Linux+cgo")
	}
	n, _ := CreateNanpaLinjaN()
	defer n.Close()
	for _, font := range []string{"sitelenSeliKiwen", "fairfaxHd", "fairfaxPonaHd"} {
		o := DefaultFullRenderOptions()
		o.Font = font
		p, e := n.BuildFullRenderPlan("[jan pona,,]", o)
		if e != nil {
			t.Fatal(e)
		}
		r := p.Runs[0]
		found := false
		for _, cp := range r.RenderCodepoints {
			if cp == TallyCodepoint {
				found = true
			}
		}
		if !found {
			t.Fatalf("%s did not retain tally", font)
		}
		if len(r.TallyGroups) != 0 {
			t.Fatalf("%s synthetic tally", font)
		}
	}
}

func TestFullRendererLowLevelOperations(t *testing.T) {
	if !fullNativeAvailable() {
		t.Skip("full native renderer requires Linux+cgo")
	}
	n, _ := CreateNanpaLinjaN()
	defer n.Close()
	ast := n.ParseInput("jan [pona] 123")
	if ast.Type != "document" || len(ast.Lines) != 1 {
		t.Fatal("AST")
	}
	p, e := n.BuildFullRenderPlan("jan [pona] 123")
	if e != nil {
		t.Fatal(e)
	}
	var word *FullRenderRun
	for i := range p.Runs {
		if p.Runs[i].FontRole == "word" {
			word = &p.Runs[i]
			break
		}
	}
	if word == nil {
		t.Fatal("word")
	}
	c, e := n.RenderRunToNewCanvas(*word)
	if e != nil || c.Width() <= 0 {
		t.Fatalf("run canvas %v", e)
	}
	c, e = n.RenderTextToNewCanvas("jan pona")
	if e != nil || c.Width() <= 0 {
		t.Fatalf("text canvas %v", e)
	}
	target := image.NewRGBA(image.Rect(0, 0, 400, 200))
	if _, e = n.RenderTextToCanvas(target, 5, 5, "jan pona"); e != nil {
		t.Fatal(e)
	}
	uc, e := n.RenderUcsurToNewCanvas([][]int{{0xF1911, 0xF1954}, {0xF196C}})
	if e != nil || uc.Width() <= 0 {
		t.Fatalf("ucsur %v", e)
	}
	vd, e := n.ToVectorDocument("jan [pona,,] 123.45")
	if e != nil || len(vd.Elements) == 0 {
		t.Fatalf("vector %v", e)
	}
}
