package nanpa

import (
	"strings"
	"testing"
)

func TestAstToTextNumericBaseline(t *testing.T) {
	n, err := CreateNanpaLinjaN()
	if err != nil {
		t.Fatal(err)
	}
	defer n.Close()

	production := DefaultProductionOptions()
	parsed, err := ParseNumber("123", production)
	if err != nil {
		t.Fatal(err)
	}
	if parsed.DisplayValue != "123" || parsed.ProperName != "Nanpa Watusen" || parsed.UniqueCode != "#~WTS" {
		t.Fatalf("public alternatives mismatch: %+v", parsed)
	}
	if got := strings.Join(parsed.AbbreviatedWords, " "); got != "nanpa : wan tu seli nanpa" {
		t.Fatalf("abbreviatedWords %q", got)
	}

	for _, source := range []string{
		"12 34", "12 .34", "12. 34", "12 %", "1 e8", "1 *10^8",
		"1* 10^8", "1 * 10 ^ 8", "1 /2", "1/ 2", "1 +1/2", "1+ 1/2",
		"2026- 09-20", "12: 30",
	} {
		if _, err := ParseNumber(source, production); err == nil {
			t.Fatalf("internal whitespace accepted: %q", source)
		}
	}
	outer, err := ParseNumber("  1234  ", production)
	if err != nil || outer.DisplayValue != "1234" {
		t.Fatalf("outer whitespace: result=%+v err=%v", outer, err)
	}
	proper, err := ParseNumber("Nanpa Wan Eke Tusenan Eke Lunumun", production)
	if err != nil || proper.DisplayValue != "1,234,567" {
		t.Fatalf("proper-name spaces: result=%+v err=%v", proper, err)
	}
	cartOpts := production
	cartOpts.AbbreviateNumericCartouches = true
	cart, err := ParseNumber("[nanpa : wan tu seli nanpa]", cartOpts)
	if err != nil || cart.DisplayValue != "123" {
		t.Fatalf("cartouche spaces: result=%+v err=%v", cart, err)
	}

	nnpOpts := production
	nnpOpts.NasinNanpaPona = true
	nnp, err := ParseNumber("123", nnpOpts)
	if err != nil || strings.Join(nnp.NasinNanpaPonaWords, " ") != "wan ale mute tu wan" {
		t.Fatalf("nasin nanpa pona words: result=%+v err=%v", nnp, err)
	}

	ast := n.ParseInput("toki&pona 123 456 zz pi(telo lete) te tomo to")
	if len(ast.Lines) != 1 || len(ast.Lines[0].Children) != 1 {
		t.Fatalf("unexpected AST shape: %+v", ast)
	}
	structures := ast.Lines[0].Children[0].NumericStructures
	if len(structures) != 2 || structures[0].SourceText != "123" || structures[1].SourceText != "456" {
		t.Fatalf("numeric structures: %+v", structures)
	}

	checkOutput := func(mode, want string, mutate func(*FullRenderOptions)) {
		t.Helper()
		o := DefaultFullRenderOptions()
		o.NumericOutput = mode
		if mutate != nil {
			mutate(&o)
		}
		got, err := n.AstToText(ast, o)
		if err != nil {
			t.Fatal(err)
		}
		if got != want {
			t.Fatalf("%s got %q want %q", mode, got, want)
		}
	}
	checkOutput("source", "toki&pona 123 456 zz pi(telo lete) te tomo to", nil)
	checkOutput("properName", "toki&pona Nanpa Watusen Nanpa Nalunun zz pi(telo lete) te tomo to", nil)
	checkOutput("#~", "toki&pona #~WTS #~ALU zz pi(telo lete) te tomo to", nil)
	checkOutput("cartouche", "toki&pona [nanpa : wan ala tu uta seli e nanpa] [nanpa : nena awen luka uta nena utala nanpa] zz pi(telo lete) te tomo to", nil)
	checkOutput("cartouche", "toki&pona [nanpa : wan tu seli nanpa] [nanpa : awen luka utala nanpa] zz pi(telo lete) te tomo to", func(o *FullRenderOptions) {
		o.Parser.AbbreviateNumericCartouches = true
		o.Parser.PreserveNumericCartoucheBreaks = true
	})
	checkOutput("cartouche", "toki&pona wan ale mute tu wan tu tu ale mute mute luka luka luka wan zz pi(telo lete) te tomo to", func(o *FullRenderOptions) {
		o.Parser.NasinNanpaPona = true
	})
	checkOutput("#~", "toki&pona wan ale mute tu wan tu tu ale mute mute luka luka luka wan zz pi(telo lete) te tomo to", func(o *FullRenderOptions) {
		o.Parser.NasinNanpaPona = true
	})

	mixed := n.ParseInput("1+1/2")
	mixedOptions := DefaultFullRenderOptions()
	mixedOptions.NumericOutput = "cartouche"
	mixedOptions.Parser.AbbreviateNumericCartouches = true
	mixedOptions.Parser.PreserveNumericCartoucheBreaks = true
	mixedText, err := n.AstToText(mixed, mixedOptions)
	if err != nil || mixedText != "[nanpa : wan kin wan o o tu nanpa]" {
		t.Fatalf("mixed fraction got %q err=%v", mixedText, err)
	}

	fallbackOptions := DefaultFullRenderOptions()
	fallbackOptions.NumericOutput = "#~"
	fallback := n.ParseInput("#ABC 0b1010", fallbackOptions)
	fallbackText, err := n.AstToText(fallback, fallbackOptions)
	if err != nil || fallbackText != "#ABC 0b1010" {
		t.Fatalf("#~ fallback got %q err=%v", fallbackText, err)
	}

	multi := DocumentAST{
		Type:          "document",
		ParserOptions: DefaultFullParserOptions(),
		Lines: []DocumentLine{{SourceLineIndex: 0, Children: []DocumentSegment{{
			Kind: "text", Value: "a 123 b 45 c",
			NumericStructures: []NumericStructure{{Index: 2, End: 5, SourceText: "123"}, {Index: 8, End: 10, SourceText: "45"}},
		}}}},
	}
	multiOptions := DefaultFullRenderOptions()
	multiOptions.NumericOutput = "#~"
	multiText, err := n.AstToText(multi, multiOptions)
	if err != nil || multiText != "a #~WTS b #~AL c" {
		t.Fatalf("multiple structures got %q err=%v", multiText, err)
	}

	stale := DocumentAST{
		Type:          "document",
		ParserOptions: DefaultFullParserOptions(),
		Lines: []DocumentLine{{SourceLineIndex: 0, Children: []DocumentSegment{{
			Kind: "text", Value: "124", NumericStructures: []NumericStructure{{Index: 0, End: 3, SourceText: "123"}},
		}}}},
	}
	staleOptions := DefaultFullRenderOptions()
	staleOptions.NumericOutput = "properName"
	staleText, err := n.AstToText(stale, staleOptions)
	if err != nil || staleText != "124" {
		t.Fatalf("stale metadata got %q err=%v", staleText, err)
	}

	raw := DocumentAST{Type: "document", Lines: []DocumentLine{{SourceLineIndex: 0, Children: []DocumentSegment{{Kind: "rawUcsur", Codepoints: []int{0xF1900, 0x1F600}}}}}}
	rawText, err := n.AstToText(raw)
	if err != nil || rawText != "U+F1900 U+1F600" {
		t.Fatalf("raw UCSUR got %q err=%v", rawText, err)
	}
	invalidRaw := DocumentAST{Type: "document", Lines: []DocumentLine{{SourceLineIndex: 0, Children: []DocumentSegment{{Kind: "rawUcsur", Codepoints: []int{0xD800}}}}}}
	if _, err := n.AstToText(invalidRaw); err == nil {
		t.Fatal("invalid raw UCSUR code point accepted")
	}

	badMode := DefaultFullRenderOptions()
	badMode.NumericOutput = "abbreviation"
	if _, err := n.AstToText(ast, badMode); err == nil || !strings.Contains(err.Error(), "unsupported numericOutput mode") {
		t.Fatalf("unsupported numericOutput result err=%v", err)
	}
}
