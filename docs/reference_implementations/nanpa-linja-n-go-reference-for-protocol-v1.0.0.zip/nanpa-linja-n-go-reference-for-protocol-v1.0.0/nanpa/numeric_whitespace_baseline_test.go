package nanpa

import "testing"

func TestNumericWhitespaceBaseline(t *testing.T) {
	opts := Options{
		Mode:                        "uniform",
		MixedStyle:                  "short",
		RelaxedNanpaLinjanParsing:   true,
		RelaxedNanpaLinjanRendering: true,
		NanpaColonParsing:           true,
		NanpaColonRendering:         true,
		EnableHexParsing:            true,
		EnableBinaryParsing:         true,
	}

	for _, input := range []string{"12 34", "12 .34", "12 %", "1 e8", "1 /2", "2026- 09-20", "1 1/2"} {
		t.Run("reject_"+input, func(t *testing.T) {
			if _, err := ParseNumber(input, opts); err == nil {
				t.Fatalf("ParseNumber(%q) accepted internal whitespace", input)
			}
		})
	}

	for _, input := range []string{"12 34", "1 1/2"} {
		t.Run("encode_reject_"+input, func(t *testing.T) {
			if _, err := EncodeDecimal(input, opts); err == nil {
				t.Fatalf("EncodeDecimal(%q) accepted internal whitespace", input)
			}
		})
	}

	if _, err := ParseNumber("1+1/2", opts); err != nil {
		t.Fatalf("valid mixed fraction rejected: %v", err)
	}
	if r, err := ParseNumber("Nanpa Wan Eke Tusenan Eke Lunumun", opts); err != nil || r.DisplayValue != "1,234,567" {
		t.Fatalf("proper-name spaces changed: result=%#v err=%v", r, err)
	}
	if r, err := ParseNumber("[nanpa : wan tu seli nanpa]", opts); err != nil || r.DisplayValue != "123" {
		t.Fatalf("cartouche spaces changed: result=%#v err=%v", r, err)
	}

	full := DefaultFullParserOptions()
	n := &NanpaLinjaN{}
	hits := n.scanCanonicalNumericHits("123 456", full)
	if len(hits) != 2 || hits[0].Start != 0 || hits[0].End != 3 || hits[1].Start != 4 || hits[1].End != 7 {
		t.Fatalf("full-document whitespace boundary got %#v", hits)
	}
	mixedHits := n.scanCanonicalNumericHits("1 1/2", full)
	if len(mixedHits) != 2 || mixedHits[0].Start != 0 || mixedHits[0].End != 1 || mixedHits[1].Start != 2 || mixedHits[1].End != 5 {
		t.Fatalf("spaced mixed fraction should split into independent numeric hits, got %#v", mixedHits)
	}
}
