package nanpa

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"reflect"
	"runtime"
	"strings"
	"testing"
)

type planGoldenDoc struct {
	Cases []planGolden `json:"cases"`
}
type planGolden struct {
	ID                  string   `json:"id"`
	Input               string   `json:"input"`
	FontPx              int      `json:"fontPx"`
	Abbreviate          bool     `json:"abbreviate"`
	Preserve            bool     `json:"preserveNumericCartoucheBreaks"`
	Canonical           []int    `json:"canonicalCodepoints"`
	Identity            []int    `json:"identityRenderCodepoints"`
	LegacyLinjaPonaText string   `json:"legacyLinjaPonaText"`
	LegacyLinjaSikeText string   `json:"legacyLinjaSikeText"`
	Features            []string `json:"openTypeFeatures"`
}

type renderCaseDoc struct {
	Cases []renderCase `json:"cases"`
}
type renderCase struct {
	ID         string `json:"id"`
	Input      string `json:"input"`
	FontPx     int    `json:"fontPx"`
	Abbreviate bool   `json:"abbreviateNumericCartouches"`
	Preserve   *bool  `json:"preserveNumericCartoucheBreaksInAbbreviation"`
}

func productionTestPath(name string) string {
	return filepath.Join("..", "testdata", "production", name)
}

func TestProductionFacadePlanConformance128(t *testing.T) {
	raw, err := os.ReadFile(productionTestPath("render-facade-plan-goldens-v1.0.0.json"))
	if err != nil {
		t.Fatal(err)
	}
	var doc planGoldenDoc
	if err := json.Unmarshal(raw, &doc); err != nil {
		t.Fatal(err)
	}
	if len(doc.Cases) != 16 {
		t.Fatalf("cases=%d want 16", len(doc.Cases))
	}
	n, err := CreateNanpaLinjaN()
	if err != nil {
		t.Fatal(err)
	}
	defer n.Close()
	fonts := n.ListFonts()
	if len(fonts) != 8 {
		t.Fatalf("fonts=%d want 8", len(fonts))
	}
	checks := 0
	for _, tc := range doc.Cases {
		for _, font := range fonts {
			opts := DefaultRenderOptions()
			opts.Font = font.Key
			opts.FontSize = tc.FontPx
			opts.Abbreviate = tc.Abbreviate
			opts.PreserveNumericCartoucheBreaks = tc.Preserve
			plan, err := n.BuildRenderPlan(tc.Input, opts)
			if err != nil {
				t.Fatalf("%s/%s: %v", font.Key, tc.ID, err)
			}
			if !reflect.DeepEqual(plan.CanonicalCodepoints, tc.Canonical) {
				t.Fatalf("%s/%s canonical\n got %v\nwant %v", font.Key, tc.ID, plan.CanonicalCodepoints, tc.Canonical)
			}
			if !reflect.DeepEqual(plan.OpenTypeFeatures, tc.Features) {
				t.Fatalf("%s/%s features got %v want %v", font.Key, tc.ID, plan.OpenTypeFeatures, tc.Features)
			}
			if plan.RenderAdapterID != font.RenderAdapterID {
				t.Fatalf("%s/%s adapter got %q want %q", font.Key, tc.ID, plan.RenderAdapterID, font.RenderAdapterID)
			}
			switch font.RenderAdapterID {
			case "linja-pona-legacy-v1":
				if plan.RenderText != tc.LegacyLinjaPonaText {
					t.Fatalf("%s/%s legacy text got %q want %q", font.Key, tc.ID, plan.RenderText, tc.LegacyLinjaPonaText)
				}
				if !plan.LegacyASCII {
					t.Fatal("legacy flag false")
				}
			case "linja-sike-legacy-v1":
				if plan.RenderText != tc.LegacyLinjaSikeText {
					t.Fatalf("%s/%s legacy text got %q want %q", font.Key, tc.ID, plan.RenderText, tc.LegacyLinjaSikeText)
				}
				if !plan.LegacyASCII {
					t.Fatal("legacy flag false")
				}
			default:
				if !reflect.DeepEqual(plan.RenderCodepoints, tc.Identity) {
					t.Fatalf("%s/%s render cps got %v want %v", font.Key, tc.ID, plan.RenderCodepoints, tc.Identity)
				}
				if plan.LegacyASCII {
					t.Fatal("identity marked legacy")
				}
			}
			checks++
		}
	}
	if checks != 128 {
		t.Fatalf("checks=%d", checks)
	}
	t.Log("Go production render-plan conformance: 128/128 PASS")
}

func TestProductionFacadeRendering128AndFormats(t *testing.T) {
	if runtime.GOOS != "linux" || !ProductionNativeRenderingAvailable() {
		t.Skip("native production rendering qualification runs on Linux")
	}
	raw, err := os.ReadFile(productionTestPath("font-golden-cases-v1.1.0.json"))
	if err != nil {
		t.Fatal(err)
	}
	var doc renderCaseDoc
	if err := json.Unmarshal(raw, &doc); err != nil {
		t.Fatal(err)
	}
	if len(doc.Cases) != 16 {
		t.Fatalf("cases=%d", len(doc.Cases))
	}
	n, err := CreateNanpaLinjaN()
	if err != nil {
		t.Fatal(err)
	}
	defer n.Close()
	count := 0
	for _, font := range n.ListFonts() {
		for _, tc := range doc.Cases {
			preserve := true
			if tc.Preserve != nil {
				preserve = *tc.Preserve
			}
			opts := DefaultRenderOptions()
			opts.Font = font.Key
			opts.FontSize = tc.FontPx
			opts.Abbreviate = tc.Abbreviate
			opts.PreserveNumericCartoucheBreaks = preserve
			r, err := n.Render(tc.Input, OutputPNG, opts)
			if err != nil {
				t.Fatalf("%s/%s: %v", font.Key, tc.ID, err)
			}
			if r.Width <= 0 || r.Height <= 0 || len(r.Bytes) < 64 || !bytes.HasPrefix(r.Bytes, []byte{137, 80, 78, 71, 13, 10, 26, 10}) {
				t.Fatalf("%s/%s invalid PNG", font.Key, tc.ID)
			}
			count++
		}
	}
	if count != 128 {
		t.Fatalf("renders=%d", count)
	}
	opts := DefaultRenderOptions()
	opts.Font = "linjaPona"
	plan, err := n.BuildRenderPlan("2026-09-13", opts)
	if err != nil {
		t.Fatal(err)
	}
	if plan.RenderAdapterID != "linja-pona-legacy-v1" || !plan.LegacyASCII || !isASCII(plan.RenderText) {
		t.Fatalf("legacy adaptation not automatic: %+v", plan)
	}
	svg, err := n.RenderToSVG("#ABCDEF", DefaultRenderOptions())
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Contains(svg, []byte("<svg")) {
		t.Fatal("invalid SVG")
	}
	pdf, err := n.RenderToPDF("0b10101", DefaultRenderOptions())
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.HasPrefix(pdf, []byte("%PDF-")) {
		t.Fatal("invalid PDF")
	}
	t.Log("Go production-font facade: 128/128 render cases PASS; PNG/SVG/PDF PASS")
}

func isASCII(s string) bool {
	for _, r := range s {
		if r > 127 {
			return false
		}
	}
	return true
}

func TestFrozenCoreSourceHashesUnchanged(t *testing.T) {
	raw, err := os.ReadFile(filepath.Join("..", "testdata", "core-source-sha256-v1.0.0.json"))
	if err != nil {
		t.Fatal(err)
	}
	var doc struct {
		Files map[string]string `json:"files"`
	}
	if err := json.Unmarshal(raw, &doc); err != nil {
		t.Fatal(err)
	}
	if len(doc.Files) != 7 {
		t.Fatalf("core hash count=%d", len(doc.Files))
	}
	for rel, want := range doc.Files {
		b, err := os.ReadFile(filepath.Join("..", rel))
		if err != nil {
			t.Fatal(err)
		}
		got := sha256.Sum256(b)
		if hex.EncodeToString(got[:]) != want {
			t.Fatalf("frozen Core changed: %s", rel)
		}
	}
}

func TestProductionFontAssetsHashes(t *testing.T) {
	raw, err := os.ReadFile(productionTestPath("font-assets-sha256-v1.0.0.json"))
	if err != nil {
		t.Fatal(err)
	}
	var doc struct {
		Files map[string]string `json:"files"`
	}
	if err := json.Unmarshal(raw, &doc); err != nil {
		t.Fatal(err)
	}
	if len(doc.Files) != 21 {
		t.Fatalf("asset hashes=%d want 21", len(doc.Files))
	}
	for name, want := range doc.Files {
		b, err := os.ReadFile(filepath.Join("..", "assets", "fonts", name))
		if err != nil {
			t.Fatal(err)
		}
		got := sha256.Sum256(b)
		if hex.EncodeToString(got[:]) != strings.ToLower(want) {
			t.Fatalf("font hash mismatch: %s", name)
		}
	}
}
