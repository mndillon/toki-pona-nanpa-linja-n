//go:build !linux || !cgo

package nanpa

import "fmt"

type fullTextMetrics struct {
	InkX, InkY, InkW, InkH int
	Baseline               float64
}

func fullNativeAvailable() bool { return false }
func nativeFullMeasure(text, family, fontPath string, size float64, features []string) (fullTextMetrics, error) {
	return fullTextMetrics{}, fmt.Errorf("full native renderer unavailable")
}
func nativeFullCaretX(text, family, fontPath string, size float64, features []string, byteIndex int) (float64, error) {
	return 0, fmt.Errorf("full native renderer unavailable")
}

type nativeFullSurface struct{}

func newNativeFullSurface(width, height int, format OutputFormat, bg RGBA) (*nativeFullSurface, error) {
	return nil, fmt.Errorf("full native renderer unavailable")
}

func (s *nativeFullSurface) drawText(text, family, fontPath string, size float64, features []string, ox, oy float64, fg RGBA, halo bool, hc RGBA, hw float64) error {
	return fmt.Errorf("full native renderer unavailable")
}
func (s *nativeFullSurface) drawLine(x1, y1, x2, y2, w float64, fg RGBA, halo bool, hc RGBA, hw float64) error {
	return fmt.Errorf("full native renderer unavailable")
}
func (s *nativeFullSurface) drawButtLine(x1, y1, x2, y2, w float64, c RGBA) error {
	return fmt.Errorf("full native renderer unavailable")
}
func (s *nativeFullSurface) drawSyntheticCornerBracket(cp int, x, baseline, fontPx, widthPx, heightPx float64, fg RGBA, halo bool, hc RGBA, hw float64) error {
	return fmt.Errorf("full native renderer unavailable")
}
func (s *nativeFullSurface) fillRoundedRect(x, y, w, h, radius float64, c RGBA) error {
	return fmt.Errorf("full native renderer unavailable")
}
func (s *nativeFullSurface) drawRect(x, y, w, h, lw float64, c RGBA) error {
	return fmt.Errorf("full native renderer unavailable")
}
func (s *nativeFullSurface) drawImage(path string, x, y, w, h float64) error {
	return fmt.Errorf("full native renderer unavailable")
}
func (s *nativeFullSurface) finish() ([]byte, error) {
	return nil, fmt.Errorf("full native renderer unavailable")
}
