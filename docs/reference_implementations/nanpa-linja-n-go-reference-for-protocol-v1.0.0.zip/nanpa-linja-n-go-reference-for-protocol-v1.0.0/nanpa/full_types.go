package nanpa

import (
	"image"
	"math"
	"strings"
)

const (
	TallyCodepoint       = 0xF199E
	MiddleDotCodepoint   = 0xF199C
	ColonCodepoint       = 0xF199D
	StackJoinerCodepoint = 0xF1995
	NestJoinerCodepoint  = 0xF1996
	OpenQuoteCodepoint   = 0x300C
	CloseQuoteCodepoint  = 0x300D
)

type FullParserOptions struct {
	EnableBinaryParsing                bool
	EnableHexParsing                   bool
	Mode                               string
	NumericMode                        string
	NanpaColonParsing                  bool
	NanpaColonRendering                bool
	RelaxedNanpaLinjanParsing          bool
	RelaxedNanpaLinjanRendering        bool
	AbbreviateNumericCartouches        bool
	PreserveNumericCartoucheBreaks     bool
	NumericCartoucheStartGlyph         string
	RendererMode                       string
	MixedStyle                         string
	BreakLinesAtFullStops              bool
	ShowUnknownText                    bool
	AutoCartoucheStandaloneProperNames bool
	InterpretDoubleQuotesAsTeTo        bool
	CartoucheCommaTallyMarks           bool
	// CommaTallyMarks is the documented Go binding alias of JavaScript commaTallyMarks.
	// When non-nil it overrides CartoucheCommaTallyMarks.
	CommaTallyMarks            *bool
	CartoucheTallyMode         string
	ManualTallySmallFontLiftPx *float64
	ManualTallySmallFontMaxPx  *float64
	NasinNanpaPona             bool
}

func effectiveCommaTallyMarks(p FullParserOptions) bool {
	if p.CommaTallyMarks != nil {
		return *p.CommaTallyMarks
	}
	return p.CartoucheCommaTallyMarks
}

func effectiveRendererMode(p FullParserOptions) string {
	switch p.Mode {
	case "standard-sitelen-pona-ascii-core", "sitelen-pona-ascii-extended", "sitelen-seli-kiwen":
		return p.Mode
	default:
		return p.RendererMode
	}
}

func DefaultFullParserOptions() FullParserOptions {
	return FullParserOptions{
		EnableBinaryParsing: true, EnableHexParsing: true,
		Mode: "uniform", NumericMode: "uniform",
		NanpaColonParsing: true, NanpaColonRendering: true,
		RelaxedNanpaLinjanParsing: true, RelaxedNanpaLinjanRendering: true,
		RendererMode: "sitelen-pona-ascii-extended", MixedStyle: "short",
		AutoCartoucheStandaloneProperNames: true, CartoucheCommaTallyMarks: true,
	}
}

func (p FullParserOptions) numericOptions() Options {
	mode := p.Mode
	if p.NumericMode == "traditional" || p.Mode == "traditional" {
		mode = "traditional"
	}
	if mode != "traditional" {
		mode = "uniform"
	}
	return Options{
		Mode: mode, NumericMode: mode, MixedStyle: p.MixedStyle,
		RelaxedNanpaLinjanParsing:   p.RelaxedNanpaLinjanParsing,
		RelaxedNanpaLinjanRendering: p.RelaxedNanpaLinjanRendering,
		NanpaColonParsing:           p.NanpaColonParsing, NanpaColonRendering: p.NanpaColonRendering,
		EnableHexParsing: p.EnableHexParsing, EnableBinaryParsing: p.EnableBinaryParsing,
		EnableBinaryRendering:                        true,
		AbbreviateNumericCartouches:                  p.AbbreviateNumericCartouches,
		PreserveNumericCartoucheBreaksInAbbreviation: p.PreserveNumericCartoucheBreaks,
		NumericCartoucheStartGlyph:                   p.NumericCartoucheStartGlyph,
	}
}

type FullLayoutOptions struct {
	Align                 string
	SpacingPreset         string
	GlyphGapScale         *float64
	GlyphGapMinPx         *float64
	GlyphGapMaxPx         *float64
	CartoucheLeadGapScale *float64
	CartouchePadScale     *float64
	CartouchePadMinPx     *float64
	LineGapPx             *float64
	ForceLineGapPx        bool
}

func DefaultFullLayoutOptions() FullLayoutOptions {
	return FullLayoutOptions{Align: "left", SpacingPreset: "default"}
}
func (l FullLayoutOptions) glyphGap(px float64) float64 {
	if l.GlyphGapScale != nil {
		v := px * (*l.GlyphGapScale)
		if l.GlyphGapMinPx != nil {
			v = math.Max(v, *l.GlyphGapMinPx)
		}
		if l.GlyphGapMaxPx != nil {
			v = math.Min(v, *l.GlyphGapMaxPx)
		}
		return math.Max(0, v)
	}
	switch strings.ToLower(l.SpacingPreset) {
	case "compact":
		return math.Max(2, px*.08)
	case "comfortable":
		return math.Max(6, px*.22)
	default:
		return math.Max(4, px*.14)
	}
}
func (l FullLayoutOptions) cartoucheLeadGap(px float64) float64 {
	if l.CartoucheLeadGapScale != nil {
		return math.Max(0, px*(*l.CartoucheLeadGapScale))
	}
	return l.glyphGap(px)
}
func (l FullLayoutOptions) cartouchePad(px float64) float64 {
	scale := .12
	if l.CartouchePadScale != nil {
		scale = *l.CartouchePadScale
	}
	v := px * scale
	if l.CartouchePadMinPx != nil {
		v = math.Max(v, *l.CartouchePadMinPx)
	}
	return math.Max(0, v)
}
func (l FullLayoutOptions) lineGap(px float64) float64 {
	if l.LineGapPx != nil && (l.ForceLineGapPx || *l.LineGapPx >= 0) {
		return math.Max(0, *l.LineGapPx)
	}
	switch strings.ToLower(l.SpacingPreset) {
	case "compact":
		return math.Max(8, px*.20)
	case "comfortable":
		return math.Max(18, px*.40)
	default:
		return 18
	}
}

type UnknownTextStyle struct {
	Style, Color           string
	LineWidthPx, PaddingPx float64
	Dash                   []float64
}
type FullPaintOptions struct {
	FillStyle   string
	UnknownText UnknownTextStyle
	HaloEnabled bool
	HaloColor   string
	HaloWidthPx float64
}

func DefaultFullPaintOptions() FullPaintOptions {
	return FullPaintOptions{FillStyle: "#000000", UnknownText: UnknownTextStyle{Style: "outline-box", Color: "#000000", LineWidthPx: 1.5, PaddingPx: 2}, HaloColor: "#FFFFFF"}
}

type FullRenderOptions struct {
	Font        string
	FontSize    float64
	PaddingPx   int
	Parser      FullParserOptions
	Layout      FullLayoutOptions
	Paint       FullPaintOptions
	IncludePlan bool
}

func DefaultFullRenderOptions() FullRenderOptions {
	return FullRenderOptions{Font: DefaultProductionFontKey, FontSize: 56, PaddingPx: 18, Parser: DefaultFullParserOptions(), Layout: DefaultFullLayoutOptions(), Paint: DefaultFullPaintOptions(), IncludePlan: true}
}

type ImageDescriptor struct {
	Src, W, H, Alt, VAlign string
	Wriggle                float64
	Transparent            bool
}
type DocumentSegment struct {
	Kind, Value            string
	Image                  *ImageDescriptor
	OpenQuote, CloseQuote  string
	SourceStart, SourceEnd int
}
type DocumentLine struct {
	Index, SourceLineIndex, SentenceIndexInSourceLine int
	SourceText                                        string
	Children                                          []DocumentSegment
}
type DocumentAST struct {
	Type, NormalizedInput string
	BreakLinesAtFullStops bool
	Lines                 []DocumentLine
}

type TallyGroup struct {
	OwnerIndex, Count                                                      int
	OwnerLeftPx, OwnerRightPx, CenterXPx, TopYPx, BottomYPx, StrokeWidthPx float64
	StrokeCentersPx                                                        []float64
}

type FullRenderRun struct {
	ID                                              string
	LineIndex, RunIndex                             int
	Kind, RenderMode, FontRole                      string
	NumericCartouche, HexCartouche, BinaryCartouche bool
	NumericBase                                     int
	OpenerCodepoint, CloserCodepoint                *int
	CanonicalCodepoints, RenderCodepoints           []int
	RenderText, RenderAdapterID                     string
	SourceText, SourceKind                          string
	SourceStart, SourceEnd                          int
	ManualTallies                                   []int
	TallyGroups                                     []TallyGroup
	Quoted, InterpretedQuote, Unrecognized          bool
	ImageAlt                                        string
	XPx, YPx, WidthPx, HeightPx, BaselineYPx        float64
}

type FullRenderLinePlan struct {
	LineIndex, SourceLineIndex, SentenceIndexInSourceLine         int
	XPx, YPx, WidthPx, HeightPx, BaselineYPx, AscentPx, DescentPx float64
	Runs                                                          []FullRenderRun
}
type FullRenderPlan struct {
	Input, FontKey   string
	Abbreviated      bool
	Width, Height    int
	OpenTypeFeatures []string
	Runs             []FullRenderRun
	Parsed           *ParseResult
	Diagnostics      []string
	AST              DocumentAST
	Lines            []FullRenderLinePlan
}

func (p FullRenderPlan) LineCount() int { return len(p.Lines) }
func (p FullRenderPlan) CartoucheCount() int {
	n := 0
	for _, r := range p.Runs {
		if r.NumericCartouche || r.FontRole == "cartouche" {
			n++
		}
	}
	return n
}

type CanvasRenderResult struct {
	Image   image.Image
	Plan    *FullRenderPlan
	FontKey string
}

func (r CanvasRenderResult) Width() int {
	if r.Image == nil {
		return 0
	}
	return r.Image.Bounds().Dx()
}
func (r CanvasRenderResult) Height() int {
	if r.Image == nil {
		return 0
	}
	return r.Image.Bounds().Dy()
}

type VectorElement struct {
	Kind, RunID, Path, Fill, Href, Text string
	X, Y, Width, Height                 float64
}
type VectorDocument struct {
	Width, Height int
	Elements      []VectorElement
	Diagnostics   []string
	Plan          FullRenderPlan
}

type RenderAdapter func(codepoints []int, font ProductionFontInfo, fontSize float64) []int
