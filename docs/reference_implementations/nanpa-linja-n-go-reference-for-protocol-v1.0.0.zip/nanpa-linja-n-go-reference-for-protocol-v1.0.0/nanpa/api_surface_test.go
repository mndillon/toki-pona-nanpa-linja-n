package nanpa

import "testing"

func TestFrozenAPISurface35(t *testing.T) {
	o := Options{Mode: "uniform", RelaxedNanpaLinjanParsing: true, RelaxedNanpaLinjanRendering: true, NanpaColonParsing: true, NanpaColonRendering: true, EnableHexParsing: true, EnableBinaryParsing: true}
	checks := []func() error{
		func() error { _, e := ParseNumber("1", o); return e },
		func() error { _, e := EncodeDecimal("1", o); return e },
		func() error { _, e := DecimalToUcsurCodepoints("1", o); return e },
		func() error { _, e := ProperNameToUcsurCodepoints("Newan", o); return e },
		func() error { _, e := SplitCapsToProperName("NEWEN", true, o); return e },
		func() error { _ = CapsToUniqueCode("NEWEN", o); return nil },
		func() error { _, e := DecodeCaps("NEWEN"); return e },
		func() error { _ = UcsurCodepointsToTpWords([]int{wordToCP["nanpa"]}); return nil },
		func() error { _ = CodepointsToWords([]int{wordToCP["nanpa"]}); return nil },
		func() error { _ = TpWordsToText([]string{"nanpa"}); return nil },
		func() error { _, e := ParseTpWordsToCodepoints("nanpa"); return e },
		func() error { _, e := TpWordsToUcsurCodepoints([]string{"nanpa"}); return e },
		func() error { _ = CodepointsToHex([]int{wordToCP["nanpa"]}); return nil },
		func() error { _ = CodepointsToHexWithCartouche([]int{wordToCP["nanpa"]}); return nil },
		func() error { _, e := ParseHexCodepoints("F193D"); return e },
		func() error { _ = WithCartoucheMarkers([]int{wordToCP["nanpa"]}); return nil },
		func() error {
			_ = StripCartoucheMarkers([]int{CartoucheStart, wordToCP["nanpa"], CartoucheEnd})
			return nil
		},
		func() error {
			if !IsValidCaps("NEWEN", o) {
				t.Error("isValidCaps")
			}
			return nil
		},
		func() error {
			if !IsValidProperName("Newan", o) {
				t.Error("isValidProperName")
			}
			return nil
		},
		func() error { _ = IsValidTimeOrDate("NEWETE N" /* intentionally false */, o); return nil },
		func() error { _ = IsValidTime("NEWEN", o); return nil },
		func() error { _ = IsValidDate("NEWEN", o); return nil },
		func() error { _, e := TokenizeCaps("NEWEN", o); return e },
		func() error { _, e := CapsTokensToTpWords([]string{"NE", "WE", "N"}, o); return e },
		func() error { _, e := CapsToWords("NEWEN", o); return e },
		func() error { _, e := CapsToCodepoints("NEWEN", o); return e },
		func() error { _, e := ParseIdentifier("#~W", o); return e },
		func() error { _, e := NormalizeVulgarFraction("½"); return e },
		func() error { _ = NormalizeTpWord("Nanpa!"); return nil },
		func() error { _ = GetSmallCodepointsSet(); return nil },
		func() error { _ = GetQuarterCodepointsSet(); return nil },
		func() error { _ = GetOneThirdCodepointsSet(); return nil },
		func() error { _ = GetTwoThirdsCodepointsSet(); return nil },
		func() error { _ = GetHalfCodepointsSet(); return nil },
		func() error {
			if !IsAllowedTpUcsurCodepoint(wordToCP["nanpa"]) {
				t.Error("isAllowedTpUcsurCodepoint")
			}
			return nil
		},
	}
	if len(checks) != 35 {
		t.Fatalf("API smoke check list: got %d, want 35", len(checks))
	}
	for i, check := range checks {
		if err := check(); err != nil {
			t.Fatalf("API operation %d failed: %v", i+1, err)
		}
	}
}
