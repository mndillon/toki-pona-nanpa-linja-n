package nanpa

import (
	"regexp"
	"strings"
)

type semantic struct {
	kind, sourceType, sourceText, digits string
	parts                                []NumericPart
}

func ptrString(s string) *string { return &s }
func makeSemantic(kind string, parts []NumericPart, srcType, srcText string) (semantic, bool) {
	digits := ""
	if len(parts) == 0 || parts[0].Kind != "digits" {
		return semantic{}, false
	}
	for _, p := range parts {
		if p.Kind == "digits" {
			if p.Digits == "" {
				return semantic{}, false
			}
			digits += p.Digits
		} else if p.Kind != "delimiter" {
			return semantic{}, false
		}
	}
	if digits == "" {
		return semantic{}, false
	}
	return semantic{kind: kind, sourceType: srcType, sourceText: srcText, digits: digits, parts: parts}, true
}
func asciiHex(ch byte) bool {
	return ch >= '0' && ch <= '9' || ch >= 'A' && ch <= 'F' || ch >= 'a' && ch <= 'f'
}
func asciiLetter(ch byte) bool { return ch >= 'A' && ch <= 'Z' || ch >= 'a' && ch <= 'z' }
func parseHexHash(s string) (semantic, bool) {
	if len(s) < 2 || s[0] != '#' || !asciiHex(s[1]) {
		return semantic{}, false
	}
	parts := []NumericPart{}
	run := ""
	count := 0
	flush := func() {
		if run != "" {
			parts = append(parts, NumericPart{Kind: "digits", Digits: strings.ToUpper(run)})
			run = ""
		}
	}
	i := 1
	for i < len(s) {
		ch := s[i]
		if ch == ' ' || ch == '\t' || ch == '\n' || ch == '\r' {
			break
		}
		if asciiHex(ch) {
			run += string(ch)
			count++
			i++
			continue
		}
		if asciiLetter(ch) {
			break
		}
		flush()
		x := string(ch)
		parts = append(parts, NumericPart{Kind: "delimiter", Char: &x})
		i++
	}
	flush()
	if count == 0 || i != len(s) {
		return semantic{}, false
	}
	return makeSemantic("hex", parts, "hash", s)
}
func hexGroupSizes(n int) []int {
	if n <= 0 {
		return nil
	}
	if n <= 3 {
		return []int{n}
	}
	out := []int{}
	for n > 3 {
		out = append(out, 2)
		n -= 2
	}
	return append(out, n)
}
func hexGroups(s string) []string {
	s = strings.ToUpper(s)
	sz := hexGroupSizes(len(s))
	out := []string{}
	p := 0
	for _, n := range sz {
		out = append(out, s[p:p+n])
		p += n
	}
	return out
}

var hexStrict = map[byte]string{'0': "NI", '1': "WE", '2': "TE", '3': "SE", '4': "NA", '5': "LE", '6': "NU", '7': "ME", '8': "PE", '9': "JE", 'A': "JA", 'B': "LA", 'C': "MA", 'D': "PA", 'E': "SI", 'F': "TA"}
var hexRelaxed = map[byte]string{'0': "NI", '1': "WA", '2': "TU", '3': "SE", '4': "NA", '5': "LU", '6': "NU", '7': "MU", '8': "PI", '9': "JO", 'A': "JA", 'B': "LA", 'C': "MA", 'D': "PA", 'E': "SI", 'F': "TA"}

func hexSyllableMap(relaxed bool) map[string]string {
	m := map[string]string{}
	src := hexStrict
	if relaxed {
		src = hexRelaxed
	}
	for d, s := range src {
		m[s] = string(d)
	}
	if relaxed {
		for d, s := range hexStrict {
			m[s] = string(d)
		}
	}
	return m
}
func validateHexTokens(tokens []struct{ k, d string }, srcType, src string) (semantic, bool) {
	if len(tokens) == 0 || tokens[0].k != "digit" {
		return semantic{}, false
	}
	parts := []NumericPart{}
	run := []struct{ k, d string }{}
	flush := func() bool {
		if len(run) == 0 {
			return true
		}
		groups := []string{}
		g := ""
		for _, t := range run {
			if t.k == "digit" {
				g += t.d
			} else if t.k == "generated" && g != "" {
				groups = append(groups, g)
				g = ""
			} else {
				return false
			}
		}
		if g == "" {
			return false
		}
		groups = append(groups, g)
		digits := strings.Join(groups, "")
		exp := hexGroups(digits)
		if len(exp) != len(groups) {
			return false
		}
		for i := range exp {
			if exp[i] != groups[i] {
				return false
			}
		}
		parts = append(parts, NumericPart{Kind: "digits", Digits: digits})
		run = nil
		return true
	}
	for _, t := range tokens {
		if t.k == "delimiter" {
			if len(run) > 0 && !flush() {
				return semantic{}, false
			}
			if len(parts) == 0 {
				return semantic{}, false
			}
			parts = append(parts, NumericPart{Kind: "delimiter"})
			continue
		}
		run = append(run, t)
	}
	if len(run) > 0 && !flush() {
		return semantic{}, false
	}
	return makeSemantic("hex", parts, srcType, src)
}
func parseHexProper(raw string, relaxed bool) (semantic, bool) {
	s := strings.TrimSpace(raw)
	if !regexp.MustCompile(`^[A-Za-z]+(?:[ \t]+[A-Za-z]+)*$`).MatchString(s) {
		return semantic{}, false
	}
	compact := strings.Join(strings.Fields(s), "")
	if len(compact) < 5 || !strings.EqualFold(compact[:4], "nasa") || !strings.HasSuffix(strings.ToLower(compact), "n") {
		return semantic{}, false
	}
	body := strings.ToUpper(compact[4 : len(compact)-1])
	if body == "" {
		return semantic{}, false
	}
	m := hexSyllableMap(relaxed)
	tokens := []struct{ k, d string }{}
	for i := 0; i < len(body); {
		if strings.HasPrefix(body[i:], "NENE") {
			tokens = append(tokens, struct{ k, d string }{k: "delimiter"})
			i += 4
			continue
		}
		if strings.HasPrefix(body[i:], "NEKE") {
			tokens = append(tokens, struct{ k, d string }{k: "generated"})
			i += 4
			continue
		}
		if i+2 > len(body) {
			return semantic{}, false
		}
		d, ok := m[body[i:i+2]]
		if !ok {
			return semantic{}, false
		}
		tokens = append(tokens, struct{ k, d string }{"digit", d})
		i += 2
	}
	return validateHexTokens(tokens, "properName", s)
}
func tokenizeCartouche(raw string) ([]string, bool) {
	s := strings.TrimSpace(raw)
	out := []string{}
	for i := 0; i < len(s); {
		ch := s[i]
		if ch == ' ' || ch == '\t' || ch == '\r' || ch == '\n' {
			i++
			continue
		}
		if ch == ':' {
			out = append(out, ":")
			i++
			continue
		}
		if asciiLetter(ch) {
			j := i + 1
			for j < len(s) && asciiLetter(s[j]) {
				j++
			}
			out = append(out, strings.ToLower(s[i:j]))
			i = j
			continue
		}
		return nil, false
	}
	return out, true
}

var hexAbbrev = map[string]string{"ijo": "0", "wan": "1", "tu": "2", "seli": "3", "awen": "4", "luka": "5", "utala": "6", "mun": "7", "pipi": "8", "jo": "9", "jan": "A", "lawa": "B", "ma": "C", "pakala": "D", "sike": "E", "tan": "F"}

type wordPattern struct {
	d string
	w []string
}

func hexPatterns(relaxed bool) []wordPattern {
	join := []string{"e", "en", "esun"}
	nw := []string{"nena", "nasa"}
	out := []wordPattern{}
	add := func(d, a string, bs []string) {
		for _, b := range bs {
			out = append(out, wordPattern{d, []string{a, b}})
		}
	}
	for _, n := range nw {
		add("0", n, []string{"ijo"})
	}
	for _, x := range []struct{ d, a string }{{"1", "wan"}, {"2", "tu"}, {"3", "seli"}, {"5", "luka"}, {"7", "mun"}, {"8", "pipi"}, {"9", "jo"}} {
		add(x.d, x.a, join)
	}
	for _, n := range nw {
		add("4", n, []string{"awen"})
		add("6", n, []string{"utala"})
	}
	if relaxed {
		add("1", "wan", []string{"ala"})
		add("2", "tu", []string{"uta"})
		add("5", "luka", []string{"uta"})
		add("7", "mun", []string{"uta"})
		add("8", "pipi", []string{"ike"})
		add("9", "jo", []string{"open"})
	}
	for _, x := range []struct{ d, a, b string }{{"A", "jan", "ala"}, {"B", "lawa", "ala"}, {"C", "ma", "ala"}, {"D", "pakala", "ala"}, {"E", "sike", "ike"}, {"F", "tan", "ala"}} {
		add(x.d, x.a, []string{x.b})
	}
	return out
}
func parseHexCartouche(raw string, opts Options) (semantic, bool) {
	t, ok := tokenizeCartouche(raw)
	if !ok || len(t) < 3 || t[0] != "nasa" || t[len(t)-1] != "nasa" {
		return semantic{}, false
	}
	start := 1
	if t[start] == ":" {
		start++
	}
	body := t[start : len(t)-1]
	if len(body) == 0 {
		return semantic{}, false
	}
	abbrev := func() (semantic, bool) {
		tok := []struct{ k, d string }{}
		for _, w := range body {
			if w == "kule" {
				tok = append(tok, struct{ k, d string }{k: "generated"})
				continue
			}
			if w == "e" {
				tok = append(tok, struct{ k, d string }{k: "delimiter"})
				continue
			}
			d, ok := hexAbbrev[w]
			if !ok {
				return semantic{}, false
			}
			tok = append(tok, struct{ k, d string }{"digit", d})
		}
		return validateHexTokens(tok, "cartouche", raw)
	}
	full := func() (semantic, bool) {
		tok := []struct{ k, d string }{}
		pats := hexPatterns(opts.RelaxedNanpaLinjanParsing)
		isN := func(w string) bool { return w == "nena" || w == "nasa" }
		isJ := func(w string) bool { return w == "e" || w == "en" || w == "esun" }
		for i := 0; i < len(body); {
			if i+3 < len(body) && isN(body[i]) && isJ(body[i+1]) && body[i+2] == "kule" && isJ(body[i+3]) {
				tok = append(tok, struct{ k, d string }{k: "generated"})
				i += 4
				continue
			}
			if i+3 < len(body) && isN(body[i]) && isJ(body[i+1]) && isN(body[i+2]) && isJ(body[i+3]) {
				tok = append(tok, struct{ k, d string }{k: "delimiter"})
				i += 4
				continue
			}
			found := false
			for _, p := range pats {
				if i+len(p.w) <= len(body) {
					match := true
					for k := range p.w {
						if body[i+k] != p.w[k] {
							match = false
							break
						}
					}
					if match {
						tok = append(tok, struct{ k, d string }{"digit", p.d})
						i += len(p.w)
						found = true
						break
					}
				}
			}
			if !found {
				return semantic{}, false
			}
		}
		return validateHexTokens(tok, "cartouche", raw)
	}
	if opts.AbbreviateNumericCartouches {
		if x, ok := abbrev(); ok {
			return x, true
		}
		return full()
	}
	if x, ok := full(); ok {
		return x, true
	}
	return abbrev()
}
func parseCompleteHex(input string, opts Options) (semantic, bool) {
	s := strings.TrimSpace(input)
	if strings.HasPrefix(s, "#") {
		return parseHexHash(s)
	}
	if strings.HasPrefix(s, "[") && strings.HasSuffix(s, "]") {
		return parseHexCartouche(strings.TrimSpace(s[1:len(s)-1]), opts)
	}
	return parseHexProper(s, opts.RelaxedNanpaLinjanParsing)
}
func hexFullWords(d byte, opts Options) []string {
	switch d {
	case 'A':
		return []string{"jan", "ala"}
	case 'B':
		return []string{"lawa", "ala"}
	case 'C':
		return []string{"ma", "ala"}
	case 'D':
		return []string{"pakala", "ala"}
	case 'E':
		return []string{"sike", "ike"}
	case 'F':
		return []string{"tan", "ala"}
	}
	if opts.RelaxedNanpaLinjanRendering {
		switch d {
		case '1':
			return []string{"wan", "ala"}
		case '2':
			return []string{"tu", "uta"}
		case '5':
			return []string{"luka", "uta"}
		case '7':
			return []string{"mun", "uta"}
		case '8':
			return []string{"pipi", "ike"}
		case '9':
			return []string{"jo", "open"}
		}
	}
	n, e := "nena", "e"
	if opts.normalizedMode() == "traditional" {
		n, e = "nasa", "esun"
	}
	switch d {
	case '0':
		return []string{n, "ijo"}
	case '1':
		return []string{"wan", e}
	case '2':
		return []string{"tu", e}
	case '3':
		return []string{"seli", e}
	case '4':
		return []string{n, "awen"}
	case '5':
		return []string{"luka", e}
	case '6':
		return []string{n, "utala"}
	case '7':
		return []string{"mun", e}
	case '8':
		return []string{"pipi", e}
	case '9':
		return []string{"jo", e}
	}
	return nil
}
func hexWords(s semantic, opts Options, abbr bool) []string {
	out := []string{"nasa", ":"}
	for _, p := range s.parts {
		if p.Kind == "delimiter" {
			if abbr {
				out = append(out, "e")
			} else {
				out = append(out, "nena", "e", "nena", "e")
			}
			continue
		}
		groups := hexGroups(p.Digits)
		for gi, g := range groups {
			for i := 0; i < len(g); i++ {
				if abbr {
					for w, d := range hexAbbrev {
						if d == string(g[i]) {
							out = append(out, w)
							break
						}
					}
				} else {
					out = append(out, hexFullWords(g[i], opts)...)
				}
			}
			if gi < len(groups)-1 {
				if abbr {
					out = append(out, "kule")
				} else {
					out = append(out, "nena", "e", "kule", "e")
				}
			}
		}
	}
	return append(out, "nasa")
}
func hexProper(s semantic, opts Options) string {
	out := []string{"Nasa"}
	attach := func(suf string) { out[len(out)-1] += "n"; out = append(out, suf) }
	for _, p := range s.parts {
		if p.Kind == "delimiter" {
			attach("Ene")
			continue
		}
		for gi, g := range hexGroups(p.Digits) {
			w := ""
			for i := 0; i < len(g); i++ {
				sy := hexStrict[g[i]]
				if opts.RelaxedNanpaLinjanRendering {
					sy = hexRelaxed[g[i]]
				}
				w += strings.ToLower(sy)
			}
			w = strings.ToUpper(w[:1]) + w[1:]
			out = append(out, w)
			if gi < len(hexGroups(p.Digits))-1 {
				attach("Eke")
			}
		}
	}
	out[len(out)-1] += "n"
	return strings.Join(out, " ")
}
func semanticCanonical(s semantic, prefix string) string {
	out := prefix
	for _, p := range s.parts {
		if p.Kind == "digits" {
			out += p.Digits
		} else if p.Char != nil {
			out += *p.Char
		} else {
			out += ":"
		}
	}
	return out
}

func parseBinaryPrefix(s string) (semantic, bool) {
	if len(s) < 3 || !strings.HasPrefix(s, "0b") || (s[2] != '0' && s[2] != '1') {
		return semantic{}, false
	}
	parts := []NumericPart{}
	run := ""
	count := 0
	flush := func() {
		if run != "" {
			parts = append(parts, NumericPart{Kind: "digits", Digits: run})
			run = ""
		}
	}
	i := 2
	for i < len(s) {
		ch := s[i]
		if ch == ' ' || ch == '\t' || ch == '\r' || ch == '\n' {
			break
		}
		if ch == '0' || ch == '1' {
			run += string(ch)
			count++
			i++
			continue
		}
		if ch >= '2' && ch <= '9' || asciiLetter(ch) {
			break
		}
		flush()
		x := string(ch)
		parts = append(parts, NumericPart{Kind: "delimiter", Char: &x})
		i++
	}
	flush()
	if count == 0 || i != len(s) {
		return semantic{}, false
	}
	return makeSemantic("binary", parts, "prefix", s)
}
func parseBinaryProper(raw string, opts Options) (semantic, bool) {
	s := strings.TrimSpace(raw)
	if !regexp.MustCompile(`^[A-Za-z]+(?:[ \t]+[A-Za-z]+)*$`).MatchString(s) {
		return semantic{}, false
	}
	c := strings.Join(strings.Fields(s), "")
	if len(c) < 5 || !strings.EqualFold(c[:4], "noka") || !strings.HasSuffix(strings.ToLower(c), "n") {
		return semantic{}, false
	}
	body := strings.ToUpper(c[4 : len(c)-1])
	m := map[string]string{"NI": "0", "WE": "1"}
	if opts.RelaxedNanpaLinjanParsing {
		m["WA"] = "1"
	}
	parts := []NumericPart{}
	run := ""
	flush := func() {
		if run != "" {
			parts = append(parts, NumericPart{Kind: "digits", Digits: run})
			run = ""
		}
	}
	for i := 0; i < len(body); {
		if strings.HasPrefix(body[i:], "NENE") {
			flush()
			parts = append(parts, NumericPart{Kind: "delimiter"})
			i += 4
			continue
		}
		if i+2 > len(body) {
			return semantic{}, false
		}
		d, ok := m[body[i:i+2]]
		if !ok {
			return semantic{}, false
		}
		run += d
		i += 2
	}
	flush()
	return makeSemantic("binary", parts, "properName", s)
}
func parseBinaryCartouche(raw string, opts Options) (semantic, bool) {
	t, ok := tokenizeCartouche(raw)
	if !ok || len(t) < 3 || t[0] != "noka" || t[len(t)-1] != "noka" {
		return semantic{}, false
	}
	st := 1
	if t[st] == ":" {
		st++
	}
	body := t[st : len(t)-1]
	if len(body) == 0 {
		return semantic{}, false
	}
	abbrev := func() (semantic, bool) {
		parts := []NumericPart{}
		run := ""
		flush := func() {
			if run != "" {
				parts = append(parts, NumericPart{Kind: "digits", Digits: run})
				run = ""
			}
		}
		for _, w := range body {
			if w == "e" {
				if run == "" {
					return semantic{}, false
				}
				flush()
				parts = append(parts, NumericPart{Kind: "delimiter"})
				continue
			}
			if w == "ijo" {
				run += "0"
			} else if w == "wan" {
				run += "1"
			} else {
				return semantic{}, false
			}
		}
		flush()
		return makeSemantic("binary", parts, "cartouche", raw)
	}
	full := func() (semantic, bool) {
		parts := []NumericPart{}
		run := ""
		flush := func() {
			if run != "" {
				parts = append(parts, NumericPart{Kind: "digits", Digits: run})
				run = ""
			}
		}
		pats := hexPatterns(opts.RelaxedNanpaLinjanParsing)
		for i := 0; i < len(body); {
			if i+3 < len(body) && (body[i] == "nena" || body[i] == "nasa") && (body[i+1] == "e" || body[i+1] == "en" || body[i+1] == "esun") && (body[i+2] == "nena" || body[i+2] == "nasa") && (body[i+3] == "e" || body[i+3] == "en" || body[i+3] == "esun") {
				if run == "" {
					return semantic{}, false
				}
				flush()
				parts = append(parts, NumericPart{Kind: "delimiter"})
				i += 4
				continue
			}
			found := false
			for _, p := range pats {
				if p.d != "0" && p.d != "1" {
					continue
				}
				if i+len(p.w) <= len(body) {
					match := true
					for k := range p.w {
						if body[i+k] != p.w[k] {
							match = false
							break
						}
					}
					if match {
						run += p.d
						i += len(p.w)
						found = true
						break
					}
				}
			}
			if !found {
				return semantic{}, false
			}
		}
		flush()
		return makeSemantic("binary", parts, "cartouche", raw)
	}
	if opts.AbbreviateNumericCartouches {
		if x, ok := abbrev(); ok {
			return x, true
		}
		return full()
	}
	if x, ok := full(); ok {
		return x, true
	}
	return abbrev()
}
func parseCompleteBinary(input string, opts Options) (semantic, bool) {
	s := strings.TrimSpace(input)
	if strings.HasPrefix(s, "0b") {
		return parseBinaryPrefix(s)
	}
	if strings.HasPrefix(s, "[") && strings.HasSuffix(s, "]") {
		return parseBinaryCartouche(strings.TrimSpace(s[1:len(s)-1]), opts)
	}
	return parseBinaryProper(s, opts)
}
func binaryWords(s semantic, opts Options, abbr bool) []string {
	out := []string{"noka", ":"}
	for _, p := range s.parts {
		if p.Kind == "delimiter" {
			if abbr {
				out = append(out, "e")
			} else {
				out = append(out, "nena", "e", "nena", "e")
			}
			continue
		}
		for i := 0; i < len(p.Digits); i++ {
			if abbr {
				if p.Digits[i] == '0' {
					out = append(out, "ijo")
				} else {
					out = append(out, "wan")
				}
			} else {
				out = append(out, hexFullWords(p.Digits[i], opts)...)
			}
		}
	}
	return append(out, "noka")
}
func binaryProper(s semantic, opts Options) string {
	out := []string{"Noka"}
	attach := func(suf string) { out[len(out)-1] += "n"; out = append(out, suf) }
	for _, p := range s.parts {
		if p.Kind == "delimiter" {
			attach("Ene")
			continue
		}
		w := ""
		for i := 0; i < len(p.Digits); i++ {
			sy := "NI"
			if p.Digits[i] == '1' {
				sy = "WE"
				if opts.RelaxedNanpaLinjanRendering {
					sy = "WA"
				}
			}
			w += strings.ToLower(sy)
		}
		out = append(out, strings.ToUpper(w[:1])+w[1:])
	}
	out[len(out)-1] += "n"
	return strings.Join(out, " ")
}
