package nanpa

import (
	"errors"
	"fmt"
	"strconv"
	"strings"
	"unicode"
)

var tokenPrefixes = []string{"KEKEKE", "KEKE", "KO", "KE", "NONONO", "NONO", "NOKO", "OK", "NE", "NS", "NO"}

func canonicalizeScientificCaps(caps string) string {
	s := strings.ToUpper(strings.TrimSpace(caps))
	return strings.ReplaceAll(s, "NEKOWENINEKO", "NEKO")
}

func digitToken(ch byte, opts Options) (string, error) {
	var t string
	if opts.RelaxedNanpaLinjanParsing {
		t = relaxedDigitToken[ch]
	} else {
		t = strictDigitToken[ch]
	}
	if t == "" {
		return "", fmt.Errorf("unsupported digit %q", ch)
	}
	return t, nil
}

func acceptedDigitToken(t string, opts Options) bool {
	if _, ok := digitTokenToChar[t]; !ok {
		return false
	}
	if opts.RelaxedNanpaLinjanParsing {
		return true
	}
	_, relaxedOnly := relaxedToStrict[t]
	return !relaxedOnly
}

func tokenizeCaps(caps string, opts Options) ([]string, error) {
	s := strings.ToUpper(strings.TrimSpace(caps))
	if s == "" {
		return nil, errors.New("caps is empty")
	}
	if !strings.HasSuffix(s, "N") {
		return nil, errors.New("caps must end N")
	}
	if !strings.HasPrefix(s, "NE") {
		return nil, errors.New("caps must start NE")
	}
	tokens := []string{}
	for i := 0; i < len(s)-1; {
		matched := ""
		for _, p := range tokenPrefixes {
			if strings.HasPrefix(s[i:len(s)-1], p) {
				matched = p
				break
			}
		}
		if matched != "" {
			tokens = append(tokens, matched)
			i += len(matched)
			continue
		}
		if i+2 <= len(s)-1 {
			two := s[i : i+2]
			if acceptedDigitToken(two, opts) {
				tokens = append(tokens, two)
				i += 2
				continue
			}
		}
		return nil, fmt.Errorf("invalid caps token at %d in %q", i, caps)
	}
	tokens = append(tokens, "N")
	return tokens, nil
}

func hasDigitToken(tokens []string) bool {
	for _, t := range tokens {
		if _, ok := digitTokenToChar[t]; ok {
			return true
		}
	}
	return false
}

func looksLikeCaps(s string) bool {
	t := strings.TrimSpace(s)
	if len(t) < 3 || !strings.EqualFold(t[:2], "NE") {
		return false
	}
	if t[len(t)-1] != 'n' && t[len(t)-1] != 'N' {
		return false
	}
	for _, r := range t {
		if !unicode.IsLetter(r) || r > unicode.MaxASCII {
			return false
		}
	}
	return true
}

func capsForOutputRendering(caps string, opts Options) (string, error) {
	c := canonicalizeScientificCaps(caps)
	if !opts.RelaxedNanpaLinjanRendering {
		return c, nil
	}
	ro := opts
	ro.RelaxedNanpaLinjanParsing = true
	toks, err := tokenizeCaps(c, ro)
	if err != nil {
		return "", err
	}
	for i, t := range toks {
		if v, ok := strictToRelaxedOutput[t]; ok {
			toks[i] = v
		}
	}
	return strings.Join(toks, ""), nil
}

func magnitudeKeProperNameFragment(count int) string {
	if count < 1 {
		return ""
	}
	if count <= 3 {
		return "e" + strings.Repeat("ke", count)
	}
	sizes := []int{2}
	rem := count - 2
	for rem > 3 {
		sizes = append(sizes, 2)
		rem -= 2
	}
	sizes = append(sizes, rem)
	var b strings.Builder
	for i, n := range sizes {
		if i == 0 {
			b.WriteString("e")
		}
		b.WriteString(strings.Repeat("ke", n))
		if i+1 < len(sizes) {
			b.WriteByte(' ')
		}
	}
	return b.String()
}

var strictHundredSuffixes = []string{"weninin", "teninin", "seninin", "naninin", "leninin", "nuninin", "meninin", "peninin", "jeninin"}
var relaxedHundredSuffixes = []string{"waninin", "tuninin", "luninin", "muninin", "pininin", "joninin"}

func splitFinalHundredIninWords(raw string, opts Options) string {
	words := strings.Fields(raw)
	suffixes := append([]string{}, strictHundredSuffixes...)
	if opts.RelaxedNanpaLinjanParsing {
		suffixes = append(suffixes, relaxedHundredSuffixes...)
	}
	out := []string{}
	for _, w := range words {
		lower := strings.ToLower(w)
		split := false
		for _, s := range suffixes {
			if strings.HasSuffix(lower, s) {
				split = true
				break
			}
		}
		if split && strings.HasSuffix(lower, "inin") && len(w) > 4 {
			out = append(out, w[:len(w)-4], w[len(w)-4:])
		} else {
			out = append(out, w)
		}
	}
	return strings.Join(out, " ")
}

func splitCapsRaw(caps string) (string, error) {
	s0 := strings.ToUpper(strings.TrimSpace(caps))
	if len(s0) < 3 || !strings.HasPrefix(s0, "NE") || !strings.HasSuffix(s0, "N") {
		return "", fmt.Errorf("invalid caps %q", caps)
	}
	hasOK := len(s0) >= 3 && s0[len(s0)-3:len(s0)-1] == "OK"
	main := s0
	if hasOK {
		main = s0[:len(s0)-3] + "N"
	}
	end := len(main) - 1
	if end%2 != 0 {
		return "", fmt.Errorf("odd pair area")
	}
	var b strings.Builder
	for i := 0; i < end; {
		pair := main[i : i+2]
		next := ""
		if i+4 <= end {
			next = main[i+2 : i+4]
		}
		switch {
		case pair == "NE" && next == "NO" && i == 0:
			b.WriteString("neno ")
			i += 4
			continue
		case pair == "NE" && next == "NS" && i == 0:
			b.WriteString("nene ")
			i += 4
			continue
		case pair == "NE" && next == "NE":
			b.WriteString("n ene ")
			i += 4
			continue
		case pair == "NO" && next == "NE" && i > 0:
			b.WriteString("n one ")
			i += 4
			continue
		case pair == "NO" && next == "KO" && i > 0:
			b.WriteString("n oko")
			if i+4 < end {
				b.WriteByte(' ')
			}
			i += 4
			continue
		case pair == "NE" && next == "KO" && i > 0:
			b.WriteString("n eko")
			if i+4 < end {
				b.WriteByte(' ')
			}
			i += 4
			continue
		case pair == "NO" && next == "NO" && i > 0:
			b.WriteString("n o")
			count := 1
			j := i
			for j+6 <= end && main[j+4:j+6] == "NO" {
				count++
				j += 2
			}
			b.WriteString(strings.Repeat("no", count))
			if i+2*count < end {
				b.WriteByte(' ')
			}
			i += 2 + 2*count
			continue
		case pair == "NE" && next == "KE":
			b.WriteString("n ")
			count := 1
			j := i
			for j+6 <= end && main[j+4:j+6] == "KE" {
				count++
				j += 2
			}
			b.WriteString(magnitudeKeProperNameFragment(count))
			if i+2*count < end {
				b.WriteByte(' ')
			}
			i += 2 + 2*count
			continue
		}
		if pair == "OK" {
			if i > 0 && !strings.HasSuffix(b.String(), " ") {
				b.WriteByte(' ')
			}
			if i > 0 {
				b.WriteString("n ")
			}
			b.WriteString("oke")
		} else {
			b.WriteString(strings.ToLower(pair))
		}
		i += 2
	}
	raw := strings.TrimSpace(b.String())
	for strings.Contains(raw, " n ") {
		raw = strings.ReplaceAll(raw, " n ", "n ")
	}
	if strings.HasSuffix(raw, " n") {
		raw = strings.TrimSuffix(raw, " n") + "n"
	}
	raw += "n"
	if hasOK {
		raw += " oken"
	}
	return raw, nil
}

func titleWords(s string) string {
	parts := strings.Fields(s)
	for i, w := range parts {
		if w != "" {
			parts[i] = strings.ToUpper(w[:1]) + w[1:]
		}
	}
	return strings.Join(parts, " ")
}

func splitCapsToProperName(caps string, titleCase bool, opts Options) (string, error) {
	rendered, err := capsForOutputRendering(caps, opts)
	if err != nil {
		return "", err
	}
	raw, err := splitCapsRaw(rendered)
	if err != nil {
		return "", err
	}
	ro := opts
	ro.RelaxedNanpaLinjanParsing = opts.RelaxedNanpaLinjanParsing || opts.RelaxedNanpaLinjanRendering
	raw = splitFinalHundredIninWords(raw, ro)
	if opts.NanpaColonRendering {
		alt := nanpaColonProperNameFromLegacy(raw, "")
		if titleCase {
			return alt, nil
		}
		return strings.ToLower(alt), nil
	}
	if titleCase {
		return titleWords(raw), nil
	}
	return raw, nil
}

func capsToUniqueCode(caps string, opts Options) string {
	c := canonicalizeScientificCaps(caps)
	toks, err := tokenizeCaps(c, opts)
	if err != nil {
		return "#~"
	}
	parts := []string{}
	for i := 0; i < len(toks); i++ {
		t := toks[i]
		if t == "NE" {
			if i == 0 && i+1 < len(toks) && toks[i+1] == "NS" {
				parts = append(parts, "e")
				i++
				continue
			}
			j := i
			for j < len(toks) && toks[j] == "NE" {
				j++
			}
			count := j - i
			if count/2 > 0 {
				parts = append(parts, strings.Repeat("ee", count/2))
			}
			if count%2 == 1 && j < len(toks) && toks[j] == "KO" {
				parts = append(parts, "eko")
				i = j
			} else {
				i = j - 1
			}
			continue
		}
		if t == "N" {
			continue
		}
		if v, ok := tokenToCodeLetter[t]; ok {
			parts = append(parts, v)
			continue
		}
		switch t {
		case "NO":
			parts = append(parts, "o")
		case "NONO":
			parts = append(parts, "oo")
		case "NONONO":
			parts = append(parts, "ooo")
		case "NOKO":
			parts = append(parts, "oko")
		case "KO":
			parts = append(parts, "ko")
		case "KE":
			parts = append(parts, "k")
		case "KEKE":
			parts = append(parts, "kk")
		case "KEKEKE":
			parts = append(parts, "kkk")
		case "OK":
			parts = append(parts, "ok")
		}
	}
	return "#~" + strings.Join(parts, "")
}

func decodeSegment(tokens []string, opts map[string]string) (string, bool) {
	intEne, intGroup, fracEne, fracGroup := ",", ",", "_", "_"
	if v := opts["intEneSep"]; v != "" {
		intEne = v
	}
	if v := opts["intGroupSep"]; v != "" {
		intGroup = v
	}
	if v := opts["fracEneSep"]; v != "" {
		fracEne = v
	}
	if v := opts["fracGroupSep"]; v != "" {
		fracGroup = v
	}
	i := 0
	positive, neg := false, false
	if i < len(tokens) && tokens[i] == "NS" {
		positive = true
		i++
	}
	if i < len(tokens) && tokens[i] == "NO" && !(i+1 < len(tokens) && tokens[i+1] == "NE") {
		neg = true
		i++
	}
	kind := "int"
	is, fs := "", ""
	suffix := 0
	appendSep := func(ene bool) {
		sep := intGroup
		if ene {
			sep = intEne
		}
		target := &is
		if kind != "int" {
			target = &fs
			sep = fracGroup
			if ene {
				sep = fracEne
			}
		}
		if *target != "" && !strings.HasSuffix(*target, sep) {
			*target += sep
		}
	}
	keCount := func(t string) int {
		switch t {
		case "KE":
			return 1
		case "KEKE":
			return 2
		case "KEKEKE":
			return 3
		}
		return 0
	}
	for i < len(tokens) {
		t := tokens[i]
		if d, ok := digitTokenToChar[t]; ok {
			if kind == "int" {
				is += d
			} else {
				fs += d
			}
			i++
			continue
		}
		if t == "NO" && i+1 < len(tokens) && tokens[i+1] == "NE" {
			if kind != "int" {
				return "", false
			}
			if is == "" {
				is = "0"
			}
			kind = "frac"
			i += 2
			continue
		}
		if t == "NE" && i+1 < len(tokens) && tokens[i+1] == "NE" {
			appendSep(true)
			i += 2
			continue
		}
		if t == "NE" && i+1 < len(tokens) {
			j := i + 1
			c := 0
			for j < len(tokens) {
				k := keCount(tokens[j])
				if k == 0 {
					break
				}
				c += k
				j++
			}
			if c > 0 {
				if j < len(tokens) {
					if _, ok := digitTokenToChar[tokens[j]]; ok {
						appendSep(false)
						i = j
						continue
					}
				}
				suffix += c
				i = j
				continue
			}
			return "", false
		}
		if keCount(t) > 0 {
			return "", false
		}
		return "", false
	}
	if is == "" {
		is = "0"
	}
	suf := ""
	switch suffix {
	case 1:
		suf = "K"
	case 2:
		suf = "M"
	case 3:
		suf = "B"
	case 4:
		suf = "T"
	default:
		if suffix > 4 {
			suf = "×1000^" + strconv.Itoa(suffix)
		}
	}
	sign := ""
	if neg {
		sign = "-"
	} else if positive {
		sign = "+"
	}
	if kind == "frac" {
		if fs == "" {
			fs = "0"
		}
		return sign + is + "." + fs + suf, true
	}
	return sign + is + suf, true
}

func findScientificMarker(tokens []string, start, end int) (int, int, bool) {
	if end > len(tokens) {
		end = len(tokens)
	}
	for i := start; i+1 < end; i++ {
		if tokens[i] == "NE" && tokens[i+1] == "KO" {
			return i, 2, true
		}
	}
	return 0, 0, false
}
func DecodeCaps(caps string, opts ...map[string]string) (string, error) {
	c := canonicalizeScientificCaps(caps)
	toks, err := tokenizeCaps(c, Options{RelaxedNanpaLinjanParsing: true})
	if err != nil {
		return "", err
	}
	if len(toks) < 2 {
		return "", errors.New("bad caps")
	}
	hasPct := false
	if len(toks) >= 2 && toks[len(toks)-2] == "OK" {
		hasPct = true
		toks = append(append([]string{}, toks[:len(toks)-2]...), "N")
	}
	final := len(toks) - 1
	decodeOpts := map[string]string{}
	if len(opts) > 0 {
		decodeOpts = opts[0]
	}
	mixed := -1
	for i, t := range toks {
		if t == "NONONO" || t == "NOKO" {
			mixed = i
			break
		}
	}
	if mixed >= 0 {
		frac := -1
		for i := mixed + 1; i < final; i++ {
			if toks[i] == "NONO" {
				frac = i
				break
			}
		}
		if frac < 0 {
			return "", errors.New("bad mixed")
		}
		a, ok := decodeSegment(toks[1:mixed], decodeOpts)
		if !ok {
			return "", errors.New("bad mixed")
		}
		b, ok := decodeSegment(toks[mixed+1:frac], decodeOpts)
		if !ok {
			return "", errors.New("bad mixed")
		}
		d, ok := decodeSegment(toks[frac+1:final], decodeOpts)
		if !ok {
			return "", errors.New("bad mixed")
		}
		s := a + "+" + b + "/" + d
		if hasPct {
			s += "%"
		}
		return s, nil
	}
	frac := -1
	for i := 1; i < final; i++ {
		if toks[i] == "NONO" {
			frac = i
			break
		}
	}
	if frac >= 0 {
		a, ok := decodeSegment(toks[1:frac], decodeOpts)
		if !ok {
			return "", errors.New("bad fraction")
		}
		b, ok := decodeSegment(toks[frac+1:final], decodeOpts)
		if !ok {
			return "", errors.New("bad fraction")
		}
		s := a + "/" + b
		if hasPct {
			s += "%"
		}
		return s, nil
	}
	if idx, n, ok := findScientificMarker(toks, 1, final); ok && idx > 1 {
		a, ok := decodeSegment(toks[1:idx], decodeOpts)
		if !ok {
			return "", errors.New("bad sci")
		}
		b, ok := decodeSegment(toks[idx+n:final], decodeOpts)
		if !ok {
			return "", errors.New("bad sci")
		}
		s := a + "e" + b
		if hasPct {
			s += "%"
		}
		return s, nil
	}
	s, ok := decodeSegment(toks[1:final], decodeOpts)
	if !ok {
		return "", errors.New("bad caps")
	}
	if hasPct {
		s += "%"
	}
	return s, nil
}

func codepointsToHex(cps []int) string {
	parts := make([]string, len(cps))
	for i, cp := range cps {
		parts[i] = strings.ToUpper(fmt.Sprintf("%04X", cp))
	}
	return strings.Join(parts, " ")
}
func withMarkers(cps []int) []int { return append(append([]int{CartoucheStart}, cps...), CartoucheEnd) }
func codepointsToWords(cps []int) []string {
	out := []string{}
	for _, cp := range cps {
		if w, ok := cpToWord[cp]; ok {
			out = append(out, w)
		}
	}
	return out
}
func tpWordsToCodepoints(words []string) ([]int, error) {
	out := make([]int, 0, len(words))
	for _, w := range words {
		cp, ok := wordToCP[strings.ToLower(w)]
		if !ok {
			return nil, fmt.Errorf("unknown word %q", w)
		}
		out = append(out, cp)
	}
	return out, nil
}
func normalizeTpWord(s string) string {
	var b strings.Builder
	for _, r := range strings.ToLower(s) {
		if r >= 'a' && r <= 'z' {
			b.WriteRune(r)
		}
	}
	return b.String()
}
