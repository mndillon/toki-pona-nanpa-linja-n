package nanpa

import (
	"bytes"
	"encoding/hex"
	"fmt"
	"image"
	"image/draw"
	_ "image/gif"
	_ "image/jpeg"
	_ "image/png"
	"math"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"unicode"
	"unicode/utf8"

	productionassets "nanpa-linja-n.com/assets"
)

var nativeBaseFamilies = map[string]string{
	"nasinNanpa":         "nasin-nanpa",
	"sitelenSeliKiwen":   "sitelen seli kiwen juniko-latin-ligatures",
	"fairfaxHd":          "Fairfax HD",
	"fairfaxPonaHd":      "Fairfax Pona HD",
	"linjaPona":          "linja pona 4.9",
	"linjaSike":          "linja sike 5-cartouche-fix",
	"nasinSitelenPuMono": "nasin-sitelen-pu",
	"linjaLipamanka":     "linja lipamanka-cartouche-fix",
}

var numericLikeRE = regexp.MustCompile(`[0-9]`)
var integerRE = regexp.MustCompile(`^\+?[0-9]+$`)
var compoundSplitRE = regexp.MustCompile(`([+-])`)

var fullFontMaterializeMu sync.Mutex

type fullGraphic struct {
	Text, Family, FontPath  string
	Features                []string
	Width, Height, Baseline float64
	OriginX, OriginY        float64
	TallyGroups             []TallyGroup
	ImageBytes              []byte
	ImageHref               string
	UnknownDecoration       bool
}
type logicalFullRun struct {
	Run     FullRenderRun
	Graphic fullGraphic
}
type preparedFull struct {
	Plan   FullRenderPlan
	Placed []logicalFullRun
}

func parseHexColor(s string, def RGBA) RGBA {
	s = strings.TrimSpace(s)
	if strings.HasPrefix(s, "#") {
		h := s[1:]
		if len(h) == 3 {
			h = string([]byte{h[0], h[0], h[1], h[1], h[2], h[2]})
		}
		if len(h) == 6 {
			if b, e := hex.DecodeString(h); e == nil {
				return RGBA{b[0], b[1], b[2], 255}
			}
		}
	}
	return def
}
func normalizedFullOptions(o FullRenderOptions) FullRenderOptions {
	d := DefaultFullRenderOptions()
	if strings.TrimSpace(o.Font) == "" {
		o.Font = d.Font
	}
	if o.FontSize == 0 {
		o.FontSize = d.FontSize
	}
	if o.FontSize < 8 {
		o.FontSize = 8
	}
	if o.PaddingPx < 0 {
		o.PaddingPx = 0
	}
	if o.Parser.RendererMode == "" {
		o.Parser = d.Parser
	}
	if o.Layout.Align == "" {
		o.Layout = d.Layout
	}
	if o.Paint.FillStyle == "" {
		o.Paint = d.Paint
	}
	if o.Paint.UnknownText.Color == "" {
		o.Paint.UnknownText = d.Paint.UnknownText
	}
	if o.Paint.HaloColor == "" {
		o.Paint.HaloColor = d.Paint.HaloColor
	}
	return o
}

func (n *NanpaLinjaN) materializeFont(filename string) (string, error) {
	if filename == "" {
		return "", fmt.Errorf("empty font filename")
	}
	if n.closed {
		return "", fmt.Errorf("NanpaLinjaN facade is closed")
	}

	// Full-document rendering registers fonts with the process-wide Fontconfig
	// configuration.  A facade-local temporary file cannot be used here: once
	// that facade is closed Fontconfig may still retain the now-deleted path,
	// causing later renderer instances to resolve the same family through a
	// stale file.  Keep immutable embedded fonts at deterministic process-stable
	// paths instead.  The legacy numeric renderer intentionally retains its
	// existing facade-local materialisation path and is therefore unaffected.
	fullFontMaterializeMu.Lock()
	defer fullFontMaterializeMu.Unlock()

	b, err := productionassets.ReadFont(filename)
	if err != nil {
		return "", err
	}
	dir := filepath.Join(os.TempDir(), "nanpa-linja-n-go-full-fonts-v1")
	if err := os.MkdirAll(dir, 0700); err != nil {
		return "", err
	}
	path := filepath.Join(dir, filepath.Base(filename))
	if old, err := os.ReadFile(path); err == nil && bytes.Equal(old, b) {
		return path, nil
	}
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, b, 0600); err != nil {
		return "", err
	}
	if err := os.Rename(tmp, path); err != nil {
		_ = os.Remove(tmp)
		return "", err
	}
	return path, nil
}

func (n *NanpaLinjaN) RegisterRenderAdapter(id string, adapter RenderAdapter) {
	n.fullAdapterMu.Lock()
	defer n.fullAdapterMu.Unlock()
	if n.fullAdapters == nil {
		n.fullAdapters = map[string]RenderAdapter{}
	}
	n.fullAdapters[id] = adapter
}
func (n *NanpaLinjaN) GetRenderAdapter(id string) (RenderAdapter, bool) {
	n.fullAdapterMu.RLock()
	defer n.fullAdapterMu.RUnlock()
	a, ok := n.fullAdapters[id]
	return a, ok
}
func (n *NanpaLinjaN) RemoveRenderAdapter(id string) (RenderAdapter, bool) {
	n.fullAdapterMu.Lock()
	defer n.fullAdapterMu.Unlock()
	a, ok := n.fullAdapters[id]
	if ok {
		delete(n.fullAdapters, id)
	}
	return a, ok
}

func (n *NanpaLinjaN) ParseInput(input string, options ...FullRenderOptions) DocumentAST {
	o := DefaultFullRenderOptions()
	if len(options) > 0 {
		o = normalizedFullOptions(options[0])
	}
	return ParseDocument(input, o.Parser)
}

// AstToText serializes a DocumentAST returned by ParseInput back to valid source text.
func (n *NanpaLinjaN) AstToText(ast DocumentAST) (string, error) {
	return AstToText(ast)
}

func (n *NanpaLinjaN) numericFullParse(source string, p FullParserOptions) (*ParseResult, bool) {
	r, err := ParseNumber(source, p.numericOptions())
	if err != nil || r == nil {
		return nil, false
	}
	// The frozen Core-v1 Go parser predates the browser renderer's explicit
	// positive-sign semantic glyph update.  Keep that core API untouched for
	// compatibility, but make the full-renderer binding match the canonical
	// JavaScript renderer: the explicit + sign is nena+en, not nena+e.
	if strings.HasPrefix(strings.TrimSpace(source), "+") {
		patch := func(in []int) []int {
			out := append([]int(nil), in...)
			for i := 0; i+1 < len(out); i++ {
				if out[i] == wordToCP["nena"] && out[i+1] == wordToCP["e"] {
					out[i+1] = wordToCP["en"]
					break
				}
			}
			return out
		}
		r.InnerCodepoints = patch(r.InnerCodepoints)
		r.UcsurCodepoints = patch(r.UcsurCodepoints)
		r.Codepoints = patch(r.Codepoints)
	}
	return r, true
}

func byteIndexForRuneIndex(s string, index int) int {
	if index <= 0 {
		return 0
	}
	n := 0
	i := 0
	for _, r := range s {
		if i >= index {
			break
		}
		n += utf8.RuneLen(r)
		i++
	}
	return n
}

func (n *NanpaLinjaN) measureGraphic(text, family, path string, size float64, features []string, pad int, bottomExtra float64) (fullGraphic, error) {
	m, err := nativeFullMeasure(text, family, path, size, features)
	if err != nil {
		return fullGraphic{}, err
	}
	w := float64(m.InkW + 2*pad)
	h := float64(m.InkH+2*pad) + bottomExtra
	return fullGraphic{Text: text, Family: family, FontPath: path, Features: append([]string(nil), features...), Width: math.Max(1, w), Height: math.Max(1, h), Baseline: m.Baseline - float64(m.InkY) + float64(pad), OriginX: float64(pad - m.InkX), OriginY: float64(pad - m.InkY)}, nil
}

func (n *NanpaLinjaN) glyphLogical(source string, cps []int, start, end int, sourceKind string, font ProductionFontInfo, o FullRenderOptions, quoted, interpreted bool) (logicalFullRun, error) {
	canonical := append([]int(nil), cps...)
	render := append([]int(nil), canonical...)
	if a, ok := n.GetRenderAdapter(font.RenderAdapterID); ok {
		render = a(render, font, o.FontSize)
	}
	var b strings.Builder
	for _, cp := range render {
		if err := validateScalar(cp); err != nil {
			return logicalFullRun{}, err
		}
		b.WriteRune(rune(cp))
	}
	text := b.String()
	path, err := n.materializeFont(font.BaseFilename)
	if err != nil {
		return logicalFullRun{}, err
	}
	fam := nativeBaseFamilies[font.Key]
	g, err := n.measureGraphic(text, fam, path, o.FontSize, nil, 0, 0)
	if err != nil {
		return logicalFullRun{}, err
	}
	r := FullRenderRun{Kind: "glyph", RenderMode: "text", FontRole: "word", CanonicalCodepoints: canonical, RenderCodepoints: render, RenderText: text, RenderAdapterID: font.RenderAdapterID, SourceText: source, SourceKind: sourceKind, SourceStart: start, SourceEnd: end, Quoted: quoted, InterpretedQuote: interpreted}
	if len(canonical) > 1 {
		r.Kind = "run"
	}
	return logicalFullRun{r, g}, nil
}

func (n *NanpaLinjaN) literalLogical(source string, start, end int, sourceKind string, font ProductionFontInfo, o FullRenderOptions, quoted, interpreted, unknown bool) (logicalFullRun, error) {
	path, err := n.materializeFont("PatrickHand-Regular.ttf")
	if err != nil {
		return logicalFullRun{}, err
	}
	g, err := n.measureGraphic(source, "Patrick Hand", path, o.FontSize, nil, 0, 0)
	if err != nil {
		return logicalFullRun{}, err
	}
	if unknown {
		pad := math.Max(0, o.Paint.UnknownText.PaddingPx)
		g.Width += 2 * pad
		g.Height += 2 * pad
		g.Baseline += pad
		g.OriginX += pad
		g.OriginY += pad
		g.UnknownDecoration = true
	}
	r := FullRenderRun{Kind: "text", RenderMode: "raster", FontRole: "literal", RenderText: source, RenderAdapterID: font.RenderAdapterID, SourceText: source, SourceKind: sourceKind, SourceStart: start, SourceEnd: end, Quoted: quoted, InterpretedQuote: interpreted, Unrecognized: unknown}
	return logicalFullRun{r, g}, nil
}

func (n *NanpaLinjaN) numericLogical(source string, parsed *ParseResult, start, end int, sourceKind string, font ProductionFontInfo, o FullRenderOptions) (logicalFullRun, error) {
	full := productionCanonicalCodepoints(parsed)
	if o.Parser.AbbreviateNumericCartouches {
		ab, err := abbreviateProductionCartouche(full, o.Parser.PreserveNumericCartoucheBreaks)
		if err != nil {
			return logicalFullRun{}, err
		}
		full = ab
	}
	text, _, err := adaptProductionCartouche(full, font.RenderAdapterID)
	if err != nil {
		return logicalFullRun{}, err
	}
	path, err := n.materializeFont(font.CompanionFilename)
	if err != nil {
		return logicalFullRun{}, err
	}
	features := openTypeFeaturesFor(o.FontSize)
	g, err := n.measureGraphic(text, font.NativeCompanionFamily, path, o.FontSize, features, 6, 0)
	if err != nil {
		return logicalFullRun{}, err
	}
	inner := full
	if len(full) >= 2 {
		inner = full[1 : len(full)-1]
	}
	base := 10
	if parsed.NumberBase != nil {
		base = *parsed.NumberBase
	}
	r := FullRenderRun{Kind: "cartouche", RenderMode: "raster", FontRole: "number", NumericCartouche: true, NumericBase: base, CanonicalCodepoints: append([]int(nil), inner...), RenderText: text, RenderCodepoints: runesToInts(text), RenderAdapterID: font.RenderAdapterID, SourceText: source, SourceKind: sourceKind, SourceStart: start, SourceEnd: end}
	if parsed.IsHex != nil {
		r.HexCartouche = *parsed.IsHex
	}
	if parsed.IsBinary != nil {
		r.BinaryCartouche = *parsed.IsBinary
	}
	if len(inner) > 0 {
		r.OpenerCodepoint = intPtr(inner[0])
		r.CloserCodepoint = intPtr(inner[len(inner)-1])
	}
	return logicalFullRun{r, g}, nil
}
func runesToInts(s string) []int {
	out := []int{}
	for _, r := range s {
		out = append(out, int(r))
	}
	return out
}

func (n *NanpaLinjaN) cartoucheLogical(source string, oc ordinaryCartouche, start, end int, sourceKind string, font ProductionFontInfo, o FullRenderOptions) (logicalFullRun, error) {
	adapted := adaptOrdinary(font, oc.Inner)
	path, err := n.materializeFont(font.BaseFilename)
	if err != nil {
		return logicalFullRun{}, err
	}
	fam := nativeBaseFamilies[font.Key]
	extra := 0.0
	if oc.hasManualTallies() {
		extra = math.Ceil(o.FontSize * .34)
	}
	g, err := n.measureGraphic(adapted.Text, fam, path, o.FontSize, nil, 6, extra)
	if err != nil {
		return logicalFullRun{}, err
	}
	groups := []TallyGroup{}
	if oc.hasManualTallies() {
		bottom := float64(g.Height) - extra - 6
		lift := manualTallyLift(font, o.Parser, o.FontSize)
		top := bottom - lift
		bot := top + o.FontSize*.10
		stroke := math.Max(1.5, o.FontSize*.045)
		gap := o.FontSize * .075
		for i, count := range oc.ManualTallies {
			count = minInt(8, maxInt(0, count))
			if count == 0 {
				continue
			}
			span := adapted.CanonicalSpans[i+1]
			lx, err := nativeFullCaretX(adapted.Text, fam, path, o.FontSize, nil, byteIndexForRuneIndex(adapted.Text, span[0]))
			if err != nil {
				return logicalFullRun{}, err
			}
			rx, err := nativeFullCaretX(adapted.Text, fam, path, o.FontSize, nil, byteIndexForRuneIndex(adapted.Text, span[1]))
			if err != nil {
				return logicalFullRun{}, err
			}
			left := g.OriginX + lx
			right := g.OriginX + rx
			center := (left + right) / 2
			total := stroke
			if count > 1 {
				total = float64(count)*stroke + float64(count-1)*gap
			}
			first := center - total/2 + stroke/2
			centers := make([]float64, count)
			for k := 0; k < count; k++ {
				centers[k] = first + float64(k)*(stroke+gap)
			}
			groups = append(groups, TallyGroup{OwnerIndex: i, Count: count, OwnerLeftPx: left, OwnerRightPx: right, CenterXPx: center, TopYPx: top, BottomYPx: bot, StrokeWidthPx: stroke, StrokeCentersPx: centers})
		}
	}
	g.TallyGroups = groups
	manual := []int(nil)
	if oc.hasManualTallies() {
		manual = append([]int(nil), oc.ManualTallies...)
	}
	r := FullRenderRun{Kind: "cartouche", RenderMode: "raster", FontRole: "cartouche", OpenerCodepoint: intPtr(CartoucheStart), CloserCodepoint: intPtr(CartoucheEnd), CanonicalCodepoints: append([]int(nil), oc.Inner...), RenderCodepoints: runesToInts(adapted.Text), RenderText: adapted.Text, RenderAdapterID: font.RenderAdapterID, SourceText: source, SourceKind: sourceKind, SourceStart: start, SourceEnd: end, ManualTallies: manual}
	return logicalFullRun{r, g}, nil
}
func maxInt(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func parseSize(v string, base float64) float64 {
	v = strings.TrimSpace(strings.ToLower(v))
	if v == "" {
		return math.NaN()
	}
	mul := 1.0
	if strings.HasSuffix(v, "em") {
		mul = base
		v = strings.TrimSuffix(v, "em")
	} else if strings.HasSuffix(v, "px") {
		v = strings.TrimSuffix(v, "px")
	}
	f, e := strconv.ParseFloat(v, 64)
	if e != nil {
		return math.NaN()
	}
	return f * mul
}
func (n *NanpaLinjaN) imageLogical(seg DocumentSegment, font ProductionFontInfo, o FullRenderOptions) (logicalFullRun, error) {
	d := seg.Image
	if d == nil {
		d = &ImageDescriptor{VAlign: "baseline", Transparent: true}
	}
	var raw []byte
	var err error
	if strings.HasPrefix(d.Src, "data:image/") {
		raw, err = decodeDataImage(d.Src)
	} else if d.Src != "" {
		raw, err = os.ReadFile(d.Src)
	}
	if err != nil {
		raw = nil
	}
	w, h := math.NaN(), math.NaN()
	if len(raw) > 0 {
		if cfg, _, e := image.DecodeConfig(bytes.NewReader(raw)); e == nil {
			w = float64(cfg.Width)
			h = float64(cfg.Height)
		}
	}
	targetW, targetH := parseSize(d.W, o.FontSize), parseSize(d.H, o.FontSize)
	if math.IsNaN(targetW) && math.IsNaN(targetH) {
		targetH = o.FontSize
	}
	if math.IsNaN(targetW) {
		if math.IsNaN(w) || math.IsNaN(h) || h == 0 {
			targetW = targetH
		} else {
			targetW = targetH * w / h
		}
	}
	if math.IsNaN(targetH) {
		if math.IsNaN(w) || math.IsNaN(h) || w == 0 {
			targetH = targetW
		} else {
			targetH = targetW * h / w
		}
	}
	baseline := targetH
	if strings.EqualFold(d.VAlign, "center") {
		baseline = targetH * .75
	}
	r := FullRenderRun{Kind: "cartouche", RenderMode: "raster", FontRole: "cartouche", RenderAdapterID: font.RenderAdapterID, SourceKind: "image", SourceStart: seg.SourceStart, SourceEnd: seg.SourceEnd, ImageAlt: d.Alt}
	return logicalFullRun{r, fullGraphic{Width: math.Max(1, targetW), Height: math.Max(1, targetH), Baseline: baseline, ImageBytes: raw, ImageHref: d.Src}}, nil
}

func (n *NanpaLinjaN) emitCore(core string, start, end int, kind string, out *[]logicalFullRun, font ProductionFontInfo, o FullRenderOptions) error {
	if allRunesUcsur(core) {
		return n.appendGlyph(out, core, runesToInts(core), start, end, kind, font, o, false, false)
	}
	if parsed, ok := n.numericFullParse(core, o.Parser); ok {
		if o.Parser.NasinNanpaPona && integerRE.MatchString(core) {
			for _, w := range nnpWords(strings.TrimPrefix(core, "+")) {
				if cp, ok := wordToCP[w]; ok {
					if err := n.appendGlyph(out, core, []int{cp}, start, end, kind, font, o, false, false); err != nil {
						return err
					}
				}
			}
			return nil
		}
		l, err := n.numericLogical(core, parsed, start, end, kind, font, o)
		if err != nil {
			return err
		}
		*out = append(*out, l)
		return nil
	}
	if (effectiveRendererMode(o.Parser) == "sitelen-pona-ascii-extended" || effectiveRendererMode(o.Parser) == "sitelen-seli-kiwen") && (strings.Contains(core, "-") || strings.Contains(core, "+")) {
		parts := compoundSplitRE.Split(core, -1)
		ops := compoundSplitRE.FindAllString(core, -1)
		cps := []int{}
		ok := true
		for i, p := range parts {
			if p != "" {
				cp, yes := wordToCP[sanitizeWord(p)]
				if !yes {
					ok = false
					break
				}
				cps = append(cps, cp)
			}
			if i < len(ops) {
				if ops[i] == "-" {
					cps = append(cps, StackJoinerCodepoint)
				} else {
					cps = append(cps, NestJoinerCodepoint)
				}
			}
		}
		if ok {
			return n.appendGlyph(out, core, cps, start, end, kind, font, o, false, false)
		}
	}
	if o.Parser.AutoCartoucheStandaloneProperNames && core != "" {
		r, _ := utf8.DecodeRuneInString(core)
		if unicode.IsUpper(r) {
			if cps, ok := properNameCodepoints(core); ok {
				l, err := n.cartoucheLogical(core, ordinaryCartouche{Inner: cps, ManualTallies: make([]int, len(cps)), TallyMode: "ucsur"}, start, end, kind, font, o)
				if err != nil {
					return err
				}
				*out = append(*out, l)
				return nil
			}
		}
	}
	if cp, ok := wordToCP[sanitizeWord(core)]; ok {
		return n.appendGlyph(out, core, []int{cp}, start, end, kind, font, o, false, false)
	}
	if o.Parser.ShowUnknownText {
		lit := core
		ls, le := start, end
		if effectiveRendererMode(o.Parser) == "standard-sitelen-pona-ascii-core" && len(lit) >= 2 && strings.HasPrefix(lit, "'") && strings.HasSuffix(lit, "'") {
			lit = lit[1 : len(lit)-1]
			ls++
			le--
		}
		l, err := n.literalLogical(lit, ls, le, kind, font, o, false, false, true)
		if err != nil {
			return err
		}
		*out = append(*out, l)
	}
	return nil
}
func (n *NanpaLinjaN) appendGlyph(out *[]logicalFullRun, source string, cps []int, start, end int, kind string, font ProductionFontInfo, o FullRenderOptions, quoted, interpreted bool) error {
	l, err := n.glyphLogical(source, cps, start, end, kind, font, o, quoted, interpreted)
	if err == nil {
		*out = append(*out, l)
	}
	return err
}

func (n *NanpaLinjaN) parseText(text string, base int, kind string, out *[]logicalFullRun, font ProductionFontInfo, o FullRenderOptions) error {
	if text == "" {
		return nil
	}
	trim := strings.TrimSpace(text)
	if trim == "" {
		return nil
	}
	leading := strings.Index(text, trim)
	if raw, ok := parseRawUnicodeSequence(trim); ok {
		return n.appendGlyph(out, trim, raw, base+leading, base+leading+len(trim), kind, font, o, false, false)
	}
	if parsed, ok := n.numericFullParse(trim, o.Parser); ok {
		if o.Parser.NasinNanpaPona && integerRE.MatchString(trim) {
			for _, w := range nnpWords(strings.TrimPrefix(trim, "+")) {
				if cp, yes := wordToCP[w]; yes {
					if err := n.appendGlyph(out, trim, []int{cp}, base+leading, base+leading+len(trim), kind, font, o, false, false); err != nil {
						return err
					}
				}
			}
			return nil
		}
		l, err := n.numericLogical(trim, parsed, base+leading, base+leading+len(trim), kind, font, o)
		if err != nil {
			return err
		}
		*out = append(*out, l)
		return nil
	}
	fields := regexp.MustCompile(`\S+`).FindAllStringIndex(text, -1)
	for _, loc := range fields {
		token := text[loc[0]:loc[1]]
		start, end := base+loc[0], base+loc[1]
		core := token
		for strings.HasPrefix(core, "(") || strings.HasPrefix(core, "{") {
			core = core[1:]
			start++
		}
		trail := ""
		for core != "" {
			last := core[len(core)-1]
			if !strings.ContainsRune(").;:!?}", rune(last)) {
				break
			}
			if last == '.' && numericLikeRE.MatchString(core) {
				break
			}
			trail = string(last) + trail
			core = core[:len(core)-1]
			end--
		}
		if strings.HasSuffix(core, ".") && len(core) > 1 && numericLikeRE.MatchString(core[:len(core)-1]) {
			trail = "." + trail
			core = core[:len(core)-1]
			end--
		}
		if core != "" {
			if err := n.emitCore(core, start, end, kind, out, font, o); err != nil {
				return err
			}
		}
		for j, c := range trail {
			cp := 0
			if c == '.' {
				cp = MiddleDotCodepoint
			} else if c == ':' {
				cp = ColonCodepoint
			}
			if cp != 0 {
				if err := n.appendGlyph(out, string(c), []int{cp}, end+j, end+j+1, kind, font, o, false, false); err != nil {
					return err
				}
			}
		}
	}
	return nil
}
func (n *NanpaLinjaN) parseBracket(body string, sourceStart int, out *[]logicalFullRun, font ProductionFontInfo, o FullRenderOptions) error {
	trim := strings.TrimSpace(body)
	if parsed, ok := n.numericFullParse("["+trim+"]", o.Parser); ok {
		l, err := n.numericLogical(trim, parsed, sourceStart, sourceStart+len(body), "bracket", font, o)
		if err != nil {
			return err
		}
		*out = append(*out, l)
		return nil
	}
	if oc, ok := parseOrdinaryBody(trim, font, o.Parser); ok {
		l, err := n.cartoucheLogical(trim, oc, sourceStart, sourceStart+len(body), "bracket", font, o)
		if err != nil {
			return err
		}
		*out = append(*out, l)
		return nil
	}
	if o.Parser.ShowUnknownText {
		l, err := n.literalLogical(trim, sourceStart, sourceStart+len(body), "bracket", font, o, false, false, true)
		if err != nil {
			return err
		}
		*out = append(*out, l)
	}
	return nil
}
func (n *NanpaLinjaN) parseQuote(seg DocumentSegment, out *[]logicalFullRun, font ProductionFontInfo, o FullRenderOptions) error {
	q := strings.ReplaceAll(seg.Value, `\"`, `"`)
	q = strings.ReplaceAll(q, `\\`, `\`)
	q = strings.ReplaceAll(q, `\t`, "    ")
	q = strings.ReplaceAll(q, `\n`, "\n")
	if o.Parser.InterpretDoubleQuotesAsTeTo {
		if err := n.appendGlyph(out, "te", []int{OpenQuoteCodepoint}, seg.SourceStart, seg.SourceStart+1, "interpretedQuote", font, o, false, true); err != nil {
			return err
		}
		before := len(*out)
		if err := n.parseText(q, seg.SourceStart+1, "interpretedQuote", out, font, o); err != nil {
			return err
		}
		for i := before; i < len(*out); i++ {
			(*out)[i].Run.InterpretedQuote = true
		}
		return n.appendGlyph(out, "to", []int{CloseQuoteCodepoint}, maxInt(seg.SourceStart+1, seg.SourceEnd-1), seg.SourceEnd, "interpretedQuote", font, o, false, true)
	}
	l, err := n.literalLogical(q, seg.SourceStart, seg.SourceEnd, "quote", font, o, true, false, false)
	if err != nil {
		return err
	}
	*out = append(*out, l)
	return nil
}

func (n *NanpaLinjaN) prepareFull(input string, o FullRenderOptions) (preparedFull, error) {
	o = normalizedFullOptions(o)
	font, err := n.registry.Get(o.Font)
	if err != nil {
		return preparedFull{}, err
	}
	ast := ParseDocument(input, o.Parser)
	logicalLines := make([][]logicalFullRun, len(ast.Lines))
	var firstParsed *ParseResult
	anyAbbr := false
	for li, line := range ast.Lines {
		runs := []logicalFullRun{}
		for _, seg := range line.Children {
			switch seg.Kind {
			case "text":
				err = n.parseText(seg.Value, seg.SourceStart, "text", &runs, font, o)
			case "bracket":
				err = n.parseBracket(seg.Value, seg.SourceStart, &runs, font, o)
			case "quote":
				err = n.parseQuote(seg, &runs, font, o)
			case "image":
				var l logicalFullRun
				l, err = n.imageLogical(seg, font, o)
				if err == nil {
					runs = append(runs, l)
				}
			}
			if err != nil {
				return preparedFull{}, err
			}
		}
		for _, l := range runs {
			if l.Run.NumericCartouche && firstParsed == nil {
				if p, ok := n.numericFullParse(l.Run.SourceText, o.Parser); ok {
					firstParsed = p
				}
			}
			if l.Run.NumericCartouche && o.Parser.AbbreviateNumericCartouches {
				anyAbbr = true
			}
		}
		logicalLines[li] = runs
	}
	lineGap := o.Layout.lineGap(o.FontSize)
	pad := float64(o.PaddingPx)
	lineWidths := make([]float64, len(logicalLines))
	lineAsc := make([]float64, len(logicalLines))
	lineDesc := make([]float64, len(logicalLines))
	maxw := 0.0
	for i, line := range logicalLines {
		x, asc, desc := 0.0, 0.0, 0.0
		first := true
		for _, l := range line {
			if !first {
				if l.Run.FontRole == "cartouche" || l.Run.NumericCartouche {
					x += o.Layout.cartoucheLeadGap(o.FontSize)
				} else {
					x += o.Layout.glyphGap(o.FontSize)
				}
			}
			first = false
			x += l.Graphic.Width
			asc = math.Max(asc, l.Graphic.Baseline)
			desc = math.Max(desc, math.Max(0, l.Graphic.Height-l.Graphic.Baseline))
		}
		h := math.Max(o.FontSize, asc+desc)
		if len(line) == 0 {
			asc = o.FontSize * .82
			desc = h - asc
		}
		lineWidths[i] = x
		lineAsc[i] = asc
		lineDesc[i] = desc
		maxw = math.Max(maxw, x)
	}
	width := maxInt(1, int(math.Ceil(maxw+2*pad)))
	total := 2*pad + lineGap*float64(maxInt(0, len(logicalLines)-1))
	for i := range logicalLines {
		total += math.Max(o.FontSize, lineAsc[i]+lineDesc[i])
	}
	height := maxInt(1, int(math.Ceil(total)))
	allRuns := []FullRenderRun{}
	linePlans := []FullRenderLinePlan{}
	placed := []logicalFullRun{}
	y := pad
	for li, line := range logicalLines {
		lw, asc, desc := lineWidths[li], lineAsc[li], lineDesc[li]
		lh := math.Max(o.FontSize, asc+desc)
		x := pad
		switch strings.ToLower(o.Layout.Align) {
		case "center":
			x += (maxw - lw) / 2
		case "right":
			x += maxw - lw
		}
		lineStart := x
		lr := []FullRenderRun{}
		first := true
		for ri, l := range line {
			if !first {
				if l.Run.FontRole == "cartouche" || l.Run.NumericCartouche {
					x += o.Layout.cartoucheLeadGap(o.FontSize)
				} else {
					x += o.Layout.glyphGap(o.FontSize)
				}
			}
			first = false
			ty := y + asc - l.Graphic.Baseline
			tx := x
			r := l.Run
			r.ID = fmt.Sprintf("L%dR%d", li, ri)
			r.LineIndex = li
			r.RunIndex = ri
			r.XPx = tx
			r.YPx = ty
			r.WidthPx = l.Graphic.Width
			r.HeightPx = l.Graphic.Height
			r.BaselineYPx = y + asc
			if len(l.Graphic.TallyGroups) > 0 {
				r.TallyGroups = make([]TallyGroup, len(l.Graphic.TallyGroups))
				for gi, g := range l.Graphic.TallyGroups {
					ng := g
					ng.OwnerLeftPx += tx
					ng.OwnerRightPx += tx
					ng.CenterXPx += tx
					ng.TopYPx += ty
					ng.BottomYPx += ty
					ng.StrokeCentersPx = append([]float64(nil), g.StrokeCentersPx...)
					for k := range ng.StrokeCentersPx {
						ng.StrokeCentersPx[k] += tx
					}
					r.TallyGroups[gi] = ng
				}
			}
			pl := l
			pl.Run = r
			placed = append(placed, pl)
			allRuns = append(allRuns, r)
			lr = append(lr, r)
			x += l.Graphic.Width
		}
		linePlans = append(linePlans, FullRenderLinePlan{LineIndex: li, SourceLineIndex: ast.Lines[li].SourceLineIndex, SentenceIndexInSourceLine: ast.Lines[li].SentenceIndexInSourceLine, XPx: lineStart, YPx: y, WidthPx: lw, HeightPx: lh, BaselineYPx: y + asc, AscentPx: asc, DescentPx: desc, Runs: lr})
		y += lh
		if li+1 < len(logicalLines) {
			y += lineGap
		}
	}
	plan := FullRenderPlan{Input: input, FontKey: font.Key, Abbreviated: anyAbbr, Width: width, Height: height, OpenTypeFeatures: openTypeFeaturesFor(o.FontSize), Runs: allRuns, Parsed: firstParsed, AST: ast, Lines: linePlans}
	return preparedFull{plan, placed}, nil
}

func (n *NanpaLinjaN) BuildFullRenderPlan(input string, options ...FullRenderOptions) (FullRenderPlan, error) {
	o := DefaultFullRenderOptions()
	if len(options) > 0 {
		o = options[0]
	}
	p, err := n.prepareFull(input, o)
	return p.Plan, err
}

func (n *NanpaLinjaN) renderPreparedFull(prep preparedFull, o FullRenderOptions, format OutputFormat) ([]byte, error) {
	o = normalizedFullOptions(o)
	surf, err := newNativeFullSurface(prep.Plan.Width, prep.Plan.Height, format, Transparent)
	if err != nil {
		return nil, err
	}
	fg := parseHexColor(o.Paint.FillStyle, Black)
	hc := parseHexColor(o.Paint.HaloColor, RGBA{255, 255, 255, 255})
	hw := o.Paint.HaloWidthPx
	if hw <= 0 && o.Paint.HaloEnabled {
		hw = math.Max(2, math.Min(24, math.Round(math.Max(8, o.FontSize)*.10)))
	}
	tempImages := []string{}
	defer func() {
		for _, p := range tempImages {
			_ = os.Remove(p)
		}
	}()
	for _, l := range prep.Placed {
		r, g := l.Run, l.Graphic
		if len(g.ImageBytes) > 0 {
			f, e := os.CreateTemp("", "nanpa_full_img_*.png")
			if e != nil {
				return nil, e
			}
			if _, e = f.Write(g.ImageBytes); e != nil {
				_ = f.Close()
				return nil, e
			}
			_ = f.Close()
			tempImages = append(tempImages, f.Name())
			if e := surf.drawImage(f.Name(), r.XPx, r.YPx, g.Width, g.Height); e != nil {
				return nil, e
			}
			continue
		}
		// Manual tally halos follow the browser reference: one rounded backing per
		// tally group is painted before the cartouche/text foreground. The visible
		// tally strokes are then painted on top with butt caps and no per-line halo.
		if o.Paint.HaloEnabled && hw > 0 {
			padX := hw * .85
			padBottom := hw * .85
			radius := math.Max(1.25, math.Min(hw, o.FontSize*.045))
			for _, tg := range r.TallyGroups {
				if len(tg.StrokeCentersPx) == 0 {
					continue
				}
				left := tg.StrokeCentersPx[0] - tg.StrokeWidthPx/2
				right := tg.StrokeCentersPx[len(tg.StrokeCentersPx)-1] + tg.StrokeWidthPx/2
				x := left - padX
				y := tg.TopYPx
				w := (right - left) + padX*2
				h := math.Max(1, (tg.BottomYPx-tg.TopYPx)+padBottom)
				if e := surf.fillRoundedRect(x, y, w, h, radius, hc); e != nil {
					return nil, e
				}
			}
		}
		if g.Text != "" {
			ox := r.XPx + g.OriginX
			oy := r.YPx + g.OriginY
			if e := surf.drawText(g.Text, g.Family, g.FontPath, o.FontSize, g.Features, ox, oy, fg, o.Paint.HaloEnabled, hc, hw); e != nil {
				return nil, e
			}
		}
		for _, tg := range r.TallyGroups {
			for _, cx := range tg.StrokeCentersPx {
				if e := surf.drawButtLine(cx, tg.TopYPx, cx, tg.BottomYPx, tg.StrokeWidthPx, fg); e != nil {
					return nil, e
				}
			}
		}
		if r.Unrecognized && g.UnknownDecoration {
			uc := parseHexColor(o.Paint.UnknownText.Color, Black)
			if e := surf.drawRect(r.XPx, r.YPx, g.Width, g.Height, math.Max(1, o.Paint.UnknownText.LineWidthPx), uc); e != nil {
				return nil, e
			}
		}
	}
	return surf.finish()
}
func (n *NanpaLinjaN) RenderFull(input string, format OutputFormat, options ...FullRenderOptions) (RenderResult, error) {
	o := DefaultFullRenderOptions()
	if len(options) > 0 {
		o = options[0]
	}
	prep, err := n.prepareFull(input, o)
	if err != nil {
		return RenderResult{}, err
	}
	b, err := n.renderPreparedFull(prep, o, format)
	if err != nil {
		return RenderResult{}, err
	}
	return RenderResult{Bytes: b, Width: prep.Plan.Width, Height: prep.Plan.Height, Format: format}, nil
}
func (n *NanpaLinjaN) RenderFullToPNG(input string, options ...FullRenderOptions) ([]byte, error) {
	r, e := n.RenderFull(input, OutputPNG, options...)
	return r.Bytes, e
}
func (n *NanpaLinjaN) RenderFullToSVG(input string, options ...FullRenderOptions) ([]byte, error) {
	r, e := n.RenderFull(input, OutputSVG, options...)
	return r.Bytes, e
}
func (n *NanpaLinjaN) RenderFullToPDF(input string, options ...FullRenderOptions) ([]byte, error) {
	r, e := n.RenderFull(input, OutputPDF, options...)
	return r.Bytes, e
}
func (n *NanpaLinjaN) RenderToCanvas(input string, options ...FullRenderOptions) (CanvasRenderResult, error) {
	o := DefaultFullRenderOptions()
	if len(options) > 0 {
		o = options[0]
	}
	prep, err := n.prepareFull(input, o)
	if err != nil {
		return CanvasRenderResult{}, err
	}
	b, err := n.renderPreparedFull(prep, o, OutputPNG)
	if err != nil {
		return CanvasRenderResult{}, err
	}
	im, _, err := image.Decode(bytes.NewReader(b))
	if err != nil {
		return CanvasRenderResult{}, err
	}
	var pp *FullRenderPlan
	if o.IncludePlan {
		p := prep.Plan
		pp = &p
	}
	return CanvasRenderResult{Image: im, Plan: pp, FontKey: prep.Plan.FontKey}, nil
}

func (n *NanpaLinjaN) ToVectorDocument(input string, options ...FullRenderOptions) (VectorDocument, error) {
	o := DefaultFullRenderOptions()
	if len(options) > 0 {
		o = options[0]
	}
	prep, err := n.prepareFull(input, o)
	if err != nil {
		return VectorDocument{}, err
	}
	els := []VectorElement{}
	for _, l := range prep.Placed {
		r, g := l.Run, l.Graphic
		if g.ImageHref != "" {
			els = append(els, VectorElement{Kind: "image", RunID: r.ID, Href: g.ImageHref, X: r.XPx, Y: r.YPx, Width: g.Width, Height: g.Height})
		} else if g.Text != "" {
			els = append(els, VectorElement{Kind: "text", RunID: r.ID, Text: g.Text, Fill: o.Paint.FillStyle, X: r.XPx + g.OriginX, Y: r.YPx + g.OriginY, Width: g.Width, Height: g.Height})
		}
		for _, tg := range r.TallyGroups {
			for _, cx := range tg.StrokeCentersPx {
				els = append(els, VectorElement{Kind: "path", RunID: r.ID, Path: fmt.Sprintf("M %.3f %.3f L %.3f %.3f", cx, tg.TopYPx, cx, tg.BottomYPx), Fill: o.Paint.FillStyle})
			}
		}
	}
	return VectorDocument{Width: prep.Plan.Width, Height: prep.Plan.Height, Elements: els, Diagnostics: prep.Plan.Diagnostics, Plan: prep.Plan}, nil
}

func (n *NanpaLinjaN) RenderRunToNewCanvas(run FullRenderRun, options ...FullRenderOptions) (CanvasRenderResult, error) {
	o := DefaultFullRenderOptions()
	if len(options) > 0 {
		o = options[0]
	}
	font, err := n.registry.Get(o.Font)
	if err != nil {
		return CanvasRenderResult{}, err
	}
	var g fullGraphic
	if run.RenderText != "" {
		var family, path string
		features := []string{}
		switch run.FontRole {
		case "number":
			family = font.NativeCompanionFamily
			path, err = n.materializeFont(font.CompanionFilename)
			features = openTypeFeaturesFor(o.FontSize)
		case "literal":
			family = "Patrick Hand"
			path, err = n.materializeFont("PatrickHand-Regular.ttf")
		default:
			family = nativeBaseFamilies[font.Key]
			path, err = n.materializeFont(font.BaseFilename)
		}
		if err != nil {
			return CanvasRenderResult{}, err
		}
		g, err = n.measureGraphic(run.RenderText, family, path, o.FontSize, features, 0, 0)
		if err != nil {
			return CanvasRenderResult{}, err
		}
		g.TallyGroups = append([]TallyGroup(nil), run.TallyGroups...)
	} else {
		return n.RenderToCanvas(run.SourceText, o)
	}
	rr := run
	rr.XPx = float64(o.PaddingPx)
	rr.YPx = float64(o.PaddingPx)
	rr.WidthPx = g.Width
	rr.HeightPx = g.Height
	prep := preparedFull{Plan: FullRenderPlan{FontKey: font.Key, Width: int(math.Ceil(g.Width + 2*float64(o.PaddingPx))), Height: int(math.Ceil(g.Height + 2*float64(o.PaddingPx))), Runs: []FullRenderRun{rr}}, Placed: []logicalFullRun{{Run: rr, Graphic: g}}}
	b, err := n.renderPreparedFull(prep, o, OutputPNG)
	if err != nil {
		return CanvasRenderResult{}, err
	}
	im, _, err := image.Decode(bytes.NewReader(b))
	return CanvasRenderResult{Image: im, FontKey: font.Key}, err
}
func (n *NanpaLinjaN) RenderTextToNewCanvas(text string, options ...FullRenderOptions) (CanvasRenderResult, error) {
	return n.RenderToCanvas(text, options...)
}
func (n *NanpaLinjaN) RenderTextToCanvas(target draw.Image, x, y int, text string, options ...FullRenderOptions) (draw.Image, error) {
	res, err := n.RenderToCanvas(text, options...)
	if err != nil {
		return target, err
	}
	draw.Draw(target, image.Rect(x, y, x+res.Width(), y+res.Height()), res.Image, res.Image.Bounds().Min, draw.Over)
	return target, nil
}
func ucsurSource(lines [][]int) string {
	ls := make([]string, len(lines))
	for i, line := range lines {
		parts := make([]string, len(line))
		for j, cp := range line {
			parts[j] = fmt.Sprintf("U+%04X", cp)
		}
		ls[i] = strings.Join(parts, " ")
	}
	return strings.Join(ls, "\n")
}
func (n *NanpaLinjaN) RenderUcsurToNewCanvas(lines [][]int, options ...FullRenderOptions) (CanvasRenderResult, error) {
	return n.RenderToCanvas(ucsurSource(lines), options...)
}
func (n *NanpaLinjaN) RenderUcsurToCanvas(target draw.Image, x, y int, lines [][]int, options ...FullRenderOptions) (draw.Image, error) {
	return n.RenderTextToCanvas(target, x, y, ucsurSource(lines), options...)
}
