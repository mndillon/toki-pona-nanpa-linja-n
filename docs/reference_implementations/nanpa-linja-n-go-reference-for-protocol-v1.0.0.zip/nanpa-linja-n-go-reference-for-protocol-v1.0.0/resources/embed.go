package resources

import (
	"archive/zip"
	"bytes"
	_ "embed"
	"fmt"
	"io"
	"path"
	"sync"
)

const manifestEntry = "fonts/preloaded-font-pairs.manifest.json"

// fontBundle is the single bundled production-font source used by the Go
// reference implementation.
//
//go:embed fonts.zip
var fontBundle []byte

var (
	fontZipOnce sync.Once
	fontZip     *zip.Reader
	fontZipErr  error
)

func zipReader() (*zip.Reader, error) {
	fontZipOnce.Do(func() {
		fontZip, fontZipErr = zip.NewReader(bytes.NewReader(fontBundle), int64(len(fontBundle)))
	})
	if fontZipErr != nil {
		return nil, fmt.Errorf("open embedded resources/fonts.zip: %w", fontZipErr)
	}
	return fontZip, nil
}

func readEntry(name string) ([]byte, error) {
	zr, err := zipReader()
	if err != nil {
		return nil, err
	}
	for _, f := range zr.File {
		if f.Name != name {
			continue
		}
		rc, err := f.Open()
		if err != nil {
			return nil, fmt.Errorf("open %q from embedded resources/fonts.zip: %w", name, err)
		}
		defer rc.Close()
		b, err := io.ReadAll(rc)
		if err != nil {
			return nil, fmt.Errorf("read %q from embedded resources/fonts.zip: %w", name, err)
		}
		return b, nil
	}
	return nil, fmt.Errorf("entry %q not found in embedded resources/fonts.zip", name)
}

// ReadFont returns one manifest-selected font from resources/fonts.zip.
func ReadFont(name string) ([]byte, error) {
	if name == "" || path.Base(name) != name {
		return nil, fmt.Errorf("invalid production font filename %q", name)
	}
	return readEntry("fonts/" + name)
}

// Manifest returns the production font manifest stored inside resources/fonts.zip.
func Manifest() ([]byte, error) {
	return readEntry(manifestEntry)
}
