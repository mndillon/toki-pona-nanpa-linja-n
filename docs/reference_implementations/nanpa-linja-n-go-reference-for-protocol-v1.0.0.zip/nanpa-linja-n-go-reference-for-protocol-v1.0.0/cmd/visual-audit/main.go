package main

import (
	"bytes"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"image/png"
	"os"
	"path/filepath"

	nanpa "nanpa-linja-n.com/nanpa"
)

func must(err error) {
	if err != nil {
		panic(err)
	}
}
func write(path string, b []byte) {
	must(os.MkdirAll(filepath.Dir(path), 0755))
	must(os.WriteFile(path, b, 0644))
	if len(b) < 100 {
		panic("suspiciously small PNG: " + path)
	}
}
func decode(b []byte) image.Image  { im, e := png.Decode(bytes.NewReader(b)); must(e); return im }
func encode(im image.Image) []byte { var b bytes.Buffer; must(png.Encode(&b, im)); return b.Bytes() }
func whiteBack(im image.Image, pad int) image.Image {
	b := im.Bounds()
	dst := image.NewRGBA(image.Rect(0, 0, b.Dx()+pad*2, b.Dy()+pad*2))
	draw.Draw(dst, dst.Bounds(), &image.Uniform{C: color.White}, image.Point{}, draw.Src)
	draw.Draw(dst, image.Rect(pad, pad, pad+b.Dx(), pad+b.Dy()), im, b.Min, draw.Over)
	return dst
}
func contact(images []image.Image, gap int) image.Image {
	cellW, cellH := 0, 0
	for _, im := range images {
		b := im.Bounds()
		if b.Dx() > cellW {
			cellW = b.Dx()
		}
		if b.Dy() > cellH {
			cellH = b.Dy()
		}
	}
	w := cellW*2 + gap*3
	h := cellH*2 + gap*3
	dst := image.NewRGBA(image.Rect(0, 0, w, h))
	draw.Draw(dst, dst.Bounds(), &image.Uniform{C: color.White}, image.Point{}, draw.Src)
	for i, im := range images {
		x := gap + (i%2)*(cellW+gap)
		y := gap + (i/2)*(cellH+gap)
		b := im.Bounds()
		draw.Draw(dst, image.Rect(x, y, x+b.Dx(), y+b.Dy()), im, b.Min, draw.Over)
	}
	return dst
}
func numeric(n *nanpa.NanpaLinjaN, out string) int {
	count := 0
	for _, f := range n.ListFonts() {
		for _, v := range []struct {
			name string
			abbr bool
		}{{"full", false}, {"abbreviated", true}} {
			o := nanpa.DefaultRenderOptions()
			o.Font = f.Key
			o.FontSize = 56
			o.Abbreviate = v.abbr
			o.OuterPadding = 4
			b, e := n.RenderToPNG("123.45", o)
			must(e)
			base := filepath.Join(out, fmt.Sprintf("%s-%s.png", f.Key, v.name))
			write(base, b)
			count++
			finished := filepath.Join(out, fmt.Sprintf("%s-%s-finished.png", f.Key, v.name))
			write(finished, encode(whiteBack(decode(b), 12)))
			count++
		}
	}
	return count
}
func ordinary(n *nanpa.NanpaLinjaN, out string) int {
	count := 0
	for _, f := range n.ListFonts() {
		vars := []struct {
			name, text string
			halo       bool
		}{{"ordinary-cartouche", "[jan pona]", false}, {"ordinary-cartouche-halo-red", "[jan pona]", true}, {"ordinary-cartouche-tallies", "[jan pona,,]", false}, {"ordinary-cartouche-tallies-halo-red", "[jan pona,,]", true}}
		ims := make([]image.Image, 0, 4)
		for _, v := range vars {
			o := nanpa.DefaultFullRenderOptions()
			o.Font = f.Key
			o.FontSize = 56
			if v.halo {
				o.Paint.HaloEnabled = true
				o.Paint.HaloColor = "#D91E18"
				o.Paint.HaloWidthPx = 6
			}
			b, e := n.RenderFullToPNG(v.text, o)
			must(e)
			path := filepath.Join(out, fmt.Sprintf("%s--%s.png", f.Key, v.name))
			write(path, b)
			ims = append(ims, decode(b))
			count++
		}
		path := filepath.Join(out, fmt.Sprintf("%s--ordinary-cartouche-contact.png", f.Key))
		write(path, encode(contact(ims, 12)))
		count++
	}
	return count
}
func main() {
	if len(os.Args) < 3 {
		fmt.Fprintln(os.Stderr, "usage: visual-audit <numeric|ordinary|all> <output-dir>")
		os.Exit(2)
	}
	n, e := nanpa.CreateNanpaLinjaN()
	must(e)
	defer n.Close()
	mode, out := os.Args[1], os.Args[2]
	total := 0
	switch mode {
	case "numeric":
		total = numeric(n, out)
	case "ordinary":
		total = ordinary(n, out)
	case "all":
		total = numeric(n, out) + ordinary(n, filepath.Join(out, "cartouche-audit"))
	default:
		panic("unknown mode: " + mode)
	}
	fmt.Printf("Go visual audit: %d PNG file(s) written to %s\n", total, out)
}
