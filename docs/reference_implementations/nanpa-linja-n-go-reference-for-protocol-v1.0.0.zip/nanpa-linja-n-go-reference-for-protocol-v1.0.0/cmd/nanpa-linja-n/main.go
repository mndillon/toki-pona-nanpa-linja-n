package main

import (
	"encoding/json"
	"fmt"
	"os"
	"strings"

	nanpa "nanpa-linja-n.com/nanpa"
)

func defaultOptions() nanpa.Options {
	return nanpa.Options{
		Mode:                        "uniform",
		MixedStyle:                  "short",
		RelaxedNanpaLinjanParsing:   true,
		RelaxedNanpaLinjanRendering: true,
		NanpaColonParsing:           true,
		NanpaColonRendering:         true,
		EnableHexParsing:            true,
		EnableBinaryParsing:         true,
	}
}

func usage() {
	fmt.Fprintln(os.Stderr, "usage: nanpa-linja-n <parse|encode|decode> <value>")
	os.Exit(2)
}

func main() {
	if len(os.Args) < 3 {
		usage()
	}
	command := os.Args[1]
	input := strings.Join(os.Args[2:], " ")
	opts := defaultOptions()

	switch command {
	case "parse":
		r, err := nanpa.ParseNumber(input, opts)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		enc := json.NewEncoder(os.Stdout)
		enc.SetIndent("", "  ")
		if err := enc.Encode(r); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
	case "encode":
		caps, err := nanpa.EncodeDecimal(input, opts)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		fmt.Println(caps)
	case "decode":
		value, err := nanpa.DecodeCaps(input)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		fmt.Println(value)
	default:
		usage()
	}
}
