#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
OUT="${1:-$ROOT/test-output/cartouche-audit}"; mkdir -p "$OUT"
go run ./cmd/visual-audit ordinary "$OUT"
