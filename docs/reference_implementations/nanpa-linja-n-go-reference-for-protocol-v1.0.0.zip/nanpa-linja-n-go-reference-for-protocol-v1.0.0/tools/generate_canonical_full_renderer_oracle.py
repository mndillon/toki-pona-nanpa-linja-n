#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, sys
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
JS_PATH = ROOT / 'reference' / 'renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js'
OUT = ROOT / 'conformance' / 'full-renderer-canonical-v1.0.1' / 'cases.json'

BASE = {
    'mode': 'sitelen-pona-ascii-extended',
    'numericMode': 'uniform',
    'mixedStyle': 'short',
    'showUnknownText': False,
    'abbreviateNumericCartouches': False,
    'preserveNumericCartoucheBreaksInAbbreviation': True,
    'autoCartoucheStandaloneProperNames': True,
    'relaxedNanpaLinjanParsing': True,
    'relaxedNanpaLinjanRendering': True,
    'nanpaColonParsing': True,
    'nanpaColonRendering': True,
    'numericCartoucheStartGlyph': None,
    'enableHexParsing': True,
    'enableBinaryParsing': True,
    'enableBinaryRendering': True,
    'nasinNanpaPona': False,
    'cartoucheCommaTallyMarks': True,
    'cartoucheTallyMode': 'ucsur',
    'interpretDoubleQuotesAsTeTo': False,
    'breakLinesAtFullStops': False,
}

CASES=[]
def add(id, input, parser=None, font=None, compare_ast=True, note=None):
    p=dict(BASE)
    if parser: p.update(parser)
    CASES.append({'id':id,'input':input,'parser':p,'font':font or 'nasinNanpa','compareAst':compare_ast, **({'note':note} if note else {})})

# Ordinary words, direct tokens, aliases, punctuation, boundaries.
add('word.jan','jan')
add('word.multi','jan pona mi toki')
add('word.ale-ali-ota','ale ali ota')
for s in ['ni01','ni02','ni03','ni04','sewi01','sewi02']:
    add('alias-glyph.'+s,s)
add('direct.te-to-zz','te to zz')
add('punct.period-middle-colon-comma','jan. pona· mi: toki,')
add('dash.unicode-separators','jan–pona jan—pona jan−pona')
add('proper.auto-on','Jan')
add('proper.auto-off-hidden','Jan',{'autoCartoucheStandaloneProperNames':False})
add('proper.auto-off-shown','Jan',{'autoCartoucheStandaloneProperNames':False,'showUnknownText':True})
add('unknown.hidden','xyzzy')
add('unknown.shown','xyzzy',{'showUnknownText':True})
add('unknown.core-single-quoted',"'xyzzy'",{'mode':'standard-sitelen-pona-ascii-core','showUnknownText':True})

# Early aliases: all aliases individually, and core mode exclusion.
aliases={
 'cartouche-start':"'cartouche-start' jan 'cartouche-end'",
 'zw-joiner':"toki'zw-joiner'pona",
 'stack-joiner':"toki'stack-joiner'pona",
 'nesting-joiner':"toki'nesting-joiner'pona",
 'ideographic-space':"jan'ideographic-space'pona",
 'long-delims':"pi'long-start'telo'long-end'",
 'left-right-bracket':"'left-bracket' jan 'right-bracket'",
 'middle-dot':"jan'middle-dot'pona",
 'colon':"jan'colon'pona",
 'tally':"[jan'tally''tally']",
}
for k,v in aliases.items(): add('early-alias.'+k,v)
for k,v in aliases.items(): add('core-alias-excluded.'+k,v,{'mode':'standard-sitelen-pona-ascii-core','showUnknownText':True})

# Raw Unicode precedence and exact runs.
add('raw.single','U+F1911')
add('raw.sequence-spaces','U+F1911 U+F1954')
add('raw.sequence-tabs','U+F1911\tU+F1954')
add('raw.embedded','jan U+F1911 U+F1954 pona')
add('raw.lowercase','u+f1911')
add('raw.invalid-following','U+F1911G',{'showUnknownText':True})

# Extended/SSK/core compound and long-glyph grammar.
for mode,prefix in [('sitelen-pona-ascii-extended','extended'),('sitelen-seli-kiwen','ssk'),('standard-sitelen-pona-ascii-core','core')]:
    for op,name in [('&','zw'),('-','stack'),('+','nest')]:
        add(f'{prefix}.compound.{name}',f'toki{op}pona',{'mode':mode})
    add(f'{prefix}.compound.chain','luka&luka&luka&luka',{'mode':mode})
    add(f'{prefix}.compound.mixed','jan-pona+mute&toki',{'mode':mode})
    add(f'{prefix}.compound.whitespace-invalid','toki & pona',{'mode':mode,'showUnknownText':True})

for mode,prefix in [('sitelen-pona-ascii-extended','extended'),('sitelen-seli-kiwen','ssk')]:
    add(f'{prefix}.long.current','pi(telo lete)',{'mode':mode})
    add(f'{prefix}.long.reverse','{telo lete}pi',{'mode':mode})
    add(f'{prefix}.long.combined','{jan pona}lon(telo lete)',{'mode':mode})
    add(f'{prefix}.long.compound-inner','pi(toki&pona jan+mute)',{'mode':mode})
    add(f'{prefix}.long.whitespace-before-paren','pi (telo)',{'mode':mode,'showUnknownText':True})

# Extended-only legacy long pi forms and rejection elsewhere.
legacy=['pi+telo','pi++telo lete','pi+++telo lete pona','pi--telo lete','pi---telo lete pona','pi+__telo','pi+__telo__lete','pi+__telo__lete__pona']
for i,s in enumerate(legacy):
    add(f'extended.legacy-long-pi.{i+1}',s,{'mode':'sitelen-pona-ascii-extended'})
    add(f'ssk.legacy-long-pi-excluded.{i+1}',s,{'mode':'sitelen-seli-kiwen','showUnknownText':True})
    add(f'core.legacy-long-pi-excluded.{i+1}',s,{'mode':'standard-sitelen-pona-ascii-core','showUnknownText':True})
add('core.long-pi','pi(telo lete)',{'mode':'standard-sitelen-pona-ascii-core'})
add('core.generic-long-excluded','lon(telo)',{'mode':'standard-sitelen-pona-ascii-core','showUnknownText':True})
add('core.reverse-long-excluded','{telo}pi',{'mode':'standard-sitelen-pona-ascii-core','showUnknownText':True})
add('core.legacy-brace-pi-excluded','pi { telo }',{'mode':'standard-sitelen-pona-ascii-core','showUnknownText':True})
add('core.full-width-space','jan|pona',{'mode':'standard-sitelen-pona-ascii-core'})

# Brackets/cartouches: literal, ordinary, compounds, aliases, tally modes, unknown fallback.
add('bracket.ordinary-one','[jan]')
add('bracket.ordinary-many','[jan pona mi toki]')
add('bracket.compound-zw','[toki&pona]')
add('bracket.compound-stack','[toki-pona]')
add('bracket.compound-nest','[toki+pona]')
add('bracket.compound-chain','[luka&luka&luka]')
add('bracket.legacy-underscore','[_jan_pona]',{'mode':'sitelen-pona-ascii-extended'})
add('bracket.legacy-underscore-not-ssk','[_jan_pona]',{'mode':'sitelen-seli-kiwen','showUnknownText':True})
add('bracket.literal-latin','["HELLO"]')
add('bracket.literal-latin-escaped','["A\\"B"]')
add('bracket.literal-latin-spaced-excluded','[ "HELLO" ]',{'showUnknownText':True})
add('bracket.tally-ucsur-one','[meli,]')
add('bracket.tally-ucsur-many','[meli,,,,,,,,]')
add('bracket.tally-ucsur-clamp','[meli,,,,,,,,,,]')
add('bracket.tally-between','[meli,pona]')
add('bracket.tally-disabled','[meli,,]',{'cartoucheCommaTallyMarks':False})
add('bracket.tally-mode-comma','[meli,,]',{'cartoucheTallyMode':'comma'})
add('bracket.tally-mode-manual','[meli,,]',{'cartoucheTallyMode':'manual'})
add('bracket.punctuation','[jan . pona · mi : toki]')
add('bracket.unknown','[xyzzy]')

# Quotes and quote interpretation, including active syntax inside interpreted quotes.
add('quote.literal-straight','"Hello"')
add('quote.literal-curly','“Hello”')
add('quote.escaped','"A\\"B"')
add('quote.interpreted-words','"jan pona"',{'interpretDoubleQuotesAsTeTo':True})
add('quote.interpreted-compound','"toki&pona"',{'interpretDoubleQuotesAsTeTo':True})
add('quote.interpreted-number','"123"',{'interpretDoubleQuotesAsTeTo':True})
add('quote.interpreted-unknown','"xyzzy"',{'interpretDoubleQuotesAsTeTo':True,'showUnknownText':True})

# Numeric whole-text integration. Frozen Core already tests low-level parser; these assert scanner boundaries/precedence.
numeric_inputs={
 'decimal':'123.45','negative':'-123.45','positive':'+123.45','percent':'10.5%',
 'fraction':'3/4','mixed-plus':'8+1/2','mixed-space':'8 1/2','vulgar-half':'½','vulgar-mixed':'2½',
 'scientific-e':'1.25e-3','scientific-times':'1*10^8','scientific-signed':'1*10+8',
 'magnitude-k':'12K','magnitude-m':'3.5M','thousands':'1,234,567.89',
 'time-hm':'12:30','time-hms':'1:02:03','time-fractional':'1:02:03.45',
 'date-full':'2026-09-17','date-yearless':'--09-17','date-leap-yearless':'--02-29',
 'number-code':'#~WTSLMJ','telephone-proper':'Toki Newan Ene Tusenan Ene Lululun Ene Numupijon',
 'hex-hash':'#a44eff','hex-proper':'Nasa Wan Tu Se','binary-prefix':'0b10101101',
}
for k,v in numeric_inputs.items(): add('numeric.'+k,v)
# Boundary / overlap / glyph-prefix cases.
for k,v in {
 'embedded':'jan 123.45 pona','two-numbers':'jan 12 pona 34 toki','date-time-precedence':'2026-09-17 12:30',
 'glyph-suffix-ni2':'ni2','glyph-suffix-ni020':'ni020','glyph-suffix-sewi020':'sewi020 34',
 'protected-ni02':'ni02 34','hex-no-glyph-split':'#a44eff','mixed-prose':'jan 8+1/2 pona 1:02:03.45 toki',
}.items(): add('scanner.'+k,v)

# Hex/binary options and actual binary (not the historically faulty #b... hex-like test).
add('option.hex-off','#a44eff',{'enableHexParsing':False,'showUnknownText':True})
add('option.binary-parsing-off','0b10101101',{'enableBinaryParsing':False,'enableBinaryRendering':False,'showUnknownText':True})
add('option.binary-rendering-enables-parsing','0b10101101',{'enableBinaryParsing':False,'enableBinaryRendering':True,'showUnknownText':True})
add('option.binary-parsing-on-rendering-off','0b10101101',{'enableBinaryParsing':True,'enableBinaryRendering':False,'showUnknownText':True})

# Bracket numeric precedence/types and typed heads.
for k,v in {
 'decimal':'[123.45]','time':'[12:30]','date':'[2026-09-17]','yearless':'[--09-17]',
 'hex':'[nasa : jan lawa kule ma pakala kule sike tan nasa]','binary':'[noka : wan ijo wan ijo wan noka]','code':'[#~W]',
 'typed-nanpa':'[nanpa : wan nanpa]','typed-tenpo':'[tenpo : wan tu kasi seli ijo nanpa]',
 'typed-suno':'[suno : wan nanpa]','typed-toki':'[toki : en wan e tu seli awen e luka luka luka e utala mun pipi jo nanpa]',
}.items(): add('bracket.numeric.'+k,v)
add('bracket.binary-off','[noka : wan ijo wan ijo wan noka]',{'enableBinaryParsing':False,'enableBinaryRendering':False,'showUnknownText':True})
add('bracket.hex-off','[nasa : jan lawa kule ma pakala kule sike tan nasa]',{'enableHexParsing':False,'showUnknownText':True})
add('bracket.colon-off','[nanpa : wan nanpa]',{'nanpaColonParsing':False,'nanpaColonRendering':False,'showUnknownText':True})

# Numeric parser/render switches.
add('numeric.abbreviated','123.45',{'abbreviateNumericCartouches':True})
add('integration.hello-compound-abbreviated','toki&pona 123',{'abbreviateNumericCartouches':True})
add('numeric.abbreviated-preserve','1,234.56',{'abbreviateNumericCartouches':True,'preserveNumericCartoucheBreaksInAbbreviation':True})
add('numeric.abbreviated-no-preserve','1,234.56',{'abbreviateNumericCartouches':True,'preserveNumericCartoucheBreaksInAbbreviation':False})
add('numeric.relaxed-off','123.45',{'relaxedNanpaLinjanParsing':False,'relaxedNanpaLinjanRendering':False})
add('numeric.nasin-nanpa-pona','12345',{'nasinNanpaPona':True})
add('numeric.mixed-style-long','8+1/2',{'mixedStyle':'long'})
for g in [None,'nanpa','tenpo','suno','toki']:
    add('numeric.start-glyph.'+(g or 'default'),'123.45',{'numericCartoucheStartGlyph':g})

# TP numeric phrase forms / abbreviated forms. These are high-risk browser branches.
phrase_inputs=[
 'nanpa e wan nanpa',
 'nanpa en wan nanpa',
 'nanpa esun wan nanpa',
 'nanpa e nena en wan nanpa',
 'nanpa e wan en tu nanpa',
 'nanpa e wan neko tu nanpa',
]
for i,s in enumerate(phrase_inputs): add(f'numeric.tp-phrase.{i+1}',s)
for i,s in enumerate(phrase_inputs): add(f'bracket.tp-phrase.{i+1}',f'[{s}]')
for i,s in enumerate(['nanpa wan nanpa','nanpa en wan nanpa','nanpa wan tu nanpa']):
    add(f'bracket.tp-abbreviated.{i+1}',f'[{s}]',{'abbreviateNumericCartouches':True})

# Document AST/newline/sentence/image behavior.
add('document.multiline','jan pona\nmi toki\n\npona')
add('document.crlf','jan pona\r\nmi toki')
add('document.sentence-breaks','jan pona. mi toki. 12.5. "Hello. World." [jan. pona].',{'breakLinesAtFullStops':True})
add('document.sentence-no-break','jan pona. mi toki.',{'breakLinesAtFullStops':False})
img="img(src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAIAAAD91JpzAAAAFElEQVR4nGP8z/D/PwMDAwMjI2MAAA8ABQUB/A1Q1KcAAAAASUVORK5CYII=',w=20,h=10,alt='dot',valign=center,wriggle=3,transparent=false)"
add('image.inline','jan '+img+' pona')
add('image.quoted-comma',"img(src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAIAAAD91JpzAAAAFElEQVR4nGP8z/D/PwMDAwMjI2MAAA8ABQUB/A1Q1KcAAAAASUVORK5CYII=',alt='a,b',w=12,h=8)")

# Production word adapters: all eight IDs. Identity-backed fonts are included explicitly.
adapters={
 'nasinNanpa':'identity','sitelenSeliKiwen':'identity','fairfaxHd':'identity','fairfaxPonaHd':'identity',
 'linjaPona':'linja-pona-legacy-v1','linjaSike':'linja-sike-legacy-v1','nasinSitelenPuMono':'nasin-sitelen-pu-mono-v1','linjaLipamanka':'linja-lipamanka-v1'
}
for font,adapter in adapters.items():
    add('adapter.'+font+'.word','jan pona',font=font)
    add('adapter.'+font+'.compound','toki&pona',font=font)
    add('adapter.'+font+'.long','pi(telo lete)',font=font)
    add('adapter.'+font+'.cartouche','[jan pona]',font=font)
    add('adapter.'+font+'.raw','U+F1911 U+F1954',font=font)

# Minimize plan to language-neutral semantic material we can compare in Go.
EXTRACT = r'''async ({cases, adapters}) => {
 const results=[];
 const R = await window.SitelenRenderer.create({});
 function astMin(ast){
   return {type:ast?.type||'', normalizedInput:ast?.normalizedInput||'', lines:(ast?.lines||[]).map(l=>({
     index:l.index, sourceLineIndex:l.sourceLineIndex, sentenceIndexInSourceLine:l.sentenceIndexInSourceLine,
     sourceText:l.sourceText||'', children:(l.children||[]).map(s=>({
       kind:s.kind||'', value:typeof s.value==='string'?s.value:null,
       openQuote:s.openQuote||null, closeQuote:s.closeQuote||null,
       image:(s.kind==='image' && s.value && typeof s.value==='object') ? {
         src:s.value.src||'', w:s.value.w||'', h:s.value.h||'', alt:s.value.alt||'', valign:s.value.valign||'',
         wriggle:Number(s.value.wriggle??0), transparent:s.value.transparent!==false
       } : null
     }))
   }))};
 }
 function runMin(x){
   const el=x?._element||{};
   return {
     kind:x.kind||'', renderMode:x.renderMode||'', fontRole:x.fontRole||'',
     sourceText:x.sourceText??'', sourceKind:x.sourceKind??'',
     canonicalCps:Array.from(x.canonicalCps||x.cps||[]),
     canonicalFullCps:Array.from(x.canonicalFullCps||[]),
     renderCps:Array.from(x.renderCps||[]),
     renderAdapterId:x.renderAdapterId||'identity', requestedRenderAdapterId:x.requestedRenderAdapterId||x.renderAdapterId||'identity',
     isQuoted:!!x.isQuoted, interpretedQuote:!!x.interpretedQuote, isUnrecognized:!!x.isUnrecognized,
     manualTallies:Array.isArray(x.manualTallies)?x.manualTallies:null,
     isNumericCartouche:!!el.isNumericCartouche,
     isLiteralCartouche:!!el.isLiteralCartouche,
     imageAlt:x.imageAlt??null,
     encodedText:typeof x.encodedText==='string'?x.encodedText:null
   };
 }
 for (const c of cases){
   const adapter=adapters[c.font]||'identity';
   let ok=true,error=null,ast=null,runs=[];
   try {
     const plan=await R.buildRenderPlan({input:c.input,parser:c.parser,fonts:{renderAdapterId:adapter}});
     ast=astMin(plan.ast);
     runs=(plan.lines||[]).flatMap(l=>l.runs||[]).map(runMin);
   } catch(e){ok=false;error=String(e?.stack||e);}
   results.push({...c,oracle:{ok,error,ast,runs}});
 }
 return results;
}'''

def main():
    js = JS_PATH.read_text(encoding='utf-8')
    sha=hashlib.sha256(js.encode()).hexdigest()
    for s in ['export { SitelenRenderer };','export const NanpaParser = SitelenRenderer.NanpaParser;','export default SitelenRenderer;']:
        js=js.replace(s,'')
    adapters={'nasinNanpa':'identity','sitelenSeliKiwen':'identity','fairfaxHd':'identity','fairfaxPonaHd':'identity','linjaPona':'linja-pona-legacy-v1','linjaSike':'linja-sike-legacy-v1','nasinSitelenPuMono':'nasin-sitelen-pu-mono-v1','linjaLipamanka':'linja-lipamanka-v1'}
    with sync_playwright() as pw:
        browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        page=browser.new_page()
        page.set_content('<!doctype html><html><body></body></html>')
        page.add_script_tag(content=js)
        results=page.evaluate(EXTRACT,{'cases':CASES,'adapters':adapters})
        random_cps_cases={
            'proper.auto-on','core-alias-excluded.tally','bracket.legacy-underscore-not-ssk',
            'numeric.hex-proper','bracket.hex-off','bracket.colon-off','bracket.tp-phrase.6',
            'bracket.tp-abbreviated.1','bracket.tp-abbreviated.2','bracket.tp-abbreviated.3',
        }
        for item in results:
            if item.get('id') in random_cps_cases:
                item['randomCps']=True
        browser.close()
    failed=[x for x in results if not x['oracle']['ok']]
    data={'version':'1.0.1','authority':{'path':str(JS_PATH.relative_to(ROOT)),'sha256':sha},'description':'Frozen branch-oriented canonical full-renderer semantic oracle generated directly from the bundled JavaScript renderer. Geometry is covered by existing profile tests; this corpus targets parser, AST, semantic runs, numeric scanning, syntax modes, aliases, options, cartouches, quotes, images, and all production adapter IDs.','caseCount':len(results),'cases':results}
    OUT.parent.mkdir(parents=True,exist_ok=True)
    OUT.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f'wrote {OUT} cases={len(results)} oracleErrors={len(failed)} sha={sha}')
    if failed:
        for c in failed: print('ERROR',c['id'],c['oracle']['error'],file=sys.stderr)
        return 1
    return 0

if __name__=='__main__': raise SystemExit(main())
