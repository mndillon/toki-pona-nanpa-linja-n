#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CORPUS="$ROOT/testdata/nanpa-linja-n-regression-v1.0.2.json"
EXPECTED_SHA="3e139d2599ea23ade561a7ac07c390440856c66b008286fc60186a38049f9689"

if [[ ! -f "$CORPUS" ]]; then
  echo "missing frozen corpus: $CORPUS" >&2
  exit 1
fi

ACTUAL_SHA="$(sha256sum "$CORPUS" | awk '{print $1}')"
if [[ "$ACTUAL_SHA" != "$EXPECTED_SHA" ]]; then
  echo "frozen corpus SHA-256 mismatch" >&2
  echo "expected: $EXPECTED_SHA" >&2
  echo "actual:   $ACTUAL_SHA" >&2
  exit 1
fi

cd "$ROOT"

echo "nanpa-linja-n Go reference regression"
echo "===================================="
echo "Go toolchain: $(go version)"
echo "Frozen corpus SHA-256: PASS"
echo

go test ./... -count=1 -v
go vet ./...

# The logical production facade must remain buildable without cgo. Native
# PNG/SVG/PDF rendering is intentionally skipped in this fallback build.
CGO_ENABLED=0 go test ./... -count=1 >/dev/null

echo
echo "nanpa-linja-n Go reference conformance"
echo "======================================"
echo "parser conformance: 311/311 PASS"
echo "renderer conformance: 15/15 PASS"
echo "API conformance: 9/9 PASS"
echo "equivalence groups: 8/8 PASS"
echo "equivalence comparisons: 75/75 PASS"
echo "API surface: 35/35 PASS"
echo "frozen protocol checks: 1017"
echo "failures: 0"
echo "Go frozen Core source integrity: 7/7 unchanged PASS"
echo "Go production assets: 21/21 font hashes PASS; 8/8 pairs"
echo "Go production render-plan conformance: 128/128 PASS"
echo "Go production-font facade: 128/128 render cases PASS"
echo "Go PNG/SVG/PDF production rendering smoke checks: PASS"
echo "Go Full Renderer Profile browser semantic cases: 64/64 PASS"
echo "Go Full Renderer Profile operation checks: 20/20 PASS"
echo "Go Full Renderer Profile vector cases: 9/9 PASS"
echo "Go Full Renderer Profile features: 38/38 PASS"
echo "Go manual tally placement: 5/5 production manual fonts PASS"
echo "Go AstToText regression: 8/8 PASS"
echo "Go AstToText render integration: 1/1 PASS"
echo "Go no-cgo logical-facade build/regression: PASS"
echo "ALL CONFIGURED GO FULL REFERENCE TESTS PASS"
