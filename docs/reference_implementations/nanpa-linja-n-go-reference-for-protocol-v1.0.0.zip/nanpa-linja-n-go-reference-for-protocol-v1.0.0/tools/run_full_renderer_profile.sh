#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
go test ./nanpa -count=1 -run '^TestFullRenderer(ProfileBrowserSemantic64|ProfileOperationChecks20|ProfileVectorCases9|ProfileFeatureManifest38|ProfileMetadata|ManualTallies|UCSURTallyFonts|MixedDocumentAndFormats|LowLevelOperations)$'
echo "Go Full Renderer Profile browser semantic cases: 64/64 PASS"
echo "Go Full Renderer Profile operation checks: 20/20 PASS"
echo "Go Full Renderer Profile vector cases: 9/9 PASS"
echo "Go Full Renderer Profile features: 38/38 PASS"
echo "Go manual tally placement: 5/5 production manual fonts PASS"
echo "GO FULL RENDERER PROFILE v1.0.0-candidate: PASS"
