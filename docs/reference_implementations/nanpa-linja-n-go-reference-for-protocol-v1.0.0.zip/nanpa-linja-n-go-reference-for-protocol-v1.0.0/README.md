# nanpa-linja-n Go reference implementation

Native Go reference implementation of **nanpa-linja-n Protocol v1.0.0**, targeting the frozen language-neutral **conformance corpus v1.0.2**, the Production Rendering Profile, and **Full Renderer Profile v1.0.0-candidate** derived from the canonical JavaScript renderer.

The Core-v1 semantics are implemented directly in Go. The production facade is additive: the seven frozen Core source files are hash-pinned and unchanged from the v0.1.0 Go reference.

Reference implementation version: **0.3.0**.

## What is included

- Core-v1 parser/semantic implementation
- Binding-v1 public API mapping (35 frozen operations)
- frozen Protocol v1.0.0 regression corpus
- high-level `NanpaLinjaN` production-rendering facade
- all 8 production font pairs and the approved production manifest
- automatic legacy adaptation for `linjaPona` and `linjaSike`
- dynamic `ss12` / `ss13` OpenType feature selection by font size
- native PNG, SVG, and PDF output on Linux with cgo
- 128-case cross-language render-plan conformance suite
- 128-case production-font native rendering suite
- native full-document parser/layout/rendering surface for mixed sitelen pona, ordinary cartouches, numeric cartouches, literal quotes, unknown text, multiline layout, and inline images
- native full-document PNG, SVG, PDF, and Canvas-equivalent output
- low-level run/text/UCSUR rendering operations and runtime render-adapter registration
- 64-case canonical-browser semantic parity suite, 20 operation checks, 9 vector cases, and 38 feature areas
- explicit manual-tally ownership/placement qualification for all 5 manual-tally production fonts
- `test-output` visual audit exporters producing 72 PNGs

No JavaScript or Python subprocess is used. The Go module has **no third-party Go dependencies**.

## Quick production API

```go
package main

import (
    "os"

    nanpa "nanpa-linja-n.com/nanpa"
)

func main() {
    renderer, err := nanpa.CreateNanpaLinjaN()
    if err != nil {
        panic(err)
    }
    defer renderer.Close()

    // Defaults: nasinNanpa, 56px, relaxed/Nanpa-format Core profile.
    png, err := renderer.RenderToPNG("123.45")
    if err != nil {
        panic(err)
    }
    _ = os.WriteFile("number.png", png, 0644)

    opts := nanpa.DefaultRenderOptions()
    opts.Font = "linjaPona"
    opts.FontSize = 29

    png, err = renderer.RenderToPNG("12:30", opts)
    if err != nil {
        panic(err)
    }
    _ = os.WriteFile("time.png", png, 0644)

    svg, _ := renderer.RenderToSVG("#ABCDEF")
    _ = os.WriteFile("hex.svg", svg, 0644)

    pdf, _ := renderer.RenderToPDF("0b10101")
    _ = os.WriteFile("binary.pdf", pdf, 0644)
}
```

The caller selects a production font by key or alias. The facade automatically handles canonical UCSUR versus legacy ASCII-ligature syntax; callers do not need to know adapter IDs such as `linja-pona-legacy-v1`.

## Full renderer API

The original numeric production facade above remains unchanged. Full JavaScript-renderer functionality is additive through the Go full-renderer binding:

```go
opts := nanpa.DefaultFullRenderOptions()
opts.Font = "linjaPona"
opts.FontSize = 56

plan, err := renderer.BuildFullRenderPlan(`mi toki e ni: [jan pona,,] 123.45 "Hello"`, opts)
if err != nil { panic(err) }

png, _ := renderer.RenderFullToPNG(`jan [pona,,] 123.45`, opts)
svg, _ := renderer.RenderFullToSVG(`jan [pona,,] 123.45`, opts)
pdf, _ := renderer.RenderFullToPDF(`jan [pona,,] 123.45`, opts)
_ = plan
_ = png
_ = svg
_ = pdf
```

Full-renderer methods include:

- `ParseInput`
- `AstToText`
- `BuildFullRenderPlan`
- `RenderFull`
- `RenderToCanvas`
- `RenderFullToPNG`
- `RenderFullToSVG`
- `RenderFullToPDF`
- `RenderRunToNewCanvas`
- `RenderTextToNewCanvas` / `RenderTextToCanvas`
- `RenderUcsurToNewCanvas` / `RenderUcsurToCanvas`
- `RegisterRenderAdapter` / `GetRenderAdapter` / `RemoveRenderAdapter`
- `ToVectorDocument`

Go cannot overload `BuildRenderPlan`/`RenderToPNG` by option type, so the full-document operations use explicit `Full` names while the frozen numeric production API remains source-compatible.


### Editing a parsed document AST

`ParseInput` returns the Go full-document `DocumentAST`. `AstToText` serializes the current AST contents back into valid nanpa-linja-n source without changing the existing rendering pipeline. The package-level `nanpa.AstToText(ast)` function and `renderer.AstToText(ast)` method are equivalent.

```go
ast := renderer.ParseInput(`jan   pona [ jan  pona,, ]`)

for li := range ast.Lines {
    for si := range ast.Lines[li].Children {
        segment := &ast.Lines[li].Children[si]
        if segment.Kind == "bracket" {
            segment.Value = " jan  suno,, "
        }
    }
}

editedText, err := renderer.AstToText(ast)
if err != nil { panic(err) }

png, err := renderer.RenderFullToPNG(editedText)
if err != nil { panic(err) }
_ = png
```

Normal editable content fields are `DocumentSegment.Value` for `text`, `bracket`, and `quote` segments; `OpenQuote` / `CloseQuote` for quote delimiters; and the existing fields of `ImageDescriptor` for `image` segments. `Index`, `SourceLineIndex`, `SentenceIndexInSourceLine`, `SourceText`, `SourceStart`, `SourceEnd`, `NormalizedInput`, and segment `Kind` are structural/source metadata and normally should not be edited. `SourceLineIndex` is used to reconstruct the original physical line boundaries when `BreakLinesAtFullStops` split one source line into multiple AST lines.

Whitespace retained in segment values, including repeated spaces, tabs, blank lines, cartouche interior spacing, and quote delimiters, is preserved. `img(...)` is emitted in canonical valid form from its parsed `ImageDescriptor`, so its exact original argument spacing/quoting is not guaranteed. Parser newline normalization also means CRLF input serializes as LF.

### Manual tally placement

For the five manifest `manual` tally fonts (`nasinNanpa`, `linjaPona`, `linjaSike`, `nasinSitelenPuMono`, and `linjaLipamanka`), **U+F199E is never inserted into the shaped font run**. Synthetic tally strokes are attached to the owning canonical glyph and derive their X position from that glyph's caret span in the complete adapted layout. The full native renderer uses a font-file-isolated Pango/Fontconfig map so companion-font registration cannot change base-font metrics. The browser/Pango geometry comparison permits a 1.5px backend tolerance; ownership and centering are exact in the Go shaped layout.

The three UCSUR-tally fonts (`sitelenSeliKiwen`, `fairfaxHd`, `fairfaxPonaHd`) retain U+F199E in the font run and do not receive synthetic tally groups.

### Production facade methods

- `CreateNanpaLinjaN()`
- `ListFonts()`
- `GetFontInfo(font)`
- `Parse(input, options)`
- `BuildRenderPlan(input, options...)`
- `Render(input, format, options...)`
- `RenderToPNG(input, options...)`
- `RenderToSVG(input, options...)`
- `RenderToPDF(input, options...)`
- `Close()`

`BuildRenderPlan` is available even when native graphical rendering is unavailable.

## Production font keys

The bundled profile exposes exactly these eight pairs:

- `nasinNanpa`
- `sitelenSeliKiwen`
- `fairfaxHd`
- `fairfaxPonaHd`
- `linjaPona`
- `linjaSike`
- `nasinSitelenPuMono`
- `linjaLipamanka`

`linjaPona` and `linjaSike` are automatically translated to their native legacy underscore-cell syntax. The production colon exception is preserved as literal ASCII `:`. Identity/UCSUR fonts receive canonical production codepoints directly.

## Native rendering requirements

Core-v1 and render-plan construction are ordinary Go and build without cgo.

Graphical PNG/SVG/PDF production rendering currently targets **Linux with cgo** and dynamically loads the runtime libraries:

- Pango / PangoCairo
- PangoFT2 / HarfBuzz stack
- Cairo
- Fontconfig
- GObject/GLib

Development headers are not required by this package because the runtime libraries are loaded dynamically. If native rendering is unavailable, `BuildRenderPlan` remains usable and the graphical methods return a clear error.

## Conformance scope

Frozen corpus identity:

```text
file:   nanpa-linja-n-regression-v1.0.2.json
sha256: 3e139d2599ea23ade561a7ac07c390440856c66b008286fc60186a38049f9689
```

The production suite also pins:

- 7 frozen Go Core source hashes
- 21 production font asset hashes
- 8 production font pairs
- 16 logical cases × 8 fonts = 128 render-plan checks
- 16 logical cases × 8 fonts = 128 native graphical render checks
- 64 frozen canonical-browser full-renderer semantic cases
- 20 Full Renderer Profile operation checks
- 9 vector-export cases
- 38 Full Renderer Profile feature areas
- 5/5 manual-tally production-font placement checks

A successful complete regression ends with:

```text
frozen protocol checks: 1017
failures: 0
Go frozen Core source integrity: 7/7 unchanged PASS
Go production assets: 21/21 font hashes PASS; 8/8 pairs
Go production render-plan conformance: 128/128 PASS
Go production-font facade: 128/128 render cases PASS
Go PNG/SVG/PDF production rendering smoke checks: PASS
Go Full Renderer Profile browser semantic cases: 64/64 PASS
Go Full Renderer Profile operation checks: 20/20 PASS
Go Full Renderer Profile vector cases: 9/9 PASS
Go Full Renderer Profile features: 38/38 PASS
Go manual tally placement: 5/5 production manual fonts PASS
Go AstToText regression: 8/8 PASS
Go AstToText render integration: 1/1 PASS
ALL CONFIGURED GO FULL REFERENCE TESTS PASS
```

## Requirements

- Go 1.18 or later
- a POSIX shell for `tools/run_go_regression.sh`
- `sha256sum`
- cgo + the native rendering libraries above for PNG/SVG/PDF qualification

## Run the complete regression

From the repository root:

```bash
./tools/run_go_regression.sh
```

You can also run:

```bash
go test ./... -count=1
go vet ./...
```

Run only the full-renderer qualification with:

```bash
./tools/run_full_renderer_profile.sh
```

Generate visual audit output with:

```bash
./tools/export_visual_pngs.sh
./tools/export_cartouche_audit.sh
find test-output -type f -name '*.png' | wc -l
```

The expected count is **72 PNGs**: 32 numeric views and 40 ordinary-cartouche/tally audit views including one contact sheet per production font.

## Core API example

The original Binding-v1 API remains unchanged:

```go
import nanpa "nanpa-linja-n.com/nanpa"

opts := nanpa.Options{
    Mode:                        "uniform",
    MixedStyle:                  "short",
    RelaxedNanpaLinjanParsing:   true,
    RelaxedNanpaLinjanRendering: true,
    NanpaColonParsing:           true,
    NanpaColonRendering:         true,
    EnableHexParsing:            true,
    EnableBinaryParsing:         true,
}

result, err := nanpa.ParseNumber("12:30", opts)
if err != nil {
    panic(err)
}

fmt.Println(result.DisplayValue)
fmt.Println(result.TpWords)
```

## CLI

The original reference command is retained:

```bash
go run ./cmd/nanpa-linja-n parse '12:30'
go run ./cmd/nanpa-linja-n parse '--02-29'
go run ./cmd/nanpa-linja-n parse '#ABCDEF'
go run ./cmd/nanpa-linja-n parse '0b10101'
go run ./cmd/nanpa-linja-n encode '123.456'
go run ./cmd/nanpa-linja-n decode 'NEWETESEN'
```

## Protocol invariants preserved

The implementation preserves the frozen protocol distinctions, including:

- decimal numeric cartouches close with `nanpa`
- decimal semantic/opening glyphs may be `nanpa`, `tenpo`, `suno`, or `toki`
- hexadecimal cartouches use `nasa ... nasa`
- binary cartouches use `noka ... noka`
- `toki` is a decimal numeric start glyph, not a separate telephone type
- strict and relaxed nanpa-linja-n digit syllables remain distinct
- signed two-field clock input such as `-12:30` remains rejected by the frozen corpus
- yearless dates and single-number `suno` forms preserve their frozen semantic behavior

The Production Rendering Profile additionally normalizes the rendered date separator to `kasi` and the full positive `toki` telephone head to `nena en`, without changing the frozen Core parser representation.

## Repository layout

```text
nanpa-linja-n-go-reference-for-protocol-v1.0.0/
├── assets/
│   ├── embed.go
│   └── fonts/                 # complete production font asset set + manifest
├── cmd/nanpa-linja-n/
├── nanpa/
│   ├── frozen Core-v1 sources
│   ├── facade.go
│   ├── production_fonts.go
│   ├── production_adapter.go
│   ├── native_renderer_linux.go
│   ├── native_renderer_stub.go
│   └── production_facade_test.go
├── testdata/
│   ├── nanpa-linja-n-regression-v1.0.2.json
│   ├── core-source-sha256-v1.0.0.json
│   └── production/
├── tools/run_go_regression.sh
├── go.mod
└── README.md
```

## Reference status

Protocol v1.0.0 and its frozen corpus remain normative. This Go implementation is an independent executable interpretation of the same protocol and Production Rendering Profile; implementation code does not override the protocol.
