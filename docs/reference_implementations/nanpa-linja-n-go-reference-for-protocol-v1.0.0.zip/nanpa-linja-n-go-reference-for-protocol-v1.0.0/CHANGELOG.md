# Changelog

## 0.3.0 — Full Renderer Profile v1.0.0-candidate

- Added a native Go full-document renderer alongside the unchanged frozen Core-v1/numeric production facade.
- Added document parsing, ordinary cartouches, literal/unknown text, multiline layout, inline images, Canvas-equivalent rendering, PNG/SVG/PDF, vector documents, and low-level run/text/UCSUR operations.
- Added runtime render-adapter registration.
- Added canonical browser semantic qualification: 64 parity cases, 20 operation checks, 9 vector cases, and 38 feature areas.
- Added exact-font-file Pango/Fontconfig layout isolation for full rendering so companion font registration cannot alter base-font selection.
- Fixed manual tally placement for the five manual-tally production fonts. U+F199E is excluded from manual font runs and synthetic tallies derive from the complete shaped owner-glyph span.
- Preserved all existing 1,017 frozen Protocol checks, 128/128 production render-plan checks, and 128/128 existing native production render cases.
- Added 72-image `test-output` visual audit exporters.
