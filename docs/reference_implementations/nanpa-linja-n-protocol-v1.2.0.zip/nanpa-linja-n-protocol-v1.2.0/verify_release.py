#!/usr/bin/env python3
from pathlib import Path
import hashlib, importlib.util, json, shutil, subprocess, sys

root=Path(__file__).resolve().parent

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fail(*msg):
    print('FAIL',*msg); raise SystemExit(1)

def require(cond,*msg):
    if not cond: fail(*msg)

manifest=json.loads((root/'release-manifest.json').read_text())
require(manifest.get('protocolVersion')=='1.2.0' and manifest.get('status')=='final','release manifest identity')
seen=set()
for item in manifest.get('bundledFiles',[]):
    rel=item.get('path'); require(rel and rel not in seen,'invalid/duplicate manifest path',rel); seen.add(rel)
    p=root/rel; require(p.is_file(),'missing bundled file',rel)
    require(sha(p)==item.get('sha256') and p.stat().st_size==item.get('size'),'bundled file hash/size mismatch',rel)
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='release-manifest.json'}
require(actual==seen,'release manifest file-set mismatch','missing-from-manifest='+str(sorted(actual-seen)),'stale='+str(sorted(seen-actual)))

proto=json.loads((root/'protocol.json').read_text())
require(proto.get('protocol')=='nanpa-linja-n' and proto.get('protocolVersion')=='1.2.0' and proto.get('status')=='final','protocol identity')

# Frozen Core-v1 contract.
core_path=root/proto['core']['conformanceCorpus']; core=json.loads(core_path.read_text()); core_sha=sha(core_path)
EXPECTED_CORE='e4baf51251861c114f5314fc2af05eb44e1b5dbcbdebdcd2678c868f5dbf306a'
require(core_sha==EXPECTED_CORE==proto['core']['conformanceCorpusSha256'],'Core-v1 corpus identity',core_sha)
require(len(core.get('parserCases',[]))==320 and proto['core'].get('parserCases')==320,'Core parser case count')
require(proto['core'].get('conformanceChecks')==1030,'Core conformance check count')
require(len(proto['core'].get('publicOperations',[]))==35 and len(set(proto['core']['publicOperations']))==35,'Core operation count')

# Current parser/renderer profile and pinned source.
pr=proto['parserRendererProfile']; profile_path=root/pr['normativeProfile']; profile=json.loads(profile_path.read_text()); profile_sha=sha(profile_path)
require(profile.get('profileVersion')=='1.2.0' and profile_sha==pr['normativeProfileSha256'],'parser/renderer profile identity')
reg_path=root/pr['normativeRegressionCorpus']; reg=json.loads(reg_path.read_text()); reg_sha=sha(reg_path)
require(reg_sha==pr['normativeRegressionCorpusSha256'],'parser regression hash')
require(reg.get('protocolVersion')=='1.2.0' and reg.get('caseCount')==24 and len(reg.get('cases',[]))==24,'parser regression identity/count')
ids=[c.get('id') for c in reg['cases']]; require(len(set(ids))==24,'duplicate parser regression id')
counts={}
for c in reg['cases']: counts[c['category']]=counts.get(c['category'],0)+1
require(counts=={'full-stop':10,'direct-csp-ucsur':12,'quote-escape':2},'parser regression category counts',counts)
reg_schema=root/pr['normativeRegressionSchema']; require(sha(reg_schema)==pr['normativeRegressionSchemaSha256'],'parser regression schema hash')

source_meta=json.loads((root/'references/current-javascript-source.json').read_text()); source_path=root/source_meta['bundledPath']; source_sha=sha(source_path)
EXPECTED_SOURCE='6bfcb77e5177eec4d923bbd24d60dbac211e574b62e128e6dbfc07f8e859d220'
require(source_sha==EXPECTED_SOURCE==pr['canonicalRendererSha256']==source_meta['sha256'],'canonical JavaScript source hash')
require(source_meta.get('bytes')==source_path.stat().st_size==626248,'canonical JavaScript source size')
require(source_meta.get('nanpaParserOperationCount')==35,'source metadata operation count')

# Stable defaults and v1.2 promoted semantics.
defs=profile.get('defaults',{})
for k,v in {
 'numericMode':'uniform','relaxedNanpaLinjanParsing':True,'relaxedNanpaLinjanRendering':True,
 'nanpaColonParsingEffective':True,'nanpaColonRendering':True,'abbreviateNumericCartouches':True,
 'preserveNumericCartoucheBreaksInAbbreviation':False,'breakLinesAtFullStops':False,
 'interpretDoubleQuotesAsTeTo':False,'enableHexParsing':False,'enableBinaryParsing':False,
 'enableBinaryRendering':False,'nasinNanpaPona':False,'defaultRenderAdapterId':'identity'
}.items(): require(defs.get(k)==v,'default mismatch',k,defs.get(k),v)
fs=profile.get('fullStopParsing',{})
require(fs.get('ordinaryParserTextMapsToCanonicalMiddleDot') is True and fs.get('canonicalMiddleDot')=='U+F199C','full-stop profile invariant')
require(fs.get('literalQuotePreservesAsciiFullStop') is True and fs.get('literalCartouchePreservesAsciiFullStop') is True,'full-stop literal preservation invariant')
require(fs.get('numericRecognitionPrecedesOrdinaryPunctuationFallback') is True,'numeric/full-stop precedence invariant')
du=profile.get('directCspUcsurInput',{})
require(du.get('sourcePreservation',{}).get('sourceEncodingValue')=='mixed-csp-unicode','direct UCSUR source metadata invariant')
require(du.get('normalParserSemanticsAfterCanonicalization') is True,'direct UCSUR parser-pipeline invariant')
require(du.get('specialMappings',{}).get('U+200D')=='&' and du.get('specialMappings',{}).get('U+F199C')=='.','direct UCSUR mapping invariant')
qe=profile.get('quoteEscapes',{})
require(qe.get('oddBackslashCountEscapes') is True and qe.get('evenBackslashCountCloses') is True,'quote parity invariant')

# Production-Font-Profile-v1.1 remains frozen/unchanged.
font_path=root/proto['renderingProfile']['fontPairsManifest']; fonts=json.loads(font_path.read_text()); font_sha=sha(font_path)
EXPECTED_FONT='50b8a4b6cab0c27f2061f94e404a2af992cbf95c8097c58caa5e6b2dc4625f09'
require(font_sha==EXPECTED_FONT==proto['renderingProfile']['fontPairsManifestSha256'],'production font manifest hash')
require(fonts.get('schema')==2 and len(fonts.get('pairs',[]))==8,'production font manifest schema/count')
require(len({p.get('fontKey') for p in fonts['pairs']})==8,'duplicate fontKey')
require({p.get('renderAdapterId') for p in fonts['pairs'] if p.get('renderAdapterId')}=={'linja-pona-legacy-v1','linja-sike-legacy-v1','nasin-sitelen-pu-mono-v1','linja-lipamanka-v1'},'production adapter inventory')
for pair in fonts['pairs']:
    require(pair.get('parserMode')=='sitelen-pona-ascii-extended','unexpected production parser mode',pair.get('fontKey'))
    settings=pair.get('settings',{}); require(settings.get('cartoucheVulgarFractions') is True,'cartoucheVulgarFractions must remain true',pair.get('fontKey'))
    require(settings.get('emulateLegacyCartoucheScaling') is False,'legacy scale emulation must remain false',pair.get('fontKey'))
require(proto['renderingProfile'].get('requiredLegacyStylisticSetFeatures')==[],'legacy stylistic sets must not be required')

golden_path=root/proto['renderingProfile']['logicalGoldenCases']; golden=json.loads(golden_path.read_text())
require(golden.get('schemaVersion')=='1.1.0' and len(golden.get('cases',[]))==16,'logical production rendering inventory')
require(len({c.get('id') for c in golden['cases']})==16,'duplicate logical rendering case id')

# Historical visual evidence remains clearly historical.
refs=json.loads((root/'references/reference-implementations.json').read_text())
require('historical' in refs.get('historicalV101Evidence',{}).get('status','').lower(),'historical evidence status')
require(proto['renderingProfile'].get('currentJavascriptApprovedVisualArtifactsBundled')==0,'current visual qualification incorrectly claimed')

print(f"PASS {len(manifest['bundledFiles'])} frozen bundled files")
print('PASS Core-v1 corpus retained:',core_sha)
print('PASS Parser-Renderer-Profile-v1.2:',profile_sha)
print('PASS parser/renderer regression corpus:',reg_sha,'24 cases')
print('PASS canonical JavaScript:',source_sha)
print('PASS Production-Font-Profile-v1.1 retained:',font_sha)

# Optional executable source validation.
node=shutil.which('node')
if node:
    cp=subprocess.run([node,str(root/'conformance/verify-current-javascript.mjs')],cwd=root,text=True,capture_output=True)
    if cp.returncode!=0:
        sys.stdout.write(cp.stdout); sys.stderr.write(cp.stderr); fail('JavaScript profile smoke verifier')
    for line in cp.stdout.splitlines():
        if line.startswith('PASS '): print(line)
else: print('SKIP JavaScript source verifier (node not found)')

# Optional browser execution of the normative document-parser corpus.
has_playwright=importlib.util.find_spec('playwright') is not None
chromium=shutil.which('chromium') or shutil.which('chromium-browser') or shutil.which('google-chrome')
if has_playwright and chromium:
    cp=subprocess.run([sys.executable,str(root/'conformance/verify-parser-renderer-regressions.py')],cwd=root,text=True,capture_output=True)
    if cp.returncode!=0:
        sys.stdout.write(cp.stdout); sys.stderr.write(cp.stderr); fail('browser parser/renderer regression verifier')
    for line in cp.stdout.splitlines():
        if line.startswith('PASS '): print(line)
else: print('SKIP browser parser/renderer regression verifier (Playwright/Chromium unavailable)')
