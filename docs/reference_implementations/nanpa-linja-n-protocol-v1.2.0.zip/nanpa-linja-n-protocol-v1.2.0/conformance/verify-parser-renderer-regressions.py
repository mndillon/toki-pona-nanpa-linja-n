#!/usr/bin/env python3
"""Execute the Protocol v1.2 document-parser regression corpus against the pinned JavaScript source.

This verifier is reference-evidence tooling, not a requirement that non-JavaScript bindings use Playwright.
Other bindings should consume parser-renderer-regression-v1.2.0.json directly and compare the same
AST/source metadata and language-neutral semantic summaries.
"""
from pathlib import Path
import json, re, shutil, sys

ROOT=Path(__file__).resolve().parents[1]
CORPUS=ROOT/'conformance/parser-renderer-regression-v1.2.0.json'
SOURCE=ROOT/'references/canonical/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js'

def fail(msg):
    print('FAIL', msg)
    raise SystemExit(1)

def fmt_cp(n): return f'U+{int(n):04X}'

def clean_ast(ast):
    lines=[]
    for line in ast.get('lines',[]):
        item={'sourceText':line.get('sourceText',''), 'segments':[{'kind':s.get('kind'),'value':s.get('value')} for s in line.get('children',[])]}
        if 'canonicalSourceText' in line: item['canonicalSourceText']=line['canonicalSourceText']
        if 'sourceEncoding' in line: item['sourceEncoding']=line['sourceEncoding']
        lines.append(item)
    return {'normalizedInput':ast.get('normalizedInput',''), 'lineCount':len(lines), 'lines':lines}

def semantic_summary(lines):
    result=[]
    for els in lines:
        cps=[]; literals=[]; classes=[]; kinds=[]
        for e in els:
            if e.get('type')=='gap': continue
            kinds.append(e.get('type'))
            if e.get('type')=='text': literals.append(e.get('text') or '')
            if e.get('type')=='cartouche':
                classes.append('literal' if e.get('isLiteralCartouche') else ('number' if e.get('fontRole')=='number' else 'ordinary'))
            arr=e.get('canonicalCps')
            if arr is None: arr=e.get('cps')
            if arr is None and e.get('cp') is not None: arr=[e.get('cp')]
            if arr: cps.extend(fmt_cp(x) for x in arr)
        result.append({'elementKinds':kinds,'canonicalCodepoints':cps,'literalTexts':literals,'cartoucheClasses':classes})
    return result

try:
    from playwright.sync_api import sync_playwright
except Exception as e:
    fail(f'Playwright is required for the canonical JavaScript regression verifier: {e}')

chromium=shutil.which('chromium') or shutil.which('chromium-browser') or shutil.which('google-chrome')
if not chromium: fail('Chromium/Chrome not found')

corpus=json.loads(CORPUS.read_text(encoding='utf-8'))
source=SOURCE.read_text(encoding='utf-8')
source=re.sub(r'\nexport \{ SitelenRenderer \};\nexport const NanpaParser = SitelenRenderer\.NanpaParser;\nexport default SitelenRenderer;\s*$', '\n', source)

with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path=chromium, args=['--no-sandbox'])
    page=browser.new_page()
    page.set_content('<!doctype html><html><body></body></html>')
    page.add_script_tag(content=source)
    for case in corpus['cases']:
        actual=page.evaluate('''async ({input,parser})=>{
          const r=await SitelenRenderer.create({parser});
          const parsed=await r.parseInput({input,parser});
          const plan=await r.buildRenderPlan({input,parser,layout:{fontPx:32}});
          const simplify=e=>({type:e.type,cp:e.cp??null,cps:e.cps??null,canonicalCps:e.canonicalCps??null,text:e.text??null,isLiteralCartouche:!!e.isLiteralCartouche,fontRole:e.fontRole??null});
          return {ast:parsed.ast,lines:(plan.linesElements||[]).map(xs=>xs.map(simplify))};
        }''', {'input':case['input'],'parser':case.get('parserOptions',{})})
        got_ast=clean_ast(actual['ast']); got_sem=semantic_summary(actual['lines'])
        exp=case['expected']
        if got_ast != exp['ast']:
            fail(f"{case['id']} AST mismatch\nexpected={json.dumps(exp['ast'],ensure_ascii=False)}\nactual={json.dumps(got_ast,ensure_ascii=False)}")
        if got_sem != exp['semantic']:
            fail(f"{case['id']} semantic mismatch\nexpected={json.dumps(exp['semantic'],ensure_ascii=False)}\nactual={json.dumps(got_sem,ensure_ascii=False)}")
        equivalent=exp.get('equivalentCanonicalInput')
        if equivalent is not None:
            eq=page.evaluate('''async ({input,parser})=>{
              const r=await SitelenRenderer.create({parser});
              const plan=await r.buildRenderPlan({input,parser,layout:{fontPx:32}});
              const simplify=e=>({type:e.type,cp:e.cp??null,cps:e.cps??null,canonicalCps:e.canonicalCps??null,text:e.text??null,isLiteralCartouche:!!e.isLiteralCartouche,fontRole:e.fontRole??null});
              return (plan.linesElements||[]).map(xs=>xs.map(simplify));
            }''', {'input':equivalent,'parser':case.get('parserOptions',{})})
            eq_sem=semantic_summary(eq)
            if eq_sem != got_sem:
                fail(f"{case['id']} is not semantically equivalent to canonical textual input {equivalent!r}")
    browser.close()
print(f"PASS Parser-Renderer-Profile-v1.2 regression corpus: {corpus['caseCount']}/{corpus['caseCount']} cases")
