# Protocol changelog

## v1.2.0 — 2026-09-28

- Promoted the supplied current JavaScript parser/renderer (SHA-256 `6bfcb77e5177eec4d923bbd24d60dbac211e574b62e128e6dbfc07f8e859d220`) to **Parser-Renderer-Profile-v1.2**.
- Standardized ordinary ASCII full stop U+002E as the sitelen pona middle-dot alias U+F199C in ordinary parser text, including adjacent forms such as `toki.pona` and ordinary cartouches.
- Explicitly preserved U+002E in quoted literal text and literal cartouches, and preserved numeric-decimal precedence so `1.25` remains numeric syntax.
- Added normative direct Common Sitelen Pona / UCSUR document-input normalization. Recognized word glyphs and structural controls are converted to canonical parser syntax and then reparsed through the normal semantic pipeline while original source text is preserved.
- Added canonical handling for direct U+200D compounds, cartouche controls, current and deprecated long-glyph controls, U+F199C/U+F199D/U+F199E punctuation, U+3000, U+300C/U+300D, ni alternates, sewi alternate, and PUA te/to brackets.
- Clarified that explicit textual `U+...` input and dedicated `renderUcsur...` methods remain raw-codepoint/raw-rendering paths and are distinct from direct pasted UCSUR document parsing.
- Fixed quoted-segment termination to use odd/even consecutive-backslash parity.
- Added the normative 24-case `conformance/parser-renderer-regression-v1.2.0.json` corpus: 10 full-stop, 12 direct-CSP/UCSUR, and 2 quote-escape cases.
- Added an executable Chromium/Playwright verifier for the new document-parser corpus; 24/24 cases pass against the pinned source.
- Retained the 16 existing `NanpaParser` profile smoke vectors; 16/16 pass against the pinned source.
- Retained the Core-v1 v1.0.2 corpus byte-for-byte and retained all 35 Core operations.
- Retained Production-Font-Profile-v1.1, its schema-2 font manifest, and its 16 logical rendering cases unchanged.
- No new visual certification is claimed; historical v1.0.1 SVG evidence remains historical only.

## v1.1.0 — 2026-09-25

- Added the normative Parser-Renderer-Profile-v1.1 aligned to the then-current JavaScript parser/renderer.
- Standardized integrated defaults, named parser modes, render-adapter contracts, and Production-Font-Profile-v1.1.
- Retained the Core-v1 corpus and 35 Core operations.

## v1.0.1 — 2026-09-21

- Pinned the then-current JavaScript reference package and updated reference hashes/qualification metadata.
- Expanded the Core regression corpus to 320 parser cases / 1030 checks with internal-whitespace clarification vectors.

## v1.0.0 — 2026-09-14

Initial frozen Protocol v1 release.
