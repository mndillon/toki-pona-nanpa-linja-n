# nanpa-linja-n Protocol v1.2.0

This directory is the frozen **nanpa-linja-n Protocol v1.2.0** release dated **2026-09-28**.

Protocol v1.2.0 keeps the frozen Core-v1 numeric semantics and the Production-Font-Profile-v1.1 rendering contract unchanged. It updates the normative integrated parser/renderer profile to match the supplied current JavaScript parser/renderer, with three narrowly scoped document-parser changes:

- ordinary ASCII full stop `.` is consistently parsed as the sitelen pona middle-dot alias U+F199C, including adjacent forms such as `toki.pona`, while numeric decimal points and literal contexts retain their established meanings;
- directly pasted Common Sitelen Pona / UCSUR text is recognized and canonicalized into the normal parser pipeline, including words, compounds, cartouches, long glyphs, punctuation, corner brackets, U+3000, and recognized alternates;
- quote termination now uses odd/even consecutive-backslash parity, so an odd run escapes a quote and an even run does not.

Start with `SPEC.md`, then `MIGRATION-v1.1-to-v1.2.md`, `PARSER-RENDERER-PROFILE.md`, `CONFORMANCE.md`, `API.md`, `RENDERING-PROFILE.md`, and `VERSIONING.md`.

## Compatibility boundary

The existing `conformance/nanpa-linja-n-regression-v1.0.2.json` corpus remains byte-for-byte Core-v1 authority. Protocol v1.2.0 does not alter any frozen Core-v1 expected result.

The production font manifest and the 16 logical font cases remain the v1.1 production rendering profile. Protocol v1.2 changes parser semantics, not the production font contract.

New parser behavior is specified by:

- `conformance/parser-renderer-profile-v1.2.0.json`
- `conformance/parser-renderer-regression-v1.2.0.json`
- `PARSER-RENDERER-PROFILE.md`

## Current JavaScript authority

Canonical parser/renderer source SHA-256:

`6bfcb77e5177eec4d923bbd24d60dbac211e574b62e128e6dbfc07f8e859d220`

The source is bundled at `references/canonical/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js` and described by `references/current-javascript-source.json`.

## Regression coverage added in v1.2

The new language-neutral parser/renderer corpus contains **24 cases**:

- 10 full-stop cases;
- 12 direct CSP/UCSUR input cases;
- 2 quote-escape parity cases.

The corpus deliberately tests semantic output rather than canvas pixels. The bundled JavaScript browser verifier is `conformance/verify-parser-renderer-regressions.py`.

## Visual evidence status

Protocol v1.2.0 does not claim a new visual baseline. The 128 retained JavaScript SVG artifacts remain historical v1.0.1 evidence, and the Production-Font-Profile-v1.1 files remain unchanged.
