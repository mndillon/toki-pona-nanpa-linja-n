# Reference implementation migration: v1.1 → v1.2

Use this checklist when updating a v1.1 reference implementation to Parser-Renderer-Profile-v1.2. Do **not** change Core-v1 numeric semantics or Production-Font-Profile-v1.1 behavior as part of this migration.

## 1. Full-stop tokenization

Update the ordinary text fallback so ASCII U+002E is recognized as its own punctuation token even when adjacent to words.

Required semantics:

- `toki . pona` → canonical `toki`, U+F199C, `pona`;
- `toki.pona` → the same canonical sequence;
- `[toki.pona]` → ordinary cartouche containing U+F199C;
- `[""toki.pona]` → same ordinary-cartouche semantics;
- `"toki.pona"` → literal U+002E;
- `["toki.pona"]` → literal U+002E;
- `1.25` → numeric decimal syntax, not U+F199C.

Keep sentence splitting (`breakLinesAtFullStops`) independent from punctuation semantics.

## 2. Add direct CSP/UCSUR document-input normalization

Before normal segment parsing on each rendered source line:

1. cheaply detect whether a potential CSP/UCSUR trigger exists;
2. confirm at least one codepoint is recognized by the direct-input mapping;
3. if none is recognized, return the source line unchanged;
4. otherwise protect literal quoted ranges when `interpretDoubleQuotesAsTeTo` is false and protect complete `img(...)` ranges;
5. convert contiguous recognized runs to canonical parser syntax;
6. preserve raw/unconverted pieces;
7. insert only necessary word-boundary spacing;
8. parse the resulting canonical text using the existing parser.

Do not replace the original source string. Where the binding exposes equivalent AST metadata, retain both original and canonicalized source and mark the normalized path equivalently to `mixed-csp-unicode`.

## 3. Required direct-input mappings

Implement the mapping table in `SPEC.md` §8.4 and `conformance/parser-renderer-profile-v1.2.0.json`.

Critical cases include:

- ordinary UCSUR word glyphs → canonical preferred word names;
- U+200D → `&`;
- U+F1990/U+F1991 → `[`/`]`;
- U+F1995/U+F1996 → `-`/`+`;
- U+F1997/U+F1998 → `(`/`)`;
- U+F199A/U+F199B → `{`/`}`;
- U+F199C/U+F199D/U+F199E → `.`/`:`/`,`;
- U+3000 → `zz`;
- U+300C/U+300D and U+F19B4/U+F19B5 → `te`/`to`;
- U+F1989/U+F198A/U+F198B/U+F198C → `ni<`/`ni^`/`ni>`/`sewi^`.

Normalize deprecated U+F1993/U+F1994 long-pi input to current `pi(...)` semantics.

## 4. Keep raw paths raw

Do not route explicit textual `U+...` input through the new direct-Unicode canonicalizer. It remains a raw-codepoint extension.

Likewise, dedicated raw UCSUR rendering functions remain raw rendering functions. This is important for bindings that expose both document parsing and direct codepoint rendering.

## 5. Quote escape parity

Replace any single-character `previous != '\\'` closing-quote test with consecutive-backslash parity:

- odd count immediately before candidate quote → escaped quote;
- even count → closing quote.

Use the same rule in ordinary quote segmentation and in quote-protection scans used by direct CSP/UCSUR normalization.

## 6. Run the new corpus

Port `conformance/parser-renderer-regression-v1.2.0.json` into the binding's native test harness.

Required inventory:

- 10 `full-stop` cases;
- 12 `direct-csp-ucsur` cases;
- 2 `quote-escape` cases.

Compare the language-neutral semantic summary represented by the corpus: selected AST/source metadata, ordered non-gap element kinds, canonical codepoints, literal text, and cartouche classification. Cases with `equivalentCanonicalInput` must produce the same semantic summary as that canonical textual input.

## 7. Regression boundary

Before releasing a v1.2 reference implementation, also rerun its existing Core-v1 and v1.1 integration suites. The migration is not permission to change:

- the 35 Core-v1 operations;
- strict/relaxed numeric syllables;
- date/time/numeric namespace semantics;
- digit-whitespace rules;
- production font manifest/settings;
- numeric-cartouche abbreviation defaults;
- rendering adapter IDs/contracts;
- vulgar-fraction production scaling behavior.
