# Versioning and freeze policy

Protocol versions use semantic versioning.

- **MAJOR**: a change to already-frozen Core semantics that can alter acceptance/rejection, canonical caps/proper name, semantic classification, namespace boundary, required output fields, or required default semantics of an existing frozen Core contract.
- **MINOR**: a backward-compatible protocol/profile extension or a promoted newer integrated parser/renderer profile that leaves the frozen older Core contract available unchanged. This can include additional accepted document syntax or clarified parser behavior within the new profile version.
- **PATCH**: documentation, metadata, schema, evidence, or additional vectors that do not change normative behavior.

Reference implementations are versioned independently from the protocol.

## Change procedure

1. State the proposed behavior in prose and machine-readable form.
2. Add or update external conformance/profile vectors.
3. Validate the supplied reference implementation(s) against the proposed scope.
4. Select the semantic-version bump according to the affected normative surface.
5. Regenerate the release manifest and SHA-256 inventory.
6. Freeze the release.

No implementation becomes an oracle merely because it is newer; a release must explicitly promote behavior into a normative protocol/profile contract.

## Protocol v1.2.0 classification

Protocol v1.2.0 is a **MINOR** release.

It leaves Core-v1 and its frozen v1.0.2 corpus unchanged and leaves Production-Font-Profile-v1.1 unchanged. It promotes the supplied current document parser into Parser-Renderer-Profile-v1.2 with three parser-level changes:

1. ordinary U+002E full stop consistently maps to U+F199C, including adjacency such as `toki.pona`, while literals and recognized numeric decimal syntax retain their established meanings;
2. recognized directly pasted CSP/UCSUR input is accepted, canonicalized, and reparsed through the normal semantic pipeline;
3. quote termination uses correct odd/even consecutive-backslash parity.

These changes alter the accepted/document-input behavior of the integrated parser profile, so they are not merely a PATCH. They do not alter the frozen Core-v1 numeric operation contract, so a MAJOR Core bump is not required.

An implementation claiming only Core-v1 may continue unchanged. An implementation claiming the current integrated parser profile must update from Parser-Renderer-Profile-v1.1 to Parser-Renderer-Profile-v1.2 and pass the new 24-case corpus.
