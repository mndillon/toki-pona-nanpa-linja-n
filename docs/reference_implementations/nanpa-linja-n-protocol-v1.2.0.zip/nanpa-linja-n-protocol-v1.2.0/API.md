# API surfaces — Protocol v1.2.0

## Core-v1 language-neutral operation map

The following 35 operation names remain frozen for language-neutral bindings:

- `parseNumber`
- `encodeDecimal`
- `decimalToUcsurCodepoints`
- `properNameToUcsurCodepoints`
- `splitCapsToProperName`
- `capsToUniqueCode`
- `decodeCaps`
- `ucsurCodepointsToTpWords`
- `codepointsToWords`
- `tpWordsToText`
- `parseTpWordsToCodepoints`
- `tpWordsToUcsurCodepoints`
- `codepointsToHex`
- `codepointsToHexWithCartouche`
- `parseHexCodepoints`
- `withCartoucheMarkers`
- `stripCartoucheMarkers`
- `isValidCaps`
- `isValidProperName`
- `isValidTimeOrDate`
- `isValidTime`
- `isValidDate`
- `tokenizeCaps`
- `capsTokensToTpWords`
- `capsToWords`
- `capsToCodepoints`
- `parseIdentifier`
- `normalizeVulgarFraction`
- `normalizeTpWord`
- `getSmallCodepointsSet`
- `getQuarterCodepointsSet`
- `getOneThirdCodepointsSet`
- `getTwoThirdsCodepointsSet`
- `getHalfCodepointsSet`
- `isAllowedTpUcsurCodepoint`

## Current canonical JavaScript module

Named exports: `SitelenRenderer` and `NanpaParser`. Default export: `SitelenRenderer`.

### `SitelenRenderer` static surface

- `create(config?)`
- `registerRenderAdapter(id, adapter)`
- `unregisterRenderAdapter(id)`
- `hasRenderAdapter(id)`
- `getDefaultRenderAdapterId()`
- `NanpaParser`

The default render-adapter ID remains `identity`.

### Renderer instance surface

`await SitelenRenderer.create(config?)` returns an instance exposing:

- `parseInput({ input, parser? })`
- `buildRenderPlan({ input?, ast?, layout?, paint?, parser?, fonts? })`
- `renderRunToNewCanvas({ run, supersampleScale?, downsample? })`
- `renderTextToNewCanvas(options?)`
- `renderTextToCanvas(options?)`
- `renderUcsurToNewCanvas(options?)`
- `renderUcsurToCanvas(options?)`

No method was added or removed for v1.2.

## `parseInput` source metadata in v1.2

When directly pasted recognized CSP/UCSUR changes a parsed line, the canonical JavaScript line object retains:

- `sourceText`: original source;
- `canonicalSourceText`: the normalized textual parser form;
- `sourceEncoding: "mixed-csp-unicode"`.

When no recognized direct CSP/UCSUR normalization occurs, `canonicalSourceText` and `sourceEncoding` are omitted and the existing Latin/ASCII path is unchanged.

Bindings may expose an equivalent language-native representation, but implementations claiming Parser-Renderer-Profile-v1.2 must preserve the semantic distinction if they expose this AST/source metadata surface.

## Raw UCSUR APIs versus document parsing

`renderUcsurToNewCanvas` and `renderUcsurToCanvas` are raw rendering APIs. They are not aliases for the v1.2 direct-CSP/UCSUR document-input normalization layer.

Likewise, explicit textual `U+...` document input remains a raw-codepoint extension and bypasses font adaptation by default. Direct pasted recognized CSP/UCSUR input is canonicalized and reparsed normally.

## Render plan

The render plan continues to separate canonical semantic codepoints from font-adapted render codepoints and records mapping metadata where applicable. Parser semantics must be derived from canonical fields, not font-specific rendered sequences.

## Default-option contract

The integrated defaults are normative in `PARSER-RENDERER-PROFILE.md` and `conformance/parser-renderer-profile-v1.2.0.json`.
