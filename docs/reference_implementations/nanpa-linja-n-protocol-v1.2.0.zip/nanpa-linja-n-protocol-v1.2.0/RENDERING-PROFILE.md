# Production Rendering Profile v1.1 (unchanged in Protocol v1.2)

This profile is layered on Core-v1 and the current Parser-Renderer-Profile-v1.2. Protocol v1.2.0 does not revise the production font contract or its logical rendering cases.

## Normative profile inputs

- `rendering/production-font-pairs.manifest.json`: schema-2 production font pairs and adapter metadata.
- `rendering/font-golden-cases-v1.1.0.json`: sixteen logical full/abbreviated rendering cases.

Production manifest SHA-256: `50b8a4b6cab0c27f2061f94e404a2af992cbf95c8097c58caa5e6b2dc4625f09`.

## Font-pair contract

The manifest remains authoritative for each pair's parser mode, font families/files, render adapter/settings, comma/tally mode, inline vulgar-fraction behavior, optional legacy-scale emulation, literal-cartouche family/clipping, and support/licensing metadata.

All supplied pairs use `sitelen-pona-ascii-extended` as their parser mode. Under Protocol v1.2, that mode also receives the common v1.2 document-input rules for ordinary full stops and recognized direct CSP/UCSUR input.

## Render adapters

The production manifest continues to use `linja-pona-legacy-v1`, `linja-sike-legacy-v1`, `nasin-sitelen-pu-mono-v1`, and `linja-lipamanka-v1` where translation is required. Other pairs use identity behavior.

## Cartouche scaling

Production entries continue to opt into `cartoucheVulgarFractions: true` and `emulateLegacyCartoucheScaling: false` where recorded by the manifest. Automatic legacy stylistic-set selection remains disabled; `ss12`, `ss13`, and `ss14` are not required.

## Logical visual cases and visual baseline

The 16 logical cases remain unchanged. With 8 production pairs, the logical matrix remains 128 implementation-specific artifacts.

No new v1.2 SVG/PNG/PDF golden artifact set is claimed. The retained 128 JavaScript SVG artifacts remain historical v1.0.1 evidence.
