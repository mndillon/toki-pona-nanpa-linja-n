# nanpa-linja-n Protocol v1.2.0

Status: **final**  
Release baseline: **2026-09-28**

## 1. Normative authority

Core numeric semantics remain defined by:

- `SPEC.md`
- `protocol.json`
- `conformance/nanpa-linja-n-regression-v1.0.2.json`
- `conformance/nanpa-linja-n-regression.schema.json`

The integrated document-parser/renderer profile is additionally defined by:

- `PARSER-RENDERER-PROFILE.md`
- `conformance/parser-renderer-profile-v1.2.0.json`
- `conformance/parser-renderer-regression-v1.2.0.json`
- `conformance/parser-renderer-regression-v1.2.0.schema.json`

The production rendering profile remains defined by:

- `RENDERING-PROFILE.md`
- `rendering/production-font-pairs.manifest.json`
- `rendering/font-golden-cases-v1.1.0.json`

The supplied canonical JavaScript parser/renderer is reference authority for Parser-Renderer-Profile-v1.2 and is pinned by SHA-256 `6bfcb77e5177eec4d923bbd24d60dbac211e574b62e128e6dbfc07f8e859d220`. Source code is evidence for the profile; the normative prose and machine-readable profile/corpus define portable requirements.

## 2. Core-v1 compatibility

The Core-v1 35-operation language-neutral map and the v1.0.2 numeric regression corpus remain unchanged. An implementation claiming only Core-v1 is not required to expose the integrated document parser.

Protocol v1.2.0 does not change numeric values, strict/relaxed digit syllables, date/time classification, numeric namespaces, digit-whitespace rules, or Core-v1 public output contracts.

## 3. Numeric defaults retained from v1.1

The integrated profile retains these defaults:

- `numericMode: uniform`;
- `relaxedNanpaLinjanParsing: true`;
- `relaxedNanpaLinjanRendering: true`;
- effective nanpa-format parsing: true;
- `nanpaColonRendering: true`;
- `abbreviateNumericCartouches: true`;
- `preserveNumericCartoucheBreaksInAbbreviation: false`;
- `enableHexParsing: false`;
- `enableBinaryParsing: false`;
- `enableBinaryRendering: false`;
- `nasinNanpaPona: false`.

Strict syllables remain `0 NI, 1 WE, 2 TE, 3 SE, 4 NA, 5 LE, 6 NU, 7 ME, 8 PE, 9 JE`. Relaxed syllables remain `0 NI, 1 WA, 2 TU, 3 SE, 4 NA, 5 LU, 6 NU, 7 MU, 8 PI, 9 JO`.

## 4. Numeric namespaces retained from v1.1

- Decimal numeric cartouches may start with `nanpa`, `tenpo`, `suno`, or `toki` and close with `nanpa`.
- Hexadecimal opens/closes with `nasa` only and parsing is opt-in.
- Binary opens/closes with `noka` only and parsing is opt-in.
- Lowercase `0b` is the canonical binary prefix.
- A source/default `Toki`/`toki` start remains a decimal number rather than a separate telephone datatype.
- A single-number `Suno` form 1..31 remains numeric rather than a date object.

Starting-glyph precedence remains: explicit caller override; source-provided/default start; date/time semantic default; ordinary `nanpa` default.

## 5. Date/time and digit whitespace retained from v1.1

Recognized dates/times use `semanticKind` values `date` and `time`, with semantic default heads `suno` and `tenpo` and decimal closer `nanpa`.

Yearless date input requires the frozen leading-marker form such as `--02-29`; bare `02-29` is not a yearless date.

Internal whitespace terminates digit-based numeric syntax. `12 34` is not one decimal number and `1 1/2` is not a mixed fraction; compact `1+1/2` is the mixed-fraction form. Spaces inside proper names/cartouches remain governed by their own grammars.

## 6. Named text parser modes

Protocol v1.2 retains the named modes:

- `standard-sitelen-pona-ascii-core`
- `sitelen-pona-ascii-extended`
- `sitelen-seli-kiwen`

The standard core mode does not apply convenience alias preprocessing. Extended modes retain the compatibility syntax defined by `PARSER-RENDERER-PROFILE.md` and the machine-readable profile.

The v1.2 full-stop and direct-CSP/UCSUR rules are common document-input rules; they are applied before or within the ordinary parsing path as specified below and are not a new fourth parser mode.

## 7. Full-stop parsing — new normative v1.2 behavior

### 7.1 Ordinary parser text

ASCII full stop U+002E `.` in **ordinary parser text** is a sitelen pona middle-dot alias and MUST produce canonical U+F199C.

The mapping does not depend on surrounding ASCII whitespace. These are semantically equivalent:

- `toki . pona`
- `toki.pona`

U+00B7 `·` remains an equivalent ordinary middle-dot input alias.

### 7.2 Ordinary cartouches

The same U+002E → U+F199C mapping applies inside ordinary non-literal cartouches, including the force-ordinary `""` cartouche form. Thus `[toki.pona]` contains canonical U+F199C.

### 7.3 Literal contexts

U+002E MUST remain literal U+002E in literal contexts. In particular:

- ordinary quoted literal text such as `"toki.pona"` preserves the full stop;
- a literal cartouche such as `["toki.pona"]` preserves the full stop.

Literal input MUST NOT be reclassified as middle-dot punctuation merely because the character is U+002E.

### 7.4 Numeric precedence

Recognized numeric syntax has precedence over the ordinary punctuation fallback. A decimal point in a recognized numeric expression such as `1.25` is numeric syntax and MUST NOT become U+F199C.

### 7.5 Optional sentence line splitting

`breakLinesAtFullStops` still defaults false. When true, sentence full stops may split rendered source lines, but:

- numeric decimal points are not sentence boundaries;
- full stops inside protected quotes, brackets, parentheses, or braces are not sentence boundaries;
- adjacent full stops are kept together on one rendered source line;
- a sentence-boundary full stop remains part of the preceding source line and follows the U+F199C ordinary-punctuation rule when semantically parsed.

## 8. Direct Common Sitelen Pona / UCSUR input — new normative v1.2 behavior

### 8.1 Purpose and activation

A document parser conforming to Parser-Renderer-Profile-v1.2 MUST accept recognized directly pasted Common Sitelen Pona / UCSUR Unicode characters in ordinary document input.

This is an **opt-in-by-detection normalization layer**: if a source line contains no recognized direct CSP/UCSUR input token, the existing Latin/ASCII parser path MUST be used unchanged.

Potential trigger characters/ranges are U+200D, U+3000, U+300C, U+300D, and U+F1900..U+F19FF. A potential trigger that has no recognized input mapping MUST NOT by itself activate canonicalization.

### 8.2 Source preservation and canonical parser text

Direct CSP/UCSUR input is not treated as opaque raw rendering data. Recognized runs are translated to canonical textual parser syntax and then re-enter the same ordinary parser pipeline as equivalent Latin/ASCII input.

The original input MUST remain available as source text. In the canonical JavaScript AST, a changed line records:

- `sourceText`: the original line;
- `canonicalSourceText`: the generated parser text;
- `sourceEncoding: "mixed-csp-unicode"`.

Bindings need not use the same object representation, but a Parser-Renderer-Profile-v1.2 binding MUST preserve the distinction between original source text and canonicalized parser text where its public AST/source model exposes such metadata.

### 8.3 Word glyphs

Recognized ordinary CSP word codepoints are mapped to the implementation's canonical preferred Toki Pona word spelling and reparsed normally. Consecutive word glyphs receive separators sufficient to prevent accidental token merging.

Example: directly pasted glyphs corresponding to `mi kama sona li` canonicalize to `mi kama sona li` and have the same semantic codepoints as that textual input.

### 8.4 Structural and punctuation mapping

The following mappings are normative for direct input normalization:

| Direct codepoint | Canonical parser form / behavior |
|---|---|
| U+F1990 | `[` |
| U+F1991 | `]` |
| U+F1992 | ignorable cartouche extension control |
| U+F1993 | deprecated long-pi start; normalize as described in §8.7 |
| U+F1994 | deprecated long-pi extension; normalize as described in §8.7 |
| U+F1995 | `-` stacking joiner |
| U+F1996 | `+` scaling/nesting joiner |
| U+F1997 | `(` long start |
| U+F1998 | `)` long end |
| U+F1999 | ignorable deprecated long extension |
| U+F199A | `{` reverse-long start |
| U+F199B | `}` reverse-long end |
| U+F199C | `.` middle-dot parser alias |
| U+F199D | `:` |
| U+F199E | `,` |
| U+200D | `&` generic/ZWJ compound joiner |
| U+3000 | `zz` ideographic-space parser alias |
| U+300C | `te` |
| U+300D | `to` |
| U+F1989 | `ni<` |
| U+F198A | `ni^` |
| U+F198B | `ni>` |
| U+F198C | `sewi^` |
| U+F19B4 | `te` |
| U+F19B5 | `to` |

### 8.5 Mixed Latin/UCSUR input and boundaries

Recognized Unicode runs may be embedded in ordinary Latin/ASCII input. The normalization layer MUST insert only the separators required to avoid merging adjacent word-like text. It MUST NOT rewrite unrelated Latin/ASCII source.

At a raw/converted boundary, the canonical JavaScript inserts a space only when both adjacent boundary characters are word-like `[A-Za-z0-9_^<>]`. Equivalent behavior is required; the exact internal algorithm is not.

### 8.6 Protected constructs

When `interpretDoubleQuotesAsTeTo` is false, a syntactically complete quoted literal range is protected from direct CSP/UCSUR canonicalization. Recognized direct Unicode outside that quote is still canonicalized.

A syntactically complete `img(...)` construct is also protected from direct CSP/UCSUR canonicalization.

### 8.7 Long-glyph normalization

Current long controls are serialized into canonical current syntax such as `pi(taso lete)` and reparsed to the current semantic sequence.

Deprecated long-pi encoding beginning U+F1993, with U+F1994 extensions, MUST be upgraded through canonical `pi(...)` syntax. It MUST produce the current semantic long-pi sequence using U+F194D, U+F1997, contained glyphs, and U+F1998 rather than preserve deprecated controls as current semantics.

### 8.8 Example equivalence

The directly pasted sequence:

`󱤴󱤖󱥡󱤧󱥬‍󱥔`

MUST be semantically equivalent to:

`mi kama sona li toki&pona`

Its original Unicode source remains original source text; the canonical parser text is `mi kama sona li toki&pona`.

## 9. Explicit textual `U+...` input remains a separate raw path

The existing project extension for explicit textual Unicode escapes remains unchanged. `U+` followed by 1..6 hexadecimal digits denotes an explicit raw codepoint; horizontal whitespace between consecutive valid escapes is source syntax and is omitted from the emitted run.

This path is intentionally distinct from §8 direct pasted CSP/UCSUR normalization:

- direct pasted recognized CSP/UCSUR is translated to canonical parser syntax and receives ordinary parser semantics;
- explicit `U+...` runs remain raw codepoint input and bypass font adaptation by default;
- the dedicated `renderUcsur...` renderer methods remain raw UCSUR rendering APIs rather than document-parser normalization APIs.

## 10. Quote termination and backslash parity — new normative v1.2 fix

For ordinary quoted segments, a candidate closing quote is escaped exactly when it is immediately preceded by an **odd** number of consecutive backslashes.

Therefore:

- one preceding backslash escapes the quote;
- two preceding backslashes do not escape the quote;
- three escape it; four do not; and so on.

This parity rule applies anywhere the integrated document parser scans quoted ranges for segmentation/protection. It replaces the incorrect one-character look-behind behavior that treated any immediately preceding backslash as sufficient regardless of parity.

## 11. Rendering adapters

The default adapter remains `identity`. Built-in production adapters remain:

- `linja-pona-legacy-v1`
- `linja-sike-legacy-v1`
- `nasin-sitelen-pu-mono-v1`
- `linja-lipamanka-v1`

Canonical codepoints remain parser-level semantics. Font adapters translate canonical sequences only at render time and retain canonical/render mapping metadata.

Direct CSP/UCSUR document input normalized under §8 re-enters this canonical parser/adapter pipeline. Explicit raw `U+...` runs, literal runs, and dedicated raw-UCSUR rendering paths retain their documented adapter-bypass behavior unless explicitly configured otherwise.

## 12. Cartouche scaling and tallies

Production-Font-Profile-v1.1 remains unchanged. Current production fonts use per-font `cartoucheVulgarFractions` where supported, with inline controls `¼`, `⅓`, `½`, `⅔`, and `¾`.

Legacy automatic stylistic-set switching (`ss12`, `ss13`, `ss14`) remains disabled and is not a Protocol v1.2 production requirement. Tally behavior remains font/profile-specific as recorded in the production manifest.

## 13. Public operations and API

The 35 Core-v1 `NanpaParser` operation names remain frozen. The `SitelenRenderer` static and instance method surfaces are unchanged from Protocol v1.1. See `API.md`.

The only v1.2 API-semantic addition is the documented source/canonical-source distinction when direct CSP/UCSUR normalization changes a parsed line.

## 14. Normative v1.2 parser regression corpus

`conformance/parser-renderer-regression-v1.2.0.json` is normative for Parser-Renderer-Profile-v1.2. It contains 24 cases:

- 10 `full-stop` cases;
- 12 `direct-csp-ucsur` cases;
- 2 `quote-escape` cases.

The corpus compares language-neutral semantic summaries: selected AST/source metadata, ordered non-gap element kinds, canonical codepoints, literal text payloads, and cartouche classification. Several direct-UCSUR vectors additionally assert semantic equivalence with a canonical textual input.

## 15. Conformance

A `Core-v1` claim requires the frozen v1.0.2 corpus.

A `Parser-Renderer-Profile-v1.2` claim additionally requires:

1. the defaults and mode behavior in `conformance/parser-renderer-profile-v1.2.0.json`;
2. all 24 cases in `conformance/parser-renderer-regression-v1.2.0.json`;
3. the canonical-vs-rendered separation and adapter behavior specified here.

A `Production-Font-Profile-v1.1` claim additionally requires the unchanged schema-2 production manifest.

Current visual certification remains separate. Historical v1.0.1 SVG evidence must not be represented as a current v1.2 visual qualification.
