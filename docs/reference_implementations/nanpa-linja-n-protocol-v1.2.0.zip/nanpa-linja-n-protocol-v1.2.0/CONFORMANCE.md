# Conformance classes — Protocol v1.2.0

## Core-v1

Required: independently pass the frozen language-neutral `conformance/nanpa-linja-n-regression-v1.0.2.json` corpus. Protocol v1.2.0 preserves this corpus byte-for-byte.

The corpus has 320 parser cases, 15 renderer/public-output cases, 9 auxiliary API cases, 8 equivalence groups, and 1030 checks in the historical JavaScript Core runner.

## Binding-v1

Required: expose or document a one-to-one mapping for all 35 Core-v1 operations and their required result contracts.

## Parser-Renderer-Profile-v1.2

Required in addition to Core-v1:

- implement the default-option contract in `conformance/parser-renderer-profile-v1.2.0.json`;
- implement the named parser-mode behavior claimed by the binding;
- pass all 24 cases in `conformance/parser-renderer-regression-v1.2.0.json`;
- map ordinary `.` to canonical U+F199C except where a higher-precedence numeric grammar or literal context applies;
- accept and canonically reparse recognized direct CSP/UCSUR document input while preserving original source text separately from canonicalized parser text where the binding exposes source metadata;
- distinguish direct pasted CSP/UCSUR normalization from explicit raw `U+...` input;
- implement odd/even consecutive-backslash quote-escape parity;
- preserve canonical-vs-rendered codepoint separation when font adapters are used;
- use `identity` as the default adapter;
- preserve fixed decimal/hex/binary namespace boundaries and the no-internal-whitespace digit rule;
- use abbreviated numeric cartouche display by default unless explicitly disabled.

The canonical JavaScript SHA-256 is `6bfcb77e5177eec4d923bbd24d60dbac211e574b62e128e6dbfc07f8e859d220`.

The profile retains 16 `NanpaParser` smoke cases from v1.1 and adds the 24 document-parser regression cases above.

## Production-Font-Profile-v1.1

This conformance class is unchanged by Protocol v1.2. Required: use the exact schema-2 `rendering/production-font-pairs.manifest.json` semantics for the production font pair being claimed.

The manifest has 8 production pairs and SHA-256 `50b8a4b6cab0c27f2061f94e404a2af992cbf95c8097c58caa5e6b2dc4625f09`.

Protocol v1.2 does not require `ss12`, `ss13`, or `ss14`; inline vulgar-fraction controls remain the current production path where enabled.

## Visual-Regression-Certified-v1.1

No new v1.2 visual baseline is created by this release. The retained 128 SVG artifacts remain historical v1.0.1 evidence. A renderer/font combination must not claim current v1.2 visual qualification merely from those historical files.

## Validation performed for this release

- canonical JavaScript SHA-256 pinned;
- public `NanpaParser` operation count verified as 35;
- `SitelenRenderer` static surface verified unchanged;
- 16/16 retained `NanpaParser` smoke cases passed;
- 24/24 new Parser-Renderer-Profile-v1.2 regression cases passed in headless Chromium against the pinned source;
- Core-v1 corpus identity preserved;
- Production-Font-Profile-v1.1 manifest and 16 logical rendering cases preserved;
- release-manifest hashes regenerated and checked.

A product may claim only the conformance classes it actually runs.
