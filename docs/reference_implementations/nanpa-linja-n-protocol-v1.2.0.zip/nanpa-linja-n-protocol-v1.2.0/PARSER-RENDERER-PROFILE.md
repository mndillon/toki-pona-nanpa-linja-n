# Integrated Parser/Renderer Profile v1.2

This profile specifies the public document-parser and renderer behavior for Protocol v1.2.0. It is layered on the unchanged Core-v1 numeric contract and supersedes Parser-Renderer-Profile-v1.1 for implementations claiming the current integrated profile.

## Defaults

The v1.1 defaults are retained unchanged:

- `numericMode: uniform`
- `relaxedNanpaLinjanParsing: true`
- `relaxedNanpaLinjanRendering: true`
- effective nanpa-format parsing: true
- `nanpaColonRendering: true`
- `abbreviateNumericCartouches: true`
- `preserveNumericCartoucheBreaksInAbbreviation: false`
- `breakLinesAtFullStops: false`
- `interpretDoubleQuotesAsTeTo: false`
- `enableHexParsing: false`
- `enableBinaryParsing: false`
- `enableBinaryRendering: false`
- `nasinNanpaPona: false`
- default font render adapter: `identity`

The machine-readable source is `conformance/parser-renderer-profile-v1.2.0.json`.

## Named parser modes

### `standard-sitelen-pona-ascii-core`

Accepts `pi(words)`, `word-word`, `word+word`, `word&word`, `|`, and ordinary `[ ... ]` cartouches. Compound chains are accepted. Convenience aliases and legacy long-pi aliases are not preprocessed in this mode. Explicit `U+...` raw-codepoint input remains a project extension.

### `sitelen-pona-ascii-extended`

Retains compound operators `&`, `-`, and `+` and the compatibility long-pi/cartouche aliases recorded by the machine-readable profile.

### `sitelen-seli-kiwen`

Supports generic forward `head(words)`, reverse `{words} head`, and bidirectional `{left words} head(right words)` extended forms, together with compound operators.

## Full stop

In ordinary parser text, ASCII `.` is always tokenized as punctuation rather than being glued to an adjacent word. It maps to canonical U+F199C, as does `·`.

This includes `toki.pona` and ordinary cartouches. Literal quoted text and literal cartouches preserve U+002E. Recognized numeric syntax is attempted before the ordinary fallback, so decimal points such as the one in `1.25` retain numeric meaning.

`breakLinesAtFullStops` remains a separate optional line-segmentation feature and defaults false. Its exclusions for decimal points and protected syntactic regions remain in force.

## Direct CSP/UCSUR document input

The v1.2 parser accepts directly pasted recognized CSP/UCSUR text by translating recognized Unicode runs to canonical parser syntax and then running the ordinary parser.

This layer activates only when recognized input is actually present. In the absence of recognized direct CSP/UCSUR, the Latin/ASCII path is unchanged.

Recognized special mappings are enumerated in `SPEC.md` and `conformance/parser-renderer-profile-v1.2.0.json`. They include cartouche/long controls, joiners, U+F199C/U+F199D/U+F199E punctuation, U+200D, U+3000, corner brackets, ni alternates, sewi alternate, and the PUA te/to brackets.

The canonical JavaScript preserves the original line as `sourceText` and, when normalization changes it, adds `canonicalSourceText` plus `sourceEncoding: "mixed-csp-unicode"`.

When `interpretDoubleQuotesAsTeTo` is false, syntactically complete quoted literal ranges are protected. `img(...)` ranges are also protected. Other recognized direct Unicode on the same line is still normalized.

Deprecated long-pi encoding is upgraded to current `pi(...)` semantics rather than passed through as deprecated controls.

## Explicit `U+...` input is not direct-Unicode normalization

Explicit `U+...` textual escapes remain raw codepoint input. Horizontal whitespace between consecutive escapes belongs to the escape syntax rather than the emitted run. These runs bypass font adapters by default.

Direct pasted recognized CSP/UCSUR characters are different: they become canonical parser text and therefore follow ordinary semantic parsing and normal adapter selection afterward.

Dedicated `renderUcsurToNewCanvas` / `renderUcsurToCanvas` methods remain raw rendering APIs.

## Quote escape parity

A candidate closing quote is escaped only when the immediately preceding run of consecutive backslashes has odd length. Even-length runs do not escape the quote. This rule is used consistently by quote segmentation and by protected-range scanning for direct CSP/UCSUR normalization.

## Text aliases

Outside `standard-sitelen-pona-ascii-core`, the existing convenience aliases may be expanded before parsing. The alias inventory is unchanged from v1.1 and remains in the machine-readable profile.

## Font render adapters

The default adapter remains `identity`. Built-ins remain `linja-pona-legacy-v1`, `linja-sike-legacy-v1`, `nasin-sitelen-pu-mono-v1`, and `linja-lipamanka-v1`.

Adapters receive canonical semantics at render time. The render plan continues to expose canonical and rendered codepoint streams and mapping metadata.

## Regression requirement

A Parser-Renderer-Profile-v1.2 implementation MUST pass `conformance/parser-renderer-regression-v1.2.0.json`. The corpus is intentionally semantic rather than pixel-based so it can be applied to all reference-language bindings.
