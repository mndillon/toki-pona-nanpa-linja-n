# nanpa-linja-n Rust reference for Protocol v1.0.0

This package is the Rust reference implementation of nanpa-linja-n Protocol v1.0.0 / conformance corpus v1.0.2. Version 0.2.0 adds a production-font rendering facade while retaining the existing Core-v1 parser and Binding-v1 API.

## Core conformance

Run:

```bash
./tools/run_rust_regression.sh
```

The frozen Core suite covers parser, renderer/public-output, API, equivalence, protocol constants and the Rust unit tests. The rendering facade adds a production matrix smoke test covering all 8 production font pairs × 16 full/abbreviated cases = 128 renders.

## Seamless rendering

```rust
use nanpa_linja_n_rust::facade::{NanpaLinjaN, RenderOptions};

let nanpa = NanpaLinjaN::create()?;
let png = nanpa.render_to_png("123.45", &RenderOptions::default())?;

let options = RenderOptions {
    font: "linjaPona".into(),
    ..RenderOptions::default()
};
let png = nanpa.render_to_png("12:30", &options)?;
```

Production fonts, the font-pair manifest and font-specific adaptation are internal to the library. Developers do not need to know whether a selected font consumes canonical UCSUR or legacy ASCII ligature input.

See `RENDERING-FACADE.md` for the complete facade API.



## Current JavaScript parity qualification

The Full Renderer qualification now includes the current JavaScript-derived semantic corpora in addition to the frozen Protocol v1.0.0 and legacy Full Renderer Profile tests:

- 28 canonical syntax cases;
- 5 production-font adapter cases;
- 254 branch-oriented canonical full-renderer cases;
- 346 mixed-feature interaction cases covering `te`/`to`, `zz`, compounds, current/reverse long glyphs, legacy long `pi`, ordinary/literal cartouches, interpreted quotes, aliases, raw UCSUR, numeric constructs, production font adapters and combinations of those features.

`ast_to_text()` is the idiomatic Rust API. `astToText()` is retained as a cross-language spelling. Both are covered by the dedicated AST regression and by the mixed-feature round-trip corpus.

The master runner is intentionally **non-fail-fast**. Every configured suite is attempted and one report is written to:

```text
test-output/rust-regression-report.txt
```

Run the complete qualification with:

```bash
./tools/run_rust_regression.sh
```

A failure in one suite does not prevent later suites from running; the script returns a non-zero exit status only after the consolidated summary has been written.

### Regression runtime

The default runner keeps Cargo incremental artifacts and runs renderer-heavy tests with an optimized test profile. The legacy 64-case Full Renderer diagnostic no longer starts 64 separate renderer processes on a passing run: the complete profile runs once, and individual semantic cases are rerun only when that profile fails. Six focused full-renderer regressions are also batched into one integration-test process so the bundled font archive is initialized once.

For a deliberately cold rebuild, use:

```bash
NANPA_RUST_REGRESSION_CLEAN=1 ./tools/run_rust_regression.sh
```

The ordinary `./tools/run_rust_regression.sh` remains the complete qualification gate; the speedup does not introduce a reduced-coverage mode.

## AST editing and `ast_to_text`

The Full Renderer parser exposes a document AST through `parse_input()`. Rust exposes the idiomatic `ast_to_text()` spelling and the exact cross-language alias `astToText()`. The serializer is additive: existing text rendering still parses and renders source text exactly as before.

```rust
use nanpa_linja_n_rust::facade::NanpaLinjaN;
use nanpa_linja_n_rust::FullRenderOptions;

let nanpa = NanpaLinjaN::create()?;
let options = FullRenderOptions::default();
let mut ast = nanpa.parse_input("jan [pona]", &options);

if let Some(segment) = ast.lines
    .iter_mut()
    .flat_map(|line| line.children.iter_mut())
    .find(|segment| segment.kind == "bracket")
{
    segment.value = "suno".into();
}

let edited_text = nanpa.ast_to_text(&ast)?; // nanpa.astToText(&ast)? is equivalent
let png = nanpa.render_full_to_png(&edited_text, &options)?;
```

Normally editable content fields are `DocumentSegment.value`, `open_quote`, `close_quote`, and the fields of an `ImageDescriptor`. Structural/source metadata such as `kind`, `index`, `source_start`, `source_end`, `source_text`, and `normalized_input` should normally be left unchanged. `source_line_index` is used by `ast_to_text()` to reconstruct physical source lines when `break_lines_at_full_stops` split one source line into several AST lines.

Whitespace retained in text/bracket/quote values is preserved. `img(...)` expressions are emitted in a canonical valid form because the parser retains the image descriptor rather than the exact original argument formatting. Parser newline normalization means CRLF input is serialized with LF line endings.

To test this feature specifically:

```bash
cargo test --test ast_to_text -- --nocapture
```

A successful run prints:

```text
Rust ast_to_text regression: 8/8 PASS
Rust ast_to_text render integration: 1/1 PASS
```

## Dependencies

The production renderer uses exact-version-pinned Rust crates: `harfrust 0.13.3`, `fontdue 0.9.4`, and `image 0.25.10` (PNG feature). The library archive intentionally does not ship a stale `Cargo.lock`; Cargo will generate one on the first build.


## Full Renderer Profile test candidate

This archive contains an additive Rust implementation of the nanpa-linja-n Full Renderer Profile v1.0.0-candidate. The frozen Protocol v1.0.0 Core and the existing numeric production renderer remain unchanged and are protected by source-integrity checks.

Run the complete qualification gate:

```bash
./tools/run_rust_regression.sh
```

A successful candidate prints:

```text
Rust Full Renderer semantic parity: 64/64 PASS
Rust Full Renderer operation checks: 20/20 PASS
Rust Full Renderer vector cases: 9/9 PASS
Rust Full Renderer feature areas: 38/38 PASS
RUST FULL RENDERER PROFILE: PASS
ALL CONFIGURED RUST FULL REFERENCE TESTS PASS
```

Generate visual audits with:

```bash
./tools/export_visual_pngs.sh
./tools/export_cartouche_audit.sh
find test-output -type f -name '*.png' | wc -l
```

The expected total is 72 PNGs: 32 numeric-production views and 40 full-renderer ordinary-cartouche/tally views. The Rust visual audit deliberately uses the same canonical audit corpus and filenames as the Python/Dart exporters: `[jan pona]`, the same cartouche with a red halo, `[jan pona,,]`, and the same tallied cartouche with a red halo; each per-font contact sheet is composed from those four images rather than rendered from a Rust-specific mixed string. In particular, inspect the five manual-tally font pairs (`nasinNanpa`, `linjaPona`, `linjaSike`, `nasinSitelenPuMono`, `linjaLipamanka`). Manual tally strokes must be synthesized under the owning glyph; U+F199E must not be shaped for those five fonts.
