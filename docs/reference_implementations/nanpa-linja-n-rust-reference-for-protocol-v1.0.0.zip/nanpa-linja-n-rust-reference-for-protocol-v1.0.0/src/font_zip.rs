//! Self-contained reader for the bundled `resources/fonts.zip` archive.
//!
//! The production font bundle is the single font source for the Rust reference
//! implementation.  This module intentionally uses only the Rust standard
//! library: no ZIP crate, CDN, system `unzip`, or loose font directory is
//! required.  The canonical bundle currently uses stored directory entries and
//! raw DEFLATE for files, both handled here.

use std::collections::BTreeMap;
use std::sync::OnceLock;

const FONT_ZIP: &[u8] = include_bytes!("../resources/fonts.zip");

static ENTRIES: OnceLock<Result<BTreeMap<String, Vec<u8>>, String>> = OnceLock::new();

pub fn bundled_zip_bytes() -> &'static [u8] {
    FONT_ZIP
}

pub fn entry(name: &str) -> Result<&'static [u8], String> {
    match ENTRIES.get_or_init(load_entries) {
        Ok(entries) => entries
            .get(name)
            .map(Vec::as_slice)
            .ok_or_else(|| format!("font bundle entry not found: {name}")),
        Err(err) => Err(err.clone()),
    }
}

pub fn entry_str(name: &str) -> Result<&'static str, String> {
    let bytes = entry(name)?;
    std::str::from_utf8(bytes).map_err(|err| format!("font bundle entry is not UTF-8 ({name}): {err}"))
}

fn le_u16(bytes: &[u8], offset: usize) -> Result<u16, String> {
    let s = bytes
        .get(offset..offset + 2)
        .ok_or_else(|| "truncated ZIP u16".to_string())?;
    Ok(u16::from_le_bytes([s[0], s[1]]))
}

fn le_u32(bytes: &[u8], offset: usize) -> Result<u32, String> {
    let s = bytes
        .get(offset..offset + 4)
        .ok_or_else(|| "truncated ZIP u32".to_string())?;
    Ok(u32::from_le_bytes([s[0], s[1], s[2], s[3]]))
}

fn load_entries() -> Result<BTreeMap<String, Vec<u8>>, String> {
    let mut out = BTreeMap::new();
    let mut pos = 0usize;

    while pos + 4 <= FONT_ZIP.len() {
        let signature = le_u32(FONT_ZIP, pos)?;
        if signature != 0x0403_4b50 {
            break;
        }
        if pos + 30 > FONT_ZIP.len() {
            return Err("truncated ZIP local header".to_string());
        }

        let flags = le_u16(FONT_ZIP, pos + 6)?;
        if flags & 0x0001 != 0 {
            return Err("encrypted ZIP entries are not supported".to_string());
        }
        if flags & 0x0008 != 0 {
            return Err("ZIP data descriptors are not supported by the bundled-font reader".to_string());
        }
        let method = le_u16(FONT_ZIP, pos + 8)?;
        let compressed_size = le_u32(FONT_ZIP, pos + 18)? as usize;
        let uncompressed_size = le_u32(FONT_ZIP, pos + 22)? as usize;
        let name_len = le_u16(FONT_ZIP, pos + 26)? as usize;
        let extra_len = le_u16(FONT_ZIP, pos + 28)? as usize;
        let name_start = pos + 30;
        let name_end = name_start
            .checked_add(name_len)
            .ok_or_else(|| "ZIP filename length overflow".to_string())?;
        let data_start = name_end
            .checked_add(extra_len)
            .ok_or_else(|| "ZIP extra length overflow".to_string())?;
        let data_end = data_start
            .checked_add(compressed_size)
            .ok_or_else(|| "ZIP data length overflow".to_string())?;
        if data_end > FONT_ZIP.len() {
            return Err("truncated ZIP entry".to_string());
        }

        let name = std::str::from_utf8(&FONT_ZIP[name_start..name_end])
            .map_err(|err| format!("ZIP filename is not UTF-8: {err}"))?
            .to_string();
        let payload = &FONT_ZIP[data_start..data_end];

        if !name.ends_with('/') {
            let decoded = match method {
                0 => payload.to_vec(),
                8 => inflate_raw(payload, uncompressed_size)?,
                other => return Err(format!("unsupported ZIP compression method {other} for {name}")),
            };
            if decoded.len() != uncompressed_size {
                return Err(format!(
                    "ZIP entry size mismatch for {name}: expected {uncompressed_size}, got {}",
                    decoded.len()
                ));
            }
            out.insert(name, decoded);
        }
        pos = data_end;
    }

    if out.is_empty() {
        return Err("font ZIP contains no file entries".to_string());
    }
    Ok(out)
}

struct BitReader<'a> {
    data: &'a [u8],
    byte: usize,
    bit: u8,
}

impl<'a> BitReader<'a> {
    fn new(data: &'a [u8]) -> Self {
        Self { data, byte: 0, bit: 0 }
    }

    fn read_bits(&mut self, count: u8) -> Result<u32, String> {
        let mut value = 0u32;
        for shift in 0..count {
            let current = *self
                .data
                .get(self.byte)
                .ok_or_else(|| "truncated DEFLATE bitstream".to_string())?;
            let bit = (current >> self.bit) & 1;
            value |= (bit as u32) << shift;
            self.bit += 1;
            if self.bit == 8 {
                self.bit = 0;
                self.byte += 1;
            }
        }
        Ok(value)
    }

    fn align_byte(&mut self) {
        if self.bit != 0 {
            self.bit = 0;
            self.byte += 1;
        }
    }

    fn read_u16_aligned(&mut self) -> Result<u16, String> {
        self.align_byte();
        let b0 = *self
            .data
            .get(self.byte)
            .ok_or_else(|| "truncated DEFLATE stored block".to_string())?;
        let b1 = *self
            .data
            .get(self.byte + 1)
            .ok_or_else(|| "truncated DEFLATE stored block".to_string())?;
        self.byte += 2;
        Ok(u16::from_le_bytes([b0, b1]))
    }

    fn read_aligned_bytes(&mut self, len: usize) -> Result<&'a [u8], String> {
        self.align_byte();
        let end = self
            .byte
            .checked_add(len)
            .ok_or_else(|| "DEFLATE stored block length overflow".to_string())?;
        let slice = self
            .data
            .get(self.byte..end)
            .ok_or_else(|| "truncated DEFLATE stored block payload".to_string())?;
        self.byte = end;
        Ok(slice)
    }
}

#[derive(Clone)]
struct Huffman {
    by_len: Vec<BTreeMap<u16, u16>>,
    max_bits: u8,
}

impl Huffman {
    fn from_lengths(lengths: &[u8]) -> Result<Self, String> {
        let mut counts = [0u16; 16];
        let mut max_bits = 0u8;
        for &len in lengths {
            if len > 15 {
                return Err(format!("invalid DEFLATE Huffman code length {len}"));
            }
            if len != 0 {
                counts[len as usize] += 1;
                max_bits = max_bits.max(len);
            }
        }
        if max_bits == 0 {
            return Err("DEFLATE Huffman tree contains no symbols".to_string());
        }

        let mut next_code = [0u16; 16];
        let mut code = 0u16;
        for bits in 1..=15usize {
            code = (code + counts[bits - 1]) << 1;
            next_code[bits] = code;
        }

        let mut by_len = (0..16).map(|_| BTreeMap::<u16, u16>::new()).collect::<Vec<_>>();
        for (symbol, &len) in lengths.iter().enumerate() {
            if len == 0 {
                continue;
            }
            let canonical = next_code[len as usize];
            next_code[len as usize] = canonical + 1;
            let reversed = reverse_bits(canonical, len);
            by_len[len as usize].insert(reversed, symbol as u16);
        }
        Ok(Self { by_len, max_bits })
    }

    fn decode(&self, bits: &mut BitReader<'_>) -> Result<u16, String> {
        let mut code = 0u16;
        for len in 1..=self.max_bits {
            let bit = bits.read_bits(1)? as u16;
            code |= bit << (len - 1);
            if let Some(symbol) = self.by_len[len as usize].get(&code) {
                return Ok(*symbol);
            }
        }
        Err("invalid DEFLATE Huffman code".to_string())
    }
}

fn reverse_bits(mut value: u16, count: u8) -> u16 {
    let mut out = 0u16;
    for _ in 0..count {
        out = (out << 1) | (value & 1);
        value >>= 1;
    }
    out
}

fn fixed_trees() -> Result<(Huffman, Huffman), String> {
    let mut literal_lengths = vec![0u8; 288];
    literal_lengths[0..=143].fill(8);
    literal_lengths[144..=255].fill(9);
    literal_lengths[256..=279].fill(7);
    literal_lengths[280..=287].fill(8);
    let distance_lengths = vec![5u8; 32];
    Ok((
        Huffman::from_lengths(&literal_lengths)?,
        Huffman::from_lengths(&distance_lengths)?,
    ))
}

fn dynamic_trees_fixed(bits: &mut BitReader<'_>) -> Result<(Huffman, Huffman), String> {
    let hlit = bits.read_bits(5)? as usize + 257;
    let hdist = bits.read_bits(5)? as usize + 1;
    let hclen = bits.read_bits(4)? as usize + 4;
    const ORDER: [usize; 19] = [
        16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15,
    ];
    let mut code_lengths = [0u8; 19];
    for &index in ORDER.iter().take(hclen) {
        code_lengths[index] = bits.read_bits(3)? as u8;
    }
    let code_tree = Huffman::from_lengths(&code_lengths)?;
    let total = hlit + hdist;
    let mut lengths = Vec::<u8>::with_capacity(total);
    while lengths.len() < total {
        let symbol = code_tree.decode(bits)?;
        match symbol {
            0..=15 => lengths.push(symbol as u8),
            16 => {
                let previous = *lengths
                    .last()
                    .ok_or_else(|| "DEFLATE repeat code 16 has no previous length".to_string())?;
                let repeat = bits.read_bits(2)? as usize + 3;
                if lengths.len() + repeat > total {
                    return Err("DEFLATE code-length repeat exceeds table".to_string());
                }
                lengths.extend(std::iter::repeat(previous).take(repeat));
            }
            17 => {
                let repeat = bits.read_bits(3)? as usize + 3;
                if lengths.len() + repeat > total {
                    return Err("DEFLATE zero repeat exceeds table".to_string());
                }
                lengths.extend(std::iter::repeat(0u8).take(repeat));
            }
            18 => {
                let repeat = bits.read_bits(7)? as usize + 11;
                if lengths.len() + repeat > total {
                    return Err("DEFLATE long zero repeat exceeds table".to_string());
                }
                lengths.extend(std::iter::repeat(0u8).take(repeat));
            }
            other => return Err(format!("invalid DEFLATE code-length symbol {other}")),
        }
    }
    Ok((
        Huffman::from_lengths(&lengths[..hlit])?,
        Huffman::from_lengths(&lengths[hlit..])?,
    ))
}

const LENGTH_BASE: [usize; 29] = [
    3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83,
    99, 115, 131, 163, 195, 227, 258,
];
const LENGTH_EXTRA: [u8; 29] = [
    0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5,
    5, 5, 0,
];
const DIST_BASE: [usize; 30] = [
    1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025,
    1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577,
];
const DIST_EXTRA: [u8; 30] = [
    0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11,
    12, 12, 13, 13,
];

fn decode_compressed_block(
    bits: &mut BitReader<'_>,
    literal: &Huffman,
    distance: &Huffman,
    out: &mut Vec<u8>,
) -> Result<(), String> {
    loop {
        let symbol = literal.decode(bits)?;
        match symbol {
            0..=255 => out.push(symbol as u8),
            256 => return Ok(()),
            257..=285 => {
                let index = (symbol - 257) as usize;
                let length = LENGTH_BASE[index] + bits.read_bits(LENGTH_EXTRA[index])? as usize;
                let dist_symbol = distance.decode(bits)? as usize;
                if dist_symbol >= DIST_BASE.len() {
                    return Err(format!("invalid DEFLATE distance symbol {dist_symbol}"));
                }
                let distance_value = DIST_BASE[dist_symbol]
                    + bits.read_bits(DIST_EXTRA[dist_symbol])? as usize;
                if distance_value == 0 || distance_value > out.len() {
                    return Err(format!("invalid DEFLATE back-reference distance {distance_value}"));
                }
                for _ in 0..length {
                    let source = out.len() - distance_value;
                    let byte = out[source];
                    out.push(byte);
                }
            }
            other => return Err(format!("invalid DEFLATE literal/length symbol {other}")),
        }
    }
}

fn inflate_raw(data: &[u8], expected_size: usize) -> Result<Vec<u8>, String> {
    let mut bits = BitReader::new(data);
    let mut out = Vec::with_capacity(expected_size);
    loop {
        let final_block = bits.read_bits(1)? != 0;
        let block_type = bits.read_bits(2)?;
        match block_type {
            0 => {
                let len = bits.read_u16_aligned()?;
                let nlen = bits.read_u16_aligned()?;
                if len != !nlen {
                    return Err("invalid DEFLATE stored-block length complement".to_string());
                }
                out.extend_from_slice(bits.read_aligned_bytes(len as usize)?);
            }
            1 => {
                let (literal, distance) = fixed_trees()?;
                decode_compressed_block(&mut bits, &literal, &distance, &mut out)?;
            }
            2 => {
                let (literal, distance) = dynamic_trees_fixed(&mut bits)?;
                decode_compressed_block(&mut bits, &literal, &distance, &mut out)?;
            }
            _ => return Err("reserved DEFLATE block type".to_string()),
        }
        if final_block {
            break;
        }
    }
    if out.len() != expected_size {
        return Err(format!(
            "DEFLATE output size mismatch: expected {expected_size}, got {}",
            out.len()
        ));
    }
    Ok(out)
}
