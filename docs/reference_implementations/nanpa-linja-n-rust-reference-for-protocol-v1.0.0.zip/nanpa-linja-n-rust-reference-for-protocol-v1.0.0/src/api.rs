use crate::encoding::{encode_decimal as encode_decimal_caps, EncodeError};
use crate::options::{NumericMode, ParseOptions};
use crate::parser::parse_number;
use crate::protocol::{CARTOUCHE_END, CARTOUCHE_START};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ApiError {
    InvalidCaps(String),
}

impl std::fmt::Display for ApiError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::InvalidCaps(value) => write!(f, "invalid nanpa caps label: {value}"),
        }
    }
}

impl std::error::Error for ApiError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SplitCapsOptions {
    pub title_case: bool,
    pub relaxed_nanpa_linjan_parsing: bool,
    pub relaxed_nanpa_linjan_rendering: bool,
    pub nanpa_colon_rendering: bool,
}

impl Default for SplitCapsOptions {
    fn default() -> Self {
        Self {
            title_case: true,
            relaxed_nanpa_linjan_parsing: false,
            relaxed_nanpa_linjan_rendering: false,
            nanpa_colon_rendering: false,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CapsCodepointsResult {
    pub inner_codepoints: Vec<u32>,
    pub codepoints: Vec<u32>,
    pub words: Vec<String>,
    pub numeric_mode: String,
    pub is_time_like: bool,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct IdentifierResult {
    pub input: String,
    pub inner_codepoints: Vec<u32>,
    pub codepoints: Vec<u32>,
    pub words: Vec<String>,
    pub numeric_mode: String,
}


fn normalized_parse_options(options: &ParseOptions) -> ParseOptions {
    let mut normalized = options.clone();
    if options.mode == NumericMode::Traditional || options.numeric_mode == NumericMode::Traditional {
        normalized.mode = NumericMode::Traditional;
        normalized.numeric_mode = NumericMode::Traditional;
    }
    normalized
}

/// Rust counterpart of canonical NanpaParser.encodeDecimal().
pub fn encode_decimal(
    value: &str,
    options: &ParseOptions,
) -> Result<String, EncodeError> {
    encode_decimal_caps(value, options)
}

/// Rust counterpart of canonical NanpaParser.decimalToUcsurCodepoints().
pub fn decimal_to_ucsur_codepoints(
    value: &str,
    options: &ParseOptions,
) -> Vec<u32> {
    let normalized = normalized_parse_options(options);
    parse_number(value, &normalized)
        .map(|result| result.ucsur_codepoints)
        .unwrap_or_default()
}

/// Rust counterpart of canonical NanpaParser.properNameToUcsurCodepoints().
pub fn proper_name_to_ucsur_codepoints(
    value: &str,
    options: &ParseOptions,
) -> Vec<u32> {
    let normalized = normalized_parse_options(options);
    parse_number(value, &normalized)
        .map(|result| result.ucsur_codepoints)
        .unwrap_or_default()
}

fn relaxed_output_caps(caps: &str) -> String {
    let upper = caps.trim().to_ascii_uppercase();
    if upper.len() < 3 || !upper.starts_with("NE") || !upper.ends_with('N') {
        return upper;
    }

    let final_index = upper.len() - 1;
    let mut out = String::with_capacity(upper.len());
    let mut index = 0usize;

    while index < final_index {
        if index + 2 > final_index {
            return upper;
        }
        let pair = &upper[index..index + 2];
        out.push_str(match pair {
            "WE" => "WA",
            "TE" => "TU",
            "LE" => "LU",
            "ME" => "MU",
            "PE" => "PI",
            "JE" => "JO",
            _ => pair,
        });
        index += 2;
    }

    out.push('N');
    out
}

fn magnitude_ke_proper_name_fragment(count: usize) -> String {
    if count == 0 {
        return String::new();
    }
    if count <= 3 {
        return format!("e{}", "ke".repeat(count));
    }

    let mut sizes = vec![2usize];
    let mut remaining = count - 2;
    while remaining > 3 {
        sizes.push(2);
        remaining -= 2;
    }
    sizes.push(remaining);

    sizes
        .into_iter()
        .enumerate()
        .map(|(index, size)| {
            let prefix = if index == 0 { "e" } else { "" };
            format!("{prefix}{}", "ke".repeat(size))
        })
        .collect::<Vec<_>>()
        .join(" ")
}

fn split_final_hundred_inin_words(value: &str, relaxed_allowed: bool) -> String {
    const STRICT_SUFFIXES: &[&str] = &[
        "weninin", "teninin", "seninin", "naninin", "leninin",
        "nuninin", "meninin", "peninin", "jeninin",
    ];
    const RELAXED_SUFFIXES: &[&str] =
        &["waninin", "tuninin", "luninin", "muninin", "pininin", "joninin"];

    let mut out = Vec::<String>::new();
    for word in value.split_whitespace() {
        let lower = word.to_ascii_lowercase();
        let should_split = STRICT_SUFFIXES.iter().any(|suffix| lower.ends_with(suffix))
            || (relaxed_allowed
                && RELAXED_SUFFIXES.iter().any(|suffix| lower.ends_with(suffix)));

        if should_split && lower.ends_with("inin") && word.len() > 4 {
            let split = word.len() - 4;
            let head = &word[..split];
            let tail = &word[split..];
            if !head.is_empty() {
                out.push(head.to_string());
                out.push(tail.to_string());
                continue;
            }
        }
        out.push(word.to_string());
    }
    out.join(" ")
}

fn title_case_words(value: &str) -> String {
    value
        .split_whitespace()
        .filter(|word| !word.is_empty())
        .map(|word| {
            let mut chars = word.chars();
            match chars.next() {
                Some(first) => format!("{}{}", first.to_ascii_uppercase(), chars.as_str()),
                None => String::new(),
            }
        })
        .collect::<Vec<_>>()
        .join(" ")
}

fn colon_proper_name_from_legacy(value: &str) -> String {
    let mut body = value.trim().to_ascii_lowercase();
    if let Some(rest) = body.strip_prefix("ne") {
        body = rest.trim_start().to_string();
    } else if let Some(rest) = body.strip_prefix("n ene") {
        body = rest.trim_start().to_string();
    }

    let mut words = body
        .split_whitespace()
        .map(str::to_string)
        .collect::<Vec<_>>();

    if words.len() > 1 && (words[0] == "no" || words[0] == "ne") {
        let second = words.remove(1);
        words[0].push_str(&second);
    }

    let titled = words
        .iter()
        .map(|word| title_case_words(word))
        .collect::<Vec<_>>()
        .join(" ");

    if titled.is_empty() {
        String::new()
    } else {
        format!("Nanpa {titled}")
    }
}

fn split_caps_letters(caps: &str) -> Result<String, ApiError> {
    let s = caps.trim().to_ascii_uppercase();
    if s.is_empty() {
        return Ok(String::new());
    }
    if s.len() < 3 || !s.starts_with("NE") || !s.ends_with('N') {
        return Err(ApiError::InvalidCaps(caps.to_string()));
    }

    let has_ok_suffix = s.len() >= 3 && &s[s.len() - 3..s.len() - 1] == "OK";
    let main = if has_ok_suffix {
        format!("{}N", &s[..s.len() - 3])
    } else {
        s
    };

    let end = main.len() - 1;
    if end % 2 != 0 {
        return Err(ApiError::InvalidCaps(caps.to_string()));
    }

    let mut out = String::new();
    let mut i = 0usize;

    while i < end {
        let pair = &main[i..i + 2];
        let next_pair = if i + 4 <= end {
            Some(&main[i + 2..i + 4])
        } else {
            None
        };

        if pair == "NE" && next_pair == Some("NO") && i == 0 {
            out.push_str("neno ");
            i += 4;
            continue;
        }
        if pair == "NE" && next_pair == Some("NS") && i == 0 {
            out.push_str("nene ");
            i += 4;
            continue;
        }
        if pair == "NE" && next_pair == Some("NE") {
            out.push_str("n ene ");
            i += 4;
            continue;
        }
        if pair == "NO" && next_pair == Some("NE") && i > 0 {
            out.push_str("n one ");
            i += 4;
            continue;
        }
        if pair == "NO" && next_pair == Some("KO") && i > 0 {
            out.push_str("n oko");
            if i + 4 < end {
                out.push(' ');
            }
            i += 4;
            continue;
        }
        if pair == "NE" && next_pair == Some("KO") && i > 0 {
            out.push_str("n eko");
            if i + 4 < end {
                out.push(' ');
            }
            i += 4;
            continue;
        }
        if pair == "NO" && next_pair == Some("NO") && i > 0 {
            out.push_str("n o");
            let mut count_no = 1usize;
            let mut j = i;
            while j + 6 <= end && &main[j + 4..j + 6] == "NO" {
                count_no += 1;
                j += 2;
            }
            out.push_str(&"no".repeat(count_no));
            if i + 2 * count_no < end {
                out.push(' ');
            }
            i += 2 + 2 * count_no;
            continue;
        }
        if pair == "NE" && next_pair == Some("KE") {
            out.push_str("n ");
            let mut count_ke = 1usize;
            let mut j = i;
            while j + 6 <= end && &main[j + 4..j + 6] == "KE" {
                count_ke += 1;
                j += 2;
            }
            out.push_str(&magnitude_ke_proper_name_fragment(count_ke));
            if i + 2 * count_ke < end {
                out.push(' ');
            }
            i += 2 + 2 * count_ke;
            continue;
        }

        if pair == "OK" {
            if i > 0 && !out.ends_with(' ') {
                out.push(' ');
            }
            if i > 0 {
                out.push_str("n ");
            }
            out.push_str("oke");
        } else {
            out.push_str(&pair.to_ascii_lowercase());
        }
        i += 2;
    }

    // Canonical implementation collapses whitespace-surrounded standalone n.
    let mut words = out
        .split_whitespace()
        .map(str::to_string)
        .collect::<Vec<_>>();
    let mut index = 0usize;
    while index < words.len() {
        if words[index] == "n" {
            if index > 0 {
                words[index - 1].push('n');
                words.remove(index);
                continue;
            }
        }
        index += 1;
    }

    let mut value = words.join(" ").trim().to_string();
    value.push('n');
    if has_ok_suffix {
        value.push_str(" oken");
    }
    Ok(value)
}

/// Rust counterpart of canonical NanpaParser.splitCapsToProperName().
pub fn split_caps_to_proper_name(
    caps: &str,
    options: &SplitCapsOptions,
) -> Result<String, ApiError> {
    let parse_options = ParseOptions {
        relaxed_nanpa_linjan_parsing: options.relaxed_nanpa_linjan_parsing
            || options.relaxed_nanpa_linjan_rendering,
        relaxed_nanpa_linjan_rendering: options.relaxed_nanpa_linjan_rendering,
        nanpa_colon_rendering: options.nanpa_colon_rendering,
        ..ParseOptions::default()
    };

    let canonical = parse_number(caps, &parse_options)
        .and_then(|result| result.caps)
        .ok_or_else(|| ApiError::InvalidCaps(caps.to_string()))?;

    let rendered = if options.relaxed_nanpa_linjan_rendering {
        relaxed_output_caps(&canonical)
    } else {
        canonical
    };

    let legacy = split_final_hundred_inin_words(
        &split_caps_letters(&rendered)?,
        options.relaxed_nanpa_linjan_parsing || options.relaxed_nanpa_linjan_rendering,
    );

    if options.nanpa_colon_rendering {
        let alternative = colon_proper_name_from_legacy(&legacy);
        return Ok(if options.title_case {
            alternative
        } else {
            alternative.to_ascii_lowercase()
        });
    }

    if options.title_case {
        Ok(title_case_words(&legacy))
    } else {
        Ok(legacy)
    }
}

/// Rust counterpart of canonical NanpaParser.capsToWords().
pub fn caps_to_words(caps: &str, options: &ParseOptions) -> Vec<String> {
    let normalized = normalized_parse_options(options);
    parse_number(caps, &normalized)
        .map(|result| result.tp_words)
        .unwrap_or_default()
}

/// Canonical reverse UCSUR map used by codepointsToWords().
pub fn codepoint_to_word(codepoint: u32) -> Option<&'static str> {
    match codepoint {
        0xF1900 => Some("a"),
        0xF1901 => Some("akesi"),
        0xF1902 => Some("ala"),
        0xF1903 => Some("alasa"),
        0xF1904 => Some("ali"),
        0xF1905 => Some("anpa"),
        0xF1906 => Some("ante"),
        0xF1907 => Some("anu"),
        0xF1908 => Some("awen"),
        0xF1909 => Some("e"),
        0xF190A => Some("en"),
        0xF190B => Some("esun"),
        0xF190C => Some("ijo"),
        0xF190D => Some("ike"),
        0xF190E => Some("ilo"),
        0xF190F => Some("insa"),
        0xF1910 => Some("jaki"),
        0xF1911 => Some("jan"),
        0xF1912 => Some("jelo"),
        0xF1913 => Some("jo"),
        0xF1914 => Some("kala"),
        0xF1915 => Some("kalama"),
        0xF1916 => Some("kama"),
        0xF1917 => Some("kasi"),
        0xF1918 => Some("ken"),
        0xF1919 => Some("kepeken"),
        0xF191A => Some("kili"),
        0xF191B => Some("kiwen"),
        0xF191C => Some("ko"),
        0xF191D => Some("kon"),
        0xF191E => Some("kule"),
        0xF191F => Some("kulupu"),
        0xF1920 => Some("kute"),
        0xF1921 => Some("la"),
        0xF1922 => Some("lape"),
        0xF1923 => Some("laso"),
        0xF1924 => Some("lawa"),
        0xF1925 => Some("len"),
        0xF1926 => Some("lete"),
        0xF1927 => Some("li"),
        0xF1928 => Some("lili"),
        0xF1929 => Some("linja"),
        0xF192A => Some("lipu"),
        0xF192B => Some("loje"),
        0xF192C => Some("lon"),
        0xF192D => Some("luka"),
        0xF192E => Some("lukin"),
        0xF192F => Some("lupa"),
        0xF1930 => Some("ma"),
        0xF1931 => Some("mama"),
        0xF1932 => Some("mani"),
        0xF1933 => Some("meli"),
        0xF1934 => Some("mi"),
        0xF1935 => Some("mije"),
        0xF1936 => Some("moku"),
        0xF1937 => Some("moli"),
        0xF1938 => Some("monsi"),
        0xF1939 => Some("mu"),
        0xF193A => Some("mun"),
        0xF193B => Some("musi"),
        0xF193C => Some("mute"),
        0xF193D => Some("nanpa"),
        0xF193E => Some("nasa"),
        0xF193F => Some("nasin"),
        0xF1940 => Some("nena"),
        0xF1941 => Some("ni"),
        0xF1942 => Some("nimi"),
        0xF1943 => Some("noka"),
        0xF1944 => Some("o"),
        0xF1945 => Some("olin"),
        0xF1946 => Some("ona"),
        0xF1947 => Some("open"),
        0xF1948 => Some("pakala"),
        0xF1949 => Some("pali"),
        0xF194A => Some("palisa"),
        0xF194B => Some("pan"),
        0xF194C => Some("pana"),
        0xF194D => Some("pi"),
        0xF194E => Some("pilin"),
        0xF194F => Some("pimeja"),
        0xF1950 => Some("pini"),
        0xF1951 => Some("pipi"),
        0xF1952 => Some("poka"),
        0xF1953 => Some("poki"),
        0xF1954 => Some("pona"),
        0xF1955 => Some("pu"),
        0xF1956 => Some("sama"),
        0xF1957 => Some("seli"),
        0xF1958 => Some("selo"),
        0xF1959 => Some("seme"),
        0xF195A => Some("sewi"),
        0xF195B => Some("sijelo"),
        0xF195C => Some("sike"),
        0xF195D => Some("sin"),
        0xF195E => Some("sina"),
        0xF195F => Some("sinpin"),
        0xF1960 => Some("sitelen"),
        0xF1961 => Some("sona"),
        0xF1962 => Some("soweli"),
        0xF1963 => Some("suli"),
        0xF1964 => Some("suno"),
        0xF1965 => Some("supa"),
        0xF1966 => Some("suwi"),
        0xF1967 => Some("tan"),
        0xF1968 => Some("taso"),
        0xF1969 => Some("tawa"),
        0xF196A => Some("telo"),
        0xF196B => Some("tenpo"),
        0xF196C => Some("toki"),
        0xF196D => Some("tomo"),
        0xF196E => Some("tu"),
        0xF196F => Some("unpa"),
        0xF1970 => Some("uta"),
        0xF1971 => Some("utala"),
        0xF1972 => Some("walo"),
        0xF1973 => Some("wan"),
        0xF1974 => Some("waso"),
        0xF1975 => Some("wawa"),
        0xF1976 => Some("weka"),
        0xF1977 => Some("wile"),
        0xF1978 => Some("namako"),
        0xF1979 => Some("kin"),
        0xF197A => Some("oko"),
        0xF197B => Some("kipisi"),
        0xF197C => Some("leko"),
        0xF197D => Some("monsuta"),
        0xF197E => Some("tonsi"),
        0xF197F => Some("jasima"),
        0xF1980 => Some("kijetesantakalu"),
        0xF1981 => Some("soko"),
        0xF1982 => Some("meso"),
        0xF1983 => Some("epiku"),
        0xF1984 => Some("kokosila"),
        0xF1985 => Some("lanpan"),
        0xF1986 => Some("n"),
        0xF1987 => Some("misikeke"),
        0xF1988 => Some("ku"),
        0xF1989 => Some("ni<"),
        0xF198A => Some("ni^"),
        0xF198B => Some("ni>"),
        0xF198C => Some("sewi^"),
        0xF199C => Some("."),
        0xF199D => Some("kolon"),
        0xF199E => Some("koma"),
        0xF19A0 => Some("pake"),
        0xF19A1 => Some("apeja"),
        0xF19A2 => Some("majuna"),
        0xF19A3 => Some("powe"),
        0xF19A4 => Some("linluwi"),
        0xF19A6 => Some("su"),
        _ => None,
    }
}

/// Rust counterpart of canonical NanpaParser.codepointsToWords().
pub fn codepoints_to_words(codepoints: &[u32]) -> Vec<String> {
    codepoints
        .iter()
        .filter_map(|cp| codepoint_to_word(*cp))
        .map(str::to_string)
        .collect()
}

/// Rust counterpart of canonical NanpaParser.capsToCodepoints().
pub fn caps_to_codepoints(
    caps: &str,
    options: &ParseOptions,
) -> Option<CapsCodepointsResult> {
    let normalized = normalized_parse_options(options);
    let result = parse_number(caps, &normalized)?;
    let inner_codepoints = result.inner_codepoints;
    let codepoints = with_cartouche_markers(&inner_codepoints);
    let words = codepoints_to_words(&inner_codepoints);

    Some(CapsCodepointsResult {
        inner_codepoints,
        codepoints,
        words,
        numeric_mode: normalized.numeric_mode.as_str().to_string(),
        is_time_like: result.is_time_like,
    })
}

/// Rust counterpart of canonical NanpaParser.parseIdentifier().
pub fn parse_identifier(
    input: &str,
    options: &ParseOptions,
) -> Option<IdentifierResult> {
    let normalized = normalized_parse_options(options);
    let result = parse_number(input, &normalized)?;
    if result.inner_codepoints.is_empty() {
        return None;
    }

    let inner_codepoints = result.inner_codepoints;
    let codepoints = with_cartouche_markers(&inner_codepoints);
    let words = codepoints_to_words(&inner_codepoints);

    Some(IdentifierResult {
        input: input.to_string(),
        inner_codepoints,
        codepoints,
        words,
        numeric_mode: normalized.numeric_mode.as_str().to_string(),
    })
}

pub fn with_cartouche_markers(codepoints: &[u32]) -> Vec<u32> {
    let mut out = Vec::with_capacity(codepoints.len() + 2);
    out.push(CARTOUCHE_START);
    out.extend_from_slice(codepoints);
    out.push(CARTOUCHE_END);
    out
}

pub fn strip_cartouche_markers(codepoints: &[u32]) -> Vec<u32> {
    if codepoints.len() >= 2
        && codepoints.first() == Some(&CARTOUCHE_START)
        && codepoints.last() == Some(&CARTOUCHE_END)
    {
        codepoints[1..codepoints.len() - 1].to_vec()
    } else {
        codepoints.to_vec()
    }
}

pub fn codepoints_to_hex(codepoints: &[u32]) -> String {
    codepoints
        .iter()
        .map(|cp| format!("{cp:04X}"))
        .collect::<Vec<_>>()
        .join(" ")
}

pub fn codepoints_to_hex_with_cartouche(codepoints: &[u32]) -> String {
    codepoints_to_hex(&with_cartouche_markers(codepoints))
}

/// Rust-facing zero-sized namespace mirroring the canonical NanpaParser object.
#[derive(Debug, Clone, Copy, Default)]
pub struct NanpaParserApi;

impl NanpaParserApi {
    pub fn parse_number(input: &str, options: &ParseOptions) -> Option<crate::model::ParseResult> {
        parse_number(input, options)
    }

    pub fn encode_decimal(value: &str, options: &ParseOptions) -> Result<String, EncodeError> {
        encode_decimal(value, options)
    }

    pub fn decimal_to_ucsur_codepoints(value: &str, options: &ParseOptions) -> Vec<u32> {
        decimal_to_ucsur_codepoints(value, options)
    }

    pub fn proper_name_to_ucsur_codepoints(value: &str, options: &ParseOptions) -> Vec<u32> {
        proper_name_to_ucsur_codepoints(value, options)
    }

    pub fn split_caps_to_proper_name(
        caps: &str,
        options: &SplitCapsOptions,
    ) -> Result<String, ApiError> {
        split_caps_to_proper_name(caps, options)
    }

    pub fn caps_to_words(caps: &str, options: &ParseOptions) -> Vec<String> {
        caps_to_words(caps, options)
    }

    pub fn caps_to_codepoints(
        caps: &str,
        options: &ParseOptions,
    ) -> Option<CapsCodepointsResult> {
        caps_to_codepoints(caps, options)
    }

    pub fn parse_identifier(input: &str, options: &ParseOptions) -> Option<IdentifierResult> {
        parse_identifier(input, options)
    }

    pub fn codepoints_to_words(codepoints: &[u32]) -> Vec<String> {
        codepoints_to_words(codepoints)
    }
}
