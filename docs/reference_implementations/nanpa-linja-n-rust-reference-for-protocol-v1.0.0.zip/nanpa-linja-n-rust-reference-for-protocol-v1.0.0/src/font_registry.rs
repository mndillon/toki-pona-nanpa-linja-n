//! Bundled Production-Font-Profile-v1 registry.
//!
//! The manifest and companion fonts are embedded at compile time so a caller
//! does not need to locate font files or understand adapter IDs.

use serde::Deserialize;

const MANIFEST_JSON: &str = include_str!("../fonts/preloaded-font-pairs.manifest.json");

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
struct ManifestDocument {
    schema: u32,
    #[serde(default)]
    generated: String,
    pairs: Vec<ManifestPair>,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
struct ManifestPair {
    font_key: String,
    #[serde(default)]
    label: String,
    #[serde(default)]
    rev: String,
    #[serde(default)]
    parser_mode: String,
    #[serde(default = "identity_adapter")]
    render_adapter_id: String,
    #[serde(default)]
    base_family: String,
    #[serde(default)]
    companion_family: String,
    companion_filename: String,
}

fn identity_adapter() -> String {
    "identity".to_string()
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FontInfo {
    pub key: String,
    pub label: String,
    pub revision: String,
    pub parser_mode: String,
    pub render_adapter_id: String,
    pub base_family: String,
    pub companion_family: String,
    pub companion_filename: String,
}

#[derive(Debug, Clone)]
pub struct FontRegistry {
    schema: u32,
    generated: String,
    fonts: Vec<FontInfo>,
}

impl FontRegistry {
    pub fn bundled() -> Result<Self, String> {
        let doc: ManifestDocument = serde_json::from_str(MANIFEST_JSON)
            .map_err(|err| format!("production font manifest is invalid: {err}"))?;
        if doc.schema != 2 {
            return Err(format!("unsupported production font manifest schema: {}", doc.schema));
        }
        if doc.pairs.is_empty() {
            return Err("production font manifest contains no font pairs".to_string());
        }
        let fonts = doc
            .pairs
            .into_iter()
            .map(|pair| FontInfo {
                key: pair.font_key.clone(),
                label: if pair.label.trim().is_empty() { pair.font_key } else { pair.label },
                revision: pair.rev,
                parser_mode: pair.parser_mode,
                render_adapter_id: if pair.render_adapter_id.trim().is_empty() {
                    "identity".to_string()
                } else {
                    pair.render_adapter_id
                },
                base_family: pair.base_family,
                companion_family: pair.companion_family,
                companion_filename: pair.companion_filename,
            })
            .collect();
        Ok(Self { schema: doc.schema, generated: doc.generated, fonts })
    }

    pub const fn schema(&self) -> u32 { self.schema }

    pub fn generated(&self) -> &str { &self.generated }

    pub fn list(&self) -> &[FontInfo] { &self.fonts }

    pub fn get(&self, key_or_alias: &str) -> Option<&FontInfo> {
        let requested = normalize_alias(key_or_alias);
        self.fonts.iter().find(|font| {
            [
                font.key.as_str(),
                font.label.as_str(),
                font.base_family.as_str(),
                font.companion_family.as_str(),
            ]
            .iter()
            .any(|candidate| normalize_alias(candidate) == requested)
        })
    }

    pub fn companion_bytes(&self, font: &FontInfo) -> Result<&'static [u8], String> {
        bundled_font_bytes(&font.companion_filename).ok_or_else(|| {
            format!(
                "bundled companion font is missing for {}: {}",
                font.key, font.companion_filename
            )
        })
    }
}

fn normalize_alias(value: &str) -> String {
    value
        .chars()
        .filter(|ch| ch.is_ascii_alphanumeric())
        .flat_map(|ch| ch.to_lowercase())
        .collect()
}

pub fn bundled_manifest_json() -> &'static str { MANIFEST_JSON }

/// Resolve a production companion filename to compile-time embedded bytes.
///
/// Only the companion faces are needed by the high-level numeric-cartouche
/// facade.  All production font files are still included in the source archive
/// so advanced applications have the same asset set as the JS/Python suites.
pub fn bundled_font_bytes(filename: &str) -> Option<&'static [u8]> {
    match filename {
        "nasin-nanpa-5.0.0-beta.3-UCSUR-nanpa-linja-n-good-kasi-nasin-e-en-ss1223.otf" =>
            Some(include_bytes!("../fonts/nasin-nanpa-5.0.0-beta.3-UCSUR-nanpa-linja-n-good-kasi-nasin-e-en-ss1223.otf")),
        "sitelenselikiwenjuniko-nanpa-linja-n-good-kasi-nasin-e-en-ss1223.ttf" =>
            Some(include_bytes!("../fonts/sitelenselikiwenjuniko-nanpa-linja-n-good-kasi-nasin-e-en-ss1223.ttf")),
        "FairfaxHD-nanpa-linja-n-good-kasi-nasin-e-en-ss1223.ttf" =>
            Some(include_bytes!("../fonts/FairfaxHD-nanpa-linja-n-good-kasi-nasin-e-en-ss1223.ttf")),
        "FairfaxPonaHD-nanpa-linja-n-good-kasi-nasin-e-en-ss1223.ttf" =>
            Some(include_bytes!("../fonts/FairfaxPonaHD-nanpa-linja-n-good-kasi-nasin-e-en-ss1223.ttf")),
        "linja-pona-nanpa-linja-n-nasin-e-en-ss1223.otf" =>
            Some(include_bytes!("../fonts/linja-pona-nanpa-linja-n-nasin-e-en-ss1223.otf")),
        "linja-sike-5-nanpa-linja-n-nasin-e-en-ss1223.otf" =>
            Some(include_bytes!("../fonts/linja-sike-5-nanpa-linja-n-nasin-e-en-ss1223.otf")),
        "NasinSitelenPuMono-nanpa-linja-n-nasin-e-en-ss1223.otf" =>
            Some(include_bytes!("../fonts/NasinSitelenPuMono-nanpa-linja-n-nasin-e-en-ss1223.otf")),
        "linjalipamanka-normal-nanpa-linja-n-nasin-e-en-ss1223.otf" =>
            Some(include_bytes!("../fonts/linjalipamanka-normal-nanpa-linja-n-nasin-e-en-ss1223.otf")),
        _ => None,
    }
}
