#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct DecimalMarker {
    pub unique_code: &'static str,
    pub proper_name: &'static str,
    pub tp_words: &'static [&'static str],
    pub codepoints: &'static [u32],
}

pub const NEGATIVE_SIGN: DecimalMarker = DecimalMarker {
    unique_code: "o",
    proper_name: "No",
    tp_words: &["nena", "ona"],
    codepoints: &[0xF1940, 0xF1946],
};

pub const POSITIVE_SIGN: DecimalMarker = DecimalMarker {
    unique_code: "e",
    proper_name: "Ne",
    tp_words: &["nena", "en"],
    codepoints: &[0xF1940, 0xF190A],
};

pub const DECIMAL_POINT: DecimalMarker = DecimalMarker {
    unique_code: "o",
    proper_name: "One",
    tp_words: &["nena", "o", "nena", "e"],
    codepoints: &[0xF1940, 0xF1944, 0xF1940, 0xF1909],
};

pub const FRACTION_GROUP_SEPARATOR: DecimalMarker = DecimalMarker {
    unique_code: "ee",
    proper_name: "Ene",
    tp_words: &["nena", "e", "nena", "e"],
    codepoints: &[0xF1940, 0xF1909, 0xF1940, 0xF1909],
};

pub const PERCENT: DecimalMarker = DecimalMarker {
    unique_code: "ok",
    proper_name: "Oken",
    tp_words: &["nena", "open", "kipisi", "e"],
    codepoints: &[0xF1940, 0xF1947, 0xF197B, 0xF1909],
};