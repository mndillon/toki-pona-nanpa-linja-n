mod extended;

use crate::decimal_metadata::{
    DECIMAL_POINT,
    FRACTION_GROUP_SEPARATOR,
    NEGATIVE_SIGN,
    PERCENT,
    POSITIVE_SIGN,
};
use crate::digit_metadata::metadata_for_digit;
use crate::digits::{encode_digit, DigitStyle};
use crate::encoding::encode_decimal;
use crate::model::ParseResult;
use crate::options::{NumericMode, ParseOptions};
use crate::protocol::{
    CARTOUCHE_END,
    CARTOUCHE_START,
};

const NANPA: u32 = 0xF193D;
const COLON: u32 = 0xF199D;
const E: u32 = 0xF1909;

const MAGNITUDE_WORDS: &[&str] =
    &["nena", "e", "kulupu", "e"];

const MAGNITUDE_CODEPOINTS: &[u32] = &[
    0xF1940,
    0xF1909,
    0xF191F,
    0xF1909,
];

const MAGNITUDE_PREFIX_WORDS: &[&str] =
    &["nena", "e"];

const MAGNITUDE_PREFIX_CODEPOINTS: &[u32] = &[
    0xF1940,
    0xF1909,
];

const MAGNITUDE_UNIT_WORDS: &[&str] =
    &["kulupu", "e"];

const MAGNITUDE_UNIT_CODEPOINTS: &[u32] = &[
    0xF191F,
    0xF1909,
];

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum DecimalSign {
    None,
    Negative,
    Positive,
}

fn codepoints_to_hex(
    codepoints: &[u32],
) -> String {
    codepoints
        .iter()
        .map(|cp| format!("{cp:X}"))
        .collect::<Vec<_>>()
        .join(" ")
}

fn digit_style(
    options: &ParseOptions,
) -> DigitStyle {
    if options.relaxed_nanpa_linjan_rendering {
        DigitStyle::Relaxed
    } else {
        DigitStyle::Strict
    }
}

fn digit_proper_syllable(
    digit: u8,
    options: &ParseOptions,
) -> Option<String> {
    let syllable =
        encode_digit(
            digit,
            digit_style(options),
        )?;

    Some(
        syllable.to_ascii_lowercase()
    )
}

fn title_word(
    value: &str,
) -> String {
    let mut chars = value.chars();

    match chars.next() {
        Some(first) => format!(
            "{}{}",
            first.to_ascii_uppercase(),
            chars.as_str()
        ),

        None => String::new(),
    }
}

fn finish_numeric_proper_group(
    mut value: String,
) -> String {
    value.push('n');
    title_word(&value)
}

fn split_two_trailing_zeroes(
    value: &str,
) -> bool {
    value.len() >= 3
        && value.ends_with("00")
        && !value.ends_with("000")
}

fn append_digit(
    digit: u8,
    unique_code: &mut String,
    tp_words: &mut Vec<String>,
    codepoints: &mut Vec<u32>,
) -> Option<()> {
    let metadata =
        metadata_for_digit(digit)?;

    unique_code.push(
        metadata.unique_code
    );

    tp_words.extend(
        metadata
            .tp_words
            .iter()
            .map(|word| {
                (*word).to_string()
            }),
    );

    codepoints.extend_from_slice(
        &metadata.codepoints,
    );

    Some(())
}

fn append_marker(
    unique_code_fragment: &str,
    marker_words: &[&str],
    marker_codepoints: &[u32],
    unique_code: &mut String,
    tp_words: &mut Vec<String>,
    codepoints: &mut Vec<u32>,
) {
    unique_code.push_str(
        unique_code_fragment,
    );

    tp_words.extend(
        marker_words
            .iter()
            .map(|word| {
                (*word).to_string()
            }),
    );

    codepoints.extend_from_slice(
        marker_codepoints,
    );
}

fn append_magnitude_marker(
    unique_code: &mut String,
    tp_words: &mut Vec<String>,
    codepoints: &mut Vec<u32>,
) {
    append_marker(
        "k",
        MAGNITUDE_WORDS,
        MAGNITUDE_CODEPOINTS,
        unique_code,
        tp_words,
        codepoints,
    );
}

fn append_terminal_magnitude(
    power: usize,
    unique_code: &mut String,
    tp_words: &mut Vec<String>,
    codepoints: &mut Vec<u32>,
    proper_words: &mut Vec<String>,
) {
    if power == 0 {
        return;
    }

    for _ in 0..power {
        unique_code.push('k');
    }

    tp_words.extend(
        MAGNITUDE_PREFIX_WORDS
            .iter()
            .map(|word| {
                (*word).to_string()
            }),
    );

    codepoints.extend_from_slice(
        MAGNITUDE_PREFIX_CODEPOINTS,
    );

    for _ in 0..power {
        tp_words.extend(
            MAGNITUDE_UNIT_WORDS
                .iter()
                .map(|word| {
                    (*word).to_string()
                }),
        );

        codepoints.extend_from_slice(
            MAGNITUDE_UNIT_CODEPOINTS,
        );
    }

    match power {
        1 => {
            proper_words.push(
                "Eken".to_string(),
            );
        }

        2 => {
            proper_words.push(
                "Ekeken".to_string(),
            );
        }

        3 => {
            proper_words.push(
                "Ekekeken".to_string(),
            );
        }

        4 => {
            proper_words.push(
                "Ekeke".to_string(),
            );

            proper_words.push(
                "Keken".to_string(),
            );
        }

        _ => {
            for _ in 0..power - 1 {
                proper_words.push(
                    "Eke".to_string(),
                );
            }

            proper_words.push(
                "Eken".to_string(),
            );
        }
    }
}

fn format_fraction_display(
    fraction: &str,
) -> String {
    fraction
        .as_bytes()
        .chunks(3)
        .map(|chunk| {
            std::str::from_utf8(chunk)
                .expect(
                    "ASCII decimal fraction",
                )
        })
        .collect::<Vec<_>>()
        .join("_")
}

fn magnitude_power(
    ch: char,
) -> Option<usize> {
    match ch.to_ascii_uppercase() {
        'K' => Some(1),
        'M' => Some(2),
        'B' => Some(3),
        'T' => Some(4),
        _ => None,
    }
}

fn magnitude_suffix(
    power: usize,
) -> Option<char> {
    match power {
        1 => Some('K'),
        2 => Some('M'),
        3 => Some('B'),
        4 => Some('T'),
        _ => None,
    }
}

fn parse_decimal_number_core(
    input: &str,
    options: &ParseOptions,
) -> Option<ParseResult> {
    let source = input.trim();

    if source.is_empty() {
        return None;
    }

    let (sign, unsigned) =
        if let Some(rest) =
            source.strip_prefix('+')
        {
            (
                DecimalSign::Positive,
                rest,
            )
        } else if let Some(rest) =
            source.strip_prefix('-')
        {
            (
                DecimalSign::Negative,
                rest,
            )
        } else {
            (
                DecimalSign::None,
                source,
            )
        };

    if unsigned.is_empty() {
        return None;
    }

    let (
        numeric_unsigned,
        explicit_magnitude_power,
    ) = if let Some(last) =
        unsigned.chars().last()
    {
        if let Some(power) =
            magnitude_power(last)
        {
            let end =
                unsigned.len()
                    - last.len_utf8();

            let body =
                &unsigned[..end];

            if body.is_empty() {
                return None;
            }

            (body, power)
        } else {
            (unsigned, 0)
        }
    } else {
        return None;
    };

    let mut split =
        numeric_unsigned.split('.');

    let integer_raw =
        split.next()?;

    let fraction_raw =
        split.next();

    if split.next().is_some() {
        return None;
    }

    let has_decimal_point =
        fraction_raw.is_some();

    let implicit_zero =
        integer_raw.is_empty();

    let integer_source =
        if implicit_zero {
            if has_decimal_point {
                "0"
            } else {
                return None;
            }
        } else {
            integer_raw
        };

    let integer_groups:
        Vec<&str> =
        integer_source
            .split(',')
            .collect();

    if integer_groups.is_empty()
        || integer_groups
            .iter()
            .any(|group| {
                group.is_empty()
                    || !group
                        .chars()
                        .all(
                            |ch| {
                                ch.is_ascii_digit()
                            },
                        )
            })
    {
        return None;
    }

    if let Some(fraction) =
        fraction_raw
    {
        if fraction.is_empty()
            || !fraction
                .chars()
                .all(
                    |ch| {
                        ch.is_ascii_digit()
                    },
                )
        {
            return None;
        }
    }

    let trailing_zero_groups =
        if integer_groups.len() > 1 {
            let count =
                integer_groups
                    .iter()
                    .rev()
                    .take_while(
                        |group| {
                            **group == "000"
                        },
                    )
                    .count();

            if count <
                integer_groups.len()
            {
                count
            } else {
                0
            }
        } else {
            0
        };

    let significant_count =
        integer_groups.len()
            - trailing_zero_groups;

    let caps =
        encode_decimal(
            source,
            options,
        )
        .ok()?;

    let mut unique_code =
        String::from("#~");

    let mut tp_words = vec![
        "nanpa".to_string(),
        if options.nanpa_colon_rendering {
            ":".to_string()
        } else {
            "e".to_string()
        },
    ];

    let mut inner_codepoints =
        vec![
            NANPA,
            if options.nanpa_colon_rendering {
                COLON
            } else {
                E
            },
        ];

    let mut first_proper_group =
        String::new();

    match sign {
        DecimalSign::None => {}

        DecimalSign::Negative => {
            first_proper_group
                .push_str("no");

            append_marker(
                NEGATIVE_SIGN
                    .unique_code,
                NEGATIVE_SIGN
                    .tp_words,
                NEGATIVE_SIGN
                    .codepoints,
                &mut unique_code,
                &mut tp_words,
                &mut inner_codepoints,
            );
        }

        DecimalSign::Positive => {
            first_proper_group
                .push_str("ne");

            append_marker(
                POSITIVE_SIGN
                    .unique_code,
                POSITIVE_SIGN
                    .tp_words,
                POSITIVE_SIGN
                    .codepoints,
                &mut unique_code,
                &mut tp_words,
                &mut inner_codepoints,
            );
        }
    }

    let first_group =
        integer_groups[0];

    /*
     * Canonical proper-name compatibility:
     * an ungrouped integer component ending in
     * exactly two zero digits splits those digits
     * into the separate word "Inin".
     *
     * 100   -> Wan Inin
     * 1200  -> Watun Inin
     * -100  -> Nowan Inin
     *
     * Three or more trailing zeroes remain joined.
     */
    let split_first_two_zeroes =
        split_two_trailing_zeroes(
            first_group
        );

    let split_digit_index =
        if split_first_two_zeroes {
            first_group.len() - 2
        } else {
            first_group.len()
        };

    for (digit_index, ch) in
        first_group.chars().enumerate()
    {
        let digit =
            ch.to_digit(10)? as u8;

        if !split_first_two_zeroes
            || digit_index < split_digit_index
        {
            first_proper_group
                .push_str(
                    &digit_proper_syllable(
                        digit,
                        options,
                    )?,
                );
        }

        append_digit(
            digit,
            &mut unique_code,
            &mut tp_words,
            &mut inner_codepoints,
        )?;
    }

    let mut proper_words = vec![
        finish_numeric_proper_group(
            first_proper_group,
        ),
    ];

    if split_first_two_zeroes {
        proper_words.push(
            "Inin".to_string(),
        );
    }

    for group in integer_groups
        .iter()
        .take(significant_count)
        .skip(1)
    {
        append_magnitude_marker(
            &mut unique_code,
            &mut tp_words,
            &mut inner_codepoints,
        );

        proper_words.push(
            "Eke".to_string(),
        );

        let split_group_two_zeroes =
            split_two_trailing_zeroes(
                group
            );

        let group_split_index =
            if split_group_two_zeroes {
                group.len() - 2
            } else {
                group.len()
            };

        let mut proper_group =
            String::new();

        for (digit_index, ch) in
            group.chars().enumerate()
        {
            let digit =
                ch.to_digit(10)?
                    as u8;

            if !split_group_two_zeroes
                || digit_index
                    < group_split_index
            {
                proper_group.push_str(
                    &digit_proper_syllable(
                        digit,
                        options,
                    )?,
                );
            }

            append_digit(
                digit,
                &mut unique_code,
                &mut tp_words,
                &mut inner_codepoints,
            )?;
        }

        proper_words.push(
            finish_numeric_proper_group(
                proper_group,
            ),
        );

        if split_group_two_zeroes {
            proper_words.push(
                "Inin".to_string(),
            );
        }
    }

    append_terminal_magnitude(
        trailing_zero_groups,
        &mut unique_code,
        &mut tp_words,
        &mut inner_codepoints,
        &mut proper_words,
    );

    if let Some(fraction) =
        fraction_raw
    {
        append_marker(
            DECIMAL_POINT
                .unique_code,
            DECIMAL_POINT
                .tp_words,
            DECIMAL_POINT
                .codepoints,
            &mut unique_code,
            &mut tp_words,
            &mut inner_codepoints,
        );

        proper_words.push(
            DECIMAL_POINT
                .proper_name
                .to_string(),
        );

        for (
            group_index,
            chunk,
        ) in fraction
            .as_bytes()
            .chunks(3)
            .enumerate()
        {
            if group_index > 0 {
                append_marker(
                    FRACTION_GROUP_SEPARATOR
                        .unique_code,
                    FRACTION_GROUP_SEPARATOR
                        .tp_words,
                    FRACTION_GROUP_SEPARATOR
                        .codepoints,
                    &mut unique_code,
                    &mut tp_words,
                    &mut inner_codepoints,
                );

                proper_words.push(
                    FRACTION_GROUP_SEPARATOR
                        .proper_name
                        .to_string(),
                );
            }

            let group =
                std::str::from_utf8(
                    chunk,
                )
                .ok()?;

            let mut proper_group =
                String::new();

            for ch in group.chars() {
                let digit =
                    ch.to_digit(10)?
                        as u8;

                proper_group.push_str(
                    &digit_proper_syllable(
                        digit,
                        options,
                    )?,
                );

                append_digit(
                    digit,
                    &mut unique_code,
                    &mut tp_words,
                    &mut inner_codepoints,
                )?;
            }

            proper_words.push(
                finish_numeric_proper_group(
                    proper_group,
                ),
            );
        }
    }

    append_terminal_magnitude(
        explicit_magnitude_power,
        &mut unique_code,
        &mut tp_words,
        &mut inner_codepoints,
        &mut proper_words,
    );

    tp_words.push(
        "nanpa".to_string()
    );

    inner_codepoints.push(NANPA);

    let proper_name = if options.nanpa_colon_rendering {
        format!(
            "Nanpa {}",
            proper_words.join(" ")
        )
    } else {
        let mut legacy_words = proper_words.clone();

        match sign {
            DecimalSign::None => {
                if let Some(first) = legacy_words.first_mut() {
                    *first = format!(
                        "Ne{}",
                        first.to_ascii_lowercase()
                    );
                }
            }

            DecimalSign::Negative => {
                if let Some(first) = legacy_words.first_mut() {
                    let tail = first
                        .strip_prefix("No")
                        .unwrap_or(first.as_str())
                        .to_string();
                    *first = title_word(&tail);
                }
                legacy_words.insert(0, "Neno".to_string());
            }

            DecimalSign::Positive => {
                if let Some(first) = legacy_words.first_mut() {
                    let tail = first
                        .strip_prefix("Ne")
                        .unwrap_or(first.as_str())
                        .to_string();
                    *first = title_word(&tail);
                }
                legacy_words.insert(0, "Nene".to_string());
            }
        }

        legacy_words.join(" ")
    };

    let sign_prefix =
        match sign {
            DecimalSign::None => "",
            DecimalSign::Negative => "-",
            DecimalSign::Positive => "+",
        };

    let significant_integer =
        integer_groups
            .iter()
            .take(significant_count)
            .copied()
            .collect::<Vec<_>>()
            .join(",");

    let display_integer =
        if implicit_zero {
            "0".to_string()
        } else {
            significant_integer
        };

    let mut display_core =
        display_integer;

    if let Some(fraction) =
        fraction_raw
    {
        display_core.push('.');

        display_core.push_str(
            &format_fraction_display(
                fraction,
            ),
        );
    }

    let total_magnitude_power =
        trailing_zero_groups
            + explicit_magnitude_power;

    let display_value =
        if total_magnitude_power > 0
        {
            if let Some(suffix) =
                magnitude_suffix(
                    total_magnitude_power,
                )
            {
                format!(
                    "{sign_prefix}{display_core}{suffix}"
                )
            } else {
                let mut value =
                    format!(
                        "{sign_prefix}{display_core}"
                    );

                for _ in
                    0..trailing_zero_groups
                {
                    value.push_str(
                        ",000"
                    );
                }

                if explicit_magnitude_power
                    > 0
                {
                    if let Some(suffix) =
                        magnitude_suffix(
                            explicit_magnitude_power,
                        )
                    {
                        value.push(
                            suffix
                        );
                    }
                }

                value
            }
        } else {
            format!(
                "{sign_prefix}{display_core}"
            )
        };

    let mut codepoints =
        Vec::with_capacity(
            inner_codepoints.len() + 2,
        );

    codepoints.push(
        CARTOUCHE_START
    );

    codepoints.extend_from_slice(
        &inner_codepoints,
    );

    codepoints.push(
        CARTOUCHE_END
    );

    let hex_codepoints =
        codepoints_to_hex(
            &inner_codepoints,
        );

    let hex_with_cartouche =
        codepoints_to_hex(
            &codepoints,
        );

    Some(ParseResult {
        input: input.to_string(),

        caps: Some(caps),

        proper_name,
        unique_code,

        ucsur_codepoints:
            inner_codepoints.clone(),

        hex_codepoints,
        hex_with_cartouche,

        tp_words: tp_words.clone(),
        words: tp_words,

        display_value,

        is_time: false,
        is_date: false,
        is_time_like: false,

        inner_codepoints,
        codepoints,

        numeric_mode:
            options
                .numeric_mode
                .as_str()
                .to_string(),

        semantic_kind: None,
        semantic_start_glyph: None,

        kind: None,
        number_base: None,

        is_hex: false,
        is_binary: false,

        hex_digits: None,
        binary_digits: None,

        hex_parts: None,
        binary_parts: None,

        abbreviated_ucsur_codepoints:
            None,

        abbreviated_words: None,
        nasin_nanpa_pona_words: None,
    })
}

fn apply_percent(
    mut result: ParseResult,
    original_input: &str,
) -> Option<ParseResult> {
    /*
     * Percent is a postfix wrapper around an already
     * parsed decimal number. This deliberately reuses
     * all existing sign, decimal, grouping, magnitude,
     * proper-name, and display canonicalization.
     */

    let caps =
        result.caps.take()?;

    let caps_without_final_n =
        caps.strip_suffix('N')?;

    result.caps = Some(
        format!(
            "{caps_without_final_n}OKN"
        )
    );

    result.proper_name.push(' ');
    result.proper_name.push_str(
        PERCENT.proper_name
    );

    result.unique_code.push_str(
        PERCENT.unique_code
    );

    if result.tp_words.last().map(
        String::as_str
    ) != Some("nanpa")
    {
        return None;
    }

    result.tp_words.pop();

    result.tp_words.extend(
        PERCENT
            .tp_words
            .iter()
            .map(|word| {
                (*word).to_string()
            }),
    );

    result.tp_words.push(
        "nanpa".to_string()
    );

    result.words =
        result.tp_words.clone();

    if result.inner_codepoints.last()
        != Some(&NANPA)
    {
        return None;
    }

    result.inner_codepoints.pop();

    result
        .inner_codepoints
        .extend_from_slice(
            PERCENT.codepoints
        );

    result.inner_codepoints.push(
        NANPA
    );

    result.ucsur_codepoints =
        result.inner_codepoints.clone();

    result.hex_codepoints =
        codepoints_to_hex(
            &result.inner_codepoints,
        );

    let mut codepoints =
        Vec::with_capacity(
            result.inner_codepoints.len()
                + 2,
        );

    codepoints.push(
        CARTOUCHE_START
    );

    codepoints.extend_from_slice(
        &result.inner_codepoints,
    );

    codepoints.push(
        CARTOUCHE_END
    );

    result.hex_with_cartouche =
        codepoints_to_hex(
            &codepoints,
        );

    result.codepoints =
        codepoints;

    result.display_value.push('%');

    result.input =
        original_input.to_string();

    Some(result)
}

pub fn parse_decimal_number(
    input: &str,
    options: &ParseOptions,
) -> Option<ParseResult> {
    let source = input.trim();

    // Current JavaScript baseline: whitespace terminates digit-based numeric
    // input. Proper names and cartouches are handled by the extended parser
    // before this direct decimal path is reached.
    if source.chars().any(char::is_whitespace) {
        return None;
    }

    if let Some(before_percent) = source.strip_suffix('%') {
        if before_percent.is_empty() {
            return None;
        }
        let result = parse_decimal_number_core(before_percent, options)?;
        return apply_percent(result, input);
    }

    parse_decimal_number_core(input, options)
}


fn traditional_mode(options: &ParseOptions) -> bool {
    options.mode == NumericMode::Traditional
        || options.numeric_mode == NumericMode::Traditional
}

fn canonicalize_scientific_caps(caps: &str) -> String {
    caps.trim()
        .to_ascii_uppercase()
        .replace("NEKOWENINEKO", "NEKO")
        .replace("NEKOWANINEKO", "NEKO")
}

fn tokenize_caps_for_rendering(caps: &str) -> Option<Vec<String>> {
    const PREFIXES: &[&str] = &[
        "KEKEKE", "KEKE", "KO", "KE", "NONONO", "NONO", "NOKO", "OK", "NE", "NS", "NO",
    ];
    const DIGITS: &[&str] = &[
        "NI", "WE", "WA", "TE", "TU", "SE", "NA", "LE", "LU", "NU", "ME", "MU", "PE", "PI", "JE", "JO",
    ];

    let source = canonicalize_scientific_caps(caps);
    if source.is_empty() || !source.starts_with("NE") || !source.ends_with('N') {
        return None;
    }

    let end = source.len() - 1;
    let mut tokens = Vec::<String>::new();
    let mut index = 0usize;

    while index < end {
        let tail = &source[index..end];
        if let Some(prefix) = PREFIXES.iter().find(|prefix| tail.starts_with(**prefix)) {
            tokens.push((*prefix).to_string());
            index += prefix.len();
            continue;
        }

        if index + 2 <= end {
            let pair = &source[index..index + 2];
            if DIGITS.contains(&pair) {
                tokens.push(pair.to_string());
                index += 2;
                continue;
            }
        }

        return None;
    }

    tokens.push("N".to_string());
    Some(tokens)
}

fn traditional_digit_words(token: &str, relaxed_rendering: bool) -> Option<Vec<&'static str>> {
    if relaxed_rendering {
        let relaxed = match token {
            "WE" | "WA" => Some(vec!["wan", "ala"]),
            "TE" | "TU" => Some(vec!["tu", "uta"]),
            "LE" | "LU" => Some(vec!["luka", "uta"]),
            "ME" | "MU" => Some(vec!["mun", "uta"]),
            "PE" | "PI" => Some(vec!["pipi", "ike"]),
            "JE" | "JO" => Some(vec!["jo", "open"]),
            _ => None,
        };
        if relaxed.is_some() {
            return relaxed;
        }
    }

    let strict = match token {
        "WA" => "WE",
        "TU" => "TE",
        "LU" => "LE",
        "MU" => "ME",
        "PI" => "PE",
        "JO" => "JE",
        other => other,
    };

    let digit_word = match strict {
        "NI" => "ijo",
        "WE" => "wan",
        "TE" => "tu",
        "SE" => "seli",
        "NA" => "awen",
        "LE" => "luka",
        "NU" => "utala",
        "ME" => "mun",
        "PE" => "pipi",
        "JE" => "jo",
        _ => return None,
    };

    if matches!(strict, "NI" | "NA" | "NU") {
        Some(vec!["nasa", digit_word])
    } else {
        Some(vec![digit_word, "esun"])
    }
}

fn rendering_start_word(result: &ParseResult, options: &ParseOptions) -> &'static str {
    if let Some(glyph) = options.numeric_cartouche_start_glyph {
        return glyph.as_str();
    }
    if let Some(glyph) = result.semantic_start_glyph {
        return glyph.as_str();
    }
    if options.nanpa_colon_rendering {
        if let Some(kind) = result.semantic_kind {
            return match kind.as_str() {
                "date" => "suno",
                "time" => "tenpo",
                _ => "nanpa",
            };
        }
    }
    "nanpa"
}

fn replace_traditional_time_separators(words: &[String]) -> Vec<String> {
    let pattern = ["nasa", "e", "kulupu", "e"];
    let replacement = ["nasa", "e", "kasi", "e"];
    let mut out = Vec::<String>::new();
    let mut index = 0usize;

    while index < words.len() {
        let matches = index + pattern.len() <= words.len()
            && pattern
                .iter()
                .enumerate()
                .all(|(offset, word)| words[index + offset] == *word);
        if matches {
            out.extend(replacement.iter().map(|word| (*word).to_string()));
            index += pattern.len();
        } else {
            out.push(words[index].clone());
            index += 1;
        }
    }
    out
}

fn word_to_codepoint(word: &str) -> Option<u32> {
    match word {
        ":" => Some(0xF199D),
        "ala" => Some(0xF1902),
        "e" => Some(0xF1909),
        "en" => Some(0xF190A),
        "esun" => Some(0xF190B),
        "ijo" => Some(0xF190C),
        "ike" => Some(0xF190D),
        "jo" => Some(0xF1913),
        "kala" => Some(0xF1914),
        "kasi" => Some(0xF1917),
        "kin" => Some(0xF1979),
        "kipisi" => Some(0xF197B),
        "kulupu" => Some(0xF191F),
        "luka" => Some(0xF192D),
        "mun" => Some(0xF193A),
        "nanpa" => Some(0xF193D),
        "nasa" => Some(0xF193E),
        "nena" => Some(0xF1940),
        "ni" => Some(0xF1941),
        "noka" => Some(0xF1943),
        "o" => Some(0xF1944),
        "ona" => Some(0xF1946),
        "open" => Some(0xF1947),
        "pipi" => Some(0xF1951),
        "seli" => Some(0xF1957),
        "suno" => Some(0xF1964),
        "tenpo" => Some(0xF196B),
        "toki" => Some(0xF196C),
        "tu" => Some(0xF196E),
        "uta" => Some(0xF1970),
        "utala" => Some(0xF1971),
        "wan" => Some(0xF1973),
        "awen" => Some(0xF1908),
        _ => None,
    }
}

fn apply_traditional_rendering(
    mut result: ParseResult,
    options: &ParseOptions,
) -> Option<ParseResult> {
    if !traditional_mode(options) || !result.is_decimal() {
        return Some(result);
    }

    let caps = result.caps.as_deref()?;
    let tokens = tokenize_caps_for_rendering(caps)?;
    let has_percent = tokens.iter().any(|token| token == "OK");
    let tokens = tokens
        .into_iter()
        .filter(|token| token != "OK")
        .collect::<Vec<_>>();

    let start_word = rendering_start_word(&result, options);
    let mut words = Vec::<String>::new();
    let mut after_starting_ne = false;
    let mut after_scientific_marker = false;
    let mut index = 0usize;

    while index < tokens.len() {
        let token = tokens[index].as_str();
        match token {
            "NE" => {
                if tokens.get(index + 1).map(String::as_str) == Some("KO") {
                    if words.is_empty() {
                        if options.nanpa_colon_rendering {
                            words.extend([start_word, ":", "kala", "open"].iter().map(|word| (*word).to_string()));
                        } else {
                            words.extend([start_word, "esun", "kala", "open"].iter().map(|word| (*word).to_string()));
                        }
                    } else {
                        words.extend(["nasa", "e", "kala", "open"].iter().map(|word| (*word).to_string()));
                    }
                    after_starting_ne = false;
                    after_scientific_marker = true;
                    index += 2;
                    continue;
                }

                after_scientific_marker = false;
                if words.is_empty() {
                    if options.nanpa_colon_rendering {
                        words.extend([start_word, ":"].iter().map(|word| (*word).to_string()));
                    } else {
                        words.extend([start_word, "esun"].iter().map(|word| (*word).to_string()));
                    }
                    after_starting_ne = true;
                } else {
                    words.extend(["nasa", "e"].iter().map(|word| (*word).to_string()));
                    after_starting_ne = false;
                }
            }
            "NS" => {
                words.extend(["nena", "en"].iter().map(|word| (*word).to_string()));
                after_starting_ne = false;
                after_scientific_marker = false;
            }
            "NI" | "WE" | "WA" | "TE" | "TU" | "SE" | "NA" | "LE" | "LU" | "NU" | "ME" | "MU" | "PE" | "PI" | "JE" | "JO" => {
                words.extend(
                    traditional_digit_words(token, options.relaxed_nanpa_linjan_rendering)?
                        .into_iter()
                        .map(str::to_string),
                );
                after_starting_ne = false;
                after_scientific_marker = false;
            }
            "NO" => {
                if after_starting_ne || after_scientific_marker {
                    words.extend(["nasa", "ona"].iter().map(|word| (*word).to_string()));
                    after_starting_ne = false;
                    after_scientific_marker = false;
                } else if tokens.get(index + 1).map(String::as_str) == Some("NE") {
                    words.extend(["ni", "o", "nasa", "e"].iter().map(|word| (*word).to_string()));
                    after_starting_ne = false;
                    index += 2;
                    continue;
                } else {
                    words.extend(["ni", "o"].iter().map(|word| (*word).to_string()));
                    after_starting_ne = false;
                }
            }
            "NONO" => {
                words.extend(["nena", "o", "nena", "o"].iter().map(|word| (*word).to_string()));
                after_starting_ne = false;
            }
            "NOKO" => {
                words.extend(["nena", "open", "kin", "open"].iter().map(|word| (*word).to_string()));
                after_starting_ne = false;
            }
            "NONONO" => {
                words.extend(["nasa", "o", "nasa", "o", "nasa", "o"].iter().map(|word| (*word).to_string()));
                after_starting_ne = false;
            }
            "KE" => {
                words.extend(["kulupu", "e"].iter().map(|word| (*word).to_string()));
                after_starting_ne = false;
            }
            "KEKE" => {
                words.extend(["kulupu", "e", "kulupu", "e"].iter().map(|word| (*word).to_string()));
                after_starting_ne = false;
            }
            "KEKEKE" => {
                words.extend(["kulupu", "e", "kulupu", "e", "kulupu", "e"].iter().map(|word| (*word).to_string()));
                after_starting_ne = false;
            }
            "N" => {
                words.push("nanpa".to_string());
                after_starting_ne = false;
            }
            _ => return None,
        }
        index += 1;
    }

    if result.is_time_like {
        words = replace_traditional_time_separators(&words);
    }

    if has_percent {
        let suffix = ["noka", "open", "kipisi", "e"];
        if let Some(position) = words.iter().rposition(|word| word == "nanpa") {
            words.splice(
                position..position,
                suffix.iter().map(|word| (*word).to_string()),
            );
        } else {
            words.extend(suffix.iter().map(|word| (*word).to_string()));
        }
    }

    let inner_codepoints = words
        .iter()
        .map(|word| word_to_codepoint(word))
        .collect::<Option<Vec<_>>>()?;

    let mut codepoints = Vec::with_capacity(inner_codepoints.len() + 2);
    codepoints.push(CARTOUCHE_START);
    codepoints.extend_from_slice(&inner_codepoints);
    codepoints.push(CARTOUCHE_END);

    result.tp_words = words.clone();
    result.words = words;
    result.ucsur_codepoints = inner_codepoints.clone();
    result.inner_codepoints = inner_codepoints.clone();
    result.codepoints = codepoints.clone();
    result.hex_codepoints = codepoints_to_hex(&inner_codepoints);
    result.hex_with_cartouche = codepoints_to_hex(&codepoints);
    result.numeric_mode = "traditional".to_string();

    Some(result)
}


fn parser_word_for_codepoint(cp: u32) -> Option<&'static str> {
    match cp {
        0xF199D => Some(":"),
        0xF1902 => Some("ala"),
        0xF1908 => Some("awen"),
        0xF1909 => Some("e"),
        0xF190A => Some("en"),
        0xF190B => Some("esun"),
        0xF190C => Some("ijo"),
        0xF190D => Some("ike"),
        0xF1913 => Some("jo"),
        0xF1914 => Some("kala"),
        0xF1917 => Some("kasi"),
        0xF191F => Some("kulupu"),
        0xF192D => Some("luka"),
        0xF193A => Some("mun"),
        0xF193D => Some("nanpa"),
        0xF193E => Some("nasa"),
        0xF1940 => Some("nena"),
        0xF1941 => Some("ni"),
        0xF1943 => Some("noka"),
        0xF1944 => Some("o"),
        0xF1946 => Some("ona"),
        0xF1947 => Some("open"),
        0xF1951 => Some("pipi"),
        0xF1957 => Some("seli"),
        0xF1964 => Some("suno"),
        0xF196B => Some("tenpo"),
        0xF196C => Some("toki"),
        0xF196E => Some("tu"),
        0xF1970 => Some("uta"),
        0xF1971 => Some("utala"),
        0xF1973 => Some("wan"),
        0xF1979 => Some("kin"),
        0xF197B => Some("kipisi"),
        _ => None,
    }
}

fn abbreviate_parser_cartouche(full: &[u32], preserve_breaks: bool) -> Vec<u32> {
    if full.len() < 3 || full.first() != Some(&CARTOUCHE_START) || full.last() != Some(&CARTOUCHE_END) {
        return full.to_vec();
    }
    const NASA: u32 = 0xF193E;
    const NOKA: u32 = 0xF1943;
    const TENPO: u32 = 0xF196B;
    const SUNO: u32 = 0xF1964;
    const TOKI: u32 = 0xF196C;
    const NENA: u32 = 0xF1940;
    const EN: u32 = 0xF190A;
    const OPEN: u32 = 0xF1947;
    const ALA: u32 = 0xF1902;
    const IKE: u32 = 0xF190D;
    const UTA: u32 = 0xF1970;
    let chars = &full[1..full.len()-1];
    let heads = [NANPA, NASA, NOKA, TENPO, SUNO, TOKI];
    let is_head = |cp: u32| heads.contains(&cp);
    let is_drop = |cp: u32| matches!(cp, NANPA | EN | E | NENA | OPEN | ALA | IKE | UTA);
    let traditional_full_positive = chars.len() >= 4 && is_head(chars[0]) && chars[1] == E && chars[2] == NENA && chars[3] == EN;
    let colon_full_positive = chars.len() >= 4 && is_head(chars[0]) && chars[1] == COLON && chars[2] == NENA && chars[3] == EN;
    let full_positive = traditional_full_positive || colon_full_positive;
    let full_scaffolding_after_opening = if chars.len() > 3 { chars[2..chars.len()-1].iter().any(|cp| *cp == E || is_drop(*cp)) } else { false };
    let already_abbreviated_positive = !full_positive && !full_scaffolding_after_opening && chars.len() >= 3 && is_head(chars[0]) && chars[1] == EN;
    let already_abbreviated_colon_positive = !full_positive && !full_scaffolding_after_opening && chars.len() >= 4 && is_head(chars[0]) && chars[1] == COLON && chars[2] == EN;
    let mut inner = Vec::with_capacity(chars.len());
    let mut kept_opening = false;
    let mut i = 0usize;
    while i < chars.len() {
        let cp = chars[i];
        let final_nanpa = cp == NANPA && i + 1 == chars.len();
        if !kept_opening {
            inner.push(cp);
            if (i == 0 && is_head(cp)) || cp == NANPA { kept_opening = true; }
            i += 1;
            continue;
        }
        if final_nanpa { inner.push(cp); i += 1; continue; }
        if traditional_full_positive && i == 1 { inner.push(EN); i = 4; continue; }
        if colon_full_positive && i == 2 { inner.push(EN); i = 4; continue; }
        if already_abbreviated_positive && i == 1 { inner.push(EN); i += 1; continue; }
        if already_abbreviated_colon_positive && i == 2 { inner.push(EN); i += 1; continue; }
        if preserve_breaks && cp == NENA && i + 3 < chars.len()
            && matches!(chars[i+1], E | EN) && chars[i+2] == NENA && matches!(chars[i+3], E | EN)
        {
            inner.push(E); i += 4; continue;
        }
        if !is_drop(cp) { inner.push(cp); }
        i += 1;
    }
    let mut out = Vec::with_capacity(inner.len()+2);
    out.push(CARTOUCHE_START); out.extend(inner); out.push(CARTOUCHE_END); out
}

fn base100_group_words(mut value: u32) -> Vec<String> {
    let mut out = Vec::new();
    while value >= 20 { out.push("mute".to_string()); value -= 20; }
    while value >= 5 { out.push("luka".to_string()); value -= 5; }
    while value >= 2 { out.push("tu".to_string()); value -= 2; }
    if value == 1 { out.push("wan".to_string()); }
    out
}

fn grouped_base100_words(groups: &[String]) -> Option<Vec<String>> {
    let mut out = Vec::new();
    for (index, group) in groups.iter().enumerate() {
        if group.is_empty() || group.len() > 2 || !group.chars().all(|c| c.is_ascii_digit()) { return None; }
        let value = group.parse::<u32>().ok()?;
        if value > 99 { return None; }
        out.extend(base100_group_words(value));
        if index + 1 < groups.len() { out.push("ale".to_string()); }
    }
    Some(out)
}

pub(crate) fn try_plain_decimal_to_nasin_nanpa_pona_words(value: &str) -> Option<Vec<String>> {
    let mut raw = value.trim().replace('−', "-").replace('‒', "-").replace('–', "-").replace('—', "-");
    if raw.is_empty() { return None; }
    let negative = raw.starts_with('-');
    if negative { raw.remove(0); }
    if raw.is_empty() || raw.starts_with('+') || raw.starts_with('-') { return None; }
    let mut split = raw.split('.');
    let integer_part = split.next().unwrap_or("");
    let fraction_part = split.next();
    if split.next().is_some() { return None; }
    if fraction_part.is_some_and(|f| f.is_empty() || !f.chars().all(|c| c.is_ascii_digit())) { return None; }

    fn valid_integer(s: &str) -> bool {
        if s == "0" { return true; }
        if s.is_empty() { return false; }
        if !s.contains(',') {
            return !s.starts_with('0') && s.chars().all(|c| c.is_ascii_digit());
        }
        let groups: Vec<&str> = s.split(',').collect();
        if groups.is_empty() || groups[0].is_empty() || groups[0].len() > 3 || groups[0].starts_with('0') || !groups[0].chars().all(|c| c.is_ascii_digit()) { return false; }
        groups.iter().skip(1).all(|g| g.len() == 3 && g.chars().all(|c| c.is_ascii_digit()))
    }

    let integer_digits = if integer_part.is_empty() {
        if fraction_part.is_none() { return None; }
        "0".to_string()
    } else {
        if !valid_integer(integer_part) { return None; }
        integer_part.replace(',', "")
    };
    let fraction_digits = fraction_part.unwrap_or("").trim_end_matches('0').to_string();
    if integer_digits == "0" && fraction_digits.is_empty() { return Some(vec!["ala".to_string()]); }

    let split_right = |digits: &str| -> Vec<String> {
        let mut groups = Vec::new();
        let mut end = digits.len();
        while end > 0 {
            let start = end.saturating_sub(2);
            groups.insert(0, digits[start..end].to_string());
            end = start;
        }
        groups
    };
    let mut integer_words = if integer_digits == "0" { vec!["ala".to_string()] } else { grouped_base100_words(&split_right(&integer_digits))? };
    let mut words = Vec::new();
    if negative { words.push("weka".to_string()); }
    words.append(&mut integer_words);
    if !fraction_digits.is_empty() {
        let mut padded = fraction_digits.clone();
        if padded.len() % 2 != 0 { padded.push('0'); }
        let groups = (0..padded.len()).step_by(2).map(|i| padded[i..i+2].to_string()).collect::<Vec<_>>();
        let mut fraction_words = grouped_base100_words(&groups)?;
        words.push("ala".to_string());
        words.append(&mut fraction_words);
    }
    Some(words)
}

fn finalize_parse_result(mut result: ParseResult, options: &ParseOptions) -> ParseResult {
    if result.abbreviated_ucsur_codepoints.is_none() || result.abbreviated_words.is_none() {
        let abbreviated = abbreviate_parser_cartouche(&result.codepoints, options.preserve_numeric_cartouche_breaks_in_abbreviation);
        if abbreviated.len() >= 2 {
            let inner = abbreviated[1..abbreviated.len()-1].to_vec();
            let words = inner.iter().filter_map(|cp| parser_word_for_codepoint(*cp).map(|word| word.to_string())).collect::<Vec<_>>();
            result.abbreviated_ucsur_codepoints = Some(inner);
            result.abbreviated_words = Some(words);
        }
    }
    result.nasin_nanpa_pona_words = if options.nasin_nanpa_pona {
        try_plain_decimal_to_nasin_nanpa_pona_words(&result.display_value)
    } else { None };
    result
}

pub fn parse_number(
    input: &str,
    options: &ParseOptions,
) -> Option<ParseResult> {
    if let Some(result) = extended::parse_extended_number(input, options) {
        return apply_traditional_rendering(result, options)
            .map(|result| finalize_parse_result(result, options));
    }

    let source = input.trim();
    if source.chars().any(char::is_whitespace) {
        return None;
    }

    let result = parse_decimal_number(source, options)?;
    apply_traditional_rendering(result, options)
        .map(|result| finalize_parse_result(result, options))
}
