mod extended;

use crate::decimal_metadata::{
    DECIMAL_POINT,
    FRACTION_GROUP_SEPARATOR,
    NEGATIVE_SIGN,
    PERCENT,
    POSITIVE_SIGN,
};
use crate::digit_metadata::metadata_for_digit;
use crate::digits::{encode_digit, DigitStyle};
use crate::encoding::encode_decimal;
use crate::model::ParseResult;
use crate::options::{NumericMode, ParseOptions};
use crate::protocol::{
    CARTOUCHE_END,
    CARTOUCHE_START,
};

const NANPA: u32 = 0xF193D;
const COLON: u32 = 0xF199D;
const E: u32 = 0xF1909;

const MAGNITUDE_WORDS: &[&str] =
    &["nena", "e", "kulupu", "e"];

const MAGNITUDE_CODEPOINTS: &[u32] = &[
    0xF1940,
    0xF1909,
    0xF191F,
    0xF1909,
];

const MAGNITUDE_PREFIX_WORDS: &[&str] =
    &["nena", "e"];

const MAGNITUDE_PREFIX_CODEPOINTS: &[u32] = &[
    0xF1940,
    0xF1909,
];

const MAGNITUDE_UNIT_WORDS: &[&str] =
    &["kulupu", "e"];

const MAGNITUDE_UNIT_CODEPOINTS: &[u32] = &[
    0xF191F,
    0xF1909,
];

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum DecimalSign {
    None,
    Negative,
    Positive,
}

fn codepoints_to_hex(
    codepoints: &[u32],
) -> String {
    codepoints
        .iter()
        .map(|cp| format!("{cp:X}"))
        .collect::<Vec<_>>()
        .join(" ")
}

fn digit_style(
    options: &ParseOptions,
) -> DigitStyle {
    if options.relaxed_nanpa_linjan_rendering {
        DigitStyle::Relaxed
    } else {
        DigitStyle::Strict
    }
}

fn digit_proper_syllable(
    digit: u8,
    options: &ParseOptions,
) -> Option<String> {
    let syllable =
        encode_digit(
            digit,
            digit_style(options),
        )?;

    Some(
        syllable.to_ascii_lowercase()
    )
}

fn title_word(
    value: &str,
) -> String {
    let mut chars = value.chars();

    match chars.next() {
        Some(first) => format!(
            "{}{}",
            first.to_ascii_uppercase(),
            chars.as_str()
        ),

        None => String::new(),
    }
}

fn finish_numeric_proper_group(
    mut value: String,
) -> String {
    value.push('n');
    title_word(&value)
}

fn split_two_trailing_zeroes(
    value: &str,
) -> bool {
    value.len() >= 3
        && value.ends_with("00")
        && !value.ends_with("000")
}

fn append_digit(
    digit: u8,
    unique_code: &mut String,
    tp_words: &mut Vec<String>,
    codepoints: &mut Vec<u32>,
) -> Option<()> {
    let metadata =
        metadata_for_digit(digit)?;

    unique_code.push(
        metadata.unique_code
    );

    tp_words.extend(
        metadata
            .tp_words
            .iter()
            .map(|word| {
                (*word).to_string()
            }),
    );

    codepoints.extend_from_slice(
        &metadata.codepoints,
    );

    Some(())
}

fn append_marker(
    unique_code_fragment: &str,
    marker_words: &[&str],
    marker_codepoints: &[u32],
    unique_code: &mut String,
    tp_words: &mut Vec<String>,
    codepoints: &mut Vec<u32>,
) {
    unique_code.push_str(
        unique_code_fragment,
    );

    tp_words.extend(
        marker_words
            .iter()
            .map(|word| {
                (*word).to_string()
            }),
    );

    codepoints.extend_from_slice(
        marker_codepoints,
    );
}

fn append_magnitude_marker(
    unique_code: &mut String,
    tp_words: &mut Vec<String>,
    codepoints: &mut Vec<u32>,
) {
    append_marker(
        "k",
        MAGNITUDE_WORDS,
        MAGNITUDE_CODEPOINTS,
        unique_code,
        tp_words,
        codepoints,
    );
}

fn append_terminal_magnitude(
    power: usize,
    unique_code: &mut String,
    tp_words: &mut Vec<String>,
    codepoints: &mut Vec<u32>,
    proper_words: &mut Vec<String>,
) {
    if power == 0 {
        return;
    }

    for _ in 0..power {
        unique_code.push('k');
    }

    tp_words.extend(
        MAGNITUDE_PREFIX_WORDS
            .iter()
            .map(|word| {
                (*word).to_string()
            }),
    );

    codepoints.extend_from_slice(
        MAGNITUDE_PREFIX_CODEPOINTS,
    );

    for _ in 0..power {
        tp_words.extend(
            MAGNITUDE_UNIT_WORDS
                .iter()
                .map(|word| {
                    (*word).to_string()
                }),
        );

        codepoints.extend_from_slice(
            MAGNITUDE_UNIT_CODEPOINTS,
        );
    }

    match power {
        1 => {
            proper_words.push(
                "Eken".to_string(),
            );
        }

        2 => {
            proper_words.push(
                "Ekeken".to_string(),
            );
        }

        3 => {
            proper_words.push(
                "Ekekeken".to_string(),
            );
        }

        4 => {
            proper_words.push(
                "Ekeke".to_string(),
            );

            proper_words.push(
                "Keken".to_string(),
            );
        }

        _ => {
            for _ in 0..power - 1 {
                proper_words.push(
                    "Eke".to_string(),
                );
            }

            proper_words.push(
                "Eken".to_string(),
            );
        }
    }
}

fn format_fraction_display(
    fraction: &str,
) -> String {
    fraction
        .as_bytes()
        .chunks(3)
        .map(|chunk| {
            std::str::from_utf8(chunk)
                .expect(
                    "ASCII decimal fraction",
                )
        })
        .collect::<Vec<_>>()
        .join("_")
}

fn magnitude_power(
    ch: char,
) -> Option<usize> {
    match ch.to_ascii_uppercase() {
        'K' => Some(1),
        'M' => Some(2),
        'B' => Some(3),
        'T' => Some(4),
        _ => None,
    }
}

fn magnitude_suffix(
    power: usize,
) -> Option<char> {
    match power {
        1 => Some('K'),
        2 => Some('M'),
        3 => Some('B'),
        4 => Some('T'),
        _ => None,
    }
}

fn parse_decimal_number_core(
    input: &str,
    options: &ParseOptions,
) -> Option<ParseResult> {
    let source = input.trim();

    if source.is_empty() {
        return None;
    }

    let (sign, unsigned) =
        if let Some(rest) =
            source.strip_prefix('+')
        {
            (
                DecimalSign::Positive,
                rest,
            )
        } else if let Some(rest) =
            source.strip_prefix('-')
        {
            (
                DecimalSign::Negative,
                rest,
            )
        } else {
            (
                DecimalSign::None,
                source,
            )
        };

    if unsigned.is_empty() {
        return None;
    }

    let (
        numeric_unsigned,
        explicit_magnitude_power,
    ) = if let Some(last) =
        unsigned.chars().last()
    {
        if let Some(power) =
            magnitude_power(last)
        {
            let end =
                unsigned.len()
                    - last.len_utf8();

            let body =
                &unsigned[..end];

            if body.is_empty() {
                return None;
            }

            (body, power)
        } else {
            (unsigned, 0)
        }
    } else {
        return None;
    };

    let mut split =
        numeric_unsigned.split('.');

    let integer_raw =
        split.next()?;

    let fraction_raw =
        split.next();

    if split.next().is_some() {
        return None;
    }

    let has_decimal_point =
        fraction_raw.is_some();

    let implicit_zero =
        integer_raw.is_empty();

    let integer_source =
        if implicit_zero {
            if has_decimal_point {
                "0"
            } else {
                return None;
            }
        } else {
            integer_raw
        };

    let integer_groups:
        Vec<&str> =
        integer_source
            .split(',')
            .collect();

    if integer_groups.is_empty()
        || integer_groups
            .iter()
            .any(|group| {
                group.is_empty()
                    || !group
                        .chars()
                        .all(
                            |ch| {
                                ch.is_ascii_digit()
                            },
                        )
            })
    {
        return None;
    }

    if let Some(fraction) =
        fraction_raw
    {
        if fraction.is_empty()
            || !fraction
                .chars()
                .all(
                    |ch| {
                        ch.is_ascii_digit()
                    },
                )
        {
            return None;
        }
    }

    let trailing_zero_groups =
        if integer_groups.len() > 1 {
            let count =
                integer_groups
                    .iter()
                    .rev()
                    .take_while(
                        |group| {
                            **group == "000"
                        },
                    )
                    .count();

            if count <
                integer_groups.len()
            {
                count
            } else {
                0
            }
        } else {
            0
        };

    let significant_count =
        integer_groups.len()
            - trailing_zero_groups;

    let caps =
        encode_decimal(
            source,
            options,
        )
        .ok()?;

    let mut unique_code =
        String::from("#~");

    let mut tp_words = vec![
        "nanpa".to_string(),
        if options.nanpa_colon_rendering {
            ":".to_string()
        } else {
            "e".to_string()
        },
    ];

    let mut inner_codepoints =
        vec![
            NANPA,
            if options.nanpa_colon_rendering {
                COLON
            } else {
                E
            },
        ];

    let mut first_proper_group =
        String::new();

    match sign {
        DecimalSign::None => {}

        DecimalSign::Negative => {
            first_proper_group
                .push_str("no");

            append_marker(
                NEGATIVE_SIGN
                    .unique_code,
                NEGATIVE_SIGN
                    .tp_words,
                NEGATIVE_SIGN
                    .codepoints,
                &mut unique_code,
                &mut tp_words,
                &mut inner_codepoints,
            );
        }

        DecimalSign::Positive => {
            first_proper_group
                .push_str("ne");

            append_marker(
                POSITIVE_SIGN
                    .unique_code,
                POSITIVE_SIGN
                    .tp_words,
                POSITIVE_SIGN
                    .codepoints,
                &mut unique_code,
                &mut tp_words,
                &mut inner_codepoints,
            );
        }
    }

    let first_group =
        integer_groups[0];

    /*
     * Canonical proper-name compatibility:
     * an ungrouped integer component ending in
     * exactly two zero digits splits those digits
     * into the separate word "Inin".
     *
     * 100   -> Wan Inin
     * 1200  -> Watun Inin
     * -100  -> Nowan Inin
     *
     * Three or more trailing zeroes remain joined.
     */
    let split_first_two_zeroes =
        split_two_trailing_zeroes(
            first_group
        );

    let split_digit_index =
        if split_first_two_zeroes {
            first_group.len() - 2
        } else {
            first_group.len()
        };

    for (digit_index, ch) in
        first_group.chars().enumerate()
    {
        let digit =
            ch.to_digit(10)? as u8;

        if !split_first_two_zeroes
            || digit_index < split_digit_index
        {
            first_proper_group
                .push_str(
                    &digit_proper_syllable(
                        digit,
                        options,
                    )?,
                );
        }

        append_digit(
            digit,
            &mut unique_code,
            &mut tp_words,
            &mut inner_codepoints,
        )?;
    }

    let mut proper_words = vec![
        finish_numeric_proper_group(
            first_proper_group,
        ),
    ];

    if split_first_two_zeroes {
        proper_words.push(
            "Inin".to_string(),
        );
    }

    for group in integer_groups
        .iter()
        .take(significant_count)
        .skip(1)
    {
        append_magnitude_marker(
            &mut unique_code,
            &mut tp_words,
            &mut inner_codepoints,
        );

        proper_words.push(
            "Eke".to_string(),
        );

        let split_group_two_zeroes =
            split_two_trailing_zeroes(
                group
            );

        let group_split_index =
            if split_group_two_zeroes {
                group.len() - 2
            } else {
                group.len()
            };

        let mut proper_group =
            String::new();

        for (digit_index, ch) in
            group.chars().enumerate()
        {
            let digit =
                ch.to_digit(10)?
                    as u8;

            if !split_group_two_zeroes
                || digit_index
                    < group_split_index
            {
                proper_group.push_str(
                    &digit_proper_syllable(
                        digit,
                        options,
                    )?,
                );
            }

            append_digit(
                digit,
                &mut unique_code,
                &mut tp_words,
                &mut inner_codepoints,
            )?;
        }

        proper_words.push(
            finish_numeric_proper_group(
                proper_group,
            ),
        );

        if split_group_two_zeroes {
            proper_words.push(
                "Inin".to_string(),
            );
        }
    }

    append_terminal_magnitude(
        trailing_zero_groups,
        &mut unique_code,
        &mut tp_words,
        &mut inner_codepoints,
        &mut proper_words,
    );

    if let Some(fraction) =
        fraction_raw
    {
        append_marker(
            DECIMAL_POINT
                .unique_code,
            DECIMAL_POINT
                .tp_words,
            DECIMAL_POINT
                .codepoints,
            &mut unique_code,
            &mut tp_words,
            &mut inner_codepoints,
        );

        proper_words.push(
            DECIMAL_POINT
                .proper_name
                .to_string(),
        );

        for (
            group_index,
            chunk,
        ) in fraction
            .as_bytes()
            .chunks(3)
            .enumerate()
        {
            if group_index > 0 {
                append_marker(
                    FRACTION_GROUP_SEPARATOR
                        .unique_code,
                    FRACTION_GROUP_SEPARATOR
                        .tp_words,
                    FRACTION_GROUP_SEPARATOR
                        .codepoints,
                    &mut unique_code,
                    &mut tp_words,
                    &mut inner_codepoints,
                );

                proper_words.push(
                    FRACTION_GROUP_SEPARATOR
                        .proper_name
                        .to_string(),
                );
            }

            let group =
                std::str::from_utf8(
                    chunk,
                )
                .ok()?;

            let mut proper_group =
                String::new();

            for ch in group.chars() {
                let digit =
                    ch.to_digit(10)?
                        as u8;

                proper_group.push_str(
                    &digit_proper_syllable(
                        digit,
                        options,
                    )?,
                );

                append_digit(
                    digit,
                    &mut unique_code,
                    &mut tp_words,
                    &mut inner_codepoints,
                )?;
            }

            proper_words.push(
                finish_numeric_proper_group(
                    proper_group,
                ),
            );
        }
    }

    append_terminal_magnitude(
        explicit_magnitude_power,
        &mut unique_code,
        &mut tp_words,
        &mut inner_codepoints,
        &mut proper_words,
    );

    tp_words.push(
        "nanpa".to_string()
    );

    inner_codepoints.push(NANPA);

    let proper_name = if options.nanpa_colon_rendering {
        format!(
            "Nanpa {}",
            proper_words.join(" ")
        )
    } else {
        let mut legacy_words = proper_words.clone();

        match sign {
            DecimalSign::None => {
                if let Some(first) = legacy_words.first_mut() {
                    *first = format!(
                        "Ne{}",
                        first.to_ascii_lowercase()
                    );
                }
            }

            DecimalSign::Negative => {
                if let Some(first) = legacy_words.first_mut() {
                    let tail = first
                        .strip_prefix("No")
                        .unwrap_or(first.as_str())
                        .to_string();
                    *first = title_word(&tail);
                }
                legacy_words.insert(0, "Neno".to_string());
            }

            DecimalSign::Positive => {
                if let Some(first) = legacy_words.first_mut() {
                    let tail = first
                        .strip_prefix("Ne")
                        .unwrap_or(first.as_str())
                        .to_string();
                    *first = title_word(&tail);
                }
                legacy_words.insert(0, "Nene".to_string());
            }
        }

        legacy_words.join(" ")
    };

    let sign_prefix =
        match sign {
            DecimalSign::None => "",
            DecimalSign::Negative => "-",
            DecimalSign::Positive => "+",
        };

    let significant_integer =
        integer_groups
            .iter()
            .take(significant_count)
            .copied()
            .collect::<Vec<_>>()
            .join(",");

    let display_integer =
        if implicit_zero {
            "0".to_string()
        } else {
            significant_integer
        };

    let mut display_core =
        display_integer;

    if let Some(fraction) =
        fraction_raw
    {
        display_core.push('.');

        display_core.push_str(
            &format_fraction_display(
                fraction,
            ),
        );
    }

    let total_magnitude_power =
        trailing_zero_groups
            + explicit_magnitude_power;

    let display_value =
        if total_magnitude_power > 0
        {
            if let Some(suffix) =
                magnitude_suffix(
                    total_magnitude_power,
                )
            {
                format!(
                    "{sign_prefix}{display_core}{suffix}"
                )
            } else {
                let mut value =
                    format!(
                        "{sign_prefix}{display_core}"
                    );

                for _ in
                    0..trailing_zero_groups
                {
                    value.push_str(
                        ",000"
                    );
                }

                if explicit_magnitude_power
                    > 0
                {
                    if let Some(suffix) =
                        magnitude_suffix(
                            explicit_magnitude_power,
                        )
                    {
                        value.push(
                            suffix
                        );
                    }
                }

                value
            }
        } else {
            format!(
                "{sign_prefix}{display_core}"
            )
        };

    let mut codepoints =
        Vec::with_capacity(
            inner_codepoints.len() + 2,
        );

    codepoints.push(
        CARTOUCHE_START
    );

    codepoints.extend_from_slice(
        &inner_codepoints,
    );

    codepoints.push(
        CARTOUCHE_END
    );

    let hex_codepoints =
        codepoints_to_hex(
            &inner_codepoints,
        );

    let hex_with_cartouche =
        codepoints_to_hex(
            &codepoints,
        );

    Some(ParseResult {
        input: input.to_string(),

        caps: Some(caps),

        proper_name,
        unique_code,

        ucsur_codepoints:
            inner_codepoints.clone(),

        hex_codepoints,
        hex_with_cartouche,

        tp_words: tp_words.clone(),
        words: tp_words,

        display_value,

        is_time: false,
        is_date: false,
        is_time_like: false,

        inner_codepoints,
        codepoints,

        numeric_mode:
            options
                .numeric_mode
                .as_str()
                .to_string(),

        semantic_kind: None,
        semantic_start_glyph: None,

        kind: None,
        number_base: None,

        is_hex: false,
        is_binary: false,

        hex_digits: None,
        binary_digits: None,

        hex_parts: None,
        binary_parts: None,

        abbreviated_ucsur_codepoints:
            None,

        abbreviated_words: None,
    })
}

fn apply_percent(
    mut result: ParseResult,
    original_input: &str,
) -> Option<ParseResult> {
    /*
     * Percent is a postfix wrapper around an already
     * parsed decimal number. This deliberately reuses
     * all existing sign, decimal, grouping, magnitude,
     * proper-name, and display canonicalization.
     */

    let caps =
        result.caps.take()?;

    let caps_without_final_n =
        caps.strip_suffix('N')?;

    result.caps = Some(
        format!(
            "{caps_without_final_n}OKN"
        )
    );

    result.proper_name.push(' ');
    result.proper_name.push_str(
        PERCENT.proper_name
    );

    result.unique_code.push_str(
        PERCENT.unique_code
    );

    if result.tp_words.last().map(
        String::as_str
    ) != Some("nanpa")
    {
        return None;
    }

    result.tp_words.pop();

    result.tp_words.extend(
        PERCENT
            .tp_words
            .iter()
            .map(|word| {
                (*word).to_string()
            }),
    );

    result.tp_words.push(
        "nanpa".to_string()
    );

    result.words =
        result.tp_words.clone();

    if result.inner_codepoints.last()
        != Some(&NANPA)
    {
        return None;
    }

    result.inner_codepoints.pop();

    result
        .inner_codepoints
        .extend_from_slice(
            PERCENT.codepoints
        );

    result.inner_codepoints.push(
        NANPA
    );

    result.ucsur_codepoints =
        result.inner_codepoints.clone();

    result.hex_codepoints =
        codepoints_to_hex(
            &result.inner_codepoints,
        );

    let mut codepoints =
        Vec::with_capacity(
            result.inner_codepoints.len()
                + 2,
        );

    codepoints.push(
        CARTOUCHE_START
    );

    codepoints.extend_from_slice(
        &result.inner_codepoints,
    );

    codepoints.push(
        CARTOUCHE_END
    );

    result.hex_with_cartouche =
        codepoints_to_hex(
            &codepoints,
        );

    result.codepoints =
        codepoints;

    result.display_value.push('%');

    result.input =
        original_input.to_string();

    Some(result)
}

pub fn parse_decimal_number(
    input: &str,
    options: &ParseOptions,
) -> Option<ParseResult> {
    let source = input.trim();

    if let Some(
        before_percent,
    ) = source.strip_suffix('%')
    {
        /*
         * The reference accepts whitespace immediately
         * before the percent sign:
         *
         * "5 %" -> "5%"
         *
         * Only trailing whitespace before '%' is
         * normalized here. The base parser remains
         * otherwise unchanged.
         */
        let base_source =
            before_percent.trim_end();

        if base_source.is_empty() {
            return None;
        }

        let result =
            parse_decimal_number_core(
                base_source,
                options,
            )?;

        return apply_percent(
            result,
            input,
        );
    }

    parse_decimal_number_core(
        input,
        options,
    )
}


fn traditional_mode(options: &ParseOptions) -> bool {
    options.mode == NumericMode::Traditional
        || options.numeric_mode == NumericMode::Traditional
}

fn canonicalize_scientific_caps(caps: &str) -> String {
    caps.trim()
        .to_ascii_uppercase()
        .replace("NEKOWENINEKO", "NEKO")
        .replace("NEKOWANINEKO", "NEKO")
}

fn tokenize_caps_for_rendering(caps: &str) -> Option<Vec<String>> {
    const PREFIXES: &[&str] = &[
        "KEKEKE", "KEKE", "KO", "KE", "NONONO", "NONO", "NOKO", "OK", "NE", "NS", "NO",
    ];
    const DIGITS: &[&str] = &[
        "NI", "WE", "WA", "TE", "TU", "SE", "NA", "LE", "LU", "NU", "ME", "MU", "PE", "PI", "JE", "JO",
    ];

    let source = canonicalize_scientific_caps(caps);
    if source.is_empty() || !source.starts_with("NE") || !source.ends_with('N') {
        return None;
    }

    let end = source.len() - 1;
    let mut tokens = Vec::<String>::new();
    let mut index = 0usize;

    while index < end {
        let tail = &source[index..end];
        if let Some(prefix) = PREFIXES.iter().find(|prefix| tail.starts_with(**prefix)) {
            tokens.push((*prefix).to_string());
            index += prefix.len();
            continue;
        }

        if index + 2 <= end {
            let pair = &source[index..index + 2];
            if DIGITS.contains(&pair) {
                tokens.push(pair.to_string());
                index += 2;
                continue;
            }
        }

        return None;
    }

    tokens.push("N".to_string());
    Some(tokens)
}

fn traditional_digit_words(token: &str, relaxed_rendering: bool) -> Option<Vec<&'static str>> {
    if relaxed_rendering {
        let relaxed = match token {
            "WE" | "WA" => Some(vec!["wan", "ala"]),
            "TE" | "TU" => Some(vec!["tu", "uta"]),
            "LE" | "LU" => Some(vec!["luka", "uta"]),
            "ME" | "MU" => Some(vec!["mun", "uta"]),
            "PE" | "PI" => Some(vec!["pipi", "ike"]),
            "JE" | "JO" => Some(vec!["jo", "open"]),
            _ => None,
        };
        if relaxed.is_some() {
            return relaxed;
        }
    }

    let strict = match token {
        "WA" => "WE",
        "TU" => "TE",
        "LU" => "LE",
        "MU" => "ME",
        "PI" => "PE",
        "JO" => "JE",
        other => other,
    };

    let digit_word = match strict {
        "NI" => "ijo",
        "WE" => "wan",
        "TE" => "tu",
        "SE" => "seli",
        "NA" => "awen",
        "LE" => "luka",
        "NU" => "utala",
        "ME" => "mun",
        "PE" => "pipi",
        "JE" => "jo",
        _ => return None,
    };

    if matches!(strict, "NI" | "NA" | "NU") {
        Some(vec!["nasa", digit_word])
    } else {
        Some(vec![digit_word, "esun"])
    }
}

fn rendering_start_word(result: &ParseResult, options: &ParseOptions) -> &'static str {
    if let Some(glyph) = options.numeric_cartouche_start_glyph {
        return glyph.as_str();
    }
    if let Some(glyph) = result.semantic_start_glyph {
        return glyph.as_str();
    }
    if options.nanpa_colon_rendering {
        if let Some(kind) = result.semantic_kind {
            return match kind.as_str() {
                "date" => "suno",
                "time" => "tenpo",
                _ => "nanpa",
            };
        }
    }
    "nanpa"
}

fn replace_traditional_time_separators(words: &[String]) -> Vec<String> {
    let pattern = ["nasa", "e", "kulupu", "e"];
    let replacement = ["nasa", "e", "kasi", "e"];
    let mut out = Vec::<String>::new();
    let mut index = 0usize;

    while index < words.len() {
        let matches = index + pattern.len() <= words.len()
            && pattern
                .iter()
                .enumerate()
                .all(|(offset, word)| words[index + offset] == *word);
        if matches {
            out.extend(replacement.iter().map(|word| (*word).to_string()));
            index += pattern.len();
        } else {
            out.push(words[index].clone());
            index += 1;
        }
    }
    out
}

fn word_to_codepoint(word: &str) -> Option<u32> {
    match word {
        ":" => Some(0xF199D),
        "ala" => Some(0xF1902),
        "e" => Some(0xF1909),
        "en" => Some(0xF190A),
        "esun" => Some(0xF190B),
        "ijo" => Some(0xF190C),
        "ike" => Some(0xF190D),
        "jo" => Some(0xF1913),
        "kala" => Some(0xF1914),
        "kasi" => Some(0xF1917),
        "kin" => Some(0xF1979),
        "kipisi" => Some(0xF197B),
        "kulupu" => Some(0xF191F),
        "luka" => Some(0xF192D),
        "mun" => Some(0xF193A),
        "nanpa" => Some(0xF193D),
        "nasa" => Some(0xF193E),
        "nena" => Some(0xF1940),
        "ni" => Some(0xF1941),
        "noka" => Some(0xF1943),
        "o" => Some(0xF1944),
        "ona" => Some(0xF1946),
        "open" => Some(0xF1947),
        "pipi" => Some(0xF1951),
        "seli" => Some(0xF1957),
        "suno" => Some(0xF1964),
        "tenpo" => Some(0xF196B),
        "toki" => Some(0xF196C),
        "tu" => Some(0xF196E),
        "uta" => Some(0xF1970),
        "utala" => Some(0xF1971),
        "wan" => Some(0xF1973),
        "awen" => Some(0xF1908),
        _ => None,
    }
}

fn apply_traditional_rendering(
    mut result: ParseResult,
    options: &ParseOptions,
) -> Option<ParseResult> {
    if !traditional_mode(options) || !result.is_decimal() {
        return Some(result);
    }

    let caps = result.caps.as_deref()?;
    let tokens = tokenize_caps_for_rendering(caps)?;
    let has_percent = tokens.iter().any(|token| token == "OK");
    let tokens = tokens
        .into_iter()
        .filter(|token| token != "OK")
        .collect::<Vec<_>>();

    let start_word = rendering_start_word(&result, options);
    let mut words = Vec::<String>::new();
    let mut after_starting_ne = false;
    let mut after_scientific_marker = false;
    let mut index = 0usize;

    while index < tokens.len() {
        let token = tokens[index].as_str();
        match token {
            "NE" => {
                if tokens.get(index + 1).map(String::as_str) == Some("KO") {
                    if words.is_empty() {
                        if options.nanpa_colon_rendering {
                            words.extend([start_word, ":", "kala", "open"].iter().map(|word| (*word).to_string()));
                        } else {
                            words.extend([start_word, "esun", "kala", "open"].iter().map(|word| (*word).to_string()));
                        }
                    } else {
                        words.extend(["nasa", "e", "kala", "open"].iter().map(|word| (*word).to_string()));
                    }
                    after_starting_ne = false;
                    after_scientific_marker = true;
                    index += 2;
                    continue;
                }

                after_scientific_marker = false;
                if words.is_empty() {
                    if options.nanpa_colon_rendering {
                        words.extend([start_word, ":"].iter().map(|word| (*word).to_string()));
                    } else {
                        words.extend([start_word, "esun"].iter().map(|word| (*word).to_string()));
                    }
                    after_starting_ne = true;
                } else {
                    words.extend(["nasa", "e"].iter().map(|word| (*word).to_string()));
                    after_starting_ne = false;
                }
            }
            "NS" => {
                words.extend(["nena", "en"].iter().map(|word| (*word).to_string()));
                after_starting_ne = false;
                after_scientific_marker = false;
            }
            "NI" | "WE" | "WA" | "TE" | "TU" | "SE" | "NA" | "LE" | "LU" | "NU" | "ME" | "MU" | "PE" | "PI" | "JE" | "JO" => {
                words.extend(
                    traditional_digit_words(token, options.relaxed_nanpa_linjan_rendering)?
                        .into_iter()
                        .map(str::to_string),
                );
                after_starting_ne = false;
                after_scientific_marker = false;
            }
            "NO" => {
                if after_starting_ne || after_scientific_marker {
                    words.extend(["nasa", "ona"].iter().map(|word| (*word).to_string()));
                    after_starting_ne = false;
                    after_scientific_marker = false;
                } else if tokens.get(index + 1).map(String::as_str) == Some("NE") {
                    words.extend(["ni", "o", "nasa", "e"].iter().map(|word| (*word).to_string()));
                    after_starting_ne = false;
                    index += 2;
                    continue;
                } else {
                    words.extend(["ni", "o"].iter().map(|word| (*word).to_string()));
                    after_starting_ne = false;
                }
            }
            "NONO" => {
                words.extend(["nena", "o", "nena", "o"].iter().map(|word| (*word).to_string()));
                after_starting_ne = false;
            }
            "NOKO" => {
                words.extend(["nena", "open", "kin", "open"].iter().map(|word| (*word).to_string()));
                after_starting_ne = false;
            }
            "NONONO" => {
                words.extend(["nasa", "o", "nasa", "o", "nasa", "o"].iter().map(|word| (*word).to_string()));
                after_starting_ne = false;
            }
            "KE" => {
                words.extend(["kulupu", "e"].iter().map(|word| (*word).to_string()));
                after_starting_ne = false;
            }
            "KEKE" => {
                words.extend(["kulupu", "e", "kulupu", "e"].iter().map(|word| (*word).to_string()));
                after_starting_ne = false;
            }
            "KEKEKE" => {
                words.extend(["kulupu", "e", "kulupu", "e", "kulupu", "e"].iter().map(|word| (*word).to_string()));
                after_starting_ne = false;
            }
            "N" => {
                words.push("nanpa".to_string());
                after_starting_ne = false;
            }
            _ => return None,
        }
        index += 1;
    }

    if result.is_time_like {
        words = replace_traditional_time_separators(&words);
    }

    if has_percent {
        let suffix = ["noka", "open", "kipisi", "e"];
        if let Some(position) = words.iter().rposition(|word| word == "nanpa") {
            words.splice(
                position..position,
                suffix.iter().map(|word| (*word).to_string()),
            );
        } else {
            words.extend(suffix.iter().map(|word| (*word).to_string()));
        }
    }

    let inner_codepoints = words
        .iter()
        .map(|word| word_to_codepoint(word))
        .collect::<Option<Vec<_>>>()?;

    let mut codepoints = Vec::with_capacity(inner_codepoints.len() + 2);
    codepoints.push(CARTOUCHE_START);
    codepoints.extend_from_slice(&inner_codepoints);
    codepoints.push(CARTOUCHE_END);

    result.tp_words = words.clone();
    result.words = words;
    result.ucsur_codepoints = inner_codepoints.clone();
    result.inner_codepoints = inner_codepoints.clone();
    result.codepoints = codepoints.clone();
    result.hex_codepoints = codepoints_to_hex(&inner_codepoints);
    result.hex_with_cartouche = codepoints_to_hex(&codepoints);
    result.numeric_mode = "traditional".to_string();

    Some(result)
}

pub fn parse_number(
    input: &str,
    options: &ParseOptions,
) -> Option<ParseResult> {
    if let Some(result) =
        extended::parse_extended_number(
            input,
            options,
        )
    {
        return apply_traditional_rendering(result, options);
    }

    let result = parse_decimal_number(
        input,
        options,
    )?;
    apply_traditional_rendering(result, options)
}
