use super::{codepoints_to_hex, parse_decimal_number_core};
use crate::model::{NumberKind, NumericPart, ParseResult};
use crate::options::ParseOptions;
use crate::protocol::{
    CARTOUCHE_END,
    CARTOUCHE_START,
    DecimalStartGlyph,
    SemanticKind,
};


#[derive(Debug, Clone, PartialEq, Eq)]
enum CapsToken {
    Ne,
    Ns,
    No,
    Nono,
    Noko,
    Nonono,
    Ke(usize),
    Ko,
    Ok,
    Digit(u8),
    End,
}

#[derive(Debug, Clone)]
struct DecimalBuildMeta {
    semantic_kind: Option<SemanticKind>,
    semantic_start_glyph: Option<DecimalStartGlyph>,
    display_override: Option<String>,
    yearless: bool,
}

impl Default for DecimalBuildMeta {
    fn default() -> Self {
        Self {
            semantic_kind: None,
            semantic_start_glyph: None,
            display_override: None,
            yearless: false,
        }
    }
}

fn word_codepoint(word: &str) -> Option<u32> {
    match word {
        "nanpa" => Some(0xF193D),
        "nasa" => Some(0xF193E),
        "noka" => Some(0xF1943),
        "tenpo" => Some(0xF196B),
        "suno" => Some(0xF1964),
        "toki" => Some(0xF196C),
        ":" => Some(0xF199D),
        "nena" => Some(0xF1940),
        "e" => Some(0xF1909),
        "en" => Some(0xF190A),
        "esun" => Some(0xF190B),
        "ala" => Some(0xF1902),
        "ijo" => Some(0xF190C),
        "wan" => Some(0xF1973),
        "tu" => Some(0xF196E),
        "seli" => Some(0xF1957),
        "awen" => Some(0xF1908),
        "luka" => Some(0xF192D),
        "utala" => Some(0xF1971),
        "mun" => Some(0xF193A),
        "pipi" => Some(0xF1951),
        "jo" => Some(0xF1913),
        "ona" => Some(0xF1946),
        "o" => Some(0xF1944),
        "open" => Some(0xF1947),
        "kin" => Some(0xF1979),
        "kipisi" => Some(0xF197B),
        "kulupu" => Some(0xF191F),
        "kasi" => Some(0xF1917),
        "kala" => Some(0xF1914),
        "kule" => Some(0xF191E),
        "jan" => Some(0xF1911),
        "lawa" => Some(0xF1924),
        "ma" => Some(0xF1930),
        "pakala" => Some(0xF1948),
        "sike" => Some(0xF195C),
        "tan" => Some(0xF1967),
        "ike" => Some(0xF190D),
        "uta" => Some(0xF1970),
        _ => None,
    }
}

fn words_to_codepoints(words: &[String]) -> Option<Vec<u32>> {
    words
        .iter()
        .map(|word| word_codepoint(word))
        .collect()
}

fn digit_unique(digit: u8) -> Option<char> {
    Some(match digit {
        0 => 'I',
        1 => 'W',
        2 => 'T',
        3 => 'S',
        4 => 'A',
        5 => 'L',
        6 => 'U',
        7 => 'M',
        8 => 'P',
        9 => 'J',
        _ => return None,
    })
}

fn digit_caps(digit: u8, relaxed: bool) -> Option<&'static str> {
    Some(match (digit, relaxed) {
        (0, _) => "NI",
        (1, true) => "WA",
        (1, false) => "WE",
        (2, true) => "TU",
        (2, false) => "TE",
        (3, _) => "SE",
        (4, _) => "NA",
        (5, true) => "LU",
        (5, false) => "LE",
        (6, _) => "NU",
        (7, true) => "MU",
        (7, false) => "ME",
        (8, true) => "PI",
        (8, false) => "PE",
        (9, true) => "JO",
        (9, false) => "JE",
        _ => return None,
    })
}

fn caps_pair_to_digit(pair: &str, relaxed_allowed: bool) -> Option<u8> {
    match pair {
        "NI" => Some(0),
        "WE" => Some(1),
        "TE" => Some(2),
        "SE" => Some(3),
        "NA" => Some(4),
        "LE" => Some(5),
        "NU" => Some(6),
        "ME" => Some(7),
        "PE" => Some(8),
        "JE" => Some(9),
        "WA" if relaxed_allowed => Some(1),
        "TU" if relaxed_allowed => Some(2),
        "LU" if relaxed_allowed => Some(5),
        "MU" if relaxed_allowed => Some(7),
        "PI" if relaxed_allowed => Some(8),
        "JO" if relaxed_allowed => Some(9),
        _ => None,
    }
}

fn digit_proper_syllable(digit: u8, relaxed: bool) -> Option<&'static str> {
    Some(match (digit, relaxed) {
        (0, _) => "ni",
        (1, true) => "wa",
        (1, false) => "we",
        (2, true) => "tu",
        (2, false) => "te",
        (3, _) => "se",
        (4, _) => "na",
        (5, true) => "lu",
        (5, false) => "le",
        (6, _) => "nu",
        (7, true) => "mu",
        (7, false) => "me",
        (8, true) => "pi",
        (8, false) => "pe",
        (9, true) => "jo",
        (9, false) => "je",
        _ => return None,
    })
}

fn append_digit_words(words: &mut Vec<String>, digit: u8, relaxed: bool) -> Option<()> {
    let pair: &[&str] = if relaxed {
        match digit {
            0 => &["nena", "ijo"],
            1 => &["wan", "ala"],
            2 => &["tu", "uta"],
            3 => &["seli", "e"],
            4 => &["nena", "awen"],
            5 => &["luka", "uta"],
            6 => &["nena", "utala"],
            7 => &["mun", "uta"],
            8 => &["pipi", "ike"],
            9 => &["jo", "open"],
            _ => return None,
        }
    } else {
        match digit {
            0 => &["nena", "ijo"],
            1 => &["wan", "e"],
            2 => &["tu", "e"],
            3 => &["seli", "e"],
            4 => &["nena", "awen"],
            5 => &["luka", "e"],
            6 => &["nena", "utala"],
            7 => &["mun", "e"],
            8 => &["pipi", "e"],
            9 => &["jo", "e"],
            _ => return None,
        }
    };
    words.extend(pair.iter().map(|word| (*word).to_string()));
    Some(())
}

fn normalize_minus(value: &str) -> String {
    value
        .replace('−', "-")
        .replace('‒', "-")
        .replace('–', "-")
        .replace('—', "-")
}

fn title_word(value: &str) -> String {
    let mut chars = value.chars();
    match chars.next() {
        Some(first) => format!("{}{}", first.to_ascii_uppercase(), chars.as_str()),
        None => String::new(),
    }
}

fn tokenize_caps(caps: &str, relaxed_allowed: bool) -> Option<Vec<CapsToken>> {
    let s = caps.trim().to_ascii_uppercase();
    if !s.starts_with("NE") || !s.ends_with('N') {
        return None;
    }
    let mut out = Vec::new();
    let mut index = 0usize;
    let final_index = s.len().checked_sub(1)?;
    while index < final_index {
        let rest = &s[index..final_index];
        if rest.starts_with("KEKEKE") {
            out.push(CapsToken::Ke(3));
            index += 6;
            continue;
        }
        if rest.starts_with("KEKE") {
            out.push(CapsToken::Ke(2));
            index += 4;
            continue;
        }
        if rest.starts_with("NONONO") {
            out.push(CapsToken::Nonono);
            index += 6;
            continue;
        }
        if rest.starts_with("NONO") {
            out.push(CapsToken::Nono);
            index += 4;
            continue;
        }
        if rest.starts_with("NOKO") {
            out.push(CapsToken::Noko);
            index += 4;
            continue;
        }
        if rest.starts_with("KO") {
            out.push(CapsToken::Ko);
            index += 2;
            continue;
        }
        if rest.starts_with("KE") {
            out.push(CapsToken::Ke(1));
            index += 2;
            continue;
        }
        if rest.starts_with("OK") {
            out.push(CapsToken::Ok);
            index += 2;
            continue;
        }
        if rest.starts_with("NE") {
            out.push(CapsToken::Ne);
            index += 2;
            continue;
        }
        if rest.starts_with("NS") {
            out.push(CapsToken::Ns);
            index += 2;
            continue;
        }
        if rest.starts_with("NO") {
            out.push(CapsToken::No);
            index += 2;
            continue;
        }
        if index + 2 <= final_index {
            let pair = &s[index..index + 2];
            if let Some(digit) = caps_pair_to_digit(pair, relaxed_allowed) {
                out.push(CapsToken::Digit(digit));
                index += 2;
                continue;
            }
        }
        return None;
    }
    out.push(CapsToken::End);
    Some(out)
}

fn strip_caps_body(caps: &str) -> Option<&str> {
    let value = caps.trim();
    if !value.starts_with("NE") || !value.ends_with('N') || value.len() < 3 {
        return None;
    }
    Some(&value[2..value.len() - 1])
}

fn core_caps(input: &str, options: &ParseOptions) -> Option<String> {
    parse_decimal_number_core(input, options)?.caps
}

fn replace_time_separator_words(words: &[String]) -> Vec<String> {
    let pattern = ["nena", "e", "kulupu", "e"];
    let mut out = Vec::new();
    let mut index = 0usize;
    while index < words.len() {
        if index + 4 <= words.len()
            && words[index..index + 4]
                .iter()
                .map(String::as_str)
                .eq(pattern.iter().copied())
        {
            out.extend(
                ["nena", "e", "kasi", "e"]
                    .iter()
                    .map(|word| (*word).to_string()),
            );
            index += 4;
        } else {
            out.push(words[index].clone());
            index += 1;
        }
    }
    out
}

fn start_word(meta: &DecimalBuildMeta, options: &ParseOptions) -> &'static str {
    if let Some(override_glyph) = options.numeric_cartouche_start_glyph {
        return override_glyph.as_str();
    }
    if let Some(explicit) = meta.semantic_start_glyph {
        return explicit.as_str();
    }
    if options.nanpa_colon_rendering {
        match meta.semantic_kind {
            Some(SemanticKind::Date) => "suno",
            Some(SemanticKind::Time) => "tenpo",
            None => "nanpa",
        }
    } else {
        "nanpa"
    }
}

fn tokens_to_words(
    tokens: &[CapsToken],
    meta: &DecimalBuildMeta,
    options: &ParseOptions,
) -> Option<Vec<String>> {
    if tokens.first() != Some(&CapsToken::Ne) || tokens.last() != Some(&CapsToken::End) {
        return None;
    }
    let mut out = Vec::new();
    let mut after_start = false;
    let mut after_scientific = false;
    let mut index = 0usize;
    while index < tokens.len() {
        match &tokens[index] {
            CapsToken::Ne => {
                if matches!(tokens.get(index + 1), Some(CapsToken::Ko)) {
                    if out.is_empty() {
                        out.push("nanpa".to_string());
                        if options.nanpa_colon_rendering {
                            out.push(":".to_string());
                        } else {
                            out.push("e".to_string());
                        }
                        out.push("kala".to_string());
                        out.push("open".to_string());
                    } else {
                        out.extend(
                            ["nena", "e", "kala", "open"]
                                .iter()
                                .map(|word| (*word).to_string()),
                        );
                    }
                    after_start = false;
                    after_scientific = true;
                    index += 2;
                    continue;
                }
                if out.is_empty() {
                    out.push("nanpa".to_string());
                    out.push(if options.nanpa_colon_rendering { ":" } else { "e" }.to_string());
                    after_start = true;
                } else {
                    out.extend(["nena", "e"].iter().map(|word| (*word).to_string()));
                    after_start = false;
                }
                after_scientific = false;
                index += 1;
            }
            CapsToken::Ns => {
                out.extend(["nena", "en"].iter().map(|word| (*word).to_string()));
                after_start = false;
                after_scientific = false;
                index += 1;
            }
            CapsToken::Digit(digit) => {
                append_digit_words(&mut out, *digit, options.relaxed_nanpa_linjan_rendering)?;
                after_start = false;
                after_scientific = false;
                index += 1;
            }
            CapsToken::No => {
                if after_start || after_scientific {
                    out.extend(["nena", "ona"].iter().map(|word| (*word).to_string()));
                    after_start = false;
                    after_scientific = false;
                    index += 1;
                } else if matches!(tokens.get(index + 1), Some(CapsToken::Ne)) {
                    out.extend(
                        ["nena", "o", "nena", "e"]
                            .iter()
                            .map(|word| (*word).to_string()),
                    );
                    index += 2;
                } else {
                    out.extend(["nena", "o"].iter().map(|word| (*word).to_string()));
                    index += 1;
                }
            }
            CapsToken::Nono => {
                out.extend(
                    ["nena", "o", "nena", "o"]
                        .iter()
                        .map(|word| (*word).to_string()),
                );
                index += 1;
            }
            CapsToken::Noko => {
                out.extend(
                    ["nena", "open", "kin", "open"]
                        .iter()
                        .map(|word| (*word).to_string()),
                );
                index += 1;
            }
            CapsToken::Nonono => {
                out.extend(
                    ["nena", "o", "nena", "o", "nena", "o"]
                        .iter()
                        .map(|word| (*word).to_string()),
                );
                index += 1;
            }
            CapsToken::Ke(count) => {
                for _ in 0..*count {
                    out.extend(["kulupu", "e"].iter().map(|word| (*word).to_string()));
                }
                index += 1;
            }
            CapsToken::Ko => {
                index += 1;
            }
            CapsToken::Ok => {
                index += 1;
            }
            CapsToken::End => {
                out.push("nanpa".to_string());
                index += 1;
            }
        }
    }

    if meta.semantic_kind.is_some() {
        out = replace_time_separator_words(&out);
    }

    if tokens.iter().any(|token| token == &CapsToken::Ok) {
        let insert_at = out.iter().rposition(|word| word == "nanpa").unwrap_or(out.len());
        out.splice(
            insert_at..insert_at,
            ["nena", "open", "kipisi", "e"]
                .iter()
                .map(|word| (*word).to_string()),
        );
    }

    if !out.is_empty() {
        out[0] = start_word(meta, options).to_string();
    }
    Some(out)
}

fn flush_proper_group(
    words: &mut Vec<String>,
    prefix: &mut String,
    digits: &mut Vec<u8>,
    relaxed: bool,
) -> Option<()> {
    if digits.is_empty() {
        return Some(());
    }
    let split_two = digits.len() >= 3
        && digits[digits.len() - 1] == 0
        && digits[digits.len() - 2] == 0
        && digits[digits.len() - 3] != 0;
    let first_len = if split_two { digits.len() - 2 } else { digits.len() };
    let mut value = prefix.clone();
    for digit in digits.iter().take(first_len) {
        value.push_str(digit_proper_syllable(*digit, relaxed)?);
    }
    value.push('n');
    words.push(title_word(&value));
    if split_two {
        words.push("Inin".to_string());
    }
    prefix.clear();
    digits.clear();
    Some(())
}

fn magnitude_proper_words(count: usize) -> Vec<String> {
    match count {
        0 => Vec::new(),
        1 => vec!["Eke".to_string()],
        2 => vec!["Ekeken".to_string()],
        3 => vec!["Ekekeken".to_string()],
        4 => vec!["Ekeke".to_string(), "Keken".to_string()],
        _ => {
            let mut words = Vec::new();
            for _ in 0..count.saturating_sub(1) {
                words.push("Eke".to_string());
            }
            words.push("Eken".to_string());
            words
        }
    }
}

fn tokens_to_proper_name(
    tokens: &[CapsToken],
    meta: &DecimalBuildMeta,
    options: &ParseOptions,
) -> Option<String> {
    if tokens.first() != Some(&CapsToken::Ne) || tokens.last() != Some(&CapsToken::End) {
        return None;
    }
    let relaxed = options.relaxed_nanpa_linjan_rendering;
    let mut words = Vec::<String>::new();
    let mut prefix = String::new();
    let mut digits = Vec::<u8>::new();
    let mut index = 1usize;
    let mut after_scientific = false;

    while index + 1 <= tokens.len() {
        match tokens.get(index) {
            Some(CapsToken::End) | None => break,
            Some(CapsToken::Ns) => {
                prefix.push_str("ne");
                index += 1;
            }
            Some(CapsToken::No) => {
                if digits.is_empty() && (words.is_empty() || after_scientific) {
                    prefix.push_str("no");
                    after_scientific = false;
                    index += 1;
                } else if matches!(tokens.get(index + 1), Some(CapsToken::Ne)) {
                    flush_proper_group(&mut words, &mut prefix, &mut digits, relaxed)?;
                    words.push("One".to_string());
                    index += 2;
                } else {
                    flush_proper_group(&mut words, &mut prefix, &mut digits, relaxed)?;
                    words.push("On".to_string());
                    index += 1;
                }
            }
            Some(CapsToken::Digit(digit)) => {
                digits.push(*digit);
                index += 1;
            }
            Some(CapsToken::Nono) => {
                flush_proper_group(&mut words, &mut prefix, &mut digits, relaxed)?;
                words.push("Ono".to_string());
                index += 1;
            }
            Some(CapsToken::Noko) | Some(CapsToken::Nonono) => {
                flush_proper_group(&mut words, &mut prefix, &mut digits, relaxed)?;
                words.push("Oko".to_string());
                index += 1;
            }
            Some(CapsToken::Ne) => {
                if matches!(tokens.get(index + 1), Some(CapsToken::Ko)) {
                    flush_proper_group(&mut words, &mut prefix, &mut digits, relaxed)?;
                    words.push("Eko".to_string());
                    after_scientific = true;
                    index += 2;
                } else if matches!(tokens.get(index + 1), Some(CapsToken::Ne)) {
                    flush_proper_group(&mut words, &mut prefix, &mut digits, relaxed)?;
                    words.push("Ene".to_string());
                    index += 2;
                } else if let Some(CapsToken::Ke(count)) = tokens.get(index + 1) {
                    flush_proper_group(&mut words, &mut prefix, &mut digits, relaxed)?;
                    words.extend(magnitude_proper_words(*count));
                    index += 2;
                } else {
                    index += 1;
                }
            }
            Some(CapsToken::Ke(count)) => {
                flush_proper_group(&mut words, &mut prefix, &mut digits, relaxed)?;
                words.extend(magnitude_proper_words(*count));
                index += 1;
            }
            Some(CapsToken::Ko) => {
                index += 1;
            }
            Some(CapsToken::Ok) => {
                flush_proper_group(&mut words, &mut prefix, &mut digits, relaxed)?;
                words.push("Oken".to_string());
                index += 1;
            }
        }
    }
    flush_proper_group(&mut words, &mut prefix, &mut digits, relaxed)?;
    if words.is_empty() {
        return None;
    }
    let head = match meta.semantic_start_glyph {
        Some(DecimalStartGlyph::Toki) => "Toki",
        Some(DecimalStartGlyph::Suno) => "Suno",
        _ => "Nanpa",
    };
    Some(format!("{head} {}", words.join(" ")))
}

fn tokens_to_unique(tokens: &[CapsToken], yearless: bool) -> Option<String> {
    let mut out = String::from("#~");
    if yearless {
        out.push('k');
    }
    let mut index = 1usize;
    while index < tokens.len() {
        match tokens.get(index) {
            Some(CapsToken::End) | None => break,
            Some(CapsToken::Ns) => {
                out.push('e');
                index += 1;
            }
            Some(CapsToken::Digit(digit)) => {
                out.push(digit_unique(*digit)?);
                index += 1;
            }
            Some(CapsToken::No) => {
                out.push('o');
                if matches!(tokens.get(index + 1), Some(CapsToken::Ne)) {
                    index += 2;
                } else {
                    index += 1;
                }
            }
            Some(CapsToken::Nono) => {
                out.push_str("oo");
                index += 1;
            }
            Some(CapsToken::Noko) | Some(CapsToken::Nonono) => {
                out.push_str("oko");
                index += 1;
            }
            Some(CapsToken::Ne) => {
                if matches!(tokens.get(index + 1), Some(CapsToken::Ko)) {
                    out.push_str("eko");
                    index += 2;
                } else if matches!(tokens.get(index + 1), Some(CapsToken::Ne)) {
                    out.push_str("ee");
                    index += 2;
                } else if let Some(CapsToken::Ke(count)) = tokens.get(index + 1) {
                    for _ in 0..*count {
                        out.push('k');
                    }
                    index += 2;
                } else {
                    index += 1;
                }
            }
            Some(CapsToken::Ke(count)) => {
                for _ in 0..*count {
                    out.push('k');
                }
                index += 1;
            }
            Some(CapsToken::Ko) => {
                out.push_str("ko");
                index += 1;
            }
            Some(CapsToken::Ok) => {
                out.push_str("ok");
                index += 1;
            }
        }
    }
    Some(out)
}

fn tokens_to_display(tokens: &[CapsToken]) -> Option<String> {
    let mut out = String::new();
    let mut index = 1usize;
    let mut scientific = false;
    while index < tokens.len() {
        match tokens.get(index) {
            Some(CapsToken::End) | None => break,
            Some(CapsToken::Ns) => {
                out.push('+');
                index += 1;
            }
            Some(CapsToken::Digit(digit)) => {
                out.push(char::from(b'0' + *digit));
                index += 1;
            }
            Some(CapsToken::No) => {
                if out.is_empty() || scientific {
                    out.push('-');
                    scientific = false;
                    index += 1;
                } else if matches!(tokens.get(index + 1), Some(CapsToken::Ne)) {
                    out.push('.');
                    index += 2;
                } else {
                    out.push('-');
                    index += 1;
                }
            }
            Some(CapsToken::Nono) => {
                out.push('/');
                index += 1;
            }
            Some(CapsToken::Noko) | Some(CapsToken::Nonono) => {
                out.push('+');
                index += 1;
            }
            Some(CapsToken::Ne) => {
                if matches!(tokens.get(index + 1), Some(CapsToken::Ko)) {
                    out.push('e');
                    scientific = true;
                    index += 2;
                } else if matches!(tokens.get(index + 1), Some(CapsToken::Ne)) {
                    out.push(',');
                    index += 2;
                } else if let Some(CapsToken::Ke(count)) = tokens.get(index + 1) {
                    for _ in 0..*count {
                        out.push(',');
                    }
                    index += 2;
                } else {
                    index += 1;
                }
            }
            Some(CapsToken::Ke(count)) => {
                for _ in 0..*count {
                    out.push(',');
                }
                index += 1;
            }
            Some(CapsToken::Ko) => {
                index += 1;
            }
            Some(CapsToken::Ok) => {
                out.push('%');
                index += 1;
            }
        }
    }
    Some(out)
}

fn build_decimal_from_caps(
    input: &str,
    caps: String,
    options: &ParseOptions,
    meta: DecimalBuildMeta,
) -> Option<ParseResult> {
    let tokens = tokenize_caps(&caps, true)?;
    let words = tokens_to_words(&tokens, &meta, options)?;
    let inner_codepoints = words_to_codepoints(&words)?;
    let mut codepoints = Vec::with_capacity(inner_codepoints.len() + 2);
    codepoints.push(CARTOUCHE_START);
    codepoints.extend_from_slice(&inner_codepoints);
    codepoints.push(CARTOUCHE_END);
    let proper_name = tokens_to_proper_name(&tokens, &meta, options)?;
    let unique_code = tokens_to_unique(&tokens, meta.yearless)?;
    let display_value = meta
        .display_override
        .clone()
        .or_else(|| tokens_to_display(&tokens))?;
    let is_time = meta.semantic_kind == Some(SemanticKind::Time);
    let is_date = meta.semantic_kind == Some(SemanticKind::Date);
    Some(ParseResult {
        input: input.trim().to_string(),
        caps: Some(caps),
        proper_name,
        unique_code,
        ucsur_codepoints: inner_codepoints.clone(),
        hex_codepoints: codepoints_to_hex(&inner_codepoints),
        hex_with_cartouche: codepoints_to_hex(&codepoints),
        tp_words: words.clone(),
        words,
        display_value,
        is_time,
        is_date,
        is_time_like: is_time || is_date,
        inner_codepoints,
        codepoints,
        numeric_mode: options.numeric_mode.as_str().to_string(),
        semantic_kind: meta.semantic_kind,
        semantic_start_glyph: meta.semantic_start_glyph,
        kind: None,
        number_base: None,
        is_hex: false,
        is_binary: false,
        hex_digits: None,
        binary_digits: None,
        hex_parts: None,
        binary_parts: None,
        abbreviated_ucsur_codepoints: None,
        abbreviated_words: None,
    })
}

fn build_caps_from_parts(
    parts: &[&str],
    options: &ParseOptions,
    marker: &str,
) -> Option<String> {
    let mut caps = String::from("NE");
    for (index, part) in parts.iter().enumerate() {
        let core = core_caps(part, options)?;
        let body = strip_caps_body(&core)?;
        caps.push_str(body);
        if index + 1 < parts.len() {
            caps.push_str(marker);
        }
    }
    caps.push('N');
    Some(caps)
}

fn normalize_vulgar_fraction(source: &str) -> Option<String> {
    let mut found: Option<(usize, char, u32, u32)> = None;
    let fractions: &[(char, u32, u32)] = &[
        ('¼', 1, 4), ('½', 1, 2), ('¾', 3, 4), ('⅐', 1, 7),
        ('⅑', 1, 9), ('⅒', 1, 10), ('⅓', 1, 3), ('⅔', 2, 3),
        ('⅕', 1, 5), ('⅖', 2, 5), ('⅗', 3, 5), ('⅘', 4, 5),
        ('⅙', 1, 6), ('⅚', 5, 6), ('⅛', 1, 8), ('⅜', 3, 8),
        ('⅝', 5, 8), ('⅞', 7, 8), ('↉', 0, 3),
    ];
    for (byte_index, ch) in source.char_indices() {
        if let Some((_, num, den)) = fractions.iter().find(|(symbol, _, _)| *symbol == ch) {
            if found.is_some() {
                return None;
            }
            found = Some((byte_index, ch, *num, *den));
        }
    }
    let Some((index, symbol, numerator, denominator)) = found else {
        return Some(source.replace('⁄', "/"));
    };
    let symbol_len = symbol.len_utf8();
    if index + symbol_len != source.len() {
        return None;
    }
    let before = &source[..index];
    let (sign, whole) = if let Some(rest) = before.strip_prefix('-') {
        ("-", rest)
    } else if let Some(rest) = before.strip_prefix('+') {
        ("+", rest)
    } else {
        ("", before)
    };
    if !whole.is_empty() && !whole.chars().all(|ch| ch.is_ascii_digit()) {
        return None;
    }
    if whole.is_empty() {
        Some(format!("{sign}{numerator}/{denominator}"))
    } else {
        Some(format!("{sign}{whole}+{numerator}/{denominator}"))
    }
}

fn parse_fraction(input: &str, options: &ParseOptions) -> Option<ParseResult> {
    let source = input.trim();
    let normalized = normalize_vulgar_fraction(source)?;
    if !normalized.contains('/') {
        return None;
    }
    let slash = normalized.find('/')?;
    if normalized[slash + 1..].contains('/') {
        return None;
    }
    let left = &normalized[..slash];
    let denominator = &normalized[slash + 1..];
    if denominator.is_empty() {
        return None;
    }
    let (whole, numerator, mixed) = if let Some(plus) = left.rfind('+') {
        if plus == 0 || left[plus + 1..].is_empty() {
            return None;
        }
        (Some(&left[..plus]), &left[plus + 1..], true)
    } else {
        (None, left, false)
    };
    if numerator.is_empty() {
        return None;
    }

    let mut caps = String::from("NE");
    if mixed {
        let whole = whole?;
        let whole_caps = core_caps(whole, options)?;
        caps.push_str(strip_caps_body(&whole_caps)?);
        caps.push_str("NOKO");
        let numerator_caps = core_caps(numerator, options)?;
        caps.push_str(strip_caps_body(&numerator_caps)?);
    } else {
        let numerator_caps = core_caps(numerator, options)?;
        caps.push_str(strip_caps_body(&numerator_caps)?);
    }
    caps.push_str("NONO");
    let denominator_caps = core_caps(denominator, options)?;
    caps.push_str(strip_caps_body(&denominator_caps)?);
    caps.push('N');

    let display = if mixed {
        let whole = parse_decimal_number_core(whole?, options)?.display_value;
        let num = parse_decimal_number_core(numerator, options)?.display_value;
        let den = parse_decimal_number_core(denominator, options)?.display_value;
        format!("{whole}+{num}/{den}")
    } else {
        let num = parse_decimal_number_core(numerator, options)?.display_value;
        let den = parse_decimal_number_core(denominator, options)?.display_value;
        format!("{num}/{den}")
    };

    build_decimal_from_caps(
        source,
        caps,
        options,
        DecimalBuildMeta {
            display_override: Some(display),
            ..DecimalBuildMeta::default()
        },
    )
}

fn parse_scientific(input: &str, options: &ParseOptions) -> Option<ParseResult> {
    let source = input.trim();
    let normalized = normalize_minus(source);
    let (mantissa, exponent_raw) = if let Some(index) = normalized.find(|ch| ch == 'e' || ch == 'E') {
        if normalized[index + 1..].contains(|ch| ch == 'e' || ch == 'E') {
            return None;
        }
        (&normalized[..index], &normalized[index + 1..])
    } else if let Some(index) = normalized.find("*10^") {
        (&normalized[..index], &normalized[index + 4..])
    } else if let Some(index) = normalized.find("*10+") {
        (&normalized[..index], &normalized[index + 3..])
    } else if let Some(index) = normalized.find("*10-") {
        (&normalized[..index], &normalized[index + 3..])
    } else {
        return None;
    };
    if mantissa.is_empty() || exponent_raw.is_empty() {
        return None;
    }
    let (exp_negative, exponent) = if let Some(rest) = exponent_raw.strip_prefix('-') {
        (true, rest)
    } else if let Some(rest) = exponent_raw.strip_prefix('+') {
        (false, rest)
    } else {
        (false, exponent_raw)
    };
    if exponent.is_empty() || !exponent.chars().all(|ch| ch.is_ascii_digit()) {
        return None;
    }
    let mantissa_caps = core_caps(mantissa, options)?;
    let exponent_caps = core_caps(exponent, options)?;
    let mut caps = String::from("NE");
    caps.push_str(strip_caps_body(&mantissa_caps)?);
    caps.push_str("NEKO");
    if exp_negative {
        caps.push_str("NO");
    }
    caps.push_str(strip_caps_body(&exponent_caps)?);
    caps.push('N');
    let mantissa_display = parse_decimal_number_core(mantissa, options)?.display_value;
    let display = format!(
        "{}e{}{}",
        mantissa_display,
        if exp_negative { "-" } else { "" },
        exponent,
    );
    build_decimal_from_caps(
        source,
        caps,
        options,
        DecimalBuildMeta {
            display_override: Some(display),
            ..DecimalBuildMeta::default()
        },
    )
}

fn parse_two_digits(value: &str, max: u32) -> bool {
    value.len() == 2
        && value.chars().all(|ch| ch.is_ascii_digit())
        && value.parse::<u32>().ok().is_some_and(|number| number <= max)
}

fn parse_time(input: &str, options: &ParseOptions) -> Option<ParseResult> {
    let source = input.trim();
    if !source.contains(':') {
        return None;
    }
    let normalized = normalize_minus(source);
    let signed = normalized.starts_with('-') || normalized.starts_with('+');
    let sign_char = normalized.chars().next().filter(|ch| *ch == '-' || *ch == '+');
    let unsigned = if signed { &normalized[1..] } else { normalized.as_str() };
    let parts: Vec<&str> = unsigned.split(':').collect();
    let mut segments: Vec<String> = Vec::new();
    let mut fraction: Option<String> = None;
    let mut keep_negative = sign_char == Some('-');

    match parts.len() {
        2 => {
            if signed {
                return None;
            }
            if parts[0].is_empty()
                || parts[0].len() > 2
                || !parts[0].chars().all(|ch| ch.is_ascii_digit())
                || parts[0].parse::<u32>().ok()? > 59
                || !parse_two_digits(parts[1], 59)
            {
                return None;
            }
            segments.push(parts[0].to_string());
            segments.push(parts[1].to_string());
        }
        3 => {
            if let Some(dot) = parts[2].find('.') {
                if signed {
                    return None;
                }
                let seconds = &parts[2][..dot];
                let frac = &parts[2][dot + 1..];
                if parts[0].is_empty()
                    || parts[0].len() > 2
                    || !parts[0].chars().all(|ch| ch.is_ascii_digit())
                    || parts[0].parse::<u32>().ok()? > 59
                    || !parse_two_digits(parts[1], 59)
                    || !parse_two_digits(seconds, 59)
                    || frac.is_empty()
                    || frac.len() > 3
                    || !frac.chars().all(|ch| ch.is_ascii_digit())
                {
                    return None;
                }
                segments.extend([parts[0].to_string(), parts[1].to_string(), seconds.to_string()]);
                fraction = Some(frac.to_string());
                keep_negative = false;
            } else {
                if parts[0].is_empty()
                    || !parts[0].chars().all(|ch| ch.is_ascii_digit())
                    || !parse_two_digits(parts[1], 59)
                    || !parse_two_digits(parts[2], 59)
                {
                    return None;
                }
                segments.extend(parts.iter().map(|part| (*part).to_string()));
                let all_zero = segments.iter().all(|segment| segment.chars().all(|ch| ch == '0'));
                if all_zero {
                    keep_negative = false;
                }
            }
        }
        4 => {
            if parts[0].is_empty()
                || !parts[0].chars().all(|ch| ch.is_ascii_digit())
                || !parse_two_digits(parts[1], 59)
                || !parse_two_digits(parts[2], 59)
            {
                return None;
            }
            let (seconds, frac) = if let Some(dot) = parts[3].find('.') {
                let seconds = &parts[3][..dot];
                let frac = &parts[3][dot + 1..];
                if frac.is_empty() || frac.len() > 3 || !frac.chars().all(|ch| ch.is_ascii_digit()) {
                    return None;
                }
                (seconds, Some(frac))
            } else {
                (parts[3], None)
            };
            if !parse_two_digits(seconds, 59) {
                return None;
            }
            segments.extend([parts[0].to_string(), parts[1].to_string(), parts[2].to_string(), seconds.to_string()]);
            fraction = frac.map(str::to_string);
            let all_zero = segments.iter().all(|segment| segment.chars().all(|ch| ch == '0'))
                && fraction.as_ref().is_none_or(|value| value.chars().all(|ch| ch == '0'));
            if all_zero {
                keep_negative = false;
            }
        }
        _ => return None,
    }

    let mut caps = String::from("NE");
    if keep_negative {
        caps.push_str("NO");
    }
    for (index, segment) in segments.iter().enumerate() {
        let segment_caps = core_caps(segment, options)?;
        caps.push_str(strip_caps_body(&segment_caps)?);
        if index + 1 < segments.len() {
            caps.push_str("NEKE");
        }
    }
    if let Some(frac) = &fraction {
        caps.push_str("NONE");
        let frac_caps = core_caps(frac, options)?;
        caps.push_str(strip_caps_body(&frac_caps)?);
    }
    caps.push('N');

    let mut display = String::new();
    if keep_negative {
        display.push('-');
    }
    display.push_str(&segments.join(","));
    if let Some(frac) = fraction {
        display.push('.');
        display.push_str(&frac);
    }
    build_decimal_from_caps(
        source,
        caps,
        options,
        DecimalBuildMeta {
            semantic_kind: Some(SemanticKind::Time),
            display_override: Some(display),
            ..DecimalBuildMeta::default()
        },
    )
}

fn valid_yearless_date(month: &str, day: &str) -> bool {
    if month.len() != 2
        || day.len() != 2
        || !month.chars().all(|ch| ch.is_ascii_digit())
        || !day.chars().all(|ch| ch.is_ascii_digit())
    {
        return false;
    }
    let month_number = match month.parse::<usize>() {
        Ok(value) => value,
        Err(_) => return false,
    };
    let day_number = match day.parse::<usize>() {
        Ok(value) => value,
        Err(_) => return false,
    };
    let max_days = [0usize, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    (1..=12).contains(&month_number)
        && day_number >= 1
        && day_number <= max_days[month_number]
}

fn parse_date(input: &str, options: &ParseOptions) -> Option<ParseResult> {
    let source = input.trim();
    if let Some(rest) = source.strip_prefix("--") {
        let parts: Vec<&str> = rest.split('-').collect();
        if parts.len() == 2 && valid_yearless_date(parts[0], parts[1]) {
            let caps = build_caps_from_parts(&parts, options, "NEKE")?;
            return build_decimal_from_caps(
                source,
                caps,
                options,
                DecimalBuildMeta {
                    semantic_kind: Some(SemanticKind::Date),
                    display_override: Some(format!("--{}-{}", parts[0], parts[1])),
                    yearless: true,
                    ..DecimalBuildMeta::default()
                },
            );
        }
    }
    if let Some(rest) = source.strip_prefix("XXXX-") {
        let parts: Vec<&str> = rest.split('-').collect();
        if parts.len() == 2 && valid_yearless_date(parts[0], parts[1]) {
            let caps = build_caps_from_parts(&parts, options, "NEKE")?;
            return build_decimal_from_caps(
                source,
                caps,
                options,
                DecimalBuildMeta {
                    semantic_kind: Some(SemanticKind::Date),
                    display_override: Some(format!("--{}-{}", parts[0], parts[1])),
                    yearless: true,
                    ..DecimalBuildMeta::default()
                },
            );
        }
    }

    let separator = if source.contains('/') { '/' } else { '-' };
    let parts: Vec<&str> = source.split(separator).collect();
    if parts.len() != 3
        || parts[0].len() != 4
        || parts[1].len() != 2
        || parts[2].len() != 2
        || !parts.iter().all(|part| part.chars().all(|ch| ch.is_ascii_digit()))
    {
        return None;
    }
    let month = parts[1].parse::<u32>().ok()?;
    let day = parts[2].parse::<u32>().ok()?;
    if !(1..=12).contains(&month) || !(1..=31).contains(&day) {
        return None;
    }
    let caps = build_caps_from_parts(&parts, options, "NEKE")?;
    build_decimal_from_caps(
        source,
        caps,
        options,
        DecimalBuildMeta {
            semantic_kind: Some(SemanticKind::Date),
            display_override: Some(parts.join(",")),
            ..DecimalBuildMeta::default()
        },
    )
}

fn parse_grouped_loose(input: &str, options: &ParseOptions) -> Option<ParseResult> {
    let source = input.trim();
    if source.contains(':') || source.contains('/') || source.starts_with('#') || source.starts_with('[') {
        return None;
    }
    if !source.contains('-') {
        return None;
    }
    let normalized = normalize_minus(source);
    let (sign, rest) = if let Some(rest) = normalized.strip_prefix("--") {
        (Some('-'), rest)
    } else if let Some(rest) = normalized.strip_prefix('+') {
        (Some('+'), rest)
    } else if let Some(rest) = normalized.strip_prefix('-') {
        (Some('-'), rest)
    } else {
        (None, normalized.as_str())
    };
    let groups: Vec<&str> = rest.split('-').collect();
    if groups.len() < 2
        || groups.iter().any(|group| group.is_empty() || !group.chars().all(|ch| ch.is_ascii_digit()))
    {
        return None;
    }
    let first_source = match sign {
        Some('+') => format!("+{}", groups[0]),
        Some('-') => format!("-{}", groups[0]),
        _ => groups[0].to_string(),
    };
    let mut caps = String::from("NE");
    let first_caps = core_caps(&first_source, options)?;
    caps.push_str(strip_caps_body(&first_caps)?);
    for group in groups.iter().skip(1) {
        caps.push_str("NENE");
        let group_caps = core_caps(group, options)?;
        caps.push_str(strip_caps_body(&group_caps)?);
    }
    caps.push('N');
    let mut display = String::new();
    if let Some(sign) = sign {
        display.push(sign);
    }
    display.push_str(&groups.join(","));
    build_decimal_from_caps(
        source,
        caps,
        options,
        DecimalBuildMeta {
            display_override: Some(display),
            ..DecimalBuildMeta::default()
        },
    )
}

fn parse_number_code(input: &str, options: &ParseOptions) -> Option<ParseResult> {
    let source = input.trim();
    let body = source.strip_prefix("#~")?;
    if body.is_empty() || body.chars().any(|ch| ch.is_whitespace()) {
        return None;
    }
    let mut caps = String::from("NE");
    let chars: Vec<char> = body.chars().collect();
    let mut index = 0usize;
    if chars.first().is_some_and(|ch| *ch == 'e' || *ch == 'E') {
        if chars.len() < 2 || !matches!(chars[1].to_ascii_uppercase(), 'I'|'W'|'T'|'S'|'A'|'L'|'U'|'M'|'P'|'J') {
            return None;
        }
        caps.push_str("NS");
        index = 1;
    }
    while index < chars.len() {
        let ch = chars[index];
        let upper = ch.to_ascii_uppercase();
        let digit = match upper {
            'I' => Some(0), 'W' => Some(1), 'T' => Some(2), 'S' => Some(3), 'A' => Some(4),
            'L' => Some(5), 'U' => Some(6), 'M' => Some(7), 'P' => Some(8), 'J' => Some(9),
            _ => None,
        };
        if let Some(digit) = digit {
            caps.push_str(digit_caps(digit, false)?);
            index += 1;
            continue;
        }
        if upper == 'K' {
            let mut count = 0usize;
            while index < chars.len() && chars[index].eq_ignore_ascii_case(&'k') {
                count += 1;
                index += 1;
            }
            caps.push_str("NE");
            for _ in 0..count {
                caps.push_str("KE");
            }
            continue;
        }
        if upper == 'O' {
            let mut count = 0usize;
            while index < chars.len() && chars[index].eq_ignore_ascii_case(&'o') {
                count += 1;
                index += 1;
            }
            match count {
                1 if index == count => caps.push_str("NO"),
                1 => caps.push_str("NONE"),
                2 => caps.push_str("NONO"),
                3 => caps.push_str("NOKO"),
                _ => return None,
            }
            continue;
        }
        return None;
    }
    caps.push('N');
    build_decimal_from_caps(source, caps, options, DecimalBuildMeta::default())
}

fn parse_proper_numeric_word(
    word: &str,
    first_numeric_word: bool,
    relaxed_allowed: bool,
) -> Option<String> {
    if word.len() < 2 || !word.ends_with('n') {
        return None;
    }
    let mut core = word[..word.len() - 1].to_ascii_lowercase();
    let mut out = String::new();
    if first_numeric_word && core.starts_with("ne") && core.len() > 2 {
        out.push_str("NS");
        core.drain(..2);
    } else if first_numeric_word && core.starts_with("no") && core.len() > 2 {
        out.push_str("NO");
        core.drain(..2);
    }
    while !core.is_empty() {
        if core.len() < 2 {
            return None;
        }
        let pair = core[..2].to_ascii_uppercase();
        caps_pair_to_digit(&pair, relaxed_allowed)?;
        out.push_str(&pair);
        core.drain(..2);
    }
    Some(out)
}

fn proper_words_to_caps(
    words: &[&str],
    relaxed_allowed: bool,
) -> Option<String> {
    if words.is_empty() {
        return None;
    }
    let mut caps = String::from("NE");
    let mut numeric_seen = false;
    for word in words {
        let lower = word.to_ascii_lowercase();
        match lower.as_str() {
            "ene" => caps.push_str("NENE"),
            "eke" => caps.push_str("NEKE"),
            "one" => caps.push_str("NONE"),
            "ono" => caps.push_str("NONO"),
            "oko" => caps.push_str("NOKO"),
            "eko" => caps.push_str("NEKO"),
            "oken" => caps.push_str("OK"),
            _ => {
                let fragment = parse_proper_numeric_word(
                    &lower,
                    !numeric_seen,
                    relaxed_allowed,
                )?;
                caps.push_str(&fragment);
                numeric_seen = true;
            }
        }
    }
    if !numeric_seen {
        return None;
    }
    caps.push('N');
    tokenize_caps(&caps, relaxed_allowed)?;
    Some(caps)
}

fn legacy_proper_name_to_caps(
    source: &str,
    relaxed_allowed: bool,
) -> Option<String> {
    let source = source.trim();
    if source.is_empty() {
        return None;
    }

    if source
        .split_whitespace()
        .any(|word| word.is_empty() || !word.chars().all(|ch| ch.is_ascii_alphabetic()))
    {
        return None;
    }

    let compact: String = source.split_whitespace().collect();
    let final_char = compact.chars().last()?;
    if final_char != 'n' && final_char != 'N' {
        return None;
    }

    let mut core = compact[..compact.len() - 1].to_string();
    if core.len() < 2 || core.len() % 2 != 0 {
        return None;
    }

    let mut has_percent = false;
    if core.to_ascii_lowercase().ends_with("noke") {
        has_percent = true;
        core.truncate(core.len() - 4);
        if core.len() < 2 || core.len() % 2 != 0 {
            return None;
        }
    }

    let mut core_caps = core.to_ascii_uppercase();
    if !core_caps.starts_with("NE") {
        return None;
    }

    /*
     * Legacy unheaded proper names reserve the first "Ne" as the
     * numeric-name opener.  It is NOT the positive sign by itself:
     *
     *   Newan   -> NEWAN   -> 1
     *   Newen   -> NEWEN   -> 1 (strict)
     *
     * Only a contiguous mixed/title-case "Nene..." is the explicit
     * leading plus form:
     *
     *   Nenewan -> NENSWAN -> +1
     *   Nene Wan -> NENSWAN -> +1
     *
     * All-uppercase NENE... is handled earlier as raw CAPS input and
     * therefore keeps its historical raw-CAPS meaning.
     */
    let is_all_upper = source
        .chars()
        .filter(|ch| ch.is_ascii_alphabetic())
        .all(|ch| !ch.is_ascii_lowercase());

    if source.to_ascii_lowercase().starts_with("nene")
        && !is_all_upper
        && core_caps.starts_with("NENE")
    {
        core_caps = format!("NENS{}", &core_caps[4..]);
    }

    let caps = if has_percent {
        format!("{core_caps}OKN")
    } else {
        format!("{core_caps}N")
    };

    tokenize_caps(&caps, relaxed_allowed)?;
    Some(caps)
}

fn parse_proper_name(input: &str, options: &ParseOptions) -> Option<ParseResult> {
    let source = input.trim();
    let words: Vec<&str> = source.split_whitespace().collect();
    if words.is_empty() {
        return None;
    }

    let (head, body) = match words[0] {
        "Nanpa" | "Toki" | "Tenpo" | "Suno" if options.nanpa_colon_parsing => {
            if words.len() < 2 {
                return None;
            }
            (Some(words[0]), &words[1..])
        }
        _ => (None, words.as_slice()),
    };

    let caps = match head {
        None => legacy_proper_name_to_caps(
            source,
            options.relaxed_nanpa_linjan_parsing,
        )?,
        Some(_) => proper_words_to_caps(
            body,
            options.relaxed_nanpa_linjan_parsing,
        )?,
    };
    let tokens = tokenize_caps(&caps, true)?;
    let display = tokens_to_display(&tokens)?;

    match head {
        Some("Toki") => build_decimal_from_caps(
            source,
            caps,
            options,
            DecimalBuildMeta {
                semantic_start_glyph: Some(DecimalStartGlyph::Toki),
                display_override: Some(display),
                ..DecimalBuildMeta::default()
            },
        ),
        Some("Tenpo") => {
            if !display.contains(',') {
                return None;
            }
            build_decimal_from_caps(
                source,
                caps,
                options,
                DecimalBuildMeta {
                    semantic_kind: Some(SemanticKind::Time),
                    display_override: Some(display),
                    ..DecimalBuildMeta::default()
                },
            )
        }
        Some("Suno") => {
            if !display.contains(',') {
                let value = display.parse::<u32>().ok()?;
                if !(1..=31).contains(&value) {
                    return None;
                }
                build_decimal_from_caps(
                    source,
                    caps,
                    options,
                    DecimalBuildMeta {
                        semantic_start_glyph: Some(DecimalStartGlyph::Suno),
                        display_override: Some(display),
                        ..DecimalBuildMeta::default()
                    },
                )
            } else {
                let groups: Vec<&str> = display.split(',').collect();
                if groups.len() == 2 && valid_yearless_date(groups[0], groups[1]) {
                    build_decimal_from_caps(
                        source,
                        caps,
                        options,
                        DecimalBuildMeta {
                            semantic_kind: Some(SemanticKind::Date),
                            display_override: Some(format!("--{}-{}", groups[0], groups[1])),
                            yearless: true,
                            ..DecimalBuildMeta::default()
                        },
                    )
                } else if groups.len() == 3 {
                    build_decimal_from_caps(
                        source,
                        caps,
                        options,
                        DecimalBuildMeta {
                            semantic_kind: Some(SemanticKind::Date),
                            display_override: Some(display),
                            ..DecimalBuildMeta::default()
                        },
                    )
                } else {
                    None
                }
            }
        }
        Some("Nanpa") | None => build_decimal_from_caps(
            source,
            caps,
            options,
            DecimalBuildMeta {
                display_override: Some(display),
                ..DecimalBuildMeta::default()
            },
        ),
        _ => None,
    }
}

fn tokenize_bracket_words(source: &str) -> Option<Vec<String>> {
    let value = source.trim();
    if !value.starts_with('[') || !value.ends_with(']') {
        return None;
    }
    let inner = &value[1..value.len() - 1];
    let mut tokens = Vec::new();
    let mut current = String::new();
    for ch in inner.chars() {
        if ch.is_ascii_alphabetic() {
            current.push(ch.to_ascii_lowercase());
        } else if ch == ':' {
            if !current.is_empty() {
                tokens.push(std::mem::take(&mut current));
            }
            tokens.push(":".to_string());
        } else if ch.is_whitespace() {
            if !current.is_empty() {
                tokens.push(std::mem::take(&mut current));
            }
        } else {
            return None;
        }
    }
    if !current.is_empty() {
        tokens.push(current);
    }
    Some(tokens)
}

fn abbreviated_word_digit(word: &str) -> Option<u8> {
    match word {
        "ijo" => Some(0), "wan" => Some(1), "tu" => Some(2), "seli" => Some(3),
        "awen" => Some(4), "luka" => Some(5), "utala" => Some(6), "mun" => Some(7),
        "pipi" => Some(8), "jo" => Some(9), _ => None,
    }
}

fn full_pair_digit(a: &str, b: &str, relaxed: bool) -> Option<u8> {
    let pairs: &[(&str, &str, u8)] = if relaxed {
        &[
            ("nena","ijo",0),("wan","ala",1),("tu","uta",2),("seli","e",3),("nena","awen",4),
            ("luka","uta",5),("nena","utala",6),("mun","uta",7),("pipi","ike",8),("jo","open",9),
            ("wan","e",1),("tu","e",2),("luka","e",5),("mun","e",7),("pipi","e",8),("jo","e",9),
        ]
    } else {
        &[
            ("nena","ijo",0),("wan","e",1),("tu","e",2),("seli","e",3),("nena","awen",4),
            ("luka","e",5),("nena","utala",6),("mun","e",7),("pipi","e",8),("jo","e",9),
        ]
    };
    pairs.iter().find_map(|(x,y,digit)| (*x == a && *y == b).then_some(*digit))
}

fn parse_typed_decimal_cartouche(input: &str, options: &ParseOptions) -> Option<ParseResult> {
    if !options.nanpa_colon_parsing && !options.nanpa_colon_rendering {
        return None;
    }
    let tokens = tokenize_bracket_words(input)?;
    if tokens.len() < 3 {
        return None;
    }
    let head = tokens.first()?.as_str();
    if !matches!(head, "nanpa" | "tenpo" | "suno" | "toki") || tokens.last()?.as_str() != "nanpa" {
        return None;
    }
    let has_colon = tokens.get(1).is_some_and(|token| token == ":");
    if !has_colon && head != "suno" {
        return None;
    }
    let body_start = if has_colon { 2 } else { 1 };
    let body = &tokens[body_start..tokens.len() - 1];
    if body.is_empty() || body.iter().any(|word| word == "nanpa" || word == "nasin") {
        return None;
    }

    let mut abbrev_caps = String::from("NE");
    let mut abbrev_index = 0usize;
    let mut abbrev_ok = true;
    let mut has_digit = false;
    if body.first().is_some_and(|word| word == "en") {
        abbrev_caps.push_str("NS");
        abbrev_index = 1;
    }
    while abbrev_index < body.len() && abbrev_ok {
        let word = body[abbrev_index].as_str();
        if let Some(digit) = abbreviated_word_digit(word) {
            abbrev_caps.push_str(digit_caps(digit, false)?);
            has_digit = true;
        } else {
            match word {
                "e" => abbrev_caps.push_str("NENE"),
                "o" | "ona" => abbrev_caps.push_str("NO"),
                "kulupu" | "kasi" | "kolon" | ":" => abbrev_caps.push_str("NEKE"),
                "kala" => abbrev_caps.push_str("NEKO"),
                "kin" => abbrev_caps.push_str("NOKO"),
                "kipisi" if abbrev_index + 1 == body.len() => abbrev_caps.push_str("OK"),
                _ => abbrev_ok = false,
            }
        }
        abbrev_index += 1;
    }
    abbrev_caps.push('N');
    if !has_digit {
        abbrev_ok = false;
    }

    let mut full_caps = String::from("NE");
    let mut full_index = 0usize;
    let mut full_ok = true;
    let mut full_has_digit = false;
    if body.len() >= 2 && body[0] == "nena" && body[1] == "en" {
        full_caps.push_str("NS");
        full_index = 2;
    }
    while full_index < body.len() && full_ok {
        if full_index + 1 < body.len() {
            if let Some(digit) = full_pair_digit(
                body[full_index].as_str(),
                body[full_index + 1].as_str(),
                options.relaxed_nanpa_linjan_parsing,
            ) {
                let relaxed_pair = matches!(
                    (body[full_index].as_str(), body[full_index + 1].as_str()),
                    ("wan","ala")|("tu","uta")|("luka","uta")|("mun","uta")|("pipi","ike")|("jo","open")
                );
                full_caps.push_str(digit_caps(digit, relaxed_pair)?);
                full_has_digit = true;
                full_index += 2;
                continue;
            }
        }
        if full_index + 3 < body.len()
            && body[full_index] == "nena"
            && body[full_index + 1] == "e"
            && body[full_index + 2] == "nena"
            && body[full_index + 3] == "e"
        {
            full_caps.push_str("NENE");
            full_index += 4;
            continue;
        }
        if full_index + 3 < body.len()
            && body[full_index] == "nena"
            && body[full_index + 1] == "e"
            && matches!(body[full_index + 2].as_str(), "kulupu" | "kasi")
            && body[full_index + 3] == "e"
        {
            full_caps.push_str("NEKE");
            full_index += 4;
            continue;
        }
        if full_index + 3 < body.len()
            && body[full_index] == "nena"
            && body[full_index + 1] == "o"
            && body[full_index + 2] == "nena"
            && body[full_index + 3] == "e"
        {
            full_caps.push_str("NONE");
            full_index += 4;
            continue;
        }
        full_ok = false;
    }
    full_caps.push('N');
    if !full_has_digit {
        full_ok = false;
    }

    let caps = if full_ok { full_caps } else if abbrev_ok { abbrev_caps } else { return None };
    let generic_tokens = tokenize_caps(&caps, true)?;
    let generic_display = tokens_to_display(&generic_tokens)?;
    let meta = match head {
        "toki" => DecimalBuildMeta {
            semantic_start_glyph: Some(DecimalStartGlyph::Toki),
            display_override: Some(generic_display),
            ..DecimalBuildMeta::default()
        },
        "tenpo" => {
            if !generic_display.contains(',') {
                return None;
            }
            DecimalBuildMeta {
                semantic_kind: Some(SemanticKind::Time),
                display_override: Some(generic_display),
                ..DecimalBuildMeta::default()
            }
        }
        "suno" => {
            if generic_display.contains(',') {
                let parts: Vec<&str> = generic_display.split(',').collect();
                if parts.len() == 2 && valid_yearless_date(parts[0], parts[1]) {
                    DecimalBuildMeta {
                        semantic_kind: Some(SemanticKind::Date),
                        display_override: Some(format!("--{}-{}", parts[0], parts[1])),
                        yearless: true,
                        ..DecimalBuildMeta::default()
                    }
                } else if parts.len() == 3 {
                    DecimalBuildMeta {
                        semantic_kind: Some(SemanticKind::Date),
                        display_override: Some(generic_display),
                        ..DecimalBuildMeta::default()
                    }
                } else {
                    return None;
                }
            } else {
                let value = generic_display.parse::<u32>().ok()?;
                if !(1..=31).contains(&value) {
                    return None;
                }
                DecimalBuildMeta {
                    semantic_start_glyph: Some(DecimalStartGlyph::Suno),
                    display_override: Some(generic_display),
                    ..DecimalBuildMeta::default()
                }
            }
        }
        _ => DecimalBuildMeta {
            display_override: Some(generic_display),
            ..DecimalBuildMeta::default()
        },
    };
    build_decimal_from_caps(input, caps, options, meta)
}

fn parse_caps_identifier(input: &str, options: &ParseOptions) -> Option<ParseResult> {
    let source = input.trim();
    if source.len() < 3 || source != source.to_ascii_uppercase() || !source.starts_with("NE") || !source.ends_with('N') {
        return None;
    }
    tokenize_caps(source, options.relaxed_nanpa_linjan_parsing)?;
    build_decimal_from_caps(source, source.to_string(), options, DecimalBuildMeta::default())
}

#[derive(Debug, Clone)]
struct BasePart {
    digits: Option<String>,
    delimiter: Option<char>,
}

fn parts_digits(parts: &[BasePart]) -> String {
    parts
        .iter()
        .filter_map(|part| part.digits.as_deref())
        .collect::<Vec<_>>()
        .join("")
}

fn base_codepoints(words: &[String]) -> Option<(Vec<u32>, Vec<u32>, String, String)> {
    let inner = words_to_codepoints(words)?;
    let mut all = Vec::with_capacity(inner.len() + 2);
    all.push(CARTOUCHE_START);
    all.extend_from_slice(&inner);
    all.push(CARTOUCHE_END);
    let hex_inner = codepoints_to_hex(&inner);
    let hex_all = codepoints_to_hex(&all);
    Some((inner, all, hex_inner, hex_all))
}

fn binary_run_proper(run: &str, relaxed: bool) -> Option<String> {
    let mut value = String::new();
    for ch in run.chars() {
        value.push_str(match ch {
            '0' => "ni",
            '1' if relaxed => "wa",
            '1' => "we",
            _ => return None,
        });
    }
    Some(title_word(&value))
}

fn binary_words(parts: &[BasePart], abbreviated: bool, relaxed: bool) -> Option<Vec<String>> {
    let mut words = vec!["noka".to_string(), ":".to_string()];
    for part in parts {
        if let Some(run) = &part.digits {
            for ch in run.chars() {
                let digit = ch.to_digit(2)? as u8;
                if abbreviated {
                    words.push(if digit == 0 { "ijo" } else { "wan" }.to_string());
                } else {
                    append_digit_words(&mut words, digit, relaxed)?;
                }
            }
        } else {
            words.extend(
                if abbreviated { vec!["e".to_string()] }
                else { vec!["nena".to_string(),"e".to_string(),"nena".to_string(),"e".to_string()] },
            );
        }
    }
    words.push("noka".to_string());
    Some(words)
}

fn build_binary_result(input: &str, parts: Vec<BasePart>, options: &ParseOptions) -> Option<ParseResult> {
    let digits = parts_digits(&parts);
    if digits.is_empty() {
        return None;
    }
    let mut proper_words = vec!["Noka".to_string()];
    for part in &parts {
        if let Some(run) = &part.digits {
            proper_words.push(binary_run_proper(run, options.relaxed_nanpa_linjan_rendering)?);
        } else {
            if let Some(last) = proper_words.last_mut() {
                last.push('n');
            }
            proper_words.push("Ene".to_string());
        }
    }
    proper_words.last_mut()?.push('n');
    let proper_name = proper_words.join(" ");
    let full_words = binary_words(&parts, false, options.relaxed_nanpa_linjan_rendering)?;
    let abbreviated_words = binary_words(&parts, true, options.relaxed_nanpa_linjan_rendering)?;
    let (inner, codepoints, hex_codepoints, hex_with_cartouche) = base_codepoints(&full_words)?;
    let abbreviated_ucsur_codepoints = words_to_codepoints(&abbreviated_words)?;
    let mut canonical = String::from("0b");
    for part in &parts {
        if let Some(run) = &part.digits {
            canonical.push_str(run);
        } else {
            canonical.push(part.delimiter.unwrap_or(':'));
        }
    }
    let binary_parts = Some(parts.iter().map(|part| {
        if let Some(run) = &part.digits {
            NumericPart::Digits(run.clone())
        } else {
            NumericPart::Delimiter(part.delimiter.unwrap_or('\0'))
        }
    }).collect());
    Some(ParseResult {
        input: input.trim().to_string(),
        caps: None,
        proper_name,
        unique_code: canonical.clone(),
        ucsur_codepoints: inner.clone(),
        hex_codepoints,
        hex_with_cartouche,
        tp_words: full_words.clone(),
        words: full_words,
        display_value: canonical,
        is_time: false,
        is_date: false,
        is_time_like: false,
        inner_codepoints: inner,
        codepoints,
        numeric_mode: options.numeric_mode.as_str().to_string(),
        semantic_kind: None,
        semantic_start_glyph: None,
        kind: Some(NumberKind::Binary),
        number_base: Some(2),
        is_hex: false,
        is_binary: true,
        hex_digits: None,
        binary_digits: Some(digits),
        hex_parts: None,
        binary_parts,
        abbreviated_ucsur_codepoints: Some(abbreviated_ucsur_codepoints),
        abbreviated_words: Some(abbreviated_words),
    })
}

fn parse_binary(input: &str, options: &ParseOptions) -> Option<ParseResult> {
    if !options.enable_binary_parsing {
        return None;
    }
    let source = input.trim();
    if let Some(body) = source.strip_prefix("0b") {
        if body.is_empty() || !matches!(body.chars().next(), Some('0'|'1')) {
            return None;
        }
        let mut parts = Vec::<BasePart>::new();
        let mut run = String::new();
        for ch in body.chars() {
            if matches!(ch, '0'|'1') {
                run.push(ch);
            } else {
                if ch.is_whitespace() || ch.is_ascii_alphabetic() || matches!(ch, '2'..='9') {
                    return None;
                }
                if !run.is_empty() {
                    parts.push(BasePart { digits: Some(std::mem::take(&mut run)), delimiter: None });
                }
                parts.push(BasePart { digits: None, delimiter: Some(ch) });
            }
        }
        if !run.is_empty() {
            parts.push(BasePart { digits: Some(run), delimiter: None });
        }
        if parts.first().is_none_or(|part| part.digits.is_none()) {
            return None;
        }
        return build_binary_result(source, parts, options);
    }
    if source.starts_with('[') && source.ends_with(']') {
        let tokens = tokenize_bracket_words(source)?;
        if tokens.len() < 4 || tokens[0] != "noka" || tokens.last()? != "noka" {
            return None;
        }
        let start = if tokens.get(1).is_some_and(|token| token == ":") { 2 } else { 1 };
        let body = &tokens[start..tokens.len() - 1];
        let mut run = String::new();
        for word in body {
            match word.as_str() {
                "ijo" => run.push('0'),
                "wan" => run.push('1'),
                _ => return None,
            }
        }
        if run.is_empty() {
            return None;
        }
        return build_binary_result(source, vec![BasePart { digits: Some(run), delimiter: None }], options);
    }
    if source.starts_with("Noka ") {
        let compact: String = source.split_whitespace().collect();
        if !compact.to_ascii_lowercase().starts_with("noka") || !compact.ends_with('n') {
            return None;
        }
        let mut body = compact[4..compact.len() - 1].to_ascii_uppercase();
        let mut parts = Vec::<BasePart>::new();
        let mut run = String::new();
        while !body.is_empty() {
            if body.starts_with("NENE") {
                if run.is_empty() { return None; }
                parts.push(BasePart { digits: Some(std::mem::take(&mut run)), delimiter: None });
                parts.push(BasePart { digits: None, delimiter: None });
                body.drain(..4);
            } else if body.starts_with("NI") {
                run.push('0'); body.drain(..2);
            } else if body.starts_with("WE") || (options.relaxed_nanpa_linjan_parsing && body.starts_with("WA")) {
                run.push('1'); body.drain(..2);
            } else {
                return None;
            }
        }
        if !run.is_empty() {
            parts.push(BasePart { digits: Some(run), delimiter: None });
        }
        return build_binary_result(source, parts, options);
    }
    None
}

fn hex_group_sizes(mut len: usize) -> Vec<usize> {
    if len == 0 { return Vec::new(); }
    if len <= 3 { return vec![len]; }
    let mut out = Vec::new();
    while len > 3 {
        out.push(2);
        len -= 2;
    }
    out.push(len);
    out
}

fn hex_groups(run: &str) -> Vec<&str> {
    let mut groups = Vec::new();
    let mut pos = 0usize;
    for size in hex_group_sizes(run.len()) {
        groups.push(&run[pos..pos + size]);
        pos += size;
    }
    groups
}

fn hex_syllable(digit: char, relaxed: bool) -> Option<&'static str> {
    Some(match digit.to_ascii_uppercase() {
        '0' => "ni",
        '1' if relaxed => "wa", '1' => "we",
        '2' if relaxed => "tu", '2' => "te",
        '3' => "se", '4' => "na",
        '5' if relaxed => "lu", '5' => "le",
        '6' => "nu",
        '7' if relaxed => "mu", '7' => "me",
        '8' if relaxed => "pi", '8' => "pe",
        '9' if relaxed => "jo", '9' => "je",
        'A' => "ja", 'B' => "la", 'C' => "ma", 'D' => "pa", 'E' => "si", 'F' => "ta",
        _ => return None,
    })
}

fn hex_abbrev_word(digit: char) -> Option<&'static str> {
    Some(match digit.to_ascii_uppercase() {
        '0' => "ijo", '1' => "wan", '2' => "tu", '3' => "seli", '4' => "awen",
        '5' => "luka", '6' => "utala", '7' => "mun", '8' => "pipi", '9' => "jo",
        'A' => "jan", 'B' => "lawa", 'C' => "ma", 'D' => "pakala", 'E' => "sike", 'F' => "tan",
        _ => return None,
    })
}

fn append_hex_full_words(words: &mut Vec<String>, digit: char, relaxed: bool) -> Option<()> {
    match digit.to_ascii_uppercase() {
        'A' => words.extend(["jan","ala"].iter().map(|x| (*x).to_string())),
        'B' => words.extend(["lawa","ala"].iter().map(|x| (*x).to_string())),
        'C' => words.extend(["ma","ala"].iter().map(|x| (*x).to_string())),
        'D' => words.extend(["pakala","ala"].iter().map(|x| (*x).to_string())),
        'E' => words.extend(["sike","ike"].iter().map(|x| (*x).to_string())),
        'F' => words.extend(["tan","ala"].iter().map(|x| (*x).to_string())),
        ch @ '0'..='9' => append_digit_words(words, ch.to_digit(10)? as u8, relaxed)?,
        _ => return None,
    }
    Some(())
}

fn build_hex_result(input: &str, parts: Vec<BasePart>, options: &ParseOptions) -> Option<ParseResult> {
    let digits = parts_digits(&parts);
    if digits.is_empty() { return None; }
    let mut full_words = vec!["nasa".to_string(), ":".to_string()];
    let mut abbreviated_words = vec!["nasa".to_string(), ":".to_string()];
    let mut proper = vec!["Nasa".to_string()];
    for part in &parts {
        if let Some(run) = &part.digits {
            let groups = hex_groups(run);
            for (group_index, group) in groups.iter().enumerate() {
                let mut proper_group = String::new();
                for digit in group.chars() {
                    append_hex_full_words(&mut full_words, digit, options.relaxed_nanpa_linjan_rendering)?;
                    abbreviated_words.push(hex_abbrev_word(digit)?.to_string());
                    proper_group.push_str(hex_syllable(digit, options.relaxed_nanpa_linjan_rendering)?);
                }
                proper.push(title_word(&proper_group));
                if group_index + 1 < groups.len() {
                    full_words.extend(["nena","e","kule","e"].iter().map(|x| (*x).to_string()));
                    abbreviated_words.push("kule".to_string());
                    proper.last_mut()?.push('n');
                    proper.push("Eke".to_string());
                }
            }
        } else {
            full_words.extend(["nena","e","nena","e"].iter().map(|x| (*x).to_string()));
            abbreviated_words.push("e".to_string());
            proper.last_mut()?.push('n');
            proper.push("Ene".to_string());
        }
    }
    proper.last_mut()?.push('n');
    full_words.push("nasa".to_string());
    abbreviated_words.push("nasa".to_string());
    let (inner, codepoints, hex_codepoints, hex_with_cartouche) = base_codepoints(&full_words)?;
    let abbreviated_ucsur_codepoints = words_to_codepoints(&abbreviated_words)?;
    let mut canonical = String::from("#");
    for part in &parts {
        if let Some(run) = &part.digits {
            canonical.push_str(run);
        } else {
            canonical.push(part.delimiter.unwrap_or(':'));
        }
    }
    let hex_parts = Some(parts.iter().map(|part| {
        if let Some(run) = &part.digits {
            NumericPart::Digits(run.clone())
        } else {
            NumericPart::Delimiter(part.delimiter.unwrap_or('\0'))
        }
    }).collect());
    Some(ParseResult {
        input: input.trim().to_string(),
        caps: None,
        proper_name: proper.join(" "),
        unique_code: canonical.clone(),
        ucsur_codepoints: inner.clone(),
        hex_codepoints,
        hex_with_cartouche,
        tp_words: full_words.clone(),
        words: full_words,
        display_value: canonical,
        is_time: false,
        is_date: false,
        is_time_like: false,
        inner_codepoints: inner,
        codepoints,
        numeric_mode: options.numeric_mode.as_str().to_string(),
        semantic_kind: None,
        semantic_start_glyph: None,
        kind: Some(NumberKind::Hex),
        number_base: Some(16),
        is_hex: true,
        is_binary: false,
        hex_digits: Some(digits),
        binary_digits: None,
        hex_parts,
        binary_parts: None,
        abbreviated_ucsur_codepoints: Some(abbreviated_ucsur_codepoints),
        abbreviated_words: Some(abbreviated_words),
    })
}

fn parse_hex(input: &str, options: &ParseOptions) -> Option<ParseResult> {
    if !options.enable_hex_parsing { return None; }
    let source = input.trim();
    if let Some(body) = source.strip_prefix('#') {
        if body.is_empty() || !body.chars().next().is_some_and(|ch| ch.is_ascii_hexdigit()) {
            return None;
        }
        let mut parts = Vec::<BasePart>::new();
        let mut run = String::new();
        for ch in body.chars() {
            if ch.is_ascii_hexdigit() {
                run.push(ch.to_ascii_uppercase());
            } else {
                if ch.is_whitespace() || (ch.is_ascii_alphabetic() && !matches!(ch.to_ascii_uppercase(), 'A'..='F')) {
                    return None;
                }
                if !run.is_empty() {
                    parts.push(BasePart { digits: Some(std::mem::take(&mut run)), delimiter: None });
                }
                parts.push(BasePart { digits: None, delimiter: Some(ch) });
            }
        }
        if !run.is_empty() {
            parts.push(BasePart { digits: Some(run), delimiter: None });
        }
        if parts.first().is_none_or(|part| part.digits.is_none()) { return None; }
        return build_hex_result(source, parts, options);
    }
    if source.starts_with('[') && source.ends_with(']') {
        let tokens = tokenize_bracket_words(source)?;
        if tokens.len() < 4 || tokens[0] != "nasa" || tokens.last()? != "nasa" { return None; }
        let start = if tokens.get(1).is_some_and(|token| token == ":") { 2 } else { 1 };
        let body = &tokens[start..tokens.len() - 1];
        let mut structured: Vec<(char, Option<char>)> = Vec::new();
        for word in body {
            if word == "kule" {
                structured.push(('g', None));
            } else if word == "e" {
                structured.push(('d', None));
            } else {
                let mut found = None;
                for digit in "0123456789ABCDEF".chars() {
                    if hex_abbrev_word(digit) == Some(word.as_str()) {
                        found = Some(digit);
                        break;
                    }
                }
                structured.push(('x', Some(found?)));
            }
        }
        let mut parts = Vec::<BasePart>::new();
        let mut run = String::new();
        let mut generated_positions = Vec::<usize>::new();
        for (kind, value) in structured {
            match kind {
                'x' => run.push(value?),
                'g' => generated_positions.push(run.len()),
                'd' => {
                    if run.is_empty() { return None; }
                    let groups = hex_groups(&run);
                    let expected: Vec<usize> = groups.iter().scan(0usize, |pos, group| {
                        *pos += group.len(); Some(*pos)
                    }).take(groups.len().saturating_sub(1)).collect();
                    if generated_positions != expected { return None; }
                    parts.push(BasePart { digits: Some(std::mem::take(&mut run)), delimiter: None });
                    parts.push(BasePart { digits: None, delimiter: None });
                    generated_positions.clear();
                }
                _ => return None,
            }
        }
        if run.is_empty() { return None; }
        let groups = hex_groups(&run);
        let expected: Vec<usize> = groups.iter().scan(0usize, |pos, group| {
            *pos += group.len(); Some(*pos)
        }).take(groups.len().saturating_sub(1)).collect();
        if generated_positions != expected { return None; }
        parts.push(BasePart { digits: Some(run), delimiter: None });
        return build_hex_result(source, parts, options);
    }
    if source.starts_with("Nasa ") {
        let compact: String = source.split_whitespace().collect();
        if !compact.ends_with('n') { return None; }
        let mut body = compact[4..compact.len() - 1].to_ascii_uppercase();
        let mut parts = Vec::<BasePart>::new();
        let mut run = String::new();
        let mut generated_positions = Vec::<usize>::new();
        while !body.is_empty() {
            if body.starts_with("NENE") {
                if run.is_empty() { return None; }
                let groups = hex_groups(&run);
                let expected: Vec<usize> = groups.iter().scan(0usize, |pos, group| { *pos += group.len(); Some(*pos) })
                    .take(groups.len().saturating_sub(1)).collect();
                if generated_positions != expected { return None; }
                parts.push(BasePart { digits: Some(std::mem::take(&mut run)), delimiter: None });
                parts.push(BasePart { digits: None, delimiter: None });
                generated_positions.clear();
                body.drain(..4);
                continue;
            }
            if body.starts_with("NEKE") {
                generated_positions.push(run.len());
                body.drain(..4);
                continue;
            }
            let mut matched = false;
            for digit in "0123456789ABCDEF".chars() {
                let syllable = hex_syllable(digit, options.relaxed_nanpa_linjan_parsing)?.to_ascii_uppercase();
                let strict = hex_syllable(digit, false)?.to_ascii_uppercase();
                if body.starts_with(&syllable) || body.starts_with(&strict) {
                    let len = if body.starts_with(&syllable) { syllable.len() } else { strict.len() };
                    run.push(digit);
                    body.drain(..len);
                    matched = true;
                    break;
                }
            }
            if !matched { return None; }
        }
        if run.is_empty() { return None; }
        parts.push(BasePart { digits: Some(run), delimiter: None });
        return build_hex_result(source, parts, options);
    }
    None
}

pub(super) fn parse_extended_number(
    input: &str,
    options: &ParseOptions,
) -> Option<ParseResult> {
    let source = input.trim();
    if source.is_empty() { return None; }

    if let Some(result) = parse_binary(source, options) { return Some(result); }
    if let Some(result) = parse_hex(source, options) { return Some(result); }
    if let Some(result) = parse_typed_decimal_cartouche(source, options) { return Some(result); }
    // Raw all-uppercase CAPS must win over the mixed/title-case proper-name
    // interpretation.  In particular, NENE... remains raw CAPS while
    // Nen(e)... can carry the explicit-positive proper-name convention.
    if let Some(result) = parse_caps_identifier(source, options) { return Some(result); }
    if let Some(result) = parse_proper_name(source, options) { return Some(result); }
    if let Some(result) = parse_number_code(source, options) { return Some(result); }
    if let Some(result) = parse_date(source, options) { return Some(result); }
    if let Some(result) = parse_time(source, options) { return Some(result); }
    if let Some(result) = parse_scientific(source, options) { return Some(result); }
    if let Some(result) = parse_fraction(source, options) { return Some(result); }
    if let Some(result) = parse_grouped_loose(source, options) { return Some(result); }
    None
}
