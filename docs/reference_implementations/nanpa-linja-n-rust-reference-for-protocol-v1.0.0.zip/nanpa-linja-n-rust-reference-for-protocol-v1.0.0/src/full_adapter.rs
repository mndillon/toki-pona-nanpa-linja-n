use std::collections::BTreeMap;

use crate::api::codepoint_to_word;
use crate::full_font_registry::{setting_f64, setting_i64, setting_string, FullFontInfo};
use crate::full_types::*;
use crate::protocol::{CARTOUCHE_END, CARTOUCHE_START};

#[derive(Debug, Clone)]
pub struct AdaptedOrdinary { pub text: String, pub canonical_spans: Vec<(usize,usize)> }
#[derive(Debug, Clone)]
pub struct OrdinaryCartouche { pub inner: Vec<u32>, pub manual_tallies: Vec<usize>, pub tally_mode: String }
impl OrdinaryCartouche { pub fn has_manual_tallies(&self)->bool{self.manual_tallies.iter().any(|&n|n>0)} }

pub fn word_to_cp(word:&str)->Option<u32>{
    let mut w=word.trim().to_ascii_lowercase();
    let alias=match w.as_str(){
        "ni01"=>Some("ni"),"ni02"=>Some("ni>"),"ni03"=>Some("ni^"),"ni04"=>Some("ni<"),
        "sewi01"=>Some("sewi"),"sewi02"=>Some("sewi^"),"ale"=>Some("ali"),
        _=>None,
    };
    if let Some(alias)=alias{w=alias.to_string();}
    match w.as_str(){
        "te"=>return Some(OPEN_QUOTE_CODEPOINT),"to"=>return Some(CLOSE_QUOTE_CODEPOINT),"zz"=>return Some(0x3000),
        "ota"|"middle-dot"|"."|"·"=>return Some(MIDDLE_DOT_CODEPOINT),"colon"|":"=>return Some(COLON_CODEPOINT),"tally"|","=>return Some(TALLY_CODEPOINT),
        "ni>"=>return Some(0xF198B),"ni^"=>return Some(0xF198A),"ni<"=>return Some(0xF1989),"sewi^"=>return Some(0xF198C),
        _=>{}
    }
    for cp in 0xF1900..=0xF19FF { if codepoint_to_word(cp).is_some_and(|x|x==w){return Some(cp);} }
    None
}

fn legacy_ordinary_word(cp:u32,kind:&str)->Option<String>{
    let s=match cp{
        MIDDLE_DOT_CODEPOINT=>Some("."),COLON_CODEPOINT=>Some(":"),0x3000=>Some(if kind=="linja-lipamanka"{"zz"}else{"  "}),
        0xF1989=>Some(if kind=="linja-lipamanka"{"ni<"}else{"ni"}),0xF198A=>Some(if kind=="linja-sike"||kind=="linja-lipamanka"{"ni^"}else{"ni"}),
        0xF198B=>Some(if kind=="linja-sike"||kind=="linja-lipamanka"{"ni>"}else{"ni"}),0xF198C=>Some(if kind=="linja-sike"{"sewi1"}else{"sewi"}),
        OPEN_QUOTE_CODEPOINT if kind=="linja-lipamanka"=>Some("te"),CLOSE_QUOTE_CODEPOINT if kind=="linja-lipamanka"=>Some("to"),_=>None};
    if let Some(v)=s{return Some(v.into());}
    let w=codepoint_to_word(cp)?;
    if kind=="linja-pona" && matches!(cp,0xF19A2|0xF19A4|0xF19A5|0xF19A6){return None;}
    if kind=="linja-lipamanka" && (matches!(cp,0xF19A4|0xF19A5|0xF19A6)||cp>0xF19A3){return None;}
    Some(w.to_string())
}


fn is_control_only(cp:u32)->bool{matches!(cp,0xF1992|0xF1993|0xF1994|0xF1997|0xF1998|0xF1999|0xF199A|0xF199B)}
fn is_joiner(cp:u32)->bool{matches!(cp,0x200D|STACK_JOINER_CODEPOINT|NEST_JOINER_CODEPOINT)}

fn full_legacy_word(cp:u32,kind:&str,font:&FullFontInfo)->String{
    if matches!(cp,OPEN_QUOTE_CODEPOINT|CLOSE_QUOTE_CODEPOINT)
        && setting_string(&font.render_adapter_settings,"cornerBracketMode","").eq_ignore_ascii_case("synthetic") {
        return char::from_u32(cp).unwrap_or('\u{FFFD}').to_string();
    }
    legacy_ordinary_word(cp,kind).unwrap_or_else(||"\u{FFFD}".into())
}

fn cells(cps:&[u32])->Vec<Vec<u32>>{
    let mut out=Vec::new();let mut i=0usize;
    while i<cps.len(){
        let cp=cps[i];
        if is_control_only(cp){out.push(vec![cp]);i+=1;continue;}
        let mut cell=vec![cp];i+=1;
        while i+1<cps.len()&&is_joiner(cps[i]){cell.push(cps[i]);cell.push(cps[i+1]);i+=2;}
        out.push(cell);
    }
    out
}
fn append_legacy_cell(out:&mut String,cell:&[u32],kind:&str,font:&FullFontInfo){
    if cell.is_empty()||cell.iter().all(|cp|is_control_only(*cp)){return;}
    let mut i=0usize;
    while i<cell.len(){
        out.push_str(&full_legacy_word(cell[i],kind,font));i+=1;
        if i<cell.len(){
            let j=cell[i];let op=if kind=="linja-lipamanka"{
                if j==STACK_JOINER_CODEPOINT{'+'}else if j==NEST_JOINER_CODEPOINT{'-'}else{setting_string(&font.render_adapter_settings,"genericCompoundOperator","-").chars().next().unwrap_or('-')}
            }else{'-'};
            out.push(op);i+=1;
        }
    }
}
fn current_long(cps:&[u32])->Option<(usize,usize,usize)>{
    let start=cps.iter().position(|cp|*cp==0xF1997)?;if start==0{return None;}let end=cps.iter().enumerate().skip(start+1).find(|(_,cp)|**cp==0xF1998).map(|(i,_)|i)?;Some((start-1,start,end))
}
fn has_reverse_long(cps:&[u32])->bool{cps.iter().any(|cp|matches!(*cp,0xF199A|0xF199B))}
fn string_cps(s:&str)->Vec<u32>{s.chars().map(|c|c as u32).collect()}

/// Canonical production-font adaptation for ordinary glyph/word runs.
/// Raw U+ input bypasses this in the full renderer, matching JavaScript.
pub fn adapt_full_word_run(font:&FullFontInfo,cps:&[u32])->Vec<u32>{
    match font.render_adapter_id.as_str(){
        "linja-pona-legacy-v1"|"linja-sike-legacy-v1"=>{
            let kind=if font.render_adapter_id.starts_with("linja-sike"){"linja-sike"}else{"linja-pona"};
            if let Some((head,start,end))=current_long(cps){
                if !has_reverse_long(cps)&&word_to_cp("pi")==Some(cps[head]){
                    let usable:Vec<Vec<u32>>=cells(&cps[start+1..end]).into_iter().filter(|c|!c.iter().all(|cp|is_control_only(*cp))).collect();
                    let max=setting_i64(&font.render_adapter_settings,"maxLongPiCells",3).max(1) as usize;
                    if !usable.is_empty()&&usable.len()<=max{
                        let mut out=String::from("pi");
                        if kind=="linja-pona"{
                            out.push_str(&"+".repeat(usable.len()));
                            for (i,c) in usable.iter().enumerate(){if i>0{out.push(' ');}append_legacy_cell(&mut out,c,kind,font);}
                        }else{
                            out.push('+');for c in &usable{out.push_str("__");append_legacy_cell(&mut out,c,kind,font);}
                        }
                        return string_cps(&out);
                    }
                }
            }
            let mut out=String::new();for c in cells(cps){append_legacy_cell(&mut out,&c,kind,font);}string_cps(&out)
        }
        "nasin-sitelen-pu-mono-v1"=>{
            let replacement=setting_i64(&font.render_adapter_settings,"unsupportedReplacementCodepoint",0xFFFD) as u32;
            cps.iter().filter_map(|cp|{
                if is_joiner(*cp)||is_control_only(*cp){return None;}
                Some(match *cp{0xF1989|0xF198A|0xF198B=>0xF1941,0xF198C=>0xF195A,MIDDLE_DOT_CODEPOINT=>'.' as u32,COLON_CODEPOINT=>':' as u32,
                    x if (0xF1900..=0xF1988).contains(&x)||(0xF19A0..=0xF19A3).contains(&x)||matches!(x,0x3000|OPEN_QUOTE_CODEPOINT|CLOSE_QUOTE_CODEPOINT)=>x,_=>replacement})
            }).collect()
        }
        "linja-lipamanka-v1"=>{
            if !cps.iter().any(|cp|is_joiner(*cp)){return cps.to_vec();}
            let mut out=String::new();for c in cells(cps){append_legacy_cell(&mut out,&c,"linja-lipamanka",font);}string_cps(&out)
        }
        _=>cps.to_vec(),
    }
}

pub fn adapt_ordinary(font:&FullFontInfo,inner:&[u32])->AdaptedOrdinary{
    let full:Vec<u32>=std::iter::once(CARTOUCHE_START).chain(inner.iter().copied()).chain(std::iter::once(CARTOUCHE_END)).collect();
    let identity=||{let mut text=String::new();let mut spans=Vec::new();let mut idx=0usize;for cp in &full{let start=idx;text.push(char::from_u32(*cp).unwrap_or('\u{FFFD}'));idx+=1;spans.push((start,idx));}AdaptedOrdinary{text,canonical_spans:spans}};
    let rid=font.render_adapter_id.as_str();
    if rid=="linja-pona-legacy-v1"||rid=="linja-sike-legacy-v1"{
        let kind=if rid.starts_with("linja-sike"){"linja-sike"}else{"linja-pona"};
        let mut out="[".to_string();let mut spans=vec![(0,0);full.len()];spans[0]=(0,1);let mut i=1usize;
        while i+1<full.len(){
            let st=out.chars().count();out.push('_');
            let first=i;out.push_str(&full_legacy_word(full[i],kind,font));i+=1;
            while i+1<full.len()&&is_joiner(full[i])&&i+1<full.len()-1{
                out.push('-');i+=1;out.push_str(&full_legacy_word(full[i],kind,font));i+=1;
            }
            let en=out.chars().count();for slot in spans.iter_mut().take(i).skip(first){*slot=(st,en);}
        }
        let st=out.chars().count();out.push(']');let last=spans.len()-1;spans[last]=(st,out.chars().count());
        return AdaptedOrdinary{text:out,canonical_spans:spans};
    }
    if rid=="nasin-sitelen-pu-mono-v1"{
        let replacement=setting_i64(&font.render_adapter_settings,"unsupportedReplacementCodepoint",0xFFFD) as u32;
        let vals:Vec<u32>=full.iter().filter_map(|&cp|{
            if is_joiner(cp)||is_control_only(cp){return None;}
            Some(match cp{0xF1989|0xF198A|0xF198B=>0xF1941,0xF198C=>0xF195A,MIDDLE_DOT_CODEPOINT=>'.' as u32,COLON_CODEPOINT=>':' as u32,_ if (0xF1900..=0xF1988).contains(&cp)||(0xF19A0..=0xF19A3).contains(&cp)||cp==CARTOUCHE_START||cp==CARTOUCHE_END||cp==0x3000||cp==OPEN_QUOTE_CODEPOINT||cp==CLOSE_QUOTE_CODEPOINT=>cp,_=>replacement})
        }).collect();
        let mut text=String::new();let mut spans=Vec::new();for (i,cp) in vals.iter().enumerate(){text.push(char::from_u32(*cp).unwrap_or('\u{FFFD}'));spans.push((i,i+1));}return AdaptedOrdinary{text,canonical_spans:spans};
    }
    if rid=="linja-lipamanka-v1"{
        let needs=|cp:u32|is_joiner(cp)||cp==MIDDLE_DOT_CODEPOINT||cp==COLON_CODEPOINT||cp==TALLY_CODEPOINT||matches!(cp,0xF1989|0xF198A|0xF198B|0xF198C|OPEN_QUOTE_CODEPOINT|CLOSE_QUOTE_CODEPOINT|0x3000|0xF19A4|0xF19A5|0xF19A6)||cp>0xF19A3;
        if full.iter().copied().any(needs){
            let mut out="[".to_string();let mut spans=vec![(0,0);full.len()];spans[0]=(0,1);let mut i=1usize;let mut first_cell=true;
            while i+1<full.len(){if !first_cell{out.push(' ');}first_cell=false;let st=out.chars().count();let first=i;out.push_str(&full_legacy_word(full[i],"linja-lipamanka",font));i+=1;while i+1<full.len()&&is_joiner(full[i])&&i+1<full.len()-1{let j=full[i];out.push(if j==STACK_JOINER_CODEPOINT{'+'}else{'-'});i+=1;out.push_str(&full_legacy_word(full[i],"linja-lipamanka",font));i+=1;}let en=out.chars().count();for slot in spans.iter_mut().take(i).skip(first){*slot=(st,en);}}
            let st=out.chars().count();out.push(']');let last=spans.len()-1;spans[last]=(st,out.chars().count());return AdaptedOrdinary{text:out,canonical_spans:spans};
        }
    }
    identity()
}

pub fn parse_ordinary_body(body:&str,font:&FullFontInfo,p:&FullParserOptions)->Option<OrdinaryCartouche>{
    let body=body.trim();if body.is_empty(){return None;}let mut mode=p.cartouche_tally_mode.trim().to_ascii_lowercase();if mode.is_empty(){mode=setting_string(&font.settings,"cartoucheTallyMode","ucsur").to_ascii_lowercase();}if !matches!(mode.as_str(),"manual"|"comma"|"ucsur"){mode="ucsur".into();}
    let mut cps=Vec::new();let mut tallies=Vec::new();let mut current=String::new();
    fn flush(cur:&mut String,cps:&mut Vec<u32>,tallies:&mut Vec<usize>,mode:&str)->bool{let token=cur.trim().to_ascii_lowercase();cur.clear();if token.is_empty(){return true;}let Some(cp)=word_to_cp(&token)else{return false};if cp==TALLY_CODEPOINT&&mode=="manual"{if let Some(last)=tallies.last_mut(){*last=(*last+1).min(8);}return true;}cps.push(cp);tallies.push(0);true}
    for ch in body.chars(){if ch.is_whitespace(){if !flush(&mut current,&mut cps,&mut tallies,&mode){return None;}}else if ch=='.'||ch=='·'||ch==':'{if !flush(&mut current,&mut cps,&mut tallies,&mode){return None;}cps.push(if ch==':'{COLON_CODEPOINT}else{MIDDLE_DOT_CODEPOINT});tallies.push(0);}else if ch==','{if !flush(&mut current,&mut cps,&mut tallies,&mode){return None;}if !p.effective_comma_tally_marks(){continue;}match mode.as_str(){"manual"=>if let Some(last)=tallies.last_mut(){*last=(*last+1).min(8)},"comma"=>{cps.push(',' as u32);tallies.push(0)},_=>{cps.push(TALLY_CODEPOINT);tallies.push(0)}}}else{current.push(ch);}}
    if !flush(&mut current,&mut cps,&mut tallies,&mode)||cps.is_empty(){return None;}Some(OrdinaryCartouche{inner:cps,manual_tallies:tallies,tally_mode:mode})
}

pub fn proper_name_codepoints(word:&str)->Option<Vec<u32>>{if word.is_empty()||!word.chars().all(|c|c.is_ascii_alphabetic()){return None;}let lower=word.to_ascii_lowercase();if !lower.chars().all(|c|"aeijklmnostpuw".contains(c)){return None;}let mut bucket:BTreeMap<char,u32>=BTreeMap::new();for cp in 0xF1900..=0xF19FF{if let Some(w)=codepoint_to_word(cp){if w.chars().all(|c|c.is_ascii_lowercase()){if let Some(first)=w.chars().next(){bucket.entry(first).or_insert(cp);}}}}let mut out=Vec::new();for c in lower.chars(){out.push(*bucket.get(&c)?);}Some(out)}

pub fn nasin_nanpa_pona_words(value:&str)->Vec<String>{crate::parser::try_plain_decimal_to_nasin_nanpa_pona_words(value).unwrap_or_default()}
pub fn manual_tally_lift(font:&FullFontInfo,p:&FullParserOptions,px:f64)->f64{let max=p.manual_tally_small_font_max_px.unwrap_or_else(||setting_f64(&font.settings,"manualTallySmallFontMaxPx",12.0));let lift=p.manual_tally_small_font_lift_px.unwrap_or_else(||setting_f64(&font.settings,"manualTallySmallFontLiftPx",0.0));if px<=max{lift.max(0.0)}else{0.0}}
pub fn full_open_type_features_for(px:f64)->Vec<String>{if px<=18.0{vec!["ss12".into()]}else if px<=29.0{vec!["ss13".into()]}else{vec![]}}
pub fn all_runes_ucsur(s:&str)->bool{!s.is_empty()&&s.chars().all(|c|{let cp=c as u32;(0xF1900..=0xF19FF).contains(&cp)||cp==OPEN_QUOTE_CODEPOINT||cp==CLOSE_QUOTE_CODEPOINT})}
pub fn sanitize_word(s:&str)->String{s.to_ascii_lowercase().chars().filter(|c|c.is_ascii_alphanumeric()||"<>^.".contains(*c)).collect()}
