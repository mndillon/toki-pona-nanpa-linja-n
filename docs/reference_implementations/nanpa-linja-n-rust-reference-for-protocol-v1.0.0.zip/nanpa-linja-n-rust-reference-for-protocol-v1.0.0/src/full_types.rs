use std::collections::BTreeMap;

use crate::model::ParseResult;
use crate::options::{NumericMode, ParseOptions};
use crate::protocol::DecimalStartGlyph;

pub const TALLY_CODEPOINT: u32 = 0xF199E;
pub const MIDDLE_DOT_CODEPOINT: u32 = 0xF199C;
pub const COLON_CODEPOINT: u32 = 0xF199D;
pub const STACK_JOINER_CODEPOINT: u32 = 0xF1995;
pub const NEST_JOINER_CODEPOINT: u32 = 0xF1996;
pub const OPEN_QUOTE_CODEPOINT: u32 = 0x300C;
pub const CLOSE_QUOTE_CODEPOINT: u32 = 0x300D;

#[derive(Debug, Clone)]
pub struct FullParserOptions {
    pub enable_binary_parsing: bool,
    pub enable_hex_parsing: bool,
    pub mode: String,
    pub numeric_mode: String,
    pub nanpa_colon_parsing: bool,
    pub nanpa_colon_rendering: bool,
    pub relaxed_nanpa_linjan_parsing: bool,
    pub relaxed_nanpa_linjan_rendering: bool,
    pub abbreviate_numeric_cartouches: bool,
    pub preserve_numeric_cartouche_breaks: bool,
    pub numeric_cartouche_start_glyph: Option<String>,
    pub renderer_mode: String,
    pub mixed_style: String,
    pub break_lines_at_full_stops: bool,
    pub show_unknown_text: bool,
    pub auto_cartouche_standalone_proper_names: bool,
    pub interpret_double_quotes_as_te_to: bool,
    pub cartouche_comma_tally_marks: bool,
    pub comma_tally_marks: Option<bool>,
    pub cartouche_tally_mode: String,
    pub manual_tally_small_font_lift_px: Option<f64>,
    pub manual_tally_small_font_max_px: Option<f64>,
    pub nasin_nanpa_pona: bool,
}

impl Default for FullParserOptions {
    fn default() -> Self {
        Self {
            enable_binary_parsing: true,
            enable_hex_parsing: true,
            mode: "uniform".into(),
            numeric_mode: "uniform".into(),
            nanpa_colon_parsing: true,
            nanpa_colon_rendering: true,
            relaxed_nanpa_linjan_parsing: true,
            relaxed_nanpa_linjan_rendering: true,
            abbreviate_numeric_cartouches: false,
            preserve_numeric_cartouche_breaks: false,
            numeric_cartouche_start_glyph: None,
            renderer_mode: "sitelen-pona-ascii-extended".into(),
            mixed_style: "short".into(),
            break_lines_at_full_stops: false,
            show_unknown_text: false,
            auto_cartouche_standalone_proper_names: true,
            interpret_double_quotes_as_te_to: false,
            cartouche_comma_tally_marks: true,
            comma_tally_marks: None,
            cartouche_tally_mode: String::new(),
            manual_tally_small_font_lift_px: None,
            manual_tally_small_font_max_px: None,
            nasin_nanpa_pona: false,
        }
    }
}

impl FullParserOptions {
    pub fn effective_comma_tally_marks(&self) -> bool {
        self.comma_tally_marks.unwrap_or(self.cartouche_comma_tally_marks)
    }
    pub fn effective_renderer_mode(&self) -> &str {
        match self.mode.as_str() {
            "standard-sitelen-pona-ascii-core" | "sitelen-pona-ascii-extended" | "sitelen-seli-kiwen" => &self.mode,
            _ => &self.renderer_mode,
        }
    }
    pub fn numeric_options(&self) -> ParseOptions {
        let traditional = self.numeric_mode == "traditional" || self.mode == "traditional";
        let start = self.numeric_cartouche_start_glyph.as_deref().and_then(|s| match s.to_ascii_lowercase().as_str() {
            "nanpa" => Some(DecimalStartGlyph::Nanpa),
            "tenpo" => Some(DecimalStartGlyph::Tenpo),
            "suno" => Some(DecimalStartGlyph::Suno),
            "toki" => Some(DecimalStartGlyph::Toki),
            _ => None,
        });
        ParseOptions {
            enable_binary_parsing: self.enable_binary_parsing,
            enable_hex_parsing: self.enable_hex_parsing,
            mode: if traditional { NumericMode::Traditional } else { NumericMode::Uniform },
            numeric_mode: if traditional { NumericMode::Traditional } else { NumericMode::Uniform },
            nanpa_colon_parsing: self.nanpa_colon_parsing,
            nanpa_colon_rendering: self.nanpa_colon_rendering,
            relaxed_nanpa_linjan_parsing: self.relaxed_nanpa_linjan_parsing,
            relaxed_nanpa_linjan_rendering: self.relaxed_nanpa_linjan_rendering,
            abbreviate_numeric_cartouches: self.abbreviate_numeric_cartouches,
            preserve_numeric_cartouche_breaks_in_abbreviation: self.preserve_numeric_cartouche_breaks,
            numeric_cartouche_start_glyph: start,
            ..ParseOptions::default()
        }
    }
}

#[derive(Debug, Clone)]
pub struct FullLayoutOptions {
    pub align: String,
    pub spacing_preset: String,
    pub glyph_gap_scale: Option<f64>,
    pub glyph_gap_min_px: Option<f64>,
    pub glyph_gap_max_px: Option<f64>,
    pub cartouche_lead_gap_scale: Option<f64>,
    pub cartouche_pad_scale: Option<f64>,
    pub cartouche_pad_min_px: Option<f64>,
    pub line_gap_px: Option<f64>,
    pub force_line_gap_px: bool,
}
impl Default for FullLayoutOptions {
    fn default() -> Self {
        Self { align: "left".into(), spacing_preset: "default".into(), glyph_gap_scale: None, glyph_gap_min_px: None, glyph_gap_max_px: None, cartouche_lead_gap_scale: None, cartouche_pad_scale: None, cartouche_pad_min_px: None, line_gap_px: None, force_line_gap_px: false }
    }
}
impl FullLayoutOptions {
    pub fn glyph_gap(&self, px: f64) -> f64 {
        if let Some(scale) = self.glyph_gap_scale {
            let mut v = px * scale;
            if let Some(min) = self.glyph_gap_min_px { v = v.max(min); }
            if let Some(max) = self.glyph_gap_max_px { v = v.min(max); }
            return v.max(0.0);
        }
        match self.spacing_preset.to_ascii_lowercase().as_str() {
            "compact" => 2.0f64.max(px * 0.08),
            "comfortable" => 6.0f64.max(px * 0.22),
            _ => 4.0f64.max(px * 0.14),
        }
    }
    pub fn cartouche_lead_gap(&self, px: f64) -> f64 { self.cartouche_lead_gap_scale.map(|v| (px*v).max(0.0)).unwrap_or_else(|| self.glyph_gap(px)) }
    pub fn cartouche_pad(&self, px: f64) -> f64 {
        let mut v = px * self.cartouche_pad_scale.unwrap_or(0.12);
        if let Some(min) = self.cartouche_pad_min_px { v = v.max(min); }
        v.max(0.0)
    }
    pub fn line_gap(&self, px: f64) -> f64 {
        if let Some(v) = self.line_gap_px {
            if self.force_line_gap_px || v >= 0.0 { return v.max(0.0); }
        }
        match self.spacing_preset.to_ascii_lowercase().as_str() {
            "compact" => 8.0f64.max(px * 0.20),
            "comfortable" => 18.0f64.max(px * 0.40),
            _ => 18.0,
        }
    }
}

#[derive(Debug, Clone)]
pub struct UnknownTextStyle { pub style: String, pub color: String, pub line_width_px: f64, pub padding_px: f64, pub dash: Vec<f64> }
impl Default for UnknownTextStyle { fn default() -> Self { Self { style: "outline-box".into(), color: "#000000".into(), line_width_px: 1.5, padding_px: 2.0, dash: vec![] } } }
#[derive(Debug, Clone)]
pub struct FullPaintOptions { pub fill_style: String, pub unknown_text: UnknownTextStyle, pub halo_enabled: bool, pub halo_color: String, pub halo_width_px: f64 }
impl Default for FullPaintOptions { fn default() -> Self { Self { fill_style: "#000000".into(), unknown_text: UnknownTextStyle::default(), halo_enabled: false, halo_color: "#FFFFFF".into(), halo_width_px: 0.0 } } }

#[derive(Debug, Clone)]
pub struct FullRenderOptions { pub font: String, pub font_size: f64, pub padding_px: i32, pub parser: FullParserOptions, pub layout: FullLayoutOptions, pub paint: FullPaintOptions, pub include_plan: bool }
impl Default for FullRenderOptions { fn default() -> Self { Self { font: "nasinNanpa".into(), font_size: 56.0, padding_px: 18, parser: FullParserOptions::default(), layout: FullLayoutOptions::default(), paint: FullPaintOptions::default(), include_plan: true } } }

#[derive(Debug, Clone, Default)]
pub struct ImageDescriptor { pub src: String, pub width: String, pub height: String, pub alt: String, pub v_align: String, pub wriggle: f64, pub transparent: bool }
#[derive(Debug, Clone, Default)]
pub struct DocumentSegment { pub kind: String, pub value: String, pub image: Option<ImageDescriptor>, pub open_quote: String, pub close_quote: String, pub source_start: usize, pub source_end: usize }
#[derive(Debug, Clone, Default)]
pub struct DocumentLine { pub index: usize, pub source_line_index: usize, pub sentence_index_in_source_line: usize, pub source_text: String, pub children: Vec<DocumentSegment> }
#[derive(Debug, Clone, Default)]
pub struct DocumentAst { pub kind: String, pub normalized_input: String, pub break_lines_at_full_stops: bool, pub lines: Vec<DocumentLine> }

#[derive(Debug, Clone, Default)]
pub struct TallyGroup { pub owner_index: usize, pub count: usize, pub owner_left_px: f64, pub owner_right_px: f64, pub center_x_px: f64, pub top_y_px: f64, pub bottom_y_px: f64, pub stroke_width_px: f64, pub stroke_centers_px: Vec<f64> }

#[derive(Debug, Clone, Default)]
pub struct FullRenderRun {
    pub id: String,
    pub line_index: usize,
    pub run_index: usize,
    pub kind: String,
    pub render_mode: String,
    pub font_role: String,
    pub numeric_cartouche: bool,
    pub hex_cartouche: bool,
    pub binary_cartouche: bool,
    pub numeric_base: u32,
    pub opener_codepoint: Option<u32>,
    pub closer_codepoint: Option<u32>,
    pub canonical_codepoints: Vec<u32>,
    pub render_codepoints: Vec<u32>,
    pub render_text: String,
    pub render_adapter_id: String,
    pub source_text: String,
    pub source_kind: String,
    pub source_start: usize,
    pub source_end: usize,
    pub manual_tallies: Vec<usize>,
    pub tally_groups: Vec<TallyGroup>,
    pub quoted: bool,
    pub interpreted_quote: bool,
    pub unrecognized: bool,
    pub image_alt: String,
    pub x_px: f64,
    pub y_px: f64,
    pub width_px: f64,
    pub height_px: f64,
    pub baseline_y_px: f64,
}
#[derive(Debug, Clone, Default)]
pub struct FullRenderLinePlan { pub line_index: usize, pub source_line_index: usize, pub sentence_index_in_source_line: usize, pub x_px: f64, pub y_px: f64, pub width_px: f64, pub height_px: f64, pub baseline_y_px: f64, pub ascent_px: f64, pub descent_px: f64, pub runs: Vec<FullRenderRun> }
#[derive(Debug, Clone)]
pub struct FullRenderPlan { pub input: String, pub font_key: String, pub abbreviated: bool, pub width: u32, pub height: u32, pub open_type_features: Vec<String>, pub runs: Vec<FullRenderRun>, pub parsed: Option<ParseResult>, pub diagnostics: Vec<String>, pub ast: DocumentAst, pub lines: Vec<FullRenderLinePlan> }
impl Default for FullRenderPlan { fn default() -> Self { Self { input: String::new(), font_key: String::new(), abbreviated: false, width: 1, height: 1, open_type_features: vec![], runs: vec![], parsed: None, diagnostics: vec![], ast: DocumentAst::default(), lines: vec![] } } }
impl FullRenderPlan { pub fn line_count(&self) -> usize { self.lines.len() } pub fn cartouche_count(&self) -> usize { self.runs.iter().filter(|r| r.numeric_cartouche || r.font_role == "cartouche").count() } }

#[derive(Debug, Clone)]
pub struct FullCanvasResult { pub width: u32, pub height: u32, pub rgba: Vec<u8>, pub plan: Option<FullRenderPlan>, pub font_key: String }
#[derive(Debug, Clone, Default)]
pub struct VectorElement { pub kind: String, pub run_id: String, pub path: String, pub fill: String, pub href: String, pub text: String, pub x: f64, pub y: f64, pub width: f64, pub height: f64 }
#[derive(Debug, Clone, Default)]
pub struct VectorDocument { pub width: u32, pub height: u32, pub elements: Vec<VectorElement>, pub diagnostics: Vec<String>, pub plan: FullRenderPlan }

pub type RenderAdapter = fn(&[u32], &str, f64) -> Vec<u32>;
pub type RenderAdapterMap = BTreeMap<String, RenderAdapter>;
