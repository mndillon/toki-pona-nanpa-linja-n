#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct DigitMetadata {
    pub unique_code: char,
    pub tp_words: [&'static str; 2],
    pub codepoints: [u32; 2],
}

pub const DIGIT_METADATA: [DigitMetadata; 10] = [
    DigitMetadata {
        unique_code: 'I',
        tp_words: ["nena", "ijo"],
        codepoints: [0xF1940, 0xF190C],
    },
    DigitMetadata {
        unique_code: 'W',
        tp_words: ["wan", "ala"],
        codepoints: [0xF1973, 0xF1902],
    },
    DigitMetadata {
        unique_code: 'T',
        tp_words: ["tu", "uta"],
        codepoints: [0xF196E, 0xF1970],
    },
    DigitMetadata {
        unique_code: 'S',
        tp_words: ["seli", "e"],
        codepoints: [0xF1957, 0xF1909],
    },
    DigitMetadata {
        unique_code: 'A',
        tp_words: ["nena", "awen"],
        codepoints: [0xF1940, 0xF1908],
    },
    DigitMetadata {
        unique_code: 'L',
        tp_words: ["luka", "uta"],
        codepoints: [0xF192D, 0xF1970],
    },
    DigitMetadata {
        unique_code: 'U',
        tp_words: ["nena", "utala"],
        codepoints: [0xF1940, 0xF1971],
    },
    DigitMetadata {
        unique_code: 'M',
        tp_words: ["mun", "uta"],
        codepoints: [0xF193A, 0xF1970],
    },
    DigitMetadata {
        unique_code: 'P',
        tp_words: ["pipi", "ike"],
        codepoints: [0xF1951, 0xF190D],
    },
    DigitMetadata {
        unique_code: 'J',
        tp_words: ["jo", "open"],
        codepoints: [0xF1913, 0xF1947],
    },
];

pub fn metadata_for_digit(digit: u8) -> Option<&'static DigitMetadata> {
    DIGIT_METADATA.get(digit as usize)
}