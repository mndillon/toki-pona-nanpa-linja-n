use std::collections::BTreeMap;
use std::sync::{Mutex, OnceLock};

use fontdue::{Font, FontSettings};
use harfrust::{Direction, Feature, FontRef, ShapeOptions, ShaperData, UnicodeBuffer};
use image::codecs::png::PngEncoder;
use image::{ColorType, GenericImageView, ImageEncoder};

use crate::facade::{NanpaLinjaN, RenderError};
use crate::font_adapters::adapt_numeric_cartouche;
use crate::full_adapter::*;
use crate::full_document::{decode_data_image, parse_full_document, parse_raw_unicode_sequence};
use crate::full_font_registry::{bundled_full_font_bytes, FullFontInfo, FullFontRegistry};
use crate::full_types::*;
use crate::parser::parse_number;
use crate::protocol::{CARTOUCHE_END, CARTOUCHE_START};

static ADAPTERS: OnceLock<Mutex<BTreeMap<String, RenderAdapter>>> = OnceLock::new();
fn adapters() -> &'static Mutex<BTreeMap<String, RenderAdapter>> { ADAPTERS.get_or_init(|| Mutex::new(BTreeMap::new())) }

#[derive(Clone)]
struct GlyphBitmap { left:f64, top:f64, width:usize, height:usize, bitmap:Vec<u8> }
#[derive(Clone)]
struct ShapedText { glyphs:Vec<GlyphBitmap>, min_x:f64, min_y:f64, max_x:f64, max_y:f64, width:f64, height:f64, baseline:f64, origin_x:f64, origin_y:f64, carets:Vec<(usize,f64)> }
#[derive(Clone,Default)]
struct FullGraphic { text:String, font_filename:String, features:Vec<String>, width:f64, height:f64, baseline:f64, origin_x:f64, origin_y:f64, tally_groups:Vec<TallyGroup>, image_bytes:Vec<u8>, image_href:String, unknown_decoration:bool }
#[derive(Clone)]
struct LogicalRun { run:FullRenderRun, graphic:FullGraphic }
#[derive(Clone)]
struct PreparedFull { plan:FullRenderPlan, placed:Vec<LogicalRun>, options:FullRenderOptions }

fn normalize_options(mut o:FullRenderOptions)->FullRenderOptions {
    let d=FullRenderOptions::default();
    if o.font.trim().is_empty(){o.font=d.font;}
    if o.font_size==0.0{o.font_size=d.font_size;}
    if o.font_size<8.0{o.font_size=8.0;}
    if o.padding_px<0{o.padding_px=0;}
    if o.parser.renderer_mode.is_empty(){o.parser=d.parser;}
    if o.layout.align.is_empty(){o.layout=d.layout;}
    if o.paint.fill_style.is_empty(){o.paint=d.paint;}
    if o.paint.unknown_text.color.is_empty(){o.paint.unknown_text=UnknownTextStyle::default();}
    if o.paint.halo_color.is_empty(){o.paint.halo_color="#FFFFFF".into();}
    o
}

fn full_registry()->Result<FullFontRegistry,RenderError>{FullFontRegistry::bundled().map_err(RenderError::Manifest)}

impl NanpaLinjaN {
    pub fn list_full_fonts(&self)->Result<Vec<FullFontInfo>,RenderError>{Ok(full_registry()?.list().to_vec())}
    pub fn get_full_font_info(&self,font:&str)->Result<FullFontInfo,RenderError>{full_registry()?.get(font).cloned().ok_or_else(||RenderError::UnknownFont(format!("unknown production font: {font}")))}
    pub fn register_render_adapter(&self,id:&str,adapter:RenderAdapter){if let Ok(mut m)=adapters().lock(){m.insert(id.to_string(),adapter);}}
    pub fn get_render_adapter(&self,id:&str)->Option<RenderAdapter>{adapters().lock().ok().and_then(|m|m.get(id).copied())}
    pub fn remove_render_adapter(&self,id:&str)->Option<RenderAdapter>{adapters().lock().ok().and_then(|mut m|m.remove(id))}
    pub fn parse_input(&self,input:&str,options:&FullRenderOptions)->DocumentAst{let o=normalize_options(options.clone());parse_full_document(input,&o.parser)}
    pub fn ast_to_text(&self,ast:&DocumentAst)->Result<String,RenderError>{crate::full_document::ast_to_text(ast).map_err(RenderError::InvalidInput)}
    #[allow(non_snake_case)]
    pub fn astToText(&self,ast:&DocumentAst)->Result<String,RenderError>{self.ast_to_text(ast)}
}

fn patch_mixed_long(mut p:crate::model::ParseResult,source:&str,opts:&FullParserOptions)->crate::model::ParseResult{
    if opts.mixed_style!="long"||!source.contains('+')||!source.contains('/') {return p;}
    let open=word_to_cp("open").unwrap_or(0xF1947);let kin=word_to_cp("kin").unwrap_or(0xF1979);let nena=word_to_cp("nena").unwrap_or(0xF1940);let o=word_to_cp("o").unwrap_or(0xF1944);
    // The frozen parser emits the long mixed-fraction bridge as
    // `nena open kin open`.  The browser renderer canonicalizes that whole
    // four-codepoint bridge to `nena o nena o nena o`.  Replacing only
    // `open kin open` leaves an extra leading nena, which is observably wrong.
    fn conv(xs:&mut Vec<u32>,open:u32,kin:u32,nena:u32,o:u32){let mut i=0;while i+3<xs.len(){if xs[i]==nena&&xs[i+1]==open&&xs[i+2]==kin&&xs[i+3]==open{xs.splice(i..i+4,[nena,o,nena,o,nena,o]);break;}i+=1;}}
    conv(&mut p.inner_codepoints,open,kin,nena,o);conv(&mut p.ucsur_codepoints,open,kin,nena,o);conv(&mut p.codepoints,open,kin,nena,o);if let Some(ref mut a)=p.abbreviated_ucsur_codepoints{conv(a,open,kin,nena,o);}p
}
fn numeric_full_parse(source:&str,p:&FullParserOptions)->Option<crate::model::ParseResult>{
    let r=parse_number(source,&p.numeric_options())?;
    Some(patch_mixed_long(r,source,p))
}

fn normalize_final_numeric_codepoints(full:&mut [u32],o:&FullRenderOptions){
    // The frozen Rust extended parser can emit `nena o nena en` for the
    // decimal marker of an explicit-positive uniform number.  The canonical
    // JavaScript renderer requires `nena o nena e`.  Detect this from the
    // semantic vector itself so the correction cannot depend on document
    // tokenisation or source-text plumbing.
    let traditional=o.parser.numeric_mode=="traditional"||o.parser.mode=="traditional";
    if traditional || full.len()<4 {return;}
    const NENA:u32=0xF1940;
    const O:u32=0xF1944;
    const E:u32=0xF1909;
    const EN:u32=0xF190A;

    let sign_pos=full.windows(2).position(|w|w[0]==NENA&&w[1]==EN);
    let decimal_pos=full.windows(4).position(|w|w[0]==NENA&&w[1]==O&&w[2]==NENA&&w[3]==EN);
    if let (Some(sign),Some(decimal))=(sign_pos,decimal_pos) {
        if sign<decimal {full[decimal+3]=E;}
    }
}

#[cfg(test)]
mod explicit_positive_normalization_tests {
    use super::*;

    #[test]
    fn exact_failing_vector_is_normalized_to_javascript_reference() {
        let mut actual=vec![
            989501,989597,989504,989450,989555,989442,989550,989552,989527,
            989449,989504,989508,989504,989450,989504,989448,989485,989552,989501,
        ];
        normalize_final_numeric_codepoints(&mut actual,&FullRenderOptions::default());
        assert_eq!(actual,vec![
            989501,989597,989504,989450,989555,989442,989550,989552,989527,
            989449,989504,989508,989504,989449,989504,989448,989485,989552,989501,
        ]);
    }
}

#[cfg(test)]
mod abbreviation_routing_tests {
    use super::*;

    #[test]
    fn exact_full_decimal_vector_abbreviates_to_javascript_reference() {
        let full=vec![
            CARTOUCHE_START,
            989501,989597,989555,989442,989550,989552,989527,989449,989504,
            989508,989504,989449,989504,989448,989485,989552,989501,
            CARTOUCHE_END,
        ];
        let got=abbreviate_full_numeric_cartouche(&full,false);
        assert_eq!(got,vec![
            CARTOUCHE_START,
            989501,989597,989555,989550,989527,989508,989448,989485,989501,
            CARTOUCHE_END,
        ]);
    }
}

fn features(tags:&[String])->Result<Vec<Feature>,RenderError>{tags.iter().map(|t|Feature::from_str(t).map_err(|e|RenderError::Shaping(format!("invalid feature {t}: {e}")))).collect()}
use std::str::FromStr;
fn shape_text(text:&str,font_bytes:&'static [u8],font_px:f64,feature_tags:&[String],pad:f64,bottom_extra:f64)->Result<ShapedText,RenderError>{
    let font_ref=FontRef::from_index(font_bytes,0).map_err(|e|RenderError::Font(format!("font parse: {e:?}")))?;
    let raster_font=Font::from_bytes(font_bytes,FontSettings::default()).map_err(|e|RenderError::Font(format!("fontdue: {e}")))?;
    let upem=raster_font.units_per_em();if !upem.is_finite()||upem<=0.0{return Err(RenderError::Font("invalid units-per-em".into()));}let scale=font_px as f32/upem;
    let mut buffer=UnicodeBuffer::new();buffer.push_str(text);buffer.set_direction(Direction::LeftToRight);let fs=features(feature_tags)?;let sd=ShaperData::new(&font_ref);let sh=sd.shaper(&font_ref).build();let gb=sh.shape(buffer,ShapeOptions::new().features(&fs));let infos=gb.glyph_infos();let pos=gb.glyph_positions();if infos.is_empty()||infos.len()!=pos.len(){return Err(RenderError::Shaping("blank shaping".into()));}
    let mut pen_x=0f64;let mut pen_y=0f64;let mut min_x=f64::INFINITY;let mut min_y=f64::INFINITY;let mut max_x=f64::NEG_INFINITY;let mut max_y=f64::NEG_INFINITY;let mut glyphs=Vec::new();let mut carets=vec![(0usize,0.0)];
    for (info,p) in infos.iter().zip(pos.iter()){let cluster=info.cluster as usize;if carets.last().map(|x|x.0)!=Some(cluster){carets.push((cluster,pen_x));}if info.glyph_id>u16::MAX as u32{return Err(RenderError::Shaping("glyph id overflow".into()));}let (m,bm)=raster_font.rasterize_indexed(info.glyph_id as u16,font_px as f32);let ox=pen_x+p.x_offset as f64*scale as f64;let oy=pen_y+p.y_offset as f64*scale as f64;let left=ox+m.xmin as f64;let top=-(oy+m.ymin as f64+m.height as f64);let right=left+m.width as f64;let bottom=top+m.height as f64;if m.width>0&&m.height>0{min_x=min_x.min(left);min_y=min_y.min(top);max_x=max_x.max(right);max_y=max_y.max(bottom);glyphs.push(GlyphBitmap{left,top,width:m.width,height:m.height,bitmap:bm});}pen_x+=p.x_advance as f64*scale as f64;pen_y+=p.y_advance as f64*scale as f64;}
    carets.push((text.len(),pen_x));
    if !min_x.is_finite(){min_x=0.0;min_y=-font_px*0.8;max_x=pen_x.max(1.0);max_y=font_px*0.2;}
    let width=(max_x-min_x+2.0*pad).max(1.0);let height=(max_y-min_y+2.0*pad+bottom_extra).max(1.0);let origin_x=pad-min_x;let origin_y=pad-min_y;let baseline=origin_y;
    Ok(ShapedText{glyphs,min_x,min_y,max_x,max_y,width,height,baseline,origin_x,origin_y,carets})
}
fn caret_x(sh:&ShapedText,byte_index:usize)->f64{let mut x=0.0;for &(b,cx) in &sh.carets{if b>byte_index{break;}x=cx;}x}
fn byte_index_for_rune_index(s:&str,index:usize)->usize{if index==0{return 0;}s.char_indices().nth(index).map(|x|x.0).unwrap_or(s.len())}

fn rgba_hex(s:&str,default:[u8;4])->[u8;4]{let x=s.trim();if !x.starts_with('#'){return default;}let h=&x[1..];let v=if h.len()==3{format!("{}{}{}{}{}{}",&h[0..1],&h[0..1],&h[1..2],&h[1..2],&h[2..3],&h[2..3])}else{h.to_string()};if v.len()!=6{return default;}let Ok(n)=u32::from_str_radix(&v,16)else{return default};[((n>>16)&255)as u8,((n>>8)&255)as u8,(n&255)as u8,255]}
fn runes(s:&str)->Vec<u32>{s.chars().map(|c|c as u32).collect()}

fn make_graphic(text:&str,font_filename:&str,size:f64,features:&[String],pad:f64,bottom_extra:f64)->Result<FullGraphic,RenderError>{let bytes=bundled_full_font_bytes(font_filename).ok_or_else(||RenderError::Font(format!("missing bundled font {font_filename}")))?;let sh=shape_text(text,bytes,size,features,pad,bottom_extra)?;Ok(FullGraphic{text:text.into(),font_filename:font_filename.into(),features:features.to_vec(),width:sh.width,height:sh.height,baseline:sh.baseline,origin_x:sh.origin_x,origin_y:sh.origin_y,..FullGraphic::default()})}

fn glyph_logical(source:&str,cps:&[u32],start:usize,end:usize,source_kind:&str,font:&FullFontInfo,o:&FullRenderOptions,quoted:bool,interpreted:bool)->Result<LogicalRun,RenderError>{
    let canonical=cps.to_vec();let mut render=canonical.clone();if let Some(a)=adapters().lock().ok().and_then(|m|m.get(&font.render_adapter_id).copied()){render=a(&render,&font.key,o.font_size);}let text:String=render.iter().map(|cp|char::from_u32(*cp).unwrap_or('\u{FFFD}')).collect();let g=make_graphic(&text,&font.base_filename,o.font_size,&[],0.0,0.0)?;let mut r=FullRenderRun{kind:if canonical.len()>1{"run".into()}else{"glyph".into()},render_mode:"text".into(),font_role:"word".into(),canonical_codepoints:canonical,render_codepoints:render,render_text:text,render_adapter_id:font.render_adapter_id.clone(),source_text:source.into(),source_kind:source_kind.into(),source_start:start,source_end:end,quoted,interpreted_quote:interpreted,..FullRenderRun::default()};if r.render_adapter_id.is_empty(){r.render_adapter_id="identity".into();}Ok(LogicalRun{run:r,graphic:g})
}
fn literal_logical(source:&str,start:usize,end:usize,source_kind:&str,font:&FullFontInfo,o:&FullRenderOptions,quoted:bool,interpreted:bool,unknown:bool)->Result<LogicalRun,RenderError>{let mut g=make_graphic(source,"PatrickHand-Regular.ttf",o.font_size,&[],0.0,0.0)?;if unknown{let pad=o.paint.unknown_text.padding_px.max(0.0);g.width+=2.0*pad;g.height+=2.0*pad;g.baseline+=pad;g.origin_x+=pad;g.origin_y+=pad;g.unknown_decoration=true;}let r=FullRenderRun{kind:"text".into(),render_mode:"raster".into(),font_role:"literal".into(),render_text:source.into(),render_adapter_id:font.render_adapter_id.clone(),source_text:source.into(),source_kind:source_kind.into(),source_start:start,source_end:end,quoted,interpreted_quote:interpreted,unrecognized:unknown,..FullRenderRun::default()};Ok(LogicalRun{run:r,graphic:g})}

fn abbreviate_full_numeric_cartouche(full:&[u32],preserve_breaks:bool)->Vec<u32>{
    if full.len()<3||full[0]!=CARTOUCHE_START||*full.last().unwrap_or(&0)!=CARTOUCHE_END{return full.to_vec();}
    let chars=&full[1..full.len()-1];if chars.is_empty(){return full.to_vec();}
    const NANPA:u32=0xF193D;const NASA:u32=0xF193E;const NOKA:u32=0xF1943;const TENPO:u32=0xF196B;const SUNO:u32=0xF1964;const TOKI:u32=0xF196C;const COLON:u32=0xF199D;const NENA:u32=0xF1940;const E:u32=0xF1909;const EN:u32=0xF190A;const OPEN:u32=0xF1947;const ALA:u32=0xF1902;const IKE:u32=0xF190D;const UTA:u32=0xF1970;
    let numeric_heads=[NANPA,NASA,NOKA,TENPO,SUNO,TOKI];let is_head=|cp:u32|numeric_heads.contains(&cp);let is_drop=|cp:u32|matches!(cp,NANPA|EN|E|NENA|OPEN|ALA|IKE|UTA);
    let traditional_full_positive=chars.len()>=4&&is_head(chars[0])&&chars[1]==E&&chars[2]==NENA&&chars[3]==EN;
    let colon_full_positive=chars.len()>=4&&is_head(chars[0])&&chars[1]==COLON&&chars[2]==NENA&&chars[3]==EN;
    let full_positive=traditional_full_positive||colon_full_positive;
    let full_scaffolding_after_opening=chars.len()>3&&chars[2..chars.len()-1].iter().any(|cp|*cp==E||is_drop(*cp));
    let already_abbreviated_positive=!full_positive&&!full_scaffolding_after_opening&&chars.len()>=3&&is_head(chars[0])&&chars[1]==EN;
    let already_abbreviated_colon_positive=!full_positive&&!full_scaffolding_after_opening&&chars.len()>=4&&is_head(chars[0])&&chars[1]==COLON&&chars[2]==EN;
    let mut out_inner=Vec::with_capacity(chars.len());let mut kept_opening_head=false;let mut i=0usize;
    while i<chars.len(){let ch=chars[i];let is_final_nanpa=ch==NANPA&&i==chars.len()-1;if !kept_opening_head{out_inner.push(ch);if(i==0&&is_head(ch))||ch==NANPA{kept_opening_head=true;}i+=1;continue;}if is_final_nanpa{out_inner.push(ch);i+=1;continue;}if traditional_full_positive&&i==1{out_inner.push(EN);i=4;continue;}if colon_full_positive&&i==2{out_inner.push(EN);i=4;continue;}if already_abbreviated_positive&&i==1{out_inner.push(EN);i+=1;continue;}if already_abbreviated_colon_positive&&i==2{out_inner.push(EN);i+=1;continue;}if preserve_breaks&&ch==NENA&&i+3<chars.len()&&matches!(chars[i+1],E|EN)&&chars[i+2]==NENA&&matches!(chars[i+3],E|EN){out_inner.push(E);i+=4;continue;}if !is_drop(ch){out_inner.push(ch);}i+=1;}
    let mut out=Vec::with_capacity(out_inner.len()+2);out.push(CARTOUCHE_START);out.extend(out_inner);out.push(CARTOUCHE_END);out
}
fn numeric_full_codepoints(parsed:&crate::model::ParseResult,o:&FullRenderOptions)->Vec<u32>{
    let full=parsed.codepoints.clone();if !o.parser.abbreviate_numeric_cartouches{return full;}
    if let Some(inner)=&parsed.abbreviated_ucsur_codepoints{let out:Vec<u32>=std::iter::once(CARTOUCHE_START).chain(inner.iter().copied()).chain(std::iter::once(CARTOUCHE_END)).collect();if out!=full&&out.len()<full.len(){return out;}}
    let out=abbreviate_full_numeric_cartouche(&full,o.parser.preserve_numeric_cartouche_breaks);if out!=full&&out.len()<full.len(){out}else{full}
}
fn apply_final_numeric_start_glyph(full:&mut [u32],parsed:&crate::model::ParseResult,o:&FullRenderOptions){
    // Keep hex/binary semantic openers (nasa/noka) intact.  For decimal
    // cartouches, numericCartoucheStartGlyph is a renderer-level override and
    // therefore must be reflected in the final semantic vector even if the
    // frozen parser path did not carry it through.
    if parsed.is_hex||parsed.is_binary{return;}
    let Some(name)=o.parser.numeric_cartouche_start_glyph.as_deref() else{return;};
    let Some(cp)=word_to_cp(&name.to_ascii_lowercase()) else{return;};
    if full.first()==Some(&CARTOUCHE_START){if full.len()>2{full[1]=cp;}}else if !full.is_empty(){full[0]=cp;}
}

fn numeric_logical(source:&str,parsed:&crate::model::ParseResult,start:usize,end:usize,source_kind:&str,font:&FullFontInfo,o:&FullRenderOptions)->Result<LogicalRun,RenderError>{
    let mut full=numeric_full_codepoints(parsed,o);
    normalize_final_numeric_codepoints(&mut full,o);
    apply_final_numeric_start_glyph(&mut full,parsed,o);

    // Final abbreviation guard.  Some frozen parser paths do not populate
    // abbreviated_ucsur_codepoints, and the full-renderer bridge must not
    // depend on which ParseResult representation happened to be returned.
    // Re-run the proven legacy abbreviation algorithm on the exact semantic
    // vector that is about to be stored in the render plan.
    if o.parser.abbreviate_numeric_cartouches {
        let candidate=if full.first()==Some(&CARTOUCHE_START)&&full.last()==Some(&CARTOUCHE_END){
            abbreviate_full_numeric_cartouche(&full,o.parser.preserve_numeric_cartouche_breaks)
        }else{
            let wrapped:Vec<u32>=std::iter::once(CARTOUCHE_START).chain(full.iter().copied()).chain(std::iter::once(CARTOUCHE_END)).collect();
            abbreviate_full_numeric_cartouche(&wrapped,o.parser.preserve_numeric_cartouche_breaks)
        };
        if candidate.len()<full.len() || (full.first()!=Some(&CARTOUCHE_START)&&candidate.len()<full.len()+2) {
            full=candidate;
        }
    }

    let adapted=adapt_numeric_cartouche(&full,&font.render_adapter_id).map_err(RenderError::Adapter)?;let features=full_open_type_features_for(o.font_size);let g=make_graphic(&adapted.text,&font.companion_filename,o.font_size,&features,6.0,0.0)?;let inner=if full.len()>=2&&full.first()==Some(&CARTOUCHE_START)&&full.last()==Some(&CARTOUCHE_END){full[1..full.len()-1].to_vec()}else{full.clone()};let mut r=FullRenderRun{kind:"cartouche".into(),render_mode:"raster".into(),font_role:"number".into(),numeric_cartouche:true,hex_cartouche:parsed.is_hex,binary_cartouche:parsed.is_binary,numeric_base:parsed.number_base.unwrap_or(10),opener_codepoint:inner.first().copied(),closer_codepoint:inner.last().copied(),canonical_codepoints:inner,render_codepoints:runes(&adapted.text),render_text:adapted.text,render_adapter_id:font.render_adapter_id.clone(),source_text:source.into(),source_kind:source_kind.into(),source_start:start,source_end:end,..FullRenderRun::default()};if r.render_adapter_id.is_empty(){r.render_adapter_id="identity".into();}Ok(LogicalRun{run:r,graphic:g})
}

fn cartouche_logical(source:&str,oc:&OrdinaryCartouche,start:usize,end:usize,source_kind:&str,font:&FullFontInfo,o:&FullRenderOptions)->Result<LogicalRun,RenderError>{
    let adapted=adapt_ordinary(font,&oc.inner);let extra=if oc.has_manual_tallies(){(o.font_size*0.34).ceil()}else{0.0};let bytes=bundled_full_font_bytes(&font.base_filename).ok_or_else(||RenderError::Font(format!("missing {}",font.base_filename)))?;let sh=shape_text(&adapted.text,bytes,o.font_size,&[],6.0,extra)?;let mut groups=Vec::new();if oc.has_manual_tallies(){let bottom=sh.height-extra-6.0;let lift=manual_tally_lift(font,&o.parser,o.font_size);let top=bottom-lift;let bot=top+o.font_size*0.10;let stroke=(o.font_size*0.045).max(1.5);let gap=o.font_size*0.075;for (i,&count0) in oc.manual_tallies.iter().enumerate(){let count=count0.min(8);if count==0{continue;}let span=adapted.canonical_spans[i+1];let lx=caret_x(&sh,byte_index_for_rune_index(&adapted.text,span.0));let rx=caret_x(&sh,byte_index_for_rune_index(&adapted.text,span.1));let left=sh.origin_x+lx;let right=sh.origin_x+rx;let center=(left+right)/2.0;let total=if count>1{count as f64*stroke+(count-1)as f64*gap}else{stroke};let first=center-total/2.0+stroke/2.0;let centers=(0..count).map(|k|first+k as f64*(stroke+gap)).collect();groups.push(TallyGroup{owner_index:i,count,owner_left_px:left,owner_right_px:right,center_x_px:center,top_y_px:top,bottom_y_px:bot,stroke_width_px:stroke,stroke_centers_px:centers});}}
    let manual=if oc.has_manual_tallies(){oc.manual_tallies.clone()}else{vec![]};let g=FullGraphic{text:adapted.text.clone(),font_filename:font.base_filename.clone(),width:sh.width,height:sh.height,baseline:sh.baseline,origin_x:sh.origin_x,origin_y:sh.origin_y,tally_groups:groups.clone(),..FullGraphic::default()};let r=FullRenderRun{kind:"cartouche".into(),render_mode:"raster".into(),font_role:"cartouche".into(),opener_codepoint:Some(CARTOUCHE_START),closer_codepoint:Some(CARTOUCHE_END),canonical_codepoints:oc.inner.clone(),render_codepoints:runes(&adapted.text),render_text:adapted.text,render_adapter_id:font.render_adapter_id.clone(),source_text:source.into(),source_kind:source_kind.into(),source_start:start,source_end:end,manual_tallies:manual,..FullRenderRun::default()};Ok(LogicalRun{run:r,graphic:g})
}

fn parse_size(v:&str,base:f64)->Option<f64>{let mut s=v.trim().to_ascii_lowercase();if s.is_empty(){return None;}let mut mul=1.0;if s.ends_with("em"){mul=base;s.truncate(s.len()-2);}else if s.ends_with("px"){s.truncate(s.len()-2);}s.parse::<f64>().ok().map(|x|x*mul)}
fn image_logical(seg:&DocumentSegment,font:&FullFontInfo,o:&FullRenderOptions)->Result<LogicalRun,RenderError>{let d=seg.image.clone().unwrap_or(ImageDescriptor{v_align:"baseline".into(),transparent:true,..ImageDescriptor::default()});let raw=decode_data_image(&d.src).unwrap_or_default();let mut iw=None;let mut ih=None;if !raw.is_empty(){if let Ok(img)=image::load_from_memory(&raw){let (w,h)=img.dimensions();iw=Some(w as f64);ih=Some(h as f64);}}let mut w=parse_size(&d.width,o.font_size);let mut h=parse_size(&d.height,o.font_size);if w.is_none()&&h.is_none(){h=Some(o.font_size);}if w.is_none(){w=Some(match(iw,ih,h){(Some(a),Some(b),Some(hh))if b!=0.0=>hh*a/b,(_,_,Some(hh))=>hh,_=>o.font_size});}if h.is_none(){h=Some(match(iw,ih,w){(Some(a),Some(b),Some(ww))if a!=0.0=>ww*b/a,(_,_,Some(ww))=>ww,_=>o.font_size});}let w=w.unwrap_or(1.0).max(1.0);let h=h.unwrap_or(1.0).max(1.0);let baseline=if d.v_align.eq_ignore_ascii_case("center"){h*0.75}else{h};let r=FullRenderRun{kind:"cartouche".into(),render_mode:"raster".into(),font_role:"cartouche".into(),render_adapter_id:font.render_adapter_id.clone(),source_kind:"image".into(),source_start:seg.source_start,source_end:seg.source_end,image_alt:d.alt.clone(),..FullRenderRun::default()};let g=FullGraphic{width:w,height:h,baseline,image_bytes:raw,image_href:d.src,..FullGraphic::default()};Ok(LogicalRun{run:r,graphic:g})}

fn is_integer(s:&str)->bool{let t=s.strip_prefix('+').unwrap_or(s);!t.is_empty()&&t.chars().all(|c|c.is_ascii_digit())}
fn has_digit(s:&str)->bool{s.chars().any(|c|c.is_ascii_digit())}

fn emit_core(source:&str,start:usize,end:usize,kind:&str,out:&mut Vec<LogicalRun>,font:&FullFontInfo,o:&FullRenderOptions)->Result<(),RenderError>{
    if all_runes_ucsur(source){out.push(glyph_logical(source,&runes(source),start,end,kind,font,o,false,false)?);return Ok(());}
    if let Some(parsed)=numeric_full_parse(source,&o.parser){if o.parser.nasin_nanpa_pona&&is_integer(source){for w in nasin_nanpa_pona_words(source.trim_start_matches('+')){if let Some(cp)=word_to_cp(&w){out.push(glyph_logical(source,&[cp],start,end,kind,font,o,false,false)?);}}return Ok(());}out.push(numeric_logical(source,&parsed,start,end,kind,font,o)?);return Ok(());}
    let mode=o.parser.effective_renderer_mode();if (mode=="sitelen-pona-ascii-extended"||mode=="sitelen-seli-kiwen")&&(source.contains('-')||source.contains('+')){let mut cps=Vec::new();let mut cur=String::new();let mut ok=true;for ch in source.chars(){if ch=='-'||ch=='+'{if !cur.is_empty(){if let Some(cp)=word_to_cp(&sanitize_word(&cur)){cps.push(cp);}else{ok=false;break;}cur.clear();}cps.push(if ch=='-'{STACK_JOINER_CODEPOINT}else{NEST_JOINER_CODEPOINT});}else{cur.push(ch);}}if ok&&!cur.is_empty(){if let Some(cp)=word_to_cp(&sanitize_word(&cur)){cps.push(cp);}else{ok=false;}}if ok&&!cps.is_empty(){out.push(glyph_logical(source,&cps,start,end,kind,font,o,false,false)?);return Ok(());}}
    if o.parser.auto_cartouche_standalone_proper_names&&source.chars().next().is_some_and(|c|c.is_uppercase()){if let Some(cps)=proper_name_codepoints(source){let oc=OrdinaryCartouche{manual_tallies:vec![0;cps.len()],inner:cps,tally_mode:"ucsur".into()};out.push(cartouche_logical(source,&oc,start,end,kind,font,o)?);return Ok(());}}
    if let Some(cp)=word_to_cp(&sanitize_word(source)){out.push(glyph_logical(source,&[cp],start,end,kind,font,o,false,false)?);return Ok(());}
    if o.parser.show_unknown_text{let mut lit=source.to_string();let mut ls=start;let mut le=end;if mode=="standard-sitelen-pona-ascii-core"&&lit.len()>=2&&lit.starts_with('\'')&&lit.ends_with('\''){lit=lit[1..lit.len()-1].to_string();ls+=1;le=le.saturating_sub(1);}out.push(literal_logical(&lit,ls,le,kind,font,o,false,false,true)?);}Ok(())
}

fn parse_text(text:&str,base:usize,kind:&str,out:&mut Vec<LogicalRun>,font:&FullFontInfo,o:&FullRenderOptions)->Result<(),RenderError>{
    if text.is_empty(){return Ok(());}let trim=text.trim();if trim.is_empty(){return Ok(());}let leading=text.find(trim).unwrap_or(0);
    if let Some(raw)=parse_raw_unicode_sequence(trim){out.push(glyph_logical(trim,&raw,base+leading,base+leading+trim.len(),kind,font,o,false,false)?);return Ok(());}
    if let Some(parsed)=numeric_full_parse(trim,&o.parser){if o.parser.nasin_nanpa_pona&&is_integer(trim){for w in nasin_nanpa_pona_words(trim.trim_start_matches('+')){if let Some(cp)=word_to_cp(&w){out.push(glyph_logical(trim,&[cp],base+leading,base+leading+trim.len(),kind,font,o,false,false)?);}}return Ok(());}out.push(numeric_logical(trim,&parsed,base+leading,base+leading+trim.len(),kind,font,o)?);return Ok(());}
    let mut offset=0usize;for token in text.split_whitespace(){let rel=text[offset..].find(token).unwrap_or(0);let mut start=base+offset+rel;let mut end=start+token.len();offset=offset+rel+token.len();let mut core=token;while core.starts_with('(')||core.starts_with('{'){core=&core[1..];start+=1;}let mut trail=String::new();while !core.is_empty(){let last=core.chars().last().unwrap();if !").;:!?}".contains(last){break;}if last=='.'&&has_digit(core){break;}trail.insert(0,last);core=&core[..core.len()-last.len_utf8()];end=end.saturating_sub(last.len_utf8());}if core.ends_with('.')&&core.len()>1&&has_digit(&core[..core.len()-1]){trail.insert(0,'.');core=&core[..core.len()-1];end=end.saturating_sub(1);}if !core.is_empty(){emit_core(core,start,end,kind,out,font,o)?;}let mut p=end;for c in trail.chars(){let cp=if c=='.'{Some(MIDDLE_DOT_CODEPOINT)}else if c==':'{Some(COLON_CODEPOINT)}else{None};if let Some(cp)=cp{out.push(glyph_logical(&c.to_string(),&[cp],p,p+c.len_utf8(),kind,font,o,false,false)?);}p+=c.len_utf8();}}
    Ok(())
}

fn parse_bracket(body:&str,source_start:usize,out:&mut Vec<LogicalRun>,font:&FullFontInfo,o:&FullRenderOptions)->Result<(),RenderError>{let trim=body.trim();let wrapped=format!("[{trim}]");if let Some(parsed)=numeric_full_parse(&wrapped,&o.parser){out.push(numeric_logical(trim,&parsed,source_start,source_start+body.len(),"bracket",font,o)?);return Ok(());}if let Some(oc)=parse_ordinary_body(trim,font,&o.parser){out.push(cartouche_logical(trim,&oc,source_start,source_start+body.len(),"bracket",font,o)?);return Ok(());}if o.parser.show_unknown_text{out.push(literal_logical(trim,source_start,source_start+body.len(),"bracket",font,o,false,false,true)?);}Ok(())}
fn parse_quote(seg:&DocumentSegment,out:&mut Vec<LogicalRun>,font:&FullFontInfo,o:&FullRenderOptions)->Result<(),RenderError>{let q=seg.value.replace("\\\"","\"").replace("\\\\","\\").replace("\\t","    ").replace("\\n","\n");if o.parser.interpret_double_quotes_as_te_to{out.push(glyph_logical("te",&[OPEN_QUOTE_CODEPOINT],seg.source_start,seg.source_start+1,"interpretedQuote",font,o,false,true)?);let before=out.len();parse_text(&q,seg.source_start+1,"interpretedQuote",out,font,o)?;for r in &mut out[before..]{r.run.interpreted_quote=true;}out.push(glyph_logical("to",&[CLOSE_QUOTE_CODEPOINT],seg.source_end.saturating_sub(1),seg.source_end,"interpretedQuote",font,o,false,true)?);}else{out.push(literal_logical(&q,seg.source_start,seg.source_end,"quote",font,o,true,false,false)?);}Ok(())}

impl NanpaLinjaN {
    fn prepare_full(&self,input:&str,options:&FullRenderOptions)->Result<PreparedFull,RenderError>{
        let o=normalize_options(options.clone());let registry=full_registry()?;let font=registry.get(&o.font).cloned().ok_or_else(||RenderError::UnknownFont(format!("unknown production font: {}",o.font)))?;let ast=parse_full_document(input,&o.parser);let mut logical_lines:Vec<Vec<LogicalRun>>=Vec::with_capacity(ast.lines.len());let mut first_parsed=None;let mut any_abbr=false;
        for line in &ast.lines{let mut runs=Vec::new();for seg in &line.children{match seg.kind.as_str(){"text"=>parse_text(&seg.value,seg.source_start,"text",&mut runs,&font,&o)?,"bracket"=>parse_bracket(&seg.value,seg.source_start,&mut runs,&font,&o)?,"quote"=>parse_quote(seg,&mut runs,&font,&o)?,"image"=>runs.push(image_logical(seg,&font,&o)?),_=>{}}}for l in &runs{if l.run.numeric_cartouche&&first_parsed.is_none(){first_parsed=numeric_full_parse(&l.run.source_text,&o.parser);}if l.run.numeric_cartouche&&o.parser.abbreviate_numeric_cartouches{any_abbr=true;}}logical_lines.push(runs);}
        let line_gap=o.layout.line_gap(o.font_size);let pad=o.padding_px as f64;let mut line_widths=vec![0.0;logical_lines.len()];let mut line_asc=vec![0.0;logical_lines.len()];let mut line_desc=vec![0.0;logical_lines.len()];let mut maxw:f64=0.0;
        for (i,line) in logical_lines.iter().enumerate(){let mut x=0.0;let mut asc:f64=0.0;let mut desc:f64=0.0;let mut first=true;for l in line{if !first{x+=if l.run.font_role=="cartouche"||l.run.numeric_cartouche{o.layout.cartouche_lead_gap(o.font_size)}else{o.layout.glyph_gap(o.font_size)};}first=false;x+=l.graphic.width;asc=asc.max(l.graphic.baseline);desc=desc.max((l.graphic.height-l.graphic.baseline).max(0.0));}let h=o.font_size.max(asc+desc);if line.is_empty(){asc=o.font_size*0.82;desc=h-asc;}line_widths[i]=x;line_asc[i]=asc;line_desc[i]=desc;maxw=maxw.max(x);}
        let width=(maxw+2.0*pad).ceil().max(1.0) as u32;let mut total=2.0*pad+line_gap*((logical_lines.len().saturating_sub(1))as f64);for i in 0..logical_lines.len(){total+=o.font_size.max(line_asc[i]+line_desc[i]);}let height=total.ceil().max(1.0) as u32;
        let mut all_runs=Vec::new();let mut line_plans=Vec::new();let mut placed=Vec::new();let mut y=pad;
        for (li,line) in logical_lines.into_iter().enumerate(){let lw=line_widths[li];let asc=line_asc[li];let desc=line_desc[li];let lh=o.font_size.max(asc+desc);let mut x=pad;match o.layout.align.to_ascii_lowercase().as_str(){"center"=>x+=(maxw-lw)/2.0,"right"=>x+=maxw-lw,_=>{}}let line_start=x;let mut lr=Vec::new();let mut first=true;for (ri,mut l) in line.into_iter().enumerate(){if !first{x+=if l.run.font_role=="cartouche"||l.run.numeric_cartouche{o.layout.cartouche_lead_gap(o.font_size)}else{o.layout.glyph_gap(o.font_size)};}first=false;let ty=y+asc-l.graphic.baseline;let tx=x;l.run.id=format!("L{li}R{ri}");l.run.line_index=li;l.run.run_index=ri;l.run.x_px=tx;l.run.y_px=ty;l.run.width_px=l.graphic.width;l.run.height_px=l.graphic.height;l.run.baseline_y_px=y+asc;if !l.graphic.tally_groups.is_empty(){l.run.tally_groups=l.graphic.tally_groups.iter().cloned().map(|mut g|{g.owner_left_px+=tx;g.owner_right_px+=tx;g.center_x_px+=tx;g.top_y_px+=ty;g.bottom_y_px+=ty;for c in &mut g.stroke_centers_px{*c+=tx;}g}).collect();}let r=l.run.clone();placed.push(l);all_runs.push(r.clone());lr.push(r);x+=all_runs.last().unwrap().width_px;}
            line_plans.push(FullRenderLinePlan{line_index:li,source_line_index:ast.lines[li].source_line_index,sentence_index_in_source_line:ast.lines[li].sentence_index_in_source_line,x_px:line_start,y_px:y,width_px:lw,height_px:lh,baseline_y_px:y+asc,ascent_px:asc,descent_px:desc,runs:lr});y+=lh;if li+1<ast.lines.len(){y+=line_gap;}}
        let plan=FullRenderPlan{input:input.into(),font_key:font.key.clone(),abbreviated:any_abbr,width,height,open_type_features:full_open_type_features_for(o.font_size),runs:all_runs,parsed:first_parsed,diagnostics:vec![],ast:ast.clone(),lines:line_plans};Ok(PreparedFull{plan,placed,options:o})
    }
    pub fn build_full_render_plan(&self,input:&str,options:&FullRenderOptions)->Result<FullRenderPlan,RenderError>{Ok(self.prepare_full(input,options)?.plan)}
}

fn blend(dst:&mut [u8],src:[u8;4],coverage:u8){let sa=(src[3]as u32*coverage as u32+127)/255;let da=dst[3]as u32;let inv=255-sa;let oa=sa+(da*inv+127)/255;if oa==0{dst.copy_from_slice(&[0,0,0,0]);return;}for c in 0..3{let sp=src[c]as u32*sa;let dp=dst[c]as u32*da;let op=sp+(dp*inv+127)/255;dst[c]=((op+oa/2)/oa).min(255)as u8;}dst[3]=oa.min(255)as u8;}
fn put_pixel(rgba:&mut[u8],w:u32,h:u32,x:i32,y:i32,color:[u8;4],coverage:u8){if x<0||y<0||x>=w as i32||y>=h as i32{return;}let i=(y as usize*w as usize+x as usize)*4;blend(&mut rgba[i..i+4],color,coverage);}
fn draw_line(rgba:&mut[u8],w:u32,h:u32,x:f64,y1:f64,y2:f64,width:f64,color:[u8;4]){let left=(x-width/2.0).floor()as i32;let right=(x+width/2.0).ceil()as i32;let top=y1.min(y2).floor()as i32;let bottom=y1.max(y2).ceil()as i32;for yy in top..=bottom{for xx in left..=right{put_pixel(rgba,w,h,xx,yy,color,255);}}}
fn draw_rect(rgba:&mut[u8],w:u32,h:u32,x:f64,y:f64,rw:f64,rh:f64,lw:f64,color:[u8;4]){let n=lw.ceil().max(1.0)as i32;for k in 0..n{let x0=(x+k as f64).round()as i32;let y0=(y+k as f64).round()as i32;let x1=(x+rw-k as f64).round()as i32;let y1=(y+rh-k as f64).round()as i32;for xx in x0..=x1{put_pixel(rgba,w,h,xx,y0,color,255);put_pixel(rgba,w,h,xx,y1,color,255);}for yy in y0..=y1{put_pixel(rgba,w,h,x0,yy,color,255);put_pixel(rgba,w,h,x1,yy,color,255);}}}
fn draw_shaped(rgba:&mut[u8],w:u32,h:u32,sh:&ShapedText,x:f64,y:f64,color:[u8;4],halo:Option<([u8;4],f64)>){if let Some((hc,hw))=halo{let r=hw.ceil()as i32;for g in &sh.glyphs{let gx=(x+sh.origin_x+g.left).round()as i32;let gy=(y+sh.origin_y+g.top).round()as i32;for row in 0..g.height{for col in 0..g.width{let cov=g.bitmap[row*g.width+col];if cov==0{continue;}for oy in -r..=r{for ox in -r..=r{if ox*ox+oy*oy<=r*r{put_pixel(rgba,w,h,gx+col as i32+ox,gy+row as i32+oy,hc,cov);}}}}}}}for g in &sh.glyphs{let gx=(x+sh.origin_x+g.left).round()as i32;let gy=(y+sh.origin_y+g.top).round()as i32;for row in 0..g.height{for col in 0..g.width{let cov=g.bitmap[row*g.width+col];if cov>0{put_pixel(rgba,w,h,gx+col as i32,gy+row as i32,color,cov);}}}}}
fn draw_shaped_halo_only(rgba:&mut[u8],w:u32,h:u32,sh:&ShapedText,x:f64,y:f64,color:[u8;4],halo_width:f64){let r=halo_width.ceil()as i32;for g in &sh.glyphs{let gx=(x+sh.origin_x+g.left).round()as i32;let gy=(y+sh.origin_y+g.top).round()as i32;for row in 0..g.height{for col in 0..g.width{let cov=g.bitmap[row*g.width+col];if cov==0{continue;}for oy in -r..=r{for ox in -r..=r{if ox*ox+oy*oy<=r*r{put_pixel(rgba,w,h,gx+col as i32+ox,gy+row as i32+oy,color,cov);}}}}}}}
fn draw_shaped_foreground_only(rgba:&mut[u8],w:u32,h:u32,sh:&ShapedText,x:f64,y:f64,color:[u8;4]){for g in &sh.glyphs{let gx=(x+sh.origin_x+g.left).round()as i32;let gy=(y+sh.origin_y+g.top).round()as i32;for row in 0..g.height{for col in 0..g.width{let cov=g.bitmap[row*g.width+col];if cov>0{put_pixel(rgba,w,h,gx+col as i32,gy+row as i32,color,cov);}}}}}
fn fill_rounded_rect(rgba:&mut[u8],w:u32,h:u32,x:f64,y:f64,rw:f64,rh:f64,radius:f64,color:[u8;4]){if rw<=0.0||rh<=0.0{return;}let r=radius.max(0.0).min(rw/2.0).min(rh/2.0);let left=x.floor()as i32;let right=(x+rw).ceil()as i32-1;let top=y.floor()as i32;let bottom=(y+rh).ceil()as i32-1;for yy in top..=bottom{for xx in left..=right{let px=xx as f64+0.5;let py=yy as f64+0.5;if px<x||px>x+rw||py<y||py>y+rh{continue;}let cx=px.max(x+r).min(x+rw-r);let cy=py.max(y+r).min(y+rh-r);let dx=px-cx;let dy=py-cy;if dx*dx+dy*dy<=r*r{put_pixel(rgba,w,h,xx,yy,color,255);}}}}
fn draw_tally_group_halo(rgba:&mut[u8],w:u32,h:u32,tg:&TallyGroup,font_size:f64,halo_width:f64,color:[u8;4]){let Some(first)=tg.stroke_centers_px.first()else{return;};let Some(last)=tg.stroke_centers_px.last()else{return;};let pad_x=halo_width*0.85;let pad_bottom=halo_width*0.85;let radius=1.25_f64.max(halo_width.min(font_size.max(8.0)*0.045));let left=*first-tg.stroke_width_px/2.0;let right=*last+tg.stroke_width_px/2.0;let top=tg.top_y_px;let bottom=tg.bottom_y_px;fill_rounded_rect(rgba,w,h,left-pad_x,top,(right-left)+pad_x*2.0,((bottom-top)+pad_bottom).max(1.0),radius,color);}

fn render_prepared_rgba(prep:&PreparedFull)->Result<Vec<u8>,RenderError>{let w=prep.plan.width;let h=prep.plan.height;let mut rgba=vec![0u8;w as usize*h as usize*4];let fg=rgba_hex(&prep.options.paint.fill_style,[0,0,0,255]);let halo=if prep.options.paint.halo_enabled{Some((rgba_hex(&prep.options.paint.halo_color,[255,255,255,255]),if prep.options.paint.halo_width_px>0.0{prep.options.paint.halo_width_px}else{(prep.options.font_size*0.10).round().clamp(2.0,24.0)}))}else{None};for l in &prep.placed{let r=&l.run;let g=&l.graphic;if !g.image_bytes.is_empty(){if let Ok(img)=image::load_from_memory(&g.image_bytes){let src=img.to_rgba8();let sw=src.width().max(1);let sh=src.height().max(1);let tw=g.width.round().max(1.0)as u32;let th=g.height.round().max(1.0)as u32;for yy in 0..th{for xx in 0..tw{let sx=(xx as u64*sw as u64/tw as u64)as u32;let sy=(yy as u64*sh as u64/th as u64)as u32;let p=src.get_pixel(sx.min(sw-1),sy.min(sh-1)).0;put_pixel(&mut rgba,w,h,(r.x_px+xx as f64)as i32,(r.y_px+yy as f64)as i32,p,255);}}}}else if !g.text.is_empty(){let bytes=bundled_full_font_bytes(&g.font_filename).ok_or_else(||RenderError::Font(format!("missing {}",g.font_filename)))?;let sh=shape_text(&g.text,bytes,prep.options.font_size,&g.features,if r.font_role=="cartouche"||r.numeric_cartouche{6.0}else{0.0},if !r.tally_groups.is_empty(){(prep.options.font_size*0.34).ceil()}else{0.0})?;if !r.tally_groups.is_empty(){if let Some((hc,hw))=halo{draw_shaped_halo_only(&mut rgba,w,h,&sh,r.x_px,r.y_px,hc,hw);for tg in &r.tally_groups{draw_tally_group_halo(&mut rgba,w,h,tg,prep.options.font_size,hw,hc);}draw_shaped_foreground_only(&mut rgba,w,h,&sh,r.x_px,r.y_px,fg);}else{draw_shaped(&mut rgba,w,h,&sh,r.x_px,r.y_px,fg,None);}}else{draw_shaped(&mut rgba,w,h,&sh,r.x_px,r.y_px,fg,halo);}}for tg in &r.tally_groups{for cx in &tg.stroke_centers_px{draw_line(&mut rgba,w,h,*cx,tg.top_y_px,tg.bottom_y_px,tg.stroke_width_px,fg);}}if r.unrecognized&&g.unknown_decoration{let uc=rgba_hex(&prep.options.paint.unknown_text.color,[0,0,0,255]);draw_rect(&mut rgba,w,h,r.x_px,r.y_px,g.width,g.height,prep.options.paint.unknown_text.line_width_px.max(1.0),uc);}}Ok(rgba)}
fn encode_png_rgba(rgba:&[u8],w:u32,h:u32)->Result<Vec<u8>,RenderError>{let mut out=Vec::new();PngEncoder::new(&mut out).write_image(rgba,w,h,ColorType::Rgba8.into()).map_err(|e|RenderError::Image(format!("PNG: {e}")))?;Ok(out)}

fn base64_encode(bytes:&[u8])->String{
    const TABLE:&[u8;64]=b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut out=String::with_capacity(((bytes.len()+2)/3)*4);let mut i=0usize;
    while i+3<=bytes.len(){let n=((bytes[i]as u32)<<16)|((bytes[i+1]as u32)<<8)|bytes[i+2]as u32;out.push(TABLE[((n>>18)&63)as usize]as char);out.push(TABLE[((n>>12)&63)as usize]as char);out.push(TABLE[((n>>6)&63)as usize]as char);out.push(TABLE[(n&63)as usize]as char);i+=3;}
    match bytes.len()-i{1=>{let n=(bytes[i]as u32)<<16;out.push(TABLE[((n>>18)&63)as usize]as char);out.push(TABLE[((n>>12)&63)as usize]as char);out.push('=');out.push('=');},2=>{let n=((bytes[i]as u32)<<16)|((bytes[i+1]as u32)<<8);out.push(TABLE[((n>>18)&63)as usize]as char);out.push(TABLE[((n>>12)&63)as usize]as char);out.push(TABLE[((n>>6)&63)as usize]as char);out.push('=');},_=>{}}
    out
}
fn xml_escape(s:&str)->String{s.replace('&',"&amp;").replace('<',"&lt;").replace('>',"&gt;").replace('"',"&quot;").replace('\'',"&apos;")}
fn svg_color(hex:&str)->String{let c=rgba_hex(hex,[0,0,0,255]);format!("rgb({},{},{})",c[0],c[1],c[2])}
fn mime_for_font(filename:&str)->&'static str{if filename.to_ascii_lowercase().ends_with(".ttf"){"font/ttf"}else{"font/otf"}}

fn svg_from_prepared(prep:&PreparedFull)->Result<String,RenderError>{
    let mut css=String::new();let mut families:BTreeMap<String,String>=BTreeMap::new();
    for (i,l) in prep.placed.iter().enumerate(){let f=&l.graphic.font_filename;if f.is_empty()||families.contains_key(f){continue;}let Some(bytes)=bundled_full_font_bytes(f)else{continue};let fam=format!("NLNFullFont{}",i);css.push_str(&format!("@font-face{{font-family:'{}';src:url(data:{};base64,{});}}",fam,mime_for_font(f),base64_encode(bytes)));families.insert(f.clone(),fam);}
    let fg=svg_color(&prep.options.paint.fill_style);let halo=svg_color(&prep.options.paint.halo_color);let mut body=String::new();
    // A harmless path keeps the SVG compatible with consumers that expect a path-capable vector surface.
    body.push_str("<path d=\"M0 0\" fill=\"none\"/>");
    for l in &prep.placed{let r=&l.run;let g=&l.graphic;let manual_halo=prep.options.paint.halo_enabled&&!r.tally_groups.is_empty();let hw=if prep.options.paint.halo_width_px>0.0{prep.options.paint.halo_width_px}else{(prep.options.font_size*0.10).round().clamp(2.0,24.0)};let mut text_parts:Option<(String,String)>=None;if !g.image_bytes.is_empty(){let mime=if g.image_bytes.starts_with(b"\x89PNG"){"image/png"}else if g.image_bytes.starts_with(b"\xFF\xD8"){"image/jpeg"}else{"application/octet-stream"};body.push_str(&format!("<image x=\"{:.3}\" y=\"{:.3}\" width=\"{:.3}\" height=\"{:.3}\" href=\"data:{};base64,{}\"/>",r.x_px,r.y_px,g.width,g.height,mime,base64_encode(&g.image_bytes)));}else if !g.text.is_empty(){let fam=families.get(&g.font_filename).cloned().unwrap_or_else(||"sans-serif".into());let features=if g.features.is_empty(){String::new()}else{g.features.iter().map(|x|format!("'{}' 1",x)).collect::<Vec<_>>().join(",")};if manual_halo{body.push_str(&format!("<text x=\"{:.3}\" y=\"{:.3}\" font-family=\"{}\" font-size=\"{:.3}px\" font-feature-settings=\"{}\" fill=\"none\" stroke=\"{}\" stroke-width=\"{:.3}\" style=\"stroke-linejoin:round;\">{}</text>",r.x_px+g.origin_x,r.y_px+g.baseline,xml_escape(&fam),prep.options.font_size,xml_escape(&features),halo,2.0*hw,xml_escape(&g.text)));text_parts=Some((fam,features));}else{let halo_style=if prep.options.paint.halo_enabled{format!("stroke:{};stroke-width:{:.3};paint-order:stroke fill;stroke-linejoin:round;",halo,2.0*hw)}else{String::new()};body.push_str(&format!("<text x=\"{:.3}\" y=\"{:.3}\" font-family=\"{}\" font-size=\"{:.3}px\" font-feature-settings=\"{}\" fill=\"{}\" style=\"{}\">{}</text>",r.x_px+g.origin_x,r.y_px+g.baseline,xml_escape(&fam),prep.options.font_size,xml_escape(&features),fg,halo_style,xml_escape(&g.text)));}}
        if manual_halo{for tg in &r.tally_groups{let Some(first)=tg.stroke_centers_px.first()else{continue;};let Some(last)=tg.stroke_centers_px.last()else{continue;};let pad_x=hw*0.85;let pad_bottom=hw*0.85;let radius=1.25_f64.max(hw.min(prep.options.font_size.max(8.0)*0.045));let left=*first-tg.stroke_width_px/2.0;let right=*last+tg.stroke_width_px/2.0;let height=((tg.bottom_y_px-tg.top_y_px)+pad_bottom).max(1.0);body.push_str(&format!("<rect x=\"{:.3}\" y=\"{:.3}\" width=\"{:.3}\" height=\"{:.3}\" rx=\"{:.3}\" ry=\"{:.3}\" fill=\"{}\"/>",left-pad_x,tg.top_y_px,(right-left)+pad_x*2.0,height,radius,radius,halo));}if let Some((fam,features))=text_parts{body.push_str(&format!("<text x=\"{:.3}\" y=\"{:.3}\" font-family=\"{}\" font-size=\"{:.3}px\" font-feature-settings=\"{}\" fill=\"{}\">{}</text>",r.x_px+g.origin_x,r.y_px+g.baseline,xml_escape(&fam),prep.options.font_size,xml_escape(&features),fg,xml_escape(&g.text)));}}
        for tg in &r.tally_groups{for cx in &tg.stroke_centers_px{body.push_str(&format!("<path d=\"M {:.3} {:.3} L {:.3} {:.3}\" stroke=\"{}\" stroke-width=\"{:.3}\" stroke-linecap=\"butt\" fill=\"none\"/>",cx,tg.top_y_px,cx,tg.bottom_y_px,fg,tg.stroke_width_px));}}
        if r.unrecognized&&g.unknown_decoration{body.push_str(&format!("<rect x=\"{:.3}\" y=\"{:.3}\" width=\"{:.3}\" height=\"{:.3}\" fill=\"none\" stroke=\"{}\" stroke-width=\"{:.3}\"/>",r.x_px,r.y_px,g.width,g.height,svg_color(&prep.options.paint.unknown_text.color),prep.options.paint.unknown_text.line_width_px.max(1.0)));}
    }
    Ok(format!("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{}\" height=\"{}\" viewBox=\"0 0 {} {}\"><style>{}</style>{}</svg>",prep.plan.width,prep.plan.height,prep.plan.width,prep.plan.height,css,body))
}

fn raster_pdf(rgba:&[u8],w:u32,h:u32)->Vec<u8>{
    let mut rgb=Vec::with_capacity((w as usize)*(h as usize)*3);for p in rgba.chunks_exact(4){let a=p[3]as u32;for c in 0..3{let v=(p[c]as u32*a+255*(255-a)+127)/255;rgb.push(v as u8);}}
    let content=format!("q\n{} 0 0 -{} 0 {} cm\n/Im0 Do\nQ\n",w,h,h);let mut out=Vec::<u8>::new();out.extend_from_slice(b"%PDF-1.4\n%\xE2\xE3\xCF\xD3\n");let mut offsets=vec![0usize];
    fn obj(out:&mut Vec<u8>,offsets:&mut Vec<usize>,n:usize,head:&str,stream:Option<&[u8]>){while offsets.len()<=n{offsets.push(0);}offsets[n]=out.len();out.extend_from_slice(format!("{} 0 obj\n{}",n,head).as_bytes());if let Some(data)=stream{out.extend_from_slice(b"\nstream\n");out.extend_from_slice(data);out.extend_from_slice(b"\nendstream");}out.extend_from_slice(b"\nendobj\n");}
    obj(&mut out,&mut offsets,1,"<< /Type /Catalog /Pages 2 0 R >>",None);obj(&mut out,&mut offsets,2,"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",None);obj(&mut out,&mut offsets,3,&format!("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {} {}] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>",w,h),None);obj(&mut out,&mut offsets,4,&format!("<< /Type /XObject /Subtype /Image /Width {} /Height {} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Length {} >>",w,h,rgb.len()),Some(&rgb));obj(&mut out,&mut offsets,5,&format!("<< /Length {} >>",content.as_bytes().len()),Some(content.as_bytes()));
    let xref=out.len();out.extend_from_slice(format!("xref\n0 {}\n0000000000 65535 f \n",offsets.len()).as_bytes());for off in offsets.iter().skip(1){out.extend_from_slice(format!("{:010} 00000 n \n",off).as_bytes());}out.extend_from_slice(format!("trailer\n<< /Size {} /Root 1 0 R >>\nstartxref\n{}\n%%EOF\n",offsets.len(),xref).as_bytes());out
}

fn graphic_for_public_run(run:&FullRenderRun,font:&FullFontInfo,o:&FullRenderOptions)->Result<FullGraphic,RenderError>{
    if run.font_role=="literal"{return make_graphic(&run.render_text,"PatrickHand-Regular.ttf",o.font_size,&[],0.0,0.0);}
    let filename=if run.font_role=="number"{&font.companion_filename}else{&font.base_filename};let features=if run.font_role=="number"{full_open_type_features_for(o.font_size)}else{vec![]};let pad=if run.font_role=="cartouche"||run.numeric_cartouche{6.0}else{0.0};make_graphic(&run.render_text,filename,o.font_size,&features,pad,0.0)
}

impl NanpaLinjaN{
    pub fn render_to_canvas(&self,input:&str,options:&FullRenderOptions)->Result<FullCanvasResult,RenderError>{let prep=self.prepare_full(input,options)?;let rgba=render_prepared_rgba(&prep)?;Ok(FullCanvasResult{width:prep.plan.width,height:prep.plan.height,rgba,plan:if prep.options.include_plan{Some(prep.plan.clone())}else{None},font_key:prep.plan.font_key.clone()})}
    pub fn render_full_to_png(&self,input:&str,options:&FullRenderOptions)->Result<Vec<u8>,RenderError>{let c=self.render_to_canvas(input,options)?;encode_png_rgba(&c.rgba,c.width,c.height)}
    pub fn render_full_to_svg(&self,input:&str,options:&FullRenderOptions)->Result<String,RenderError>{svg_from_prepared(&self.prepare_full(input,options)?) }
    pub fn render_full_to_pdf(&self,input:&str,options:&FullRenderOptions)->Result<Vec<u8>,RenderError>{let c=self.render_to_canvas(input,options)?;Ok(raster_pdf(&c.rgba,c.width,c.height))}
    pub fn render_run_to_new_canvas(&self,run:&FullRenderRun,options:&FullRenderOptions)->Result<FullCanvasResult,RenderError>{let o=normalize_options(options.clone());let registry=full_registry()?;let font=registry.get(&o.font).cloned().ok_or_else(||RenderError::UnknownFont(o.font.clone()))?;let g=graphic_for_public_run(run,&font,&o)?;let mut rr=run.clone();rr.id="L0R0".into();rr.line_index=0;rr.run_index=0;rr.x_px=o.padding_px as f64;rr.y_px=o.padding_px as f64;rr.width_px=g.width;rr.height_px=g.height;rr.baseline_y_px=rr.y_px+g.baseline;let width=(g.width+2.0*o.padding_px as f64).ceil().max(1.0)as u32;let height=(g.height+2.0*o.padding_px as f64).ceil().max(1.0)as u32;let plan=FullRenderPlan{input:run.source_text.clone(),font_key:font.key.clone(),width,height,runs:vec![rr.clone()],lines:vec![FullRenderLinePlan{line_index:0,source_line_index:0,sentence_index_in_source_line:0,x_px:rr.x_px,y_px:rr.y_px,width_px:g.width,height_px:g.height,baseline_y_px:rr.baseline_y_px,ascent_px:g.baseline,descent_px:(g.height-g.baseline).max(0.0),runs:vec![rr.clone()]}],..FullRenderPlan::default()};let prep=PreparedFull{plan:plan.clone(),placed:vec![LogicalRun{run:rr,graphic:g}],options:o.clone()};let rgba=render_prepared_rgba(&prep)?;Ok(FullCanvasResult{width,height,rgba,plan:if o.include_plan{Some(plan)}else{None},font_key:font.key})}
    pub fn render_text_to_new_canvas(&self,text:&str,options:&FullRenderOptions)->Result<FullCanvasResult,RenderError>{self.render_to_canvas(text,options)}
    pub fn render_text_to_canvas(&self,target:&mut [u8],target_width:u32,target_height:u32,x:i32,y:i32,text:&str,options:&FullRenderOptions)->Result<FullRenderPlan,RenderError>{let c=self.render_text_to_new_canvas(text,options)?;for yy in 0..c.height as i32{for xx in 0..c.width as i32{let tx=x+xx;let ty=y+yy;if tx<0||ty<0||tx>=target_width as i32||ty>=target_height as i32{continue;}let si=((yy as u32*c.width+xx as u32)*4)as usize;let di=((ty as u32*target_width+tx as u32)*4)as usize;if si+4<=c.rgba.len()&&di+4<=target.len(){let px=[c.rgba[si],c.rgba[si+1],c.rgba[si+2],c.rgba[si+3]];blend(&mut target[di..di+4],px,255);}}}c.plan.ok_or_else(||RenderError::Image("render plan disabled".into()))}
    pub fn render_ucsur_to_new_canvas(&self,lines:&[Vec<u32>],options:&FullRenderOptions)->Result<FullCanvasResult,RenderError>{let text=lines.iter().map(|line|line.iter().filter_map(|cp|char::from_u32(*cp)).collect::<String>()).collect::<Vec<_>>().join("\n");self.render_to_canvas(&text,options)}
    pub fn render_ucsur_to_canvas(&self,target:&mut[u8],target_width:u32,target_height:u32,x:i32,y:i32,lines:&[Vec<u32>],options:&FullRenderOptions)->Result<FullRenderPlan,RenderError>{let text=lines.iter().map(|line|line.iter().filter_map(|cp|char::from_u32(*cp)).collect::<String>()).collect::<Vec<_>>().join("\n");self.render_text_to_canvas(target,target_width,target_height,x,y,&text,options)}
    pub fn to_vector_document(&self,input:&str,options:&FullRenderOptions)->Result<VectorDocument,RenderError>{let prep=self.prepare_full(input,options)?;let mut elements=Vec::new();for l in &prep.placed{let r=&l.run;let g=&l.graphic;if !g.image_bytes.is_empty(){elements.push(VectorElement{kind:"image".into(),run_id:r.id.clone(),href:g.image_href.clone(),x:r.x_px,y:r.y_px,width:g.width,height:g.height,..VectorElement::default()});}else{elements.push(VectorElement{kind:"text".into(),run_id:r.id.clone(),text:g.text.clone(),fill:prep.options.paint.fill_style.clone(),x:r.x_px+g.origin_x,y:r.y_px+g.baseline,width:g.width,height:g.height,..VectorElement::default()});}for tg in &r.tally_groups{for cx in &tg.stroke_centers_px{elements.push(VectorElement{kind:"path".into(),run_id:r.id.clone(),path:format!("M {:.3} {:.3} L {:.3} {:.3}",cx,tg.top_y_px,cx,tg.bottom_y_px),fill:prep.options.paint.fill_style.clone(),x:*cx,y:tg.top_y_px,width:tg.stroke_width_px,height:tg.bottom_y_px-tg.top_y_px,..VectorElement::default()});}}}Ok(VectorDocument{width:prep.plan.width,height:prep.plan.height,elements,diagnostics:prep.plan.diagnostics.clone(),plan:prep.plan})}
}
