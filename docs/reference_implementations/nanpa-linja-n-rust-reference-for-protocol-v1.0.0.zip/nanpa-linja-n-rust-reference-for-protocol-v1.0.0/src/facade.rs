//! High-level production rendering facade.
//!
//! This is intentionally a thin composition layer over the frozen Core-v1
//! parser plus the Production-Font-Profile-v1 manifest/adapters.  The caller
//! supplies ordinary numeric input and, optionally, a production font key.
//! Font selection, canonical UCSUR, legacy adaptation, OpenType shaping and
//! PNG/SVG output are handled by the crate.

use std::fmt;
use std::fs;
use std::path::{Path, PathBuf};
use std::str::FromStr;

use fontdue::{Font, FontSettings};
use harfrust::{Direction, Feature, FontRef, ShapeOptions, ShaperData, UnicodeBuffer};
use image::codecs::png::PngEncoder;
use image::{ColorType, ImageEncoder};

use crate::font_adapters::{adapt_numeric_cartouche, AdaptedRun};
use crate::font_registry::{FontInfo, FontRegistry};
use crate::model::ParseResult;
use crate::options::ParseOptions;
use crate::parser::parse_number;
use crate::protocol::{CARTOUCHE_END, CARTOUCHE_START};

pub const DEFAULT_FONT_KEY: &str = "nasinNanpa";
pub const DEFAULT_FONT_SIZE: u32 = 56;
pub const DEFAULT_OUTER_PADDING: u32 = 4;

const NANPA: u32 = 0xF193D;
const NASA: u32 = 0xF193E;
const NOKA: u32 = 0xF1943;
const TENPO: u32 = 0xF196B;
const SUNO: u32 = 0xF1964;
const TOKI: u32 = 0xF196C;
const COLON: u32 = 0xF199D;
const NENA: u32 = 0xF1940;
const E: u32 = 0xF1909;
const EN: u32 = 0xF190A;
const OPEN: u32 = 0xF1947;
const ALA: u32 = 0xF1902;
const IKE: u32 = 0xF190D;
const UTA: u32 = 0xF1970;

#[derive(Debug)]
pub enum RenderError {
    InvalidInput(String),
    UnknownFont(String),
    Manifest(String),
    Adapter(String),
    Font(String),
    Shaping(String),
    Image(String),
    Io(std::io::Error),
}

impl fmt::Display for RenderError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidInput(message)
            | Self::UnknownFont(message)
            | Self::Manifest(message)
            | Self::Adapter(message)
            | Self::Font(message)
            | Self::Shaping(message)
            | Self::Image(message) => write!(f, "{message}"),
            Self::Io(err) => write!(f, "{err}"),
        }
    }
}

impl std::error::Error for RenderError {}

impl From<std::io::Error> for RenderError {
    fn from(value: std::io::Error) -> Self { Self::Io(value) }
}

#[derive(Debug, Clone)]
pub struct RenderOptions {
    pub font: String,
    pub font_size: u32,
    pub abbreviate: bool,
    pub preserve_numeric_cartouche_breaks: bool,
    pub outer_padding: u32,
    pub foreground: [u8; 4],
    pub background: [u8; 4],
    pub parser_options: ParseOptions,
}

impl Default for RenderOptions {
    fn default() -> Self {
        Self {
            font: DEFAULT_FONT_KEY.to_string(),
            font_size: DEFAULT_FONT_SIZE,
            abbreviate: false,
            preserve_numeric_cartouche_breaks: true,
            outer_padding: DEFAULT_OUTER_PADDING,
            foreground: [0, 0, 0, 255],
            background: [0, 0, 0, 0],
            parser_options: ParseOptions::default(),
        }
    }
}

#[derive(Debug, Clone)]
pub struct RenderPlan {
    pub input: String,
    pub parsed: ParseResult,
    pub font: FontInfo,
    pub canonical_codepoints: Vec<u32>,
    pub render_text: String,
    pub render_codepoints: Vec<u32>,
    pub render_adapter_id: String,
    pub legacy_ascii: bool,
    pub font_size: u32,
    pub outer_padding: u32,
    pub open_type_features: Vec<String>,
    pub abbreviated: bool,
    pub preserve_numeric_cartouche_breaks: bool,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RenderedImage {
    pub width: u32,
    pub height: u32,
    pub rgba: Vec<u8>,
}

#[derive(Debug, Clone)]
pub struct RenderResult {
    pub image: RenderedImage,
    pub plan: RenderPlan,
}

impl RenderResult {
    pub fn width(&self) -> u32 { self.image.width }
    pub fn height(&self) -> u32 { self.image.height }
    pub fn font_key(&self) -> &str { &self.plan.font.key }
    pub fn render_adapter_id(&self) -> &str { &self.plan.render_adapter_id }

    pub fn png_bytes(&self) -> Result<Vec<u8>, RenderError> {
        encode_png(&self.image)
    }

    pub fn save_png(&self, path: impl AsRef<Path>) -> Result<PathBuf, RenderError> {
        let target = path.as_ref();
        if let Some(parent) = target.parent() {
            if !parent.as_os_str().is_empty() {
                fs::create_dir_all(parent)?;
            }
        }
        fs::write(target, self.png_bytes()?)?;
        Ok(target.to_path_buf())
    }
}

#[derive(Debug, Clone)]
pub struct SvgResult {
    pub svg: String,
    pub plan: RenderPlan,
    pub width: u32,
    pub height: u32,
}

impl SvgResult {
    pub fn save_svg(&self, path: impl AsRef<Path>) -> Result<PathBuf, RenderError> {
        let target = path.as_ref();
        if let Some(parent) = target.parent() {
            if !parent.as_os_str().is_empty() {
                fs::create_dir_all(parent)?;
            }
        }
        fs::write(target, self.svg.as_bytes())?;
        Ok(target.to_path_buf())
    }
}

#[derive(Debug, Clone)]
pub struct NanpaLinjaN {
    registry: FontRegistry,
}

impl NanpaLinjaN {
    pub fn create() -> Result<Self, RenderError> { Self::new() }

    pub fn new() -> Result<Self, RenderError> {
        Ok(Self {
            registry: FontRegistry::bundled().map_err(RenderError::Manifest)?,
        })
    }

    pub fn list_fonts(&self) -> Vec<FontInfo> { self.registry.list().to_vec() }

    pub fn get_font_info(&self, font: &str) -> Result<FontInfo, RenderError> {
        self.registry
            .get(font)
            .cloned()
            .ok_or_else(|| RenderError::UnknownFont(format!("unknown production font: {font}")))
    }

    pub fn parse(&self, input: &str, options: &ParseOptions) -> Result<ParseResult, RenderError> {
        parse_number(input, options).ok_or_else(|| {
            RenderError::InvalidInput(format!("not a valid nanpa-linja-n numeric input: {input:?}"))
        })
    }

    pub fn build_render_plan(
        &self,
        input: &str,
        options: &RenderOptions,
    ) -> Result<RenderPlan, RenderError> {
        let font = self.get_font_info(&options.font)?;
        let parsed = self.parse(input, &options.parser_options)?;
        let canonical_codepoints = display_codepoints(
            &parsed,
            options.abbreviate,
            options.preserve_numeric_cartouche_breaks,
        )?;
        let AdaptedRun { text, adapter_id, legacy_ascii, .. } =
            adapt_numeric_cartouche(&canonical_codepoints, &font.render_adapter_id)
                .map_err(RenderError::Adapter)?;
        let open_type_features = open_type_features(options.font_size);
        let render_codepoints = text.chars().map(u32::from).collect();

        Ok(RenderPlan {
            input: input.to_string(),
            parsed,
            font,
            canonical_codepoints,
            render_text: text,
            render_codepoints,
            render_adapter_id: adapter_id,
            legacy_ascii,
            font_size: options.font_size.max(8),
            outer_padding: options.outer_padding,
            open_type_features,
            abbreviated: options.abbreviate,
            preserve_numeric_cartouche_breaks: options.preserve_numeric_cartouche_breaks,
        })
    }

    pub fn render(
        &self,
        input: &str,
        options: &RenderOptions,
    ) -> Result<RenderResult, RenderError> {
        let plan = self.build_render_plan(input, options)?;
        let font_bytes = self
            .registry
            .companion_bytes(&plan.font)
            .map_err(RenderError::Font)?;
        let image = render_plan_to_image(&plan, font_bytes, options.foreground, options.background)?;
        Ok(RenderResult { image, plan })
    }

    pub fn render_default(&self, input: &str) -> Result<RenderResult, RenderError> {
        self.render(input, &RenderOptions::default())
    }

    pub fn render_to_png(
        &self,
        input: &str,
        options: &RenderOptions,
    ) -> Result<Vec<u8>, RenderError> {
        self.render(input, options)?.png_bytes()
    }

    pub fn save_png(
        &self,
        input: &str,
        path: impl AsRef<Path>,
        options: &RenderOptions,
    ) -> Result<PathBuf, RenderError> {
        self.render(input, options)?.save_png(path)
    }

    pub fn render_to_svg(
        &self,
        input: &str,
        options: &RenderOptions,
    ) -> Result<SvgResult, RenderError> {
        let plan = self.build_render_plan(input, options)?;
        let font_bytes = self
            .registry
            .companion_bytes(&plan.font)
            .map_err(RenderError::Font)?;
        let layout = shape_and_measure(&plan, font_bytes)?;
        let width = layout.width;
        let height = layout.height;
        let baseline_x = plan.outer_padding as f32 - layout.min_x;
        let baseline_y = plan.outer_padding as f32 - layout.min_y;
        let svg = svg_document(
            &plan,
            font_bytes,
            &plan.font.companion_filename,
            width,
            height,
            baseline_x,
            baseline_y,
            options.foreground,
            options.background,
        );
        Ok(SvgResult { svg, plan, width, height })
    }
}

fn display_codepoints(
    parsed: &ParseResult,
    abbreviate: bool,
    preserve_breaks: bool,
) -> Result<Vec<u32>, RenderError> {
    let full = parsed.codepoints.clone();
    if full.len() < 3
        || full.first() != Some(&CARTOUCHE_START)
        || full.last() != Some(&CARTOUCHE_END)
    {
        return Err(RenderError::InvalidInput(
            "parsed value did not produce a complete canonical numeric cartouche".to_string(),
        ));
    }
    if !abbreviate {
        return Ok(full);
    }

    if let Some(inner) = parsed.abbreviated_ucsur_codepoints.as_ref() {
        let mut out = Vec::with_capacity(inner.len() + 2);
        out.push(CARTOUCHE_START);
        out.extend_from_slice(inner);
        out.push(CARTOUCHE_END);
        if out != full && out.len() < full.len() {
            return Ok(out);
        }
    }

    let out = abbreviate_numeric_cartouche(&full, preserve_breaks)?;
    if out == full {
        return Err(RenderError::InvalidInput(
            "abbreviated cartouche is identical to its full cartouche".to_string(),
        ));
    }
    if out.len() >= full.len() {
        return Err(RenderError::InvalidInput(format!(
            "abbreviated cartouche is not shorter than full cartouche ({} >= {})",
            out.len(),
            full.len()
        )));
    }
    Ok(out)
}

fn abbreviate_numeric_cartouche(full: &[u32], preserve_breaks: bool) -> Result<Vec<u32>, RenderError> {
    if full.len() < 3 || full[0] != CARTOUCHE_START || *full.last().unwrap_or(&0) != CARTOUCHE_END {
        return Err(RenderError::InvalidInput("cannot abbreviate incomplete cartouche".to_string()));
    }
    let chars = &full[1..full.len() - 1];
    if chars.is_empty() { return Ok(full.to_vec()); }

    let numeric_heads = [NANPA, NASA, NOKA, TENPO, SUNO, TOKI];
    let is_head = |cp: u32| numeric_heads.contains(&cp);
    let is_drop = |cp: u32| matches!(cp, NANPA | EN | E | NENA | OPEN | ALA | IKE | UTA);

    let traditional_full_positive = chars.len() >= 4
        && is_head(chars[0]) && chars[1] == E && chars[2] == NENA && chars[3] == EN;
    let colon_full_positive = chars.len() >= 4
        && is_head(chars[0]) && chars[1] == COLON && chars[2] == NENA && chars[3] == EN;
    let full_positive = traditional_full_positive || colon_full_positive;
    let full_scaffolding_after_opening = chars.len() > 3
        && chars[2..chars.len() - 1].iter().any(|cp| *cp == E || is_drop(*cp));
    let already_abbreviated_positive = !full_positive
        && !full_scaffolding_after_opening
        && chars.len() >= 3 && is_head(chars[0]) && chars[1] == EN;
    let already_abbreviated_colon_positive = !full_positive
        && !full_scaffolding_after_opening
        && chars.len() >= 4 && is_head(chars[0]) && chars[1] == COLON && chars[2] == EN;

    let mut out_inner = Vec::with_capacity(chars.len());
    let mut kept_opening_head = false;
    let mut i = 0usize;
    while i < chars.len() {
        let ch = chars[i];
        let is_final_nanpa = ch == NANPA && i == chars.len() - 1;
        if !kept_opening_head {
            out_inner.push(ch);
            if (i == 0 && is_head(ch)) || ch == NANPA {
                kept_opening_head = true;
            }
            i += 1;
            continue;
        }
        if is_final_nanpa {
            out_inner.push(ch);
            i += 1;
            continue;
        }
        if traditional_full_positive && i == 1 {
            out_inner.push(EN);
            i = 4;
            continue;
        }
        if colon_full_positive && i == 2 {
            out_inner.push(EN);
            i = 4;
            continue;
        }
        if already_abbreviated_positive && i == 1 {
            out_inner.push(EN);
            i += 1;
            continue;
        }
        if already_abbreviated_colon_positive && i == 2 {
            out_inner.push(EN);
            i += 1;
            continue;
        }
        if preserve_breaks
            && ch == NENA
            && i + 3 < chars.len()
            && matches!(chars[i + 1], E | EN)
            && chars[i + 2] == NENA
            && matches!(chars[i + 3], E | EN)
        {
            out_inner.push(E);
            i += 4;
            continue;
        }
        if !is_drop(ch) { out_inner.push(ch); }
        i += 1;
    }

    let mut out = Vec::with_capacity(out_inner.len() + 2);
    out.push(CARTOUCHE_START);
    out.extend(out_inner);
    out.push(CARTOUCHE_END);
    Ok(out)
}

fn open_type_features(font_size: u32) -> Vec<String> {
    let mut features = vec!["calt".to_string(), "liga".to_string(), "ccmp".to_string()];
    if font_size > 0 && font_size <= 18 {
        features.push("ss12".to_string());
    } else if font_size <= 29 {
        features.push("ss13".to_string());
    }
    features
}

#[derive(Debug)]
struct ShapedGlyphBitmap {
    left: f32,
    top: f32,
    width: usize,
    height: usize,
    bitmap: Vec<u8>,
}

#[derive(Debug)]
struct ShapedLayout {
    glyphs: Vec<ShapedGlyphBitmap>,
    min_x: f32,
    min_y: f32,
    width: u32,
    height: u32,
}

fn harfrust_features(tags: &[String]) -> Result<Vec<Feature>, RenderError> {
    tags.iter()
        .map(|tag| Feature::from_str(tag).map_err(|err| {
            RenderError::Shaping(format!("invalid OpenType feature {tag:?}: {err}"))
        }))
        .collect()
}

fn shape_and_measure(plan: &RenderPlan, font_bytes: &'static [u8]) -> Result<ShapedLayout, RenderError> {
    let font_ref = FontRef::from_index(font_bytes, 0)
        .map_err(|err| RenderError::Font(format!("could not parse companion font: {err:?}")))?;
    let raster_font = Font::from_bytes(font_bytes, FontSettings::default())
        .map_err(|err| RenderError::Font(format!("could not rasterize companion font: {err}")))?;
    let upem = raster_font.units_per_em();
    if !upem.is_finite() || upem <= 0.0 {
        return Err(RenderError::Font("companion font has invalid units-per-em".to_string()));
    }
    let font_px = plan.font_size.max(8) as f32;
    let scale = font_px / upem;

    let mut buffer = UnicodeBuffer::new();
    buffer.push_str(&plan.render_text);
    buffer.set_direction(Direction::LeftToRight);
    let features = harfrust_features(&plan.open_type_features)?;
    let shaper_data = ShaperData::new(&font_ref);
    let shaper = shaper_data.shaper(&font_ref).build();
    let glyph_buffer = shaper.shape(buffer, ShapeOptions::new().features(&features));
    let infos = glyph_buffer.glyph_infos();
    let positions = glyph_buffer.glyph_positions();
    if infos.is_empty() || infos.len() != positions.len() {
        return Err(RenderError::Shaping("font shaping produced no drawable glyphs".to_string()));
    }

    let mut pen_x = 0.0f32;
    let mut pen_y = 0.0f32;
    let mut min_x = f32::INFINITY;
    let mut min_y = f32::INFINITY;
    let mut max_x = f32::NEG_INFINITY;
    let mut max_y = f32::NEG_INFINITY;
    let mut glyphs = Vec::with_capacity(infos.len());

    for (info, pos) in infos.iter().zip(positions.iter()) {
        if info.glyph_id > u16::MAX as u32 {
            return Err(RenderError::Shaping(format!("glyph id {} exceeds fontdue range", info.glyph_id)));
        }
        let glyph_id = info.glyph_id as u16;
        let (metrics, bitmap) = raster_font.rasterize_indexed(glyph_id, font_px);
        let origin_x = pen_x + pos.x_offset as f32 * scale;
        let origin_y = pen_y + pos.y_offset as f32 * scale;
        let left = origin_x + metrics.xmin as f32;
        let top = -(origin_y + metrics.ymin as f32 + metrics.height as f32);
        let right = left + metrics.width as f32;
        let bottom = top + metrics.height as f32;

        if metrics.width > 0 && metrics.height > 0 {
            min_x = min_x.min(left);
            min_y = min_y.min(top);
            max_x = max_x.max(right);
            max_y = max_y.max(bottom);
            glyphs.push(ShapedGlyphBitmap {
                left,
                top,
                width: metrics.width,
                height: metrics.height,
                bitmap,
            });
        }
        pen_x += pos.x_advance as f32 * scale;
        pen_y += pos.y_advance as f32 * scale;
    }

    if glyphs.is_empty() || !min_x.is_finite() || !min_y.is_finite() {
        return Err(RenderError::Shaping("font shaping produced a blank run".to_string()));
    }

    let pad = plan.outer_padding as f32;
    let width = ((max_x - min_x).ceil() + 2.0 * pad).max(1.0) as u32;
    let height = ((max_y - min_y).ceil() + 2.0 * pad).max(1.0) as u32;
    Ok(ShapedLayout { glyphs, min_x, min_y, width, height })
}

fn render_plan_to_image(
    plan: &RenderPlan,
    font_bytes: &'static [u8],
    foreground: [u8; 4],
    background: [u8; 4],
) -> Result<RenderedImage, RenderError> {
    let layout = shape_and_measure(plan, font_bytes)?;
    let pixel_count = layout.width as usize * layout.height as usize;
    let mut rgba = Vec::with_capacity(pixel_count * 4);
    for _ in 0..pixel_count { rgba.extend_from_slice(&background); }

    let offset_x = plan.outer_padding as f32 - layout.min_x;
    let offset_y = plan.outer_padding as f32 - layout.min_y;
    for glyph in &layout.glyphs {
        let gx = (glyph.left + offset_x).round() as i32;
        let gy = (glyph.top + offset_y).round() as i32;
        for row in 0..glyph.height {
            for col in 0..glyph.width {
                let coverage = glyph.bitmap[row * glyph.width + col];
                if coverage == 0 { continue; }
                let x = gx + col as i32;
                let y = gy + row as i32;
                if x < 0 || y < 0 || x >= layout.width as i32 || y >= layout.height as i32 { continue; }
                let idx = (y as usize * layout.width as usize + x as usize) * 4;
                blend_coverage(&mut rgba[idx..idx + 4], foreground, coverage);
            }
        }
    }

    Ok(RenderedImage { width: layout.width, height: layout.height, rgba })
}

fn blend_coverage(dst: &mut [u8], fg: [u8; 4], coverage: u8) {
    let src_alpha = (fg[3] as u32 * coverage as u32 + 127) / 255;
    let dst_alpha = dst[3] as u32;
    let inv_src = 255 - src_alpha;
    let out_alpha = src_alpha + (dst_alpha * inv_src + 127) / 255;
    if out_alpha == 0 {
        dst.copy_from_slice(&[0, 0, 0, 0]);
        return;
    }
    for channel in 0..3 {
        let src_premul = fg[channel] as u32 * src_alpha;
        let dst_premul = dst[channel] as u32 * dst_alpha;
        let out_premul = src_premul + (dst_premul * inv_src + 127) / 255;
        dst[channel] = ((out_premul + out_alpha / 2) / out_alpha).min(255) as u8;
    }
    dst[3] = out_alpha.min(255) as u8;
}

fn encode_png(image: &RenderedImage) -> Result<Vec<u8>, RenderError> {
    let mut bytes = Vec::new();
    PngEncoder::new(&mut bytes)
        .write_image(&image.rgba, image.width, image.height, ColorType::Rgba8.into())
        .map_err(|err| RenderError::Image(format!("PNG encoding failed: {err}")))?;
    Ok(bytes)
}

fn svg_document(
    plan: &RenderPlan,
    font_bytes: &[u8],
    font_filename: &str,
    width: u32,
    height: u32,
    baseline_x: f32,
    baseline_y: f32,
    foreground: [u8; 4],
    background: [u8; 4],
) -> String {
    let font_data = base64_encode(font_bytes);
    let font_mime = if font_filename.to_ascii_lowercase().ends_with(".ttf") {
        "font/ttf"
    } else {
        "font/otf"
    };
    let text = escape_xml(&plan.render_text);
    let feature_css = plan
        .open_type_features
        .iter()
        .map(|tag| format!("'{}' 1", tag))
        .collect::<Vec<_>>()
        .join(", ");
    let fg_opacity = foreground[3] as f32 / 255.0;
    let bg_opacity = background[3] as f32 / 255.0;
    let background_rect = if background[3] == 0 {
        String::new()
    } else {
        format!(
            "<rect width=\"100%\" height=\"100%\" fill=\"rgb({},{},{})\" fill-opacity=\"{:.6}\"/>",
            background[0], background[1], background[2], bg_opacity
        )
    };
    format!(
        concat!(
            "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{width}\" height=\"{height}\" viewBox=\"0 0 {width} {height}\">",
            "<style>@font-face{{font-family:'NanpaLinjaNEmbedded';src:url(data:{font_mime};base64,{font_data});}}</style>",
            "{background_rect}",
            "<text x=\"{x:.3}\" y=\"{y:.3}\" font-family=\"NanpaLinjaNEmbedded\" font-size=\"{size}px\" ",
            "font-feature-settings=\"{features}\" fill=\"rgb({r},{g},{b})\" fill-opacity=\"{alpha:.6}\">{text}</text>",
            "</svg>"
        ),
        width = width,
        height = height,
        font_data = font_data,
        font_mime = font_mime,
        background_rect = background_rect,
        x = baseline_x,
        y = baseline_y,
        size = plan.font_size,
        features = feature_css,
        r = foreground[0],
        g = foreground[1],
        b = foreground[2],
        alpha = fg_opacity,
        text = text,
    )
}

fn escape_xml(value: &str) -> String {
    value
        .replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
        .replace('\'', "&apos;")
}

fn base64_encode(bytes: &[u8]) -> String {
    const TABLE: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut out = String::with_capacity(bytes.len().div_ceil(3) * 4);
    let mut i = 0usize;
    while i + 3 <= bytes.len() {
        let n = ((bytes[i] as u32) << 16) | ((bytes[i + 1] as u32) << 8) | bytes[i + 2] as u32;
        out.push(TABLE[((n >> 18) & 63) as usize] as char);
        out.push(TABLE[((n >> 12) & 63) as usize] as char);
        out.push(TABLE[((n >> 6) & 63) as usize] as char);
        out.push(TABLE[(n & 63) as usize] as char);
        i += 3;
    }
    let rem = bytes.len() - i;
    if rem == 1 {
        let n = (bytes[i] as u32) << 16;
        out.push(TABLE[((n >> 18) & 63) as usize] as char);
        out.push(TABLE[((n >> 12) & 63) as usize] as char);
        out.push('=');
        out.push('=');
    } else if rem == 2 {
        let n = ((bytes[i] as u32) << 16) | ((bytes[i + 1] as u32) << 8);
        out.push(TABLE[((n >> 18) & 63) as usize] as char);
        out.push(TABLE[((n >> 12) & 63) as usize] as char);
        out.push(TABLE[((n >> 6) & 63) as usize] as char);
        out.push('=');
    }
    out
}
