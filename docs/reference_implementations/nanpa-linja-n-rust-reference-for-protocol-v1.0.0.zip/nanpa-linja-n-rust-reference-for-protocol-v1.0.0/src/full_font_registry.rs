use serde::Deserialize;
use serde_json::Value;
use std::collections::BTreeMap;

const MANIFEST_JSON: &str = include_str!("../fonts/preloaded-font-pairs.manifest.json");

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
struct ManifestDoc { schema: u32, pairs: Vec<ManifestPair> }
#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
struct ManifestPair {
    font_key: String,
    #[serde(default)] label: String,
    #[serde(default)] parser_mode: String,
    #[serde(default = "identity")] render_adapter_id: String,
    #[serde(default)] render_adapter_settings: BTreeMap<String, Value>,
    #[serde(default)] settings: BTreeMap<String, Value>,
    #[serde(default)] base_family: String,
    #[serde(default)] companion_family: String,
    #[serde(default)] base_filename: String,
    #[serde(default)] companion_filename: String,
    #[serde(default)] literal_cartouche_family: String,
    #[serde(default)] literal_cartouche_filename: String,
}
fn identity() -> String { "identity".to_string() }

#[derive(Debug, Clone)]
pub struct FullFontInfo {
    pub key: String, pub label: String, pub parser_mode: String, pub render_adapter_id: String,
    pub render_adapter_settings: BTreeMap<String, Value>, pub settings: BTreeMap<String, Value>,
    pub base_family: String, pub companion_family: String, pub base_filename: String, pub companion_filename: String,
    pub literal_cartouche_family: String, pub literal_cartouche_filename: String,
}

#[derive(Debug, Clone)]
pub struct FullFontRegistry { fonts: Vec<FullFontInfo> }
impl FullFontRegistry {
    pub fn bundled() -> Result<Self,String> {
        let doc:ManifestDoc=serde_json::from_str(MANIFEST_JSON).map_err(|e|format!("full font manifest invalid: {e}"))?;
        if doc.schema!=2 {return Err(format!("unsupported full font manifest schema {}",doc.schema));}
        let fonts=doc.pairs.into_iter().map(|p|FullFontInfo{
            key:p.font_key.clone(), label:if p.label.trim().is_empty(){p.font_key}else{p.label}, parser_mode:p.parser_mode,
            render_adapter_id:if p.render_adapter_id.trim().is_empty(){"identity".into()}else{p.render_adapter_id},
            render_adapter_settings:p.render_adapter_settings,settings:p.settings,base_family:p.base_family,companion_family:p.companion_family,
            base_filename:p.base_filename,companion_filename:p.companion_filename,literal_cartouche_family:p.literal_cartouche_family,literal_cartouche_filename:p.literal_cartouche_filename,
        }).collect(); Ok(Self{fonts})
    }
    pub fn list(&self)->&[FullFontInfo]{&self.fonts}
    pub fn get(&self,key:&str)->Option<&FullFontInfo>{ let n=normalize(key); self.fonts.iter().find(|f|[&f.key,&f.label,&f.base_family,&f.companion_family].iter().any(|x|normalize(x)==n)) }
}
fn normalize(v:&str)->String{v.chars().filter(|c|c.is_ascii_alphanumeric()).flat_map(|c|c.to_lowercase()).collect()}

pub fn bundled_full_font_bytes(filename:&str)->Option<&'static [u8]>{match filename{
    "nasin-nanpa-5.0.0-beta.3-UCSUR-v5-ascii-ligatures.otf"=>Some(include_bytes!("../fonts/nasin-nanpa-5.0.0-beta.3-UCSUR-v5-ascii-ligatures.otf")),
    "nasin-nanpa-5.0.0-beta.3-UCSUR-nanpa-linja-n-good-kasi-nasin-e-en-ss1223.otf"=>Some(include_bytes!("../fonts/nasin-nanpa-5.0.0-beta.3-UCSUR-nanpa-linja-n-good-kasi-nasin-e-en-ss1223.otf")),
    "sitelenselikiwenjuniko-latin-ligatures.ttf"=>Some(include_bytes!("../fonts/sitelenselikiwenjuniko-latin-ligatures.ttf")),
    "sitelenselikiwenjuniko-nanpa-linja-n-good-kasi-nasin-e-en-ss1223.ttf"=>Some(include_bytes!("../fonts/sitelenselikiwenjuniko-nanpa-linja-n-good-kasi-nasin-e-en-ss1223.ttf")),
    "FairfaxHD.ttf"=>Some(include_bytes!("../fonts/FairfaxHD.ttf")),
    "FairfaxHD-nanpa-linja-n-good-kasi-nasin-e-en-ss1223.ttf"=>Some(include_bytes!("../fonts/FairfaxHD-nanpa-linja-n-good-kasi-nasin-e-en-ss1223.ttf")),
    "FairfaxPonaHD.ttf"=>Some(include_bytes!("../fonts/FairfaxPonaHD.ttf")),
    "FairfaxPonaHD-nanpa-linja-n-good-kasi-nasin-e-en-ss1223.ttf"=>Some(include_bytes!("../fonts/FairfaxPonaHD-nanpa-linja-n-good-kasi-nasin-e-en-ss1223.ttf")),
    "linja-pona.otf"=>Some(include_bytes!("../fonts/linja-pona.otf")),
    "linja-pona-nanpa-linja-n-nasin-e-en-ss1223.otf"=>Some(include_bytes!("../fonts/linja-pona-nanpa-linja-n-nasin-e-en-ss1223.otf")),
    "linja-sike-5-cartouche-fix.otf"=>Some(include_bytes!("../fonts/linja-sike-5-cartouche-fix.otf")),
    "linja-sike-5-nanpa-linja-n-nasin-e-en-ss1223.otf"=>Some(include_bytes!("../fonts/linja-sike-5-nanpa-linja-n-nasin-e-en-ss1223.otf")),
    "NasinSitelenPuMono.otf"=>Some(include_bytes!("../fonts/NasinSitelenPuMono.otf")),
    "NasinSitelenPuMono-nanpa-linja-n-nasin-e-en-ss1223.otf"=>Some(include_bytes!("../fonts/NasinSitelenPuMono-nanpa-linja-n-nasin-e-en-ss1223.otf")),
    "linjalipamanka-normal-cartouche-fix.otf"=>Some(include_bytes!("../fonts/linjalipamanka-normal-cartouche-fix.otf")),
    "linjalipamanka-normal-nanpa-linja-n-nasin-e-en-ss1223.otf"=>Some(include_bytes!("../fonts/linjalipamanka-normal-nanpa-linja-n-nasin-e-en-ss1223.otf")),
    "nasin-nanpa-4.0.2-Helvetica.otf"=>Some(include_bytes!("../fonts/nasin-nanpa-4.0.2-Helvetica.otf")),
    "PatrickHand-Regular.ttf"=>Some(include_bytes!("../fonts/PatrickHand-Regular.ttf")),
    "LiberationMono-Regular.ttf"=>Some(include_bytes!("../fonts/LiberationMono-Regular.ttf")),
    "LiberationSans-Regular.ttf"=>Some(include_bytes!("../fonts/LiberationSans-Regular.ttf")),
    "LiberationSerif-Regular.ttf"=>Some(include_bytes!("../fonts/LiberationSerif-Regular.ttf")),
    _=>None,
}}

pub fn setting_string(m:&BTreeMap<String,Value>,key:&str,default:&str)->String{m.get(key).and_then(Value::as_str).filter(|s|!s.trim().is_empty()).unwrap_or(default).to_string()}
pub fn setting_f64(m:&BTreeMap<String,Value>,key:&str,default:f64)->f64{m.get(key).and_then(Value::as_f64).unwrap_or(default)}
pub fn setting_i64(m:&BTreeMap<String,Value>,key:&str,default:i64)->i64{m.get(key).and_then(Value::as_i64).or_else(||m.get(key).and_then(Value::as_u64).map(|x|x as i64)).unwrap_or(default)}
