use crate::digits::{encode_digit, DigitStyle};
use crate::options::ParseOptions;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum EncodeError {
    EmptyValue,
    InvalidValue(String),
}

impl std::fmt::Display for EncodeError {
    fn fmt(
        &self,
        f: &mut std::fmt::Formatter<'_>,
    ) -> std::fmt::Result {
        match self {
            Self::EmptyValue => {
                write!(f, "empty value cannot be encoded")
            }

            Self::InvalidValue(value) => {
                write!(f, "invalid decimal value: {value}")
            }
        }
    }
}

impl std::error::Error for EncodeError {}

fn digit_style(options: &ParseOptions) -> DigitStyle {
    if options.relaxed_nanpa_linjan_rendering {
        DigitStyle::Relaxed
    } else {
        DigitStyle::Strict
    }
}

fn encode_digits(
    digits: &str,
    options: &ParseOptions,
) -> Result<String, EncodeError> {
    if digits.is_empty() {
        return Err(
            EncodeError::InvalidValue(
                digits.to_string(),
            )
        );
    }

    let style = digit_style(options);
    let mut out = String::new();

    for ch in digits.chars() {
        let digit = ch
            .to_digit(10)
            .ok_or_else(|| {
                EncodeError::InvalidValue(
                    digits.to_string(),
                )
            })?;

        let syllable = encode_digit(
            digit as u8,
            style,
        )
        .ok_or_else(|| {
            EncodeError::InvalidValue(
                digits.to_string(),
            )
        })?;

        out.push_str(syllable);
    }

    Ok(out)
}

fn encode_fraction_digits(
    digits: &str,
    options: &ParseOptions,
) -> Result<String, EncodeError> {
    if digits.is_empty() {
        return Err(
            EncodeError::InvalidValue(
                digits.to_string(),
            )
        );
    }

    let chars: Vec<char> =
        digits.chars().collect();

    let mut groups = Vec::new();

    for chunk in chars.chunks(3) {
        let group: String =
            chunk.iter().collect();

        groups.push(
            encode_digits(
                &group,
                options,
            )?
        );
    }

    Ok(groups.join("NENE"))
}

fn encode_integer_groups(
    value: &str,
    options: &ParseOptions,
) -> Result<String, EncodeError> {
    let groups: Vec<&str> =
        value.split(',').collect();

    if groups.is_empty()
        || groups
            .iter()
            .any(|group| group.is_empty())
    {
        return Err(
            EncodeError::InvalidValue(
                value.to_string(),
            )
        );
    }

    let trailing_zero_groups = groups
        .iter()
        .rev()
        .take_while(|group| **group == "000")
        .count();

    if trailing_zero_groups > 0
        && trailing_zero_groups < groups.len()
    {
        let significant_count =
            groups.len() - trailing_zero_groups;

        let mut output = String::new();

        for (index, group) in groups
            .iter()
            .take(significant_count)
            .enumerate()
        {
            if index > 0 {
                output.push_str("NEKE");
            }

            output.push_str(
                &encode_digits(
                    group,
                    options,
                )?
            );
        }

        output.push_str("NE");

        for _ in 0..trailing_zero_groups {
            output.push_str("KE");
        }

        return Ok(output);
    }

    let mut output = String::new();

    for (index, group) in
        groups.iter().enumerate()
    {
        if index > 0 {
            output.push_str("NEKE");
        }

        output.push_str(
            &encode_digits(
                group,
                options,
            )?
        );
    }

    Ok(output)
}

fn encode_unsigned_basic(
    value: &str,
    options: &ParseOptions,
) -> Result<String, EncodeError> {
    if let Some((left, right)) =
        value.split_once('.')
    {
        if right.is_empty() {
            return Err(
                EncodeError::InvalidValue(
                    value.to_string(),
                )
            );
        }

        let integer =
            if left.is_empty() {
                "0"
            } else {
                left
            };

        return Ok(format!(
            "{}NONE{}",
            encode_integer_groups(
                integer,
                options,
            )?,
            encode_fraction_digits(
                right,
                options,
            )?
        ));
    }

    encode_integer_groups(
        value,
        options,
    )
}

fn magnitude_power(ch: char) -> Option<usize> {
    match ch.to_ascii_uppercase() {
        'K' => Some(1),
        'M' => Some(2),
        'B' => Some(3),
        'T' => Some(4),
        _ => None,
    }
}

fn split_magnitude(
    value: &str,
) -> Option<(&str, usize)> {
    let suffix = value.chars().last()?;
    let power = magnitude_power(suffix)?;

    let base_len =
        value.len() - suffix.len_utf8();

    let base = &value[..base_len];

    if base.is_empty() {
        return None;
    }

    Some((base, power))
}

pub fn encode_decimal(
    value: &str,
    options: &ParseOptions,
) -> Result<String, EncodeError> {
    let raw = value.trim();

    if raw.is_empty() {
        return Err(EncodeError::EmptyValue);
    }

    // Current JavaScript baseline: outer whitespace is ignored, but any
    // whitespace inside a digit-based numeric token is a hard boundary.
    if raw.chars().any(char::is_whitespace) {
        return Err(EncodeError::InvalidValue(raw.to_string()));
    }

    let mut body = raw;
    let mut prefix = "";

    if body.starts_with('+') {
        prefix = "NS";
        body = &body[1..];

        if body.starts_with('+')
            || body.is_empty()
        {
            return Err(
                EncodeError::InvalidValue(
                    raw.to_string(),
                )
            );
        }
    } else if body.starts_with('-') {
        prefix = "NO";
        body = body.trim_start_matches('-');

        if body.is_empty() {
            return Err(
                EncodeError::InvalidValue(
                    raw.to_string(),
                )
            );
        }
    }

    if let Some((
        magnitude_body,
        power,
    )) = split_magnitude(body)
    {
        let encoded =
            encode_unsigned_basic(
                magnitude_body,
                options,
            )?;

        let mut magnitude =
            String::from("NE");

        for _ in 0..power {
            magnitude.push_str("KE");
        }

        return Ok(format!(
            "NE{prefix}{encoded}{magnitude}N"
        ));
    }

    if let Some(percent_body) =
        body.strip_suffix('%')
    {
        let encoded =
            encode_unsigned_basic(
                percent_body,
                options,
            )?;

        return Ok(format!(
            "NE{prefix}{encoded}OKN"
        ));
    }

    if let Some(index) =
        body.find(['e', 'E'])
    {
        let mantissa =
            &body[..index];

        let mut exponent =
            &body[index + 1..];

        if exponent.is_empty() {
            return Err(
                EncodeError::InvalidValue(
                    raw.to_string(),
                )
            );
        }

        let exponent_prefix =
            if let Some(rest) =
                exponent.strip_prefix('-')
            {
                exponent = rest;
                "NO"
            } else if let Some(rest) =
                exponent.strip_prefix('+')
            {
                exponent = rest;
                ""
            } else {
                ""
            };

        if exponent.is_empty() {
            return Err(
                EncodeError::InvalidValue(
                    raw.to_string(),
                )
            );
        }

        let mantissa_encoded =
            encode_unsigned_basic(
                mantissa,
                options,
            )?;

        let exponent_encoded =
            encode_digits(
                exponent,
                options,
            )?;

        return Ok(format!(
            "NE{prefix}{mantissa_encoded}NEKO{exponent_prefix}{exponent_encoded}N"
        ));
    }

    if let Some((whole, fraction)) =
        body.split_once('+')
    {
        if let Some((
            numerator,
            denominator,
        )) = fraction.split_once('/')
        {
            let whole_encoded =
                encode_unsigned_basic(
                    whole,
                    options,
                )?;

            let numerator_encoded =
                encode_unsigned_basic(
                    numerator,
                    options,
                )?;

            let denominator_encoded =
                encode_unsigned_basic(
                    denominator,
                    options,
                )?;

            return Ok(format!(
                "NE{prefix}{whole_encoded}NOKO{numerator_encoded}NONO{denominator_encoded}N"
            ));
        }

        return Err(
            EncodeError::InvalidValue(
                raw.to_string(),
            )
        );
    }

    if let Some((
        numerator,
        denominator,
    )) = body.split_once('/')
    {
        let numerator_encoded =
            encode_unsigned_basic(
                numerator,
                options,
            )?;

        let denominator_encoded =
            encode_unsigned_basic(
                denominator,
                options,
            )?;

        return Ok(format!(
            "NE{prefix}{numerator_encoded}NONO{denominator_encoded}N"
        ));
    }

    let encoded =
        encode_unsigned_basic(
            body,
            options,
        )?;

    Ok(format!(
        "NE{prefix}{encoded}N"
    ))
}