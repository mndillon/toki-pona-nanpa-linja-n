pub const PROTOCOL_NAME: &str = "nanpa-linja-n";
pub const PROTOCOL_VERSION: &str = "1.0.0";
pub const CONFORMANCE_CORPUS_VERSION: &str = "1.0.2";

pub const CARTOUCHE_START: u32 = 0xF1990;
pub const CARTOUCHE_END: u32 = 0xF1991;

pub const STRICT_DIGITS: [&str; 10] = [
    "NI", // 0
    "WE", // 1
    "TE", // 2
    "SE", // 3
    "NA", // 4
    "LE", // 5
    "NU", // 6
    "ME", // 7
    "PE", // 8
    "JE", // 9
];

pub const RELAXED_DIGITS: [&str; 10] = [
    "NI", // 0
    "WA", // 1
    "TU", // 2
    "SE", // 3
    "NA", // 4
    "LU", // 5
    "NU", // 6
    "MU", // 7
    "PI", // 8
    "JO", // 9
];

pub const ABBREVIATED_DIGIT_WORDS: [&str; 10] = [
    "ijo",   // 0
    "wan",   // 1
    "tu",    // 2
    "seli",  // 3
    "awen",  // 4
    "luka",  // 5
    "utala", // 6
    "mun",   // 7
    "pipi",  // 8
    "jo",    // 9
];

pub const HEX_ABBREVIATED_WORDS: [(&str, &str); 6] = [
    ("A", "jan"),
    ("B", "lawa"),
    ("C", "ma"),
    ("D", "pakala"),
    ("E", "sike"),
    ("F", "tan"),
];

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DecimalStartGlyph {
    Nanpa,
    Tenpo,
    Suno,
    Toki,
}

impl DecimalStartGlyph {
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Nanpa => "nanpa",
            Self::Tenpo => "tenpo",
            Self::Suno => "suno",
            Self::Toki => "toki",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SemanticKind {
    Time,
    Date,
}

impl SemanticKind {
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Time => "time",
            Self::Date => "date",
        }
    }
}

pub const DECIMAL_DEFAULT_START_GLYPH: DecimalStartGlyph =
    DecimalStartGlyph::Nanpa;

pub const DECIMAL_CLOSER: &str = "nanpa";
pub const HEX_OPENER_CLOSER: &str = "nasa";
pub const BINARY_OPENER_CLOSER: &str = "noka";