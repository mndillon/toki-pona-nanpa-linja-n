use crate::protocol::{DecimalStartGlyph, SemanticKind};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum NumberKind {
    Hex,
    Binary,
}

impl NumberKind {
    pub const fn as_str(&self) -> &'static str {
        match self {
            Self::Hex => "hex",
            Self::Binary => "binary",
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum NumericPart {
    Digits(String),
    Delimiter(char),
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ParseResult {
    // Common parseNumber fields
    pub input: String,
    pub caps: Option<String>,
    pub proper_name: String,
    pub unique_code: String,

    pub ucsur_codepoints: Vec<u32>,
    pub hex_codepoints: String,
    pub hex_with_cartouche: String,

    pub tp_words: Vec<String>,
    pub words: Vec<String>,

    pub display_value: String,

    pub is_time: bool,
    pub is_date: bool,
    pub is_time_like: bool,

    pub inner_codepoints: Vec<u32>,
    pub codepoints: Vec<u32>,

    pub numeric_mode: String,

    // Decimal semantic fields
    pub semantic_kind: Option<SemanticKind>,
    pub semantic_start_glyph: Option<DecimalStartGlyph>,

    // Hex/binary fields
    pub kind: Option<NumberKind>,
    pub number_base: Option<u32>,
    pub is_hex: bool,
    pub is_binary: bool,

    pub hex_digits: Option<String>,
    pub binary_digits: Option<String>,

    pub hex_parts: Option<Vec<NumericPart>>,
    pub binary_parts: Option<Vec<NumericPart>>,

    pub abbreviated_ucsur_codepoints: Option<Vec<u32>>,
    pub abbreviated_words: Option<Vec<String>>,
}

impl ParseResult {
    pub fn is_decimal(&self) -> bool {
        self.kind.is_none()
    }
}