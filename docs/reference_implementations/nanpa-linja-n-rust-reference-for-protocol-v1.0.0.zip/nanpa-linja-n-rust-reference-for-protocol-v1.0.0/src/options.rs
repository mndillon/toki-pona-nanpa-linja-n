use crate::protocol::DecimalStartGlyph;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NumericMode {
    Uniform,
    Traditional,
}

impl NumericMode {
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Uniform => "uniform",
            Self::Traditional => "traditional",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MixedStyle {
    Short,
}

impl MixedStyle {
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Short => "short",
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ParseOptions {
    pub enable_binary_parsing: bool,
    pub enable_hex_parsing: bool,

    pub mixed_style: MixedStyle,

    pub mode: NumericMode,
    pub numeric_mode: NumericMode,

    pub nanpa_colon_parsing: bool,
    pub nanpa_colon_rendering: bool,

    pub relaxed_nanpa_linjan_parsing: bool,
    pub relaxed_nanpa_linjan_rendering: bool,

    pub abbreviate_numeric_cartouches: bool,
    pub preserve_numeric_cartouche_breaks_in_abbreviation: bool,

    pub numeric_cartouche_start_glyph: Option<DecimalStartGlyph>,
}

impl Default for ParseOptions {
    fn default() -> Self {
        Self {
            enable_binary_parsing: true,
            enable_hex_parsing: true,

            mixed_style: MixedStyle::Short,

            mode: NumericMode::Uniform,
            numeric_mode: NumericMode::Uniform,

            nanpa_colon_parsing: true,
            nanpa_colon_rendering: true,

            relaxed_nanpa_linjan_parsing: true,
            relaxed_nanpa_linjan_rendering: true,

            abbreviate_numeric_cartouches: false,
            preserve_numeric_cartouche_breaks_in_abbreviation: false,

            numeric_cartouche_start_glyph: None,
        }
    }
}