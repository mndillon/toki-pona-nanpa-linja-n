use serde::Deserialize;
use serde_json::Value;
use std::collections::HashMap;

#[derive(Debug, Deserialize)]
pub struct RegressionCorpus {
    #[serde(rename = "$schema")]
    pub schema: String,

    pub suite: Value,

    #[serde(rename = "optionProfiles")]
    pub option_profiles: Value,

    pub constants: Value,

    #[serde(rename = "coverageManifest")]
    pub coverage_manifest: Value,

    #[serde(rename = "outputContracts")]
    pub output_contracts: Value,

    #[serde(rename = "parserCases")]
    pub parser_cases: Vec<ParserCase>,

    #[serde(rename = "rendererCases")]
    pub renderer_cases: Vec<Value>,

    #[serde(rename = "apiCases")]
    pub api_cases: Vec<Value>,

    #[serde(rename = "equivalenceGroups")]
    pub equivalence_groups: Vec<Value>,
}

#[derive(Debug, Deserialize)]
pub struct ParserCase {
    pub id: String,

    pub category: String,

    pub input: Option<Value>,

    pub options: ParserOptions,

    #[serde(rename = "assert")]
    pub assertion: ParserAssertion,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ParserOptions {
    #[serde(default)]
    pub enable_binary_parsing: Option<bool>,

    #[serde(default)]
    pub enable_hex_parsing: Option<bool>,

    #[serde(default)]
    pub mixed_style: Option<String>,

    #[serde(default)]
    pub mode: Option<String>,

    #[serde(default)]
    pub numeric_mode: Option<String>,

    #[serde(default)]
    pub nanpa_colon_parsing: Option<bool>,

    #[serde(default)]
    pub nanpa_colon_rendering: Option<bool>,

    #[serde(default)]
    pub relaxed_nanpa_linjan_parsing: Option<bool>,

    #[serde(default)]
    pub relaxed_nanpa_linjan_rendering: Option<bool>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ParserAssertion {
    pub result: String,

    #[serde(default)]
    pub display_value: Option<String>,

    #[serde(default)]
    pub equivalent_value: Option<String>,

    #[serde(default)]
    pub equivalent_to_input: Option<String>,

    #[serde(default)]
    pub is_date: Option<bool>,

    #[serde(default)]
    pub is_time: Option<bool>,

    #[serde(default)]
    pub is_hex: Option<bool>,

    #[serde(default)]
    pub is_binary: Option<bool>,

    #[serde(default)]
    pub semantic_kind: Option<Value>,

    #[serde(default)]
    pub semantic_start_glyph: Option<Value>,

    #[serde(default)]
    pub tp_words_first: Option<String>,

    #[serde(default)]
    pub tp_words_last: Option<String>,

    #[serde(default)]
    pub kind: Option<String>,

    #[serde(default)]
    pub number_base: Option<u32>,

    #[serde(default)]
    pub unique_code: Option<String>,

    #[serde(default)]
    pub absent_fields: Option<Vec<String>>,

    #[serde(default)]
    pub notes: Option<String>,

    #[serde(flatten)]
    pub extra: HashMap<String, Value>,
}