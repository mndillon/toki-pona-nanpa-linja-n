use crate::protocol::{RELAXED_DIGITS, STRICT_DIGITS};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DigitStyle {
    Strict,
    Relaxed,
}

pub fn encode_digit(digit: u8, style: DigitStyle) -> Option<&'static str> {
    if digit > 9 {
        return None;
    }

    Some(match style {
        DigitStyle::Strict => STRICT_DIGITS[digit as usize],
        DigitStyle::Relaxed => RELAXED_DIGITS[digit as usize],
    })
}

pub fn decode_digit(syllable: &str, relaxed_parsing: bool) -> Option<u8> {
    let normalized = syllable.trim().to_ascii_uppercase();

    for (digit, strict) in STRICT_DIGITS.iter().enumerate() {
        if normalized == *strict {
            return Some(digit as u8);
        }
    }

    if relaxed_parsing {
        for (digit, relaxed) in RELAXED_DIGITS.iter().enumerate() {
            if normalized == *relaxed {
                return Some(digit as u8);
            }
        }
    }

    None
}