//! Production-font adapter subset used by numeric cartouche rendering.
//!
//! Most companion fonts consume canonical UCSUR directly.  The two legacy
//! fonts consume their native ASCII ligature syntax.  This mirrors the
//! production renderer contract rather than asking callers to know the
//! difference.

use crate::api::codepoint_to_word;
use crate::protocol::{CARTOUCHE_END, CARTOUCHE_START};

const COLON: u32 = 0xF199D;

pub const LEGACY_ASCII_ADAPTERS: [&str; 2] = [
    "linja-pona-legacy-v1",
    "linja-sike-legacy-v1",
];

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AdaptedRun {
    pub text: String,
    pub adapter_id: String,
    pub canonical_codepoints: Vec<u32>,
    pub legacy_ascii: bool,
}

fn is_legacy_adapter(adapter_id: &str) -> bool {
    LEGACY_ASCII_ADAPTERS.iter().any(|candidate| *candidate == adapter_id)
}

fn legacy_numeric_cartouche(codepoints: &[u32], adapter_id: &str) -> Result<String, String> {
    if codepoints.len() < 2
        || codepoints.first() != Some(&CARTOUCHE_START)
        || codepoints.last() != Some(&CARTOUCHE_END)
    {
        return Err(format!(
            "{adapter_id}: numeric render input is not a complete canonical cartouche"
        ));
    }

    let mut out = String::from("[");
    for cp in &codepoints[1..codepoints.len() - 1] {
        out.push('_');
        if *cp == COLON {
            out.push(':');
            continue;
        }
        let word = codepoint_to_word(*cp).ok_or_else(|| {
            format!("{adapter_id}: no legacy numeric encoding for U+{cp:04X}")
        })?;
        out.push_str(word);
    }
    out.push(']');
    Ok(out)
}

pub fn adapt_numeric_cartouche(
    codepoints: &[u32],
    render_adapter_id: &str,
) -> Result<AdaptedRun, String> {
    let adapter_id = if render_adapter_id.trim().is_empty() {
        "identity"
    } else {
        render_adapter_id.trim()
    };

    if is_legacy_adapter(adapter_id) {
        return Ok(AdaptedRun {
            text: legacy_numeric_cartouche(codepoints, adapter_id)?,
            adapter_id: adapter_id.to_string(),
            canonical_codepoints: codepoints.to_vec(),
            legacy_ascii: true,
        });
    }

    let mut text = String::new();
    for cp in codepoints {
        let ch = char::from_u32(*cp)
            .ok_or_else(|| format!("invalid Unicode scalar value U+{cp:04X}"))?;
        text.push(ch);
    }
    Ok(AdaptedRun {
        text,
        adapter_id: adapter_id.to_string(),
        canonical_codepoints: codepoints.to_vec(),
        legacy_ascii: false,
    })
}
