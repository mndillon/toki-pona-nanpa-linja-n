#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
TARGET="${1:-.}"
if [ ! -f "$TARGET/Cargo.toml" ]; then
  echo "ERROR: target does not look like nanpa-linja-n-rust project root: $TARGET" >&2
  echo "Usage: $0 /path/to/nanpa-linja-n-rust" >&2
  exit 1
fi
mkdir -p "$TARGET/src/parser" "$TARGET/tests"
cp "$HERE/src/parser.rs" "$TARGET/src/parser.rs"
cp "$HERE/src/parser/extended.rs" "$TARGET/src/parser/extended.rs"
cp "$HERE/tests/parser_conformance.rs" "$TARGET/tests/parser_conformance.rs"
cp "$HERE/tests/parse_decimal_integer.rs" "$TARGET/tests/parse_decimal_integer.rs"
echo "Applied v3 overlay to: $TARGET"
echo "Verification hashes:"
sha256sum \
  "$TARGET/src/parser.rs" \
  "$TARGET/src/parser/extended.rs" \
  "$TARGET/tests/parser_conformance.rs" \
  "$TARGET/tests/parse_decimal_integer.rs"
