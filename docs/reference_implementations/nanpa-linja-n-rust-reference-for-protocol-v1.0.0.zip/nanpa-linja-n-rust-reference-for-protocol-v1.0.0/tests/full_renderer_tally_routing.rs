use nanpa_linja_n_rust::facade::NanpaLinjaN;
use nanpa_linja_n_rust::{FullRenderOptions, TALLY_CODEPOINT};

#[test]
fn production_fonts_route_tallies_as_five_manual_and_three_ucsur() {
    let nanpa = NanpaLinjaN::create().expect("facade initializes");
    let mut manual = 0usize;
    let mut ucsur = 0usize;
    for info in nanpa.list_full_fonts().expect("font registry") {
        let mut options = FullRenderOptions::default();
        options.font = info.key.clone();
        options.font_size = 56.0;
        let plan = nanpa.build_full_render_plan("[jan pona,,]", &options).expect("tally plan");
        assert_eq!(plan.lines.len(), 1, "{} line count", info.key);
        assert_eq!(plan.lines[0].runs.len(), 1, "{} run count", info.key);
        let run = &plan.lines[0].runs[0];
        if run.tally_groups.is_empty() {
            ucsur += 1;
            assert!(run.render_codepoints.contains(&TALLY_CODEPOINT), "{} must retain UCSUR tally", info.key);
        } else {
            manual += 1;
            assert!(!run.render_codepoints.contains(&TALLY_CODEPOINT), "{} must not shape U+F199E", info.key);
            assert_eq!(run.manual_tallies, vec![0,2], "{} manual tally ownership", info.key);
            assert_eq!(run.tally_groups.len(), 1, "{} tally group count", info.key);
            let group=&run.tally_groups[0];
            assert_eq!(group.owner_index,1,"{} tally owner",info.key);
            assert_eq!(group.count,2,"{} tally count",info.key);
            assert!((group.center_x_px-(group.owner_left_px+group.owner_right_px)/2.0).abs()<=0.05,"{} tally center must be owner-centered",info.key);
        }
    }
    assert_eq!(manual,5,"manual-tally font count");
    assert_eq!(ucsur,3,"UCSUR-tally font count");
}
