use nanpa_linja_n_rust::options::ParseOptions;
use nanpa_linja_n_rust::parser::parse_number;

#[test]
fn exactly_two_trailing_zeroes_split_proper_name() {
    let options = ParseOptions::default();

    let cases = [
        ("100", "Nanpa Wan Inin"),
        ("200", "Nanpa Tun Inin"),
        ("500", "Nanpa Lun Inin"),
        ("1200", "Nanpa Watun Inin"),
        ("9900", "Nanpa Jojon Inin"),
        ("10100", "Nanpa Waniwan Inin"),
        ("12300", "Nanpa Watusen Inin"),
        ("99900", "Nanpa Jojojon Inin"),
        ("-100", "Nanpa Nowan Inin"),
        ("+100", "Nanpa Newan Inin"),
        ("100.5", "Nanpa Wan Inin One Lun"),
        ("200.5", "Nanpa Tun Inin One Lun"),
    ];

    for (input, expected) in cases {
        let result =
            parse_number(input, &options)
                .expect("reference accepts input");

        assert_eq!(
            result.proper_name,
            expected,
            "proper-name mismatch for {input}"
        );
    }
}

#[test]
fn three_or_more_trailing_zeroes_remain_joined() {
    let options = ParseOptions::default();

    let cases = [
        ("1000", "Nanpa Wanininin"),
        ("5000", "Nanpa Lunininin"),
        ("10000", "Nanpa Waninininin"),
        ("11000", "Nanpa Wawanininin"),
        ("123000", "Nanpa Watusenininin"),
        ("999000", "Nanpa Jojojonininin"),
        ("100000", "Nanpa Wanininininin"),
        ("500000", "Nanpa Lunininininin"),
    ];

    for (input, expected) in cases {
        let result =
            parse_number(input, &options)
                .expect("reference accepts input");

        assert_eq!(
            result.proper_name,
            expected,
            "proper-name mismatch for {input}"
        );
    }
}

#[test]
fn nonzero_endings_keep_existing_joined_form() {
    let options = ParseOptions::default();

    let cases = [
        ("99", "Nanpa Jojon"),
        ("101", "Nanpa Waniwan"),
        ("109", "Nanpa Wanijon"),
        ("110", "Nanpa Wawanin"),
        ("111", "Nanpa Wawawan"),
        ("123", "Nanpa Watusen"),
        ("999", "Nanpa Jojojon"),
        ("1001", "Nanpa Waniniwan"),
        ("1234", "Nanpa Watusenan"),
        ("9999", "Nanpa Jojojojon"),
    ];

    for (input, expected) in cases {
        let result =
            parse_number(input, &options)
                .expect("reference accepts input");

        assert_eq!(
            result.proper_name,
            expected,
            "proper-name mismatch for {input}"
        );
    }
}