mod support;
use nanpa_linja_n_rust::facade::NanpaLinjaN;
use serde_json::Value;
use std::fs;

#[test]
fn javascript_composition_interactions(){
    let root:Value=serde_json::from_str(&fs::read_to_string("references/javascript-composition-interactions-v1.json").unwrap()).unwrap();let cases=support::array(&root["cases"]);assert_eq!(root["caseCount"].as_u64().unwrap() as usize,cases.len());let n=NanpaLinjaN::create().unwrap();let mut errors=Vec::new();let mut passed=0usize;let mut replacement_checks=0usize;let mut png_checks=0usize;
    for c in cases{let id=c["id"].as_str().unwrap();let before=errors.len();if c["ok"].as_bool()!=Some(true){errors.push(format!("{id}: JS oracle failed"));continue;}let mut o=support::options(c["font"].as_str().unwrap_or("nasinNanpa"),&c["parser"]);o.font_size=56.0;o.padding_px=18;let input=c["input"].as_str().unwrap();match n.build_full_render_plan(input,&o){Ok(plan)=>{if plan.ast.normalized_input!=input{errors.push(format!("{id}: AST normalizedInput got={:?} want={input:?}",plan.ast.normalized_input));}match n.ast_to_text(&plan.ast){Ok(rt)=>if rt!=c["astToText"].as_str().unwrap_or(""){errors.push(format!("{id}: ast_to_text got={rt:?} want={:?}",c["astToText"]));},Err(e)=>errors.push(format!("{id}: ast_to_text threw {e}"))}let want=support::array(&c["runs"]);let got=support::flatten(&plan);if got.len()!=want.len(){errors.push(format!("{id}: run count got={} want={}",got.len(),want.len()));}else{for (i,(g,w)) in got.iter().zip(want).enumerate(){support::compare_run(g,w,&mut errors,id,i,false);if g.render_codepoints.contains(&0xFFFD){errors.push(format!("{id}: run[{i}] contains U+FFFD"));}replacement_checks+=1;}}
            let group=c["group"].as_str().unwrap_or("");if matches!(group,"single"|"targeted"|"interpreted-quote"|"linja-sike"){match n.render_full_to_png(input,&o){Ok(png)=>if png.len()<100{errors.push(format!("{id}: PNG too short: {}",png.len()));}else{png_checks+=1;},Err(e)=>errors.push(format!("{id}: PNG render threw {e}")),}}
        },Err(e)=>errors.push(format!("{id}: build threw {e}"))}if errors.len()==before{passed+=1;}}
    println!("Rust JavaScript-derived mixed-feature semantic interactions: {passed}/{} {}",cases.len(),if errors.is_empty(){"PASS"}else{"FAIL"});println!("No-replacement-glyph run checks: {replacement_checks}");println!("Mixed-feature production PNG smoke cases: {png_checks}");if !errors.is_empty(){panic!("mixed-feature failures ({}):\n{}",errors.len(),errors.join("\n"));}
}
