mod support;

use nanpa_linja_n_rust::parser::parse_number;
use nanpa_linja_n_rust::protocol::{CONFORMANCE_CORPUS_VERSION, PROTOCOL_VERSION};
use serde_json::Value;
use support::{parse_options, parse_result_to_json};

const GOLDENS: &str = include_str!("../fixtures/nanpa-linja-n-renderer-goldens-v1.0.2.json");
const EXPECTED_CORPUS_SHA256: &str =
    "e4baf51251861c114f5314fc2af05eb44e1b5dbcbdebdcd2678c868f5dbf306a";
const EXPECTED_RENDERER_SHA256: &str =
    "a7ec74577e1663ba980e49e1ca962e59c8397246190063fb84d02fb525b3f10f";
const EXPECTED_RENDERER_CASES: usize = 15;

#[test]
fn renderer_cases_match_all_canonical_goldens() {
    let root: Value = serde_json::from_str(GOLDENS).expect("valid renderer golden JSON");
    assert_eq!(root["format"], "nanpa-linja-n-renderer-goldens");
    assert_eq!(root["formatVersion"].as_u64(), Some(1));
    assert_eq!(root["protocolVersion"], PROTOCOL_VERSION);
    assert_eq!(root["corpusVersion"], CONFORMANCE_CORPUS_VERSION);
    assert_eq!(root["corpus"]["sha256"], EXPECTED_CORPUS_SHA256);
    assert_eq!(root["canonicalRenderer"]["sha256"], EXPECTED_RENDERER_SHA256);
    assert_eq!(root["corpus"]["rendererCases"].as_u64(), Some(EXPECTED_RENDERER_CASES as u64));

    let cases = root["cases"].as_array().expect("renderer cases array");
    assert_eq!(cases.len(), EXPECTED_RENDERER_CASES);

    for case in cases {
        let id = case["id"].as_str().unwrap();
        assert_eq!(case["api"], "parseNumber", "renderer corpus API changed for {id}");
        let input = case["input"].as_str().expect("renderer input string");
        let options = parse_options(&case["options"]);
        let actual = parse_number(input, &options)
            .map(|r| parse_result_to_json(&r))
            .unwrap_or(Value::Null);
        let expected = case["result"].as_object().expect("canonical renderer result object");
        let actual_object = actual.as_object().unwrap_or_else(|| panic!("renderer case rejected: {id}"));

        for (field, expected_value) in expected {
            let actual_value = actual_object.get(field).unwrap_or_else(|| {
                panic!("renderer case {id} missing canonical field {field}")
            });
            assert_eq!(actual_value, expected_value, "renderer mismatch for {id} field {field}");
        }
    }

    println!("renderer conformance: {EXPECTED_RENDERER_CASES}/{EXPECTED_RENDERER_CASES} PASS");
}
