use nanpa_linja_n_rust::facade::NanpaLinjaN;
use nanpa_linja_n_rust::FullRenderOptions;

#[test]
fn traditional_decimal_matches_current_canonical_javascript_plan() {
    let nanpa = NanpaLinjaN::create().expect("facade initializes");
    let mut options = FullRenderOptions::default();
    options.parser.numeric_mode = "traditional".into();
    // Match the canonical Full Renderer Profile case exactly. Traditional
    // parity is tested with strict nanpa-linja-n digit rendering; leaving the
    // FullRenderOptions defaults here would intentionally request relaxed
    // spellings such as `wan ala`, `tu uta`, and `luka uta`.
    options.parser.relaxed_nanpa_linjan_parsing = false;
    options.parser.relaxed_nanpa_linjan_rendering = false;
    let plan = nanpa.build_full_render_plan("123.45", &options).expect("full render plan");
    assert_eq!(plan.lines.len(), 1);
    assert_eq!(plan.lines[0].runs.len(), 1);
    assert_eq!(
        plan.lines[0].runs[0].canonical_codepoints,
        vec![989501,989597,989555,989451,989550,989451,989527,989451,989505,989508,989502,989449,989502,989448,989485,989451,989501]
    );
}
