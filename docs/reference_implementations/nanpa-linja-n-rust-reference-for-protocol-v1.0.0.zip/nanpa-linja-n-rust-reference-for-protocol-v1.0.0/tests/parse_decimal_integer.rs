use nanpa_linja_n_rust::options::ParseOptions;
use nanpa_linja_n_rust::parser::parse_number;

#[test]
fn all_frozen_decimal_integer_cases_pass() {
    let json = include_str!(
        "../fixtures/nanpa-linja-n-regression-v1.0.2.json"
    );

    let corpus: serde_json::Value =
        serde_json::from_str(json).unwrap();

    for case in corpus["parserCases"]
        .as_array()
        .unwrap()
    {
        if case["category"].as_str()
            != Some("decimal.integer")
        {
            continue;
        }

        let input = case["input"].as_str().unwrap();

        let expected = case["assert"]["displayValue"]
            .as_str()
            .unwrap();

        let result = parse_number(
            input,
            &ParseOptions::default(),
        )
        .unwrap_or_else(|| {
            panic!("failed to parse {input:?}")
        });

        assert_eq!(
            result.display_value,
            expected,
            "case {}",
            case["id"].as_str().unwrap()
        );
    }
}

#[test]
fn representative_integer_result_matches_reference() {
    let result = parse_number(
        "42",
        &ParseOptions::default(),
    )
    .unwrap();

    assert_eq!(
        result.caps.as_deref(),
        Some("NENATUN")
    );

    assert_eq!(
        result.proper_name,
        "Nanpa Natun"
    );

    assert_eq!(
        result.unique_code,
        "#~AT"
    );

    assert_eq!(
        result.tp_words,
        [
            "nanpa",
            ":",
            "nena",
            "awen",
            "tu",
            "uta",
            "nanpa",
        ]
    );

    assert_eq!(
        result.ucsur_codepoints,
        [
            0xF193D,
            0xF199D,
            0xF1940,
            0xF1908,
            0xF196E,
            0xF1970,
            0xF193D,
        ]
    );

    assert_eq!(
        result.hex_codepoints,
        "F193D F199D F1940 F1908 F196E F1970 F193D"
    );

    assert_eq!(
        result.hex_with_cartouche,
        "F1990 F193D F199D F1940 F1908 F196E F1970 F193D F1991"
    );
}

#[test]
fn negative_integer_matches_reference() {
    let result = parse_number(
        "-42",
        &ParseOptions::default(),
    )
    .unwrap();

    assert_eq!(
        result.caps.as_deref(),
        Some("NENONATUN")
    );

    assert_eq!(
        result.proper_name,
        "Nanpa Nonatun"
    );

    assert_eq!(
        result.unique_code,
        "#~oAT"
    );

    assert_eq!(
        result.display_value,
        "-42"
    );

    assert_eq!(
        result.tp_words,
        [
            "nanpa",
            ":",
            "nena",
            "ona",
            "nena",
            "awen",
            "tu",
            "uta",
            "nanpa",
        ]
    );
}

#[test]
fn leading_zeroes_are_preserved() {
    let result = parse_number(
        "007",
        &ParseOptions::default(),
    )
    .unwrap();

    assert_eq!(
        result.display_value,
        "007"
    );

    assert_eq!(
        result.caps.as_deref(),
        Some("NENINIMUN")
    );

    assert_eq!(
        result.proper_name,
        "Nanpa Ninimun"
    );

    assert_eq!(
        result.unique_code,
        "#~IIM"
    );
}

#[test]
fn formerly_unsupported_syntax_is_now_accepted() {
    let options = ParseOptions::default();

    for input in [
        "1/2",
        "50%",
        "#FF",
        "0b101",
        "12:30",
        "Nanpa Wan",
    ] {
        assert!(
            parse_number(input, &options).is_some(),
            "{input:?} should now be implemented"
        );
    }
}
