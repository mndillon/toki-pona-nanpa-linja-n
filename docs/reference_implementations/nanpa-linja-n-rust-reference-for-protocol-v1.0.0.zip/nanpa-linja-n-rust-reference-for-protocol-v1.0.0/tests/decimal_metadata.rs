use nanpa_linja_n_rust::decimal_metadata::*;

#[test]
fn decimal_markers_match_parse_number_reference() {
    assert_eq!(NEGATIVE_SIGN.unique_code, "o");
    assert_eq!(NEGATIVE_SIGN.tp_words, ["nena", "ona"]);
    assert_eq!(NEGATIVE_SIGN.codepoints, [0xF1940, 0xF1946]);

    assert_eq!(POSITIVE_SIGN.unique_code, "e");
    assert_eq!(POSITIVE_SIGN.tp_words, ["nena", "en"]);
    assert_eq!(POSITIVE_SIGN.codepoints, [0xF1940, 0xF190A]);

    assert_eq!(DECIMAL_POINT.unique_code, "o");
    assert_eq!(
        DECIMAL_POINT.tp_words,
        ["nena", "o", "nena", "e"]
    );
    assert_eq!(
        DECIMAL_POINT.codepoints,
        [0xF1940, 0xF1944, 0xF1940, 0xF1909]
    );

    assert_eq!(FRACTION_GROUP_SEPARATOR.unique_code, "ee");
    assert_eq!(FRACTION_GROUP_SEPARATOR.proper_name, "Ene");
    assert_eq!(
        FRACTION_GROUP_SEPARATOR.tp_words,
        ["nena", "e", "nena", "e"]
    );
    assert_eq!(
        FRACTION_GROUP_SEPARATOR.codepoints,
        [0xF1940, 0xF1909, 0xF1940, 0xF1909]
    );

    assert_eq!(PERCENT.unique_code, "ok");
    assert_eq!(PERCENT.proper_name, "Oken");
    assert_eq!(
        PERCENT.tp_words,
        ["nena", "open", "kipisi", "e"]
    );
    assert_eq!(
        PERCENT.codepoints,
        [0xF1940, 0xF1947, 0xF197B, 0xF1909]
    );
}