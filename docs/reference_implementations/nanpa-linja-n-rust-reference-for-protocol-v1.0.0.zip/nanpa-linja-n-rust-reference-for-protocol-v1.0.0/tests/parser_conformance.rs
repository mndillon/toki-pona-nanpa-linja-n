use std::collections::BTreeMap;

use nanpa_linja_n_rust::model::{NumericPart, ParseResult};
use nanpa_linja_n_rust::options::{MixedStyle, NumericMode, ParseOptions};
use nanpa_linja_n_rust::parser::parse_number;
use nanpa_linja_n_rust::protocol::{
    DecimalStartGlyph,
    CONFORMANCE_CORPUS_VERSION,
    PROTOCOL_VERSION,
};
use serde_json::{json, Map, Value};

const GOLDENS: &str = include_str!("../fixtures/nanpa-linja-n-parser-goldens-v1.0.2.json");
const EXPECTED_CORPUS_SHA256: &str =
    "3e139d2599ea23ade561a7ac07c390440856c66b008286fc60186a38049f9689";
const EXPECTED_RENDERER_SHA256: &str =
    "935b6a3e664d1ef25f496b8f7af1f8e3cfd3082c64bcec46b2dabf09e3447a7c";
const EXPECTED_CASE_COUNT: usize = 311;

const KNOWN_RESULT_FIELDS: &[&str] = &[
    "input", "caps", "properName", "uniqueCode", "ucsurCodepoints",
    "hexCodepoints", "hexWithCartouche", "tpWords", "words", "displayValue",
    "isTime", "isDate", "isTimeLike", "innerCodepoints", "codepoints",
    "numericMode", "semanticKind", "semanticStartGlyph", "kind", "numberBase",
    "isHex", "isBinary", "hexDigits", "binaryDigits", "hexParts", "binaryParts",
    "abbreviatedUcsurCodepoints", "abbreviatedWords",
];

const KNOWN_OPTION_FIELDS: &[&str] = &[
    "enableBinaryParsing", "enableHexParsing", "mixedStyle", "mode", "numericMode",
    "nanpaColonParsing", "nanpaColonRendering", "relaxedNanpaLinjanParsing",
    "relaxedNanpaLinjanRendering", "abbreviateNumericCartouches",
    "preserveNumericCartoucheBreaksInAbbreviation", "numericCartoucheStartGlyph",
];

#[derive(Debug, Default, Clone)]
struct CategoryStats {
    total: usize,
    pass: usize,
    unimplemented: usize,
    mismatch: usize,
}

fn parse_numeric_mode(value: &str) -> NumericMode {
    match value {
        "uniform" => NumericMode::Uniform,
        "traditional" => NumericMode::Traditional,
        other => panic!("unknown numeric mode in golden options: {other:?}"),
    }
}

fn parse_start_glyph(value: &str) -> DecimalStartGlyph {
    match value {
        "nanpa" => DecimalStartGlyph::Nanpa,
        "tenpo" => DecimalStartGlyph::Tenpo,
        "suno" => DecimalStartGlyph::Suno,
        "toki" => DecimalStartGlyph::Toki,
        other => panic!("unknown numeric cartouche start glyph: {other:?}"),
    }
}

fn options_from_json(value: &Value) -> ParseOptions {
    let object = value.as_object().expect("golden case options must be an object");
    for key in object.keys() {
        assert!(
            KNOWN_OPTION_FIELDS.contains(&key.as_str()),
            "unmodelled parser option in goldens: {key}"
        );
    }

    let mut options = ParseOptions::default();
    if let Some(value) = object.get("enableBinaryParsing") {
        options.enable_binary_parsing = value.as_bool().unwrap();
    }
    if let Some(value) = object.get("enableHexParsing") {
        options.enable_hex_parsing = value.as_bool().unwrap();
    }
    if let Some(value) = object.get("mixedStyle") {
        match value.as_str().unwrap() {
            "short" => options.mixed_style = MixedStyle::Short,
            other => panic!("unknown mixedStyle in goldens: {other:?}"),
        }
    }
    if let Some(value) = object.get("mode") {
        let parsed = parse_numeric_mode(value.as_str().unwrap());
        options.mode = parsed;
        options.numeric_mode = parsed;
    }
    if let Some(value) = object.get("numericMode") {
        options.numeric_mode = parse_numeric_mode(value.as_str().unwrap());
    }
    if let Some(value) = object.get("nanpaColonParsing") {
        options.nanpa_colon_parsing = value.as_bool().unwrap();
    }
    if let Some(value) = object.get("nanpaColonRendering") {
        options.nanpa_colon_rendering = value.as_bool().unwrap();
    }
    if let Some(value) = object.get("relaxedNanpaLinjanParsing") {
        options.relaxed_nanpa_linjan_parsing = value.as_bool().unwrap();
    }
    if let Some(value) = object.get("relaxedNanpaLinjanRendering") {
        options.relaxed_nanpa_linjan_rendering = value.as_bool().unwrap();
    }
    if let Some(value) = object.get("abbreviateNumericCartouches") {
        options.abbreviate_numeric_cartouches = value.as_bool().unwrap();
    }
    if let Some(value) = object.get("preserveNumericCartoucheBreaksInAbbreviation") {
        options.preserve_numeric_cartouche_breaks_in_abbreviation = value.as_bool().unwrap();
    }
    if let Some(value) = object.get("numericCartoucheStartGlyph") {
        options.numeric_cartouche_start_glyph = if value.is_null() {
            None
        } else {
            Some(parse_start_glyph(value.as_str().unwrap()))
        };
    }
    options
}

fn numeric_parts_to_json(parts: &[NumericPart]) -> Value {
    Value::Array(
        parts.iter().map(|part| match part {
            NumericPart::Digits(digits) => json!({
                "kind": "digits",
                "digits": digits,
            }),
            NumericPart::Delimiter(ch) => {
                // The existing public Rust model stores a char, while canonical
                // hex/binary proper-name separators may carry JS null. The
                // candidate implementation uses '\0' internally for that one
                // representational case and normalizes it back to JSON null here.
                let char_value = if *ch == '\0' {
                    Value::Null
                } else {
                    json!(ch.to_string())
                };
                json!({
                    "kind": "delimiter",
                    "char": char_value,
                })
            }
        }).collect(),
    )
}

fn optional_numeric_parts_to_json(parts: &Option<Vec<NumericPart>>) -> Value {
    match parts {
        Some(parts) => numeric_parts_to_json(parts),
        None => Value::Null,
    }
}

fn rust_result_to_json(result: &ParseResult) -> Value {
    let mut out = Map::<String, Value>::new();
    out.insert("input".into(), json!(result.input));
    out.insert("caps".into(), json!(result.caps));
    out.insert("properName".into(), json!(result.proper_name));
    out.insert("uniqueCode".into(), json!(result.unique_code));
    out.insert("ucsurCodepoints".into(), json!(result.ucsur_codepoints));
    out.insert("hexCodepoints".into(), json!(result.hex_codepoints));
    out.insert("hexWithCartouche".into(), json!(result.hex_with_cartouche));
    out.insert("tpWords".into(), json!(result.tp_words));
    out.insert("words".into(), json!(result.words));
    out.insert("displayValue".into(), json!(result.display_value));
    out.insert("isTime".into(), json!(result.is_time));
    out.insert("isDate".into(), json!(result.is_date));
    out.insert("isTimeLike".into(), json!(result.is_time_like));
    out.insert("innerCodepoints".into(), json!(result.inner_codepoints));
    out.insert("codepoints".into(), json!(result.codepoints));
    out.insert("numericMode".into(), json!(result.numeric_mode));
    out.insert(
        "semanticKind".into(),
        result.semantic_kind.map(|value| json!(value.as_str())).unwrap_or(Value::Null),
    );
    out.insert(
        "semanticStartGlyph".into(),
        result.semantic_start_glyph.map(|value| json!(value.as_str())).unwrap_or(Value::Null),
    );
    out.insert(
        "kind".into(),
        result.kind.as_ref().map(|value| json!(value.as_str())).unwrap_or(Value::Null),
    );
    out.insert("numberBase".into(), json!(result.number_base));
    out.insert("isHex".into(), json!(result.is_hex));
    out.insert("isBinary".into(), json!(result.is_binary));
    out.insert("hexDigits".into(), json!(result.hex_digits));
    out.insert("binaryDigits".into(), json!(result.binary_digits));
    out.insert("hexParts".into(), optional_numeric_parts_to_json(&result.hex_parts));
    out.insert("binaryParts".into(), optional_numeric_parts_to_json(&result.binary_parts));
    out.insert("abbreviatedUcsurCodepoints".into(), json!(result.abbreviated_ucsur_codepoints));
    out.insert("abbreviatedWords".into(), json!(result.abbreviated_words));
    Value::Object(out)
}

fn format_json(value: &Value) -> String {
    serde_json::to_string(value).unwrap()
}

fn compare_result(expected: &Value, actual: &ParseResult) -> Vec<String> {
    let expected = expected
        .as_object()
        .expect("canonical accepted result must be an object");
    for key in expected.keys() {
        assert!(
            KNOWN_RESULT_FIELDS.contains(&key.as_str()),
            "canonical result contains an unmodelled field: {key}"
        );
    }
    let actual_json = rust_result_to_json(actual);
    let actual = actual_json.as_object().unwrap();
    let mut differences = Vec::new();
    for (field, expected_value) in expected {
        match actual.get(field) {
            Some(actual_value) if actual_value == expected_value => {}
            Some(actual_value) => differences.push(format!(
                "{field}: expected {}, actual {}",
                format_json(expected_value),
                format_json(actual_value),
            )),
            None => differences.push(format!(
                "{field}: expected {}, actual <missing>",
                format_json(expected_value),
            )),
        }
    }
    differences
}

fn verify_golden_metadata(root: &Value) {
    assert_eq!(root["format"], "nanpa-linja-n-parser-goldens");
    assert_eq!(root["formatVersion"], 1);
    assert_eq!(root["protocolVersion"], PROTOCOL_VERSION);
    assert_eq!(root["corpusVersion"], CONFORMANCE_CORPUS_VERSION);
    assert_eq!(root["corpus"]["sha256"], EXPECTED_CORPUS_SHA256);
    assert_eq!(root["canonicalRenderer"]["sha256"], EXPECTED_RENDERER_SHA256);
    assert_eq!(root["corpus"]["parserCases"], EXPECTED_CASE_COUNT);
    assert_eq!(root["summary"]["total"], EXPECTED_CASE_COUNT);
}

#[test]
fn parser_matches_all_canonical_goldens() {
    let root: Value = serde_json::from_str(GOLDENS)
        .expect("parser golden file must contain valid JSON");
    verify_golden_metadata(&root);
    let cases = root["cases"].as_array().expect("golden file must contain cases");
    assert_eq!(cases.len(), EXPECTED_CASE_COUNT);

    let mut categories: BTreeMap<String, CategoryStats> = BTreeMap::new();
    let mut total_pass = 0usize;
    let mut total_unimplemented = 0usize;
    let mut total_mismatch = 0usize;
    let mut mismatch_details = Vec::<String>::new();

    for case in cases {
        let id = case["id"].as_str().unwrap();
        let category = case["category"].as_str().unwrap();
        let canonical = &case["canonical"];
        let canonical_status = canonical["status"].as_str().unwrap();
        let stats = categories.entry(category.to_string()).or_default();
        stats.total += 1;

        let input_value = &case["input"];
        let Some(input) = input_value.as_str() else {
            if input_value.is_null() && canonical_status == "reject" {
                stats.pass += 1;
                total_pass += 1;
                continue;
            }
            panic!(
                "non-string parser input cannot be represented by Rust API: case={id}, category={category}, input={input_value}"
            );
        };

        let options = options_from_json(&case["options"]);
        let rust_result = parse_number(input, &options);

        match (canonical_status, rust_result) {
            ("reject", None) => {
                stats.pass += 1;
                total_pass += 1;
            }
            ("reject", Some(actual)) => {
                stats.mismatch += 1;
                total_mismatch += 1;
                mismatch_details.push(format!(
                    "[{category}] {id}\n  input: {input:?}\n  canonical: reject\n  rust: accepted as {}",
                    actual.display_value
                ));
            }
            ("accept", None) => {
                stats.unimplemented += 1;
                total_unimplemented += 1;
            }
            ("accept", Some(actual)) => {
                let expected = canonical.get("result")
                    .expect("accepted canonical case must have result");
                let differences = compare_result(expected, &actual);
                if differences.is_empty() {
                    stats.pass += 1;
                    total_pass += 1;
                } else {
                    stats.mismatch += 1;
                    total_mismatch += 1;
                    mismatch_details.push(format!(
                        "[{category}] {id}\n  input: {input:?}\n  {}",
                        differences.join("\n  ")
                    ));
                }
            }
            (other, _) => panic!("unknown canonical status for {id}: {other:?}"),
        }
    }

    println!();
    println!("nanpa-linja-n Rust parser conformance");
    println!("====================================");
    println!();
    println!("{:<45} {:>6} {:>14} {:>10} {:>7}", "category", "pass", "unimplemented", "mismatch", "total");
    println!("{}", "-".repeat(86));
    for (category, stats) in &categories {
        println!(
            "{:<45} {:>6} {:>14} {:>10} {:>7}",
            category, stats.pass, stats.unimplemented, stats.mismatch, stats.total,
        );
    }
    println!("{}", "-".repeat(86));
    println!(
        "{:<45} {:>6} {:>14} {:>10} {:>7}",
        "TOTAL", total_pass, total_unimplemented, total_mismatch, cases.len(),
    );
    println!();

    if !mismatch_details.is_empty() {
        println!("MISMATCH DETAILS");
        println!("================");
        for detail in &mismatch_details {
            println!();
            println!("{detail}");
        }
        println!();
    }

    assert_eq!(
        total_mismatch,
        0,
        "{total_mismatch} parser conformance mismatch(es) detected"
    );
    assert_eq!(
        total_unimplemented,
        0,
        "{total_unimplemented} parser case(s) remain unimplemented"
    );
    assert_eq!(total_pass, EXPECTED_CASE_COUNT);
}
