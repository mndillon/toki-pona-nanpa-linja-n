use nanpa_linja_n_rust::facade::NanpaLinjaN;
use nanpa_linja_n_rust::FullRenderOptions;

#[test]
fn decimal_start_glyph_overrides_match_canonical_javascript_plan() {
    let nanpa = NanpaLinjaN::create().expect("facade initializes");
    for (name, expected_head) in [
        ("tenpo", 989547u32),
        ("suno", 989540u32),
        ("toki", 989548u32),
    ] {
        let mut options = FullRenderOptions::default();
        options.parser.numeric_cartouche_start_glyph = Some(name.to_string());
        let plan = nanpa
            .build_full_render_plan("123.45", &options)
            .expect("full render plan");
        assert_eq!(plan.lines.len(), 1, "{name}");
        assert_eq!(plan.lines[0].runs.len(), 1, "{name}");
        let cps = &plan.lines[0].runs[0].canonical_codepoints;
        assert_eq!(cps.first().copied(), Some(expected_head), "{name}");
        assert_eq!(
            cps,
            &vec![
                expected_head, 989597, 989555, 989442, 989550, 989552, 989527, 989449,
                989504, 989508, 989504, 989449, 989504, 989448, 989485, 989552, 989501,
            ],
            "{name}"
        );
    }
}
