use nanpa_linja_n_rust::facade::NanpaLinjaN;
use nanpa_linja_n_rust::FullRenderOptions;

#[test]
fn explicit_positive_decimal_matches_canonical_javascript_plan() {
    let nanpa = NanpaLinjaN::create().expect("facade initializes");
    let plan = nanpa
        .build_full_render_plan("+123.45", &FullRenderOptions::default())
        .expect("full render plan");
    assert_eq!(plan.lines.len(), 1);
    assert_eq!(plan.lines[0].runs.len(), 1);
    assert_eq!(
        plan.lines[0].runs[0].canonical_codepoints,
        vec![
            989501, 989597, 989504, 989450, 989555, 989442, 989550, 989552, 989527,
            989449, 989504, 989508, 989504, 989449, 989504, 989448, 989485, 989552, 989501,
        ]
    );
}
