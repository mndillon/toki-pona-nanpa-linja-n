use nanpa_linja_n_rust::facade::NanpaLinjaN;
use nanpa_linja_n_rust::FullRenderOptions;

const OPEN:u32=0x300C;
const CLOSE:u32=0x300D;

#[test]
fn legacy_profiles_render_te_to_as_synthetic_corner_brackets(){
    let nanpa=NanpaLinjaN::create().expect("create renderer");
    for font in ["linjaPona","linjaSike"]{
        let mut options=FullRenderOptions::default();options.font=font.into();options.font_size=56.0;
        let plan=nanpa.build_full_render_plan("te tomo to",&options).expect("render plan");
        assert_eq!(plan.lines.len(),1,"{font}");
        assert_eq!(plan.lines[0].runs.len(),3,"{font}");
        let open=&plan.lines[0].runs[0];let close=&plan.lines[0].runs[2];
        assert_eq!(open.render_mode,"synthetic-corner-bracket","{font}");
        assert_eq!(close.render_mode,"synthetic-corner-bracket","{font}");
        assert_eq!(open.canonical_codepoints,vec![OPEN],"{font}");
        assert_eq!(close.canonical_codepoints,vec![CLOSE],"{font}");
        assert_eq!(open.render_codepoints,vec![OPEN],"{font}");
        assert_eq!(close.render_codepoints,vec![CLOSE],"{font}");
        assert_eq!(open.width_px.round() as i32,21,"{font}");
        assert_eq!(close.width_px.round() as i32,21,"{font}");
        assert_eq!(open.height_px.round() as i32,43,"{font}");
        assert_eq!(close.height_px.round() as i32,43,"{font}");
        assert!(open.y_px<close.y_px,"opening corner must be lifted for {font}");

        let png=nanpa.render_full_to_png("te tomo to",&options).expect("PNG");
        assert!(png.starts_with(&[137,80,78,71,13,10,26,10]),"{font}");
        let vector=nanpa.to_vector_document("te tomo to",&options).expect("vector");
        assert!(vector.elements.iter().filter(|e|e.kind=="path").count()>=2,"{font}");
    }
}

#[test]
fn raw_unicode_and_other_profiles_do_not_activate_synthetic_mode(){
    let nanpa=NanpaLinjaN::create().expect("create renderer");
    let mut legacy=FullRenderOptions::default();legacy.font="linjaPona".into();
    let raw=nanpa.build_full_render_plan("U+300C U+300D",&legacy).expect("raw plan");
    assert!(raw.runs.iter().all(|run|run.render_mode!="synthetic-corner-bracket"));
    assert!(raw.runs.iter().all(|run|run.render_adapter_id=="identity"));

    for font in ["nasinNanpa","nasinSitelenPuMono","linjaLipamanka"]{
        let mut options=FullRenderOptions::default();options.font=font.into();
        let plan=nanpa.build_full_render_plan("te tomo to",&options).expect("plan");
        assert!(plan.runs.iter().all(|run|run.render_mode!="synthetic-corner-bracket"),"{font}");
    }
}
