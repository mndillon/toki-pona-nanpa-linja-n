mod support;

use serde_json::{json, Value};
use support::{contains_subsequence, dispatch_api, field_value, non_empty, parse_number_value, result_type};

const CORPUS: &str = include_str!("../fixtures/nanpa-linja-n-regression-v1.0.2.json");
const EXPECTED_CHECKS: usize = 1017;

fn empty_object() -> Value {
    Value::Object(Default::default())
}

fn assert_result(
    id: &str,
    result: &Value,
    spec: &serde_json::Map<String, Value>,
    checks: &mut usize,
    failures: &mut Vec<String>,
) {
    for (key, expected_original) in spec {
        if matches!(
            key.as_str(),
            "result" | "notes" | "equivalentToInput" | "equivalentValue" | "numericDomain"
        ) {
            continue;
        }

        *checks += 1;
        let mut expected = expected_original.clone();
        let actual = match key.as_str() {
            "accepted" => Value::Bool(!result.is_null()),
            "requiredFields" => {
                let required = expected.as_array().expect("requiredFields array");
                let missing = required
                    .iter()
                    .filter_map(|field| {
                        let name = field.as_str().unwrap();
                        if result.as_object().map_or(true, |o| !o.contains_key(name)) {
                            Some(Value::String(name.to_string()))
                        } else {
                            None
                        }
                    })
                    .collect::<Vec<_>>();
                expected = Value::Array(Vec::new());
                Value::Array(missing)
            }
            "absentFields" => {
                let absent = expected.as_array().expect("absentFields array");
                let present = absent
                    .iter()
                    .filter_map(|field| {
                        let name = field.as_str().unwrap();
                        if result.as_object().is_some_and(|o| o.contains_key(name)) {
                            Some(Value::String(name.to_string()))
                        } else {
                            None
                        }
                    })
                    .collect::<Vec<_>>();
                expected = Value::Array(Vec::new());
                Value::Array(present)
            }
            "properNameStartsWith" => {
                let prefix = expected.as_str().unwrap();
                let actual = field_value(result, "properName")
                    .and_then(Value::as_str)
                    .unwrap_or("");
                if !actual.starts_with(prefix) {
                    failures.push(format!(
                        "[{id}] properNameStartsWith: actual={actual:?} expected prefix={prefix:?}"
                    ));
                }
                continue;
            }
            "tpWordsFirst" => result
                .get("tpWords")
                .and_then(Value::as_array)
                .and_then(|a| a.first())
                .cloned()
                .unwrap_or(Value::Null),
            "tpWordsLast" => result
                .get("tpWords")
                .and_then(Value::as_array)
                .and_then(|a| a.last())
                .cloned()
                .unwrap_or(Value::Null),
            "tpWordsContainsSubsequence" => {
                expected = Value::Bool(true);
                Value::Bool(contains_subsequence(
                    result.get("tpWords").unwrap_or(&Value::Null),
                    expected_original,
                ))
            }
            "codepointsFirstInner" => result
                .get("innerCodepoints")
                .and_then(Value::as_array)
                .and_then(|a| a.first())
                .cloned()
                .unwrap_or(Value::Null),
            "codepointsLastInner" => result
                .get("innerCodepoints")
                .and_then(Value::as_array)
                .and_then(|a| a.last())
                .cloned()
                .unwrap_or(Value::Null),
            "cartoucheStart" => result
                .get("codepoints")
                .and_then(Value::as_array)
                .and_then(|a| a.first())
                .cloned()
                .unwrap_or(Value::Null),
            "cartoucheEnd" => result
                .get("codepoints")
                .and_then(Value::as_array)
                .and_then(|a| a.last())
                .cloned()
                .unwrap_or(Value::Null),
            "resultType" => Value::String(result_type(result).to_string()),
            "nonEmpty" => Value::Bool(non_empty(result)),
            "exact" => result.clone(),
            other => field_value(result, other).cloned().unwrap_or(Value::Null),
        };

        if actual != expected {
            failures.push(format!(
                "[{id}] {key}: actual={} expected={}",
                serde_json::to_string(&actual).unwrap(),
                serde_json::to_string(&expected).unwrap()
            ));
        }
    }
}

#[test]
fn frozen_protocol_v1_0_0_all_1017_checks_pass() {
    let corpus: Value = serde_json::from_str(CORPUS).expect("valid frozen corpus");
    let mut checks = 0usize;
    let mut failures = Vec::<String>::new();
    let empty_options = empty_object();

    for test in corpus["parserCases"].as_array().expect("parserCases") {
        let id = test["id"].as_str().unwrap();
        let api = test.get("api").and_then(Value::as_str).unwrap_or("parseNumber");
        if api != "parseNumber" {
            checks += 1;
            failures.push(format!("[{id}] unsupported parser API {api}"));
            continue;
        }
        let options = test.get("options").unwrap_or(&empty_options);
        let result = parse_number_value(&test["input"], options);
        let spec = test["assert"].as_object().expect("parser assert object");
        let accept = spec.get("result").and_then(Value::as_str) == Some("accept");
        checks += 1;
        if (!result.is_null()) != accept {
            failures.push(format!(
                "[{id}] accept/reject: actual={} expected={}",
                if result.is_null() { "reject" } else { "accept" },
                spec.get("result").and_then(Value::as_str).unwrap_or("<missing>")
            ));
            continue;
        }
        if !result.is_null() {
            assert_result(id, &result, spec, &mut checks, &mut failures);
        }
    }

    for section in ["rendererCases", "apiCases"] {
        for test in corpus[section].as_array().expect("case array") {
            let id = test["id"].as_str().unwrap();
            let api = test["api"].as_str().unwrap();
            let options = test.get("options").unwrap_or(&empty_options);
            checks += 1;
            let result = match dispatch_api(api, &test["input"], options) {
                Ok(value) => value,
                Err(error) => {
                    failures.push(format!("[{id}] API {api} failed: {error}"));
                    continue;
                }
            };
            let spec = test["assert"].as_object().expect("assert object");
            assert_result(id, &result, spec, &mut checks, &mut failures);
        }
    }

    for group in corpus["equivalenceGroups"].as_array().expect("equivalenceGroups") {
        let id = group["id"].as_str().unwrap();
        let api = group.get("api").and_then(Value::as_str).unwrap_or("parseNumber");
        if api != "parseNumber" {
            checks += 1;
            failures.push(format!("[{id}] unsupported equivalence API {api}"));
            continue;
        }
        let options = group.get("options").unwrap_or(&empty_options);
        let members = group["members"].as_array().expect("members array");
        let compare = group["compare"].as_array().expect("compare array");
        let base_input = &members[0];
        let base = parse_number_value(base_input, options);
        for field in compare {
            let field = field.as_str().unwrap();
            let expected = field_value(&base, field).cloned().unwrap_or(Value::Null);
            for input in members.iter().skip(1) {
                let result = parse_number_value(input, options);
                let actual = field_value(&result, field).cloned().unwrap_or(Value::Null);
                checks += 1;
                if actual != expected {
                    failures.push(format!(
                        "[{id}] {field}: base={} member={} actual={} expected={}",
                        serde_json::to_string(base_input).unwrap(),
                        serde_json::to_string(input).unwrap(),
                        serde_json::to_string(&actual).unwrap(),
                        serde_json::to_string(&expected).unwrap(),
                    ));
                }
            }
        }
    }

    println!("nanpa-linja-n frozen protocol checks: {checks}");
    println!("failures: {}", failures.len());
    assert_eq!(checks, EXPECTED_CHECKS, "frozen check count changed");
    assert!(
        failures.is_empty(),
        "{} frozen protocol failure(s):\n{}",
        failures.len(),
        failures.join("\n")
    );
}
