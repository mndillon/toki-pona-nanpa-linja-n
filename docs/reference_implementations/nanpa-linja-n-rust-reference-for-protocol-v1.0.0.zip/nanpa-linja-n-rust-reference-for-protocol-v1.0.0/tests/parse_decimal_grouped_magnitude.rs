use nanpa_linja_n_rust::options::ParseOptions;
use nanpa_linja_n_rust::parser::parse_number;

#[test]
fn all_frozen_grouped_decimal_cases_are_accepted() {
    let options =
        ParseOptions::default();

    let cases = [
        "1,234",
        "12,000",
        "3,000,000",
        "30,000,000",
        "300,000,000",
        "3,000,000,000",
        "7,321,900",
        "-12,340",
    ];

    for input in cases {
        assert!(
            parse_number(
                input,
                &options,
            )
            .is_some(),
            "frozen grouped decimal case was rejected: {input}"
        );
    }
}

#[test]
fn all_frozen_magnitude_cases_are_accepted() {
    let options =
        ParseOptions::default();

    let cases = [
        "1K",
        "1M",
        "1B",
        "1T",
        "64.5M",
        "12K",
        "3.5B",
    ];

    for input in cases {
        assert!(
            parse_number(
                input,
                &options,
            )
            .is_some(),
            "frozen magnitude case was rejected: {input}"
        );
    }
}

#[test]
fn grouped_decimal_reference_fields_match() {
    let options =
        ParseOptions::default();

    let result =
        parse_number(
            "1,234",
            &options,
        )
        .unwrap();

    assert_eq!(
        result.caps.as_deref(),
        Some(
            "NEWANEKETUSENAN"
        )
    );

    assert_eq!(
        result.proper_name,
        "Nanpa Wan Eke Tusenan"
    );

    assert_eq!(
        result.unique_code,
        "#~WkTSA"
    );

    assert_eq!(
        result.display_value,
        "1,234"
    );
}

#[test]
fn trailing_zero_groups_become_magnitude() {
    let options =
        ParseOptions::default();

    let cases = [
        (
            "12,000",
            "NEWATUNEKEN",
            "#~WTk",
            "12K",
        ),
        (
            "3,000,000",
            "NESENEKEKEN",
            "#~Skk",
            "3M",
        ),
        (
            "30,000,000",
            "NESENINEKEKEN",
            "#~SIkk",
            "30M",
        ),
        (
            "300,000,000",
            "NESENININEKEKEN",
            "#~SIIkk",
            "300M",
        ),
        (
            "3,000,000,000",
            "NESENEKEKEKEN",
            "#~Skkk",
            "3B",
        ),
    ];

    for (
        input,
        caps,
        unique_code,
        display_value,
    ) in cases
    {
        let result =
            parse_number(
                input,
                &options,
            )
            .unwrap();

        assert_eq!(
            result.caps.as_deref(),
            Some(caps),
            "caps mismatch for {input}"
        );

        assert_eq!(
            result.unique_code,
            unique_code,
            "unique code mismatch for {input}"
        );

        assert_eq!(
            result.display_value,
            display_value,
            "display mismatch for {input}"
        );
    }
}

#[test]
fn explicit_magnitude_reference_fields_match() {
    let options =
        ParseOptions::default();

    let cases = [
        (
            "1K",
            "NEWANEKEN",
            "Nanpa Wan Eken",
            "#~Wk",
            "1K",
        ),
        (
            "1M",
            "NEWANEKEKEN",
            "Nanpa Wan Ekeken",
            "#~Wkk",
            "1M",
        ),
        (
            "1B",
            "NEWANEKEKEKEN",
            "Nanpa Wan Ekekeken",
            "#~Wkkk",
            "1B",
        ),
        (
            "1T",
            "NEWANEKEKEKEKEN",
            "Nanpa Wan Ekeke Keken",
            "#~Wkkkk",
            "1T",
        ),
        (
            "64.5M",
            "NENUNANONELUNEKEKEN",
            "Nanpa Nunan One Lun Ekeken",
            "#~UAoLkk",
            "64.5M",
        ),
        (
            "3.5B",
            "NESENONELUNEKEKEKEN",
            "Nanpa Sen One Lun Ekekeken",
            "#~SoLkkk",
            "3.5B",
        ),
    ];

    for (
        input,
        caps,
        proper_name,
        unique_code,
        display_value,
    ) in cases
    {
        let result =
            parse_number(
                input,
                &options,
            )
            .unwrap();

        assert_eq!(
            result.caps.as_deref(),
            Some(caps),
            "caps mismatch for {input}"
        );

        assert_eq!(
            result.proper_name,
            proper_name,
            "proper name mismatch for {input}"
        );

        assert_eq!(
            result.unique_code,
            unique_code,
            "unique code mismatch for {input}"
        );

        assert_eq!(
            result.display_value,
            display_value,
            "display mismatch for {input}"
        );
    }
}

#[test]
fn permissive_comma_boundaries_match_reference() {
    let options =
        ParseOptions::default();

    let accepted = [
        (
            "1,23",
            "NEWANEKETUSEN",
            "1,23",
        ),
        (
            "1,2,3",
            "NEWANEKETUNEKESEN",
            "1,2,3",
        ),
    ];

    for (
        input,
        caps,
        display_value,
    ) in accepted
    {
        let result =
            parse_number(
                input,
                &options,
            )
            .unwrap();

        assert_eq!(
            result.caps.as_deref(),
            Some(caps)
        );

        assert_eq!(
            result.display_value,
            display_value
        );
    }

    for input in [
        ",123",
        "123,",
        "1,,234",
    ] {
        assert!(
            parse_number(
                input,
                &options,
            )
            .is_none(),
            "{input:?} should be rejected"
        );
    }
}

#[test]
fn magnitude_boundary_behavior_matches_reference() {
    let options =
        ParseOptions::default();

    let cases = [
        (
            "1k",
            "NEWANEKEN",
            "Nanpa Wan Eken",
            "#~Wk",
            "1K",
        ),
        (
            ".5K",
            "NENINONELUNEKEN",
            "Nanpa Nin One Lun Eken",
            "#~IoLk",
            "0.5K",
        ),
        (
            "1.2K",
            "NEWANONETUNEKEN",
            "Nanpa Wan One Tun Eken",
            "#~WoTk",
            "1.2K",
        ),
        (
            "-12K",
            "NENOWATUNEKEN",
            "Nanpa Nowatun Eken",
            "#~oWTk",
            "-12K",
        ),
        (
            "+12K",
            "NENSWATUNEKEN",
            "Nanpa Newatun Eken",
            "#~eWTk",
            "+12K",
        ),
        (
            "1,000K",
            "NEWANEKENEKEN",
            "Nanpa Wan Eken Eken",
            "#~Wkk",
            "1M",
        ),
    ];

    for (
        input,
        caps,
        proper_name,
        unique_code,
        display_value,
    ) in cases
    {
        let result =
            parse_number(
                input,
                &options,
            )
            .unwrap();

        assert_eq!(
            result.caps.as_deref(),
            Some(caps),
            "caps mismatch for {input}"
        );

        assert_eq!(
            result.proper_name,
            proper_name,
            "proper name mismatch for {input}"
        );

        assert_eq!(
            result.unique_code,
            unique_code,
            "unique code mismatch for {input}"
        );

        assert_eq!(
            result.display_value,
            display_value,
            "display mismatch for {input}"
        );
    }

    for input in [
        "K",
        "1KK",
    ] {
        assert!(
            parse_number(
                input,
                &options,
            )
            .is_none(),
            "{input:?} should be rejected"
        );
    }
}