use nanpa_linja_n_rust::corpus::RegressionCorpus;

#[test]
fn loads_frozen_v1_0_2_corpus() {
    let json = include_str!("../fixtures/nanpa-linja-n-regression-v1.0.2.json");

    let corpus: RegressionCorpus =
        serde_json::from_str(json).expect("failed to deserialize frozen regression corpus");

    assert_eq!(corpus.parser_cases.len(), 320);
    assert_eq!(corpus.renderer_cases.len(), 15);
    assert_eq!(corpus.api_cases.len(), 9);
    assert_eq!(corpus.equivalence_groups.len(), 8);

    for case in &corpus.parser_cases {
        assert!(
            case.assertion.extra.is_empty(),
            "unmodelled assertion field(s) in {}: {:?}",
            case.id,
            case.assertion.extra
        );
    }
}