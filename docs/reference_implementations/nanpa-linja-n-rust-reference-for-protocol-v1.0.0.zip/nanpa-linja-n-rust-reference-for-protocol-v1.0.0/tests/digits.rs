use nanpa_linja_n_rust::digits::{
    decode_digit,
    encode_digit,
    DigitStyle,
};

#[test]
fn encodes_all_strict_digits() {
    let expected = [
        "NI", "WE", "TE", "SE", "NA",
        "LE", "NU", "ME", "PE", "JE",
    ];

    for digit in 0..=9 {
        assert_eq!(
            encode_digit(digit, DigitStyle::Strict),
            Some(expected[digit as usize])
        );
    }
}

#[test]
fn encodes_all_relaxed_digits() {
    let expected = [
        "NI", "WA", "TU", "SE", "NA",
        "LU", "NU", "MU", "PI", "JO",
    ];

    for digit in 0..=9 {
        assert_eq!(
            encode_digit(digit, DigitStyle::Relaxed),
            Some(expected[digit as usize])
        );
    }
}

#[test]
fn rejects_digit_outside_decimal_range() {
    assert_eq!(encode_digit(10, DigitStyle::Strict), None);
    assert_eq!(encode_digit(255, DigitStyle::Relaxed), None);
}

#[test]
fn strict_parsing_accepts_strict_syllables() {
    assert_eq!(decode_digit("NI", false), Some(0));
    assert_eq!(decode_digit("WE", false), Some(1));
    assert_eq!(decode_digit("TE", false), Some(2));
    assert_eq!(decode_digit("JE", false), Some(9));
}

#[test]
fn strict_parsing_rejects_relaxed_only_syllables() {
    assert_eq!(decode_digit("WA", false), None);
    assert_eq!(decode_digit("TU", false), None);
    assert_eq!(decode_digit("LU", false), None);
    assert_eq!(decode_digit("MU", false), None);
    assert_eq!(decode_digit("PI", false), None);
    assert_eq!(decode_digit("JO", false), None);
}

#[test]
fn relaxed_parsing_accepts_both_strict_and_relaxed_aliases() {
    assert_eq!(decode_digit("WE", true), Some(1));
    assert_eq!(decode_digit("WA", true), Some(1));

    assert_eq!(decode_digit("TE", true), Some(2));
    assert_eq!(decode_digit("TU", true), Some(2));

    assert_eq!(decode_digit("JE", true), Some(9));
    assert_eq!(decode_digit("JO", true), Some(9));
}

#[test]
fn parsing_is_case_insensitive() {
    assert_eq!(decode_digit("we", false), Some(1));
    assert_eq!(decode_digit("Wa", true), Some(1));
}

#[test]
fn shared_strict_relaxed_syllables_work_in_both_modes() {
    for syllable in ["NI", "SE", "NA", "NU"] {
        assert!(decode_digit(syllable, false).is_some());
        assert!(decode_digit(syllable, true).is_some());
    }
}