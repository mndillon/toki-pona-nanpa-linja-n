#![allow(dead_code)]

use nanpa_linja_n_rust::api::{
    caps_to_codepoints, caps_to_words, codepoints_to_words,
    decimal_to_ucsur_codepoints, encode_decimal, parse_identifier,
    proper_name_to_ucsur_codepoints, split_caps_to_proper_name, SplitCapsOptions,
};
use nanpa_linja_n_rust::model::{NumericPart, ParseResult};
use nanpa_linja_n_rust::options::{MixedStyle, NumericMode, ParseOptions};
use nanpa_linja_n_rust::parser::parse_number;
use nanpa_linja_n_rust::protocol::DecimalStartGlyph;
use serde_json::{json, Map, Value};

pub fn parse_numeric_mode(value: &str) -> NumericMode {
    match value {
        "uniform" => NumericMode::Uniform,
        "traditional" => NumericMode::Traditional,
        other => panic!("unknown numeric mode: {other:?}"),
    }
}

pub fn parse_start_glyph(value: &str) -> DecimalStartGlyph {
    match value {
        "nanpa" => DecimalStartGlyph::Nanpa,
        "tenpo" => DecimalStartGlyph::Tenpo,
        "suno" => DecimalStartGlyph::Suno,
        "toki" => DecimalStartGlyph::Toki,
        other => panic!("unknown numeric cartouche start glyph: {other:?}"),
    }
}

pub fn parse_options(value: &Value) -> ParseOptions {
    let object = value.as_object().expect("options must be an object");
    let mut options = ParseOptions::default();
    if let Some(v) = object.get("enableBinaryParsing") {
        options.enable_binary_parsing = v.as_bool().unwrap();
    }
    if let Some(v) = object.get("enableHexParsing") {
        options.enable_hex_parsing = v.as_bool().unwrap();
    }
    if let Some(v) = object.get("mixedStyle") {
        match v.as_str().unwrap() {
            "short" => options.mixed_style = MixedStyle::Short,
            other => panic!("unknown mixed style: {other:?}"),
        }
    }
    if let Some(v) = object.get("mode") {
        let mode = parse_numeric_mode(v.as_str().unwrap());
        options.mode = mode;
        options.numeric_mode = mode;
    }
    if let Some(v) = object.get("numericMode") {
        options.numeric_mode = parse_numeric_mode(v.as_str().unwrap());
    }
    if let Some(v) = object.get("nanpaColonParsing") {
        options.nanpa_colon_parsing = v.as_bool().unwrap();
    }
    if let Some(v) = object.get("nanpaColonRendering") {
        options.nanpa_colon_rendering = v.as_bool().unwrap();
    }
    if let Some(v) = object.get("relaxedNanpaLinjanParsing") {
        options.relaxed_nanpa_linjan_parsing = v.as_bool().unwrap();
    }
    if let Some(v) = object.get("relaxedNanpaLinjanRendering") {
        options.relaxed_nanpa_linjan_rendering = v.as_bool().unwrap();
    }
    if let Some(v) = object.get("abbreviateNumericCartouches") {
        options.abbreviate_numeric_cartouches = v.as_bool().unwrap();
    }
    if let Some(v) = object.get("preserveNumericCartoucheBreaksInAbbreviation") {
        options.preserve_numeric_cartouche_breaks_in_abbreviation = v.as_bool().unwrap();
    }
    if let Some(v) = object.get("nasinNanpaPona") {
        options.nasin_nanpa_pona = v.as_bool().unwrap();
    }
    if let Some(v) = object.get("numericCartoucheStartGlyph") {
        options.numeric_cartouche_start_glyph = if v.is_null() {
            None
        } else {
            Some(parse_start_glyph(v.as_str().unwrap()))
        };
    }
    options
}

pub fn split_options(value: &Value) -> SplitCapsOptions {
    let object = value.as_object().expect("split options must be an object");
    SplitCapsOptions {
        title_case: object.get("titleCase").and_then(Value::as_bool).unwrap_or(true),
        relaxed_nanpa_linjan_parsing: object
            .get("relaxedNanpaLinjanParsing")
            .and_then(Value::as_bool)
            .unwrap_or(false),
        relaxed_nanpa_linjan_rendering: object
            .get("relaxedNanpaLinjanRendering")
            .and_then(Value::as_bool)
            .unwrap_or(false),
        nanpa_colon_rendering: object
            .get("nanpaColonRendering")
            .and_then(Value::as_bool)
            .unwrap_or(false),
    }
}

fn numeric_parts_to_json(parts: &[NumericPart]) -> Value {
    Value::Array(
        parts
            .iter()
            .map(|part| match part {
                NumericPart::Digits(digits) => json!({"kind": "digits", "digits": digits}),
                NumericPart::Delimiter(ch) => {
                    let char_value = if *ch == '\0' { Value::Null } else { json!(ch.to_string()) };
                    json!({"kind": "delimiter", "char": char_value})
                }
            })
            .collect(),
    )
}

pub fn parse_result_to_json(result: &ParseResult) -> Value {
    let mut out = Map::<String, Value>::new();
    out.insert("input".into(), json!(result.input));
    out.insert("caps".into(), json!(result.caps));
    out.insert("properName".into(), json!(result.proper_name));
    out.insert("uniqueCode".into(), json!(result.unique_code));
    out.insert("ucsurCodepoints".into(), json!(result.ucsur_codepoints));
    out.insert("hexCodepoints".into(), json!(result.hex_codepoints));
    out.insert("hexWithCartouche".into(), json!(result.hex_with_cartouche));
    out.insert("tpWords".into(), json!(result.tp_words));
    out.insert("words".into(), json!(result.words));
    out.insert("displayValue".into(), json!(result.display_value));
    out.insert("isTime".into(), json!(result.is_time));
    out.insert("isDate".into(), json!(result.is_date));
    out.insert("isTimeLike".into(), json!(result.is_time_like));
    out.insert("innerCodepoints".into(), json!(result.inner_codepoints));
    out.insert("codepoints".into(), json!(result.codepoints));
    out.insert("numericMode".into(), json!(result.numeric_mode));

    if result.kind.is_none() {
        out.insert(
            "semanticKind".into(),
            result.semantic_kind.map(|v| json!(v.as_str())).unwrap_or(Value::Null),
        );
        out.insert(
            "semanticStartGlyph".into(),
            result
                .semantic_start_glyph
                .map(|v| json!(v.as_str()))
                .unwrap_or(Value::Null),
        );
    }

    if let Some(cps) = result.abbreviated_ucsur_codepoints.as_ref() {
        out.insert("abbreviatedUcsurCodepoints".into(), json!(cps));
    }
    if let Some(words) = result.abbreviated_words.as_ref() {
        out.insert("abbreviatedWords".into(), json!(words));
    }
    out.insert(
        "nasinNanpaPonaWords".into(),
        json!(result.nasin_nanpa_pona_words),
    );

    if let Some(kind) = result.kind.as_ref() {
        out.insert("kind".into(), json!(kind.as_str()));
        out.insert("numberBase".into(), json!(result.number_base));
        if result.is_hex {
            out.insert("isHex".into(), Value::Bool(true));
            out.insert("hexDigits".into(), json!(result.hex_digits));
            if let Some(parts) = result.hex_parts.as_ref() {
                out.insert("hexParts".into(), numeric_parts_to_json(parts));
            }
        }
        if result.is_binary {
            out.insert("isBinary".into(), Value::Bool(true));
            out.insert("binaryDigits".into(), json!(result.binary_digits));
            if let Some(parts) = result.binary_parts.as_ref() {
                out.insert("binaryParts".into(), numeric_parts_to_json(parts));
            }
        }
    }

    Value::Object(out)
}

pub fn parse_number_value(input: &Value, options: &Value) -> Value {
    if input.is_null() {
        return Value::Null;
    }
    let Some(text) = input.as_str() else {
        return Value::Null;
    };
    let options = parse_options(options);
    match parse_number(text, &options) {
        Some(result) => parse_result_to_json(&result),
        None => Value::Null,
    }
}

pub fn dispatch_api(api: &str, input: &Value, options: &Value) -> Result<Value, String> {
    match api {
        "parseNumber" => Ok(parse_number_value(input, options)),
        "encodeDecimal" => {
            let text = input.as_str().ok_or("encodeDecimal input must be string")?;
            let options = parse_options(options);
            encode_decimal(text, &options)
                .map(Value::String)
                .map_err(|e| e.to_string())
        }
        "decimalToUcsurCodepoints" => {
            let text = input.as_str().ok_or("decimalToUcsurCodepoints input must be string")?;
            let options = parse_options(options);
            Ok(json!(decimal_to_ucsur_codepoints(text, &options)))
        }
        "properNameToUcsurCodepoints" => {
            let text = input.as_str().ok_or("properNameToUcsurCodepoints input must be string")?;
            let options = parse_options(options);
            Ok(json!(proper_name_to_ucsur_codepoints(text, &options)))
        }
        "splitCapsToProperName" => {
            let text = input.as_str().ok_or("splitCapsToProperName input must be string")?;
            let options = split_options(options);
            split_caps_to_proper_name(text, &options)
                .map(Value::String)
                .map_err(|e| e.to_string())
        }
        "capsToWords" => {
            let text = input.as_str().ok_or("capsToWords input must be string")?;
            let options = parse_options(options);
            Ok(json!(caps_to_words(text, &options)))
        }
        "capsToCodepoints" => {
            let text = input.as_str().ok_or("capsToCodepoints input must be string")?;
            let options = parse_options(options);
            let result = caps_to_codepoints(text, &options)
                .ok_or_else(|| "capsToCodepoints rejected input".to_string())?;
            serde_json::to_value(result).map_err(|e| e.to_string())
        }
        "parseIdentifier" => {
            let text = input.as_str().ok_or("parseIdentifier input must be string")?;
            let options = parse_options(options);
            let result = parse_identifier(text, &options)
                .ok_or_else(|| "parseIdentifier rejected input".to_string())?;
            serde_json::to_value(result).map_err(|e| e.to_string())
        }
        "codepointsToWords" => {
            let values = input.as_array().ok_or("codepointsToWords input must be array")?;
            let cps = values
                .iter()
                .map(|v| v.as_u64().map(|n| n as u32).ok_or("codepoint must be integer"))
                .collect::<Result<Vec<_>, _>>()?;
            Ok(json!(codepoints_to_words(&cps)))
        }
        other => Err(format!("unsupported frozen API: {other}")),
    }
}

pub fn contains_subsequence(haystack: &Value, needle: &Value) -> bool {
    let Some(h) = haystack.as_array() else { return false; };
    let Some(n) = needle.as_array() else { return false; };
    if n.is_empty() { return true; }
    if n.len() > h.len() { return false; }
    (0..=h.len() - n.len()).any(|i| h[i..i + n.len()] == n[..])
}

pub fn result_type(value: &Value) -> &'static str {
    match value {
        Value::Null => "null",
        Value::String(_) => "string",
        Value::Bool(_) => "boolean",
        Value::Object(_) => "object",
        Value::Array(items) => {
            if items.iter().all(|v| v.as_i64().is_some() || v.as_u64().is_some()) {
                "array<int>"
            } else if items.iter().all(Value::is_string) {
                "array<string>"
            } else {
                "array"
            }
        }
        Value::Number(_) => "number",
    }
}

pub fn non_empty(value: &Value) -> bool {
    match value {
        Value::String(s) => !s.is_empty(),
        Value::Array(a) => !a.is_empty(),
        Value::Object(o) => !o.is_empty(),
        Value::Null => false,
        Value::Bool(b) => *b,
        Value::Number(_) => true,
    }
}

pub fn field_value<'a>(result: &'a Value, field: &str) -> Option<&'a Value> {
    result.as_object().and_then(|o| o.get(field))
}

// Current JavaScript Full Renderer parity helpers.
use nanpa_linja_n_rust::{DocumentAst, FullParserOptions, FullRenderOptions, FullRenderPlan, FullRenderRun};

pub fn array(v:&Value)->&Vec<Value>{v.as_array().expect("expected array")}
pub fn obj(v:&Value)->&serde_json::Map<String,Value>{v.as_object().expect("expected object")}
pub fn strv(v:Option<&Value>)->String{v.and_then(Value::as_str).unwrap_or("").to_string()}
pub fn boolv(v:Option<&Value>)->bool{v.and_then(Value::as_bool).unwrap_or(false)}
pub fn ints(v:Option<&Value>)->Vec<u32>{v.and_then(Value::as_array).map(|a|a.iter().filter_map(|x|x.as_u64().map(|n|n as u32)).collect()).unwrap_or_default()}
pub fn cp_values(v:Option<&Value>)->Vec<u32>{
    v.and_then(Value::as_array).map(|a|a.iter().filter_map(|x|{
        if let Some(n)=x.as_u64(){Some(n as u32)} else {x.as_str().and_then(|s|s.strip_prefix("U+")).and_then(|h|u32::from_str_radix(h,16).ok())}
    }).collect()).unwrap_or_default()
}

pub fn apply_parser(mut p:FullParserOptions,v:&Value)->FullParserOptions{
    let Some(m)=v.as_object() else{return p};
    macro_rules! b {($json:literal,$field:ident)=>{if let Some(x)=m.get($json).and_then(Value::as_bool){p.$field=x;}}}
    macro_rules! s {($json:literal,$field:ident)=>{if let Some(x)=m.get($json).and_then(Value::as_str){p.$field=x.to_string();}}}
    b!("enableBinaryParsing",enable_binary_parsing); b!("enableBinaryRendering",enable_binary_rendering); b!("enableHexParsing",enable_hex_parsing);
    s!("mode",mode); s!("numericMode",numeric_mode); s!("rendererMode",renderer_mode); s!("mixedStyle",mixed_style);
    b!("nanpaColonParsing",nanpa_colon_parsing); b!("nanpaColonRendering",nanpa_colon_rendering);
    b!("relaxedNanpaLinjanParsing",relaxed_nanpa_linjan_parsing); b!("relaxedNanpaLinjanRendering",relaxed_nanpa_linjan_rendering);
    b!("abbreviateNumericCartouches",abbreviate_numeric_cartouches);
    b!("preserveNumericCartoucheBreaksInAbbreviation",preserve_numeric_cartouche_breaks);
    b!("breakLinesAtFullStops",break_lines_at_full_stops); b!("showUnknownText",show_unknown_text);
    b!("autoCartoucheStandaloneProperNames",auto_cartouche_standalone_proper_names); b!("interpretDoubleQuotesAsTeTo",interpret_double_quotes_as_te_to);
    b!("cartoucheCommaTallyMarks",cartouche_comma_tally_marks); b!("nasinNanpaPona",nasin_nanpa_pona);
    s!("cartoucheTallyMode",cartouche_tally_mode);
    if let Some(v)=m.get("numericCartoucheStartGlyph") { p.numeric_cartouche_start_glyph=if v.is_null(){None}else{v.as_str().map(str::to_string)}; }
    p
}

pub fn options(font:&str,parser:&Value)->FullRenderOptions{
    let mut o=FullRenderOptions::default(); if !font.is_empty(){o.font=font.to_string();} o.parser=apply_parser(o.parser,parser); o
}

pub fn full_cps(r:&FullRenderRun)->Vec<u32>{
    if r.font_role=="cartouche"||r.font_role=="number"||r.numeric_cartouche{let mut v=vec![0xF1990];v.extend(&r.canonical_codepoints);v.push(0xF1991);v}else{vec![]}
}

pub fn compare_ast(g:&DocumentAst,w:&Value,errors:&mut Vec<String>,id:&str){
    let Some(wm)=w.as_object() else{return};
    if let Some(x)=wm.get("normalizedInput").and_then(Value::as_str){if g.normalized_input!=x{errors.push(format!("{id}: AST.normalizedInput got={:?} want={:?}",g.normalized_input,x));}}
    let Some(wlines)=wm.get("lines").and_then(Value::as_array) else{return};
    if g.lines.len()!=wlines.len(){errors.push(format!("{id}: AST line count got={} want={}",g.lines.len(),wlines.len()));return;}
    for (i,(gl,wlv)) in g.lines.iter().zip(wlines).enumerate(){let wl=obj(wlv);
        if let Some(x)=wl.get("sourceText").and_then(Value::as_str){if gl.source_text!=x{errors.push(format!("{id}: AST line[{i}].sourceText got={:?} want={:?}",gl.source_text,x));}}
        let Some(wc)=wl.get("children").and_then(Value::as_array) else{continue}; if gl.children.len()!=wc.len(){errors.push(format!("{id}: AST line[{i}] child count got={} want={}",gl.children.len(),wc.len()));continue;}
        for (j,(gs,wsv)) in gl.children.iter().zip(wc).enumerate(){let ws=obj(wsv);if let Some(x)=ws.get("kind").and_then(Value::as_str){if gs.kind!=x{errors.push(format!("{id}: AST child[{i},{j}] kind got={} want={x}",gs.kind));}}if let Some(x)=ws.get("value").and_then(Value::as_str){if gs.value!=x{errors.push(format!("{id}: AST child[{i},{j}] value got={:?} want={:?}",gs.value,x));}}
            if let Some(x)=ws.get("openQuote").and_then(Value::as_str){if gs.open_quote!=x{errors.push(format!("{id}: AST child[{i},{j}] openQuote mismatch"));}} if let Some(x)=ws.get("closeQuote").and_then(Value::as_str){if gs.close_quote!=x{errors.push(format!("{id}: AST child[{i},{j}] closeQuote mismatch"));}}
            if let Some(wi)=ws.get("image").and_then(Value::as_object){match &gs.image{None=>errors.push(format!("{id}: AST child[{i},{j}] missing image")),Some(gi)=>{for (k,got) in [("src",gi.src.as_str()),("w",gi.width.as_str()),("h",gi.height.as_str()),("alt",gi.alt.as_str()),("valign",gi.v_align.as_str())]{if let Some(x)=wi.get(k).and_then(Value::as_str){if got!=x{errors.push(format!("{id}: AST image {k} got={got:?} want={x:?}"));}}}}}}
        }
    }
}

pub fn compare_run(g:&FullRenderRun,w:&Value,errors:&mut Vec<String>,id:&str,index:usize,random_cps:bool){
    let m=obj(w);let p=format!("run[{index}]");
    macro_rules! eqs {($key:literal,$got:expr)=>{if let Some(x)=m.get($key).and_then(Value::as_str){if $got!=x{errors.push(format!("{id}: {p} {} got={:?} want={:?}",$key,$got,x));}}}}
    macro_rules! eqb {($key:literal,$got:expr)=>{if let Some(x)=m.get($key).and_then(Value::as_bool){if $got!=x{errors.push(format!("{id}: {p} {} got={} want={}",$key,$got,x));}}}}
    eqs!("kind",g.kind.as_str()); eqs!("renderMode",g.render_mode.as_str()); eqs!("fontRole",g.font_role.as_str()); eqs!("sourceText",g.source_text.as_str()); eqs!("sourceKind",g.source_kind.as_str()); eqs!("renderAdapterId",g.render_adapter_id.as_str());
    if m.contains_key("requestedRenderAdapterId"){eqs!("requestedRenderAdapterId",g.requested_render_adapter_id.as_str());}
    eqb!("isQuoted",g.quoted); eqb!("interpretedQuote",g.interpreted_quote); eqb!("isUnrecognized",g.unrecognized); eqb!("isNumericCartouche",g.numeric_cartouche); if m.contains_key("isLiteralCartouche"){eqb!("isLiteralCartouche",g.literal_cartouche);}
    if !random_cps {let want=ints(m.get("canonicalCps"));if g.canonical_codepoints!=want{errors.push(format!("{id}: {p} canonicalCps got={:?} want={:?}",g.canonical_codepoints,want));}let want=ints(m.get("renderCps"));if g.render_codepoints!=want{errors.push(format!("{id}: {p} renderCps got={:?} want={:?}",g.render_codepoints,want));}if let Some(v)=m.get("canonicalFullCps"){let want=ints(Some(v));if !want.is_empty()&&full_cps(g)!=want{errors.push(format!("{id}: {p} canonicalFullCps got={:?} want={:?}",full_cps(g),want));}}}
    if let Some(x)=m.get("manualTallies"){let want=ints(Some(x)).into_iter().map(|n|n as usize).collect::<Vec<_>>();if g.manual_tallies!=want{errors.push(format!("{id}: {p} manualTallies got={:?} want={:?}",g.manual_tallies,want));}}
    if let Some(x)=m.get("encodedText").and_then(Value::as_str){if g.render_text!=x{errors.push(format!("{id}: {p} encodedText got={:?} want={:?}",g.render_text,x));}}
    if let Some(x)=m.get("imageAlt").and_then(Value::as_str){if g.image_alt!=x{errors.push(format!("{id}: {p} imageAlt got={:?} want={:?}",g.image_alt,x));}}
}

pub fn flatten(p:&FullRenderPlan)->&[FullRenderRun]{&p.runs}

