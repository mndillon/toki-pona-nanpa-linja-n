#![allow(dead_code)]

use nanpa_linja_n_rust::api::{
    caps_to_codepoints, caps_to_words, codepoints_to_words,
    decimal_to_ucsur_codepoints, encode_decimal, parse_identifier,
    proper_name_to_ucsur_codepoints, split_caps_to_proper_name, SplitCapsOptions,
};
use nanpa_linja_n_rust::model::{NumericPart, ParseResult};
use nanpa_linja_n_rust::options::{MixedStyle, NumericMode, ParseOptions};
use nanpa_linja_n_rust::parser::parse_number;
use nanpa_linja_n_rust::protocol::DecimalStartGlyph;
use serde_json::{json, Map, Value};

pub fn parse_numeric_mode(value: &str) -> NumericMode {
    match value {
        "uniform" => NumericMode::Uniform,
        "traditional" => NumericMode::Traditional,
        other => panic!("unknown numeric mode: {other:?}"),
    }
}

pub fn parse_start_glyph(value: &str) -> DecimalStartGlyph {
    match value {
        "nanpa" => DecimalStartGlyph::Nanpa,
        "tenpo" => DecimalStartGlyph::Tenpo,
        "suno" => DecimalStartGlyph::Suno,
        "toki" => DecimalStartGlyph::Toki,
        other => panic!("unknown numeric cartouche start glyph: {other:?}"),
    }
}

pub fn parse_options(value: &Value) -> ParseOptions {
    let object = value.as_object().expect("options must be an object");
    let mut options = ParseOptions::default();
    if let Some(v) = object.get("enableBinaryParsing") {
        options.enable_binary_parsing = v.as_bool().unwrap();
    }
    if let Some(v) = object.get("enableHexParsing") {
        options.enable_hex_parsing = v.as_bool().unwrap();
    }
    if let Some(v) = object.get("mixedStyle") {
        match v.as_str().unwrap() {
            "short" => options.mixed_style = MixedStyle::Short,
            other => panic!("unknown mixed style: {other:?}"),
        }
    }
    if let Some(v) = object.get("mode") {
        let mode = parse_numeric_mode(v.as_str().unwrap());
        options.mode = mode;
        options.numeric_mode = mode;
    }
    if let Some(v) = object.get("numericMode") {
        options.numeric_mode = parse_numeric_mode(v.as_str().unwrap());
    }
    if let Some(v) = object.get("nanpaColonParsing") {
        options.nanpa_colon_parsing = v.as_bool().unwrap();
    }
    if let Some(v) = object.get("nanpaColonRendering") {
        options.nanpa_colon_rendering = v.as_bool().unwrap();
    }
    if let Some(v) = object.get("relaxedNanpaLinjanParsing") {
        options.relaxed_nanpa_linjan_parsing = v.as_bool().unwrap();
    }
    if let Some(v) = object.get("relaxedNanpaLinjanRendering") {
        options.relaxed_nanpa_linjan_rendering = v.as_bool().unwrap();
    }
    if let Some(v) = object.get("abbreviateNumericCartouches") {
        options.abbreviate_numeric_cartouches = v.as_bool().unwrap();
    }
    if let Some(v) = object.get("preserveNumericCartoucheBreaksInAbbreviation") {
        options.preserve_numeric_cartouche_breaks_in_abbreviation = v.as_bool().unwrap();
    }
    if let Some(v) = object.get("numericCartoucheStartGlyph") {
        options.numeric_cartouche_start_glyph = if v.is_null() {
            None
        } else {
            Some(parse_start_glyph(v.as_str().unwrap()))
        };
    }
    options
}

pub fn split_options(value: &Value) -> SplitCapsOptions {
    let object = value.as_object().expect("split options must be an object");
    SplitCapsOptions {
        title_case: object.get("titleCase").and_then(Value::as_bool).unwrap_or(true),
        relaxed_nanpa_linjan_parsing: object
            .get("relaxedNanpaLinjanParsing")
            .and_then(Value::as_bool)
            .unwrap_or(false),
        relaxed_nanpa_linjan_rendering: object
            .get("relaxedNanpaLinjanRendering")
            .and_then(Value::as_bool)
            .unwrap_or(false),
        nanpa_colon_rendering: object
            .get("nanpaColonRendering")
            .and_then(Value::as_bool)
            .unwrap_or(false),
    }
}

fn numeric_parts_to_json(parts: &[NumericPart]) -> Value {
    Value::Array(
        parts
            .iter()
            .map(|part| match part {
                NumericPart::Digits(digits) => json!({"kind": "digits", "digits": digits}),
                NumericPart::Delimiter(ch) => {
                    let char_value = if *ch == '\0' { Value::Null } else { json!(ch.to_string()) };
                    json!({"kind": "delimiter", "char": char_value})
                }
            })
            .collect(),
    )
}

pub fn parse_result_to_json(result: &ParseResult) -> Value {
    let mut out = Map::<String, Value>::new();
    out.insert("input".into(), json!(result.input));
    out.insert("caps".into(), json!(result.caps));
    out.insert("properName".into(), json!(result.proper_name));
    out.insert("uniqueCode".into(), json!(result.unique_code));
    out.insert("ucsurCodepoints".into(), json!(result.ucsur_codepoints));
    out.insert("hexCodepoints".into(), json!(result.hex_codepoints));
    out.insert("hexWithCartouche".into(), json!(result.hex_with_cartouche));
    out.insert("tpWords".into(), json!(result.tp_words));
    out.insert("words".into(), json!(result.words));
    out.insert("displayValue".into(), json!(result.display_value));
    out.insert("isTime".into(), json!(result.is_time));
    out.insert("isDate".into(), json!(result.is_date));
    out.insert("isTimeLike".into(), json!(result.is_time_like));
    out.insert("innerCodepoints".into(), json!(result.inner_codepoints));
    out.insert("codepoints".into(), json!(result.codepoints));
    out.insert("numericMode".into(), json!(result.numeric_mode));

    if result.kind.is_none() {
        out.insert(
            "semanticKind".into(),
            result.semantic_kind.map(|v| json!(v.as_str())).unwrap_or(Value::Null),
        );
        out.insert(
            "semanticStartGlyph".into(),
            result
                .semantic_start_glyph
                .map(|v| json!(v.as_str()))
                .unwrap_or(Value::Null),
        );
    }

    if let Some(kind) = result.kind.as_ref() {
        out.insert("kind".into(), json!(kind.as_str()));
        out.insert("numberBase".into(), json!(result.number_base));
        if result.is_hex {
            out.insert("isHex".into(), Value::Bool(true));
            out.insert("hexDigits".into(), json!(result.hex_digits));
            if let Some(parts) = result.hex_parts.as_ref() {
                out.insert("hexParts".into(), numeric_parts_to_json(parts));
            }
        }
        if result.is_binary {
            out.insert("isBinary".into(), Value::Bool(true));
            out.insert("binaryDigits".into(), json!(result.binary_digits));
            if let Some(parts) = result.binary_parts.as_ref() {
                out.insert("binaryParts".into(), numeric_parts_to_json(parts));
            }
        }
        if let Some(cps) = result.abbreviated_ucsur_codepoints.as_ref() {
            out.insert("abbreviatedUcsurCodepoints".into(), json!(cps));
        }
        if let Some(words) = result.abbreviated_words.as_ref() {
            out.insert("abbreviatedWords".into(), json!(words));
        }
    }

    Value::Object(out)
}

pub fn parse_number_value(input: &Value, options: &Value) -> Value {
    if input.is_null() {
        return Value::Null;
    }
    let Some(text) = input.as_str() else {
        return Value::Null;
    };
    let options = parse_options(options);
    match parse_number(text, &options) {
        Some(result) => parse_result_to_json(&result),
        None => Value::Null,
    }
}

pub fn dispatch_api(api: &str, input: &Value, options: &Value) -> Result<Value, String> {
    match api {
        "parseNumber" => Ok(parse_number_value(input, options)),
        "encodeDecimal" => {
            let text = input.as_str().ok_or("encodeDecimal input must be string")?;
            let options = parse_options(options);
            encode_decimal(text, &options)
                .map(Value::String)
                .map_err(|e| e.to_string())
        }
        "decimalToUcsurCodepoints" => {
            let text = input.as_str().ok_or("decimalToUcsurCodepoints input must be string")?;
            let options = parse_options(options);
            Ok(json!(decimal_to_ucsur_codepoints(text, &options)))
        }
        "properNameToUcsurCodepoints" => {
            let text = input.as_str().ok_or("properNameToUcsurCodepoints input must be string")?;
            let options = parse_options(options);
            Ok(json!(proper_name_to_ucsur_codepoints(text, &options)))
        }
        "splitCapsToProperName" => {
            let text = input.as_str().ok_or("splitCapsToProperName input must be string")?;
            let options = split_options(options);
            split_caps_to_proper_name(text, &options)
                .map(Value::String)
                .map_err(|e| e.to_string())
        }
        "capsToWords" => {
            let text = input.as_str().ok_or("capsToWords input must be string")?;
            let options = parse_options(options);
            Ok(json!(caps_to_words(text, &options)))
        }
        "capsToCodepoints" => {
            let text = input.as_str().ok_or("capsToCodepoints input must be string")?;
            let options = parse_options(options);
            let result = caps_to_codepoints(text, &options)
                .ok_or_else(|| "capsToCodepoints rejected input".to_string())?;
            serde_json::to_value(result).map_err(|e| e.to_string())
        }
        "parseIdentifier" => {
            let text = input.as_str().ok_or("parseIdentifier input must be string")?;
            let options = parse_options(options);
            let result = parse_identifier(text, &options)
                .ok_or_else(|| "parseIdentifier rejected input".to_string())?;
            serde_json::to_value(result).map_err(|e| e.to_string())
        }
        "codepointsToWords" => {
            let values = input.as_array().ok_or("codepointsToWords input must be array")?;
            let cps = values
                .iter()
                .map(|v| v.as_u64().map(|n| n as u32).ok_or("codepoint must be integer"))
                .collect::<Result<Vec<_>, _>>()?;
            Ok(json!(codepoints_to_words(&cps)))
        }
        other => Err(format!("unsupported frozen API: {other}")),
    }
}

pub fn contains_subsequence(haystack: &Value, needle: &Value) -> bool {
    let Some(h) = haystack.as_array() else { return false; };
    let Some(n) = needle.as_array() else { return false; };
    if n.is_empty() { return true; }
    if n.len() > h.len() { return false; }
    (0..=h.len() - n.len()).any(|i| h[i..i + n.len()] == n[..])
}

pub fn result_type(value: &Value) -> &'static str {
    match value {
        Value::Null => "null",
        Value::String(_) => "string",
        Value::Bool(_) => "boolean",
        Value::Object(_) => "object",
        Value::Array(items) => {
            if items.iter().all(|v| v.as_i64().is_some() || v.as_u64().is_some()) {
                "array<int>"
            } else if items.iter().all(Value::is_string) {
                "array<string>"
            } else {
                "array"
            }
        }
        Value::Number(_) => "number",
    }
}

pub fn non_empty(value: &Value) -> bool {
    match value {
        Value::String(s) => !s.is_empty(),
        Value::Array(a) => !a.is_empty(),
        Value::Object(o) => !o.is_empty(),
        Value::Null => false,
        Value::Bool(b) => *b,
        Value::Number(_) => true,
    }
}

pub fn field_value<'a>(result: &'a Value, field: &str) -> Option<&'a Value> {
    result.as_object().and_then(|o| o.get(field))
}
