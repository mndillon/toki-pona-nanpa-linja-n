use nanpa_linja_n_rust::options::ParseOptions;
use nanpa_linja_n_rust::parser::parse_number;

#[test]
fn all_frozen_decimal_point_cases_are_accepted() {
    let json = include_str!(
        "../fixtures/nanpa-linja-n-regression-v1.0.2.json"
    );

    let corpus: serde_json::Value =
        serde_json::from_str(json).unwrap();

    let mut count = 0;

    for case in corpus["parserCases"]
        .as_array()
        .unwrap()
    {
        if case["category"].as_str()
            != Some("decimal.decimal-point")
        {
            continue;
        }

        count += 1;

        let input = case["input"].as_str().unwrap();

        assert!(
            parse_number(
                input,
                &ParseOptions::default()
            )
            .is_some(),
            "failed case {} with input {input:?}",
            case["id"].as_str().unwrap()
        );
    }

    assert_eq!(count, 6);
}

#[test]
fn leading_decimal_point_matches_reference() {
    let result = parse_number(
        ".75",
        &ParseOptions::default(),
    )
    .unwrap();

    assert_eq!(
        result.caps.as_deref(),
        Some("NENINONEMULUN")
    );

    assert_eq!(
        result.proper_name,
        "Nanpa Nin One Mulun"
    );

    assert_eq!(
        result.unique_code,
        "#~IoML"
    );

    assert_eq!(
        result.display_value,
        "0.75"
    );

    assert_eq!(
        result.tp_words,
        [
            "nanpa",
            ":",
            "nena",
            "ijo",
            "nena",
            "o",
            "nena",
            "e",
            "mun",
            "uta",
            "luka",
            "uta",
            "nanpa",
        ]
    );
}

#[test]
fn negative_decimal_matches_reference() {
    let result = parse_number(
        "-0.5",
        &ParseOptions::default(),
    )
    .unwrap();

    assert_eq!(
        result.caps.as_deref(),
        Some("NENONINONELUN")
    );

    assert_eq!(
        result.proper_name,
        "Nanpa Nonin One Lun"
    );

    assert_eq!(
        result.unique_code,
        "#~oIoL"
    );

    assert_eq!(
        result.display_value,
        "-0.5"
    );
}

#[test]
fn positive_decimal_matches_reference() {
    let result = parse_number(
        "+0.5",
        &ParseOptions::default(),
    )
    .unwrap();

    assert_eq!(
        result.caps.as_deref(),
        Some("NENSNINONELUN")
    );

    assert_eq!(
        result.proper_name,
        "Nanpa Nenin One Lun"
    );

    assert_eq!(
        result.unique_code,
        "#~eIoL"
    );

    assert_eq!(
        result.display_value,
        "+0.5"
    );

    assert_eq!(
        result.tp_words,
        [
            "nanpa",
            ":",
            "nena",
            "en",
            "nena",
            "ijo",
            "nena",
            "o",
            "nena",
            "e",
            "luka",
            "uta",
            "nanpa",
        ]
    );

    assert_eq!(
        result.ucsur_codepoints,
        [
            0xF193D,
            0xF199D,
            0xF1940,
            0xF190A,
            0xF1940,
            0xF190C,
            0xF1940,
            0xF1944,
            0xF1940,
            0xF1909,
            0xF192D,
            0xF1970,
            0xF193D,
        ]
    );
}

#[test]
fn fractional_triplet_grouping_matches_reference() {
    let result = parse_number(
        "3.141592",
        &ParseOptions::default(),
    )
    .unwrap();

    assert_eq!(
        result.caps.as_deref(),
        Some("NESENONEWANAWANENELUJOTUN")
    );

    assert_eq!(
        result.proper_name,
        "Nanpa Sen One Wanawan Ene Lujotun"
    );

    assert_eq!(
        result.unique_code,
        "#~SoWAWeeLJT"
    );

    assert_eq!(
        result.display_value,
        "3.141_592"
    );

    assert_eq!(
        result.tp_words,
        [
            "nanpa",
            ":",
            "seli",
            "e",
            "nena",
            "o",
            "nena",
            "e",
            "wan",
            "ala",
            "nena",
            "awen",
            "wan",
            "ala",
            "nena",
            "e",
            "nena",
            "e",
            "luka",
            "uta",
            "jo",
            "open",
            "tu",
            "uta",
            "nanpa",
        ]
    );
}

#[test]
fn malformed_decimal_points_are_rejected() {
    let options = ParseOptions::default();

    for input in [
        ".",
        "1.",
        "1.2.3",
        "+",
        "-",
    ] {
        assert!(
            parse_number(input, &options).is_none(),
            "{input:?} should be rejected"
        );
    }
}