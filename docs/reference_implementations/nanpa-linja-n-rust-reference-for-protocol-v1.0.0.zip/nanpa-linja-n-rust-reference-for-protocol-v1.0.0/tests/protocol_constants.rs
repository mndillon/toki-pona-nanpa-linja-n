use nanpa_linja_n_rust::protocol::*;

#[test]
fn frozen_protocol_constants_are_correct() {
    assert_eq!(PROTOCOL_NAME, "nanpa-linja-n");
    assert_eq!(PROTOCOL_VERSION, "1.0.0");
    assert_eq!(CONFORMANCE_CORPUS_VERSION, "1.0.2");

    assert_eq!(CARTOUCHE_START, 0xF1990);
    assert_eq!(CARTOUCHE_END, 0xF1991);

    assert_eq!(
        STRICT_DIGITS,
        ["NI", "WE", "TE", "SE", "NA", "LE", "NU", "ME", "PE", "JE"]
    );

    assert_eq!(
        RELAXED_DIGITS,
        ["NI", "WA", "TU", "SE", "NA", "LU", "NU", "MU", "PI", "JO"]
    );

    assert_eq!(
        ABBREVIATED_DIGIT_WORDS,
        [
            "ijo", "wan", "tu", "seli", "awen",
            "luka", "utala", "mun", "pipi", "jo"
        ]
    );

    assert_eq!(DecimalStartGlyph::Nanpa.as_str(), "nanpa");
    assert_eq!(DecimalStartGlyph::Tenpo.as_str(), "tenpo");
    assert_eq!(DecimalStartGlyph::Suno.as_str(), "suno");
    assert_eq!(DecimalStartGlyph::Toki.as_str(), "toki");

    assert_eq!(DECIMAL_CLOSER, "nanpa");
    assert_eq!(HEX_OPENER_CLOSER, "nasa");
    assert_eq!(BINARY_OPENER_CLOSER, "noka");
}
