use nanpa_linja_n_rust::model::{NumberKind, NumericPart};

#[test]
fn number_kinds_match_protocol_names() {
    assert_eq!(NumberKind::Hex.as_str(), "hex");
    assert_eq!(NumberKind::Binary.as_str(), "binary");
}

#[test]
fn numeric_parts_represent_digits_and_delimiters() {
    assert_eq!(
        NumericPart::Digits("1A".to_string()),
        NumericPart::Digits("1A".to_string())
    );

    assert_eq!(
        NumericPart::Delimiter(':'),
        NumericPart::Delimiter(':')
    );
}