use nanpa_linja_n_rust::facade::NanpaLinjaN;
use nanpa_linja_n_rust::FullRenderOptions;

#[test]
fn mixed_style_long_matches_canonical_javascript_plan() {
    let nanpa = NanpaLinjaN::create().expect("facade initializes");
    let mut options = FullRenderOptions::default();
    options.parser.mixed_style = "long".to_string();
    let plan = nanpa
        .build_full_render_plan("8+1/2", &options)
        .expect("full render plan");
    assert_eq!(plan.lines.len(), 1);
    assert_eq!(plan.lines[0].runs.len(), 1);
    assert_eq!(
        plan.lines[0].runs[0].canonical_codepoints,
        vec![
            989501, 989597, 989521, 989453, 989504, 989508, 989504, 989508, 989504,
            989508, 989555, 989442, 989504, 989508, 989504, 989508, 989550, 989552,
            989501,
        ]
    );
}
