use nanpa_linja_n_rust::facade::NanpaLinjaN;
use nanpa_linja_n_rust::{ast_to_text, astToText, DocumentAst, DocumentLine, DocumentSegment, FullRenderOptions};

fn find_segment_mut<'a>(ast:&'a mut DocumentAst,kind:&str)->Option<&'a mut DocumentSegment>{
    ast.lines.iter_mut().flat_map(|line|line.children.iter_mut()).find(|segment|segment.kind==kind)
}

#[test]
fn ast_to_text_regression(){
    let nanpa=NanpaLinjaN::create().expect("create renderer");
    let options=FullRenderOptions::default();
    let mut passed=0usize;

    let source="jan   pona [ jan  pona,, ]\n\n“toki pona”";
    let ast=nanpa.parse_input(source,&options);
    assert_eq!(nanpa.ast_to_text(&ast).unwrap(),source);
    passed+=1;

    let source="jan li pona. ona   li pona.";
    let mut split_options=FullRenderOptions::default();
    split_options.parser.break_lines_at_full_stops=true;
    let ast=nanpa.parse_input(source,&split_options);
    assert_eq!(ast.lines.len(),2);
    assert_eq!(nanpa.ast_to_text(&ast).unwrap(),source);
    passed+=1;

    let mut ast=nanpa.parse_input("jan   pona [ jan  pona,, ]",&options);
    let bracket=find_segment_mut(&mut ast,"bracket").expect("bracket segment");
    bracket.value=" jan  suno,, ".into();
    assert_eq!(nanpa.ast_to_text(&ast).unwrap(),"jan   pona [ jan  suno,, ]");
    passed+=1;

    let mut ast=nanpa.parse_input("jan \"pona\"",&options);
    let quote=find_segment_mut(&mut ast,"quote").expect("quote segment");
    quote.value="toki".into();
    quote.open_quote="“".into();
    quote.close_quote="”".into();
    assert_eq!(nanpa.ast_to_text(&ast).unwrap(),"jan “toki”");
    passed+=1;

    let source="jan img(src='x.png', w=20, h='30', alt='x', valign='middle', wriggle=6) pona";
    let before=nanpa.parse_input(source,&options);
    let before_image=before.lines.iter().flat_map(|line|line.children.iter()).find(|segment|segment.kind=="image").and_then(|segment|segment.image.as_ref()).expect("image descriptor").clone();
    let serialized=nanpa.ast_to_text(&before).unwrap();
    let after=nanpa.parse_input(&serialized,&options);
    let after_image=after.lines.iter().flat_map(|line|line.children.iter()).find(|segment|segment.kind=="image").and_then(|segment|segment.image.as_ref()).expect("round-trip image descriptor");
    assert_eq!(after_image.src,before_image.src);
    assert_eq!(after_image.width,before_image.width);
    assert_eq!(after_image.height,before_image.height);
    assert_eq!(after_image.alt,before_image.alt);
    assert_eq!(after_image.v_align,before_image.v_align);
    assert_eq!(after_image.wriggle,before_image.wriggle);
    assert_eq!(after_image.transparent,before_image.transparent);
    passed+=1;

    let ast=nanpa.parse_input("jan\r\npona\r\ntoki",&options);
    assert_eq!(nanpa.ast_to_text(&ast).unwrap(),"jan\npona\ntoki");
    passed+=1;

    let ast=nanpa.parse_input("jan [pona]",&options);
    let snake=ast_to_text(&ast).unwrap();
    assert_eq!(snake,nanpa.ast_to_text(&ast).unwrap());
    assert_eq!(snake,nanpa.astToText(&ast).unwrap());
    assert_eq!(snake,astToText(&ast).unwrap());
    assert_eq!(snake,"jan [pona]");
    passed+=1;

    let ast=DocumentAst{kind:"document".into(),lines:vec![DocumentLine{source_line_index:0,children:vec![DocumentSegment{kind:"unsupported".into(),..DocumentSegment::default()}],..DocumentLine::default()}],..DocumentAst::default()};
    assert!(nanpa.ast_to_text(&ast).is_err());
    passed+=1;

    assert_eq!(passed,8);
    println!("Rust ast_to_text regression: {passed}/8 PASS");
}

#[test]
fn ast_to_text_render_integration(){
    let nanpa=NanpaLinjaN::create().expect("create renderer");
    let options=FullRenderOptions::default();
    let mut ast=nanpa.parse_input("jan [pona,,] 123.45",&options);
    let bracket=find_segment_mut(&mut ast,"bracket").expect("bracket segment");
    bracket.value="suno,,".into();
    let text=nanpa.ast_to_text(&ast).expect("serialize edited AST");
    let png=nanpa.render_full_to_png(&text,&options).expect("render edited AST text");
    assert!(png.starts_with(&[137,80,78,71,13,10,26,10]));
    println!("Rust ast_to_text render integration: 1/1 PASS");
}
