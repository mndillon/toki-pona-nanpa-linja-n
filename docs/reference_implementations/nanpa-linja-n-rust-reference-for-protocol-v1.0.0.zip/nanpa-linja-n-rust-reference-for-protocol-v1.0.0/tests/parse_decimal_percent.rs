use nanpa_linja_n_rust::options::ParseOptions;
use nanpa_linja_n_rust::parser::parse_number;

#[test]
fn all_frozen_percent_cases_are_accepted() {
    let options = ParseOptions::default();

    for input in [
        "0%",
        "5%",
        "-8%",
        "10.5%",
        "1000%",
        "2,000%",
    ] {
        assert!(
            parse_number(input, &options).is_some(),
            "frozen percent case was rejected: {input}"
        );
    }
}

#[test]
fn frozen_percent_reference_fields_match() {
    let options = ParseOptions::default();

    let cases = [
        (
            "0%",
            "NENIOKN",
            "Nanpa Nin Oken",
            "#~Iok",
            "0%",
        ),
        (
            "5%",
            "NELUOKN",
            "Nanpa Lun Oken",
            "#~Lok",
            "5%",
        ),
        (
            "-8%",
            "NENOPIOKN",
            "Nanpa Nopin Oken",
            "#~oPok",
            "-8%",
        ),
        (
            "10.5%",
            "NEWANINONELUOKN",
            "Nanpa Wanin One Lun Oken",
            "#~WIoLok",
            "10.5%",
        ),
        (
            "1000%",
            "NEWANININIOKN",
            "Nanpa Wanininin Oken",
            "#~WIIIok",
            "1000%",
        ),
        (
            "2,000%",
            "NETUNEKEOKN",
            "Nanpa Tun Eken Oken",
            "#~Tkok",
            "2K%",
        ),
    ];

    for (
        input,
        caps,
        proper_name,
        unique_code,
        display_value,
    ) in cases
    {
        let result =
            parse_number(input, &options)
                .expect("reference accepts percent");

        assert_eq!(
            result.caps.as_deref(),
            Some(caps),
            "caps mismatch for {input}"
        );

        assert_eq!(
            result.proper_name,
            proper_name,
            "proper-name mismatch for {input}"
        );

        assert_eq!(
            result.unique_code,
            unique_code,
            "unique-code mismatch for {input}"
        );

        assert_eq!(
            result.display_value,
            display_value,
            "display mismatch for {input}"
        );
    }
}

#[test]
fn percent_marker_words_and_codepoints_match_reference() {
    let options = ParseOptions::default();

    let result =
        parse_number("5%", &options)
            .expect("reference accepts 5%");

    assert_eq!(
        result.tp_words,
        [
            "nanpa",
            ":",
            "luka",
            "uta",
            "nena",
            "open",
            "kipisi",
            "e",
            "nanpa",
        ]
    );

    assert_eq!(
        result.ucsur_codepoints,
        [
            0xF193D,
            0xF199D,
            0xF192D,
            0xF1970,
            0xF1940,
            0xF1947,
            0xF197B,
            0xF1909,
            0xF193D,
        ]
    );
}

#[test]
fn percent_boundary_behavior_matches_reference() {
    let options = ParseOptions::default();

    let accepted = [
        (
            "+5%",
            "NENSLUOKN",
            "Nanpa Nelun Oken",
            "#~eLok",
            "+5%",
        ),
        (
            ".5%",
            "NENINONELUOKN",
            "Nanpa Nin One Lun Oken",
            "#~IoLok",
            "0.5%",
        ),
        (
            "1,23%",
            "NEWANEKETUSEOKN",
            "Nanpa Wan Eke Tusen Oken",
            "#~WkTSok",
            "1,23%",
        ),
        (
            "2K%",
            "NETUNEKEOKN",
            "Nanpa Tun Eken Oken",
            "#~Tkok",
            "2K%",
        ),
        (
            "2k%",
            "NETUNEKEOKN",
            "Nanpa Tun Eken Oken",
            "#~Tkok",
            "2K%",
        ),
        (
            "-2K%",
            "NENOTUNEKEOKN",
            "Nanpa Notun Eken Oken",
            "#~oTkok",
            "-2K%",
        ),
        (
            "5 %",
            "NELUOKN",
            "Nanpa Lun Oken",
            "#~Lok",
            "5%",
        ),
    ];

    for (
        input,
        caps,
        proper_name,
        unique_code,
        display_value,
    ) in accepted
    {
        let result =
            parse_number(input, &options)
                .expect("reference accepts percent");

        assert_eq!(
            result.caps.as_deref(),
            Some(caps),
            "caps mismatch for {input:?}"
        );

        assert_eq!(
            result.proper_name,
            proper_name,
            "proper-name mismatch for {input:?}"
        );

        assert_eq!(
            result.unique_code,
            unique_code,
            "unique-code mismatch for {input:?}"
        );

        assert_eq!(
            result.display_value,
            display_value,
            "display mismatch for {input:?}"
        );
    }

    for input in [
        "50%%",
        "%5",
        "5.%",
    ] {
        assert!(
            parse_number(input, &options).is_none(),
            "{input:?} should be rejected"
        );
    }
}