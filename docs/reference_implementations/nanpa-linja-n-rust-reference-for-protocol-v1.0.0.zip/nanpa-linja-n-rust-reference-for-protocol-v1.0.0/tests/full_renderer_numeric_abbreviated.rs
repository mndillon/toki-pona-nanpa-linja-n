use nanpa_linja_n_rust::facade::NanpaLinjaN;
use nanpa_linja_n_rust::FullRenderOptions;

#[test]
fn abbreviated_decimal_matches_canonical_javascript_plan() {
    let nanpa = NanpaLinjaN::create().expect("facade initializes");
    let mut options = FullRenderOptions::default();
    options.parser.abbreviate_numeric_cartouches = true;
    let plan = nanpa
        .build_full_render_plan("123.45", &options)
        .expect("full render plan");
    assert!(plan.abbreviated);
    assert_eq!(plan.lines.len(), 1);
    assert_eq!(plan.lines[0].runs.len(), 1);
    assert_eq!(
        plan.lines[0].runs[0].canonical_codepoints,
        vec![989501, 989597, 989555, 989550, 989527, 989508, 989448, 989485, 989501]
    );
}
