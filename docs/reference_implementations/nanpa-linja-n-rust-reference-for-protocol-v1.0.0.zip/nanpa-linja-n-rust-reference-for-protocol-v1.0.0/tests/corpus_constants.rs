use nanpa_linja_n_rust::protocol::*;
use serde_json::Value;

#[test]
fn rust_constants_match_frozen_corpus() {
    let json = include_str!("../fixtures/nanpa-linja-n-regression-v1.0.2.json");
    let corpus: Value = serde_json::from_str(json).expect("invalid frozen corpus JSON");

    let constants = &corpus["constants"];

    assert_eq!(
        constants["cartoucheStartCodepoint"].as_str(),
        Some("U+F1990")
    );
    assert_eq!(
        constants["cartoucheEndCodepoint"].as_str(),
        Some("U+F1991")
    );

    assert_eq!(
        constants["decimalCloser"].as_str(),
        Some(DECIMAL_CLOSER)
    );
    assert_eq!(
        constants["hexOpenerCloser"].as_str(),
        Some(HEX_OPENER_CLOSER)
    );
    assert_eq!(
        constants["binaryOpenerCloser"].as_str(),
        Some(BINARY_OPENER_CLOSER)
    );

    let decimal_openers: Vec<&str> = constants["decimalSemanticOpeners"]
        .as_array()
        .expect("decimalSemanticOpeners must be an array")
        .iter()
        .map(|v| v.as_str().expect("decimal opener must be a string"))
        .collect();

    assert_eq!(
        decimal_openers,
        vec!["nanpa", "tenpo", "suno", "toki"]
    );

    for digit in 0..=9 {
        let key = digit.to_string();

        assert_eq!(
            constants["strictDigits"][&key].as_str(),
            Some(STRICT_DIGITS[digit])
        );

        assert_eq!(
            constants["relaxedDigits"][&key].as_str(),
            Some(RELAXED_DIGITS[digit])
        );

        assert_eq!(
            constants["abbreviatedDigitWords"][&key].as_str(),
            Some(ABBREVIATED_DIGIT_WORDS[digit])
        );
    }

    for (hex_digit, word) in HEX_ABBREVIATED_WORDS {
        assert_eq!(
            constants["hexAbbreviatedWords"][hex_digit].as_str(),
            Some(word)
        );
    }
}