use nanpa_linja_n_rust::api::{
    caps_to_codepoints,
    caps_to_words,
    codepoints_to_words,
    decimal_to_ucsur_codepoints,
    encode_decimal,
    parse_identifier,
    proper_name_to_ucsur_codepoints,
    split_caps_to_proper_name,
    SplitCapsOptions,
};
use nanpa_linja_n_rust::options::{MixedStyle, NumericMode, ParseOptions};
use nanpa_linja_n_rust::protocol::{CONFORMANCE_CORPUS_VERSION, PROTOCOL_VERSION};
use serde_json::{json, Value};

const GOLDENS: &str =
    include_str!("../fixtures/nanpa-linja-n-api-goldens-v1.0.2.json");

const EXPECTED_CORPUS_SHA256: &str =
    "e4baf51251861c114f5314fc2af05eb44e1b5dbcbdebdcd2678c868f5dbf306a";
const EXPECTED_RENDERER_SHA256: &str =
    "a7ec74577e1663ba980e49e1ca962e59c8397246190063fb84d02fb525b3f10f";
const EXPECTED_API_CASES: usize = 9;

fn parse_numeric_mode(value: &str) -> NumericMode {
    match value {
        "uniform" => NumericMode::Uniform,
        "traditional" => NumericMode::Traditional,
        other => panic!("unknown numeric mode: {other:?}"),
    }
}

fn parse_options(value: &Value) -> ParseOptions {
    let object = value.as_object().expect("options must be an object");
    let mut options = ParseOptions::default();

    if let Some(v) = object.get("enableBinaryParsing") {
        options.enable_binary_parsing = v.as_bool().unwrap();
    }
    if let Some(v) = object.get("enableHexParsing") {
        options.enable_hex_parsing = v.as_bool().unwrap();
    }
    if let Some(v) = object.get("mixedStyle") {
        match v.as_str().unwrap() {
            "short" => options.mixed_style = MixedStyle::Short,
            other => panic!("unknown mixed style: {other:?}"),
        }
    }
    if let Some(v) = object.get("mode") {
        let mode = parse_numeric_mode(v.as_str().unwrap());
        options.mode = mode;
        options.numeric_mode = mode;
    }
    if let Some(v) = object.get("numericMode") {
        options.numeric_mode = parse_numeric_mode(v.as_str().unwrap());
    }
    if let Some(v) = object.get("nanpaColonParsing") {
        options.nanpa_colon_parsing = v.as_bool().unwrap();
    }
    if let Some(v) = object.get("nanpaColonRendering") {
        options.nanpa_colon_rendering = v.as_bool().unwrap();
    }
    if let Some(v) = object.get("relaxedNanpaLinjanParsing") {
        options.relaxed_nanpa_linjan_parsing = v.as_bool().unwrap();
    }
    if let Some(v) = object.get("relaxedNanpaLinjanRendering") {
        options.relaxed_nanpa_linjan_rendering = v.as_bool().unwrap();
    }

    options
}

fn split_options(value: &Value) -> SplitCapsOptions {
    let object = value.as_object().expect("split options must be an object");
    SplitCapsOptions {
        title_case: object.get("titleCase").and_then(Value::as_bool).unwrap_or(true),
        relaxed_nanpa_linjan_parsing: object
            .get("relaxedNanpaLinjanParsing")
            .and_then(Value::as_bool)
            .unwrap_or(false),
        relaxed_nanpa_linjan_rendering: object
            .get("relaxedNanpaLinjanRendering")
            .and_then(Value::as_bool)
            .unwrap_or(false),
        nanpa_colon_rendering: object
            .get("nanpaColonRendering")
            .and_then(Value::as_bool)
            .unwrap_or(false),
    }
}

fn verify_metadata(root: &Value) {
    assert_eq!(root["format"], "nanpa-linja-n-api-goldens");
    assert_eq!(root["formatVersion"].as_u64(), Some(1));
    assert_eq!(root["protocolVersion"], PROTOCOL_VERSION);
    assert_eq!(root["corpusVersion"], CONFORMANCE_CORPUS_VERSION);
    assert_eq!(root["corpus"]["sha256"], EXPECTED_CORPUS_SHA256);
    assert_eq!(root["canonicalRenderer"]["sha256"], EXPECTED_RENDERER_SHA256);
    assert_eq!(root["corpus"]["apiCases"].as_u64(), Some(EXPECTED_API_CASES as u64));
}

#[test]
fn api_matches_all_canonical_goldens() {
    let root: Value = serde_json::from_str(GOLDENS).expect("valid API golden JSON");
    verify_metadata(&root);

    let cases = root["cases"].as_array().expect("cases array");
    assert_eq!(cases.len(), EXPECTED_API_CASES);

    for case in cases {
        let id = case["id"].as_str().unwrap();
        let api = case["api"].as_str().unwrap();
        let expected = &case["result"];

        let actual = match api {
            "encodeDecimal" => {
                let input = case["input"].as_str().unwrap();
                let options = parse_options(&case["options"]);
                json!(encode_decimal(input, &options).expect("encodeDecimal must succeed"))
            }
            "decimalToUcsurCodepoints" => {
                let input = case["input"].as_str().unwrap();
                let options = parse_options(&case["options"]);
                json!(decimal_to_ucsur_codepoints(input, &options))
            }
            "properNameToUcsurCodepoints" => {
                let input = case["input"].as_str().unwrap();
                let options = parse_options(&case["options"]);
                json!(proper_name_to_ucsur_codepoints(input, &options))
            }
            "splitCapsToProperName" => {
                let input = case["input"].as_str().unwrap();
                let options = split_options(&case["options"]);
                json!(split_caps_to_proper_name(input, &options).expect("splitCapsToProperName must succeed"))
            }
            "capsToWords" => {
                let input = case["input"].as_str().unwrap();
                let options = parse_options(&case["options"]);
                json!(caps_to_words(input, &options))
            }
            "capsToCodepoints" => {
                let input = case["input"].as_str().unwrap();
                let options = parse_options(&case["options"]);
                serde_json::to_value(
                    caps_to_codepoints(input, &options).expect("capsToCodepoints must succeed"),
                )
                .unwrap()
            }
            "parseIdentifier" => {
                let input = case["input"].as_str().unwrap();
                let options = parse_options(&case["options"]);
                serde_json::to_value(
                    parse_identifier(input, &options).expect("parseIdentifier must succeed"),
                )
                .unwrap()
            }
            "codepointsToWords" => {
                let input = case["input"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .map(|v| v.as_u64().unwrap() as u32)
                    .collect::<Vec<_>>();
                json!(codepoints_to_words(&input))
            }
            other => panic!("unhandled API method in frozen goldens: {other}"),
        };

        assert_eq!(actual, *expected, "API golden mismatch for {id} ({api})");
    }
}

#[test]
fn parser_source_hashes_are_not_changed_by_api_work() {
    // This is intentionally a source-level invariant documented as a test name;
    // parser behavioral invariance is enforced by the existing 320-case parser
    // conformance suite, which must be run together with this API suite.
    assert_eq!(EXPECTED_API_CASES, 9);
}
