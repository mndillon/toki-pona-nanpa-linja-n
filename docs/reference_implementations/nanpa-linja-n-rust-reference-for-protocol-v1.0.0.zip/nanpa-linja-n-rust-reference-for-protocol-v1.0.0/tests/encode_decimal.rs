use nanpa_linja_n_rust::encoding::encode_decimal;
use nanpa_linja_n_rust::options::ParseOptions;

#[test]
fn relaxed_encoding_matches_reference() {
    let options = ParseOptions::default();

    let cases = [
        ("0", "NENIN"),
        ("1", "NEWAN"),
        ("2", "NETUN"),
        ("9", "NEJON"),

        ("123.45", "NEWATUSENONENALUN"),

        ("+1", "NENSWAN"),
        ("-1", "NENOWAN"),

        (".5", "NENINONELUN"),
        ("01", "NENIWAN"),

        ("50%", "NELUNIOKN"),

        ("1e3", "NEWANEKOSEN"),
        ("1E3", "NEWANEKOSEN"),
        ("1e-3", "NEWANEKONOSEN"),
        ("1e+3", "NEWANEKOSEN"),

        ("1/0", "NEWANONONIN"),
        ("1/2", "NEWANONOTUN"),
        ("1+1/2", "NEWANOKOWANONOTUN"),

        (" 123 ", "NEWATUSEN"),
        ("--1", "NENOWAN"),

        ("1.123", "NEWANONEWATUSEN"),

        (
            "1.1234",
            "NEWANONEWATUSENENENAN",
        ),

        (
            "1.123456",
            "NEWANONEWATUSENENENALUNUN",
        ),

        (
            "1.1234567",
            "NEWANONEWATUSENENENALUNUNENEMUN",
        ),

        (
            "3.141592",
            "NESENONEWANAWANENELUJOTUN",
        ),
    ];

    for (input, expected) in cases {
        assert_eq!(
            encode_decimal(
                input,
                &options,
            )
            .unwrap(),
            expected,
            "input: {input}"
        );
    }
}

#[test]
fn magnitude_encoding_matches_reference() {
    let options = ParseOptions::default();

    let cases = [
        ("1K", "NEWANEKEN"),

        ("1M", "NEWANEKEKEN"),

        ("1B", "NEWANEKEKEKEN"),

        ("1T", "NEWANEKEKEKEKEN"),

        (
            "64.5M",
            "NENUNANONELUNEKEKEN",
        ),

        ("12K", "NEWATUNEKEN"),

        (
            "3.5B",
            "NESENONELUNEKEKEKEN",
        ),
    ];

    for (input, expected) in cases {
        assert_eq!(
            encode_decimal(
                input,
                &options,
            )
            .unwrap(),
            expected,
            "magnitude input: {input}"
        );
    }
}

#[test]
fn grouped_decimal_encoding_matches_reference() {
    let options = ParseOptions::default();

    let cases = [
        (
            "1,234",
            "NEWANEKETUSENAN",
        ),

        (
            "12,000",
            "NEWATUNEKEN",
        ),

        (
            "3,000,000",
            "NESENEKEKEN",
        ),

        (
            "30,000,000",
            "NESENINEKEKEN",
        ),

        (
            "300,000,000",
            "NESENININEKEKEN",
        ),

        (
            "3,000,000,000",
            "NESENEKEKEKEN",
        ),

        (
            "7,321,900",
            "NEMUNEKESETUWANEKEJONININ",
        ),

        (
            "-12,340",
            "NENOWATUNEKESENANIN",
        ),
    ];

    for (input, expected) in cases {
        assert_eq!(
            encode_decimal(
                input,
                &options,
            )
            .unwrap(),
            expected,
            "grouped input: {input}"
        );
    }
}

#[test]
fn strict_encoding_matches_reference() {
    let mut options = ParseOptions::default();

    options.relaxed_nanpa_linjan_parsing =
        false;

    options.relaxed_nanpa_linjan_rendering =
        false;

    assert_eq!(
        encode_decimal(
            "123.45",
            &options,
        )
        .unwrap(),
        "NEWETESENONENALEN"
    );

    assert_eq!(
        encode_decimal(
            "+1",
            &options,
        )
        .unwrap(),
        "NENSWEN"
    );

    assert_eq!(
        encode_decimal(
            "-1",
            &options,
        )
        .unwrap(),
        "NENOWEN"
    );
}

#[test]
fn malformed_values_are_rejected() {
    let options = ParseOptions::default();

    for input in [
        "",
        "abc",
        "1.",
        "++1",
        "1 1/2",
    ] {
        assert!(
            encode_decimal(
                input,
                &options,
            )
            .is_err(),
            "{input:?} should be rejected"
        );
    }
}