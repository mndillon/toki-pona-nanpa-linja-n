use nanpa_linja_n_rust::options::ParseOptions;
use nanpa_linja_n_rust::parser::parse_number;

#[test]
fn digit_based_numeric_input_does_not_cross_internal_whitespace() {
    let options = ParseOptions::default();
    for input in [
        "12 34", "12 .34", "12. 34", "12 %", "1 e8", "1 *10^8",
        "1* 10^8", "1 * 10 ^ 8", "1 /2", "1/ 2", "1 +1/2", "1+ 1/2",
        "2026- 09-20", "12: 30", "1 1/2",
    ] {
        assert!(parse_number(input, &options).is_none(), "unexpectedly accepted {input:?}");
    }

    assert!(parse_number(" 123 ", &options).is_some(), "outer whitespace remains valid");
    assert!(parse_number("1+1/2", &options).is_some(), "plus mixed fraction remains valid");

    // Spaces are still part of proper-name/cartouche grammar, not digit syntax.
    let proper = parse_number("Nanpa Watusen", &options).expect("proper-name spaces remain valid");
    assert_eq!(proper.display_value, "123");
    let cartouche = parse_number("[nanpa : wan tu seli nanpa]", &options)
        .expect("cartouche spaces remain valid");
    assert_eq!(cartouche.display_value, "123");
}

#[test]
fn parse_number_exposes_current_parse_result_fields() {
    let mut options = ParseOptions::default();
    options.preserve_numeric_cartouche_breaks_in_abbreviation = true;
    let parsed = parse_number("123", &options).expect("parseNumber 123");
    assert_eq!(parsed.proper_name, "Nanpa Watusen");
    assert_eq!(parsed.unique_code, "#~WTS");
    assert_eq!(
        parsed.abbreviated_words.as_ref().expect("abbreviated words").join(" "),
        "nanpa : wan tu seli nanpa"
    );

    options.nasin_nanpa_pona = true;
    let parsed = parse_number("123", &options).expect("parseNumber 123 with nasin nanpa pona");
    assert_eq!(
        parsed.nasin_nanpa_pona_words.as_ref().expect("nasin nanpa pona words").join(" "),
        "wan ale mute tu wan"
    );
}
