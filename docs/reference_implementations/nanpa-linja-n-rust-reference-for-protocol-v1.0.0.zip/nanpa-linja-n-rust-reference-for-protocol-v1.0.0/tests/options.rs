use nanpa_linja_n_rust::options::{
    MixedStyle,
    NumericMode,
    ParseOptions,
};

#[test]
fn default_options_match_relaxed_nanpa_format() {
    let options = ParseOptions::default();

    assert!(options.enable_binary_parsing);
    assert!(options.enable_hex_parsing);

    assert_eq!(options.mixed_style, MixedStyle::Short);

    assert_eq!(options.mode, NumericMode::Uniform);
    assert_eq!(options.numeric_mode, NumericMode::Uniform);

    assert!(options.nanpa_colon_parsing);
    assert!(options.nanpa_colon_rendering);

    assert!(options.relaxed_nanpa_linjan_parsing);
    assert!(options.relaxed_nanpa_linjan_rendering);

    assert!(!options.abbreviate_numeric_cartouches);
    assert!(!options.preserve_numeric_cartouche_breaks_in_abbreviation);

    assert!(options.numeric_cartouche_start_glyph.is_none());
    assert!(!options.nasin_nanpa_pona);
}

#[test]
fn option_names_match_protocol_strings() {
    assert_eq!(NumericMode::Uniform.as_str(), "uniform");
    assert_eq!(NumericMode::Traditional.as_str(), "traditional");
    assert_eq!(MixedStyle::Short.as_str(), "short");
}