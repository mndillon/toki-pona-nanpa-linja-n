use nanpa_linja_n_rust::digit_metadata::{
    metadata_for_digit,
    DIGIT_METADATA,
};

#[test]
fn all_ten_digits_have_metadata() {
    assert_eq!(DIGIT_METADATA.len(), 10);

    for digit in 0..=9 {
        assert!(metadata_for_digit(digit).is_some());
    }

    assert!(metadata_for_digit(10).is_none());
}

#[test]
fn unique_code_letters_match_reference() {
    let expected = ['I', 'W', 'T', 'S', 'A', 'L', 'U', 'M', 'P', 'J'];

    for (digit, expected_char) in expected.iter().enumerate() {
        assert_eq!(
            metadata_for_digit(digit as u8).unwrap().unique_code,
            *expected_char
        );
    }
}

#[test]
fn tp_word_pairs_match_reference() {
    let expected = [
        ["nena", "ijo"],
        ["wan", "ala"],
        ["tu", "uta"],
        ["seli", "e"],
        ["nena", "awen"],
        ["luka", "uta"],
        ["nena", "utala"],
        ["mun", "uta"],
        ["pipi", "ike"],
        ["jo", "open"],
    ];

    for (digit, expected_words) in expected.iter().enumerate() {
        assert_eq!(
            metadata_for_digit(digit as u8).unwrap().tp_words,
            *expected_words
        );
    }
}

#[test]
fn codepoint_pairs_match_reference() {
    let expected = [
        [0xF1940, 0xF190C],
        [0xF1973, 0xF1902],
        [0xF196E, 0xF1970],
        [0xF1957, 0xF1909],
        [0xF1940, 0xF1908],
        [0xF192D, 0xF1970],
        [0xF1940, 0xF1971],
        [0xF193A, 0xF1970],
        [0xF1951, 0xF190D],
        [0xF1913, 0xF1947],
    ];

    for (digit, expected_pair) in expected.iter().enumerate() {
        assert_eq!(
            metadata_for_digit(digit as u8).unwrap().codepoints,
            *expected_pair
        );
    }
}