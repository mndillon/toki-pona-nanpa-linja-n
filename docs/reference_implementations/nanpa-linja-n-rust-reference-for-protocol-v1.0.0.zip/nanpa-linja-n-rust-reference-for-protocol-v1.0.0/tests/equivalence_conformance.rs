mod support;

use serde_json::Value;
use support::{field_value, parse_number_value};

const CORPUS: &str = include_str!("../fixtures/nanpa-linja-n-regression-v1.0.2.json");
const EXPECTED_GROUPS: usize = 8;
const EXPECTED_COMPARISONS: usize = 75;

#[test]
fn all_frozen_equivalence_groups_match() {
    let root: Value = serde_json::from_str(CORPUS).expect("valid frozen corpus JSON");
    let groups = root["equivalenceGroups"].as_array().expect("equivalence groups");
    assert_eq!(groups.len(), EXPECTED_GROUPS);

    let mut comparisons = 0usize;
    for group in groups {
        let id = group["id"].as_str().unwrap();
        let api = group.get("api").and_then(Value::as_str).unwrap_or("parseNumber");
        assert_eq!(api, "parseNumber", "unsupported equivalence API for {id}");
        let empty_options = Value::Object(Default::default());
        let options = group.get("options").unwrap_or(&empty_options);
        let members = group["members"].as_array().expect("equivalence members");
        let compare = group["compare"].as_array().expect("equivalence compare fields");
        assert!(!members.is_empty(), "equivalence group {id} has no members");

        let base_input = &members[0];
        let base = parse_number_value(base_input, options);
        assert!(!base.is_null(), "equivalence base rejected for {id}: {base_input}");

        for field in compare {
            let field = field.as_str().unwrap();
            let expected = field_value(&base, field).cloned().unwrap_or(Value::Null);
            for member in members.iter().skip(1) {
                let actual_result = parse_number_value(member, options);
                assert!(!actual_result.is_null(), "equivalence member rejected for {id}: {member}");
                let actual = field_value(&actual_result, field).cloned().unwrap_or(Value::Null);
                comparisons += 1;
                assert_eq!(
                    actual, expected,
                    "equivalence mismatch [{id}] field {field}: base={} member={}",
                    base_input, member
                );
            }
        }
    }

    assert_eq!(comparisons, EXPECTED_COMPARISONS);
    println!("equivalence conformance: {EXPECTED_GROUPS}/{EXPECTED_GROUPS} groups, {EXPECTED_COMPARISONS}/{EXPECTED_COMPARISONS} comparisons PASS");
}
