#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
OUT="${1:-$ROOT/test-output}"
mkdir -p "$OUT"

# Remove canonical numeric audit names and the obsolete Rust-only naming scheme.
find "$OUT" -maxdepth 1 -type f \( \
  -name '*-full.png' -o \
  -name '*-full-white.png' -o \
  -name '*-abbreviated.png' -o \
  -name '*-abbreviated-white.png' -o \
  -name '*--numeric-*.png' \
\) -delete

cargo run --quiet --example visual_export -- numeric "$OUT"
COUNT="$(find "$OUT" -maxdepth 1 -type f \( \
  -name '*-full.png' -o \
  -name '*-full-white.png' -o \
  -name '*-abbreviated.png' -o \
  -name '*-abbreviated-white.png' \
\) | wc -l)"
[ "$COUNT" -eq 32 ] || { echo "expected 32 numeric PNGs, got $COUNT" >&2; exit 1; }
echo "Rust numeric visual audit: 32/32 PNGs PASS"
