import fs from "node:fs";
import crypto from "node:crypto";
import path from "node:path";
import { pathToFileURL } from "node:url";

const EXPECTED_CORPUS_SHA256 =
  "e4baf51251861c114f5314fc2af05eb44e1b5dbcbdebdcd2678c868f5dbf306a";

const EXPECTED_RENDERER_SHA256 =
  "a7ec74577e1663ba980e49e1ca962e59c8397246190063fb84d02fb525b3f10f";

const EXPECTED_PARSER_CASE_COUNT = 320;

const root = process.cwd();

const corpusPath = path.resolve(
  root,
  "fixtures/nanpa-linja-n-regression-v1.0.2.json"
);

const rendererPath = process.env.NANPA_RENDERER
  ? path.resolve(root, process.env.NANPA_RENDERER)
  : path.resolve(
      root,
      "../nanpa-linja-n-browser-font-regression-v0.1.3-reference/reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js"
    );

const outputPath = path.resolve(
  root,
  "fixtures/nanpa-linja-n-parser-goldens-v1.0.2.json"
);

function sha256File(filePath) {
  const data = fs.readFileSync(filePath);

  return crypto
    .createHash("sha256")
    .update(data)
    .digest("hex");
}

function verifyFileHash(
  label,
  filePath,
  expectedHash
) {
  if (!fs.existsSync(filePath)) {
    throw new Error(
      `${label} not found:\n${filePath}`
    );
  }

  const actualHash =
    sha256File(filePath);

  if (actualHash !== expectedHash) {
    throw new Error(
      [
        `${label} SHA-256 mismatch.`,
        `Expected: ${expectedHash}`,
        `Actual:   ${actualHash}`,
        `File:     ${filePath}`,
        "",
        "Refusing to generate goldens from an unverified source.",
      ].join("\n")
    );
  }

  console.log(
    `PASS ${label} SHA-256 ${actualHash}`
  );

  return actualHash;
}

function normalizeJsonValue(value) {
  if (
    value === null ||
    typeof value === "string" ||
    typeof value === "number" ||
    typeof value === "boolean"
  ) {
    return value;
  }

  if (typeof value === "undefined") {
    return undefined;
  }

  if (Array.isArray(value)) {
    return value.map(
      normalizeJsonValue
    );
  }

  if (ArrayBuffer.isView(value)) {
    return Array.from(value).map(
      normalizeJsonValue
    );
  }

  if (typeof value === "object") {
    const output = {};

    for (
      const key of Object.keys(value).sort()
    ) {
      const normalized =
        normalizeJsonValue(value[key]);

      if (
        typeof normalized !==
        "undefined"
      ) {
        output[key] = normalized;
      }
    }

    return output;
  }

  return String(value);
}

function canonicalStatusForCase(
  parser,
  testCase
) {
  try {
    const result = parser.parseNumber(
      testCase.input,
      testCase.options ?? {}
    );

    if (
      result === null ||
      typeof result === "undefined"
    ) {
      return {
        status: "reject",
        rejection: "null",
      };
    }

    return {
      status: "accept",
      result:
        normalizeJsonValue(result),
    };
  } catch (error) {
    return {
      status: "reject",
      rejection: "throw",
      error: {
        name:
          error?.name ??
          "Error",
        message:
          error?.message ??
          String(error),
      },
    };
  }
}

function verifyCorpusExpectation(
  testCase,
  canonical
) {
  const expected =
    testCase?.assert?.result;

  if (
    expected !== "accept" &&
    expected !== "reject"
  ) {
    throw new Error(
      `Case ${testCase.id} has unknown corpus assertion result: ${JSON.stringify(expected)}`
    );
  }

  if (
    expected !== canonical.status
  ) {
    throw new Error(
      [
        `Canonical parser disagrees with frozen corpus.`,
        `Case:     ${testCase.id}`,
        `Category: ${testCase.category}`,
        `Input:    ${JSON.stringify(testCase.input)}`,
        `Corpus:   ${expected}`,
        `JS:       ${canonical.status}`,
      ].join("\n")
    );
  }
}

const corpusSha256 =
  verifyFileHash(
    "corpus",
    corpusPath,
    EXPECTED_CORPUS_SHA256
  );

const rendererSha256 =
  verifyFileHash(
    "canonical renderer",
    rendererPath,
    EXPECTED_RENDERER_SHA256
  );

const corpus = JSON.parse(
  fs.readFileSync(
    corpusPath,
    "utf8"
  )
);

if (
  !Array.isArray(
    corpus.parserCases
  )
) {
  throw new Error(
    "Frozen corpus does not contain parserCases."
  );
}

if (
  corpus.parserCases.length !==
  EXPECTED_PARSER_CASE_COUNT
) {
  throw new Error(
    [
      "Unexpected parser case count.",
      `Expected: ${EXPECTED_PARSER_CASE_COUNT}`,
      `Actual:   ${corpus.parserCases.length}`,
    ].join("\n")
  );
}

console.log(
  `PASS parser case count ${corpus.parserCases.length}`
);

const moduleUrl =
  pathToFileURL(
    rendererPath
  ).href;

const canonicalModule =
  await import(moduleUrl);

const NanpaParser =
  canonicalModule.NanpaParser;

if (
  !NanpaParser ||
  typeof NanpaParser.parseNumber
    !== "function"
) {
  throw new Error(
    "Canonical renderer does not export NanpaParser.parseNumber()."
  );
}

const cases = [];

let accepted = 0;
let rejected = 0;

const categoryCounts =
  new Map();

for (
  const testCase of
  corpus.parserCases
) {
  const canonical =
    canonicalStatusForCase(
      NanpaParser,
      testCase
    );

  verifyCorpusExpectation(
    testCase,
    canonical
  );

  if (
    canonical.status ===
    "accept"
  ) {
    accepted += 1;
  } else {
    rejected += 1;
  }

  const category =
    testCase.category;

  const existing =
    categoryCounts.get(
      category
    ) ?? {
      total: 0,
      accept: 0,
      reject: 0,
    };

  existing.total += 1;

  if (
    canonical.status ===
    "accept"
  ) {
    existing.accept += 1;
  } else {
    existing.reject += 1;
  }

  categoryCounts.set(
    category,
    existing
  );

  cases.push({
    id: testCase.id,
    category:
      testCase.category,
    input:
      testCase.input,
    options:
      normalizeJsonValue(
        testCase.options ?? {}
      ),
    corpusAssert:
      normalizeJsonValue(
        testCase.assert ?? {}
      ),
    canonical,
  });
}

const categories = {};

for (
  const category of
  [...categoryCounts.keys()]
    .sort()
) {
  categories[category] =
    categoryCounts.get(
      category
    );
}

const golden = {
  format:
    "nanpa-linja-n-parser-goldens",
  formatVersion: 1,

  protocolVersion:
    "1.0.0",

  corpusVersion:
    "1.0.2",

  corpus: {
    file:
      path.basename(
        corpusPath
      ),
    sha256:
      corpusSha256,
    parserCases:
      corpus.parserCases.length,
  },

  canonicalRenderer: {
    file:
      path.basename(
        rendererPath
      ),
    sha256:
      rendererSha256,
  },

  summary: {
    total:
      cases.length,
    accept:
      accepted,
    reject:
      rejected,
    categories:
      Object.keys(
        categories
      ).length,
  },

  categories,

  cases,
};

const serialized =
  JSON.stringify(
    golden,
    null,
    2
  ) + "\n";

fs.writeFileSync(
  outputPath,
  serialized,
  "utf8"
);

const outputSha256 =
  sha256File(
    outputPath
  );

console.log("");
console.log(
  `PASS generated ${cases.length} parser goldens`
);

console.log(
  `  accepted: ${accepted}`
);

console.log(
  `  rejected: ${rejected}`
);

console.log(
  `  categories: ${Object.keys(categories).length}`
);

console.log("");
console.log(
  `Output: ${outputPath}`
);

console.log(
  `SHA-256: ${outputSha256}`
);