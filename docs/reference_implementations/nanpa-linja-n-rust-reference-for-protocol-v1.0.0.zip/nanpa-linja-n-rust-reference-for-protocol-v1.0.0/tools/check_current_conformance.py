#!/usr/bin/env python3
import hashlib,json,pathlib,sys
root=pathlib.Path(__file__).resolve().parents[1]
renderer=root/'reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js'
sha=hashlib.sha256(renderer.read_bytes()).hexdigest()
expected='a7ec74577e1663ba980e49e1ca962e59c8397246190063fb84d02fb525b3f10f'
errors=[]
if sha!=expected: errors.append(f'renderer authority hash got={sha} want={expected}')
checks=[
 ('conformance/canonical-syntax-v1.0.1-phase1/cases.json','cases',28),
 ('conformance/canonical-syntax-v1.0.1-phase1/cases.json','fontAdapterCases',5),
 ('conformance/full-renderer-canonical-v1.0.1/cases.json','cases',254),
 ('references/javascript-composition-interactions-v1.json','cases',346),
]
for rel,key,n in checks:
 p=root/rel
 try:d=json.loads(p.read_text())
 except Exception as e: errors.append(f'{rel}: {e}');continue
 got=len(d.get(key,[]))
 if got!=n: errors.append(f'{rel}:{key} got={got} want={n}')
 if 'authority' in d and isinstance(d['authority'],dict):
  h=d['authority'].get('sha256') or d['authority'].get('rendererSha256')
  if h and h!=expected: errors.append(f'{rel}: authority sha got={h} want={expected}')
if errors:
 print('Rust current JavaScript-derived conformance authority: FAIL')
 for e in errors: print('FAIL',e)
 sys.exit(1)
print('Rust current JavaScript-derived conformance authority: PASS')
print('renderer sha256:',sha)
print('canonical syntax: 28; adapters: 5; canonical full renderer: 254; mixed interactions: 346')
