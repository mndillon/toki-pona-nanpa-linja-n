import fs from "node:fs";
import crypto from "node:crypto";
import path from "node:path";
import { pathToFileURL } from "node:url";

const EXPECTED_CORPUS_SHA256 =
  "3e139d2599ea23ade561a7ac07c390440856c66b008286fc60186a38049f9689";
const EXPECTED_RENDERER_SHA256 =
  "935b6a3e664d1ef25f496b8f7af1f8e3cfd3082c64bcec46b2dabf09e3447a7c";
const EXPECTED_API_CASE_COUNT = 9;

const root = process.cwd();
const corpusPath = path.resolve(root, "fixtures/nanpa-linja-n-regression-v1.0.2.json");
const rendererPath = process.env.NANPA_RENDERER
  ? path.resolve(root, process.env.NANPA_RENDERER)
  : path.resolve(
      root,
      "../nanpa-linja-n-browser-font-regression-v0.1.3-reference/reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js"
    );
const outputPath = path.resolve(root, "fixtures/nanpa-linja-n-api-goldens-v1.0.2.json");

function sha256File(filePath) {
  return crypto.createHash("sha256").update(fs.readFileSync(filePath)).digest("hex");
}

function verifyFileHash(label, filePath, expectedHash) {
  if (!fs.existsSync(filePath)) throw new Error(`${label} not found:\n${filePath}`);
  const actualHash = sha256File(filePath);
  if (actualHash !== expectedHash) {
    throw new Error([
      `${label} SHA-256 mismatch.`,
      `Expected: ${expectedHash}`,
      `Actual:   ${actualHash}`,
      `File:     ${filePath}`,
      "",
      "Refusing to generate API goldens from an unverified source.",
    ].join("\n"));
  }
  console.log(`PASS ${label} SHA-256 ${actualHash}`);
  return actualHash;
}

function normalize(value) {
  if (value === undefined) return undefined;
  if (value === null || ["string", "number", "boolean"].includes(typeof value)) return value;
  if (Array.isArray(value)) return value.map(normalize);
  if (value instanceof Set) return [...value].map(normalize).sort((a, b) => a - b);
  if (ArrayBuffer.isView(value)) return Array.from(value).map(normalize);
  if (typeof value === "object") {
    const out = {};
    for (const key of Object.keys(value).sort()) {
      const v = normalize(value[key]);
      if (v !== undefined) out[key] = v;
    }
    return out;
  }
  return String(value);
}

const corpusSha256 = verifyFileHash("corpus", corpusPath, EXPECTED_CORPUS_SHA256);
const rendererSha256 = verifyFileHash("canonical renderer", rendererPath, EXPECTED_RENDERER_SHA256);
const corpus = JSON.parse(fs.readFileSync(corpusPath, "utf8"));
if (!Array.isArray(corpus.apiCases) || corpus.apiCases.length !== EXPECTED_API_CASE_COUNT) {
  throw new Error(`Expected ${EXPECTED_API_CASE_COUNT} apiCases, found ${corpus.apiCases?.length ?? "missing"}`);
}
console.log(`PASS API case count ${corpus.apiCases.length}`);

const { NanpaParser } = await import(pathToFileURL(rendererPath).href);
if (!NanpaParser) throw new Error("Canonical renderer does not export NanpaParser.");

const cases = [];
for (const testCase of corpus.apiCases) {
  const fn = NanpaParser[testCase.api];
  if (typeof fn !== "function") throw new Error(`Missing canonical API method ${testCase.api}`);
  let result;
  try {
    result = fn.call(NanpaParser, testCase.input, testCase.options ?? {});
  } catch (error) {
    result = {
      __throws: true,
      name: error?.name ?? "Error",
      message: error?.message ?? String(error),
    };
  }
  cases.push({
    id: testCase.id,
    api: testCase.api,
    input: normalize(testCase.input),
    options: normalize(testCase.options ?? {}),
    corpusAssert: normalize(testCase.assert ?? {}),
    result: normalize(result),
  });
}

const golden = {
  format: "nanpa-linja-n-api-goldens",
  formatVersion: 1,
  protocolVersion: "1.0.0",
  corpusVersion: "1.0.2",
  corpus: {
    file: path.basename(corpusPath),
    sha256: corpusSha256,
    apiCases: corpus.apiCases.length,
  },
  canonicalRenderer: {
    file: path.basename(rendererPath),
    sha256: rendererSha256,
  },
  cases,
};

fs.writeFileSync(outputPath, JSON.stringify(golden, null, 2) + "\n", "utf8");
console.log(`PASS generated ${cases.length} API goldens`);
console.log(`Output: ${outputPath}`);
console.log(`SHA-256: ${sha256File(outputPath)}`);
