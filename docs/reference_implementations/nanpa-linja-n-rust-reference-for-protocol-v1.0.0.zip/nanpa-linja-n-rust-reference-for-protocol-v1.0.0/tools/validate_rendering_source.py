#!/usr/bin/env python3
"""Offline structural/integrity validation for the Rust rendering addition.

This does not replace `cargo test`.  It exists so release archives can verify
that their frozen Core-v1 sources and bundled production assets were not
silently changed or omitted.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
failures=[]
checks=0

def check(ok,msg):
    global checks
    checks+=1
    if ok:
        print('PASS',msg)
    else:
        failures.append(msg); print('FAIL',msg,file=sys.stderr)

core=json.loads((ROOT/'fixtures/core-v1-source-sha256.json').read_text())['files']
for rel,expected in core.items():
    p=ROOT/rel
    actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
    check(actual==expected,f'Core source unchanged {rel}')

asset_fixture=json.loads((ROOT/'fixtures/font-assets-sha256-v1.0.0.json').read_text())
bundle=ROOT/'resources/fonts.zip'
check(bundle.exists(),'single production font bundle resources/fonts.zip present')
actual_bundle_sha=hashlib.sha256(bundle.read_bytes()).hexdigest() if bundle.exists() else None
check(actual_bundle_sha==asset_fixture.get('bundleSha256'),'production fonts.zip SHA-256')
with zipfile.ZipFile(bundle) as zf:
    names=set(zf.namelist())
    manifest=json.loads(zf.read('fonts/preloaded-font-pairs.manifest.json'))
    for name,expected in asset_fixture['files'].items():
        entry='fonts/'+name
        actual=hashlib.sha256(zf.read(entry)).hexdigest() if entry in names else None
        check(actual==expected,f'font asset sha256 {name}')

pairs=manifest.get('pairs') or []
check(manifest.get('schema')==2,'production font manifest schema 2')
check(len(pairs)==8,'production font manifest has 8 pairs')
keys=[p.get('fontKey') for p in pairs]
check(len(keys)==len(set(keys))==8,'production font keys are unique')
for pair in pairs:
    filename=pair.get('companionFilename')
    check(bool(filename) and 'fonts/'+filename in names,f"{pair.get('fontKey')}: companion font present in ZIP")

support=manifest.get('supportFonts') or {}
for key in ('literalText','vectorSans','vectorSerif','vectorMono'):
    filename=(support.get(key) or {}).get('filename')
    check(bool(filename) and 'fonts/'+filename in names,f'support font {key} present in ZIP')

implementation='\n'.join((ROOT/'src'/name).read_text() for name in ('font_registry.rs','full_font_registry.rs','full_renderer.rs'))
for name in asset_fixture['files']:
    check(name not in implementation,f'production font filename not hard-coded in Rust source: {name}')

cases=json.loads((ROOT/'fixtures/font-golden-cases-v1.1.0.json').read_text()).get('cases') or []
plans=json.loads((ROOT/'fixtures/render-facade-plan-goldens-v1.0.0.json').read_text()).get('cases') or []
check(len(cases)==16,'production render matrix has 16 logical cases')
check(len(plans)==16,'facade render-plan golden fixture has 16 cases')
check({c.get('id') for c in cases}=={c.get('id') for c in plans},'render case IDs match plan goldens')
full=[c for c in cases if not c.get('abbreviateNumericCartouches')]
abbr=[c for c in cases if c.get('abbreviateNumericCartouches')]
check(len(full)==8 and len(abbr)==8,'render matrix is 8 full + 8 abbreviated')

cargo=(ROOT/'Cargo.toml').read_text()
for dep in ('harfrust = "=0.13.3"','fontdue = "=0.9.4"','image = { version = "=0.25.10"'):
    check(dep in cargo,f'Cargo rendering dependency pinned: {dep.split(" = ")[0]}')


# Additive Full Renderer Profile candidate structure.
profile_root=ROOT/'conformance'/'full-renderer-profile-v1.0.0-candidate'
profile=json.loads((profile_root/'profile.json').read_text())
check(profile.get('profile')=='nanpa-linja-n-full-renderer-profile','full renderer profile id')
check(profile.get('profileVersion')=='1.0.0-candidate','full renderer profile version')
check(profile.get('semanticParityCases')==64,'full renderer semantic fixture count metadata')
check(profile.get('featureCount')==38,'full renderer feature count metadata')
canonical=ROOT/'reference'/profile['canonicalRenderer']['filename']
check(canonical.exists(),'canonical JavaScript renderer present')
if canonical.exists(): check(hashlib.sha256(canonical.read_bytes()).hexdigest()==profile['canonicalRenderer']['sha256'],'canonical JavaScript renderer SHA-256')
for rel in ('src/full_types.rs','src/full_document.rs','src/full_font_registry.rs','src/full_adapter.rs','src/full_renderer.rs','examples/full_renderer_profile.rs','examples/visual_export.rs'):
    check((ROOT/rel).exists() and (ROOT/rel).stat().st_size>0,f'full renderer source present {rel}')

print(f'\nsource/asset validation: {checks-len(failures)}/{checks} PASS; failures: {len(failures)}')
if failures:
    raise SystemExit(1)
