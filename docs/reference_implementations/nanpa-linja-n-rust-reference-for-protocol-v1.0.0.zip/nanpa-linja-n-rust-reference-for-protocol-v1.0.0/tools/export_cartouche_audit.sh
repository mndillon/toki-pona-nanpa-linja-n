#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
OUT="${1:-$ROOT/test-output/cartouche-audit}"
mkdir -p "$OUT"

# Remove both current canonical audit files and obsolete Rust-only audit files so
# an overlaid candidate cannot leave stale images in the comparison directory.
find "$OUT" -maxdepth 1 -type f -name '*.png' -delete

cargo run --quiet --example visual_export -- ordinary "$OUT"
python3 tools/make_cartouche_contacts.py "$OUT"

COUNT="$(find "$OUT" -maxdepth 1 -type f -name '*.png' | wc -l)"
[ "$COUNT" -eq 40 ] || { echo "expected 40 cartouche audit PNGs, got $COUNT" >&2; exit 1; }
echo "Rust ordinary-cartouche visual audit: 40/40 PNGs PASS"
