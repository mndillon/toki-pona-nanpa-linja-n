#!/usr/bin/env python3
import hashlib,json,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'fixtures/legacy-production-rendering-sha256.json').read_text())
bad=[]
for rel,want in manifest.items():
    p=root/rel
    got=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else 'MISSING'
    if got!=want: bad.append((rel,want,got))
if bad:
    for rel,want,got in bad: print(f'FAIL {rel}: {got} != {want}',file=sys.stderr)
    raise SystemExit(1)
print(f'Rust legacy production rendering integrity: {len(manifest)}/{len(manifest)} unchanged PASS')
