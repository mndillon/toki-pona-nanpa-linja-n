import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const EXPECTED_CORPUS_SHA256 = 'e4baf51251861c114f5314fc2af05eb44e1b5dbcbdebdcd2678c868f5dbf306a';
const EXPECTED_RENDERER_SHA256 = 'a7ec74577e1663ba980e49e1ca962e59c8397246190063fb84d02fb525b3f10f';
const EXPECTED_RENDERER_CASES = 15;

const root = process.cwd();
const corpusPath = path.resolve(root, 'fixtures/nanpa-linja-n-regression-v1.0.2.json');
const rendererPath = process.env.NANPA_RENDERER
  ? path.resolve(root, process.env.NANPA_RENDERER)
  : path.resolve(root, '../nanpa-linja-n-browser-font-regression-v0.1.3-reference/reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js');
const outputPath = path.resolve(root, 'fixtures/nanpa-linja-n-renderer-goldens-v1.0.2.json');

function sha256(filePath) {
  return crypto.createHash('sha256').update(fs.readFileSync(filePath)).digest('hex');
}
function verify(label, filePath, expected) {
  if (!fs.existsSync(filePath)) throw new Error(`${label} not found: ${filePath}`);
  const actual = sha256(filePath);
  if (actual !== expected) throw new Error(`${label} hash mismatch\nexpected ${expected}\nactual   ${actual}`);
  console.log(`PASS ${label} SHA-256 ${actual}`);
  return actual;
}
function normalize(value) {
  if (value === null || ['string','number','boolean'].includes(typeof value)) return value;
  if (typeof value === 'undefined') return undefined;
  if (Array.isArray(value)) return value.map(normalize);
  if (ArrayBuffer.isView(value)) return Array.from(value).map(normalize);
  if (typeof value === 'object') {
    const out = {};
    for (const key of Object.keys(value).sort()) {
      const v = normalize(value[key]);
      if (typeof v !== 'undefined') out[key] = v;
    }
    return out;
  }
  return String(value);
}

const corpusSha256 = verify('corpus', corpusPath, EXPECTED_CORPUS_SHA256);
const rendererSha256 = verify('canonical renderer', rendererPath, EXPECTED_RENDERER_SHA256);
const corpus = JSON.parse(fs.readFileSync(corpusPath, 'utf8'));
if (!Array.isArray(corpus.rendererCases) || corpus.rendererCases.length !== EXPECTED_RENDERER_CASES) {
  throw new Error(`expected ${EXPECTED_RENDERER_CASES} renderer cases`);
}
const mod = await import(pathToFileURL(rendererPath).href);
const parser = mod.NanpaParser ?? mod.default?.NanpaParser ?? mod.SitelenRenderer?.NanpaParser;
if (!parser) throw new Error('canonical renderer does not export NanpaParser');

const cases = corpus.rendererCases.map(testCase => {
  const fn = parser[testCase.api];
  if (typeof fn !== 'function') throw new Error(`missing canonical API ${testCase.api}`);
  const result = fn.call(parser, testCase.input, testCase.options ?? {});
  return {
    id: testCase.id,
    api: testCase.api,
    input: normalize(testCase.input),
    options: normalize(testCase.options ?? {}),
    corpusAssert: normalize(testCase.assert ?? {}),
    result: normalize(result),
  };
});

const golden = {
  format: 'nanpa-linja-n-renderer-goldens',
  formatVersion: 1,
  protocolVersion: '1.0.0',
  corpusVersion: '1.0.2',
  corpus: { file: path.basename(corpusPath), sha256: corpusSha256, rendererCases: cases.length },
  canonicalRenderer: { file: path.basename(rendererPath), sha256: rendererSha256 },
  cases,
};
fs.writeFileSync(outputPath, JSON.stringify(golden, null, 2) + '\n');
console.log(`PASS generated ${cases.length} renderer goldens`);
console.log(`Output: ${outputPath}`);
console.log(`SHA-256: ${sha256(outputPath)}`);
