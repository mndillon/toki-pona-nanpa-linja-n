#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

echo "nanpa-linja-n Rust full reference regression"
echo "============================================"
rustc --version
cargo --version

python3 tools/validate_rendering_source.py
python3 tools/check_legacy_rendering_integrity.py

# Candidate ZIPs may be extracted over a previously built tree.  Cargo uses
# mtimes for freshness, while archive extraction can restore source mtimes
# older than target artifacts.  Clean this package before qualification so
# every candidate is compiled from the source that is actually on disk.
echo "Forcing rebuild of nanpa-linja-n-rust package artifacts"
cargo clean -p nanpa-linja-n-rust
echo "Full-renderer source fingerprints:"
sha256sum src/full_renderer.rs examples/full_renderer_profile.rs

cargo check --all-targets

# Frozen/legacy integration suite.  Keep full_renderer_* tests out of this
# phase so a new-profile mismatch cannot prevent the 64-case diagnostic pass.
for test_src in tests/*.rs; do
    test_name="$(basename "$test_src" .rs)"
    case "$test_name" in
        full_renderer_*|ast_to_text) continue ;;
    esac
    cargo test --test "$test_name" -- --nocapture
done

# New-module unit tests (normalization/abbreviation helpers, etc.).
cargo test --lib -- --nocapture

echo "=== astToText ==="
cargo test --test ast_to_text -- --nocapture

# Run all 64 semantic fixtures independently so one mismatch cannot hide the rest.
./tools/run_full_renderer_diagnostics.sh

# Targeted regressions for issues already found and tally routing.
cargo test --test full_renderer_explicit_positive -- --nocapture
cargo test --test full_renderer_numeric_abbreviated -- --nocapture
cargo test --test full_renderer_traditional -- --nocapture
cargo test --test full_renderer_tally_routing -- --nocapture
cargo test --test full_renderer_mixed_style_long -- --nocapture
cargo test --test full_renderer_start_glyphs -- --nocapture

# Once semantic parity is clean, run the monolithic operation/vector/feature gate.
cargo run --quiet --example full_renderer_profile

echo "ALL CONFIGURED RUST FULL REFERENCE TESTS PASS"
