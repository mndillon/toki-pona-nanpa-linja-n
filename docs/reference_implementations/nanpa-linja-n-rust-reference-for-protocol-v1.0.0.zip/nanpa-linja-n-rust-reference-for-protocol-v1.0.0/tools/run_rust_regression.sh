#!/usr/bin/env bash
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
mkdir -p test-output
REPORT="$ROOT/test-output/rust-regression-report.txt"
: > "$REPORT"

echo "nanpa-linja-n Rust regression"
echo "report: $REPORT"
echo

passed=0
failed=0
skipped=0
names=()
results=()

run_suite() {
  local name="$1"; shift
  local tmp
  tmp="$(mktemp)"
  echo "[RUN ] $name"
  {
    echo "=== $name ==="
    echo "START $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  } >> "$REPORT"
  if "$@" >"$tmp" 2>&1; then
    cat "$tmp" >> "$REPORT"
    echo "RESULT PASS ($name)" >> "$REPORT"
    passed=$((passed+1)); names+=("$name"); results+=("PASS")
    echo "[PASS] $name"
  else
    local rc=$?
    cat "$tmp" >> "$REPORT"
    echo "RESULT FAIL ($name) exit=$rc" >> "$REPORT"
    failed=$((failed+1)); names+=("$name"); results+=("FAIL")
    echo "[FAIL] $name (exit=$rc)"
  fi
  echo "END $(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$REPORT"
  echo >> "$REPORT"
  rm -f "$tmp"
}

run_suite "environment" bash -c 'rustc --version && cargo --version && python3 --version'
run_suite "current JavaScript-derived conformance authority" python3 tools/check_current_conformance.py
run_suite "rendering source authority" python3 tools/validate_rendering_source.py
run_suite "legacy rendering integrity" python3 tools/check_legacy_rendering_integrity.py

# Cargo already fingerprints the source graph.  Preserve its incremental cache by
# default; set NANPA_RUST_REGRESSION_CLEAN=1 when a deliberately cold rebuild is
# required.
run_suite "Rust compilation" bash -c '
  if [[ "${NANPA_RUST_REGRESSION_CLEAN:-0}" == "1" ]]; then
    cargo clean -p nanpa-linja-n-rust >/dev/null 2>&1 || true
  fi
  cargo check --all-targets
' 

run_suite "frozen protocol and core integration" bash -c '
  rc=0
  for test_src in tests/*.rs; do
    test_name="$(basename "$test_src" .rs)"
    case "$test_name" in
      full_renderer_*|ast_to_text|canonical_syntax|canonical_full_renderer|composition_interactions|facade_plan_conformance|facade_rendering) continue ;;
    esac
    echo "--- cargo test --test $test_name ---"
    cargo test --test "$test_name" -- --nocapture || rc=1
  done
  exit "$rc"
'
run_suite "library unit tests" cargo test --lib -- --nocapture
run_suite "ast_to_text" cargo test --test ast_to_text -- --nocapture
run_suite "canonical syntax and production adapters" cargo test --test canonical_syntax -- --nocapture
run_suite "canonical full renderer" cargo test --test canonical_full_renderer -- --nocapture
run_suite "mixed-feature JavaScript interactions" cargo test --test composition_interactions -- --nocapture
run_suite "targeted full renderer regressions" cargo test --test full_renderer_targeted -- --nocapture
run_suite "production render-plan conformance" cargo test --test facade_plan_conformance -- --nocapture
run_suite "production facade rendering" cargo test --test facade_rendering -- --nocapture
run_suite "legacy full renderer profile + diagnostics" ./tools/run_full_renderer_diagnostics.sh

{
  echo "=== CONSOLIDATED SUMMARY ==="
  for i in "${!names[@]}"; do echo "${results[$i]}: ${names[$i]}"; done
  echo
  echo "configured suites: ${#names[@]}"
  echo "passed suites: $passed"
  echo "failed suites: $failed"
  echo "skipped suites: $skipped"
  echo "report: $REPORT"
  if (( failed == 0 )); then
    echo "ALL CONFIGURED RUST TESTS PASS"
  else
    echo "RUST REGRESSION FAILED: $failed suite(s) failed; all configured suites were attempted."
  fi
} | tee -a "$REPORT"

if (( failed > 0 )); then exit 1; fi
exit 0
