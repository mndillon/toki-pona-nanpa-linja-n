#!/usr/bin/env bash
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
mkdir -p test-output
REPORT="test-output/full-renderer-semantic-diagnostics.txt"
: > "$REPORT"
: > "$REPORT.summary"

mapfile -t IDS < <(python3 - <<'PY'
import json
from pathlib import Path
p=Path('conformance/full-renderer-profile-v1.0.0-candidate/conformance/render-parity-cases-v1.0.0.json')
data=json.loads(p.read_text())
for case in data['cases']:
    print(case['id'])
PY
)

passed=0
failed=0
failed_ids=()
for id in "${IDS[@]}"; do
    tmp="$(mktemp)"
    if cargo run --quiet --example full_renderer_profile -- "$id" >"$tmp" 2>&1; then
        passed=$((passed+1))
    else
        failed=$((failed+1))
        failed_ids+=("$id")
        {
            echo "===== FAIL: $id ====="
            cat "$tmp"
            echo
        } >> "$REPORT"
    fi
    rm -f "$tmp"
done

{
    echo "Rust Full Renderer diagnostic semantic matrix: ${passed}/64 PASS; ${failed} FAIL"
    if (( failed > 0 )); then
        echo "Failing semantic cases:"
        printf '  %s\n' "${failed_ids[@]}"
        echo "Detailed failures: $REPORT"
    fi
} | tee -a "$REPORT.summary"

if (( failed > 0 )); then
    exit 1
fi
exit 0
