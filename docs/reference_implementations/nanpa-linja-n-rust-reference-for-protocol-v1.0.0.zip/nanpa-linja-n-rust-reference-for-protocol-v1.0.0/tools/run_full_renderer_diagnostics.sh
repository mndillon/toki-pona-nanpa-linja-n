#!/usr/bin/env bash
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
mkdir -p test-output
REPORT="test-output/full-renderer-semantic-diagnostics.txt"
SUMMARY="$REPORT.summary"
: > "$REPORT"
: > "$SUMMARY"

# The old runner launched the same Rust example once for each of the 64
# semantic cases.  That repeatedly paid process startup and bundled-font
# initialization.  Run the complete profile once in optimized mode instead.
# Only if it fails do we fall back to one-case invocations to identify the
# semantic failures precisely.
full_tmp="$(mktemp)"
if cargo run --release --quiet --example full_renderer_profile >"$full_tmp" 2>&1; then
    cat "$full_tmp" >> "$REPORT"
    semantic_line="$(grep -E 'Rust Full Renderer semantic parity:' "$full_tmp" | tail -1 || true)"
    {
        if [[ -n "$semantic_line" ]]; then
            echo "$semantic_line"
        else
            echo "Rust Full Renderer semantic parity: PASS"
        fi
        echo "RUST FULL RENDERER PROFILE: PASS"
        echo "Fast diagnostics: complete profile executed once; per-case reruns not required."
    } | tee -a "$SUMMARY"
    rm -f "$full_tmp"
    exit 0
else
    full_rc=$?
fi
{
    echo "===== COMPLETE PROFILE FAILURE ====="
    cat "$full_tmp"
    echo
} >> "$REPORT"
rm -f "$full_tmp"

mapfile -t IDS < <(python3 - <<'PY'
import json
from pathlib import Path
p=Path('conformance/full-renderer-profile-v1.0.0-candidate/conformance/render-parity-cases-v1.0.0.json')
data=json.loads(p.read_text())
for case in data['cases']:
    print(case['id'])
PY
)

passed=0
failed=0
failed_ids=()
for id in "${IDS[@]}"; do
    tmp="$(mktemp)"
    if cargo run --release --quiet --example full_renderer_profile -- "$id" >"$tmp" 2>&1; then
        passed=$((passed+1))
    else
        failed=$((failed+1))
        failed_ids+=("$id")
        {
            echo "===== SEMANTIC FAIL: $id ====="
            cat "$tmp"
            echo
        } >> "$REPORT"
    fi
    rm -f "$tmp"
done

{
    echo "Complete Full Renderer Profile failed (exit=$full_rc)."
    echo "Rust Full Renderer diagnostic semantic matrix: ${passed}/64 PASS; ${failed} FAIL"
    if (( failed > 0 )); then
        echo "Failing semantic cases:"
        printf '  %s\n' "${failed_ids[@]}"
    else
        echo "All 64 semantic cases pass individually; failure is in an operation/vector/feature check."
    fi
    echo "Detailed failure output: $REPORT"
} | tee -a "$SUMMARY"

exit 1
