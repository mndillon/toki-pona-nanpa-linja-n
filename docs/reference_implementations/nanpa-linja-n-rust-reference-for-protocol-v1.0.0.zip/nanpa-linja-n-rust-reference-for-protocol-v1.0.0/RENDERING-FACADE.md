# Rust production rendering facade

The Rust reference keeps the frozen Protocol v1.0.0 parser/API unchanged and adds a high-level production rendering layer.

## Minimal use

```rust
use nanpa_linja_n_rust::facade::{NanpaLinjaN, RenderOptions};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let nanpa = NanpaLinjaN::create()?;

    let result = nanpa.render_default("123.45")?;
    result.save_png("number.png")?;

    let linja_pona = RenderOptions {
        font: "linjaPona".into(),
        ..RenderOptions::default()
    };
    nanpa.save_png("12:30", "time.png", &linja_pona)?;

    let svg = nanpa.render_to_svg("#ABCDEF", &RenderOptions::default())?;
    svg.save_svg("hex.svg")?;
    Ok(())
}
```

The caller does **not** select a render adapter or locate font files. `font: "linjaPona"` automatically selects `linja-pona-legacy-v1`; the eight production companion fonts and manifest are embedded into the crate at compile time.

## Public facade

- `NanpaLinjaN::create()` / `NanpaLinjaN::new()`
- `list_fonts()`
- `get_font_info()`
- `parse()`
- `build_render_plan()`
- `render()` / `render_default()`
- `render_to_png()` / `save_png()`
- `render_to_svg()` / `SvgResult::save_svg()`

`RenderOptions` exposes font choice, font size, abbreviation, padding, foreground/background RGBA, and the existing `ParseOptions` without redefining Core-v1 semantics.

## Rendering implementation

- HarfRust performs OpenType shaping.
- fontdue rasterizes the shaped glyph IDs.
- `image` encodes RGBA output as PNG.
- SVG embeds the selected production companion font as a data URL so the result remains self-contained.
- `calt`, `liga`, and `ccmp` are enabled for numeric cartouches.
- `ss12` is added at <=18 px and `ss13` at <=29 px, matching the production regression matrix.
- `linjaPona` and `linjaSike` are automatically converted from canonical UCSUR to their native ASCII ligature syntax before shaping.
