nanpa-linja-n Rust parser v3 overlay
===================================

Purpose
-------
Addresses the supplied run: 300/311 parser cases passed, 0 unimplemented,
11 mismatches, all in identifier.caps / legacy proper-name interpretation.
It also updates the now-stale integer regression test that expected newly
implemented syntax to remain rejected.

Important verification
----------------------
The supplied run still showed old dead-code warnings for NANPA/NASA/NOKA/
TENPO/SUNO/TOKI/COLON and two unused helper functions. Those symbols do not
exist in this v3 extended.rs. If those warnings still appear, this overlay
was not applied to the file Cargo is compiling.

Files replaced
--------------
src/parser.rs
src/parser/extended.rs
tests/parser_conformance.rs
tests/parse_decimal_integer.rs

Apply
-----
From the extracted overlay directory:

  ./apply-overlay.sh /path/to/nanpa-linja-n-rust

Then, from the Rust project root:

  cargo test --test parser_conformance -- --nocapture
  cargo test

Target parser result:

  311 PASS
  0 UNIMPLEMENTED
  0 MISMATCH

Expected file SHA-256 values
----------------------------
554f1126104468349110ef6ce74d3f2e1b4cdfaee57a66ee81a7bc824a63b4e8  /mnt/data/nanpa-linja-n-rust-parser-v3-overlay/src/parser.rs
2097af46e5fdd2656adbebf8ba0999a1378111d2fcb2ef58c24fdb1a771f281a  /mnt/data/nanpa-linja-n-rust-parser-v3-overlay/src/parser/extended.rs
fe04fdee51b0ee8e9f2c24f2c503eb68a7f95204cfb233d977c341400aeed082  /mnt/data/nanpa-linja-n-rust-parser-v3-overlay/tests/parser_conformance.rs
a881a1b5fad59cd3f6cb73602ba35e983d7aa49052c18ced1ecdf52d1874e752  /mnt/data/nanpa-linja-n-rust-parser-v3-overlay/tests/parse_decimal_integer.rs
