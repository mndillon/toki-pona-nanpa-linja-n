# Assets

Production fonts are not stored in this directory.

The Java reference uses `resources/fonts.zip` as its single production font source.
The manifest and all pair/support font files are read from that ZIP.
