package com.nanpalinjan;
import java.nio.file.*;
import java.util.*;
public final class VisualMatrixExport {
  private static ParseOptions abbreviation(ParseOptions p,boolean ab){return new ParseOptions(p.enableBinaryParsing(),p.enableHexParsing(),p.mode(),p.numericMode(),p.nanpaColonParsing(),p.nanpaColonRendering(),p.relaxedNanpaLinjanParsing(),p.relaxedNanpaLinjanRendering(),ab,ab,p.numericCartoucheStartGlyph());}
  @SuppressWarnings("unchecked") public static void main(String[] args)throws Exception{
    if(args.length<3)throw new IllegalArgumentException("usage: VisualMatrixExport <font-dir> <cases-json> <output-dir>");
    Path fontDir=Path.of(args[0]),fixture=Path.of(args[1]),out=Path.of(args[2]); Files.createDirectories(out);
    Map<String,Object> root=(Map<String,Object>)MiniJson.parse(Files.readString(fixture)); List<Object> cases=(List<Object>)root.get("cases"); int written=0;
    try(NanpaLinjaN n=NanpaLinjaN.create(fontDir)){for(FontPairInfo f:n.listFonts())for(Object raw:cases){Map<String,Object> c=(Map<String,Object>)raw;String id=String.valueOf(c.get("id")),input=String.valueOf(c.get("input"));float px=((Number)c.get("fontPx")).floatValue();boolean ab=Boolean.TRUE.equals(c.get("abbreviateNumericCartouches"));RenderOptions o=new RenderOptions().withFont(f.key()).withFontSize(px).withPaddingPx(8);o=o.withParser(abbreviation(o.parser(),ab));Files.write(out.resolve(f.key()+"--"+id+".png"),n.renderToPng(input,o).bytes());written++;}}
    System.out.println("Java production visual matrix: "+written+" PNG file(s) written to "+out.toAbsolutePath().normalize());
  }
}
