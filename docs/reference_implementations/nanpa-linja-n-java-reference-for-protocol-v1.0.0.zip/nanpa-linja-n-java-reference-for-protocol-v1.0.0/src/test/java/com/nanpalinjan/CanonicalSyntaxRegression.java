package com.nanpalinjan;

import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;

/** Current JavaScript-derived syntax/adaptor qualification corpus. */
public final class CanonicalSyntaxRegression {
    private static final List<String> failures = new ArrayList<>();
    private static int casesPassed=0, adapterPassed=0;
    @SuppressWarnings("unchecked") private static Map<String,Object> map(Object v){return v instanceof Map<?,?>m?(Map<String,Object>)m:Map.of();}
    private static List<?> list(Object v){return v instanceof List<?>l?l:List.of();}
    private static String str(Object v){return v==null?null:String.valueOf(v);}
    private static boolean bool(Object v,boolean d){return v instanceof Boolean b?b:v==null?d:Boolean.parseBoolean(String.valueOf(v));}
    private static List<Integer> cps(Object v){List<Integer> out=new ArrayList<>(); for(Object x:list(v)){String s=String.valueOf(x); if(s.startsWith("U+"))out.add(Integer.parseInt(s.substring(2),16)); else out.add(((Number)x).intValue());} return List.copyOf(out);}
    private static String cpString(String s){if(s==null||!s.startsWith("U+"))return s;return new String(Character.toChars(Integer.parseInt(s.substring(2),16)));}
    private static String sha256(Path p)throws Exception{MessageDigest md=MessageDigest.getInstance("SHA-256");md.update(Files.readAllBytes(p));return HexFormat.of().formatHex(md.digest());}
    private static List<RenderRun> runs(RenderPlan p){return p.lines().isEmpty()?p.runs():p.lines().stream().flatMap(l->l.runs().stream()).toList();}
    private static void fail(String id,String message){failures.add("["+id+"] "+message);}
    private static void one(Map<String,Object> c,NanpaLinjaN n)throws Exception{
        String id=str(c.get("id")), input=str(c.get("input")), mode=str(c.get("rendererMode"));
        ParseOptions p=new ParseOptions().withRendererMode(mode);
        RenderPlan plan=n.buildRenderPlan(input,new RenderOptions().withParser(p));
        List<RenderRun> rs=runs(plan); int before=failures.size();
        if(c.containsKey("expectedNormalizedInput")&&!Objects.equals(plan.ast().normalizedInput(),str(c.get("expectedNormalizedInput"))))fail(id,"normalizedInput got="+plan.ast().normalizedInput()+" want="+str(c.get("expectedNormalizedInput")));
        if(c.containsKey("expectedRuns")){
            List<?> er=list(c.get("expectedRuns")); if(rs.size()!=er.size())fail(id,"run count got="+rs.size()+" want="+er.size());
            for(int i=0;i<Math.min(rs.size(),er.size());i++){List<Integer>w=cps(er.get(i));if(!rs.get(i).canonicalCodepoints().equals(w))fail(id,"run["+i+"] canonical="+rs.get(i).canonicalCodepoints()+" want="+w);}
        } else {
            if(rs.size()!=1)fail(id,"expected one run, got "+rs.size()+" "+rs);
            else {
                RenderRun r=rs.getFirst(); List<Integer>w=cps(c.get("expectedCanonicalCodepoints")); if(!r.canonicalCodepoints().equals(w))fail(id,"canonical="+r.canonicalCodepoints()+" want="+w);
                if(c.containsKey("expectedSourceText")&&!Objects.equals(r.sourceText(),str(c.get("expectedSourceText"))))fail(id,"sourceText="+r.sourceText()+" want="+str(c.get("expectedSourceText")));
                if(c.containsKey("expectedFontRole")&&!Objects.equals(r.fontRole(),str(c.get("expectedFontRole"))))fail(id,"fontRole="+r.fontRole()+" want="+str(c.get("expectedFontRole")));
                if(c.containsKey("expectedRenderText")){String want=cpString(str(c.get("expectedRenderText")));if(!Objects.equals(r.renderText(),want))fail(id,"renderText="+r.renderText()+" want="+want);}
            }
        }
        if(failures.size()==before)casesPassed++;
    }
    private static void adapter(Map<String,Object> c,NanpaLinjaN n)throws Exception{
        String id=str(c.get("id")); int before=failures.size();
        RenderPlan plan=n.buildRenderPlan(str(c.get("input")),new RenderOptions().withFont(str(c.get("font")))); List<RenderRun> rs=runs(plan);
        if(rs.size()!=1)fail(id,"expected one run, got "+rs.size()); else {RenderRun r=rs.getFirst();
            if(c.containsKey("expectedRenderText")&&!Objects.equals(r.renderText(),str(c.get("expectedRenderText"))))fail(id,"renderText="+r.renderText()+" want="+str(c.get("expectedRenderText")));
            if(c.containsKey("expectedRenderCodepoints")){List<Integer>w=cps(c.get("expectedRenderCodepoints"));if(!r.renderCodepoints().equals(w))fail(id,"renderCps="+r.renderCodepoints()+" want="+w);}
            if(bool(c.get("mustDifferFromCanonicalCodepoints"),false)&&r.renderCodepoints().equals(r.canonicalCodepoints()))fail(id,"renderCodepoints unexpectedly equal canonicalCodepoints");
        }
        if(failures.size()==before)adapterPassed++;
    }
    public static void main(String[] args)throws Exception{
        if(args.length<1)throw new IllegalArgumentException("usage: CanonicalSyntaxRegression <font-dir> [cases.json]");
        Path file=Path.of(args.length>1?args[1]:"conformance/canonical-syntax-v1.0.1-phase1/cases.json"); Map<String,Object> root=map(MiniJson.parse(Files.readString(file)));
        Map<String,Object> authority=map(root.get("authority"));Path js=Path.of(str(authority.get("canonicalJavaScript")));String want=str(authority.get("sha256"));if(!Files.isRegularFile(js)||!Objects.equals(sha256(js),want))throw new IllegalStateException("canonical JavaScript authority hash mismatch");
        try(NanpaLinjaN n=NanpaLinjaN.create(Path.of(args[0]))){for(Object x:list(root.get("cases")))one(map(x),n);for(Object x:list(root.get("fontAdapterCases")))adapter(map(x),n);}
        int total=list(root.get("cases")).size(), adapters=list(root.get("fontAdapterCases")).size();
        System.out.printf("Java canonical syntax: %d/%d %s%n",casesPassed,total,casesPassed==total?"PASS":"FAIL");
        System.out.printf("Java canonical production font adapters: %d/%d %s%n",adapterPassed,adapters,adapterPassed==adapters?"PASS":"FAIL");
        if(!failures.isEmpty()){failures.forEach(System.err::println);System.exit(1);}    }
}
