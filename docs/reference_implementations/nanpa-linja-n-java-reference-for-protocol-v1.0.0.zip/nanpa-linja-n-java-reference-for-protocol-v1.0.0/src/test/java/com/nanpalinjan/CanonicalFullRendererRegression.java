package com.nanpalinjan;

import java.nio.file.*;
import java.security.*;
import java.util.*;

/** Branch-oriented semantic qualification against the current canonical JS renderer corpus. */
public final class CanonicalFullRendererRegression {
    @SuppressWarnings("unchecked") private static Map<String,Object> map(Object x){return (Map<String,Object>)x;}
    @SuppressWarnings("unchecked") private static List<Object> list(Object x){return x instanceof List<?> l?(List<Object>)l:List.of();}
    private static String str(Object x){return x==null?"":String.valueOf(x);}
    private static boolean bool(Object x){return Boolean.TRUE.equals(x);}
    private static int integer(Object x){return x instanceof Number n?n.intValue():Integer.parseInt(String.valueOf(x));}
    private static List<Integer> ints(Object x){if(!(x instanceof List<?> l))return List.of();List<Integer>o=new ArrayList<>();for(Object v:l)o.add(integer(v));return List.copyOf(o);}
    private static String sha256(Path p)throws Exception{byte[]b=Files.readAllBytes(p),d=MessageDigest.getInstance("SHA-256").digest(b);return java.util.HexFormat.of().formatHex(d);}
    private static void fail(List<String>e,String id,String what,Object got,Object want){e.add(id+": "+what+" got="+String.valueOf(got)+" want="+String.valueOf(want));}
    private static List<RenderRun> flatten(RenderPlan p){List<RenderRun>out=new ArrayList<>();for(RenderLinePlan l:p.lines())out.addAll(l.runs());return out;}
    private static List<Integer> fullCps(RenderRun r){if("cartouche".equals(r.fontRole())||"number".equals(r.fontRole())||r.numericCartouche()){List<Integer>o=new ArrayList<>();o.add(Constants.CARTOUCHE_START);o.addAll(r.canonicalCodepoints());o.add(Constants.CARTOUCHE_END);return o;}return List.of();}
    private static String nullableString(Object x){return x==null?null:String.valueOf(x);}

    private static void compareAst(List<String>errors,String id,DocumentAst g,Map<String,Object>w){
        if(!Objects.equals(g.type(),str(w.get("type"))))fail(errors,id,"AST.type",g.type(),w.get("type"));
        if(!Objects.equals(g.normalizedInput(),str(w.get("normalizedInput"))))fail(errors,id,"AST.normalizedInput",g.normalizedInput(),w.get("normalizedInput"));
        List<Object>wl=list(w.get("lines"));if(g.lines().size()!=wl.size()){fail(errors,id,"AST.lines.size",g.lines().size(),wl.size());return;}
        for(int i=0;i<wl.size();i++){DocumentLine gl=g.lines().get(i);Map<String,Object> x=map(wl.get(i));
            if(gl.index()!=integer(x.get("index")))fail(errors,id,"AST.line["+i+"].index",gl.index(),x.get("index"));
            if(gl.sourceLineIndex()!=integer(x.get("sourceLineIndex")))fail(errors,id,"AST.line["+i+"].sourceLineIndex",gl.sourceLineIndex(),x.get("sourceLineIndex"));
            if(gl.sentenceIndexInSourceLine()!=integer(x.get("sentenceIndexInSourceLine")))fail(errors,id,"AST.line["+i+"].sentence",gl.sentenceIndexInSourceLine(),x.get("sentenceIndexInSourceLine"));
            if(!Objects.equals(gl.sourceText(),str(x.get("sourceText"))))fail(errors,id,"AST.line["+i+"].sourceText",gl.sourceText(),x.get("sourceText"));
            List<Object>wc=list(x.get("children"));if(gl.children().size()!=wc.size()){fail(errors,id,"AST.line["+i+"].children.size",gl.children().size(),wc.size());continue;}
            for(int j=0;j<wc.size();j++){DocumentSegment gs=gl.children().get(j);Map<String,Object>ws=map(wc.get(j));if(!Objects.equals(gs.kind(),str(ws.get("kind"))))fail(errors,id,"AST child kind",gs.kind(),ws.get("kind"));
                if(ws.containsKey("value")&&ws.get("value")!=null&&!Objects.equals(gs.value(),str(ws.get("value"))))fail(errors,id,"AST child value",gs.value(),ws.get("value"));
                if(ws.get("openQuote")!=null&&!Objects.equals(gs.openQuote(),str(ws.get("openQuote"))))fail(errors,id,"AST openQuote",gs.openQuote(),ws.get("openQuote"));
                if(ws.get("closeQuote")!=null&&!Objects.equals(gs.closeQuote(),str(ws.get("closeQuote"))))fail(errors,id,"AST closeQuote",gs.closeQuote(),ws.get("closeQuote"));
                if(ws.get("image") instanceof Map<?,?>){Map<String,Object>wi=map(ws.get("image"));ImageDescriptor gi=gs.image();if(gi==null)fail(errors,id,"AST image",null,wi);else{
                    if(!Objects.equals(gi.src(),str(wi.get("src"))))fail(errors,id,"AST image.src",gi.src(),wi.get("src"));if(!Objects.equals(gi.w(),str(wi.get("w"))))fail(errors,id,"AST image.w",gi.w(),wi.get("w"));if(!Objects.equals(gi.h(),str(wi.get("h"))))fail(errors,id,"AST image.h",gi.h(),wi.get("h"));if(!Objects.equals(gi.alt(),str(wi.get("alt"))))fail(errors,id,"AST image.alt",gi.alt(),wi.get("alt"));if(!Objects.equals(gi.valign(),str(wi.get("valign"))))fail(errors,id,"AST image.valign",gi.valign(),wi.get("valign"));
                }}
            }
        }
    }

    public static void main(String[]args)throws Exception{
        Path fontDir=Path.of(args.length>0?args[0]:"resources/fonts.zip");Path file=Path.of(args.length>1?args[1]:"conformance/full-renderer-canonical-v1.0.1/cases.json");Map<String,Object>root=map(MiniJson.parse(Files.readString(file)));List<Object>cases=list(root.get("cases"));
        if(integer(root.get("caseCount"))!=cases.size())throw new IllegalStateException("canonical corpus caseCount mismatch");Map<String,Object>authority=map(root.get("authority"));Path ap=Path.of(str(authority.get("path")));if(!Files.isRegularFile(ap))ap=Path.of(str(authority.get("path")).replaceFirst("^reference/","reference/"));String gotHash=sha256(ap);if(!gotHash.equals(str(authority.get("sha256"))))throw new IllegalStateException("canonical authority hash mismatch got="+gotHash);
        List<String>errors=new ArrayList<>();int pass=0;
        try(NanpaLinjaN n=NanpaLinjaN.create(fontDir)){
            for(Object co:cases){Map<String,Object>c=map(co),oracle=map(c.get("oracle"));String id=str(c.get("id"));int before=errors.size();
                if(!bool(oracle.get("ok"))){fail(errors,id,"oracle.ok",false,true);continue;}
                Map<String,Object>om=new LinkedHashMap<>();om.put("font",str(c.get("font")));om.put("parser",map(c.get("parser")));RenderOptions opts=RenderOptions.fromMap(om);RenderPlan plan;
                try{plan=n.buildRenderPlan(str(c.get("input")),opts);}catch(Exception ex){errors.add(id+": buildRenderPlan threw "+ex);continue;}
                if(bool(c.get("compareAst")))compareAst(errors,id,plan.ast(),map(oracle.get("ast")));
                List<RenderRun>gr=flatten(plan),wruns=new ArrayList<>();List<Object>wo=list(oracle.get("runs"));
                if(gr.size()!=wo.size()){fail(errors,id,"run count",gr.size(),wo.size());continue;}
                boolean random=bool(c.get("randomCps"));
                for(int i=0;i<wo.size();i++){RenderRun g=gr.get(i);Map<String,Object>w=map(wo.get(i));String pfx="run["+i+"] ";
                    if(!Objects.equals(g.kind(),str(w.get("kind"))))fail(errors,id,pfx+"kind",g.kind(),w.get("kind"));
                    if(!Objects.equals(g.renderMode(),str(w.get("renderMode"))))fail(errors,id,pfx+"renderMode",g.renderMode(),w.get("renderMode"));
                    if(!Objects.equals(g.fontRole(),str(w.get("fontRole"))))fail(errors,id,pfx+"fontRole",g.fontRole(),w.get("fontRole"));
                    if(!Objects.equals(g.sourceText()==null?"":g.sourceText(),str(w.get("sourceText"))))fail(errors,id,pfx+"sourceText",g.sourceText(),w.get("sourceText"));
                    if(!Objects.equals(g.sourceKind(),str(w.get("sourceKind"))))fail(errors,id,pfx+"sourceKind",g.sourceKind(),w.get("sourceKind"));
                    if(!random&&!Objects.equals(g.canonicalCodepoints(),ints(w.get("canonicalCps"))))fail(errors,id,pfx+"canonicalCps",g.canonicalCodepoints(),ints(w.get("canonicalCps")));
                    List<Integer>wfull=ints(w.get("canonicalFullCps"));if(!random&&!wfull.isEmpty()&&!Objects.equals(fullCps(g),wfull))fail(errors,id,pfx+"canonicalFullCps",fullCps(g),wfull);
                    if(!random&&!Objects.equals(g.renderCodepoints(),ints(w.get("renderCps"))))fail(errors,id,pfx+"renderCps",g.renderCodepoints(),ints(w.get("renderCps")));
                    if(!Objects.equals(g.renderAdapterId(),str(w.get("renderAdapterId"))))fail(errors,id,pfx+"renderAdapterId",g.renderAdapterId(),w.get("renderAdapterId"));
                    if(g.quoted()!=bool(w.get("isQuoted")))fail(errors,id,pfx+"isQuoted",g.quoted(),w.get("isQuoted"));if(g.interpretedQuote()!=bool(w.get("interpretedQuote")))fail(errors,id,pfx+"interpretedQuote",g.interpretedQuote(),w.get("interpretedQuote"));if(g.unrecognized()!=bool(w.get("isUnrecognized")))fail(errors,id,pfx+"isUnrecognized",g.unrecognized(),w.get("isUnrecognized"));
                    if(!Objects.equals(g.manualTallies(),ints(w.get("manualTallies"))))fail(errors,id,pfx+"manualTallies",g.manualTallies(),ints(w.get("manualTallies")));if(g.numericCartouche()!=bool(w.get("isNumericCartouche")))fail(errors,id,pfx+"numericCartouche",g.numericCartouche(),w.get("isNumericCartouche"));
                    if(w.get("imageAlt")!=null&&!Objects.equals(g.imageAlt(),nullableString(w.get("imageAlt"))))fail(errors,id,pfx+"imageAlt",g.imageAlt(),w.get("imageAlt"));
                    if(w.get("encodedText")!=null&&!Objects.equals(g.renderText(),str(w.get("encodedText"))))fail(errors,id,pfx+"encodedText",g.renderText(),w.get("encodedText"));
                }
                if(errors.size()==before)pass++;
            }
        }
        System.out.println("Java canonical full-renderer semantic corpus: "+pass+"/"+cases.size()+(errors.isEmpty()?" PASS":" FAIL"));
        if(!errors.isEmpty()){System.err.println("--- canonical full-renderer failures ("+errors.size()+") ---");for(String e:errors)System.err.println(e);throw new IllegalStateException("canonical full renderer failures: "+errors.size());}
    }
}
