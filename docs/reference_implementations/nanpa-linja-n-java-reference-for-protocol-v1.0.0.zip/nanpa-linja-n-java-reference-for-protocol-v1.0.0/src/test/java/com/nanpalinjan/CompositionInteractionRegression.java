package com.nanpalinjan;

import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;

/**
 * Mixed-feature differential regression generated from the current JavaScript
 * reference.  It deliberately composes features which are easy to get right
 * in isolation but wrong when adjacent: te/to, zz, compounds, long glyphs,
 * ordinary/literal cartouches, quotes, aliases and raw UCSUR.
 */
public final class CompositionInteractionRegression {
    @SuppressWarnings("unchecked") private static Map<String,Object> map(Object x){return x instanceof Map<?,?>m?(Map<String,Object>)m:Map.of();}
    @SuppressWarnings("unchecked") private static List<Object> list(Object x){return x instanceof List<?>l?(List<Object>)l:List.of();}
    private static String str(Object x){return x==null?"":String.valueOf(x);}
    private static boolean bool(Object x){return Boolean.TRUE.equals(x);}
    private static int integer(Object x){return x instanceof Number n?n.intValue():Integer.parseInt(String.valueOf(x));}
    private static double dbl(Object x){return x instanceof Number n?n.doubleValue():Double.parseDouble(String.valueOf(x));}
    private static List<Integer> ints(Object x){if(!(x instanceof List<?>l))return List.of();List<Integer>o=new ArrayList<>();for(Object v:l)o.add(integer(v));return List.copyOf(o);}
    private static List<RenderRun> flatten(RenderPlan p){List<RenderRun>o=new ArrayList<>();for(RenderLinePlan l:p.lines())o.addAll(l.runs());return o;}
    private static String sha256(Path p)throws Exception{byte[]d=MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(p));return HexFormat.of().formatHex(d);}
    private static void fail(List<String>e,String id,String what,Object got,Object want){e.add(id+": "+what+" got="+String.valueOf(got)+" want="+String.valueOf(want));}
    private static void near(List<String>e,String id,String what,double got,double want,double tol){if(Math.abs(got-want)>tol)fail(e,id,what,got,want);}

    public static void main(String[]args)throws Exception{
        if(args.length<1)throw new IllegalArgumentException("usage: CompositionInteractionRegression <font-dir> [corpus.json]");
        Path fontDir=Path.of(args[0]);
        Path corpus=Path.of(args.length>1?args[1]:"references/javascript-composition-interactions-v1.json");
        Map<String,Object>root=map(MiniJson.parse(Files.readString(corpus)));List<Object>cases=list(root.get("cases"));
        if(integer(root.get("caseCount"))!=cases.size())throw new IllegalStateException("interaction corpus caseCount mismatch");
        Map<String,Object>authority=map(root.get("authority"));
        Path facade=Path.of(str(authority.get("facadePath"))), renderer=Path.of(str(authority.get("rendererPath")));
        if(!Files.isRegularFile(facade)||!Objects.equals(sha256(facade),str(authority.get("facadeSha256"))))throw new IllegalStateException("interaction corpus JavaScript facade authority mismatch");
        if(!Files.isRegularFile(renderer)||!Objects.equals(sha256(renderer),str(authority.get("rendererSha256"))))throw new IllegalStateException("interaction corpus JavaScript renderer authority mismatch");

        List<String>errors=new ArrayList<>();int passed=0,syntheticChecks=0,zzChecks=0,pngChecks=0,replacementChecks=0;
        try(NanpaLinjaN n=NanpaLinjaN.create(fontDir)){
            for(Object co:cases){Map<String,Object>c=map(co);String id=str(c.get("id")),input=str(c.get("input"));int before=errors.size();
                if(!bool(c.get("ok"))){fail(errors,id,"oracle ok",false,true);continue;}
                Map<String,Object>om=new LinkedHashMap<>();om.put("font",str(c.get("font")));om.put("fontSize",56);om.put("paddingPx",18);om.put("parser",map(c.get("parser")));
                RenderOptions opts=RenderOptions.fromMap(om);RenderPlan plan;
                try{plan=n.buildRenderPlan(input,opts);}catch(Exception ex){errors.add(id+": buildRenderPlan threw "+ex);continue;}
                if(!Objects.equals(plan.ast().normalizedInput(),input))fail(errors,id,"AST normalizedInput",plan.ast().normalizedInput(),input);
                String rt=n.astToText(plan.ast());if(!Objects.equals(rt,str(c.get("astToText"))))fail(errors,id,"astToText",rt,c.get("astToText"));
                List<RenderRun>gr=flatten(plan);List<Object>wr=list(c.get("runs"));
                if(gr.size()!=wr.size()){fail(errors,id,"run count",gr.size(),wr.size());continue;}
                for(int i=0;i<wr.size();i++){
                    RenderRun g=gr.get(i);Map<String,Object>w=map(wr.get(i));String p="run["+i+"] ";
                    if(!Objects.equals(g.kind(),str(w.get("kind"))))fail(errors,id,p+"kind",g.kind(),w.get("kind"));
                    if(!Objects.equals(g.renderMode(),str(w.get("renderMode"))))fail(errors,id,p+"renderMode",g.renderMode(),w.get("renderMode"));
                    if(!Objects.equals(g.fontRole(),str(w.get("fontRole"))))fail(errors,id,p+"fontRole",g.fontRole(),w.get("fontRole"));
                    if(!Objects.equals(g.sourceText()==null?"":g.sourceText(),str(w.get("sourceText"))))fail(errors,id,p+"sourceText",g.sourceText(),w.get("sourceText"));
                    if(!Objects.equals(g.sourceKind(),str(w.get("sourceKind"))))fail(errors,id,p+"sourceKind",g.sourceKind(),w.get("sourceKind"));
                    if(!Objects.equals(g.canonicalCodepoints(),ints(w.get("canonicalCps"))))fail(errors,id,p+"canonicalCps",g.canonicalCodepoints(),ints(w.get("canonicalCps")));
                    if(!Objects.equals(g.renderCodepoints(),ints(w.get("renderCps"))))fail(errors,id,p+"renderCps",g.renderCodepoints(),ints(w.get("renderCps")));
                    if(w.get("encodedText")!=null&&!Objects.equals(g.renderText(),str(w.get("encodedText"))))fail(errors,id,p+"encodedText",g.renderText(),w.get("encodedText"));
                    if(!Objects.equals(g.renderAdapterId(),str(w.get("renderAdapterId"))))fail(errors,id,p+"renderAdapterId",g.renderAdapterId(),w.get("renderAdapterId"));
                    if(g.quoted()!=bool(w.get("isQuoted")))fail(errors,id,p+"isQuoted",g.quoted(),w.get("isQuoted"));
                    if(g.interpretedQuote()!=bool(w.get("interpretedQuote")))fail(errors,id,p+"interpretedQuote",g.interpretedQuote(),w.get("interpretedQuote"));
                    if(g.unrecognized()!=bool(w.get("isUnrecognized")))fail(errors,id,p+"isUnrecognized",g.unrecognized(),w.get("isUnrecognized"));
                    if(g.numericCartouche()!=bool(w.get("isNumericCartouche")))fail(errors,id,p+"isNumericCartouche",g.numericCartouche(),w.get("isNumericCartouche"));
                    if(!Objects.equals(g.manualTallies(),ints(w.get("manualTallies"))))fail(errors,id,p+"manualTallies",g.manualTallies(),ints(w.get("manualTallies")));

                    // JavaScript has no U+FFFD in this corpus.  This catches the
                    // exact class of missing-glyph adapter failure that exposed
                    // te/to inside legacy font paths.
                    if(g.renderCodepoints().contains(0xFFFD))fail(errors,id,p+"replacement glyph",g.renderCodepoints(),"no U+FFFD");
                    replacementChecks++;

                    if("synthetic-corner-bracket".equals(str(w.get("renderMode")))){
                        syntheticChecks++;
                        near(errors,id,p+"synthetic width",g.widthPx(),dbl(w.get("widthPx")),2.0);
                        near(errors,id,p+"synthetic height",g.heightPx(),dbl(w.get("heightPx")),2.0);
                    }
                    if("\u3000".equals(str(w.get("encodedText")))){
                        zzChecks++;
                        // Canvas gives the ideographic space one em of advance.
                        // Java2D must not collapse it to an empty/1px run.
                        near(errors,id,p+"zz advance",g.widthPx(),56.0,1.0);
                    }
                }

                String group=str(c.get("group"));
                if(Set.of("single","targeted","interpreted-quote","linja-sike").contains(group)){
                    try{PngRenderResult png=n.renderToPng(input,opts);if(png.bytes().length<100)fail(errors,id,"PNG bytes",png.bytes().length,">=100");else pngChecks++;}
                    catch(Exception ex){errors.add(id+": renderToPng threw "+ex);}
                }
                if(errors.size()==before)passed++;
            }
        }
        System.out.println("Java JavaScript-derived mixed-feature semantic interactions: "+passed+"/"+cases.size()+(errors.isEmpty()?" PASS":" FAIL"));
        System.out.println("Synthetic te/to geometry checks: "+syntheticChecks+" PASS");
        System.out.println("zz one-em advance checks: "+zzChecks+" PASS");
        System.out.println("No-replacement-glyph run checks: "+replacementChecks+" PASS");
        System.out.println("Mixed-feature production PNG smoke cases: "+pngChecks+" PASS");
        if(!errors.isEmpty()){System.err.println("--- mixed-feature interaction failures ("+errors.size()+") ---");for(String e:errors)System.err.println(e);throw new IllegalStateException("mixed-feature interaction failures: "+errors.size());}
    }
}
