package com.nanpalinjan;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Physical audit generated through the actual NanpaLinjaN production renderer. */
public final class CartoucheAuditExport {
    private static final String ORDINARY="[jan pona]";
    private static final String WITH_TALLIES="[jan pona,,]";
    private static final String HALO_RED="#D91E18";

    record Variant(String id,String label,String input,boolean halo){}
    private static final List<Variant> VARIANTS=List.of(
            new Variant("ordinary-cartouche","ordinary",ORDINARY,false),
            new Variant("ordinary-cartouche-halo-red","ordinary + red halo",ORDINARY,true),
            new Variant("ordinary-cartouche-tallies","ordinary + tallies",WITH_TALLIES,false),
            new Variant("ordinary-cartouche-tallies-halo-red","ordinary + tallies + red halo",WITH_TALLIES,true));

    private static byte[] png(BufferedImage image)throws IOException{ByteArrayOutputStream out=new ByteArrayOutputStream();if(!ImageIO.write(image,"png",out))throw new IOException("PNG writer unavailable");return out.toByteArray();}
    private static BufferedImage white(BufferedImage src){BufferedImage out=new BufferedImage(src.getWidth(),src.getHeight(),BufferedImage.TYPE_INT_RGB);Graphics2D g=out.createGraphics();try{g.setColor(Color.WHITE);g.fillRect(0,0,out.getWidth(),out.getHeight());g.drawImage(src,0,0,null);}finally{g.dispose();}return out;}
    private static BufferedImage sheet(String key,Map<Variant,BufferedImage> images){int gap=24,pad=24,titleH=38,labelH=25,cellW=0,cellH=0;for(BufferedImage im:images.values()){cellW=Math.max(cellW,im.getWidth());cellH=Math.max(cellH,im.getHeight());}int w=pad*2+cellW*2+gap,h=pad*2+titleH+2*(labelH+cellH)+gap;BufferedImage out=new BufferedImage(w,h,BufferedImage.TYPE_INT_RGB);Graphics2D g=out.createGraphics();try{g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);g.setColor(Color.WHITE);g.fillRect(0,0,w,h);g.setColor(Color.BLACK);g.setFont(new Font("SansSerif",Font.BOLD,24));g.drawString(key+" ordinary cartouche audit",pad,pad+23);g.setFont(new Font("SansSerif",Font.PLAIN,16));for(int i=0;i<VARIANTS.size();i++){Variant v=VARIANTS.get(i);BufferedImage im=images.get(v);int col=i%2,row=i/2,x=pad+col*(cellW+gap),y=pad+titleH+row*(labelH+cellH+gap);g.drawString(v.label,x,y+16);g.drawImage(im,x+(cellW-im.getWidth())/2,y+labelH+(cellH-im.getHeight())/2,null);}}finally{g.dispose();}return out;}

    public static void main(String[]args)throws Exception{
        if(args.length<2)throw new IllegalArgumentException("usage: CartoucheAuditExport <font-dir> <output-dir>");
        Path fontDir=Path.of(args[0]),out=Path.of(args[1]);Files.createDirectories(out);int written=0;
        try(NanpaLinjaN n=NanpaLinjaN.create(fontDir)){
            for(FontPairInfo f:n.listFonts()){
                Map<Variant,BufferedImage> images=new LinkedHashMap<>();
                for(Variant v:VARIANTS){
                    RenderOptions o=new RenderOptions().withFont(f.key()).withFontSize(56f).withPaddingPx(18);
                    if(v.halo())o=o.withHalo(true).withHaloColor(HALO_RED);
                    PngRenderResult result=n.renderToPng(v.input(),o);
                    BufferedImage decoded=ImageIO.read(new java.io.ByteArrayInputStream(result.bytes()));
                    if(decoded==null)throw new IOException("Could not decode production PNG for "+f.key()+"/"+v.id());
                    images.put(v,white(decoded));
                    Files.write(out.resolve(f.key()+"--"+v.id()+".png"),result.bytes());written++;
                }
                Files.write(out.resolve(f.key()+"--ordinary-cartouche-contact.png"),png(sheet(f.key(),images)));written++;
            }
        }
        System.out.println("Java ordinary cartouche audit: "+written+" PNG file(s) written to "+out.toAbsolutePath().normalize());
        System.out.println("All samples were rendered through NanpaLinjaN.renderToPng(); tally routing comes from each font pair's cartoucheTallyMode; halo color is "+HALO_RED+".");
    }
}
