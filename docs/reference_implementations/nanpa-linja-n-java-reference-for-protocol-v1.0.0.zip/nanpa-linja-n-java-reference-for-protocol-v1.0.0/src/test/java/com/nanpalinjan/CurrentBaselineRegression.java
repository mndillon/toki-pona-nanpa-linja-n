package com.nanpalinjan;

import java.nio.file.Path;
import java.util.*;

/** Focused regression coverage for post-v1.0.2 JavaScript-baseline additions. */
public final class CurrentBaselineRegression {
    private static int checks;
    private static void c(boolean ok,String name){checks++;if(!ok)throw new IllegalStateException("current baseline regression failed: "+name);}

    public static void main(String[] args) throws Exception {
        if(args.length<1)throw new IllegalArgumentException("fonts.zip path required");
        Path fonts=Path.of(args[0]);
        try(NanpaLinjaN n=NanpaLinjaN.create(fonts)){
            ParseOptions numeric=new ParseOptions().withAbbreviateNumericCartouches(true).withPreserveNumericCartoucheBreaksInAbbreviation(true);
            ParseResult p=n.parseNumber("123",numeric);
            c(p!=null,"instance parseNumber");
            c("Nanpa Watusen".equals(p.properName),"parseNumber properName");
            c("#~WTS".equals(p.uniqueCode),"parseNumber uniqueCode");
            c(p.abbreviatedWords!=null&&p.abbreviatedWords.equals(List.of("nanpa",":","wan","tu","seli","nanpa")),"parseNumber abbreviatedWords");
            c(p.abbreviatedUcsurCodepoints!=null&&!p.abbreviatedUcsurCodepoints.isEmpty(),"parseNumber abbreviated codepoints");
            c(p.nasinNanpaPonaWords==null,"parseNumber NNP null by default");
            ParseResult pn=n.parseNumber("123",numeric.withNasinNanpaPona(true));
            c(pn!=null&&pn.nasinNanpaPonaWords.equals(List.of("wan","ale","mute","tu","wan")),"parseNumber NNP words");
            c(n.parseNumber("-123",numeric.withNasinNanpaPona(true)).nasinNanpaPonaWords.equals(List.of("weka","wan","ale","mute","tu","wan")),"negative NNP words");
            c(n.parseNumber("123.45",numeric.withNasinNanpaPona(true)).nasinNanpaPonaWords.equals(List.of("wan","ale","mute","tu","wan","ala","mute","mute","luka")),"decimal NNP words");

            String[] invalid={"12 34","12 .34","12. 34","12 %","1 e8","1 *10^8","1* 10^8","1 * 10 ^ 8","1 /2","1/ 2","1 +1/2","1+ 1/2","2026- 09-20","12: 30","1 1/2"};
            for(String x:invalid)c(n.parseNumber(x,numeric)==null,"whitespace rejection "+x);
            c(n.parseNumber(" 123 ",numeric)!=null,"outer whitespace remains valid");
            c(n.parseNumber("1e+3",numeric)!=null,"scientific plus exponent valid");
            c(n.parseNumber("1+1/2",numeric)!=null,"mixed fraction plus valid");
            c(n.parseNumber("Nanpa Wan Eke Tusenan Eke Lunumun",numeric)!=null,"proper-name spaces valid");
            c(n.parseNumber("[nanpa : wan tu seli nanpa]",numeric)!=null,"cartouche spaces valid");
            c(NanpaApi.encodeDecimal("1 1/2",numeric)==null,"encoder rejects spaced mixed fraction");
            c(NanpaApi.encodeDecimal("1e+3",numeric)!=null,"encoder preserves scientific plus exponent");
            c(NanpaApi.encodeDecimal("1+1/2",numeric)!=null,"encoder accepts plus mixed fraction");

            RenderOptions base=new RenderOptions().withFont("linjaPona").withParser(numeric);
            String input="toki&pona 123 456 zz pi(telo lete) te tomo to";
            DocumentAst ast=n.parseInput(input,base);
            c(input.equals(n.astToText(ast,base.withNumericOutput("source"))),"ast source");
            c("toki&pona Nanpa Watusen Nanpa Nalunun zz pi(telo lete) te tomo to".equals(n.astToText(ast,base.withNumericOutput("properName"))),"ast properName");
            c("toki&pona #~WTS #~ALU zz pi(telo lete) te tomo to".equals(n.astToText(ast,base.withNumericOutput("#~"))),"ast #~");
            DocumentAst properPair=n.parseInput("Nanpa Watusen Nanpa Nalunun",base);
            c("#~WTS #~ALU".equals(n.astToText(properPair,base.withNumericOutput("#~"))),"multiple proper-name numeric structures");
            c("toki&pona [nanpa : wan tu seli nanpa] [nanpa : awen luka utala nanpa] zz pi(telo lete) te tomo to".equals(n.astToText(ast,base.withNumericOutput("cartouche"))),"ast abbreviated cartouche");
            RenderOptions full=base.withParser(numeric.withAbbreviateNumericCartouches(false)).withNumericOutput("cartouche");
            c("toki&pona [nanpa : wan ala tu uta seli e nanpa] [nanpa : nena awen luka uta nena utala nanpa] zz pi(telo lete) te tomo to".equals(n.astToText(ast,full)),"ast full cartouche");
            RenderOptions nnp=base.withParser(numeric.withNasinNanpaPona(true).withAbbreviateNumericCartouches(false)).withNumericOutput("cartouche");
            c("toki&pona wan ale mute tu wan tu tu ale mute mute luka luka luka wan zz pi(telo lete) te tomo to".equals(n.astToText(ast,nnp)),"ast NNP");

            DocumentAst mixed=n.parseInput("1+1/2",base);
            String mixedOut=n.astToText(mixed,base.withNumericOutput("cartouche")); c("[nanpa : wan kin wan o o tu nanpa]".equals(mixedOut),"mixed fraction abbreviated ast");
            DocumentAst fallback=n.parseInput("#ABC 0b1010",base);
            c("#ABC 0b1010".equals(n.astToText(fallback,base.withNumericOutput("#~"))),"hex/binary #~ fallback");

            boolean badMode=false;try{n.astToText(ast,base.withNumericOutput("bad-mode"));}catch(IllegalArgumentException e){badMode=true;}c(badMode,"invalid numericOutput rejected");

            DocumentSegment raw=DocumentSegment.rawUcsur(List.of(0xF1900,0x300C),0,0);
            DocumentAst rawAst=new DocumentAst("document","",Map.of(),List.of(new DocumentLine(0,0,0,"",List.of(raw))));
            c("U+F1900 U+300C".equals(n.astToText(rawAst)),"rawUcsur serialization");

            DocumentAst old=n.parseInput("123",base);DocumentLine line=old.lines().getFirst();DocumentSegment seg=line.children().getFirst();
            DocumentSegment stale=new DocumentSegment(seg.kind(),"124",seg.image(),seg.openQuote(),seg.closeQuote(),seg.sourceStart(),seg.sourceEnd(),seg.codepoints(),seg.numericStructures());
            DocumentAst staleAst=new DocumentAst("document","124",old.parserOptions(),List.of(new DocumentLine(0,0,0,"124",List.of(stale))));
            c("124".equals(n.astToText(staleAst,base.withNumericOutput("properName"))),"stale numeric metadata bypass");

            // Synthetic te/to drawing is validated geometrically by CompositionInteractionRegression
            // (132 current-JavaScript checks). Keep a focused routing check here.
            for(String font:List.of("linjaPona","linjaSike")){
                RenderPlan plan=n.buildRenderPlan("te tomo to",base.withFont(font));
                c(plan.runs().stream().anyMatch(r->r.canonicalCodepoints().contains(0x300C)&&r.canonicalCodepoints().contains(0x300D)),font+" canonical te/to brackets");
                c(plan.runs().stream().noneMatch(r->r.renderCodepoints().contains(0xFFFD)),font+" no replacement glyph");
            }
        }
        System.out.println("Java current-baseline focused regressions: "+checks+"/"+checks+" PASS");
    }
}
