package com.nanpalinjan;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.nio.file.Path;
import java.util.*;

public final class OrdinaryCartoucheRegression {
    private static void check(boolean ok,String m){if(!ok)throw new IllegalStateException(m);}
    private static boolean containsCp(String s,int cp){return s.codePoints().anyMatch(x->x==cp);}
    private static boolean printableAscii(String s){return s.codePoints().allMatch(cp->cp>=0x20&&cp<=0x7E);}
    private static int countNear(BufferedImage img, Color c){int n=0;for(int y=0;y<img.getHeight();y++)for(int x=0;x<img.getWidth();x++){int argb=img.getRGB(x,y);int a=(argb>>>24)&255;if(a<32)continue;int r=(argb>>>16)&255,g=(argb>>>8)&255,b=argb&255;if(Math.abs(r-c.getRed())+Math.abs(g-c.getGreen())+Math.abs(b-c.getBlue())<90)n++;}return n;}
    private static boolean nearColorAt(BufferedImage img,double fx,double fy,Color c,int radius){int cx=(int)Math.round(fx),cy=(int)Math.round(fy);for(int y=Math.max(0,cy-radius);y<=Math.min(img.getHeight()-1,cy+radius);y++)for(int x=Math.max(0,cx-radius);x<=Math.min(img.getWidth()-1,cx+radius);x++){int argb=img.getRGB(x,y);int a=(argb>>>24)&255;if(a<64)continue;int r=(argb>>>16)&255,g=(argb>>>8)&255,b=argb&255;if(Math.abs(r-c.getRed())+Math.abs(g-c.getGreen())+Math.abs(b-c.getBlue())<100)return true;}return false;}

    @SuppressWarnings("unchecked")
    public static void main(String[]args)throws Exception{
        if(args.length<1)throw new IllegalArgumentException("usage: OrdinaryCartoucheRegression <font-dir> [browser-oracle-json]");
        Path fontDir=Path.of(args[0]); Map<String,Object> oracle=null; if(args.length>1) oracle=(Map<String,Object>)MiniJson.parse(java.nio.file.Files.readString(Path.of(args[1]))); int fonts=0,manual=0,ucsur=0,halo=0,manualHaloCompositing=0,browserCases=0;
        try(NanpaLinjaN n=NanpaLinjaN.create(fontDir)){
            for(FontPairInfo f:n.listFonts()){
                fonts++;
                String mode=String.valueOf(f.settings().getOrDefault("cartoucheTallyMode","ucsur")).toLowerCase(Locale.ROOT);
                RenderOptions base=new RenderOptions().withFont(f.key()).withFontSize(56f).withPaddingPx(18);
                RenderPlan ordinary=n.buildRenderPlan("[jan pona]",base);
                check(ordinary.cartoucheCount()==1,f.key()+" ordinary cartoucheCount");
                RenderRun r0=ordinary.runs().getFirst();
                check("cartouche".equals(r0.fontRole())&&!r0.numericCartouche(),f.key()+" ordinary role");
                RenderPlan tally=n.buildRenderPlan("[jan pona,,]",base);
                String text=tally.runs().getFirst().renderText();
                if(oracle!=null){
                    Map<String,Object> fo=(Map<String,Object>)oracle.get(f.key());
                    check(fo!=null,f.key()+" browser ordinary oracle entry");
                    for(String caseId:List.of("ordinary","ordinary-halo","tallies","tallies-halo")){
                        Map<String,Object> co=(Map<String,Object>)fo.get(caseId);
                        check(co!=null,f.key()+"/"+caseId+" browser oracle case");
                        String javaText=caseId.startsWith("ordinary")?ordinary.runs().getFirst().renderText():tally.runs().getFirst().renderText();
                        List<Integer> actual=javaText.codePoints().boxed().toList();
                        List<Integer> expected=((List<?>)co.get("renderCps")).stream().map(x->((Number)x).intValue()).toList();
                        check(actual.equals(expected),f.key()+"/"+caseId+" render-adapter sequence differs from Chromium JavaScript reference: "+actual+" != "+expected);
                        check(String.valueOf(co.get("renderAdapterId")).equals(f.renderAdapterId()),f.key()+"/"+caseId+" renderAdapterId browser parity");
                        browserCases++;
                    }
                }
                if("manual".equals(mode)){
                    check(!containsCp(text,0xF199E),f.key()+" manual mode leaked U+F199E into font run");
                    check(tally.height()>ordinary.height(),f.key()+" manual tally must extend below ordinary cartouche");
                    if(f.renderAdapterId().equals("linja-pona-legacy-v1")||f.renderAdapterId().equals("linja-sike-legacy-v1"))check(printableAscii(text),f.key()+" legacy ordinary cartouche must be adapted to native ASCII");
                    manual++;
                }else if("ucsur".equals(mode)){
                    check(containsCp(text,0xF199E),f.key()+" UCSUR tally mode must retain U+F199E in font run");
                    ucsur++;
                }
                CanvasRenderResult haloResult=n.renderToCanvas("[jan pona,,]",base.withHalo(true).withHaloColor("#D91E18"));
                check(countNear(haloResult.canvas(),new Color(0xD91E18))>10,f.key()+" red halo pixels");
                check(countNear(haloResult.canvas(),Color.BLACK)>10,f.key()+" black foreground pixels");
                if("manual".equals(mode)){
                    RenderRun hr=haloResult.plan().runs().getFirst();
                    check(hr.tallyGroups().size()==1,f.key()+" halo tally group count");
                    TallyGroup g=hr.tallyGroups().getFirst();
                    check(g.strokeCentersPx().size()==2,f.key()+" halo tally stroke count");
                    double midY=(g.topYPx()+g.bottomYPx())/2.0;
                    for(double cx:g.strokeCentersPx())check(nearColorAt(haloResult.canvas(),cx,midY,Color.BLACK,1),f.key()+" foreground tally must be painted over halo backing");
                    double between=(g.strokeCentersPx().get(0)+g.strokeCentersPx().get(1))/2.0;
                    check(nearColorAt(haloResult.canvas(),between,midY,new Color(0xD91E18),1),f.key()+" rounded tally-group halo backing must span between strokes");
                    check(nearColorAt(haloResult.canvas(),between,g.topYPx(),Color.BLACK,2),f.key()+" cartouche bottom rule must be foreground over tally halo backing");
                    manualHaloCompositing++;
                }
                halo++;
            }
        }
        check(fonts==8,"font count");check(manual==5,"manual tally font count");check(ucsur==3,"UCSUR tally font count");
        System.out.println("Java ordinary cartouche routing: "+fonts+"/8 PASS");
        System.out.println("Java manual tally routing: "+manual+"/5 PASS (U+F199E excluded from font runs)");
        System.out.println("Java UCSUR tally routing: "+ucsur+"/3 PASS (U+F199E retained in font runs)");
        System.out.println("Java ordinary cartouche red-halo rendering: "+halo+"/8 PASS");
        System.out.println("Java manual tally halo compositing: "+manualHaloCompositing+"/5 PASS (group backing behind foreground)");
        if(oracle!=null)System.out.println("JavaScript Chromium ordinary-cartouche adapter parity: "+browserCases+"/32 PASS");
    }
}
