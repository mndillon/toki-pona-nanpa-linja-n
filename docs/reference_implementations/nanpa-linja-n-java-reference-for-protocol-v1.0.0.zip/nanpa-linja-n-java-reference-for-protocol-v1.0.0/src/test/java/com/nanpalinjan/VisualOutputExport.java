package com.nanpalinjan;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Optional utility that writes human-inspectable PNG samples to disk. */
public final class VisualOutputExport {
    private static void check(boolean ok, String m){ if(!ok) throw new IllegalStateException(m); }
    private static ParseOptions abbreviation(ParseOptions p, boolean ab){
        return new ParseOptions(p.enableBinaryParsing(),p.enableHexParsing(),p.mode(),p.numericMode(),p.nanpaColonParsing(),p.nanpaColonRendering(),p.relaxedNanpaLinjanParsing(),p.relaxedNanpaLinjanRendering(),ab,ab,p.numericCartoucheStartGlyph());
    }
    private static byte[] writeWhitePng(BufferedImage src) throws IOException {
        BufferedImage out = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D g = out.createGraphics();
        try {
            g.setColor(Color.WHITE);
            g.fillRect(0,0,out.getWidth(),out.getHeight());
            g.drawImage(src,0,0,null);
        } finally { g.dispose(); }
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        if(!ImageIO.write(out, "png", baos)) throw new IOException("PNG ImageIO writer unavailable");
        return baos.toByteArray();
    }
    private static void write(Path path, byte[] bytes) throws IOException {
        Files.createDirectories(path.getParent());
        Files.write(path, bytes);
        check(Files.size(path) > 100, "wrote suspiciously small PNG: "+path);
    }

    public static void main(String[] args) throws Exception {
        if(args.length < 1 || args.length > 2) {
            throw new IllegalArgumentException("usage: VisualOutputExport <font-dir> [output-dir]");
        }
        Path fontDir = Path.of(args[0]);
        Path outDir = args.length >= 2 ? Path.of(args[1]) : Path.of("test-output");
        Files.createDirectories(outDir);

        // Keep the sample set stable and easy to inspect.
        String fullInput = "123.45";
        String abbreviatedInput = fullInput;
        int written = 0;

        try(NanpaLinjaN n = NanpaLinjaN.create(fontDir)) {
            for(FontPairInfo f : n.listFonts()) {
                String key = f.key();
                RenderOptions base = new RenderOptions().withFont(key).withFontSize(56f);

                PngRenderResult full = n.renderToPng(fullInput, base);
                Path fullPath = outDir.resolve(key + "-full.png");
                write(fullPath, full.bytes());
                written++;

                CanvasRenderResult fullCanvas = n.renderToCanvas(fullInput, base);
                Path fullWhitePath = outDir.resolve(key + "-full-white.png");
                write(fullWhitePath, writeWhitePng(fullCanvas.canvas()));
                written++;

                RenderOptions abbr = base.withParser(abbreviation(base.parser(), true));
                PngRenderResult abbreviated = n.renderToPng(abbreviatedInput, abbr);
                Path abbreviatedPath = outDir.resolve(key + "-abbreviated.png");
                write(abbreviatedPath, abbreviated.bytes());
                written++;

                CanvasRenderResult abbreviatedCanvas = n.renderToCanvas(abbreviatedInput, abbr);
                Path abbreviatedWhitePath = outDir.resolve(key + "-abbreviated-white.png");
                write(abbreviatedWhitePath, writeWhitePng(abbreviatedCanvas.canvas()));
                written++;
            }
        }
        System.out.println("Java visual PNG export: " + written + " file(s) written to " + outDir.toAbsolutePath().normalize());
    }
}
