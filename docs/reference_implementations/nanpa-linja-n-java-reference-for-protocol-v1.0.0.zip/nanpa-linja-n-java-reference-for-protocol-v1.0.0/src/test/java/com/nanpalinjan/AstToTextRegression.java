package com.nanpalinjan;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Dedicated regression coverage for the additive AST -> text facade API. */
public final class AstToTextRegression {
    private static int checks;

    private static void check(boolean condition, String name) {
        checks++;
        if (!condition) throw new IllegalStateException("astToText regression failed: " + name);
    }

    private static DocumentAst replaceFirstBracket(DocumentAst ast, String value) {
        List<DocumentLine> lines = new ArrayList<>(ast.lines());
        for (int li = 0; li < lines.size(); li++) {
            DocumentLine line = lines.get(li);
            List<DocumentSegment> children = new ArrayList<>(line.children());
            for (int si = 0; si < children.size(); si++) {
                DocumentSegment old = children.get(si);
                if ("bracket".equals(old.kind())) {
                    children.set(si, DocumentSegment.bracket(value, old.sourceStart(), old.sourceEnd()));
                    lines.set(li, new DocumentLine(line.index(), line.sourceLineIndex(), line.sentenceIndexInSourceLine(), line.sourceText(), children));
                    return new DocumentAst(ast.type(), ast.normalizedInput(), ast.parserOptions(), lines);
                }
            }
        }
        throw new IllegalStateException("test AST did not contain a bracket segment");
    }

    private static DocumentAst replaceFirstQuote(DocumentAst ast, String value, String open, String close) {
        List<DocumentLine> lines = new ArrayList<>(ast.lines());
        for (int li = 0; li < lines.size(); li++) {
            DocumentLine line = lines.get(li);
            List<DocumentSegment> children = new ArrayList<>(line.children());
            for (int si = 0; si < children.size(); si++) {
                DocumentSegment old = children.get(si);
                if ("quote".equals(old.kind())) {
                    children.set(si, DocumentSegment.quote(value, open, close, old.sourceStart(), old.sourceEnd()));
                    lines.set(li, new DocumentLine(line.index(), line.sourceLineIndex(), line.sentenceIndexInSourceLine(), line.sourceText(), children));
                    return new DocumentAst(ast.type(), ast.normalizedInput(), ast.parserOptions(), lines);
                }
            }
        }
        throw new IllegalStateException("test AST did not contain a quote segment");
    }

    private static ImageDescriptor firstImage(DocumentAst ast) {
        for (DocumentLine line : ast.lines()) for (DocumentSegment segment : line.children()) if ("image".equals(segment.kind())) return segment.image();
        return null;
    }

    public static void main(String[] args) throws Exception {
        try (NanpaLinjaN nanpa = NanpaLinjaN.create((Path) null)) {
            String exact = "jan   pona\t[ jan  pona,, ]\n\n“toki  pona”";
            check(exact.equals(nanpa.astToText(nanpa.parseInput(exact))), "exact whitespace, blank-line and quote round-trip");

            RenderOptions splitOptions = new RenderOptions().withParser(new ParseOptions().withBreakLinesAtFullStops(true));
            String split = "jan pona.  ona pona.\nmi pona.";
            check(split.equals(nanpa.astToText(nanpa.parseInput(split, splitOptions))), "physical lines preserved after full-stop splitting");

            DocumentAst bracketAst = nanpa.parseInput("jan   pona [ jan  pona,, ]");
            DocumentAst editedBracket = replaceFirstBracket(bracketAst, " jan  suno,, ");
            String editedText = nanpa.astToText(editedBracket);
            check("jan   pona [ jan  suno,, ]".equals(editedText), "edited bracket value serialized without reformatting surrounding text");

            DocumentAst quoteAst = nanpa.parseInput("mi toki e \"pona\"");
            DocumentAst editedQuote = replaceFirstQuote(quoteAst, "suno", "“", "”");
            check("mi toki e “suno”".equals(nanpa.astToText(editedQuote)), "edited quote value and delimiters serialized");

            String imageSource = "img(src='x.png',w='20',h='30',alt='hello',valign='center',wriggle=4,transparent=false)";
            DocumentAst imageAst = nanpa.parseInput(imageSource);
            String canonicalImage = nanpa.astToText(imageAst);
            ImageDescriptor before = firstImage(imageAst);
            ImageDescriptor after = firstImage(nanpa.parseInput(canonicalImage));
            check(before != null && before.equals(after), "image descriptor semantic round-trip");
            check(canonicalImage.startsWith("img(") && canonicalImage.endsWith(")"), "image emitted as canonical img(...) source");

            boolean nullRejected = false;
            try { nanpa.astToText(null); } catch (IllegalArgumentException expected) { nullRejected = true; }
            check(nullRejected, "null AST rejected");

            DocumentSegment bogus = new DocumentSegment("bogus", "x", null, null, null, 0, 1);
            DocumentAst invalid = new DocumentAst("document", "x", java.util.Map.of(), List.of(new DocumentLine(0, 0, 0, "x", List.of(bogus))));
            boolean bogusRejected = false;
            try { nanpa.astToText(invalid); } catch (IllegalArgumentException expected) { bogusRejected = true; }
            check(bogusRejected, "unsupported segment kind rejected");

            if (checks != 8) throw new IllegalStateException("Expected 8 astToText checks, got " + checks);
            System.out.println("Java astToText regression: 8/8 PASS");
        }

        if (args.length > 0) {
            Path fonts = Path.of(args[0]);
            try (NanpaLinjaN nanpa = NanpaLinjaN.create(fonts)) {
                DocumentAst ast = replaceFirstBracket(nanpa.parseInput("mi toki e [jan pona,,]"), "jan suno,,");
                String edited = nanpa.astToText(ast);
                PngRenderResult png = nanpa.renderToPng(edited, new RenderOptions().withFont("linjaPona"));
                if (png.bytes() == null || png.bytes().length < 100) throw new IllegalStateException("astToText edited output did not render to PNG");
                System.out.println("Java astToText render integration: 1/1 PASS");
            }
        }
    }
}
