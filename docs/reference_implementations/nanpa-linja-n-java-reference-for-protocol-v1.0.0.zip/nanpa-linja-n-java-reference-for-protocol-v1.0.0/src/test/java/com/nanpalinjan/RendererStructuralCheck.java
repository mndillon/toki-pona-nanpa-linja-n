package com.nanpalinjan;

import java.nio.file.*;

public final class RendererStructuralCheck {
    private static void check(boolean ok,String m){if(!ok)throw new IllegalStateException(m);}
    private static void one(NanpaLinjaN n,String id,String input,int opener,int closer,int base,boolean hex,boolean bin,RenderOptions o)throws Exception{
        RenderPlan p=n.buildRenderPlan(input,o);
        check(p.cartoucheCount()==1,id+" cartoucheCount");
        RenderRun r=p.runs().getFirst();
        check(r.numericCartouche(),id+" numeric");
        check(r.openerCodepoint()!=null&&r.openerCodepoint()==opener,id+" opener");
        check(r.closerCodepoint()!=null&&r.closerCodepoint()==closer,id+" closer");
        check(r.numericBase()==base,id+" base");
        check(r.hexCartouche()==hex,id+" hex");
        check(r.binaryCartouche()==bin,id+" binary");
    }
    public static void main(String[] args)throws Exception{
        Path dir=Path.of(args[0]);
        try(NanpaLinjaN n=NanpaLinjaN.create(dir)){
            RenderOptions d=new RenderOptions();
            one(n,"decimal-12345","123.45",0xF193D,0xF193D,10,false,false,d);
            one(n,"time-1230","12:30",0xF196B,0xF193D,10,false,false,d);
            one(n,"date-full","2026-09-13",0xF1964,0xF193D,10,false,false,d);
            one(n,"date-yearless","--09-13",0xF1964,0xF193D,10,false,false,d);
            one(n,"suno-day-one","[suno : wan nanpa]",0xF1964,0xF193D,10,false,false,d);
            one(n,"toki-explicit-telephone","Toki Newan Ene Tusenan Ene Lululun Ene Numupijon",0xF196C,0xF193D,10,false,false,d);
            one(n,"hex-abcdef","#ABCDEF",0xF193E,0xF193E,16,true,false,d);
            one(n,"binary-10101","0b10101",0xF1943,0xF1943,2,false,true,d);
            ParseOptions p=d.parser();
            ParseOptions ab=new ParseOptions(p.enableBinaryParsing(),p.enableHexParsing(),p.mode(),p.numericMode(),p.nanpaColonParsing(),p.nanpaColonRendering(),p.relaxedNanpaLinjanParsing(),p.relaxedNanpaLinjanRendering(),true,true,p.numericCartoucheStartGlyph());
            RenderPlan ap=n.buildRenderPlan("12:30",d.withParser(ab));
            check(ap.abbreviated(),"abbreviated time");
            RenderPlan ordinary=n.buildRenderPlan("toki pona",d);
            check(ordinary.cartoucheCount()==0&&ordinary.runs().getFirst().fontRole().equals("text"),"ordinary text");
        }
        System.out.println("Java structural browser-renderer parity cases: 10/10 PASS");
    }
}
