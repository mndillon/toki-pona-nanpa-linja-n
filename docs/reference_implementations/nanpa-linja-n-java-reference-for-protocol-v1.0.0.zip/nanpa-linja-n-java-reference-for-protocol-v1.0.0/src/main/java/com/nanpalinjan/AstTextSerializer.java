package com.nanpalinjan;

import java.util.*;

/** Current JavaScript-compatible full-document AST serializer. */
final class AstTextSerializer {
    private AstTextSerializer() {}

    static String astToText(DocumentAst ast) {
        ParseOptions parser=ast==null?new ParseOptions():ParseOptions.fromMap(ast.parserOptions());
        return astToText(ast,new RenderOptions().withParser(parser));
    }

    static String astToText(DocumentAst ast,RenderOptions options) {
        if(ast==null)throw new IllegalArgumentException("astToText() expects a document AST");
        if(ast.type()!=null&&!ast.type().isEmpty()&&!"document".equals(ast.type()))throw new IllegalArgumentException("astToText() expects a document AST");
        RenderOptions o=options==null?new RenderOptions().withParser(ParseOptions.fromMap(ast.parserOptions())):options;
        String mode=o.numericOutput()==null||o.numericOutput().isBlank()?"source":o.numericOutput().trim();
        if(!Set.of("source","properName","#~","cartouche").contains(mode))throw new IllegalArgumentException("unsupported numericOutput mode: "+mode);
        StringBuilder out=new StringBuilder();Integer previous=null;
        for(int i=0;i<ast.lines().size();i++){
            DocumentLine line=ast.lines().get(i);if(line==null)throw new IllegalArgumentException("AST line must not be null");
            int sli=line.sourceLineIndex()>=0?line.sourceLineIndex():i;if(previous!=null&&previous!=sli)out.append('\n');
            if(line.children()!=null)for(DocumentSegment seg:line.children()){String source=segmentText(seg);out.append(applyNumeric(source,seg,mode,o.parser()));}
            previous=sli;
        }
        return out.toString();
    }

    private static String applyNumeric(String source,DocumentSegment seg,String mode,ParseOptions parser){
        if("source".equals(mode)||seg.numericStructures()==null||seg.numericStructures().isEmpty())return source;
        List<NumericStructure> list=new ArrayList<>(seg.numericStructures());list.sort(Comparator.comparingInt(NumericStructure::index).thenComparingInt(NumericStructure::end));
        StringBuilder out=new StringBuilder();int pos=0;boolean replaced=false;
        for(NumericStructure n:list){if(n.end()<=n.index()||n.index()<pos||n.end()>source.length())continue;if(!source.substring(n.index(),n.end()).equals(n.sourceText()))continue;out.append(source,pos,n.index());out.append(numericText(n.sourceText(),mode,parser));pos=n.end();replaced=true;}
        if(!replaced)return source;out.append(source.substring(pos));return out.toString();
    }

    private static String numericText(String source,String mode,ParseOptions parser){
        if("source".equals(mode))return source;ParseResult p=NanpaApi.parseNumber(source,parser);if(p==null)return source;
        if(parser.nasinNanpaPona()&&p.nasinNanpaPonaWords!=null&&!p.nasinNanpaPonaWords.isEmpty())return String.join(" ",p.nasinNanpaPonaWords);
        return switch(mode){
            case "properName" -> p.properName==null||p.properName.isEmpty()?source:p.properName;
            case "#~" -> p.uniqueCode!=null&&p.uniqueCode.startsWith("#~")?p.uniqueCode:source;
            case "cartouche" -> {List<String>w=parser.abbreviateNumericCartouches()&&p.abbreviatedWords!=null?p.abbreviatedWords:p.tpWords;yield w==null||w.isEmpty()?source:"["+String.join(" ",w)+"]";}
            default -> source;
        };
    }

    private static String segmentText(DocumentSegment segment){
        if(segment==null)throw new IllegalArgumentException("AST segment must not be null");String kind=segment.kind();if(kind==null)throw new IllegalArgumentException("AST segment kind is required");
        return switch(kind){
            case "text" -> orEmpty(segment.value());
            case "bracket" -> "["+orEmpty(segment.value())+"]";
            case "quote" -> {String open=nonEmpty(segment.openQuote(),"\"");String close=nonEmpty(segment.closeQuote(),"“".equals(open)?"”":"\"");yield open+orEmpty(segment.value())+close;}
            case "image" -> imageText(segment.image());
            case "rawUcsur" -> rawUcsur(segment.codepoints());
            default -> throw new IllegalArgumentException("Unsupported AST segment kind: "+kind);
        };
    }

    private static String rawUcsur(List<Integer> cps){List<String>parts=new ArrayList<>();for(Integer cp:cps==null?List.<Integer>of():cps){if(cp==null||cp<0||cp>0x10FFFF||(cp>=0xD800&&cp<=0xDFFF))throw new IllegalArgumentException("invalid rawUcsur code point: "+cp);parts.add(String.format("U+%04X",cp));}return String.join(" ",parts);}
    private static String imageText(ImageDescriptor image){ImageDescriptor d=image==null?new ImageDescriptor("",null,null,null,"baseline",8,true):image;StringBuilder args=new StringBuilder();arg(args,"src",d.src(),false);arg(args,"w",d.w(),false);arg(args,"h",d.h(),false);arg(args,"alt",d.alt(),true);if(d.valign()!=null&&!d.valign().isEmpty()&&!"baseline".equals(d.valign()))arg(args,"valign",d.valign(),true);if(Double.compare(d.wriggle(),8d)!=0){comma(args);args.append("wriggle=").append(Double.isFinite(d.wriggle())?numberText(d.wriggle()):quote(String.valueOf(d.wriggle())));}if(!d.transparent()){comma(args);args.append("transparent=false");}return "img("+args+")";}
    private static void arg(StringBuilder a,String n,String v,boolean empty){if(v==null||(!empty&&v.isEmpty()))return;comma(a);a.append(n).append('=').append(quote(v));}
    private static void comma(StringBuilder a){if(!a.isEmpty())a.append(',');}
    private static String quote(String v){String t=v==null?"":v;if(t.indexOf('\'')<0)return "'"+t+"'";if(t.indexOf('"')<0)return "\""+t+"\"";return "\""+t.replace("\\","\\\\").replace("\"","\\\"")+"\"";}
    private static String numberText(double v){return v==Math.rint(v)?Long.toString((long)v):Double.toString(v);}
    private static String orEmpty(String v){return v==null?"":v;}private static String nonEmpty(String v,String f){return v==null||v.isEmpty()?f:v;}
}
