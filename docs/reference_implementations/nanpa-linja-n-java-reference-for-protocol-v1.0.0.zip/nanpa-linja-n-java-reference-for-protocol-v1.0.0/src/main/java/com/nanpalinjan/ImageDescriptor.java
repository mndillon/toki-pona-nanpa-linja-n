package com.nanpalinjan;
public record ImageDescriptor(String src,String w,String h,String alt,String valign,double wriggle,boolean transparent){
 public ImageDescriptor{src=src==null?"":src;valign=valign==null?"baseline":valign;wriggle=Double.isFinite(wriggle)&&wriggle>=0?wriggle:8;}
}
