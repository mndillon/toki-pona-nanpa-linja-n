package com.nanpalinjan;
import java.util.*;
/** Foreground, halo, and unknown-text paint configuration. */
public record PaintOptions(String fillStyle, UnknownTextStyle unknownText){
 public PaintOptions(){this("#000000",new UnknownTextStyle());}
 public PaintOptions{fillStyle=normalizeColor(fillStyle,"#000000");unknownText=unknownText==null?new UnknownTextStyle():unknownText;}
 @SuppressWarnings("unchecked") public static PaintOptions fromMap(Map<String,?>m){if(m==null)return new PaintOptions();return new PaintOptions(String.valueOf(m.containsKey("fillStyle")?m.get("fillStyle"):"#000000"),UnknownTextStyle.fromMap(m.get("unknownText")));}
 static String normalizeColor(String value,String d){String s=value==null?d:value.trim();if(s.matches("(?i)^#[0-9a-f]{6}$"))return s.toUpperCase();if(s.matches("(?i)^#[0-9a-f]{3}$")){char[]c=s.substring(1).toUpperCase().toCharArray();return "#"+c[0]+c[0]+c[1]+c[1]+c[2]+c[2];}return d;}
}
