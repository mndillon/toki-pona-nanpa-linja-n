package com.nanpalinjan;

/** Numeric span metadata attached to document AST segments for astToText re-serialization. */
public record NumericStructure(
        String kind,
        String sourceText,
        int index,
        int end,
        String semanticKind,
        String semanticStartGlyph,
        boolean wholeSegment) {
    public NumericStructure {
        kind = kind == null || kind.isBlank() ? "number" : kind;
        sourceText = sourceText == null ? "" : sourceText;
        semanticKind = semanticKind == null ? "" : semanticKind;
        semanticStartGlyph = semanticStartGlyph == null ? "" : semanticStartGlyph;
    }
}
