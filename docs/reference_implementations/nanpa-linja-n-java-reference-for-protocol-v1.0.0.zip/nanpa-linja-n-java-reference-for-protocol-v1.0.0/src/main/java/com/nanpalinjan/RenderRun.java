package com.nanpalinjan;

import java.util.*;

/** Public semantic/measured run. The legacy constructor is retained. */
public record RenderRun(
        String id,
        int lineIndex,
        int runIndex,
        String kind,
        String renderMode,
        String fontRole,
        boolean numericCartouche,
        boolean hexCartouche,
        boolean binaryCartouche,
        int numericBase,
        Integer openerCodepoint,
        Integer closerCodepoint,
        List<Integer> canonicalCodepoints,
        List<Integer> renderCodepoints,
        String renderText,
        String renderAdapterId,
        String sourceText,
        String sourceKind,
        int sourceStart,
        int sourceEnd,
        List<Integer> manualTallies,
        List<TallyGroup> tallyGroups,
        boolean quoted,
        boolean interpretedQuote,
        boolean unrecognized,
        String imageAlt,
        double xPx,
        double yPx,
        double widthPx,
        double heightPx,
        double baselineYPx) {
    public RenderRun {
        id=id==null?"":id;kind=kind==null?"glyph":kind;renderMode=renderMode==null?"text":renderMode;fontRole=fontRole==null?"word":fontRole;
        canonicalCodepoints=canonicalCodepoints==null?List.of():List.copyOf(canonicalCodepoints);
        renderCodepoints=renderCodepoints==null?canonicalCodepoints:List.copyOf(renderCodepoints);
        manualTallies=manualTallies==null?List.of():List.copyOf(manualTallies);tallyGroups=tallyGroups==null?List.of():List.copyOf(tallyGroups);
        renderText=renderText==null?"":renderText;renderAdapterId=renderAdapterId==null?"identity":renderAdapterId;
    }
    /** Frozen pre-full-renderer constructor. */
    public RenderRun(String fontRole, boolean numericCartouche, boolean hexCartouche, boolean binaryCartouche, int numericBase, Integer openerCodepoint, Integer closerCodepoint, List<Integer> canonicalCodepoints, String renderText, String renderAdapterId){
        this("",0,0,numericCartouche?"cartouche":"glyph",numericCartouche?"raster":"text",fontRole,numericCartouche,hexCartouche,binaryCartouche,numericBase,openerCodepoint,closerCodepoint,canonicalCodepoints,canonicalCodepoints,renderText,renderAdapterId,null,null,-1,-1,List.of(),List.of(),false,false,false,null,0,0,0,0,0);
    }
    public RenderRun withGeometry(double x,double y,double w,double h,double baseline,List<TallyGroup> groups){return new RenderRun(id,lineIndex,runIndex,kind,renderMode,fontRole,numericCartouche,hexCartouche,binaryCartouche,numericBase,openerCodepoint,closerCodepoint,canonicalCodepoints,renderCodepoints,renderText,renderAdapterId,sourceText,sourceKind,sourceStart,sourceEnd,manualTallies,groups==null?tallyGroups:groups,quoted,interpretedQuote,unrecognized,imageAlt,x,y,w,h,baseline);}
}
