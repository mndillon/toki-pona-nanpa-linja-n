package com.nanpalinjan;

public record SvgRenderResult(
        String kind,
        String input,
        String svg,
        RenderPlan plan,
        String fontKey,
        FontPairInfo preset,
        RenderOptions config) {}
