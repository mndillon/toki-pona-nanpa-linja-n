package com.nanpalinjan;

import java.util.LinkedHashMap;
import java.util.Map;

public record NumericPart(String kind, String digits, String character) {
    public static NumericPart digits(String s) { return new NumericPart("digits", s, null); }
    public static NumericPart delimiter(String s) { return new NumericPart("delimiter", null, s); }
    public Map<String,Object> toMap() {
        Map<String,Object> m=new LinkedHashMap<>(); m.put("kind",kind);
        if ("digits".equals(kind)) m.put("digits",digits); else m.put("char",character);
        return m;
    }
}
