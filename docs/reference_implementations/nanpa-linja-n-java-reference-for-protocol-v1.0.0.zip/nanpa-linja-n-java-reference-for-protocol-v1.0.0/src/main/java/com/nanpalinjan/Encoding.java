package com.nanpalinjan;

import java.util.*;
import java.util.regex.Pattern;

final class Encoding {
    private Encoding() {}
    private static final Pattern DIGITS=Pattern.compile("^\\d+$");
    static String repeat(String s,int n){return s.repeat(Math.max(0,n));}
    static String digitSyllable(int d, ParseOptions o){return (o.relaxedNanpaLinjanRendering()?Constants.RELAXED_DIGITS:Constants.STRICT_DIGITS).get(d);}
    static String encodeDigits(String digits, ParseOptions o){if(digits.isEmpty()||!DIGITS.matcher(digits).matches())return null;StringBuilder b=new StringBuilder();for(int i=0;i<digits.length();i++)b.append(digitSyllable(digits.charAt(i)-'0',o));return b.toString();}
    static String encodeFractionDigits(String digits,ParseOptions o){if(digits.isEmpty()||!DIGITS.matcher(digits).matches())return null;List<String>groups=new ArrayList<>();for(int i=0;i<digits.length();i+=3){String x=encodeDigits(digits.substring(i,Math.min(i+3,digits.length())),o);if(x==null)return null;groups.add(x);}return String.join("NENE",groups);}
    static String encodeIntegerGroups(String value,ParseOptions o){String[]groups=value.split(",",-1);if(groups.length==0)return null;for(String g:groups)if(g.isEmpty()||!DIGITS.matcher(g).matches())return null;int trailing=0;for(int i=groups.length-1;i>=0&&groups[i].equals("000");i--)trailing++;if(trailing>0&&trailing<groups.length){int sig=groups.length-trailing;StringBuilder b=new StringBuilder();for(int i=0;i<sig;i++){if(i>0)b.append("NEKE");String x=encodeDigits(groups[i],o);if(x==null)return null;b.append(x);}b.append("NE");for(int i=0;i<trailing;i++)b.append("KE");return b.toString();}List<String>out=new ArrayList<>();for(String g:groups){String x=encodeDigits(g,o);if(x==null)return null;out.add(x);}return String.join("NEKE",out);}
    static String encodeUnsignedBasic(String value,ParseOptions o){int dot=value.indexOf('.');if(dot>=0){if(value.indexOf('.',dot+1)>=0)return null;String left=value.substring(0,dot),right=value.substring(dot+1);if(right.isEmpty())return null;String a=encodeIntegerGroups(left.isEmpty()?"0":left,o),b=encodeFractionDigits(right,o);return a==null||b==null?null:a+"NONE"+b;}return encodeIntegerGroups(value,o);}
    static Integer magnitudePower(String c){return switch(c.toUpperCase(Locale.ROOT)){case"K"->1;case"M"->2;case"B"->3;case"T"->4;default->null;};}
    static String encodeDecimalCaps(Object value,ParseOptions o){
        if(value==null)return null;
        String raw=value.toString().trim();
        if(raw.isEmpty()||raw.matches(".*\\s.*"))return null;
        String body=raw,prefix="";
        if(body.startsWith("+")){prefix="NS";body=body.substring(1);if(body.startsWith("+")||body.isEmpty())return null;}
        else if(body.startsWith("-")){prefix="NO";while(body.startsWith("-"))body=body.substring(1);if(body.isEmpty())return null;}

        if(!body.isEmpty()){
            Integer power=magnitudePower(body.substring(body.length()-1));
            if(power!=null){String base=body.substring(0,body.length()-1);if(base.isEmpty())return null;String e=encodeUnsignedBasic(base,o);return e==null?null:"NE"+prefix+e+"NE"+repeat("KE",power)+"N";}
        }
        if(body.endsWith("%")){String e=encodeUnsignedBasic(body.substring(0,body.length()-1),o);return e==null?null:"NE"+prefix+e+"OKN";}

        // Scientific notation must be recognized before mixed-fraction '+'.
        int sci=-1;
        for(int i=0;i<body.length();i++)if(body.charAt(i)=='e'||body.charAt(i)=='E'){if(sci>=0)return null;sci=i;}
        if(sci>=0){
            String mantissa=body.substring(0,sci),exp=body.substring(sci+1);if(exp.isEmpty())return null;
            String ep="";if(exp.startsWith("-")){ep="NO";exp=exp.substring(1);}else if(exp.startsWith("+"))exp=exp.substring(1);
            if(exp.isEmpty())return null;String a=encodeUnsignedBasic(mantissa,o),b=encodeDigits(exp,o);return a==null||b==null?null:"NE"+prefix+a+"NEKO"+ep+b+"N";
        }

        int plus=body.indexOf('+');
        if(plus>=0){
            if(body.indexOf('+',plus+1)>=0)return null;
            String whole=body.substring(0,plus),fraction=body.substring(plus+1);int slash=fraction.indexOf('/');
            if(whole.isEmpty()||slash<=0||fraction.indexOf('/',slash+1)>=0)return null;
            String a=encodeUnsignedBasic(whole,o),b=encodeUnsignedBasic(fraction.substring(0,slash),o),c=encodeUnsignedBasic(fraction.substring(slash+1),o);
            String marker="long".equals(o.mixedStyle())?"NONONO":"NOKO";
            return a==null||b==null||c==null?null:"NE"+prefix+a+marker+b+"NONO"+c+"N";
        }

        int slash=body.indexOf('/');
        if(slash>=0){if(body.indexOf('/',slash+1)>=0)return null;String a=encodeUnsignedBasic(body.substring(0,slash),o),b=encodeUnsignedBasic(body.substring(slash+1),o);return a==null||b==null?null:"NE"+prefix+a+"NONO"+b+"N";}
        String e=encodeUnsignedBasic(body,o);return e==null?null:"NE"+prefix+e+"N";
    }
}

