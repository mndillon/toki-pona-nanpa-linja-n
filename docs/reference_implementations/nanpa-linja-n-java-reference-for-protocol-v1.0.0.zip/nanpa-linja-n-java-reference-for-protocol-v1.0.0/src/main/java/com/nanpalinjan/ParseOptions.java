package com.nanpalinjan;

import java.util.Map;

/**
 * Numeric Core options plus the document-renderer parser switches used by the
 * Full Renderer Profile.  The original 11-argument constructor is retained so
 * Protocol-v1.0.0 callers remain source compatible.
 */
public record ParseOptions(
        boolean enableBinaryParsing,
        boolean enableBinaryRendering,
        boolean enableHexParsing,
        NumericMode mode,
        NumericMode numericMode,
        boolean nanpaColonParsing,
        boolean nanpaColonRendering,
        boolean relaxedNanpaLinjanParsing,
        boolean relaxedNanpaLinjanRendering,
        boolean abbreviateNumericCartouches,
        boolean preserveNumericCartoucheBreaksInAbbreviation,
        DecimalStartGlyph numericCartoucheStartGlyph,
        String rendererMode,
        String mixedStyle,
        boolean breakLinesAtFullStops,
        boolean showUnknownText,
        boolean autoCartoucheStandaloneProperNames,
        boolean interpretDoubleQuotesAsTeTo,
        boolean cartoucheCommaTallyMarks,
        String cartoucheTallyMode,
        Double manualTallySmallFontLiftPx,
        Double manualTallySmallFontMaxPx,
        boolean nasinNanpaPona) {

    public enum NumericMode { uniform, traditional }
    public enum DecimalStartGlyph { nanpa, tenpo, suno, toki }
    public enum SemanticKind { time, date }

    public ParseOptions() {
        this(true, true, true, NumericMode.uniform, NumericMode.uniform,
                true, true, true, true, false, false, null,
                "sitelen-pona-ascii-extended", "short", false, false, true,
                false, true, null, null, null, false);
    }

    /** Compatibility constructor retained for the frozen Core-v1 API. */
    public ParseOptions(boolean enableBinaryParsing, boolean enableHexParsing,
                        NumericMode mode, NumericMode numericMode,
                        boolean nanpaColonParsing, boolean nanpaColonRendering,
                        boolean relaxedNanpaLinjanParsing, boolean relaxedNanpaLinjanRendering,
                        boolean abbreviateNumericCartouches,
                        boolean preserveNumericCartoucheBreaksInAbbreviation,
                        DecimalStartGlyph numericCartoucheStartGlyph) {
        this(enableBinaryParsing, enableBinaryParsing, enableHexParsing, mode, numericMode,
                nanpaColonParsing, nanpaColonRendering,
                relaxedNanpaLinjanParsing, relaxedNanpaLinjanRendering,
                abbreviateNumericCartouches, preserveNumericCartoucheBreaksInAbbreviation,
                numericCartoucheStartGlyph,
                "sitelen-pona-ascii-extended", "short", false, false, true,
                false, true, null, null, null, false);
    }

    /** Compatibility constructor for the pre-enableBinaryRendering full option surface. */
    public ParseOptions(boolean enableBinaryParsing, boolean enableHexParsing,
                        NumericMode mode, NumericMode numericMode,
                        boolean nanpaColonParsing, boolean nanpaColonRendering,
                        boolean relaxedNanpaLinjanParsing, boolean relaxedNanpaLinjanRendering,
                        boolean abbreviateNumericCartouches,
                        boolean preserveNumericCartoucheBreaksInAbbreviation,
                        DecimalStartGlyph numericCartoucheStartGlyph,
                        String rendererMode, String mixedStyle,
                        boolean breakLinesAtFullStops, boolean showUnknownText,
                        boolean autoCartoucheStandaloneProperNames,
                        boolean interpretDoubleQuotesAsTeTo,
                        boolean cartoucheCommaTallyMarks, String cartoucheTallyMode,
                        Double manualTallySmallFontLiftPx, Double manualTallySmallFontMaxPx,
                        boolean nasinNanpaPona) {
        this(enableBinaryParsing, enableBinaryParsing, enableHexParsing, mode, numericMode,
                nanpaColonParsing, nanpaColonRendering, relaxedNanpaLinjanParsing,
                relaxedNanpaLinjanRendering, abbreviateNumericCartouches,
                preserveNumericCartoucheBreaksInAbbreviation, numericCartoucheStartGlyph,
                rendererMode, mixedStyle, breakLinesAtFullStops, showUnknownText,
                autoCartoucheStandaloneProperNames, interpretDoubleQuotesAsTeTo,
                cartoucheCommaTallyMarks, cartoucheTallyMode, manualTallySmallFontLiftPx,
                manualTallySmallFontMaxPx, nasinNanpaPona);
    }

    public ParseOptions {
        mode = mode == null ? NumericMode.uniform : mode;
        numericMode = numericMode == null ? mode : numericMode;
        rendererMode = normalizeRendererMode(rendererMode);
        mixedStyle = "long".equalsIgnoreCase(mixedStyle) ? "long" : "short";
        if (cartoucheTallyMode != null) {
            String t=cartoucheTallyMode.trim().toLowerCase();
            cartoucheTallyMode = switch(t){ case "manual","comma","ucsur" -> t; default -> null; };
        }
        if (manualTallySmallFontLiftPx != null && (!Double.isFinite(manualTallySmallFontLiftPx) || manualTallySmallFontLiftPx < 0)) manualTallySmallFontLiftPx=null;
        if (manualTallySmallFontMaxPx != null && (!Double.isFinite(manualTallySmallFontMaxPx) || manualTallySmallFontMaxPx <= 0)) manualTallySmallFontMaxPx=null;
    }

    public static ParseOptions fromMap(Map<String, ?> m) {
        if (m == null) return new ParseOptions();
        Object modeValue=m.get("mode");
        NumericMode mode = modeOf(modeValue, NumericMode.uniform);
        NumericMode numericMode = modeOf(m.get("numericMode"), mode);
        String rendererMode = rendererModeOf(modeValue, str(m,"rendererMode","sitelen-pona-ascii-extended"));
        String tallyMode = nullableStr(first(m,"cartoucheTallyMode","tallyMode","ordinaryCartoucheTallyMode"));
        Object commaValue=first(m,"cartoucheCommaTallyMarks","commaTallyMarks","enableCartoucheCommaTallies");
        return new ParseOptions(
                bool(m, "enableBinaryParsing", true),
                bool(m, "enableBinaryRendering", true),
                bool(m, "enableHexParsing", true),
                mode,
                numericMode,
                bool(m, "nanpaColonParsing", true),
                bool(m, "nanpaColonRendering", true),
                bool(m, "relaxedNanpaLinjanParsing", true),
                bool(m, "relaxedNanpaLinjanRendering", true),
                truthy(first(m,"abbreviateNumericCartouches","numericCartoucheAbbreviation","abbreviatedNumericCartouches"),false),
                truthy(first(m,"preserveNumericCartoucheBreaksInAbbreviation","abbreviatedNumericCartoucheBreakAsEn"),false),
                glyphOf(m.get("numericCartoucheStartGlyph")),
                rendererMode,
                str(m,"mixedStyle","short"),
                bool(m,"breakLinesAtFullStops",false),
                bool(m,"showUnknownText",false),
                bool(m,"autoCartoucheStandaloneProperNames",true),
                bool(m,"interpretDoubleQuotesAsTeTo",false),
                commaValue==null ? true : truthy(commaValue,true),
                tallyMode,
                number(first(m,"manualTallySmallFontLiftPx","tallySmallFontLiftPx")),
                number(first(m,"manualTallySmallFontMaxPx","tallySmallFontMaxPx")),
                bool(m,"nasinNanpaPona",false));
    }

    private static Object first(Map<String,?>m,String...keys){for(String k:keys)if(m.containsKey(k))return m.get(k);return null;}
    private static boolean truthy(Object v,boolean d){return v instanceof Boolean b?b:v==null?d:Boolean.parseBoolean(String.valueOf(v));}
    private static boolean bool(Map<String, ?> m, String k, boolean d) { return truthy(m.get(k),d); }
    private static String str(Map<String,?>m,String k,String d){Object v=m.get(k);return v==null?d:String.valueOf(v);}
    private static String nullableStr(Object v){return v==null?null:String.valueOf(v);}
    private static Double number(Object v){if(v instanceof Number n)return n.doubleValue();if(v==null)return null;try{return Double.valueOf(String.valueOf(v));}catch(Exception e){return null;}}
    private static NumericMode modeOf(Object v, NumericMode d) {
        if (v!=null && "traditional".equalsIgnoreCase(String.valueOf(v))) return NumericMode.traditional;
        if (v!=null && "uniform".equalsIgnoreCase(String.valueOf(v))) return NumericMode.uniform;
        return d;
    }
    private static String rendererModeOf(Object modeValue,String d){
        if(modeValue==null)return normalizeRendererMode(d);
        String s=String.valueOf(modeValue);
        if("uniform".equalsIgnoreCase(s)||"traditional".equalsIgnoreCase(s))return normalizeRendererMode(d);
        return normalizeRendererMode(s);
    }
    private static String normalizeRendererMode(String s){
        String v=s==null?"":s.trim().toLowerCase();
        return switch(v){
            case "standard-sitelen-pona-ascii-core","sitelen-pona-ascii-extended","sitelen-seli-kiwen" -> v;
            default -> "sitelen-pona-ascii-extended";
        };
    }
    private static DecimalStartGlyph glyphOf(Object v) {
        if (v == null) return null;
        try { return DecimalStartGlyph.valueOf(v.toString().toLowerCase()); }
        catch (IllegalArgumentException e) { return null; }
    }
    public NumericMode effectiveNumericMode() {
        return mode == NumericMode.traditional || numericMode == NumericMode.traditional ? NumericMode.traditional : NumericMode.uniform;
    }
    public String numericModeName() { return effectiveNumericMode().name(); }
    public ParseOptions normalized() {
        if (effectiveNumericMode()==NumericMode.traditional && (mode!=NumericMode.traditional || numericMode!=NumericMode.traditional))
            return new ParseOptions(enableBinaryParsing,enableBinaryRendering,enableHexParsing,NumericMode.traditional,NumericMode.traditional,nanpaColonParsing,nanpaColonRendering,relaxedNanpaLinjanParsing,relaxedNanpaLinjanRendering,abbreviateNumericCartouches,preserveNumericCartoucheBreaksInAbbreviation,numericCartoucheStartGlyph,rendererMode,mixedStyle,breakLinesAtFullStops,showUnknownText,autoCartoucheStandaloneProperNames,interpretDoubleQuotesAsTeTo,cartoucheCommaTallyMarks,cartoucheTallyMode,manualTallySmallFontLiftPx,manualTallySmallFontMaxPx,nasinNanpaPona);
        return this;
    }

    public ParseOptions withRendererMode(String v){return copy(v,mixedStyle,breakLinesAtFullStops,showUnknownText,autoCartoucheStandaloneProperNames,interpretDoubleQuotesAsTeTo,cartoucheCommaTallyMarks,cartoucheTallyMode,manualTallySmallFontLiftPx,manualTallySmallFontMaxPx,nasinNanpaPona);}
    public ParseOptions withBreakLinesAtFullStops(boolean v){return copy(rendererMode,mixedStyle,v,showUnknownText,autoCartoucheStandaloneProperNames,interpretDoubleQuotesAsTeTo,cartoucheCommaTallyMarks,cartoucheTallyMode,manualTallySmallFontLiftPx,manualTallySmallFontMaxPx,nasinNanpaPona);}
    public ParseOptions withShowUnknownText(boolean v){return copy(rendererMode,mixedStyle,breakLinesAtFullStops,v,autoCartoucheStandaloneProperNames,interpretDoubleQuotesAsTeTo,cartoucheCommaTallyMarks,cartoucheTallyMode,manualTallySmallFontLiftPx,manualTallySmallFontMaxPx,nasinNanpaPona);}
    public ParseOptions withInterpretDoubleQuotesAsTeTo(boolean v){return copy(rendererMode,mixedStyle,breakLinesAtFullStops,showUnknownText,autoCartoucheStandaloneProperNames,v,cartoucheCommaTallyMarks,cartoucheTallyMode,manualTallySmallFontLiftPx,manualTallySmallFontMaxPx,nasinNanpaPona);}
    public ParseOptions withCartoucheCommaTallyMarks(boolean v){return copy(rendererMode,mixedStyle,breakLinesAtFullStops,showUnknownText,autoCartoucheStandaloneProperNames,interpretDoubleQuotesAsTeTo,v,cartoucheTallyMode,manualTallySmallFontLiftPx,manualTallySmallFontMaxPx,nasinNanpaPona);}
    public ParseOptions withCartoucheTallyMode(String v){return copy(rendererMode,mixedStyle,breakLinesAtFullStops,showUnknownText,autoCartoucheStandaloneProperNames,interpretDoubleQuotesAsTeTo,cartoucheCommaTallyMarks,v,manualTallySmallFontLiftPx,manualTallySmallFontMaxPx,nasinNanpaPona);}
    public ParseOptions withEnableBinaryParsing(boolean v){return new ParseOptions(v,enableBinaryRendering,enableHexParsing,mode,numericMode,nanpaColonParsing,nanpaColonRendering,relaxedNanpaLinjanParsing,relaxedNanpaLinjanRendering,abbreviateNumericCartouches,preserveNumericCartoucheBreaksInAbbreviation,numericCartoucheStartGlyph,rendererMode,mixedStyle,breakLinesAtFullStops,showUnknownText,autoCartoucheStandaloneProperNames,interpretDoubleQuotesAsTeTo,cartoucheCommaTallyMarks,cartoucheTallyMode,manualTallySmallFontLiftPx,manualTallySmallFontMaxPx,nasinNanpaPona);}
    public ParseOptions withEnableBinaryRendering(boolean v){return new ParseOptions(enableBinaryParsing,v,enableHexParsing,mode,numericMode,nanpaColonParsing,nanpaColonRendering,relaxedNanpaLinjanParsing,relaxedNanpaLinjanRendering,abbreviateNumericCartouches,preserveNumericCartoucheBreaksInAbbreviation,numericCartoucheStartGlyph,rendererMode,mixedStyle,breakLinesAtFullStops,showUnknownText,autoCartoucheStandaloneProperNames,interpretDoubleQuotesAsTeTo,cartoucheCommaTallyMarks,cartoucheTallyMode,manualTallySmallFontLiftPx,manualTallySmallFontMaxPx,nasinNanpaPona);}
    public Map<String,Object> toMap(){
        Map<String,Object> m=new java.util.LinkedHashMap<>();
        m.put("enableBinaryParsing",enableBinaryParsing); m.put("enableBinaryRendering",enableBinaryRendering); m.put("enableHexParsing",enableHexParsing);
        m.put("mode",mode.name()); m.put("numericMode",numericMode.name());
        m.put("nanpaColonParsing",nanpaColonParsing); m.put("nanpaColonRendering",nanpaColonRendering);
        m.put("relaxedNanpaLinjanParsing",relaxedNanpaLinjanParsing); m.put("relaxedNanpaLinjanRendering",relaxedNanpaLinjanRendering);
        m.put("abbreviateNumericCartouches",abbreviateNumericCartouches); m.put("preserveNumericCartoucheBreaksInAbbreviation",preserveNumericCartoucheBreaksInAbbreviation);
        if(numericCartoucheStartGlyph!=null)m.put("numericCartoucheStartGlyph",numericCartoucheStartGlyph.name());
        m.put("rendererMode",rendererMode); m.put("mixedStyle",mixedStyle); m.put("breakLinesAtFullStops",breakLinesAtFullStops); m.put("showUnknownText",showUnknownText);
        m.put("autoCartoucheStandaloneProperNames",autoCartoucheStandaloneProperNames); m.put("interpretDoubleQuotesAsTeTo",interpretDoubleQuotesAsTeTo);
        m.put("cartoucheCommaTallyMarks",cartoucheCommaTallyMarks); if(cartoucheTallyMode!=null)m.put("cartoucheTallyMode",cartoucheTallyMode);
        if(manualTallySmallFontLiftPx!=null)m.put("manualTallySmallFontLiftPx",manualTallySmallFontLiftPx); if(manualTallySmallFontMaxPx!=null)m.put("manualTallySmallFontMaxPx",manualTallySmallFontMaxPx);
        m.put("nasinNanpaPona",nasinNanpaPona);
        return java.util.Collections.unmodifiableMap(m);
    }

    public ParseOptions withAbbreviateNumericCartouches(boolean v){return new ParseOptions(enableBinaryParsing,enableBinaryRendering,enableHexParsing,mode,numericMode,nanpaColonParsing,nanpaColonRendering,relaxedNanpaLinjanParsing,relaxedNanpaLinjanRendering,v,preserveNumericCartoucheBreaksInAbbreviation,numericCartoucheStartGlyph,rendererMode,mixedStyle,breakLinesAtFullStops,showUnknownText,autoCartoucheStandaloneProperNames,interpretDoubleQuotesAsTeTo,cartoucheCommaTallyMarks,cartoucheTallyMode,manualTallySmallFontLiftPx,manualTallySmallFontMaxPx,nasinNanpaPona);}
    public ParseOptions withPreserveNumericCartoucheBreaksInAbbreviation(boolean v){return new ParseOptions(enableBinaryParsing,enableBinaryRendering,enableHexParsing,mode,numericMode,nanpaColonParsing,nanpaColonRendering,relaxedNanpaLinjanParsing,relaxedNanpaLinjanRendering,abbreviateNumericCartouches,v,numericCartoucheStartGlyph,rendererMode,mixedStyle,breakLinesAtFullStops,showUnknownText,autoCartoucheStandaloneProperNames,interpretDoubleQuotesAsTeTo,cartoucheCommaTallyMarks,cartoucheTallyMode,manualTallySmallFontLiftPx,manualTallySmallFontMaxPx,nasinNanpaPona);}
    public ParseOptions withNasinNanpaPona(boolean v){return new ParseOptions(enableBinaryParsing,enableBinaryRendering,enableHexParsing,mode,numericMode,nanpaColonParsing,nanpaColonRendering,relaxedNanpaLinjanParsing,relaxedNanpaLinjanRendering,abbreviateNumericCartouches,preserveNumericCartoucheBreaksInAbbreviation,numericCartoucheStartGlyph,rendererMode,mixedStyle,breakLinesAtFullStops,showUnknownText,autoCartoucheStandaloneProperNames,interpretDoubleQuotesAsTeTo,cartoucheCommaTallyMarks,cartoucheTallyMode,manualTallySmallFontLiftPx,manualTallySmallFontMaxPx,v);}

    private ParseOptions copy(String rm,String ms,boolean bl,boolean su,boolean ap,boolean iq,boolean ct,String tm,Double lift,Double max,boolean nnp){return new ParseOptions(enableBinaryParsing,enableBinaryRendering,enableHexParsing,mode,numericMode,nanpaColonParsing,nanpaColonRendering,relaxedNanpaLinjanParsing,relaxedNanpaLinjanRendering,abbreviateNumericCartouches,preserveNumericCartoucheBreaksInAbbreviation,numericCartoucheStartGlyph,rm,ms,bl,su,ap,iq,ct,tm,lift,max,nnp);}
}
