package com.nanpalinjan;
/** Idiomatic Java facade over the frozen Core-v1 operations. */
public final class NanpaParser {
 public ParseResult parseNumber(Object input){return NanpaApi.parseNumber(input);} public ParseResult parseNumber(Object input,ParseOptions o){return NanpaApi.parseNumber(input,o);}
 public String encodeDecimal(Object value){return NanpaApi.encodeDecimal(value);} public String encodeDecimal(Object value,ParseOptions o){return NanpaApi.encodeDecimal(value,o);}
}
