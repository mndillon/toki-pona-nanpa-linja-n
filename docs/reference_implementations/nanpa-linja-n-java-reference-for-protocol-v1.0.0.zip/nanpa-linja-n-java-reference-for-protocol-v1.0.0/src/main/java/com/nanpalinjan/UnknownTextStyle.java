package com.nanpalinjan;
import java.util.*;
public record UnknownTextStyle(String style,String color,float lineWidthPx,float paddingPx,List<Float> dash){
 public UnknownTextStyle(){this("outline-box","#000000",1.5f,2f,List.of());}
 public UnknownTextStyle{style=style==null||style.isBlank()?"outline-box":style;color=PaintOptions.normalizeColor(color,"#000000");lineWidthPx=Float.isFinite(lineWidthPx)&&lineWidthPx>=0?lineWidthPx:1.5f;paddingPx=Float.isFinite(paddingPx)&&paddingPx>=0?paddingPx:2f;dash=dash==null?List.of():List.copyOf(dash);}
 @SuppressWarnings("unchecked") public static UnknownTextStyle fromMap(Object raw){if(!(raw instanceof Map<?,?> mm))return new UnknownTextStyle();Map<String,Object>m=(Map<String,Object>)mm;List<Float>d=new ArrayList<>();Object dr=m.get("dash");if(dr instanceof List<?> l)for(Object x:l)if(x instanceof Number n)d.add(n.floatValue());return new UnknownTextStyle(String.valueOf(m.getOrDefault("style","outline-box")),String.valueOf(m.getOrDefault("color","#000000")),num(m.get("lineWidthPx"),1.5f),num(m.get("paddingPx"),2f),d);}
 private static float num(Object v,float d){return v instanceof Number n?n.floatValue():d;}
}
