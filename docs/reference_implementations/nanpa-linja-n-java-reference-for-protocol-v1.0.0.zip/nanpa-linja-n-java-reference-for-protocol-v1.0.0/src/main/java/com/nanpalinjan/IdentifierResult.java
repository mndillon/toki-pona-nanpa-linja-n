package com.nanpalinjan;
import java.util.*;
public record IdentifierResult(String input,List<Integer> innerCodepoints,List<Integer> codepoints,List<String> words,String numericMode){
 public Map<String,Object> toMap(){Map<String,Object>m=new LinkedHashMap<>();m.put("input",input);m.put("innerCodepoints",innerCodepoints);m.put("codepoints",codepoints);m.put("words",words);m.put("numericMode",numericMode);return m;}
}
