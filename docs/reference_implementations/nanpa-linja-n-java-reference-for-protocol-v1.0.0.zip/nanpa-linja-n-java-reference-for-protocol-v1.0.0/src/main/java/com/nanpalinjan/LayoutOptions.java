package com.nanpalinjan;

import java.util.Map;

/** Full-renderer line/layout controls corresponding to the canonical JavaScript renderer. */
public record LayoutOptions(
        String align,
        String spacingPreset,
        Double glyphGapScale,
        Double glyphGapMinPx,
        Double glyphGapMaxPx,
        Double cartoucheLeadGapScale,
        Double cartouchePadScale,
        Double cartouchePadMinPx,
        Double lineGapPx,
        boolean forceLineGapPx) {
    public LayoutOptions(){this("left","default",null,null,null,null,null,null,null,false);}
    public LayoutOptions{
        String a=align==null?"left":align.trim().toLowerCase();
        align=switch(a){case "center","right"->a;default->"left";};
        String p=spacingPreset==null?"default":spacingPreset.trim().toLowerCase();
        spacingPreset=switch(p){case "compact","comfortable"->p;default->"default";};
        glyphGapScale=finite(glyphGapScale);glyphGapMinPx=finite(glyphGapMinPx);glyphGapMaxPx=finite(glyphGapMaxPx);
        cartoucheLeadGapScale=finite(cartoucheLeadGapScale);cartouchePadScale=finite(cartouchePadScale);cartouchePadMinPx=finite(cartouchePadMinPx);lineGapPx=finite(lineGapPx);
    }
    private static Double finite(Double v){return v!=null&&Double.isFinite(v)?v:null;}
    public static LayoutOptions fromMap(Map<String,?>m){
        if(m==null)return new LayoutOptions();
        return new LayoutOptions(str(m,"align","left"),str(m,"spacingPreset","default"),num(m,"glyphGapScale"),num(m,"glyphGapMinPx"),num(m,"glyphGapMaxPx"),num(m,"cartoucheLeadGapScale"),num(m,"cartouchePadScale"),num(m,"cartouchePadMinPx"),num(m,"lineGapPx"),bool(m,"forceLineGapPx",false));
    }
    private static String str(Map<String,?>m,String k,String d){Object v=m.get(k);return v==null?d:String.valueOf(v);}
    private static Double num(Map<String,?>m,String k){Object v=m.get(k);if(v instanceof Number n)return n.doubleValue();if(v==null)return null;try{return Double.valueOf(String.valueOf(v));}catch(Exception e){return null;}}
    private static boolean bool(Map<String,?>m,String k,boolean d){Object v=m.get(k);return v instanceof Boolean b?b:v==null?d:Boolean.parseBoolean(String.valueOf(v));}

    double glyphGap(float fontPx){
        if(glyphGapScale!=null){double v=fontPx*glyphGapScale; if(glyphGapMinPx!=null)v=Math.max(v,glyphGapMinPx);if(glyphGapMaxPx!=null)v=Math.min(v,glyphGapMaxPx);return Math.max(0,v);}
        return switch(spacingPreset){case "compact"->Math.max(2,fontPx*0.08);case "comfortable"->Math.max(6,fontPx*0.22);default->Math.max(4,fontPx*0.14);};
    }
    double cartoucheLeadGap(float fontPx){return cartoucheLeadGapScale!=null?Math.max(0,fontPx*cartoucheLeadGapScale):glyphGap(fontPx);}
    double cartouchePad(float fontPx){double v=cartouchePadScale!=null?fontPx*cartouchePadScale:fontPx*0.12;if(cartouchePadMinPx!=null)v=Math.max(v,cartouchePadMinPx);return Math.max(0,v);}
    double lineGap(float fontPx){if(lineGapPx!=null&&(forceLineGapPx||lineGapPx>=0))return Math.max(0,lineGapPx);return switch(spacingPreset){case "compact"->Math.max(8,fontPx*0.20);case "comfortable"->Math.max(18,fontPx*0.40);default->18;};}
}
