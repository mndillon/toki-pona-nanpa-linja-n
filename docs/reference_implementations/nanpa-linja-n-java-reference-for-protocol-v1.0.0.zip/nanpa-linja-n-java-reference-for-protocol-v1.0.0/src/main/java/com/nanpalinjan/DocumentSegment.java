package com.nanpalinjan;

import java.util.*;

public record DocumentSegment(
        String kind,
        String value,
        ImageDescriptor image,
        String openQuote,
        String closeQuote,
        int sourceStart,
        int sourceEnd,
        List<Integer> codepoints,
        List<NumericStructure> numericStructures) {
    public DocumentSegment {
        codepoints = codepoints == null ? List.of() : List.copyOf(codepoints);
        numericStructures = numericStructures == null ? List.of() : List.copyOf(numericStructures);
    }
    /** Compatibility constructor retained for the previous seven-field AST segment surface. */
    public DocumentSegment(String kind,String value,ImageDescriptor image,String openQuote,String closeQuote,int sourceStart,int sourceEnd){
        this(kind,value,image,openQuote,closeQuote,sourceStart,sourceEnd,List.of(),List.of());
    }
    public static DocumentSegment text(String v,int s,int e){return new DocumentSegment("text",v,null,null,null,s,e,List.of(),List.of());}
    public static DocumentSegment bracket(String v,int s,int e){return new DocumentSegment("bracket",v,null,null,null,s,e,List.of(),List.of());}
    public static DocumentSegment quote(String v,String o,String c,int s,int e){return new DocumentSegment("quote",v,null,o,c,s,e,List.of(),List.of());}
    public static DocumentSegment image(ImageDescriptor i,int s,int e){return new DocumentSegment("image",null,i,null,null,s,e,List.of(),List.of());}
    public static DocumentSegment rawUcsur(List<Integer> cps,int s,int e){return new DocumentSegment("rawUcsur",null,null,null,null,s,e,cps,List.of());}
    public DocumentSegment withNumericStructures(List<NumericStructure> structures){return new DocumentSegment(kind,value,image,openQuote,closeQuote,sourceStart,sourceEnd,codepoints,structures);}
}
