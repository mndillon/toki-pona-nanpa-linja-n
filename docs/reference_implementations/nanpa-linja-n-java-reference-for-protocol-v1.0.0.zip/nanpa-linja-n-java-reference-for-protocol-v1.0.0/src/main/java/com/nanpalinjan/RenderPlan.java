package com.nanpalinjan;

import java.util.*;

public record RenderPlan(
        String input,
        String fontKey,
        FontPairInfo preset,
        boolean abbreviated,
        int width,
        int height,
        List<String> openTypeFeatures,
        List<RenderRun> runs,
        ParseResult parsed,
        List<String> diagnostics,
        DocumentAst ast,
        List<RenderLinePlan> lines) {
    public RenderPlan {
        openTypeFeatures = openTypeFeatures == null ? List.of() : List.copyOf(openTypeFeatures);
        runs = runs == null ? List.of() : List.copyOf(runs);
        diagnostics = diagnostics == null ? List.of() : List.copyOf(diagnostics);
        lines=lines==null?List.of():List.copyOf(lines);
    }
    /** Compatibility constructor retained for Protocol/Core and old production-rendering callers. */
    public RenderPlan(String input,String fontKey,FontPairInfo preset,boolean abbreviated,int width,int height,List<String>openTypeFeatures,List<RenderRun>runs,ParseResult parsed,List<String>diagnostics){
        this(input,fontKey,preset,abbreviated,width,height,openTypeFeatures,runs,parsed,diagnostics,null,List.of());
    }
    public long cartoucheCount() { return runs.stream().filter(r -> r.numericCartouche() || "cartouche".equals(r.fontRole())).count(); }
    public int lineCount(){return lines.isEmpty()?(runs.isEmpty()?0:1):lines.size();}
}
