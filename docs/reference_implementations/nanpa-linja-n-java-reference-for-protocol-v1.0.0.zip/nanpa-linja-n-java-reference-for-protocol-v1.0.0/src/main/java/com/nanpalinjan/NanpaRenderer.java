package com.nanpalinjan;
import java.util.*;
public final class NanpaRenderer {
 static List<Integer> wordsToCodepoints(List<String>w){List<Integer>o=new ArrayList<>();for(String x:w){Integer cp=Constants.ALL_WORD_CODEPOINTS.get(x);if(cp==null)throw new IllegalStateException("No canonical code point for renderer word "+x);o.add(cp);}return o;}
 private static boolean has(List<String>w,int i,String...v){if(i+v.length>w.size())return false;for(int j=0;j<v.length;j++)if(!w.get(i+j).equals(v[j]))return false;return true;}
 static List<String> abbreviateDecimalWords(List<String>w,boolean preserve){
  if(w==null||w.isEmpty())return List.of();
  Set<String> starts=Set.of("nanpa","nasa","noka","tenpo","suno","toki");
  Set<String> drop=Set.of("nanpa","en","e","nena","open","ala","ike","uta");
  List<String>out=new ArrayList<>();boolean kept=false;
  boolean trad=w.size()>=4&&starts.contains(w.get(0))&&"e".equals(w.get(1))&&"nena".equals(w.get(2))&&"en".equals(w.get(3));
  boolean colon=w.size()>=4&&starts.contains(w.get(0))&&":".equals(w.get(1))&&"nena".equals(w.get(2))&&"en".equals(w.get(3));
  boolean scaffold=w.size()>2&&w.subList(2,w.size()-1).stream().anyMatch(x->"e".equals(x)||drop.contains(x));
  boolean abbrPos=!trad&&!colon&&!scaffold&&w.size()>=3&&starts.contains(w.get(0))&&"en".equals(w.get(1));
  boolean abbrColon=!trad&&!colon&&!scaffold&&w.size()>=4&&starts.contains(w.get(0))&&":".equals(w.get(1))&&"en".equals(w.get(2));
  for(int i=0;i<w.size();i++){
   String x=w.get(i);boolean lastNanpa="nanpa".equals(x)&&i==w.size()-1;
   if(!kept){out.add(x);if(i==0&&starts.contains(x)||"nanpa".equals(x))kept=true;continue;}
   if(lastNanpa){out.add(x);continue;}
   if(trad&&i==1){out.add("en");i=3;continue;}
   if(colon&&i==2){out.add("en");i=3;continue;}
   if(abbrPos&&i==1){out.add("en");continue;}
   if(abbrColon&&i==2){out.add("en");continue;}
   if(preserve&&i+3<w.size()&&"nena".equals(x)&&Set.of("e","en").contains(w.get(i+1))&&"nena".equals(w.get(i+2))&&Set.of("e","en").contains(w.get(i+3))){out.add("e");i+=3;continue;}
   if(drop.contains(x))continue;out.add(x);
  }
  return out;
 }

 public RenderResult render(Object input){return render(input,new ParseOptions());}
 public RenderResult render(Object input,ParseOptions o){ParseResult p=NanpaApi.parseNumber(input,o);if(p==null)return null;List<String>fw=List.copyOf(p.tpWords);List<Integer>fi=List.copyOf(p.innerCodepoints),fc=List.copyOf(p.codepoints);List<String>aw=null;List<Integer>ai=null,ac=null;if(p.abbreviatedWords!=null){aw=List.copyOf(p.abbreviatedWords);ai=List.copyOf(p.abbreviatedUcsurCodepoints!=null?p.abbreviatedUcsurCodepoints:wordsToCodepoints(aw));ac=List.copyOf(NanpaApi.withCartoucheMarkers(ai));}else if(p.caps!=null&&o.nanpaColonRendering()){aw=List.copyOf(abbreviateDecimalWords(fw,o.preserveNumericCartoucheBreaksInAbbreviation()));ai=List.copyOf(wordsToCodepoints(aw));ac=List.copyOf(NanpaApi.withCartoucheMarkers(ai));}boolean use=o.abbreviateNumericCartouches()&&aw!=null;List<String>vw=use?aw:fw;List<Integer>vi=use?ai:fi,vc=use?ac:fc;StringBuilder u=new StringBuilder();for(int cp:vc)u.appendCodePoint(cp);return new RenderResult(p,fw,fi,fc,aw,ai,ac,use,List.copyOf(vw),List.copyOf(vi),List.copyOf(vc),u.toString());}
}
