package com.nanpalinjan;
import java.util.*;
@FunctionalInterface
public interface RenderAdapter {
    /** Map canonical codepoints to native render codepoints. */
    List<Integer> adapt(List<Integer> canonicalCodepoints, FontPairInfo font, float fontPx);
}
