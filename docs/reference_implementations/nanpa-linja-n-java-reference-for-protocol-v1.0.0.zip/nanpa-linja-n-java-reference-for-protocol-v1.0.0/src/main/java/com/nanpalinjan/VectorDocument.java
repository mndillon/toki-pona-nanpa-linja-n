package com.nanpalinjan;
import java.util.*;
/** Vector output plus the semantic render plan used to produce it. */
public record VectorDocument(double width,double height,List<VectorElement> elements,List<String> diagnostics,RenderPlan plan){
 public VectorDocument{elements=elements==null?List.of():List.copyOf(elements);diagnostics=diagnostics==null?List.of():List.copyOf(diagnostics);}
 public VectorDocument(double width,double height,List<VectorElement> elements,List<String> diagnostics){this(width,height,elements,diagnostics,null);}
}
