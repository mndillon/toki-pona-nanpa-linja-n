package com.nanpalinjan;

public record PngRenderResult(
        String kind,
        String input,
        byte[] bytes,
        CanvasRenderResult canvasResult,
        String fontKey,
        FontPairInfo preset,
        RenderOptions config) {
    public PngRenderResult { bytes = bytes.clone(); }
}
