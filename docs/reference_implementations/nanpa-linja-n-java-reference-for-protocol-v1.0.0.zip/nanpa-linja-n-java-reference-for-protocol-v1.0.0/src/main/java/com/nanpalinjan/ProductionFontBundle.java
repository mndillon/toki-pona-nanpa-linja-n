package com.nanpalinjan;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Canonical production font source backed only by resources/fonts.zip. */
final class ProductionFontBundle {
    static final String MANIFEST_ENTRY = "fonts/preloaded-font-pairs.manifest.json";
    static final String CLASSPATH_RESOURCE = "/com/nanpalinjan/fonts.zip";

    private final Map<String, byte[]> entries;
    private final String source;

    private ProductionFontBundle(Map<String, byte[]> entries, String source) {
        this.entries = Collections.unmodifiableMap(entries);
        this.source = source;
    }

    static ProductionFontBundle loadDefault() throws IOException {
        String prop = System.getProperty("nanpa.font.zip");
        if (prop == null || prop.isBlank()) prop = System.getProperty("nanpa.font.dir");
        String env = System.getenv("NANPA_FONT_ZIP");
        if (env == null || env.isBlank()) env = System.getenv("NANPA_FONT_DIR");
        String override = prop != null && !prop.isBlank() ? prop : env;
        if (override != null && !override.isBlank()) return load(Path.of(override));

        try (InputStream in = ProductionFontBundle.class.getResourceAsStream(CLASSPATH_RESOURCE)) {
            if (in != null) return read(in, "classpath:" + CLASSPATH_RESOURCE);
        }
        Path local = Path.of("resources", "fonts.zip").toAbsolutePath().normalize();
        if (Files.isRegularFile(local)) return load(local);
        throw new FileNotFoundException("Production font bundle not found: resources/fonts.zip");
    }

    static ProductionFontBundle load(Path source) throws IOException {
        if (source == null) return loadDefault();
        Path p = source.toAbsolutePath().normalize();
        if (Files.isDirectory(p)) {
            Path direct = p.resolve("fonts.zip");
            Path nested = p.resolve("resources").resolve("fonts.zip");
            if (Files.isRegularFile(direct)) p = direct;
            else if (Files.isRegularFile(nested)) p = nested;
            else throw new FileNotFoundException("Directory does not contain fonts.zip: " + p);
        }
        if (!Files.isRegularFile(p)) throw new FileNotFoundException("Production font bundle not found: " + p);
        try (InputStream in = Files.newInputStream(p)) { return read(in, p.toString()); }
    }

    private static ProductionFontBundle read(InputStream raw, String source) throws IOException {
        LinkedHashMap<String, byte[]> entries = new LinkedHashMap<>();
        try (ZipInputStream zin = new ZipInputStream(new BufferedInputStream(raw))) {
            for (ZipEntry e; (e = zin.getNextEntry()) != null;) {
                if (e.isDirectory()) continue;
                String name = normaliseEntry(e.getName());
                if (!name.startsWith("fonts/")) continue;
                entries.put(name, zin.readAllBytes());
            }
        }
        if (!entries.containsKey(MANIFEST_ENTRY)) {
            throw new FileNotFoundException("Manifest entry not found inside " + source + ": " + MANIFEST_ENTRY);
        }
        return new ProductionFontBundle(entries, source);
    }

    String manifestJson() {
        return new String(entries.get(MANIFEST_ENTRY), StandardCharsets.UTF_8);
    }

    byte[] fontBytes(String filename) throws FileNotFoundException {
        String name = filename == null ? "" : filename.replace('\\', '/').trim();
        while (name.startsWith("./")) name = name.substring(2);
        if (name.startsWith("/")) name = name.substring(1);
        if (!name.startsWith("fonts/")) name = "fonts/" + Path.of(name).getFileName();
        byte[] data = entries.get(normaliseEntry(name));
        if (data == null) throw new FileNotFoundException("Font entry not found in " + source + ": " + name);
        return data;
    }

    boolean containsFont(String filename) {
        try { fontBytes(filename); return true; } catch (IOException e) { return false; }
    }

    String source() { return source; }

    private static String normaliseEntry(String name) {
        String n = name == null ? "" : name.replace('\\', '/');
        while (n.startsWith("./")) n = n.substring(2);
        while (n.startsWith("/")) n = n.substring(1);
        return n;
    }
}
