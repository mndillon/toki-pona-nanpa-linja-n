package com.nanpalinjan;
import java.util.*;
public record CapsCodepointsResult(List<Integer> innerCodepoints,List<Integer> codepoints,List<String> words,String numericMode,boolean isTimeLike){
 public Map<String,Object> toMap(){Map<String,Object>m=new LinkedHashMap<>();m.put("innerCodepoints",innerCodepoints);m.put("codepoints",codepoints);m.put("words",words);m.put("numericMode",numericMode);m.put("isTimeLike",isTimeLike);return m;}
}
