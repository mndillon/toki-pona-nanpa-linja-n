package com.nanpalinjan;

import java.util.*;

/** Java port of the ordinary-cartouche branches of the canonical JavaScript font render adapters. */
final class FontRenderAdapters {
    record Span(int start,int end){}
    record Adapted(String text,List<Span> canonicalSpans){}
    private FontRenderAdapters(){}

    static Adapted adaptOrdinaryCartouche(FontPairInfo pair,List<Integer> inner){
        List<Integer> full=new ArrayList<>();full.add(Constants.CARTOUCHE_START);full.addAll(inner);full.add(Constants.CARTOUCHE_END);
        String id=pair.renderAdapterId()==null?"identity":pair.renderAdapterId();
        return switch(id){
            case "linja-pona-legacy-v1" -> adaptLegacy(full,"linja-pona",pair.renderAdapterSettings());
            case "linja-sike-legacy-v1" -> adaptLegacy(full,"linja-sike",pair.renderAdapterSettings());
            case "nasin-sitelen-pu-mono-v1" -> adaptPuMono(full,pair.renderAdapterSettings());
            case "linja-lipamanka-v1" -> adaptLipamanka(full,pair.renderAdapterSettings());
            default -> identity(full);
        };
    }



    /** Canonical production-font adaptation for ordinary word/glyph runs. */
    static List<Integer> adaptFullWordRun(FontPairInfo pair,List<Integer> cps){
        String id=pair.renderAdapterId()==null?"identity":pair.renderAdapterId();
        return switch(id){
            case "linja-pona-legacy-v1" -> adaptLegacyFullWordRun(pair,cps,"linja-pona");
            case "linja-sike-legacy-v1" -> adaptLegacyFullWordRun(pair,cps,"linja-sike");
            case "nasin-sitelen-pu-mono-v1" -> adaptPuMonoFullWordRun(pair,cps);
            case "linja-lipamanka-v1" -> adaptLipamankaFullWordRun(pair,cps);
            default -> List.copyOf(cps);
        };
    }

    private record Cell(List<Integer> cps,boolean controlOnly){}
    private static boolean controlOnly(int cp){return cp==0xF1992||cp==0xF1993||cp==0xF1994||cp==0xF1997||cp==0xF1998||cp==0xF1999||cp==0xF199A||cp==0xF199B;}
    private static boolean joiner(int cp){return cp==0x200D||cp==0xF1995||cp==0xF1996;}
    private static List<Cell> splitCells(List<Integer>cps,int start,int end){
        List<Cell>out=new ArrayList<>();
        for(int i=start;i<end;){int cp=cps.get(i);if(controlOnly(cp)){out.add(new Cell(List.of(cp),true));i++;continue;}List<Integer>cell=new ArrayList<>();cell.add(cp);i++;while(i+1<end&&joiner(cps.get(i))){cell.add(cps.get(i));cell.add(cps.get(i+1));i+=2;}out.add(new Cell(List.copyOf(cell),false));}
        return out;
    }
    private static String fullLegacyWord(int cp,String kind,Map<String,Object> settings){
        if((cp==0x300C||cp==0x300D)&&"synthetic".equalsIgnoreCase(String.valueOf(settings.get("cornerBracketMode"))))return new String(Character.toChars(cp));
        String w=legacyWord(cp,kind,settings);return w==null?"\uFFFD":w;
    }
    private static String fullLegacyWord(int cp,String kind,FontPairInfo pair){return fullLegacyWord(cp,kind,pair.renderAdapterSettings());}
    private static void appendLegacyCell(StringBuilder b,Cell cell,String kind,FontPairInfo pair){
        if(cell.controlOnly()||cell.cps().isEmpty())return;
        List<Integer>a=cell.cps();
        for(int i=0;i<a.size();){b.append(fullLegacyWord(a.get(i),kind,pair));i++;if(i<a.size()){int j=a.get(i);String op="-";if("linja-lipamanka".equals(kind)){if(j==0xF1995)op="+";else if(j==0xF1996)op="-";else {Object x=pair.renderAdapterSettings().get("genericCompoundOperator");if(x!=null&&!String.valueOf(x).isEmpty())op=String.valueOf(x).substring(0,1);}}b.append(op);i++;}}
    }
    private static int[] currentLong(List<Integer>cps){int start=-1;for(int i=0;i<cps.size();i++)if(cps.get(i)==0xF1997){start=i;break;}if(start<=0)return null;int end=-1;for(int i=start+1;i<cps.size();i++)if(cps.get(i)==0xF1998){end=i;break;}return end<0?null:new int[]{start-1,start,end};}
    private static boolean reverseLong(List<Integer>cps){return cps.stream().anyMatch(cp->cp==0xF199A||cp==0xF199B);}
    private static List<Integer> textCps(String s){return s.codePoints().boxed().toList();}
    private static List<Integer> adaptLegacyFullWordRun(FontPairInfo pair,List<Integer>cps,String kind){
        int[]lr=currentLong(cps);Integer pi=Constants.ALL_WORD_CODEPOINTS.get("pi");
        if(lr!=null&&!reverseLong(cps)&&Objects.equals(cps.get(lr[0]),pi)){
            List<Cell>usable=splitCells(cps,lr[1]+1,lr[2]).stream().filter(c->!c.controlOnly()).toList();int max=3;Object mv=pair.renderAdapterSettings().get("maxLongPiCells");if(mv instanceof Number n&&n.intValue()>0)max=n.intValue();
            if(!usable.isEmpty()&&usable.size()<=max){StringBuilder b=new StringBuilder("pi");if("linja-pona".equals(kind)){b.append("+".repeat(usable.size()));for(int i=0;i<usable.size();i++){if(i>0)b.append(' ');appendLegacyCell(b,usable.get(i),kind,pair);}}else{b.append('+');for(Cell c:usable){b.append("__");appendLegacyCell(b,c,kind,pair);}}return textCps(b.toString());}
        }
        StringBuilder b=new StringBuilder();for(Cell c:splitCells(cps,0,cps.size()))appendLegacyCell(b,c,kind,pair);return textCps(b.toString());
    }
    private static List<Integer> adaptPuMonoFullWordRun(FontPairInfo pair,List<Integer>cps){
        int replacement=replacement(pair.renderAdapterSettings());List<Integer>out=new ArrayList<>();
        for(int cp:cps){if(joiner(cp)||controlOnly(cp))continue;Integer m=puMonoMap(cp);out.add(m==null?replacement:m);}return List.copyOf(out);
    }
    private static boolean lipamankaFullNeedsTranslation(List<Integer>cps,FontPairInfo pair){
        for(int cp:cps)if(joiner(cp)||cp==0xF199C||cp==0xF199D||cp==0xF199E||cp==0xF1989||cp==0xF198A||cp==0xF198B||cp==0xF198C||cp==0x300C||cp==0x300D||cp==0x3000||cp>=0xF19A4)return true;
        if(reverseLong(cps))return true;int[]lr=currentLong(cps);if(lr!=null){Integer pi=Constants.ALL_WORD_CODEPOINTS.get("pi"),lon=Constants.ALL_WORD_CODEPOINTS.get("lon");return !Objects.equals(cps.get(lr[0]),pi)&&!Objects.equals(cps.get(lr[0]),lon);}return false;
    }
    private static List<Integer> adaptLipamankaFullWordRun(FontPairInfo pair,List<Integer>cps){
        if(!lipamankaFullNeedsTranslation(cps,pair))return List.copyOf(cps);int[]lr=currentLong(cps);Integer pi=Constants.ALL_WORD_CODEPOINTS.get("pi"),lon=Constants.ALL_WORD_CODEPOINTS.get("lon");
        if(lr!=null&&!reverseLong(cps)&&(Objects.equals(cps.get(lr[0]),pi)||Objects.equals(cps.get(lr[0]),lon))){StringBuilder b=new StringBuilder(fullLegacyWord(cps.get(lr[0]),"linja-lipamanka",pair)).append('(');boolean first=true;for(Cell c:splitCells(cps,lr[1]+1,lr[2])){if(c.controlOnly())continue;if(!first)b.append(' ');first=false;appendLegacyCell(b,c,"linja-lipamanka",pair);}b.append(')');return textCps(b.toString());}
        StringBuilder b=new StringBuilder();for(Cell c:splitCells(cps,0,cps.size()))appendLegacyCell(b,c,"linja-lipamanka",pair);return textCps(b.toString());
    }

    private static Adapted identity(List<Integer> cps){
        StringBuilder b=new StringBuilder();List<Span>s=new ArrayList<>();int pos=0;
        for(int cp:cps){b.appendCodePoint(cp);s.add(new Span(pos,pos+1));pos++;}
        return new Adapted(b.toString(),List.copyOf(s));
    }

    private static Adapted adaptLegacy(List<Integer> cps,String kind,Map<String,Object> settings){
        StringBuilder b=new StringBuilder();List<Span>sp=blankSpans(cps.size());
        if(cps.isEmpty())return new Adapted("",List.of());
        append(b,sp,"[",0);
        int limit=Math.max(1,cps.size()-1);
        for(int i=1;i<limit;){
            int cp=cps.get(i);
            if(controlOnly(cp)){sp.set(i,new Span(codepointLength(b),codepointLength(b)));i++;continue;}
            int cellStart=i;List<Integer>cell=new ArrayList<>();cell.add(cp);i++;
            while(i+1<limit&&joiner(cps.get(i))){cell.add(cps.get(i));cell.add(cps.get(i+1));i+=2;}
            int st=codepointLength(b);b.append('_');
            for(int j=0;j<cell.size();){
                b.append(fullLegacyWord(cell.get(j),kind,settings));j++;
                if(j<cell.size()){
                    int op=cell.get(j);b.append('-');j++;
                }
            }
            int en=codepointLength(b);for(int k=cellStart;k<i;k++)sp.set(k,new Span(st,en));
        }
        if(cps.size()>1)append(b,sp,"]",cps.size()-1);
        return new Adapted(b.toString(),List.copyOf(sp));
    }

    private static Adapted adaptPuMono(List<Integer> cps,Map<String,Object> settings){
        StringBuilder b=new StringBuilder();List<Span>sp=blankSpans(cps.size());
        for(int i=0;i<cps.size();i++){
            Integer mapped=puMonoMap(cps.get(i));
            if(mapped==null)mapped=replacement(settings);
            appendCp(b,sp,mapped,i);
        }
        return new Adapted(b.toString(),List.copyOf(sp));
    }

    private static Adapted adaptLipamanka(List<Integer> cps,Map<String,Object> settings){
        if(cps.stream().noneMatch(cp->lipamankaNeedsTranslation(cp,settings)))return identity(cps);
        StringBuilder b=new StringBuilder();List<Span>sp=blankSpans(cps.size());
        append(b,sp,"[",0);
        for(int i=1;i<cps.size()-1;i++){
            if(i>1)b.append(' ');
            int start=codepointLength(b);
            String word=legacyWord(cps.get(i),"linja-lipamanka",settings);
            if(word==null)word=String.valueOf((char)0xFFFD);
            b.append(word);
            sp.set(i,new Span(start,codepointLength(b)));
        }
        append(b,sp,"]",cps.size()-1);
        return new Adapted(b.toString(),List.copyOf(sp));
    }

    private static boolean lipamankaNeedsTranslation(int cp,Map<String,Object> settings){
        return cp==0xF199C||cp==0xF199D||cp==0xF199E||cp==0xF1989||cp==0xF198A||cp==0xF198B||cp==0xF198C||cp==0x300C||cp==0x300D||cp==0x3000||cp==0xF19A4||cp==0xF19A6||cp>0xF19A3||((cp==0xF1910||cp==0xF191C)&&!Boolean.FALSE.equals(settings.get("deterministicAlternates")));
    }

    private static Integer puMonoMap(int cp){
        if(cp==0xF1989||cp==0xF198A||cp==0xF198B)return 0xF1941;
        if(cp==0xF198C)return 0xF195A;
        if(cp==0xF199C)return (int)'.';
        if(cp==0xF199D)return (int)':';
        if((cp>=0xF1900&&cp<=0xF1988)||(cp>=0xF19A0&&cp<=0xF19A3)||cp==Constants.CARTOUCHE_START||cp==Constants.CARTOUCHE_END||cp==0x3000||cp==0x300C||cp==0x300D)return cp;
        return null;
    }

    private static String legacyWord(int cp,String kind,Map<String,Object> settings){
        if(cp==0xF199C)return ".";
        if(cp==0xF199D)return ":";
        if(cp==0x3000)return "linja-lipamanka".equals(kind)?"zz":"  ";
        if(cp==0xF1989)return "linja-lipamanka".equals(kind)?"ni<":"ni";
        if(cp==0xF198A)return ("linja-sike".equals(kind)||"linja-lipamanka".equals(kind))?"ni^":"ni";
        if(cp==0xF198B)return ("linja-sike".equals(kind)||"linja-lipamanka".equals(kind))?"ni>":"ni";
        if(cp==0xF198C)return "linja-sike".equals(kind)?"sewi1":"sewi";
        if(cp==0x300C&&"linja-lipamanka".equals(kind))return "te";
        if(cp==0x300D&&"linja-lipamanka".equals(kind))return "to";
        String word=Constants.ALL_CODEPOINT_WORDS.get(cp);
        if(word==null)return null;
        if("linja-pona".equals(kind)&&(cp==0xF19A2||cp==0xF19A4||cp==0xF19A6||cp==0xF19A5))return null;
        if("linja-lipamanka".equals(kind)&&(cp==0xF19A4||cp==0xF19A6||cp==0xF19A5||cp>0xF19A3))return null;
        return word;
    }

    private static int replacement(Map<String,Object>settings){Object v=settings.get("unsupportedReplacementCodepoint");return v instanceof Number n?n.intValue():0xFFFD;}
    private static List<Span> blankSpans(int n){ArrayList<Span>s=new ArrayList<>(n);for(int i=0;i<n;i++)s.add(new Span(0,0));return s;}
    private static void append(StringBuilder b,List<Span>sp,String text,int index){int st=codepointLength(b);b.append(text);sp.set(index,new Span(st,codepointLength(b)));}
    private static void appendCp(StringBuilder b,List<Span>sp,int cp,int index){int st=codepointLength(b);b.appendCodePoint(cp);sp.set(index,new Span(st,codepointLength(b)));}
    private static int codepointLength(StringBuilder b){return b.codePointCount(0,b.length());}
}
