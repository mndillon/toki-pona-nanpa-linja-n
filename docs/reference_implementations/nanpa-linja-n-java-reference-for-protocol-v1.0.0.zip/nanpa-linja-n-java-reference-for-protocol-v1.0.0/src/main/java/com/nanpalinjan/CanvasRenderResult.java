package com.nanpalinjan;

import java.awt.image.BufferedImage;

public record CanvasRenderResult(
        String kind,
        String input,
        BufferedImage canvas,
        int width,
        int height,
        RenderPlan plan,
        String fontKey,
        FontPairInfo preset,
        RenderOptions config) {}
