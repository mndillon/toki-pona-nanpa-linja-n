package com.nanpalinjan;
import java.util.*;
public record RenderLinePlan(int lineIndex,int sourceLineIndex,int sentenceIndexInSourceLine,double xPx,double yPx,double widthPx,double heightPx,double baselineYPx,double ascentPx,double descentPx,List<RenderRun> runs){public RenderLinePlan{runs=runs==null?List.of():List.copyOf(runs);}}
