package com.nanpalinjan;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public final class ProductionFontRegistry {
    private final List<FontPairInfo> fonts;
    private final Map<String,FontPairInfo> byKey;
    private final Map<String,String> supportFontFilenames;

    private ProductionFontRegistry(List<FontPairInfo> fonts, Map<String,String> supportFontFilenames) {
        this.fonts = List.copyOf(fonts);
        LinkedHashMap<String,FontPairInfo> m = new LinkedHashMap<>();
        for (FontPairInfo f : fonts) m.put(f.key(), f);
        this.byKey = Collections.unmodifiableMap(m);
        this.supportFontFilenames = Collections.unmodifiableMap(new LinkedHashMap<>(supportFontFilenames));
    }

    public static ProductionFontRegistry load(Path manifest) throws IOException {
        return fromJson(Files.readString(manifest, StandardCharsets.UTF_8));
    }

    public static ProductionFontRegistry loadDefault() throws IOException {
        return load(ProductionFontBundle.loadDefault());
    }

    static ProductionFontRegistry load(ProductionFontBundle bundle) {
        return fromJson(bundle.manifestJson());
    }

    @SuppressWarnings("unchecked")
    private static ProductionFontRegistry fromJson(String text) {
        Map<String,Object> root = (Map<String,Object>) Json.parse(text);
        List<Object> pairs = (List<Object>) root.getOrDefault("pairs", List.of());
        ArrayList<FontPairInfo> out = new ArrayList<>();
        LinkedHashMap<String,String> support = new LinkedHashMap<>();
        Object supportNode = root.get("supportFonts");
        if (supportNode instanceof Map<?,?> rawSupport) {
            for (Map.Entry<?,?> e : rawSupport.entrySet()) {
                if (!(e.getValue() instanceof Map<?,?> rawFont)) continue;
                Object filename = rawFont.get("filename");
                if (filename == null) filename = rawFont.get("fileName");
                if (filename != null && !String.valueOf(filename).isBlank()) support.put(String.valueOf(e.getKey()), String.valueOf(filename));
            }
        }
        for (Object o : pairs) {
            Map<String,Object> p = (Map<String,Object>) o;
            String key = str(p, "fontKey", "");
            if (key.isBlank()) continue;
            out.add(new FontPairInfo(
                    key,
                    str(p, "label", key),
                    str(p, "baseFamily", key),
                    str(p, "companionFamily", key + "-nanpa-linja-n"),
                    str(p, "literalCartoucheFamily", str(p, "baseFamily", key)),
                    str(p, "parserMode", "sitelen-pona-ascii-extended"),
                    str(p, "renderAdapterId", "identity"),
                    str(p, "baseFilename", ""),
                    str(p, "companionFilename", ""),
                    str(p, "literalCartoucheFilename", ""),
                    map(p.get("settings")),
                    map(p.get("renderAdapterSettings"))));
        }
        if (out.isEmpty()) throw new IllegalArgumentException("No production font pairs in manifest");
        return new ProductionFontRegistry(out, support);
    }

    @SuppressWarnings("unchecked") private static Map<String,Object> map(Object o) { return o instanceof Map<?,?> ? (Map<String,Object>)o : Map.of(); }
    private static String str(Map<String,Object> m, String k, String d) { Object v=m.get(k); return v==null?d:String.valueOf(v); }

    public List<FontPairInfo> listFonts() { return fonts; }
    String supportFontFilename(String key) { return supportFontFilenames.get(key); }
    public FontPairInfo get(String keyOrAlias) {
        String requested = keyOrAlias == null || keyOrAlias.isBlank() ? "nasinNanpa" : keyOrAlias.trim();
        FontPairInfo exact = byKey.get(requested);
        if (exact != null) return exact;
        String a = alias(requested);
        for (FontPairInfo f : fonts) {
            if (alias(f.key()).equals(a) || alias(f.label()).equals(a) || alias(f.baseFamily()).equals(a) || alias(f.cartoucheFamily()).equals(a)) return f;
        }
        throw new IllegalArgumentException("Unknown production font key: " + requested);
    }
    private static String alias(String s) { return s == null ? "" : s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", ""); }
}
