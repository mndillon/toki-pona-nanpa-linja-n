package com.nanpalinjan;

import java.util.*;

final class Json {
    private final String s;
    private int i;
    private Json(String s) { this.s = s; }
    static Object parse(String s) {
        Json p = new Json(s);
        Object v = p.value();
        p.ws();
        if (p.i != s.length()) throw new IllegalArgumentException("trailing JSON");
        return v;
    }
    private void ws() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }
    private char ch() { return i < s.length() ? s.charAt(i) : '\0'; }
    private Object value() {
        ws();
        return switch (ch()) {
            case '{' -> obj();
            case '[' -> arr();
            case '"' -> str();
            case 't' -> { lit("true"); yield true; }
            case 'f' -> { lit("false"); yield false; }
            case 'n' -> { lit("null"); yield null; }
            default -> num();
        };
    }
    private void lit(String x) { if (!s.startsWith(x, i)) throw new IllegalArgumentException("bad literal"); i += x.length(); }
    private Map<String,Object> obj() {
        i++; Map<String,Object> m = new LinkedHashMap<>(); ws();
        if (ch() == '}') { i++; return m; }
        while (true) {
            ws(); String k = str(); ws(); if (ch() != ':') throw new IllegalArgumentException("colon"); i++;
            m.put(k, value()); ws();
            if (ch() == '}') { i++; return m; }
            if (ch() != ',') throw new IllegalArgumentException("comma"); i++;
        }
    }
    private List<Object> arr() {
        i++; List<Object> a = new ArrayList<>(); ws();
        if (ch() == ']') { i++; return a; }
        while (true) {
            a.add(value()); ws();
            if (ch() == ']') { i++; return a; }
            if (ch() != ',') throw new IllegalArgumentException("comma"); i++;
        }
    }
    private String str() {
        if (ch() != '"') throw new IllegalArgumentException("string"); i++;
        StringBuilder b = new StringBuilder();
        while (i < s.length()) {
            char c = s.charAt(i++);
            if (c == '"') return b.toString();
            if (c == '\\') {
                char e = s.charAt(i++);
                switch (e) {
                    case '"','\\','/' -> b.append(e);
                    case 'b' -> b.append('\b'); case 'f' -> b.append('\f'); case 'n' -> b.append('\n'); case 'r' -> b.append('\r'); case 't' -> b.append('\t');
                    case 'u' -> { int cp = Integer.parseInt(s.substring(i, i + 4), 16); i += 4; b.append((char) cp); }
                    default -> throw new IllegalArgumentException("escape");
                }
            } else b.append(c);
        }
        throw new IllegalArgumentException("unterminated");
    }
    private Number num() {
        int st = i; if (ch() == '-') i++; while (Character.isDigit(ch())) i++;
        boolean dec = false;
        if (ch() == '.') { dec = true; i++; while (Character.isDigit(ch())) i++; }
        if (ch() == 'e' || ch() == 'E') { dec = true; i++; if (ch() == '+' || ch() == '-') i++; while (Character.isDigit(ch())) i++; }
        String n = s.substring(st, i); if (n.isEmpty()) throw new IllegalArgumentException("number");
        return dec ? Double.valueOf(n) : Long.valueOf(n);
    }
}
