package com.nanpalinjan;
public record VectorElement(String kind,String runId,String pathData,String fill,String imageHref,double x,double y,double width,double height){}
