package com.nanpalinjan;

public record PdfRenderResult(
        String kind,
        String input,
        byte[] bytes,
        RenderPlan plan,
        String fontKey,
        FontPairInfo preset,
        RenderOptions config) {
    public PdfRenderResult { bytes = bytes.clone(); }
}
