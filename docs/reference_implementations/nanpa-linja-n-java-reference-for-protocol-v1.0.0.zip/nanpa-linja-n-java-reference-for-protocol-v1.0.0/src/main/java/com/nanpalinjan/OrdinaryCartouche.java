package com.nanpalinjan;

import java.util.*;

/** Parsed ordinary (non-numeric, non-literal) cartouche content. */
final class OrdinaryCartouche {
    final List<Integer> innerCodepoints;
    final List<Integer> manualTallies;
    final String tallyMode;

    private OrdinaryCartouche(List<Integer> cps,List<Integer> tallies,String tallyMode){
        this.innerCodepoints=List.copyOf(cps);
        this.manualTallies=List.copyOf(tallies);
        this.tallyMode=tallyMode;
    }

    static OrdinaryCartouche parse(String input, FontPairInfo pair){return parse(input,pair,new ParseOptions());}
    static OrdinaryCartouche parse(String input, FontPairInfo pair, ParseOptions parser){
        if(input==null)return null;String s=input.trim();if(s.length()<2||s.charAt(0)!='['||s.charAt(s.length()-1)!=']')return null;
        return parseBody(s.substring(1,s.length()-1),pair,parser);
    }
    static OrdinaryCartouche parseBody(String body,FontPairInfo pair,ParseOptions parser){
        if(body==null||body.isBlank())return null;ParseOptions p=parser==null?new ParseOptions():parser;
        boolean commaTallies=p.cartoucheCommaTallyMarks();
        String mode=p.cartoucheTallyMode();
        if(mode==null||mode.isBlank())mode=String.valueOf(pair.settings().getOrDefault("cartoucheTallyMode","ucsur")).trim().toLowerCase(Locale.ROOT);
        if(!Set.of("manual","comma","ucsur").contains(mode))mode="ucsur";
        final String tallyMode=mode;
        List<Integer> cps=new ArrayList<>();List<Integer> tallies=new ArrayList<>();StringBuilder cur=new StringBuilder();
        class Flush {boolean run(){if(cur.isEmpty())return true;String token=cur.toString().trim().toLowerCase(Locale.ROOT);cur.setLength(0);if(token.isEmpty())return true;Integer cp=Constants.ALL_WORD_CODEPOINTS.get(token);if(cp==null)return false;if(cp==0xF199E&&"manual".equals(tallyMode)){if(!cps.isEmpty())tallies.set(tallies.size()-1,Math.min(8,tallies.getLast()+1));return true;}cps.add(cp);tallies.add(0);return true;}}
        Flush flush=new Flush();
        for(int off=0;off<body.length();){int cp=body.codePointAt(off);off+=Character.charCount(cp);if(Character.isWhitespace(cp)){if(!flush.run())return null;continue;}if(cp=='.'||cp==0x00B7||cp==':'){if(!flush.run())return null;int mapped=cp==':'?0xF199D:0xF199C;cps.add(mapped);tallies.add(0);continue;}if(cp==','){if(!flush.run())return null;if(!commaTallies)continue;if("manual".equals(tallyMode)){if(!cps.isEmpty())tallies.set(tallies.size()-1,Math.min(8,tallies.getLast()+1));}else if("comma".equals(tallyMode)){cps.add((int)',');tallies.add(0);}else{cps.add(0xF199E);tallies.add(0);}continue;}cur.appendCodePoint(cp);}
        if(!flush.run()||cps.isEmpty())return null;return new OrdinaryCartouche(cps,tallies,tallyMode);
    }

    static OrdinaryCartouche of(List<Integer> cps,List<Integer> tallies,String mode){List<Integer> t=tallies==null?java.util.Collections.nCopies(cps.size(),0):tallies;return new OrdinaryCartouche(cps,t,mode==null?"ucsur":mode);}

    boolean hasManualTallies(){return manualTallies.stream().anyMatch(n->n!=null&&n>0);}
}
