package com.nanpalinjan;
import java.util.*;
public record TallyGroup(int ownerIndex,int count,double ownerLeftPx,double ownerRightPx,double centerXPx,double topYPx,double bottomYPx,double strokeWidthPx,List<Double> strokeCentersPx){public TallyGroup{strokeCentersPx=strokeCentersPx==null?List.of():List.copyOf(strokeCentersPx);}}
