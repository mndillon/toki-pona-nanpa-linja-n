package com.nanpalinjan;

import java.util.*;

public record FacadeParseResult(
        String input,
        String fontKey,
        FontPairInfo preset,
        ParseResult numeric,
        boolean numericInput,
        List<String> diagnostics) {
    public FacadeParseResult { diagnostics = diagnostics == null ? List.of() : List.copyOf(diagnostics); }
}
