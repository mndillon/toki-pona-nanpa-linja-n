package com.nanpalinjan;
import java.util.*;
public record DocumentLine(int index,int sourceLineIndex,int sentenceIndexInSourceLine,String sourceText,List<DocumentSegment> children){public DocumentLine{children=children==null?List.of():List.copyOf(children);}}
