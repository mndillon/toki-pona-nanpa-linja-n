package com.nanpalinjan;

import java.util.*;

public record FontPairInfo(
        String key,
        String label,
        String baseFamily,
        String cartoucheFamily,
        String literalCartoucheFamily,
        String parserMode,
        String renderAdapterId,
        String baseFilename,
        String companionFilename,
        String literalCartoucheFilename,
        Map<String,Object> settings,
        Map<String,Object> renderAdapterSettings) {
    public FontPairInfo {
        settings = settings == null ? Map.of() : Collections.unmodifiableMap(new LinkedHashMap<>(settings));
        renderAdapterSettings = renderAdapterSettings == null ? Map.of() : Collections.unmodifiableMap(new LinkedHashMap<>(renderAdapterSettings));
    }
}
