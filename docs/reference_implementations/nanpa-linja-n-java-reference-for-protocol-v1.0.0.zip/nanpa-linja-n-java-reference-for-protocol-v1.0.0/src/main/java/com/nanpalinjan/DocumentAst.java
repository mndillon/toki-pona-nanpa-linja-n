package com.nanpalinjan;
import java.util.*;
public record DocumentAst(String type,String normalizedInput,Map<String,Object> parserOptions,List<DocumentLine> lines){public DocumentAst{type=type==null?"document":type;parserOptions=parserOptions==null?Map.of():Map.copyOf(parserOptions);lines=lines==null?List.of():List.copyOf(lines);}}
