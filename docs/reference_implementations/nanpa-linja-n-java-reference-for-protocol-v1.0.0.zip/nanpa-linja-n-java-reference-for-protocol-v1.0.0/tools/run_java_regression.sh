#!/usr/bin/env bash
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

REPORT_DIR="$ROOT/test-output"
REPORT="$REPORT_DIR/java-regression-report.txt"
mkdir -p "$REPORT_DIR"
: > "$REPORT"

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
CLASSES="$TMP/classes"
mkdir -p "$CLASSES"

declare -a SUITE_NAMES=()
declare -a SUITE_STATUS=()
declare -a SUITE_RC=()

log(){ printf '%s\n' "$*" | tee -a "$REPORT"; }

run_suite(){
  local name="$1"; shift
  local out="$TMP/suite-${#SUITE_NAMES[@]}.log"
  log ""
  log "=== $name ==="
  "$@" >"$out" 2>&1
  local rc=$?
  cat "$out" | tee -a "$REPORT"
  SUITE_NAMES+=("$name")
  SUITE_RC+=("$rc")
  if [[ $rc -eq 0 ]]; then
    SUITE_STATUS+=("PASS")
    log "--- RESULT: PASS ($name) ---"
  else
    SUITE_STATUS+=("FAIL")
    log "--- RESULT: FAIL rc=$rc ($name) ---"
  fi
  return 0
}

run_java(){ java -Djava.awt.headless=true -cp "$CLASSES" "$@"; }

FONT_SOURCE="${NANPA_FONT_ZIP:-${NANPA_FONT_DIR:-$ROOT/resources/fonts.zip}}"
if [[ -d "$FONT_SOURCE" ]]; then
  if [[ -f "$FONT_SOURCE/fonts.zip" ]]; then FONT_SOURCE="$FONT_SOURCE/fonts.zip"
  elif [[ -f "$FONT_SOURCE/resources/fonts.zip" ]]; then FONT_SOURCE="$FONT_SOURCE/resources/fonts.zip"
  fi
fi
if [[ -f "$FONT_SOURCE" ]]; then
  FONT_SOURCE="$(cd "$(dirname "$FONT_SOURCE")" && pwd)/$(basename "$FONT_SOURCE")"
  FONT_OK=1
else
  FONT_OK=0
fi

font_required(){
  if [[ "$FONT_OK" -ne 1 ]]; then
    echo "ERROR: this suite requires the production resources/fonts.zip bundle." >&2
    echo "Set NANPA_FONT_ZIP (or legacy NANPA_FONT_DIR) to fonts.zip or a directory containing it." >&2
    return 3
  fi
  "$@"
}

version_check(){
  java -version 2>&1 | head -1
  javac -version
  local major
  major="$(javac -version 2>&1 | awk '{print $2}' | cut -d. -f1)"
  if [[ "$major" != "21" ]]; then
    echo "ERROR: Java 21 is required; found javac $major" >&2
    return 2
  fi
  if [[ "$FONT_OK" -eq 1 ]]; then
    echo "Production font bundle: $FONT_SOURCE"
  else
    echo "WARNING: production font bundle is unavailable: $FONT_SOURCE" >&2
    echo "Core suites will still run; each font-dependent suite will be reported as FAIL instead of aborting the run." >&2
  fi
}

compile_all(){
  mapfile -t SOURCES < <(find src/main/java src/test/java -type f -name '*.java' | sort)
  javac --release 21 -encoding UTF-8 -d "$CLASSES" "${SOURCES[@]}" || return $?
  echo "Java compiler source checks: ${#SOURCES[@]}/${#SOURCES[@]} PASS"
}

log "nanpa-linja-n Java reference regression"
log "========================================"
log "Non-fail-fast mode: every configured suite is attempted."
log "Consolidated report: $REPORT"

run_suite "environment / Java 21" version_check
run_suite "compile all Java sources" compile_all
run_suite "Core API surface" run_java com.nanpalinjan.ApiSurfaceCheck
run_suite "astToText regression + render integration" run_java com.nanpalinjan.AstToTextRegression "$FONT_SOURCE"
run_suite "current baseline parseNumber / astToText / numeric whitespace / te-to routing" font_required run_java com.nanpalinjan.CurrentBaselineRegression "$FONT_SOURCE"
run_suite "frozen Protocol parser/renderer/API conformance" run_java com.nanpalinjan.ConformanceRunner conformance/nanpa-linja-n-regression-v1.0.2.json
run_suite "logical renderer smoke" run_java com.nanpalinjan.RendererSmoke
run_suite "JavaScript facade parity API" font_required run_java com.nanpalinjan.FacadeParityCheck "$FONT_SOURCE"
run_suite "current canonical syntax + production adapters" font_required run_java com.nanpalinjan.CanonicalSyntaxRegression "$FONT_SOURCE" conformance/canonical-syntax-v1.0.1-phase1/cases.json
run_suite "current canonical full renderer (254 cases)" font_required run_java com.nanpalinjan.CanonicalFullRendererRegression "$FONT_SOURCE" conformance/full-renderer-canonical-v1.0.1/cases.json
run_suite "mixed-feature JavaScript differential interactions (346 cases)" font_required run_java com.nanpalinjan.CompositionInteractionRegression "$FONT_SOURCE" references/javascript-composition-interactions-v1.json
run_suite "browser-renderer structural parity" font_required run_java com.nanpalinjan.RendererStructuralCheck "$FONT_SOURCE"
run_suite "production font/vector/geometry rendering" font_required run_java com.nanpalinjan.ProductionRenderingRegression "$FONT_SOURCE" rendering/font-golden-cases-v1.1.0.json references/javascript-browser-render-geometry-v1.json
run_suite "ordinary cartouche/tally/halo parity" font_required run_java com.nanpalinjan.OrdinaryCartoucheRegression "$FONT_SOURCE" references/javascript-browser-ordinary-cartouche-v1.json
run_suite "legacy Full Renderer Profile v1.0.0 candidate" font_required run_java com.nanpalinjan.FullRendererProfileRegression "$FONT_SOURCE" conformance/full-renderer-profile-v1.0.0-candidate

passed=0
failed=0
log ""
log "=== CONSOLIDATED SUMMARY ==="
for i in "${!SUITE_NAMES[@]}"; do
  log "${SUITE_STATUS[$i]}: ${SUITE_NAMES[$i]} (rc=${SUITE_RC[$i]})"
  if [[ "${SUITE_STATUS[$i]}" == "PASS" ]]; then ((passed+=1)); else ((failed+=1)); fi
done
log "configured suites: ${#SUITE_NAMES[@]}"
log "passed suites: $passed"
log "failed suites: $failed"
if [[ $failed -eq 0 ]]; then
  log "ALL CONFIGURED JAVA TESTS PASS"
  exit 0
else
  log "JAVA REGRESSION RUN COMPLETED WITH $failed FAILING SUITE(S)"
  exit 1
fi
