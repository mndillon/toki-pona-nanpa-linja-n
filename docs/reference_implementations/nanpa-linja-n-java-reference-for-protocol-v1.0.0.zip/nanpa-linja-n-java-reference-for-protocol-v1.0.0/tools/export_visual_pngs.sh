#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

FONT_SOURCE="${NANPA_FONT_ZIP:-${NANPA_FONT_DIR:-$ROOT/resources/fonts.zip}}"
if [[ -d "$FONT_SOURCE" ]]; then
  if [[ -f "$FONT_SOURCE/fonts.zip" ]]; then FONT_SOURCE="$FONT_SOURCE/fonts.zip"
  elif [[ -f "$FONT_SOURCE/resources/fonts.zip" ]]; then FONT_SOURCE="$FONT_SOURCE/resources/fonts.zip"
  fi
fi
[[ -f "$FONT_SOURCE" ]] || { echo "ERROR: resources/fonts.zip not found; set NANPA_FONT_ZIP if overriding" >&2; exit 3; }
FONT_SOURCE="$(cd "$(dirname "$FONT_SOURCE")" && pwd)/$(basename "$FONT_SOURCE")"
OUT_DIR="${1:-$ROOT/test-output}"
mkdir -p "$OUT_DIR"

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mapfile -t SOURCES < <(find src/main/java src/test/java -type f -name '*.java' | sort)
javac --release 21 -encoding UTF-8 -d "$TMP/classes" "${SOURCES[@]}"
java -Djava.awt.headless=true -cp "$TMP/classes" com.nanpalinjan.VisualOutputExport "$FONT_SOURCE" "$OUT_DIR"
