#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
FONT_SOURCE="${NANPA_FONT_ZIP:-${NANPA_FONT_DIR:-$ROOT/resources/fonts.zip}}"; [[ -f "$FONT_SOURCE" ]] || { echo "ERROR: resources/fonts.zip not found; set NANPA_FONT_ZIP if overriding" >&2; exit 3; }
OUT="${1:-$ROOT/test-output/matrix}"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
mapfile -t SOURCES < <(find src/main/java src/test/java -type f -name '*.java' | sort)
javac --release 21 -encoding UTF-8 -d "$TMP/classes" "${SOURCES[@]}"
java -Djava.awt.headless=true -cp "$TMP/classes" com.nanpalinjan.VisualMatrixExport "$FONT_SOURCE" rendering/font-golden-cases-v1.1.0.json "$OUT"
