#!/usr/bin/env bash
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
REPORT_DIR="$ROOT/test-output"; REPORT="$REPORT_DIR/java-core-regression-report.txt"; mkdir -p "$REPORT_DIR"; : > "$REPORT"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT; CLASSES="$TMP/classes"; mkdir -p "$CLASSES"
declare -a NAMES=() STATUS=() RCS=()
log(){ printf '%s\n' "$*" | tee -a "$REPORT"; }
run_suite(){ local n="$1"; shift; local o="$TMP/s${#NAMES[@]}.log"; log ""; log "=== $n ==="; "$@" >"$o" 2>&1; local r=$?; cat "$o" | tee -a "$REPORT"; NAMES+=("$n"); RCS+=("$r"); if [[ $r -eq 0 ]];then STATUS+=(PASS);log "--- RESULT: PASS ($n) ---";else STATUS+=(FAIL);log "--- RESULT: FAIL rc=$r ($n) ---";fi; return 0; }
run_java(){ java -Djava.awt.headless=true -cp "$CLASSES" "$@"; }
version(){ java -version 2>&1|head -1; javac -version; local m="$(javac -version 2>&1|awk '{print $2}'|cut -d. -f1)"; [[ "$m" == 21 ]] || { echo "ERROR: Java 21 required; found $m" >&2; return 2; }; }
compile(){ mapfile -t S < <(find src/main/java src/test/java -type f -name '*.java'|sort); javac --release 21 -encoding UTF-8 -d "$CLASSES" "${S[@]}" || return $?; echo "Java compiler source checks: ${#S[@]}/${#S[@]} PASS"; }
log "nanpa-linja-n Java core reference regression"; log "============================================="; log "Non-fail-fast mode: every configured Core suite is attempted."; log "Consolidated report: $REPORT"
run_suite "environment / Java 21" version
run_suite "compile all Java sources" compile
run_suite "Core API surface" run_java com.nanpalinjan.ApiSurfaceCheck
run_suite "astToText pure regression" run_java com.nanpalinjan.AstToTextRegression
run_suite "frozen Protocol parser/renderer/API conformance" run_java com.nanpalinjan.ConformanceRunner conformance/nanpa-linja-n-regression-v1.0.2.json
run_suite "logical renderer smoke" run_java com.nanpalinjan.RendererSmoke
run_suite "JavaScript facade API smoke" run_java com.nanpalinjan.FacadeParityCheck
p=0;f=0;log "";log "=== CONSOLIDATED SUMMARY ===";for i in "${!NAMES[@]}";do log "${STATUS[$i]}: ${NAMES[$i]} (rc=${RCS[$i]})";if [[ "${STATUS[$i]}" == PASS ]];then ((p+=1));else ((f+=1));fi;done;log "configured suites: ${#NAMES[@]}";log "passed suites: $p";log "failed suites: $f";if [[ $f -eq 0 ]];then log "ALL CONFIGURED JAVA CORE TESTS PASS";exit 0;else log "JAVA CORE REGRESSION RUN COMPLETED WITH $f FAILING SUITE(S)";exit 1;fi
