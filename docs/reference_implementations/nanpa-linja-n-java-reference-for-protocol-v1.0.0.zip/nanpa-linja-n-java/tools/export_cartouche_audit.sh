#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
FONT_DIR="${NANPA_FONT_DIR:-}"; [[ -n "$FONT_DIR" ]] || { echo "ERROR: set NANPA_FONT_DIR" >&2; exit 3; }
OUT="${1:-$ROOT/test-output/cartouche-audit}"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
mapfile -t SOURCES < <(find src/main/java src/test/java -type f -name '*.java' | sort)
javac --release 21 -encoding UTF-8 -d "$TMP/classes" "${SOURCES[@]}"
java -Djava.awt.headless=true -cp "$TMP/classes" com.nanpalinjan.CartoucheAuditExport "$FONT_DIR" "$OUT"
