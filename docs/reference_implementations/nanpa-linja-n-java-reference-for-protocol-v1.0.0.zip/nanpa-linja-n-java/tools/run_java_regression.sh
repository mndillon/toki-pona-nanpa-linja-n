#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

echo "nanpa-linja-n Java reference regression"
echo "========================================"
java -version 2>&1 | head -1
javac -version

major="$(javac -version 2>&1 | awk '{print $2}' | cut -d. -f1)"
if [[ "$major" != "21" ]]; then
  echo "ERROR: Java 21 is required; found javac $major" >&2
  exit 2
fi

has_fonts() {
  local d="$1"
  # Full JavaScript-parity qualification needs both the base sitelen font and the
  # nanpa-linja-n companion font for every production pair.
  [[ -f "$d/nasin-nanpa-5.0.0-beta.3-UCSUR-v5-ascii-ligatures.otf" ]] &&
  [[ -f "$d/nasin-nanpa-5.0.0-beta.3-UCSUR-nanpa-linja-n-good-kasi-nasin-e-en-ss1223.otf" ]] &&
  [[ -f "$d/sitelenselikiwenjuniko-latin-ligatures.ttf" ]] &&
  [[ -f "$d/sitelenselikiwenjuniko-nanpa-linja-n-good-kasi-nasin-e-en-ss1223.ttf" ]] &&
  [[ -f "$d/FairfaxHD.ttf" ]] &&
  [[ -f "$d/FairfaxHD-nanpa-linja-n-good-kasi-nasin-e-en-ss1223.ttf" ]] &&
  [[ -f "$d/FairfaxPonaHD.ttf" ]] &&
  [[ -f "$d/FairfaxPonaHD-nanpa-linja-n-good-kasi-nasin-e-en-ss1223.ttf" ]] &&
  [[ -f "$d/linja-pona.otf" ]] &&
  [[ -f "$d/linja-pona-nanpa-linja-n-nasin-e-en-ss1223.otf" ]] &&
  [[ -f "$d/linja-sike-5-cartouche-fix.otf" ]] &&
  [[ -f "$d/linja-sike-5-nanpa-linja-n-nasin-e-en-ss1223.otf" ]] &&
  [[ -f "$d/NasinSitelenPuMono.otf" ]] &&
  [[ -f "$d/NasinSitelenPuMono-nanpa-linja-n-nasin-e-en-ss1223.otf" ]] &&
  [[ -f "$d/linjalipamanka-normal-cartouche-fix.otf" ]] &&
  [[ -f "$d/linjalipamanka-normal-nanpa-linja-n-nasin-e-en-ss1223.otf" ]]
}

FONT_DIR="${NANPA_FONT_DIR:-}"
if [[ -z "$FONT_DIR" ]]; then
  for d in "$ROOT/assets/fonts" "$ROOT/../assets/fonts" "$ROOT/../../assets/fonts" "$PWD/assets/fonts"; do
    if [[ -d "$d" ]] && has_fonts "$d"; then FONT_DIR="$d"; break; fi
  done
fi
if [[ -z "$FONT_DIR" ]] || ! has_fonts "$FONT_DIR"; then
  cat >&2 <<MSG
ERROR: the full Java rendering regression requires all eight production base+companion font pairs.
Set NANPA_FONT_DIR to the directory containing the filenames listed in
rendering/production-font-pairs.manifest.json.
For Core-v1-only checks, run ./tools/run_java_core_regression.sh.
MSG
  exit 3
fi
FONT_DIR="$(cd "$FONT_DIR" && pwd)"
echo "Production font directory: $FONT_DIR"

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mapfile -t SOURCES < <(find src/main/java src/test/java -type f -name '*.java' | sort)
javac --release 21 -encoding UTF-8 -d "$TMP/classes" "${SOURCES[@]}"
echo "Java compiler source checks: ${#SOURCES[@]}/${#SOURCES[@]} PASS"
java -Djava.awt.headless=true -cp "$TMP/classes" com.nanpalinjan.ApiSurfaceCheck
echo "=== astToText ==="
java -Djava.awt.headless=true -cp "$TMP/classes" com.nanpalinjan.AstToTextRegression "$FONT_DIR"
java -Djava.awt.headless=true -cp "$TMP/classes" com.nanpalinjan.ConformanceRunner conformance/nanpa-linja-n-regression-v1.0.2.json
java -Djava.awt.headless=true -cp "$TMP/classes" com.nanpalinjan.RendererSmoke
java -Djava.awt.headless=true -cp "$TMP/classes" com.nanpalinjan.FacadeParityCheck "$FONT_DIR"
java -Djava.awt.headless=true -cp "$TMP/classes" com.nanpalinjan.RendererStructuralCheck "$FONT_DIR"
java -Djava.awt.headless=true -cp "$TMP/classes" com.nanpalinjan.ProductionRenderingRegression "$FONT_DIR" rendering/font-golden-cases-v1.1.0.json references/javascript-browser-render-geometry-v1.json
java -Djava.awt.headless=true -cp "$TMP/classes" com.nanpalinjan.OrdinaryCartoucheRegression "$FONT_DIR" references/javascript-browser-ordinary-cartouche-v1.json
java -Djava.awt.headless=true -cp "$TMP/classes" com.nanpalinjan.FullRendererProfileRegression "$FONT_DIR" conformance/full-renderer-profile-v1.0.0-candidate

echo "ALL CONFIGURED JAVA PARSING, PRODUCTION-RENDERING, AND FULL-RENDERER PROFILE TESTS PASS"
