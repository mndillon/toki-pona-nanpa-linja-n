#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

echo "nanpa-linja-n Java core reference regression"
echo "============================================="
java -version 2>&1 | head -1
javac -version

major="$(javac -version 2>&1 | awk '{print $2}' | cut -d. -f1)"
if [[ "$major" != "21" ]]; then
  echo "ERROR: Java 21 is required; found javac $major" >&2
  exit 2
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mapfile -t SOURCES < <(find src/main/java src/test/java -type f -name '*.java' | sort)
javac --release 21 -encoding UTF-8 -d "$TMP/classes" "${SOURCES[@]}"
echo "Java compiler source checks: ${#SOURCES[@]}/${#SOURCES[@]} PASS"
java -Djava.awt.headless=true -cp "$TMP/classes" com.nanpalinjan.ApiSurfaceCheck
echo "=== astToText ==="
java -Djava.awt.headless=true -cp "$TMP/classes" com.nanpalinjan.AstToTextRegression
java -Djava.awt.headless=true -cp "$TMP/classes" com.nanpalinjan.ConformanceRunner conformance/nanpa-linja-n-regression-v1.0.2.json
java -Djava.awt.headless=true -cp "$TMP/classes" com.nanpalinjan.RendererSmoke
java -Djava.awt.headless=true -cp "$TMP/classes" com.nanpalinjan.FacadeParityCheck
