#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
if [[ -n "${NANPA_FONT_DIR:-}" ]]; then
  echo "Maven will activate the production-rendering profile from NANPA_FONT_DIR."
else
  echo "NANPA_FONT_DIR is not set; Maven will run the Core/API/facade build checks only."
  echo "Use ./tools/run_java_regression.sh for mandatory full rendering qualification."
fi
exec mvn test
