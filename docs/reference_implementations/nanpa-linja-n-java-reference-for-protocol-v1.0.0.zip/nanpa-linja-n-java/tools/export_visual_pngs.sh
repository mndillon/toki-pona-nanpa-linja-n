#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

has_fonts() {
  local d="$1"
  [[ -f "$d/nasin-nanpa-5.0.0-beta.3-UCSUR-nanpa-linja-n-good-kasi-nasin-e-en-ss1223.otf" ]] &&
  [[ -f "$d/sitelenselikiwenjuniko-nanpa-linja-n-good-kasi-nasin-e-en-ss1223.ttf" ]] &&
  [[ -f "$d/FairfaxHD-nanpa-linja-n-good-kasi-nasin-e-en-ss1223.ttf" ]] &&
  [[ -f "$d/FairfaxPonaHD-nanpa-linja-n-good-kasi-nasin-e-en-ss1223.ttf" ]] &&
  [[ -f "$d/linja-pona-nanpa-linja-n-nasin-e-en-ss1223.otf" ]] &&
  [[ -f "$d/linja-sike-5-nanpa-linja-n-nasin-e-en-ss1223.otf" ]] &&
  [[ -f "$d/NasinSitelenPuMono-nanpa-linja-n-nasin-e-en-ss1223.otf" ]] &&
  [[ -f "$d/linjalipamanka-normal-nanpa-linja-n-nasin-e-en-ss1223.otf" ]]
}

FONT_DIR="${NANPA_FONT_DIR:-}"
if [[ -z "$FONT_DIR" ]]; then
  for d in "$ROOT/assets/fonts" "$ROOT/../assets/fonts" "$ROOT/../../assets/fonts" "$PWD/assets/fonts"; do
    if [[ -d "$d" ]] && has_fonts "$d"; then FONT_DIR="$d"; break; fi
  done
fi
if [[ -z "$FONT_DIR" ]] || ! has_fonts "$FONT_DIR"; then
  cat >&2 <<MSG
ERROR: visual PNG export requires the eight production companion fonts.
Set NANPA_FONT_DIR to the directory containing the filenames listed in
rendering/production-font-pairs.manifest.json.
MSG
  exit 3
fi
FONT_DIR="$(cd "$FONT_DIR" && pwd)"
OUT_DIR="${1:-$ROOT/test-output}"
mkdir -p "$OUT_DIR"

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mapfile -t SOURCES < <(find src/main/java src/test/java -type f -name '*.java' | sort)
javac --release 21 -encoding UTF-8 -d "$TMP/classes" "${SOURCES[@]}"
java -Djava.awt.headless=true -cp "$TMP/classes" com.nanpalinjan.VisualOutputExport "$FONT_DIR" "$OUT_DIR"
