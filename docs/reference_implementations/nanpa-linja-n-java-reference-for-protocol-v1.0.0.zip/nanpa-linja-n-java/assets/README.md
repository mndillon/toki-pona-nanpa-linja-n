# Production font assets

The Java reference does not duplicate production font binaries in this source archive.
It consumes the same eight production **companion** font files named by
`rendering/production-font-pairs.manifest.json`.

For production-rendering regression, point `NANPA_FONT_DIR` at the directory that
contains those companion font files, or place them under `assets/fonts/`.

The high-level Java facade (`NanpaLinjaN`) uses the companion font as the complete
Java2D shaping resource for each production pair; the manifest's base/literal
metadata is retained for API parity and identification.
