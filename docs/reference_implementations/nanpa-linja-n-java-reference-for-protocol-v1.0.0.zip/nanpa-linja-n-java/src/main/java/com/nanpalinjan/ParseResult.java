package com.nanpalinjan;

import java.util.*;

public final class ParseResult {
    public String input, caps, properName, uniqueCode, hexCodepoints, hexWithCartouche, displayValue, numericMode;
    public List<Integer> ucsurCodepoints, innerCodepoints, codepoints, abbreviatedUcsurCodepoints;
    public List<String> tpWords, words, abbreviatedWords;
    public boolean isTime,isDate,isTimeLike,isHex,isBinary;
    public ParseOptions.SemanticKind semanticKind;
    public ParseOptions.DecimalStartGlyph semanticStartGlyph;
    public String kind, hexDigits, binaryDigits;
    public Integer numberBase;
    public List<NumericPart> hexParts,binaryParts;

    public Map<String,Object> toMap() {
        Map<String,Object> out=new LinkedHashMap<>();
        out.put("input",input); out.put("caps",caps); out.put("properName",properName); out.put("uniqueCode",uniqueCode);
        out.put("ucsurCodepoints",ucsurCodepoints); out.put("hexCodepoints",hexCodepoints); out.put("hexWithCartouche",hexWithCartouche);
        out.put("tpWords",tpWords); out.put("words",words); out.put("displayValue",displayValue); out.put("isTime",isTime); out.put("isDate",isDate); out.put("isTimeLike",isTimeLike);
        out.put("innerCodepoints",innerCodepoints); out.put("codepoints",codepoints); out.put("numericMode",numericMode);
        if (kind==null) { out.put("semanticKind", semanticKind==null?null:semanticKind.name()); out.put("semanticStartGlyph", semanticStartGlyph==null?null:semanticStartGlyph.name()); }
        if (kind!=null) out.put("kind",kind); if(numberBase!=null)out.put("numberBase",numberBase); if(isHex)out.put("isHex",true); if(isBinary)out.put("isBinary",true);
        if(hexDigits!=null)out.put("hexDigits",hexDigits); if(binaryDigits!=null)out.put("binaryDigits",binaryDigits);
        if(hexParts!=null)out.put("hexParts",hexParts.stream().map(NumericPart::toMap).toList()); if(binaryParts!=null)out.put("binaryParts",binaryParts.stream().map(NumericPart::toMap).toList());
        if(abbreviatedUcsurCodepoints!=null)out.put("abbreviatedUcsurCodepoints",abbreviatedUcsurCodepoints); if(abbreviatedWords!=null)out.put("abbreviatedWords",abbreviatedWords);
        return out;
    }
}
