package com.nanpalinjan;

import java.util.*;
import java.util.regex.*;

/** Java port of the canonical renderer's host-independent document segmentation layer. */
final class DocumentParser {
    private DocumentParser(){}
    private static final List<Map.Entry<String,String>> ALIASES=List.of(
            Map.entry("'cartouche-start'","["),Map.entry("'cartouche-end'","]"),
            Map.entry("'zw-joiner'","&"),Map.entry("'stack-joiner'","-"),Map.entry("'nesting-joiner'","+"),
            Map.entry("'ideographic-space'"," zz "),Map.entry("'long-start'","("),Map.entry("'long-end'",")"),
            Map.entry("'left-bracket'"," te "),Map.entry("'right-bracket'"," to "),Map.entry("'middle-dot'","."),
            Map.entry("'colon'",":"),Map.entry("'tally'",","));

    static DocumentAst parse(String input, ParseOptions parser){
        ParseOptions p=parser==null?new ParseOptions():parser;
        String normalized=normalize(input,p);
        List<DocumentLine> lines=new ArrayList<>();
        String[] sourceLines=normalized.split("\\n",-1);
        for(int sourceLineIndex=0;sourceLineIndex<sourceLines.length;sourceLineIndex++){
            List<String> rendered=p.breakLinesAtFullStops()?splitAtFullStops(sourceLines[sourceLineIndex]):List.of(sourceLines[sourceLineIndex]);
            for(int sentence=0;sentence<rendered.size();sentence++){
                String s=rendered.get(sentence);
                lines.add(new DocumentLine(lines.size(),sourceLineIndex,sentence,s,segments(s)));
            }
        }
        return new DocumentAst("document",normalized,Map.of("breakLinesAtFullStops",p.breakLinesAtFullStops()),lines);
    }

    static String normalize(String input,ParseOptions p){
        String s=input==null?"":input;
        if(!"standard-sitelen-pona-ascii-core".equals(p.rendererMode()))for(var e:ALIASES)s=s.replace(e.getKey(),e.getValue());
        return s.replace("\r\n","\n").replace('\r','\n');
    }

    static List<DocumentSegment> segments(String line){
        String s=line==null?"":line;List<DocumentSegment> out=new ArrayList<>();int i=0,start=0;
        while(i<s.length()){
            char ch=s.charAt(i);
            if(ch=='['){int j=s.indexOf(']',i+1);if(j<0)break;pushText(out,s,start,i);out.add(DocumentSegment.bracket(s.substring(i+1,j),i,j+1));i=j+1;start=i;continue;}
            if(ch=='"'||ch=='“'){
                char close=ch=='“'?'”':'"';int j=i+1;boolean found=false;
                while(j<s.length()){char cj=s.charAt(j);boolean isClose=cj==close||(ch=='“'&&cj=='"')||(ch=='"'&&cj=='”');if(isClose&&(j==0||s.charAt(j-1)!='\\')){found=true;break;}j++;}
                if(!found)break;pushText(out,s,start,i);out.add(DocumentSegment.quote(s.substring(i+1,j),String.valueOf(ch),String.valueOf(s.charAt(j)),i,j+1));i=j+1;start=i;continue;
            }
            if(s.startsWith("img(",i)){
                int j=i+4,depth=1;Character quote=null;boolean esc=false;
                while(j<s.length()){
                    char cj=s.charAt(j);if(esc){esc=false;j++;continue;}if(cj=='\\'){esc=true;j++;continue;}if(quote!=null){if(cj==quote)quote=null;j++;continue;}if(cj=='"'||cj=='\''){quote=cj;j++;continue;}if(cj=='(')depth++;else if(cj==')'){depth--;if(depth==0)break;}j++;
                }
                if(j>=s.length())break;pushText(out,s,start,i);out.add(DocumentSegment.image(parseImageArgs(s.substring(i+4,j)),i,j+1));i=j+1;start=i;continue;
            }
            i++;
        }
        pushText(out,s,start,s.length());return List.copyOf(out);
    }
    private static void pushText(List<DocumentSegment>out,String s,int a,int b){if(b>a)out.add(DocumentSegment.text(s.substring(a,b),a,b));}

    static List<String> splitAtFullStops(String line){
        String s=line==null?"":line;List<String>out=new ArrayList<>();int start=0,square=0,paren=0,brace=0;char quote=0;
        for(int i=0;i<s.length();i++){
            char ch=s.charAt(i);
            if(quote!=0){if(ch=='\\'){i++;continue;}boolean close=(quote=='“'&&(ch=='”'||ch=='"'))||(quote=='"'&&(ch=='"'||ch=='”'));if(close)quote=0;continue;}
            if(ch=='"'||ch=='“'){quote=ch;continue;}if(ch=='['){square++;continue;}if(ch==']'){square=Math.max(0,square-1);continue;}if(ch=='('){paren++;continue;}if(ch==')'){paren=Math.max(0,paren-1);continue;}if(ch=='{'){brace++;continue;}if(ch=='}'){brace=Math.max(0,brace-1);continue;}
            if(ch!='.'||square>0||paren>0||brace>0||!sentenceStop(s,i))continue;
            int end=i+1;while(end<s.length()&&s.charAt(end)=='.'&&sentenceStop(s,end))end++;out.add(s.substring(start,end));start=end;i=end-1;
        }
        String tail=s.substring(start);if(!tail.trim().isEmpty()||out.isEmpty())out.add(tail);return List.copyOf(out);
    }
    private static boolean sentenceStop(String s,int i){char prev=i>0?s.charAt(i-1):0,next=i+1<s.length()?s.charAt(i+1):0;boolean numeric=Character.isDigit(next)&&(Character.isDigit(prev)||i==0||Character.isWhitespace(prev)||"+-(,:=".indexOf(prev)>=0);return !numeric;}

    private static ImageDescriptor parseImageArgs(String arg){
        List<String> parts=splitArgs(arg);String src="",w=null,h=null,alt=null,valign="baseline";double wriggle=8;boolean transparent=true;int start=0;
        if(!parts.isEmpty()&&!parts.getFirst().contains("=")){src=strip(parts.getFirst());start=1;}
        for(int i=start;i<parts.size();i++){String x=parts.get(i);int eq=x.indexOf('=');if(eq<0)continue;String k=x.substring(0,eq).trim(),v=strip(x.substring(eq+1));switch(k){case"src"->src=v;case"w"->w=v;case"h"->h=v;case"alt"->alt=v;case"valign"->valign=v;case"wriggle"->{try{wriggle=Double.parseDouble(v);}catch(Exception ignored){}}case"transparent"->transparent=!v.matches("(?i)false|0|no|off");}}
        return new ImageDescriptor(src,w,h,alt,valign,wriggle,transparent);
    }
    private static List<String> splitArgs(String s){List<String>out=new ArrayList<>();StringBuilder cur=new StringBuilder();Character q=null;boolean esc=false;int depth=0;for(int i=0;i<s.length();i++){char ch=s.charAt(i);if(esc){cur.append(ch);esc=false;continue;}if(ch=='\\'){cur.append(ch);esc=true;continue;}if(q!=null){cur.append(ch);if(ch==q)q=null;continue;}if(ch=='"'||ch=='\''){q=ch;cur.append(ch);continue;}if(ch=='('){depth++;cur.append(ch);continue;}if(ch==')'){if(depth>0)depth--;cur.append(ch);continue;}if(ch==','&&depth==0){out.add(cur.toString().trim());cur.setLength(0);continue;}cur.append(ch);}if(!cur.toString().trim().isEmpty())out.add(cur.toString().trim());return out;}
    private static String strip(String v){String s=v==null?"":v.trim();if(s.length()>=2&&((s.charAt(0)=='"'&&s.charAt(s.length()-1)=='"')||(s.charAt(0)=='\''&&s.charAt(s.length()-1)=='\'')))return s.substring(1,s.length()-1);return s;}

    static List<Integer> parseRawUnicodeSequence(String s){
        String v=s==null?"":s.trim();if(v.isEmpty()||!v.matches("(?i)U\\+[0-9a-f]{1,6}(?:[ \\t]+U\\+[0-9a-f]{1,6})*"))return null;List<Integer>out=new ArrayList<>();Matcher m=Pattern.compile("(?i)U\\+([0-9a-f]{1,6})").matcher(v);while(m.find()){int cp=Integer.parseInt(m.group(1),16);if(!Character.isValidCodePoint(cp)||(cp>=0xD800&&cp<=0xDFFF))return null;out.add(cp);}return List.copyOf(out);
    }
}
