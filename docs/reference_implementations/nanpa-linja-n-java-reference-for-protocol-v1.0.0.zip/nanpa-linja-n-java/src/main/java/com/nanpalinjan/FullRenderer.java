package com.nanpalinjan;

import java.awt.*;
import java.awt.font.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.text.AttributedCharacterIterator;
import java.awt.font.TextAttribute;
import java.util.*;
import java.util.List;
import java.util.regex.*;
import javax.imageio.ImageIO;
import java.util.Base64;

/**
 * Full document renderer layered on the frozen numeric Core and the production
 * font renderer.  It ports the canonical JavaScript document segmentation and
 * mixed-run behavior into Java rather than delegating to another language.
 */
final class FullRenderer {
    private static final FontRenderContext FRC=new FontRenderContext(new AffineTransform(),true,true);
    private final ProductionRenderer production;
    private final Path fontDirectory;
    private final Map<String,RenderAdapter> runtimeAdapters;

    FullRenderer(ProductionRenderer production,Path fontDirectory,Map<String,RenderAdapter> runtimeAdapters){
        this.production=production;this.fontDirectory=fontDirectory;this.runtimeAdapters=runtimeAdapters;
    }

    DocumentAst parseInput(String input,RenderOptions options){return DocumentParser.parse(input,options==null?new ParseOptions():options.parser());}

    private record Graphic(Shape foreground,Shape halo,Shape decoration,Color decorationColor,BufferedImage image,String imageHref,double width,double height,double baseline,List<TallyGroup> tallyGroups){}
    private record Logical(RenderRun run,Graphic graphic){}
    private record Placed(RenderRun run,Graphic graphic,double tx,double ty){}
    private record Prepared(DocumentAst ast,RenderPlan plan,List<Placed> placed,Area foreground,Area halo,Area decoration,List<Placed> images,Color fillColor,Color decorationColor){}

    RenderPlan buildPlan(String input,FontPairInfo pair,RenderOptions options) throws Exception{return prepare(input,pair,options).plan;}

    CanvasRenderResult renderCanvas(String input,FontPairInfo pair,RenderOptions options) throws Exception{
        Prepared d=prepare(input,pair,options);
        BufferedImage image=new BufferedImage(Math.max(1,d.plan.width()),Math.max(1,d.plan.height()),BufferedImage.TYPE_INT_ARGB);
        Graphics2D g=image.createGraphics();
        try{
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            if(options.haloEnabled()&&!d.halo.isEmpty()){g.setColor(color(options.haloColor(),Color.WHITE));g.fill(d.halo);}
            g.setColor(d.fillColor);g.fill(d.foreground);
            if(!d.decoration.isEmpty()){g.setColor(d.decorationColor);g.fill(d.decoration);}
            for(Placed p:d.images){if(p.graphic.image()!=null)g.drawImage(p.graphic.image(),(int)Math.round(p.tx),(int)Math.round(p.ty),null);}
        }finally{g.dispose();}
        return new CanvasRenderResult("canvas",input,image,image.getWidth(),image.getHeight(),options.includePlan()?d.plan:null,pair.key(),pair,options);
    }

    PngRenderResult renderPng(String input,FontPairInfo pair,RenderOptions options) throws Exception{
        CanvasRenderResult c=renderCanvas(input,pair,options);ByteArrayOutputStream out=new ByteArrayOutputStream();if(!ImageIO.write(c.canvas(),"png",out))throw new IOException("PNG ImageIO writer unavailable");byte[]b=out.toByteArray();byte[]sig={(byte)137,80,78,71,13,10,26,10};for(int i=0;i<sig.length;i++)if(b.length<=i||b[i]!=sig[i])throw new IOException("Invalid PNG signature");return new PngRenderResult("png",input,b,c,pair.key(),pair,options);
    }

    SvgRenderResult renderSvg(String input,FontPairInfo pair,RenderOptions options) throws Exception{
        Prepared d=prepare(input,pair,options);StringBuilder s=new StringBuilder();s.append("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"").append(d.plan.width()).append("\" height=\"").append(d.plan.height()).append("\" viewBox=\"0 0 ").append(d.plan.width()).append(' ').append(d.plan.height()).append("\">");
        if(options.haloEnabled()&&!d.halo.isEmpty())s.append("<path d=\"").append(ProductionRenderer.svgPath(d.halo)).append("\" fill=\"").append(options.haloColor()).append("\"/>");
        if(!d.foreground.isEmpty())s.append("<path d=\"").append(ProductionRenderer.svgPath(d.foreground)).append("\" fill=\"").append(options.paint().fillStyle()).append("\"/>");
        if(!d.decoration.isEmpty())s.append("<path d=\"").append(ProductionRenderer.svgPath(d.decoration)).append("\" fill=\"").append(hex(d.decorationColor)).append("\"/>");
        for(Placed p:d.images){String href=p.graphic.imageHref();if(href==null||href.isBlank())href=pngDataUrl(p.graphic.image());s.append("<image x=\"").append(n(p.tx)).append("\" y=\"").append(n(p.ty)).append("\" width=\"").append(n(p.graphic.width())).append("\" height=\"").append(n(p.graphic.height())).append("\" href=\"").append(xml(href)).append("\"/>");}
        s.append("</svg>");return new SvgRenderResult("svg",input,s.toString(),options.includePlan()?d.plan:null,pair.key(),pair,options);
    }

    PdfRenderResult renderPdf(String input,FontPairInfo pair,RenderOptions options) throws Exception{
        Prepared d=prepare(input,pair,options);Area f=new Area(d.foreground);f.add(new Area(d.decoration));for(Placed p:d.images)f.add(new Area(new Rectangle2D.Double(p.tx,p.ty,p.graphic.width(),p.graphic.height())));byte[]bytes=ProductionRenderer.vectorPdf(f,d.halo,d.plan.width(),d.plan.height(),options);return new PdfRenderResult("pdf",input,bytes,options.includePlan()?d.plan:null,pair.key(),pair,options);
    }

    VectorDocument vectorDocument(String input,FontPairInfo pair,RenderOptions options) throws Exception{
        Prepared d=prepare(input,pair,options);List<VectorElement> els=new ArrayList<>();if(options.haloEnabled()&&!d.halo.isEmpty())els.add(new VectorElement("halo",null,ProductionRenderer.svgPath(d.halo),options.haloColor(),null,0,0,d.plan.width(),d.plan.height()));
        for(Placed p:d.placed){if(p.graphic.image()!=null){els.add(new VectorElement("image",p.run.id(),null,null,p.graphic.imageHref(),p.tx,p.ty,p.graphic.width(),p.graphic.height()));continue;}Shape x=translate(p.graphic.foreground(),p.tx,p.ty);if(x!=null&&!x.getBounds2D().isEmpty())els.add(new VectorElement("path",p.run.id(),ProductionRenderer.svgPath(x),options.paint().fillStyle(),null,p.tx,p.ty,p.graphic.width(),p.graphic.height()));}
        return new VectorDocument(d.plan.width(),d.plan.height(),els,d.plan.diagnostics(),d.plan);
    }

    private Prepared prepare(String input,FontPairInfo pair,RenderOptions options) throws Exception{
        RenderOptions o=options==null?new RenderOptions():options;DocumentAst ast=DocumentParser.parse(input,o.parser());List<List<Logical>> logicalLines=new ArrayList<>();boolean anyAbbr=false;ParseResult firstParsed=null;
        for(DocumentLine line:ast.lines()){
            List<Logical> runs=new ArrayList<>();int sourceSeg=0;
            for(DocumentSegment seg:line.children()){
                switch(seg.kind()){
                    case "text" -> parseText(seg.value(),seg.sourceStart(),"text",sourceSeg,runs,pair,o);
                    case "bracket" -> parseBracket(seg.value(),seg.sourceStart(),"bracket",sourceSeg,runs,pair,o);
                    case "quote" -> parseQuote(seg,sourceSeg,runs,pair,o);
                    case "image" -> runs.add(imageRun(seg,sourceSeg,pair,o));
                }
                sourceSeg++;
            }
            for(Logical l:runs){if(l.run.numericCartouche()){RenderResult rr=new NanpaRenderer().render(l.run.sourceText(),o.parser());if(rr!=null){anyAbbr|=rr.abbreviated;if(firstParsed==null)firstParsed=rr.parsed;}}}
            logicalLines.add(runs);
        }

        double lineGap=o.layout().lineGap(o.fontSize());double pad=o.paddingPx();double maxLineW=0;List<Double>lineWidths=new ArrayList<>(),lineAsc=new ArrayList<>(),lineDesc=new ArrayList<>();
        for(List<Logical> line:logicalLines){double x=0,asc=0,desc=0;boolean first=true;for(Logical l:line){if(!first)x+=gapBefore(l.run,o);first=false;x+=l.graphic.width();asc=Math.max(asc,l.graphic.baseline());desc=Math.max(desc,Math.max(0,l.graphic.height()-l.graphic.baseline()));}double h=Math.max(o.fontSize(),asc+desc);if(line.isEmpty()){asc=o.fontSize()*0.82;desc=h-asc;}lineWidths.add(x);lineAsc.add(asc);lineDesc.add(desc);maxLineW=Math.max(maxLineW,x);}
        int width=Math.max(1,(int)Math.ceil(maxLineW+2*pad));double totalH=2*pad;for(int i=0;i<logicalLines.size();i++){totalH+=Math.max(o.fontSize(),lineAsc.get(i)+lineDesc.get(i));if(i+1<logicalLines.size())totalH+=lineGap;}int height=Math.max(1,(int)Math.ceil(totalH));
        List<Placed> placed=new ArrayList<>(),images=new ArrayList<>();List<RenderRun> allRuns=new ArrayList<>();List<RenderLinePlan> linePlans=new ArrayList<>();Area foreground=new Area(),halo=new Area(),decoration=new Area();double y=pad;
        for(int li=0;li<logicalLines.size();li++){
            List<Logical> line=logicalLines.get(li);double lw=lineWidths.get(li),asc=lineAsc.get(li),desc=lineDesc.get(li),lh=Math.max(o.fontSize(),asc+desc);double x=pad+switch(o.layout().align()){case"center"->(maxLineW-lw)/2;case"right"->maxLineW-lw;default->0;};double lineStartX=x;List<RenderRun> lineRuns=new ArrayList<>();boolean first=true;int ri=0;
            for(Logical l:line){if(!first)x+=gapBefore(l.run,o);first=false;double ty=y+asc-l.graphic.baseline();double tx=x;Shape fg=translate(l.graphic.foreground(),tx,ty),hs=translate(l.graphic.halo(),tx,ty),ds=translate(l.graphic.decoration(),tx,ty);if(fg!=null)foreground.add(new Area(fg));if(hs!=null)halo.add(new Area(hs));if(ds!=null)decoration.add(new Area(ds));List<TallyGroup> groups=translateGroups(l.graphic.tallyGroups(),tx,ty);RenderRun r=new RenderRun("L"+li+"R"+ri,li,ri,l.run.kind(),l.run.renderMode(),l.run.fontRole(),l.run.numericCartouche(),l.run.hexCartouche(),l.run.binaryCartouche(),l.run.numericBase(),l.run.openerCodepoint(),l.run.closerCodepoint(),l.run.canonicalCodepoints(),l.run.renderCodepoints(),l.run.renderText(),l.run.renderAdapterId(),l.run.sourceText(),l.run.sourceKind(),l.run.sourceStart(),l.run.sourceEnd(),l.run.manualTallies(),groups,l.run.quoted(),l.run.interpretedQuote(),l.run.unrecognized(),l.run.imageAlt(),tx,ty,l.graphic.width(),l.graphic.height(),y+asc);Placed pl=new Placed(r,l.graphic,tx,ty);placed.add(pl);if(l.graphic.image()!=null)images.add(pl);allRuns.add(r);lineRuns.add(r);x+=l.graphic.width();ri++;}
            linePlans.add(new RenderLinePlan(li,ast.lines().get(li).sourceLineIndex(),ast.lines().get(li).sentenceIndexInSourceLine(),lineStartX,y,lw,lh,y+asc,asc,desc,lineRuns));y+=lh+(li+1<logicalLines.size()?lineGap:0);
        }
        List<RenderRun> publicRuns=allRuns;
        // Preserve the pre-full-renderer public-plan shape for a simple plain-text
        // input: historically buildRenderPlan("toki pona") exposed one top-level
        // text run.  Detailed word/glyph runs are now available in lines(), while
        // runs() retains that compatibility contract.
        if(ast.lines().size()==1&&ast.lines().getFirst().children().size()==1&&"text".equals(ast.lines().getFirst().children().getFirst().kind())
                &&!allRuns.isEmpty()&&allRuns.stream().noneMatch(r->r.numericCartouche()||"cartouche".equals(r.fontRole())||"image".equals(r.sourceKind()))){
            String rt=allRuns.stream().map(RenderRun::renderText).reduce("",String::concat);
            List<Integer> cc=new ArrayList<>();List<Integer> rc=new ArrayList<>();for(RenderRun r:allRuns){cc.addAll(r.canonicalCodepoints());rc.addAll(r.renderCodepoints());}
            RenderRun legacy=new RenderRun("",0,0,"text","text","text",false,false,false,0,null,null,cc,rc,rt,pair.renderAdapterId(),input,"text",0,input.length(),List.of(),List.of(),false,false,false,null,pad,pad,maxLineW,Math.max(o.fontSize(),lineAsc.getFirst()+lineDesc.getFirst()),pad+lineAsc.getFirst());
            publicRuns=List.of(legacy);
        }
        RenderPlan plan=new RenderPlan(input,pair.key(),pair,anyAbbr,width,height,ProductionRenderer.featuresFor(o.fontSize()),publicRuns,firstParsed,List.of(),ast,linePlans);return new Prepared(ast,plan,placed,foreground,halo,decoration,images,color(o.paint().fillStyle(),Color.BLACK),color(o.paint().unknownText().color(),Color.BLACK));
    }

    private double gapBefore(RenderRun run,RenderOptions o){return "cartouche".equals(run.fontRole())||run.numericCartouche()?o.layout().cartoucheLeadGap(o.fontSize()):o.layout().glyphGap(o.fontSize());}

    private void parseText(String text,int base,String kind,int segIndex,List<Logical> out,FontPairInfo pair,RenderOptions o) throws Exception{
        if(text==null||text.isEmpty())return;String trimmed=text.trim();if(trimmed.isEmpty())return;int leading=text.indexOf(trimmed);
        List<Integer> raw=DocumentParser.parseRawUnicodeSequence(trimmed);if(raw!=null){out.add(glyphRun(trimmed,raw,base+leading,base+leading+trimmed.length(),kind,false,false,pair,o));return;}
        RenderResult whole=new NanpaRenderer().render(trimmed,o.parser());if(whole!=null){if(o.parser().nasinNanpaPona()&&trimmed.matches("[+]?[0-9]+")){for(String w:nnpWords(trimmed.replace("+","")))out.add(glyphRun(trimmed,List.of(Constants.ALL_WORD_CODEPOINTS.get(w)),base+leading,base+leading+trimmed.length(),kind,false,false,pair,o));return;}out.add(numericRun(trimmed,whole,base+leading,base+leading+trimmed.length(),kind,pair,o));return;}
        Matcher m=Pattern.compile("\\S+").matcher(text);while(m.find()){
            String token=m.group();int start=base+m.start(),end=base+m.end();
            // Extended-mode parenthesis wrappers are long-glyph syntax.  The
            // current profile case only requires their ordinary content.
            String core=token;while(core.startsWith("(")||core.startsWith("{")) {core=core.substring(1);start++;}String trail="";while(!core.isEmpty()&&").;:!?}".indexOf(core.charAt(core.length()-1))>=0){char c=core.charAt(core.length()-1);if(c=='.'&&looksNumeric(core))break;trail=c+trail;core=core.substring(0,core.length()-1);end--;}
            if(core.endsWith(".")&&core.length()>1&&looksNumeric(core.substring(0,core.length()-1))){trail="."+trail;core=core.substring(0,core.length()-1);end--;}
            if(!core.isEmpty())emitCoreToken(core,start,end,kind,segIndex,out,pair,o);
            for(int j=0;j<trail.length();j++){char c=trail.charAt(j);Integer cp=null;if(c=='.')cp=Integer.valueOf(0xF199C);else if(c==':')cp=Integer.valueOf(0xF199D);if(cp!=null)out.add(glyphRun(String.valueOf(c),List.of(cp),end+j,end+j+1,kind,false,false,pair,o));}
        }
    }

    private void emitCoreToken(String core,int start,int end,String kind,int segIndex,List<Logical>out,FontPairInfo pair,RenderOptions o) throws Exception{
        List<Integer> direct=core.codePoints().boxed().toList();
        if(!direct.isEmpty()&&direct.stream().allMatch(FullRenderer::isDirectRenderCodepoint)){out.add(glyphRun(core,direct,start,end,kind,false,false,pair,o));return;}
        RenderResult rr=new NanpaRenderer().render(core,o.parser());if(rr!=null){if(o.parser().nasinNanpaPona()&&core.matches("[+]?[0-9]+")){for(String w:nnpWords(core.replace("+","")))out.add(glyphRun(core,List.of(Constants.ALL_WORD_CODEPOINTS.get(w)),start,end,kind,false,false,pair,o));}else out.add(numericRun(core,rr,start,end,kind,pair,o));return;}
        if(("sitelen-pona-ascii-extended".equals(o.parser().rendererMode())||"sitelen-seli-kiwen".equals(o.parser().rendererMode()))&&(core.contains("-")||core.contains("+"))){List<Integer>cps=compound(core);if(cps!=null){out.add(glyphRun(core,cps,start,end,kind,false,false,pair,o));return;}}
        if(o.parser().autoCartoucheStandaloneProperNames()&&Character.isUpperCase(core.codePointAt(0))){List<Integer>cps=properNameCps(core);if(cps!=null&&!cps.isEmpty()){out.add(cartoucheRun(core,OrdinaryCartouche.of(cps,Collections.nCopies(cps.size(),0),"ucsur"),start,end,kind,pair,o));return;}}
        String norm=normalizeWord(core);Integer cp=Constants.ALL_WORD_CODEPOINTS.get(norm);if(cp!=null){out.add(glyphRun(core,List.of(cp),start,end,kind,false,false,pair,o));return;}
        if(o.parser().showUnknownText()){
            String literal=core;int ls=start,le=end;
            if("standard-sitelen-pona-ascii-core".equals(o.parser().rendererMode())&&literal.length()>=2&&literal.startsWith("'")&&literal.endsWith("'")){literal=literal.substring(1,literal.length()-1);ls++;le--;}
            out.add(literalRun(literal,ls,le,kind,false,false,true,pair,o));
        }
    }

    private void parseBracket(String body,int sourceStart,String kind,int segIndex,List<Logical>out,FontPairInfo pair,RenderOptions o) throws Exception{
        String trimmed=body==null?"":body.trim();RenderResult rr=new NanpaRenderer().render("["+trimmed+"]",o.parser());if(rr!=null){out.add(numericRun(trimmed,rr,sourceStart,sourceStart+body.length(),kind,pair,o));return;}OrdinaryCartouche oc=OrdinaryCartouche.parseBody(trimmed,pair,o.parser());if(oc!=null)out.add(cartoucheRun(trimmed,oc,sourceStart,sourceStart+body.length(),kind,pair,o));else if(o.parser().showUnknownText())out.add(literalRun(trimmed,sourceStart,sourceStart+body.length(),kind,false,false,true,pair,o));
    }

    private void parseQuote(DocumentSegment seg,int segIndex,List<Logical>out,FontPairInfo pair,RenderOptions o) throws Exception{
        String q=unescape(seg.value());if(o.parser().interpretDoubleQuotesAsTeTo()){
            out.add(glyphRun("te",List.of(0x300C),seg.sourceStart(),seg.sourceStart()+1,"interpretedQuote",false,true,pair,o));
            int before=out.size();parseText(q,seg.sourceStart()+1,"interpretedQuote",segIndex,out,pair,o);
            for(int i=before;i<out.size();i++)out.set(i,markInterpreted(out.get(i)));
            out.add(glyphRun("to",List.of(0x300D),Math.max(seg.sourceStart()+1,seg.sourceEnd()-1),seg.sourceEnd(),"interpretedQuote",false,true,pair,o));
        }else out.add(literalRun(q,seg.sourceStart(),seg.sourceEnd(),"quote",true,false,false,pair,o));
    }

    private Logical imageRun(DocumentSegment seg,int segIndex,FontPairInfo pair,RenderOptions o) throws Exception{
        ImageDescriptor d=seg.image();BufferedImage img=loadImage(d,o.fontSize());double baseline="center".equalsIgnoreCase(d.valign())?img.getHeight()*0.75:img.getHeight();RenderRun r=baseRun("cartouche","raster","cartouche",false,false,false,0,null,null,List.of(),List.of(),"",pair.renderAdapterId(),null,"image",seg.sourceStart(),seg.sourceEnd(),List.of(),false,false,false,d.alt());return new Logical(r,new Graphic(null,null,null,Color.BLACK,img,d.src(),img.getWidth(),img.getHeight(),baseline,List.of()));
    }

    private Logical numericRun(String source,RenderResult rr,int start,int end,String sourceKind,FontPairInfo pair,RenderOptions o) throws Exception{
        RenderOptions ro=o.withPaddingPx(0).withIncludePlan(false);ProductionRenderer.Shaped s=production.shape(source,rr,pair,ro);ParseResult p=rr.parsed;Integer op=rr.activeInnerCodepoints.isEmpty()?null:rr.activeInnerCodepoints.getFirst(),cl=rr.activeInnerCodepoints.isEmpty()?null:rr.activeInnerCodepoints.getLast();int base=p.numberBase==null?10:p.numberBase;RenderRun r=baseRun("cartouche","raster","number",true,p.isHex,p.isBinary,base,op,cl,rr.activeInnerCodepoints,rr.activeCodepoints,s.text(),pair.renderAdapterId(),source,sourceKind,start,end,List.of(),false,false,false,null);return new Logical(r,graphic(s,List.of(),null,Color.BLACK));
    }

    private Logical cartoucheRun(String source,OrdinaryCartouche oc,int start,int end,String sourceKind,FontPairInfo pair,RenderOptions o) throws Exception{
        RenderOptions ro=o.withPaddingPx(0).withIncludePlan(false);ProductionRenderer.Shaped s=production.shapeOrdinaryCartouche("["+source+"]",oc,pair,ro);FontRenderAdapters.Adapted a=FontRenderAdapters.adaptOrdinaryCartouche(pair,oc.innerCodepoints);List<Integer>render=a.text().codePoints().boxed().toList();List<TallyGroup>groups=production.manualTallyGroups(oc,pair,ro);List<Integer>canonical=oc.innerCodepoints;List<Integer>semanticTallies=oc.hasManualTallies()?oc.manualTallies:List.of();RenderRun r=baseRun("cartouche","raster","cartouche",false,false,false,0,Constants.CARTOUCHE_START,Constants.CARTOUCHE_END,canonical,render,s.text(),pair.renderAdapterId(),source,sourceKind,start,end,semanticTallies,false,false,false,null);return new Logical(r,graphic(s,groups,null,Color.BLACK));
    }

    private Logical glyphRun(String source,List<Integer>cps,int start,int end,String sourceKind,boolean quoted,boolean interpreted,FontPairInfo pair,RenderOptions o) throws Exception{
        List<Integer>render=adaptRuntime(cps,pair,o.fontSize());String text=codepoints(render);RenderOptions ro=o.withPaddingPx(0).withIncludePlan(false);ProductionRenderer.Shaped s=production.shape(text,null,pair,ro);RenderRun r=baseRun(cps.size()>1?"run":"glyph","text","word",false,false,false,0,null,null,cps,render,text,pair.renderAdapterId(),source,sourceKind,start,end,List.of(),quoted,interpreted,false,null);return new Logical(r,graphic(s,List.of(),null,Color.BLACK));
    }

    private Logical literalRun(String source,int start,int end,String sourceKind,boolean quoted,boolean interpreted,boolean unknown,FontPairInfo pair,RenderOptions o){
        Font f=literalFont(o.fontSize());TextLayout tl=new TextLayout(source.isEmpty()?" ":source,f,FRC);Shape raw=tl.getOutline(null);Rectangle2D b=raw.getBounds2D();double margin=unknown?o.paint().unknownText().paddingPx():0;AffineTransform at=AffineTransform.getTranslateInstance(margin-b.getX(),margin-b.getY());Shape fg=at.createTransformedShape(raw);double baseline=at.getTranslateY();double w=Math.max(1,b.getWidth()+2*margin),h=Math.max(1,b.getHeight()+2*margin);Shape halo=o.haloEnabled()?new BasicStroke(haloWidth(o),BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND).createStrokedShape(fg):null;Shape dec=null;Color dc=Color.BLACK;if(unknown){UnknownTextStyle us=o.paint().unknownText();double rw=w,rh=h;Shape box=new Rectangle2D.Double(0,0,rw,rh);float[]dash=us.dash().isEmpty()?null:toDash(us.dash());BasicStroke st=dash==null?new BasicStroke(us.lineWidthPx()):new BasicStroke(us.lineWidthPx(),BasicStroke.CAP_BUTT,BasicStroke.JOIN_MITER,10,dash,0);dec=st.createStrokedShape(box);dc=color(us.color(),Color.BLACK);}RenderRun r=baseRun("text","raster","literal",false,false,false,0,null,null,List.of(),List.of(),source,pair.renderAdapterId(),source,sourceKind,start,end,List.of(),quoted,interpreted,unknown,null);return new Logical(r,new Graphic(fg,halo,dec,dc,null,null,w,h,baseline,List.of()));
    }

    private static Logical markInterpreted(Logical l){RenderRun r=l.run();RenderRun x=new RenderRun(r.id(),r.lineIndex(),r.runIndex(),r.kind(),r.renderMode(),r.fontRole(),r.numericCartouche(),r.hexCartouche(),r.binaryCartouche(),r.numericBase(),r.openerCodepoint(),r.closerCodepoint(),r.canonicalCodepoints(),r.renderCodepoints(),r.renderText(),r.renderAdapterId(),r.sourceText(),r.sourceKind(),r.sourceStart(),r.sourceEnd(),r.manualTallies(),r.tallyGroups(),r.quoted(),true,r.unrecognized(),r.imageAlt(),r.xPx(),r.yPx(),r.widthPx(),r.heightPx(),r.baselineYPx());return new Logical(x,l.graphic());}

    private RenderRun baseRun(String kind,String mode,String role,boolean numeric,boolean hex,boolean binary,int base,Integer op,Integer cl,List<Integer>canonical,List<Integer>render,String text,String adapter,String source,String sourceKind,int start,int end,List<Integer>tallies,boolean quoted,boolean interpreted,boolean unknown,String imageAlt){return new RenderRun("",0,0,kind,mode,role,numeric,hex,binary,base,op,cl,canonical,render,text,adapter,source,sourceKind,start,end,tallies,List.of(),quoted,interpreted,unknown,imageAlt,0,0,0,0,0);}

    private Graphic graphic(ProductionRenderer.Shaped s,List<TallyGroup>groups,Shape decoration,Color dc){double baseline=s.placement()==null?s.height()*0.8:s.placement().getTranslateY();return new Graphic(s.outline(),s.haloShape(),decoration,dc,null,null,s.width(),s.height(),baseline,groups);}

    private List<Integer> adaptRuntime(List<Integer>cps,FontPairInfo pair,float px){RenderAdapter a=runtimeAdapters.get(pair.renderAdapterId());return a==null?cps:List.copyOf(a.adapt(cps,pair,px));}

    private static boolean isDirectRenderCodepoint(int cp){return (cp>=0xF1900&&cp<=0xF19FF)||cp==0x300C||cp==0x300D;}
    private static List<Integer> compound(String token){String[]parts=token.split("(?=[+-])|(?<=[+-])");List<Integer>out=new ArrayList<>();for(String p:parts){if(p.equals("-")){out.add(0xF1995);continue;}if(p.equals("+")){out.add(0xF1996);continue;}Integer cp=Constants.ALL_WORD_CODEPOINTS.get(normalizeWord(p));if(cp==null)return null;out.add(cp);}return out;}
    private static String normalizeWord(String s){return s==null?"":s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9<>^.]","");}
    private static boolean looksNumeric(String s){return s!=null&&s.matches(".*[0-9].*");}
    private static String codepoints(List<Integer>cps){StringBuilder b=new StringBuilder();for(int cp:cps)b.appendCodePoint(cp);return b.toString();}
    private static String unescape(String s){StringBuilder o=new StringBuilder();for(int i=0;i<s.length();i++){char c=s.charAt(i);if(c!='\\'||i+1>=s.length()){o.append(c);continue;}char n=s.charAt(++i);switch(n){case'"'->o.append('"');case'\\'->o.append('\\');case't'->o.append("    ");case'n'->o.append('\n');default->o.append(n);}}return o.toString();}

    private static List<Integer> properNameCps(String word){if(word==null||!word.matches("[A-Za-z]+")||!word.matches("(?i)[aeijklmnostpuw]+"))return null;Map<Character,Integer>bucket=new HashMap<>();Constants.ALL_WORD_CODEPOINTS.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(e->{String w=e.getKey();if(w.matches("[a-z]+")&&!w.isEmpty())bucket.putIfAbsent(w.charAt(0),e.getValue());});List<Integer>out=new ArrayList<>();for(char c:word.toLowerCase(Locale.ROOT).toCharArray()){Integer cp=bucket.get(c);if(cp==null)return null;out.add(cp);}return out;}

    private static List<String> nnpWords(String digits){try{BigInteger n=new BigInteger(digits);if(n.signum()<0)return List.of();List<String>out=new ArrayList<>();encodeNnp(n,out);return out;}catch(Exception e){return List.of();}}
    private static void encodeNnp(BigInteger n,List<String>out){BigInteger H=BigInteger.valueOf(100),TW=BigInteger.valueOf(20),F=BigInteger.valueOf(5),T=BigInteger.valueOf(2);if(n.signum()==0){out.add("ala");return;}if(n.compareTo(H)>=0){BigInteger[]q=n.divideAndRemainder(H);encodeNnp(q[0],out);out.add("ali");if(q[1].signum()>0)encodeNnp(q[1],out);return;}while(n.compareTo(TW)>=0){out.add("mute");n=n.subtract(TW);}if(n.compareTo(F)>=0){out.add("luka");n=n.subtract(F);}while(n.compareTo(T)>=0){out.add("tu");n=n.subtract(T);}if(n.signum()>0)out.add("wan");}

    private BufferedImage loadImage(ImageDescriptor d,float fontPx) throws IOException{BufferedImage src=null;String href=d.src();if(href.startsWith("data:image/")){int comma=href.indexOf(',');if(comma>0){String meta=href.substring(0,comma),data=href.substring(comma+1);byte[]bytes=meta.contains(";base64")?Base64.getDecoder().decode(data):java.net.URLDecoder.decode(data,StandardCharsets.UTF_8).getBytes(StandardCharsets.ISO_8859_1);try{src=ImageIO.read(new ByteArrayInputStream(bytes));}catch(IOException ignored){src=null;}}}else if(!href.isBlank()){Path p=Path.of(href);if(Files.isRegularFile(p))try{src=ImageIO.read(p.toFile());}catch(IOException ignored){src=null;}}if(src==null)src=new BufferedImage(1,1,BufferedImage.TYPE_INT_ARGB);double w=parseSize(d.w(),fontPx),h=parseSize(d.h(),fontPx);if(Double.isNaN(w)&&Double.isNaN(h))h=fontPx;if(Double.isNaN(w))w=Math.max(1,h*src.getWidth()/Math.max(1.0,src.getHeight()));if(Double.isNaN(h))h=Math.max(1,w*src.getHeight()/Math.max(1.0,src.getWidth()));BufferedImage out=new BufferedImage(Math.max(1,(int)Math.round(w)),Math.max(1,(int)Math.round(h)),BufferedImage.TYPE_INT_ARGB);Graphics2D g=out.createGraphics();try{g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BILINEAR);g.drawImage(src,0,0,out.getWidth(),out.getHeight(),null);}finally{g.dispose();}if(d.transparent())keyTransparent(out,d.wriggle());return out;}
    private static void keyTransparent(BufferedImage im,double wiggle){int key=im.getRGB(0,0),kr=(key>>16)&255,kg=(key>>8)&255,kb=key&255,ka=(key>>>24)&255,w=(int)Math.max(0,wiggle);for(int y=0;y<im.getHeight();y++)for(int x=0;x<im.getWidth();x++){int c=im.getRGB(x,y),a=(c>>>24)&255,r=(c>>16)&255,g=(c>>8)&255,b=c&255;if(Math.abs(r-kr)<=w&&Math.abs(g-kg)<=w&&Math.abs(b-kb)<=w&&Math.abs(a-ka)<=Math.max(8,w))im.setRGB(x,y,c&0x00FFFFFF);}}
    private static double parseSize(String v,float base){if(v==null||v.isBlank())return Double.NaN;String s=v.trim().toLowerCase();try{if(s.endsWith("em"))return Double.parseDouble(s.substring(0,s.length()-2))*base;if(s.endsWith("px"))return Double.parseDouble(s.substring(0,s.length()-2));return Double.parseDouble(s);}catch(Exception e){return Double.NaN;}}

    private Font literalFont(float px){Font base=new Font("SansSerif",Font.PLAIN,Math.round(px));if(fontDirectory!=null){Path p=fontDirectory.resolve("PatrickHand-Regular.ttf");if(Files.isRegularFile(p))try(InputStream in=Files.newInputStream(p)){base=Font.createFont(Font.TRUETYPE_FONT,in).deriveFont(px);}catch(Exception ignored){}}return base.deriveFont(px);}
    private static float[]toDash(List<Float>x){float[]a=new float[x.size()];for(int i=0;i<a.length;i++)a[i]=Math.max(0.1f,x.get(i));return a;}
    private static float haloWidth(RenderOptions o){if(!o.haloEnabled())return 0;if(o.haloWidthPx()>0)return o.haloWidthPx();return Math.max(2f,Math.min(24f,Math.round(Math.max(8f,o.fontSize())*0.10f)));}
    private static Shape translate(Shape s,double x,double y){return s==null?null:AffineTransform.getTranslateInstance(x,y).createTransformedShape(s);}
    private static List<TallyGroup>translateGroups(List<TallyGroup>g,double x,double y){if(g==null||g.isEmpty())return List.of();List<TallyGroup>out=new ArrayList<>();for(TallyGroup t:g){List<Double>c=t.strokeCentersPx().stream().map(v->v+x).toList();out.add(new TallyGroup(t.ownerIndex(),t.count(),t.ownerLeftPx()+x,t.ownerRightPx()+x,t.centerXPx()+x,t.topYPx()+y,t.bottomYPx()+y,t.strokeWidthPx(),c));}return List.copyOf(out);}
    private static Color color(String h,Color d){try{return Color.decode(h);}catch(Exception e){return d;}}
    private static String hex(Color c){return String.format("#%02X%02X%02X",c.getRed(),c.getGreen(),c.getBlue());}
    private static String n(double v){if(Math.abs(v)<1e-6)v=0;return String.format(Locale.ROOT,"%.3f",v).replaceAll("0+$","").replaceAll("\\.$","");}
    private static String xml(String s){return s==null?"":s.replace("&","&amp;").replace("\"","&quot;").replace("<","&lt;").replace(">","&gt;");}
    private static String pngDataUrl(BufferedImage im){if(im==null)return "";try{ByteArrayOutputStream b=new ByteArrayOutputStream();ImageIO.write(im,"png",b);return "data:image/png;base64,"+Base64.getEncoder().encodeToString(b.toByteArray());}catch(Exception e){return "";}}
}
