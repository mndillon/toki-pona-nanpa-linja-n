package com.nanpalinjan;

import java.awt.Color;
import java.awt.BasicStroke;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.font.*;
import java.awt.geom.*;
import java.awt.font.GlyphVector;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.text.AttributedCharacterIterator;
import java.awt.font.TextAttribute;
import java.util.*;
import javax.imageio.ImageIO;

final class ProductionRenderer {
    private final Path fontDirectory;
    private final Map<String,Font> fontCache = new HashMap<>();
    private final Map<String,Map<Integer,Integer>> featureSubstitutionCache = new HashMap<>();
    private static final FontRenderContext FRC = new FontRenderContext(new AffineTransform(), true, true);

    record Shaped(Font font, String text, Shape outline, Shape haloShape, Rectangle2D bounds, int width, int height, AffineTransform placement) {}

    ProductionRenderer(Path fontDirectory) { this.fontDirectory = fontDirectory; }

    Font loadFont(FontPairInfo pair) throws IOException, FontFormatException { return loadFont(pair, true); }

    Font loadBaseFont(FontPairInfo pair) throws IOException, FontFormatException { return loadFont(pair, false); }

    private Font loadFont(FontPairInfo pair, boolean companion) throws IOException, FontFormatException {
        String role = companion ? "companion" : "base";
        String cacheKey = pair.key()+"\u0000"+role;
        Font cached = fontCache.get(cacheKey);
        if (cached != null) return cached;
        if (fontDirectory == null) throw new FileNotFoundException("Production fonts are not configured. Set NANPA_FONT_DIR or use NanpaLinjaN.create(Path fontDirectory).");
        String filename = companion ? pair.companionFilename() : pair.baseFilename();
        Path p = fontDirectory.resolve(filename);
        if (!Files.isRegularFile(p)) throw new FileNotFoundException("Missing production "+role+" font: " + p);
        try (InputStream in = Files.newInputStream(p)) {
            Font f = Font.createFont(Font.TRUETYPE_FONT, in);
            fontCache.put(cacheKey, f);
            return f;
        }
    }

    static List<String> featuresFor(float px) {
        if (px <= 18f) return List.of("ss12");
        if (px <= 29f) return List.of("ss13");
        return List.of();
    }

    private Font sizedFont(Font base, float px) {
        Map<AttributedCharacterIterator.Attribute,Object> attrs = new HashMap<>();
        attrs.put(TextAttribute.SIZE, px);
        attrs.put(TextAttribute.LIGATURES, TextAttribute.LIGATURES_ON);
        attrs.put(TextAttribute.KERNING, TextAttribute.KERNING_ON);
        return base.deriveFont(attrs);
    }

    private static boolean isLegacy(FontPairInfo pair) {
        return pair.renderAdapterId().equals("linja-pona-legacy-v1") || pair.renderAdapterId().equals("linja-sike-legacy-v1");
    }

    static String legacyNumericText(RenderResult rr) {
        if (rr == null) return "";
        StringBuilder b = new StringBuilder("[");
        for (String word : rr.activeWords) {
            if (word.equals(":")) b.append("_:");
            else b.append('_').append(word);
        }
        b.append(']');
        return b.toString();
    }

    static String renderTextFor(String input, RenderResult rr, FontPairInfo pair) {
        if (rr == null) return input == null ? "" : input;
        if (isLegacy(pair)) return legacyNumericText(rr);
        return rr.unicodeText;
    }

    Shaped shape(String input, RenderResult rr, FontPairInfo pair, RenderOptions options) throws Exception {
        if (rr != null) return shapeNumeric(input, rr, pair, options);
        OrdinaryCartouche ordinary = OrdinaryCartouche.parse(input, pair, options.parser());
        if (ordinary != null) return shapeOrdinaryCartouche(input, ordinary, pair, options);
        return shapePlainText(input, pair, options);
    }

    private Shaped shapeNumeric(String input, RenderResult rr, FontPairInfo pair, RenderOptions options) throws Exception {
        Font font = sizedFont(loadFont(pair), options.fontSize());
        String text = renderTextFor(input, rr, pair);
        GlyphVector glyphs = layout(font, text);
        List<String> features = featuresFor(options.fontSize());
        if (!features.isEmpty()) glyphs = applySingleSubstitutionFeature(glyphs, font, pair, features.getFirst());
        return placeShaped(font, text, glyphs.getOutline(), options, null);
    }

    private Shaped shapePlainText(String input, FontPairInfo pair, RenderOptions options) throws Exception {
        Font font = sizedFont(loadBaseFont(pair), options.fontSize());
        String text = input == null ? "" : input;
        GlyphVector glyphs = layout(font, text);
        return placeShaped(font, text, glyphs.getOutline(), options, null);
    }

    private GlyphVector layout(Font font, String text) {
        String value=text==null?"":text;
        if(value.isEmpty()) return font.createGlyphVector(FRC, " ");
        return font.layoutGlyphVector(FRC, value.toCharArray(), 0, value.length(), Font.LAYOUT_LEFT_TO_RIGHT);
    }

    Shaped shapeOrdinaryCartouche(String input, OrdinaryCartouche ordinary, FontPairInfo pair, RenderOptions options) throws Exception {
        Font font = sizedFont(loadBaseFont(pair), options.fontSize());
        FontRenderAdapters.Adapted adapted = FontRenderAdapters.adaptOrdinaryCartouche(pair, ordinary.innerCodepoints);
        String text = adapted.text();
        TextLayout completeLayout = new TextLayout(text, font, FRC);
        Shape raw = completeLayout.getOutline(null);
        Rectangle2D rawBounds = raw.getBounds2D();
        float haloW = haloWidth(options);
        double margin = options.paddingPx() + (options.haloEnabled()?haloW:0);
        AffineTransform placement = AffineTransform.getTranslateInstance(margin - rawBounds.getX(), margin - rawBounds.getY());
        Shape placedBase = placement.createTransformedShape(raw);
        Area foreground = new Area(placedBase);
        Area halo = options.haloEnabled() ? new Area(new BasicStroke(haloW, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND).createStrokedShape(placedBase)) : null;

        int baseW=Math.max(1,(int)Math.ceil(rawBounds.getWidth()+margin*2));
        int baseH=Math.max(1,(int)Math.ceil(rawBounds.getHeight()+margin*2));
        double tallyBottom=-1;
        if(ordinary.hasManualTallies()){
            double bottomRuleY=detectBottomRuleY(placedBase,baseW,baseH,options.fontSize());
            double lift=manualTallyLift(pair,options.parser(),options.fontSize());
            double yTop=bottomRuleY-lift;
            double h=options.fontSize()*0.10;
            double yBottom=yTop+h;
            double strokeW=Math.max(1.5,options.fontSize()*0.045);
            double gap=options.fontSize()*0.075;
            double textOriginX=margin-rawBounds.getX();
            List<FontRenderAdapters.Span> spans=adapted.canonicalSpans();
            for(int i=0;i<ordinary.innerCodepoints.size();i++){
                int count=Math.max(0,Math.min(8,ordinary.manualTallies.get(i)));
                if(count<=0)continue;
                FontRenderAdapters.Span span=spans.get(i+1);
                double left=textOriginX+layoutCaretX(completeLayout,text,span.start());
                double right=textOriginX+layoutCaretX(completeLayout,text,span.end());
                double center=(left+right)/2.0;
                double totalW=count<=1?strokeW:count*strokeW+(count-1)*gap;
                double firstX=center-totalW/2.0+strokeW/2.0;
                double groupLeft=firstX-strokeW/2.0;
                double groupRight=firstX+(count-1)*(strokeW+gap)+strokeW/2.0;
                for(int k=0;k<count;k++){
                    double x=firstX+k*(strokeW+gap);
                    Shape tallyStroke=new BasicStroke((float)strokeW,BasicStroke.CAP_BUTT,BasicStroke.JOIN_MITER)
                            .createStrokedShape(new Line2D.Double(x,yTop,x,yBottom));
                    foreground.add(new Area(tallyStroke));
                }
                if(halo!=null){
                    double padX=haloW*0.85;
                    double padBottom=haloW*0.85;
                    double radius=Math.max(1.25,Math.min(haloW,options.fontSize()*0.045));
                    Shape backing=new RoundRectangle2D.Double(groupLeft-padX,yTop,(groupRight-groupLeft)+padX*2,Math.max(1,(yBottom-yTop)+padBottom),radius*2,radius*2);
                    halo.add(new Area(backing));
                }
                tallyBottom=Math.max(tallyBottom,yBottom);
            }
        }
        Rectangle2D bounds=foreground.getBounds2D();
        int width=Math.max(baseW,(int)Math.ceil(bounds.getMaxX()+options.paddingPx()+(options.haloEnabled()?haloW:0)));
        int height=Math.max(baseH,(int)Math.ceil(Math.max(bounds.getMaxY(),tallyBottom)+options.paddingPx()+(options.haloEnabled()?haloW:0)));
        return new Shaped(font,text,foreground,halo,bounds,width,height,placement);
    }

    private Shaped placeShaped(Font font,String text,Shape raw,RenderOptions options,Shape extraForeground){
        Rectangle2D b=raw.getBounds2D();
        float haloW=haloWidth(options);
        double margin=options.paddingPx()+(options.haloEnabled()?haloW:0);
        if(text==null||text.isEmpty()||b.isEmpty()){
            Shape empty=new Rectangle2D.Double(margin,margin,1,1);
            Shape halo=options.haloEnabled()?new BasicStroke(haloW,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND).createStrokedShape(empty):null;
            return new Shaped(font,text==null?"":text,empty,halo,empty.getBounds2D(),Math.max(1,(int)Math.ceil(1+margin*2)),Math.max(1,(int)Math.ceil(1+margin*2)),AffineTransform.getTranslateInstance(margin,margin));
        }
        AffineTransform placement=AffineTransform.getTranslateInstance(margin-b.getX(),margin-b.getY());
        Area placed=new Area(placement.createTransformedShape(raw));
        if(extraForeground!=null)placed.add(new Area(extraForeground));
        Shape halo=options.haloEnabled()?new BasicStroke(haloW,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND).createStrokedShape(placed):null;
        Rectangle2D pb=placed.getBounds2D();
        int width=Math.max(1,(int)Math.ceil(pb.getMaxX()+margin));
        int height=Math.max(1,(int)Math.ceil(pb.getMaxY()+margin));
        return new Shaped(font,text,placed,halo,pb,width,height,placement);
    }

    private static double layoutCaretX(TextLayout layout,String text,int codepointCount){
        if(codepointCount<=0)return 0;
        int total=text.codePointCount(0,text.length());
        int count=Math.max(0,Math.min(total,codepointCount));
        if(count>=total)return layout.getAdvance();
        int charIndex=text.offsetByCodePoints(0,count);
        try{return layout.getCaretInfo(TextHitInfo.leading(charIndex))[0];}
        catch(Exception e){return layout.getAdvance()*count/Math.max(1.0,total);}
    }

    private static double detectBottomRuleY(Shape shape,int width,int height,float fontPx){
        BufferedImage mask=new BufferedImage(Math.max(1,width),Math.max(1,height),BufferedImage.TYPE_INT_ARGB);
        Graphics2D g=mask.createGraphics();
        try{g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);g.setColor(Color.BLACK);g.fill(shape);}finally{g.dispose();}
        Rectangle2D b=shape.getBounds2D();
        int x0=Math.max(0,(int)Math.floor(b.getMinX()));
        int x1=Math.min(width,(int)Math.ceil(b.getMaxX()));
        int span=Math.max(1,x1-x0);
        int threshold=Math.max(4,(int)Math.round(span*0.18));
        int startY=Math.max(0,Math.min(height-1,(int)Math.floor(b.getCenterY())));
        for(int y=height-1;y>=startY;y--){
            int count=0;
            for(int x=x0;x<x1;x++)if(((mask.getRGB(x,y)>>>24)&255)>8)count++;
            if(count>=threshold)return y+1.0;
        }
        return b.getMaxY();
    }

    private static double manualTallyLift(FontPairInfo pair,ParseOptions parser,float px){
        Object maxO=pair.settings().get("manualTallySmallFontMaxPx");
        Object liftO=pair.settings().get("manualTallySmallFontLiftPx");
        double max=parser!=null&&parser.manualTallySmallFontMaxPx()!=null?parser.manualTallySmallFontMaxPx():(maxO instanceof Number n?n.doubleValue():12.0);
        double lift=parser!=null&&parser.manualTallySmallFontLiftPx()!=null?parser.manualTallySmallFontLiftPx():(liftO instanceof Number n?n.doubleValue():0.0);
        return px<=max?Math.max(0,lift):0;
    }


    List<TallyGroup> manualTallyGroups(OrdinaryCartouche ordinary,FontPairInfo pair,RenderOptions options) throws Exception {
        if(ordinary==null||!ordinary.hasManualTallies())return List.of();
        Font font=sizedFont(loadBaseFont(pair),options.fontSize());
        FontRenderAdapters.Adapted adapted=FontRenderAdapters.adaptOrdinaryCartouche(pair,ordinary.innerCodepoints);
        String text=adapted.text();
        TextLayout completeLayout=new TextLayout(text,font,FRC);
        Shape raw=completeLayout.getOutline(null);
        Rectangle2D rawBounds=raw.getBounds2D();
        float haloW=haloWidth(options);
        double margin=options.paddingPx()+(options.haloEnabled()?haloW:0);
        AffineTransform placement=AffineTransform.getTranslateInstance(margin-rawBounds.getX(),margin-rawBounds.getY());
        Shape placed=placement.createTransformedShape(raw);
        int w=Math.max(1,(int)Math.ceil(rawBounds.getWidth()+margin*2));
        int h=Math.max(1,(int)Math.ceil(rawBounds.getHeight()+margin*2));
        double bottom=detectBottomRuleY(placed,w,h,options.fontSize());
        double lift=manualTallyLift(pair,options.parser(),options.fontSize());
        double yTop=bottom-lift,yBottom=yTop+options.fontSize()*0.10;
        double strokeW=Math.max(1.5,options.fontSize()*0.045),gap=options.fontSize()*0.075;
        double textOriginX=margin-rawBounds.getX();
        List<TallyGroup> groups=new ArrayList<>();
        List<FontRenderAdapters.Span> spans=adapted.canonicalSpans();
        for(int i=0;i<ordinary.innerCodepoints.size();i++){
            int count=Math.max(0,Math.min(8,ordinary.manualTallies.get(i)));if(count<=0)continue;
            FontRenderAdapters.Span span=spans.get(i+1);
            double left=textOriginX+layoutCaretX(completeLayout,text,span.start());
            double right=textOriginX+layoutCaretX(completeLayout,text,span.end());
            double center=(left+right)/2.0;double totalW=count<=1?strokeW:count*strokeW+(count-1)*gap;double firstX=center-totalW/2.0+strokeW/2.0;
            List<Double> centers=new ArrayList<>();for(int k=0;k<count;k++)centers.add(firstX+k*(strokeW+gap));
            groups.add(new TallyGroup(i,count,left,right,center,yTop,yBottom,strokeW,centers));
        }
        return List.copyOf(groups);
    }
    private static float haloWidth(RenderOptions options){
        if(!options.haloEnabled())return 0f;
        if(options.haloWidthPx()>0)return options.haloWidthPx();
        return Math.max(2f,Math.min(24f,Math.round(Math.max(8f,options.fontSize())*0.10f)));
    }

    private static Color parseColor(String hex){
        try{return Color.decode(hex);}catch(Exception e){return Color.WHITE;}
    }


    private GlyphVector applySingleSubstitutionFeature(GlyphVector original, Font font, FontPairInfo pair, String featureTag) throws IOException {
        if (fontDirectory == null || featureTag == null || featureTag.isBlank() || original.getNumGlyphs() == 0) return original;
        String cacheKey = pair.key() + "\u0000" + featureTag;
        Map<Integer,Integer> substitutions = featureSubstitutionCache.get(cacheKey);
        if (substitutions == null) {
            Path fontPath = fontDirectory.resolve(pair.companionFilename());
            substitutions = OpenTypeFeatureSubstitutions.loadSingleSubstitutions(fontPath, featureTag);
            featureSubstitutionCache.put(cacheKey, substitutions);
        }
        if (substitutions.isEmpty()) return original;
        int count = original.getNumGlyphs();
        int[] codes = original.getGlyphCodes(0, count, null);
        boolean changed = false;
        for (int i = 0; i < codes.length; i++) {
            Integer replacement = substitutions.get(codes[i]);
            if (replacement != null && replacement != codes[i]) { codes[i] = replacement; changed = true; }
        }
        if (!changed) return original;

        GlyphVector replaced = font.createGlyphVector(FRC, codes);
        double x = original.getGlyphPosition(0).getX();
        double y = original.getGlyphPosition(0).getY();
        for (int i = 0; i < count; i++) {
            replaced.setGlyphPosition(i, new Point2D.Double(x, y));
            Point2D op = original.getGlyphPosition(i);
            Point2D on = original.getGlyphPosition(i + 1);
            double originalAdvance = original.getGlyphMetrics(i).getAdvanceX();
            double pairAdjustment = (on.getX() - op.getX()) - originalAdvance;
            x += replaced.getGlyphMetrics(i).getAdvanceX() + pairAdjustment;
            y += on.getY() - op.getY();
        }
        replaced.setGlyphPosition(count, new Point2D.Double(x, y));
        return replaced;
    }

    RenderPlan buildPlan(String input, FontPairInfo pair, RenderOptions options) throws Exception {
        RenderResult rr = new NanpaRenderer().render(input, options.parser());
        ParseResult parsed = rr == null ? null : rr.parsed;
        Shaped shaped = shape(input, rr, pair, options);
        RenderRun run;
        boolean abbreviated = rr != null && rr.abbreviated;
        if (rr == null) {
            OrdinaryCartouche ordinary=OrdinaryCartouche.parse(input,pair,options.parser());
            if(ordinary!=null){
                List<Integer> canonical=new ArrayList<>();canonical.add(Constants.CARTOUCHE_START);canonical.addAll(ordinary.innerCodepoints);canonical.add(Constants.CARTOUCHE_END);
                run = new RenderRun("cartouche", false, false, false, 0, Constants.CARTOUCHE_START, Constants.CARTOUCHE_END, canonical, shaped.text(), pair.renderAdapterId());
            } else {
                run = new RenderRun("text", false, false, false, 0, null, null, List.of(), shaped.text(), pair.renderAdapterId());
            }
        } else {
            List<Integer> inner = rr.activeInnerCodepoints;
            Integer opener = inner.isEmpty() ? null : inner.getFirst();
            Integer closer = inner.isEmpty() ? null : inner.getLast();
            int base = parsed.numberBase == null ? 10 : parsed.numberBase;
            run = new RenderRun("number", true, parsed.isHex, parsed.isBinary, base, opener, closer, rr.activeCodepoints, shaped.text(), pair.renderAdapterId());
        }
        return new RenderPlan(input, pair.key(), pair, abbreviated, shaped.width(), shaped.height(), featuresFor(options.fontSize()), List.of(run), parsed, List.of());
    }

    CanvasRenderResult renderCanvas(String input, FontPairInfo pair, RenderOptions options, RenderPlan existingPlan) throws Exception {
        RenderResult rr = new NanpaRenderer().render(input, options.parser());
        Shaped shaped = shape(input, rr, pair, options);
        BufferedImage image = new BufferedImage(shaped.width(), shaped.height(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = image.createGraphics();
        try {
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            if(options.haloEnabled() && shaped.haloShape()!=null){
                g.setColor(parseColor(options.haloColor()));
                g.fill(shaped.haloShape());
            }
            g.setColor(Color.BLACK);
            g.fill(shaped.outline());
        } finally { g.dispose(); }
        RenderPlan plan = options.includePlan() ? (existingPlan != null ? existingPlan : buildPlan(input,pair,options)) : null;
        return new CanvasRenderResult("canvas", input, image, image.getWidth(), image.getHeight(), plan, pair.key(), pair, options);
    }

    PngRenderResult renderPng(String input, FontPairInfo pair, RenderOptions options) throws Exception {
        RenderPlan plan = options.includePlan() ? buildPlan(input,pair,options) : null;
        CanvasRenderResult canvas = renderCanvas(input,pair,options,plan);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        if (!ImageIO.write(canvas.canvas(), "png", out)) throw new IOException("PNG ImageIO writer unavailable");
        byte[] bytes = out.toByteArray();
        byte[] sig={(byte)137,80,78,71,13,10,26,10};
        for(int i=0;i<sig.length;i++) if(bytes.length<=i||bytes[i]!=sig[i]) throw new IOException("PNG export did not produce a valid PNG signature");
        return new PngRenderResult("png",input,bytes,canvas,pair.key(),pair,options);
    }

    SvgRenderResult renderSvg(String input, FontPairInfo pair, RenderOptions options) throws Exception {
        RenderResult rr = new NanpaRenderer().render(input, options.parser());
        Shaped shaped = shape(input, rr, pair, options);
        RenderPlan plan = options.includePlan() ? buildPlan(input,pair,options) : null;
        String d = svgPath(shaped.outline());
        StringBuilder sb=new StringBuilder("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"")
                .append(shaped.width()).append("\" height=\"").append(shaped.height())
                .append("\" viewBox=\"0 0 ").append(shaped.width()).append(' ').append(shaped.height()).append("\">");
        if(options.haloEnabled()&&shaped.haloShape()!=null)sb.append("<path d=\"").append(svgPath(shaped.haloShape())).append("\" fill=\"").append(options.haloColor()).append("\"/>");
        sb.append("<path d=\"").append(d).append("\" fill=\"#000\"/></svg>");
        String svg=sb.toString();
        if (!svg.contains("<svg") || !svg.contains("<path")) throw new IOException("SVG export did not produce a valid SVG payload");
        return new SvgRenderResult("svg",input,svg,plan,pair.key(),pair,options);
    }

    PdfRenderResult renderPdf(String input, FontPairInfo pair, RenderOptions options) throws Exception {
        RenderResult rr = new NanpaRenderer().render(input, options.parser());
        Shaped shaped = shape(input, rr, pair, options);
        RenderPlan plan = options.includePlan() ? buildPlan(input,pair,options) : null;
        byte[] bytes = vectorPdf(shaped.outline(), shaped.haloShape(), shaped.width(), shaped.height(), options);
        if (bytes.length < 8 || !new String(bytes,0,8,StandardCharsets.ISO_8859_1).startsWith("%PDF-1.")) throw new IOException("PDF export did not produce a valid PDF payload");
        return new PdfRenderResult("pdf",input,bytes,plan,pair.key(),pair,options);
    }

    static String svgPath(Shape shape) {
        PathIterator it = shape.getPathIterator(null);
        double[] c = new double[6];
        StringBuilder d = new StringBuilder();
        while (!it.isDone()) {
            int t=it.currentSegment(c);
            switch(t){
                case PathIterator.SEG_MOVETO -> d.append('M').append(n(c[0])).append(' ').append(n(c[1]));
                case PathIterator.SEG_LINETO -> d.append('L').append(n(c[0])).append(' ').append(n(c[1]));
                case PathIterator.SEG_QUADTO -> d.append('Q').append(n(c[0])).append(' ').append(n(c[1])).append(' ').append(n(c[2])).append(' ').append(n(c[3]));
                case PathIterator.SEG_CUBICTO -> d.append('C').append(n(c[0])).append(' ').append(n(c[1])).append(' ').append(n(c[2])).append(' ').append(n(c[3])).append(' ').append(n(c[4])).append(' ').append(n(c[5]));
                case PathIterator.SEG_CLOSE -> d.append('Z');
            }
            d.append(' '); it.next();
        }
        return d.toString().trim();
    }
    private static String n(double v){ if(Math.abs(v)<0.00001)v=0; return String.format(Locale.ROOT,"%.3f",v).replaceAll("0+$","").replaceAll("\\.$",""); }

    static byte[] vectorPdf(Shape shape, Shape haloShape, int width, int height, RenderOptions options) throws IOException {
        StringBuilder contentBuilder=new StringBuilder();
        if(options.haloEnabled()&&haloShape!=null){
            Color hc=parseColor(options.haloColor());
            contentBuilder.append(pdfPath(haloShape,height)).append('\n')
                    .append(String.format(Locale.ROOT,"%.5f %.5f %.5f rg\n",hc.getRed()/255.0,hc.getGreen()/255.0,hc.getBlue()/255.0)).append("f\n");
        }
        contentBuilder.append(pdfPath(shape,height)).append("\n0 0 0 rg\nf\n");
        String content=contentBuilder.toString();
        byte[] cb = content.getBytes(StandardCharsets.ISO_8859_1);
        String[] objs = new String[5];
        objs[1] = "<< /Type /Catalog /Pages 2 0 R >>";
        objs[2] = "<< /Type /Pages /Kids [3 0 R] /Count 1 >>";
        objs[3] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 "+width+" "+height+"] /Contents 4 0 R >>";
        objs[4] = "<< /Length "+cb.length+" >>\nstream\n"+content+"endstream";
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        out.write("%PDF-1.4\n%\u00e2\u00e3\u00cf\u00d3\n".getBytes(StandardCharsets.ISO_8859_1));
        long[] offsets=new long[5];
        for(int i=1;i<=4;i++){ offsets[i]=out.size(); out.write((i+" 0 obj\n"+objs[i]+"\nendobj\n").getBytes(StandardCharsets.ISO_8859_1)); }
        long xref=out.size();
        out.write("xref\n0 5\n0000000000 65535 f \n".getBytes(StandardCharsets.ISO_8859_1));
        for(int i=1;i<=4;i++) out.write(String.format(Locale.ROOT,"%010d 00000 n \n",offsets[i]).getBytes(StandardCharsets.ISO_8859_1));
        out.write(("trailer\n<< /Size 5 /Root 1 0 R >>\nstartxref\n"+xref+"\n%%EOF\n").getBytes(StandardCharsets.ISO_8859_1));
        return out.toByteArray();
    }

    static String pdfPath(Shape shape, int height) {
        PathIterator it=shape.getPathIterator(null); double[] c=new double[6]; StringBuilder b=new StringBuilder(); double cx=0,cy=0;
        while(!it.isDone()){
            int t=it.currentSegment(c);
            switch(t){
                case PathIterator.SEG_MOVETO -> {cx=c[0];cy=c[1];b.append(n(c[0])).append(' ').append(n(height-c[1])).append(" m\n");}
                case PathIterator.SEG_LINETO -> {cx=c[0];cy=c[1];b.append(n(c[0])).append(' ').append(n(height-c[1])).append(" l\n");}
                case PathIterator.SEG_QUADTO -> {double x1=cx+2.0/3.0*(c[0]-cx),y1=cy+2.0/3.0*(c[1]-cy),x2=c[2]+2.0/3.0*(c[0]-c[2]),y2=c[3]+2.0/3.0*(c[1]-c[3]); b.append(n(x1)).append(' ').append(n(height-y1)).append(' ').append(n(x2)).append(' ').append(n(height-y2)).append(' ').append(n(c[2])).append(' ').append(n(height-c[3])).append(" c\n");cx=c[2];cy=c[3];}
                case PathIterator.SEG_CUBICTO -> {b.append(n(c[0])).append(' ').append(n(height-c[1])).append(' ').append(n(c[2])).append(' ').append(n(height-c[3])).append(' ').append(n(c[4])).append(' ').append(n(height-c[5])).append(" c\n");cx=c[4];cy=c[5];}
                case PathIterator.SEG_CLOSE -> b.append("h\n");
            }
            it.next();
        }
        return b.toString();
    }
}
