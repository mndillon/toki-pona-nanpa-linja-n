package com.nanpalinjan;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/** Minimal OpenType GSUB reader for SingleSubst lookups used by the pinned ss12/ss13/ss14 font features. */
final class OpenTypeFeatureSubstitutions {
    private OpenTypeFeatureSubstitutions() {}

    static Map<Integer,Integer> loadSingleSubstitutions(Path fontPath, String featureTag) throws IOException {
        byte[] bytes = Files.readAllBytes(fontPath);
        ByteBuffer b = ByteBuffer.wrap(bytes).order(ByteOrder.BIG_ENDIAN);
        int gsub = findTable(b, "GSUB");
        if (gsub < 0) return Map.of();
        int featureList = gsub + u16(b, gsub + 6);
        int lookupList = gsub + u16(b, gsub + 8);
        List<Integer> lookupIndices = featureLookups(b, featureList, featureTag);
        if (lookupIndices.isEmpty()) return Map.of();
        LinkedHashMap<Integer,Integer> out = new LinkedHashMap<>();
        int lookupCount = u16(b, lookupList);
        for (int lookupIndex : lookupIndices) {
            if (lookupIndex < 0 || lookupIndex >= lookupCount) continue;
            int lookup = lookupList + u16(b, lookupList + 2 + lookupIndex * 2);
            int lookupType = u16(b, lookup);
            int subCount = u16(b, lookup + 4);
            for (int i = 0; i < subCount; i++) {
                int sub = lookup + u16(b, lookup + 6 + i * 2);
                if (lookupType == 1) readSingleSubst(b, sub, out);
                else if (lookupType == 7) {
                    int format = u16(b, sub);
                    if (format != 1) continue;
                    int extensionType = u16(b, sub + 2);
                    long extensionOffset = u32(b, sub + 4);
                    if (extensionType == 1 && extensionOffset <= Integer.MAX_VALUE) {
                        readSingleSubst(b, sub + (int)extensionOffset, out);
                    }
                }
            }
        }
        return Collections.unmodifiableMap(out);
    }

    private static int findTable(ByteBuffer b, String tag) {
        if (b.capacity() < 12) return -1;
        int numTables = u16(b, 4);
        for (int i = 0; i < numTables; i++) {
            int rec = 12 + i * 16;
            if (rec + 16 > b.capacity()) return -1;
            String t = ascii(b, rec, 4);
            if (tag.equals(t)) {
                long off = u32(b, rec + 8);
                long len = u32(b, rec + 12);
                if (off < 0 || off > Integer.MAX_VALUE || off + len > b.capacity()) return -1;
                return (int)off;
            }
        }
        return -1;
    }

    private static List<Integer> featureLookups(ByteBuffer b, int featureList, String wantedTag) {
        int count = u16(b, featureList);
        for (int i = 0; i < count; i++) {
            int rec = featureList + 2 + i * 6;
            if (!wantedTag.equals(ascii(b, rec, 4))) continue;
            int feature = featureList + u16(b, rec + 4);
            int lookupCount = u16(b, feature + 2);
            ArrayList<Integer> out = new ArrayList<>(lookupCount);
            for (int j = 0; j < lookupCount; j++) out.add(u16(b, feature + 4 + j * 2));
            return out;
        }
        return List.of();
    }

    private static void readSingleSubst(ByteBuffer b, int sub, Map<Integer,Integer> out) {
        int format = u16(b, sub);
        int coverage = sub + u16(b, sub + 2);
        List<Integer> glyphs = coverageGlyphs(b, coverage);
        if (format == 1) {
            int delta = i16(b, sub + 4);
            for (int g : glyphs) out.put(g, (g + delta) & 0xffff);
        } else if (format == 2) {
            int glyphCount = u16(b, sub + 4);
            int n = Math.min(glyphCount, glyphs.size());
            for (int i = 0; i < n; i++) out.put(glyphs.get(i), u16(b, sub + 6 + i * 2));
        }
    }

    private static List<Integer> coverageGlyphs(ByteBuffer b, int coverage) {
        int format = u16(b, coverage);
        ArrayList<Integer> out = new ArrayList<>();
        if (format == 1) {
            int count = u16(b, coverage + 2);
            for (int i = 0; i < count; i++) out.add(u16(b, coverage + 4 + i * 2));
        } else if (format == 2) {
            int rangeCount = u16(b, coverage + 2);
            TreeMap<Integer,Integer> indexed = new TreeMap<>();
            for (int i = 0; i < rangeCount; i++) {
                int r = coverage + 4 + i * 6;
                int start = u16(b, r), end = u16(b, r + 2), startIndex = u16(b, r + 4);
                for (int g = start; g <= end; g++) indexed.put(startIndex + (g - start), g);
            }
            out.addAll(indexed.values());
        }
        return out;
    }

    private static String ascii(ByteBuffer b, int pos, int len) {
        byte[] a = new byte[len];
        for (int i = 0; i < len; i++) a[i] = b.get(pos + i);
        return new String(a, StandardCharsets.US_ASCII);
    }
    private static int u16(ByteBuffer b, int pos) { return b.getShort(pos) & 0xffff; }
    private static int i16(ByteBuffer b, int pos) { return b.getShort(pos); }
    private static long u32(ByteBuffer b, int pos) { return b.getInt(pos) & 0xffffffffL; }
}
