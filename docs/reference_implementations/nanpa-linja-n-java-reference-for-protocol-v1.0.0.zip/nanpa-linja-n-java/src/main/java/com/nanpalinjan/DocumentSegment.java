package com.nanpalinjan;
public record DocumentSegment(String kind,String value,ImageDescriptor image,String openQuote,String closeQuote,int sourceStart,int sourceEnd){
 public static DocumentSegment text(String v,int s,int e){return new DocumentSegment("text",v,null,null,null,s,e);}
 public static DocumentSegment bracket(String v,int s,int e){return new DocumentSegment("bracket",v,null,null,null,s,e);}
 public static DocumentSegment quote(String v,String o,String c,int s,int e){return new DocumentSegment("quote",v,null,o,c,s,e);}
 public static DocumentSegment image(ImageDescriptor i,int s,int e){return new DocumentSegment("image",null,i,null,null,s,e);}
}
