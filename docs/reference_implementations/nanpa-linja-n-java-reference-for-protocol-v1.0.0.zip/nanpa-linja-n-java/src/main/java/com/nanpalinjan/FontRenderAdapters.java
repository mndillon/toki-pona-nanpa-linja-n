package com.nanpalinjan;

import java.util.*;

/** Java port of the ordinary-cartouche branches of the canonical JavaScript font render adapters. */
final class FontRenderAdapters {
    record Span(int start,int end){}
    record Adapted(String text,List<Span> canonicalSpans){}
    private FontRenderAdapters(){}

    static Adapted adaptOrdinaryCartouche(FontPairInfo pair,List<Integer> inner){
        List<Integer> full=new ArrayList<>();full.add(Constants.CARTOUCHE_START);full.addAll(inner);full.add(Constants.CARTOUCHE_END);
        String id=pair.renderAdapterId()==null?"identity":pair.renderAdapterId();
        return switch(id){
            case "linja-pona-legacy-v1" -> adaptLegacy(full,"linja-pona",pair.renderAdapterSettings());
            case "linja-sike-legacy-v1" -> adaptLegacy(full,"linja-sike",pair.renderAdapterSettings());
            case "nasin-sitelen-pu-mono-v1" -> adaptPuMono(full,pair.renderAdapterSettings());
            case "linja-lipamanka-v1" -> adaptLipamanka(full,pair.renderAdapterSettings());
            default -> identity(full);
        };
    }

    private static Adapted identity(List<Integer> cps){
        StringBuilder b=new StringBuilder();List<Span>s=new ArrayList<>();int pos=0;
        for(int cp:cps){b.appendCodePoint(cp);s.add(new Span(pos,pos+1));pos++;}
        return new Adapted(b.toString(),List.copyOf(s));
    }

    private static Adapted adaptLegacy(List<Integer> cps,String kind,Map<String,Object> settings){
        StringBuilder b=new StringBuilder();List<Span>sp=blankSpans(cps.size());
        append(b,sp,"[",0);
        for(int i=1;i<cps.size()-1;i++){
            int start=codepointLength(b);
            b.append('_');
            String word=legacyWord(cps.get(i),kind,settings);
            if(word==null)word=String.valueOf((char)0xFFFD);
            b.append(word);
            sp.set(i,new Span(start,codepointLength(b)));
        }
        append(b,sp,"]",cps.size()-1);
        return new Adapted(b.toString(),List.copyOf(sp));
    }

    private static Adapted adaptPuMono(List<Integer> cps,Map<String,Object> settings){
        StringBuilder b=new StringBuilder();List<Span>sp=blankSpans(cps.size());
        for(int i=0;i<cps.size();i++){
            Integer mapped=puMonoMap(cps.get(i));
            if(mapped==null)mapped=replacement(settings);
            appendCp(b,sp,mapped,i);
        }
        return new Adapted(b.toString(),List.copyOf(sp));
    }

    private static Adapted adaptLipamanka(List<Integer> cps,Map<String,Object> settings){
        if(cps.stream().noneMatch(cp->lipamankaNeedsTranslation(cp,settings)))return identity(cps);
        StringBuilder b=new StringBuilder();List<Span>sp=blankSpans(cps.size());
        append(b,sp,"[",0);
        for(int i=1;i<cps.size()-1;i++){
            if(i>1)b.append(' ');
            int start=codepointLength(b);
            String word=legacyWord(cps.get(i),"linja-lipamanka",settings);
            if(word==null)word=String.valueOf((char)0xFFFD);
            b.append(word);
            sp.set(i,new Span(start,codepointLength(b)));
        }
        append(b,sp,"]",cps.size()-1);
        return new Adapted(b.toString(),List.copyOf(sp));
    }

    private static boolean lipamankaNeedsTranslation(int cp,Map<String,Object> settings){
        return cp==0xF199C||cp==0xF199D||cp==0xF199E||cp==0xF1989||cp==0xF198A||cp==0xF198B||cp==0xF198C||cp==0x300C||cp==0x300D||cp==0x3000||cp==0xF19A4||cp==0xF19A6||cp>0xF19A3||((cp==0xF1910||cp==0xF191C)&&!Boolean.FALSE.equals(settings.get("deterministicAlternates")));
    }

    private static Integer puMonoMap(int cp){
        if(cp==0xF1989||cp==0xF198A||cp==0xF198B)return 0xF1941;
        if(cp==0xF198C)return 0xF195A;
        if(cp==0xF199C)return (int)'.';
        if(cp==0xF199D)return (int)':';
        if((cp>=0xF1900&&cp<=0xF1988)||(cp>=0xF19A0&&cp<=0xF19A3)||cp==Constants.CARTOUCHE_START||cp==Constants.CARTOUCHE_END||cp==0x3000||cp==0x300C||cp==0x300D)return cp;
        return null;
    }

    private static String legacyWord(int cp,String kind,Map<String,Object> settings){
        if(cp==0xF199C)return ".";
        if(cp==0xF199D)return ":";
        if(cp==0x3000)return "linja-lipamanka".equals(kind)?"zz":"  ";
        if(cp==0xF1989)return "linja-lipamanka".equals(kind)?"ni<":"ni";
        if(cp==0xF198A)return ("linja-sike".equals(kind)||"linja-lipamanka".equals(kind))?"ni^":"ni";
        if(cp==0xF198B)return ("linja-sike".equals(kind)||"linja-lipamanka".equals(kind))?"ni>":"ni";
        if(cp==0xF198C)return "linja-sike".equals(kind)?"sewi1":"sewi";
        if(cp==0x300C&&"linja-lipamanka".equals(kind))return "te";
        if(cp==0x300D&&"linja-lipamanka".equals(kind))return "to";
        String word=Constants.ALL_CODEPOINT_WORDS.get(cp);
        if(word==null)return null;
        if("linja-pona".equals(kind)&&(cp==0xF19A2||cp==0xF19A4||cp==0xF19A6||cp==0xF19A5))return null;
        if("linja-lipamanka".equals(kind)&&(cp==0xF19A4||cp==0xF19A6||cp==0xF19A5||cp>0xF19A3))return null;
        return word;
    }

    private static int replacement(Map<String,Object>settings){Object v=settings.get("unsupportedReplacementCodepoint");return v instanceof Number n?n.intValue():0xFFFD;}
    private static List<Span> blankSpans(int n){ArrayList<Span>s=new ArrayList<>(n);for(int i=0;i<n;i++)s.add(new Span(0,0));return s;}
    private static void append(StringBuilder b,List<Span>sp,String text,int index){int st=codepointLength(b);b.append(text);sp.set(index,new Span(st,codepointLength(b)));}
    private static void appendCp(StringBuilder b,List<Span>sp,int cp,int index){int st=codepointLength(b);b.appendCodePoint(cp);sp.set(index,new Span(st,codepointLength(b)));}
    private static int codepointLength(StringBuilder b){return b.codePointCount(0,b.length());}
}
