package com.nanpalinjan;

import java.util.List;

/**
 * Converts a full-document AST back into valid nanpa-linja-n source text.
 *
 * <p>The serializer uses the AST's current semantic/editable fields rather than
 * {@link DocumentAst#normalizedInput()} or {@link DocumentLine#sourceText()}.
 * Whitespace stored in text, bracket and quote segment values is therefore
 * preserved. When full-stop splitting creates more than one AST line for the
 * same physical source line, {@link DocumentLine#sourceLineIndex()} is used to
 * concatenate those pieces without inventing a newline. Image descriptors are
 * emitted in a canonical valid {@code img(...)} form.</p>
 */
final class AstTextSerializer {
    private AstTextSerializer() {}

    static String astToText(DocumentAst ast) {
        if (ast == null) throw new IllegalArgumentException("astToText() expects a document AST");
        List<DocumentLine> lines = ast.lines();
        if (lines == null) throw new IllegalArgumentException("astToText() expects a document AST with lines");

        StringBuilder out = new StringBuilder();
        boolean havePrevious = false;
        int previousSourceLineIndex = -1;

        for (int i = 0; i < lines.size(); i++) {
            DocumentLine line = lines.get(i);
            if (line == null) throw new IllegalArgumentException("AST line must not be null");
            int currentSourceLineIndex = line.sourceLineIndex() >= 0 ? line.sourceLineIndex() : i;
            if (havePrevious && currentSourceLineIndex != previousSourceLineIndex) out.append('\n');
            appendLine(out, line);
            havePrevious = true;
            previousSourceLineIndex = currentSourceLineIndex;
        }
        return out.toString();
    }

    private static void appendLine(StringBuilder out, DocumentLine line) {
        List<DocumentSegment> children = line.children();
        if (children == null) return;
        for (DocumentSegment segment : children) appendSegment(out, segment);
    }

    private static void appendSegment(StringBuilder out, DocumentSegment segment) {
        if (segment == null) throw new IllegalArgumentException("AST segment must not be null");
        String kind = segment.kind();
        if (kind == null) throw new IllegalArgumentException("AST segment kind is required");
        switch (kind) {
            case "text" -> out.append(orEmpty(segment.value()));
            case "bracket" -> out.append('[').append(orEmpty(segment.value())).append(']');
            case "quote" -> {
                String open = nonEmpty(segment.openQuote(), "\"");
                String defaultClose = "“".equals(open) ? "”" : "\"";
                String close = nonEmpty(segment.closeQuote(), defaultClose);
                out.append(open).append(orEmpty(segment.value())).append(close);
            }
            case "image" -> appendImage(out, segment.image());
            default -> throw new IllegalArgumentException("Unsupported AST segment kind: " + kind);
        }
    }

    private static void appendImage(StringBuilder out, ImageDescriptor image) {
        ImageDescriptor d = image == null ? new ImageDescriptor("", null, null, null, "baseline", 8, true) : image;
        StringBuilder args = new StringBuilder();
        appendNamedArg(args, "src", d.src(), false);
        appendNamedArg(args, "w", d.w(), false);
        appendNamedArg(args, "h", d.h(), false);
        appendNamedArg(args, "alt", d.alt(), true);
        if (d.valign() != null && !d.valign().isEmpty() && !"baseline".equals(d.valign())) appendNamedArg(args, "valign", d.valign(), true);
        if (Double.compare(d.wriggle(), 8d) != 0) {
            comma(args);
            args.append("wriggle=").append(Double.isFinite(d.wriggle()) ? numberText(d.wriggle()) : quoteImageArgument(String.valueOf(d.wriggle())));
        }
        if (!d.transparent()) {
            comma(args);
            args.append("transparent=false");
        }
        out.append("img(").append(args).append(')');
    }

    private static void appendNamedArg(StringBuilder args, String name, String value, boolean includeEmpty) {
        if (value == null || (!includeEmpty && value.isEmpty())) return;
        comma(args);
        args.append(name).append('=').append(quoteImageArgument(value));
    }

    private static void comma(StringBuilder args) {
        if (!args.isEmpty()) args.append(',');
    }

    private static String quoteImageArgument(String value) {
        String text = value == null ? "" : value;
        if (text.indexOf('\'') < 0) return "'" + text + "'";
        if (text.indexOf('"') < 0) return "\"" + text + "\"";
        return "\"" + text.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }

    private static String numberText(double value) {
        if (value == Math.rint(value)) return Long.toString((long) value);
        return Double.toString(value);
    }

    private static String orEmpty(String value) { return value == null ? "" : value; }
    private static String nonEmpty(String value, String fallback) { return value == null || value.isEmpty() ? fallback : value; }
}
