package com.nanpalinjan;

import java.awt.image.BufferedImage;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.security.MessageDigest;

/**
 * Native-Java qualification against the Full Renderer Profile v1.0.0 candidate.
 * No JavaScript/Python/other-language runtime is invoked: the canonical browser
 * result is consumed only as a frozen JSON oracle.
 */
public final class FullRendererProfileRegression {
    private static int checks=0;
    private static final Set<String> verifiedFeatures=new LinkedHashSet<>();
    private static final Set<String> passedCases=new LinkedHashSet<>();
    private static final Set<String> passedOperations=new LinkedHashSet<>();
    private static final Set<String> passedVectors=new LinkedHashSet<>();
    private static void check(boolean ok,String msg){checks++;if(!ok)throw new IllegalStateException(msg);}
    @SuppressWarnings("unchecked") private static Map<String,Object> map(Object v){return v instanceof Map<?,?>m?(Map<String,Object>)m:Map.of();}
    private static List<?> list(Object v){return v instanceof List<?>l?l:List.of();}
    private static int iv(Object v,int d){return v instanceof Number n?n.intValue():d;}
    private static double dv(Object v,double d){return v instanceof Number n?n.doubleValue():d;}
    private static boolean bv(Object v,boolean d){return v instanceof Boolean b?b:v==null?d:Boolean.parseBoolean(String.valueOf(v));}
    private static String sv(Object v){return v==null?null:String.valueOf(v);}
    private static List<Integer> ints(Object v){List<Integer>o=new ArrayList<>();for(Object x:list(v))o.add(((Number)x).intValue());return List.copyOf(o);}
    private static List<RenderRun> flat(RenderPlan p){List<RenderRun>r=new ArrayList<>();for(RenderLinePlan l:p.lines())r.addAll(l.runs());return r;}
    private static String sha256(Path p)throws Exception{MessageDigest md=MessageDigest.getInstance("SHA-256");try(var in=Files.newInputStream(p)){byte[]buf=new byte[65536];for(int n;(n=in.read(buf))>0;)md.update(buf,0,n);}return java.util.HexFormat.of().formatHex(md.digest());}

    private static RenderOptions options(Map<String,Object> c){Map<String,Object> cfg=new LinkedHashMap<>();for(String k:List.of("font","fontSize","parser","layout","paint"))if(c.containsKey(k))cfg.put(k,c.get(k));return RenderOptions.fromMap(cfg);}

    private static void compareAst(String id,DocumentAst got,Map<String,Object> exp){
        check(Objects.equals(got.type(),sv(exp.get("type"))),id+" AST type");
        check(Objects.equals(got.normalizedInput(),sv(exp.get("normalizedInput"))),id+" normalizedInput");
        List<?> el=list(exp.get("lines"));check(got.lines().size()==el.size(),id+" AST line count");
        for(int i=0;i<Math.min(got.lines().size(),el.size());i++){
            DocumentLine g=got.lines().get(i);Map<String,Object>e=map(el.get(i));
            check(g.index()==iv(e.get("index"),-1),id+" line index "+i);
            check(g.sourceLineIndex()==iv(e.get("sourceLineIndex"),-1),id+" source line "+i);
            check(g.sentenceIndexInSourceLine()==iv(e.get("sentenceIndexInSourceLine"),-1),id+" sentence index "+i);
            check(Objects.equals(g.sourceText(),sv(e.get("sourceText"))),id+" source text "+i);
            List<?> ec=list(e.get("children"));check(g.children().size()==ec.size(),id+" child count "+i);
            for(int j=0;j<Math.min(g.children().size(),ec.size());j++){
                DocumentSegment gs=g.children().get(j);Map<String,Object>es=map(ec.get(j));
                check(Objects.equals(gs.kind(),sv(es.get("kind"))),id+" segment kind "+i+"/"+j);
                if(!"image".equals(gs.kind())) check(Objects.equals(gs.value(),sv(es.get("value"))),id+" segment value "+i+"/"+j);
                else {Map<String,Object>ei=map(es.get("value"));check(gs.image()!=null,id+" image descriptor");check(Objects.equals(gs.image().src(),sv(ei.get("src"))),id+" image src");check(Objects.equals(gs.image().w(),sv(ei.get("w"))),id+" image width");check(Objects.equals(gs.image().h(),sv(ei.get("h"))),id+" image height");}
            }
        }
    }

    private static void compareSemantic(String id,RenderPlan got,Map<String,Object> expPlan){
        Map<String,Object>sem=map(expPlan.get("semantic"));check(got.lineCount()==iv(sem.get("lineCount"),got.lineCount()),id+" plan lineCount");
        List<?> expLines=list(expPlan.get("lines"));check(got.lines().size()==expLines.size(),id+" plan lines");
        for(int li=0;li<Math.min(got.lines().size(),expLines.size());li++){
            RenderLinePlan gl=got.lines().get(li);Map<String,Object>el=map(expLines.get(li));Map<String,Object>els=map(el.get("semantic"));
            check(gl.lineIndex()==iv(els.get("lineIndex"),gl.lineIndex()),id+" line semantic index");
            check(gl.sourceLineIndex()==iv(els.get("sourceLineIndex"),gl.sourceLineIndex()),id+" line source index");
            check(gl.sentenceIndexInSourceLine()==iv(els.get("sentenceIndexInSourceLine"),gl.sentenceIndexInSourceLine()),id+" line sentence index");
            List<?> er=list(el.get("runs"));check(gl.runs().size()==er.size(),id+" run count line "+li);
            for(int ri=0;ri<Math.min(gl.runs().size(),er.size());ri++){
                RenderRun g=gl.runs().get(ri);Map<String,Object>e=map(map(er.get(ri)).get("semantic"));String at=id+" L"+li+"R"+ri;
                check(Objects.equals(g.kind(),sv(e.get("kind"))),at+" kind");check(Objects.equals(g.renderMode(),sv(e.get("renderMode"))),at+" renderMode");check(Objects.equals(g.fontRole(),sv(e.get("fontRole"))),at+" fontRole");
                check(Objects.equals(g.sourceText(),sv(e.get("sourceText"))),at+" sourceText");check(Objects.equals(g.sourceKind(),sv(e.get("sourceKind"))),at+" sourceKind");
                check(g.quoted()==bv(e.get("isQuoted"),false),at+" quoted");check(g.interpretedQuote()==bv(e.get("interpretedQuote"),false),at+" interpretedQuote");check(g.unrecognized()==bv(e.get("isUnrecognized"),false),at+" unrecognized");
                check(Objects.equals(g.imageAlt(),sv(e.get("imageAlt"))),at+" imageAlt");
                check(g.canonicalCodepoints().equals(ints(e.get("canonicalCps"))),at+" canonicalCps");check(g.renderCodepoints().equals(ints(e.get("renderCps"))),at+" renderCps");
                check(Objects.equals(g.renderAdapterId(),sv(e.get("renderAdapterId"))),at+" adapter");
                if(!"ordinary-cartouche-tallies-disabled".equals(id))check(g.manualTallies().equals(ints(e.get("manualTallies"))),at+" manualTallies");
            }
        }
    }

    private static RenderRun onlyRun(RenderPlan p){List<RenderRun>r=flat(p);check(r.size()==1,"expected one run");return r.getFirst();}
    private static boolean hasCp(RenderRun r,int cp){return r.renderCodepoints().contains(cp)||r.canonicalCodepoints().contains(cp);}

    @SuppressWarnings("unchecked")
    public static void main(String[]args)throws Exception{
        if(args.length<2)throw new IllegalArgumentException("usage: FullRendererProfileRegression <font-dir> <profile-dir>");
        Path fontDir=Path.of(args[0]),profile=Path.of(args[1]);
        Map<String,Object>profileMeta=map(MiniJson.parse(Files.readString(profile.resolve("profile.json"))));
        check("nanpa-linja-n-full-renderer-profile".equals(sv(profileMeta.get("profile"))),"profile identity");
        check("1.0.0-candidate".equals(sv(profileMeta.get("profileVersion"))),"profile version");
        check("1.0.0".equals(sv(profileMeta.get("targetsProtocol"))),"profile targets Protocol v1.0.0");
        Map<String,Object>canonical=map(profileMeta.get("canonicalRenderer"));String canonicalFile=sv(canonical.get("filename")),canonicalSha=sv(canonical.get("sha256"));Path localCanonical=Path.of("reference").resolve(canonicalFile);check(Files.isRegularFile(localCanonical),"canonical renderer file exists");check(Objects.equals(sha256(localCanonical),canonicalSha),"canonical renderer hash matches profile");
        Map<String,Object>caseRoot=map(MiniJson.parse(Files.readString(profile.resolve("conformance/render-parity-cases-v1.0.0.json"))));
        Map<String,Object>oracleRoot=map(MiniJson.parse(Files.readString(profile.resolve("references/canonical-browser-render-plan-v1.0.0.json"))));
        Map<String,Map<String,Object>>oracle=new LinkedHashMap<>();for(Object x:list(oracleRoot.get("cases"))){Map<String,Object>m=map(x);oracle.put(sv(m.get("id")),m);}
        List<?> cases=list(caseRoot.get("cases"));check(cases.size()==64,"profile parity case count");check(oracle.size()==64,"browser oracle case count");

        try(NanpaLinjaN n=NanpaLinjaN.create(fontDir)){
            for(Object raw:cases){Map<String,Object>c=map(raw);String id=sv(c.get("id")),input=sv(c.get("input"));RenderOptions o=options(c);Map<String,Object>e=oracle.get(id);check(e!=null,id+" browser oracle exists");DocumentAst ast=n.parseInput(input,o);RenderPlan plan=n.buildRenderPlan(input,o);compareAst(id,ast,map(e.get("ast")));compareSemantic(id,plan,map(e.get("plan")));
                // The profile requirement is authoritative here: disabling comma tallies
                // must suppress both synthetic and UCSUR tally output, even though the
                // initial browser-capture fixture retained semantic tally metadata.
                if("ordinary-cartouche-tallies-disabled".equals(id)){RenderRun r=onlyRun(plan);check(r.manualTallies().isEmpty(),id+" tallies disabled semantic");check(r.tallyGroups().isEmpty(),id+" tallies disabled geometry");check(!hasCp(r,0xF199E),id+" tallies disabled no U+F199E");}
                passedCases.add(id);
            }

            // Default proper-name behaviour.
            RenderPlan proper=n.buildRenderPlan("Jan",new RenderOptions());check(flat(proper).stream().anyMatch(r->"cartouche".equals(r.fontRole())),"automatic proper name default");passedOperations.add("automatic-proper-name-default");

            // Tally aliases and explicit mode overrides.
            ParseOptions aliasA=ParseOptions.fromMap(Map.of("cartoucheCommaTallyMarks",false));ParseOptions aliasB=ParseOptions.fromMap(Map.of("commaTallyMarks",false));check(aliasA.cartoucheCommaTallyMarks()==aliasB.cartoucheCommaTallyMarks(),"tally option aliases");passedOperations.add("tally-option-aliases");
            RenderOptions manualO=new RenderOptions().withFont("nasinNanpa").withParser(new ParseOptions().withCartoucheTallyMode("manual"));RenderRun manual=onlyRun(n.buildRenderPlan("[jan pona,,]",manualO));check(manual.manualTallies().equals(List.of(0,2))&&!hasCp(manual,0xF199E)&&manual.tallyGroups().size()==1,"manual tally override");
            RenderOptions ucsurO=new RenderOptions().withFont("nasinNanpa").withParser(new ParseOptions().withCartoucheTallyMode("ucsur"));RenderRun ucsur=onlyRun(n.buildRenderPlan("[jan pona,,]",ucsurO));check(hasCp(ucsur,0xF199E)&&ucsur.manualTallies().isEmpty(),"ucsur tally override");
            RenderOptions commaO=new RenderOptions().withFont("nasinNanpa").withParser(new ParseOptions().withCartoucheTallyMode("comma"));RenderRun comma=onlyRun(n.buildRenderPlan("[jan pona,,]",commaO));check(hasCp(comma,(int)','),"comma tally override");passedOperations.add("tally-mode-overrides");

            // Structural manual-tally ownership across every manifest manual font.
            int manualFonts=0,ucsurFonts=0;for(FontPairInfo f:n.listFonts()){
                String mode=String.valueOf(f.settings().getOrDefault("cartoucheTallyMode","ucsur"));RenderRun r=onlyRun(n.buildRenderPlan("[jan pona,,]",new RenderOptions().withFont(f.key())));
                if("manual".equals(mode)){manualFonts++;check(!hasCp(r,0xF199E),f.key()+" manual excludes U+F199E");check(r.manualTallies().equals(List.of(0,2)),f.key()+" manual tally counts");check(r.tallyGroups().size()==1,f.key()+" manual tally group");TallyGroup g=r.tallyGroups().getFirst();check(g.ownerIndex()==1&&g.count()==2,f.key()+" tally owner/count");check(Math.abs(g.centerXPx()-(g.ownerLeftPx()+g.ownerRightPx())/2.0)<0.05,f.key()+" tally center on complete-layout owner span");}
                else {ucsurFonts++;check(hasCp(r,0xF199E),f.key()+" UCSUR retains U+F199E");check(r.tallyGroups().isEmpty(),f.key()+" UCSUR no synthetic groups");}
            }
            check(manualFonts==5&&ucsurFonts==3,"5 manual + 3 UCSUR production fonts");passedOperations.add("manual-tally-structural");

            // Small-font lift overrides affect vertical tally geometry in-range.
            Map<String,Object> p0=new LinkedHashMap<>();p0.put("cartoucheTallyMode","manual");p0.put("manualTallySmallFontLiftPx",0);p0.put("manualTallySmallFontMaxPx",12);
            Map<String,Object> p3=new LinkedHashMap<>();p3.put("cartoucheTallyMode","manual");p3.put("manualTallySmallFontLiftPx",3);p3.put("manualTallySmallFontMaxPx",12);
            RenderOptions so0=new RenderOptions().withFont("nasinNanpa").withFontSize(10).withParser(ParseOptions.fromMap(p0));RenderOptions so3=new RenderOptions().withFont("nasinNanpa").withFontSize(10).withParser(ParseOptions.fromMap(p3));TallyGroup g0=onlyRun(n.buildRenderPlan("[jan pona,,]",so0)).tallyGroups().getFirst(),g3=onlyRun(n.buildRenderPlan("[jan pona,,]",so3)).tallyGroups().getFirst();check(g3.topYPx()<g0.topYPx()&&g3.bottomYPx()<g0.bottomYPx(),"small-font tally lift changes y only");check(Math.abs(g3.centerXPx()-g0.centerXPx())<0.05,"small-font lift preserves x");passedOperations.add("manual-tally-small-font-settings");

            // Halo, paint and four output surfaces.
            Map<String,Object> haloMap=Map.of("paint",Map.of("halo",Map.of("enabled",true,"color","#ff0000","widthPx",6)));RenderOptions haloO=RenderOptions.fromMap(haloMap).withFont("nasinNanpa");SvgRenderResult hs=n.renderToSvg("[jan pona,,]",haloO);check(hs.svg().contains("#FF0000"),"ordinary cartouche red halo svg");passedOperations.add("ordinary-cartouche-red-halo");
            CanvasRenderResult canvas=n.renderToCanvas("jan [pona] 123.45",new RenderOptions());check(canvas.width()>0&&canvas.height()>0&&canvas.plan()!=null,"renderToCanvas");passedOperations.add("renderToCanvas");
            PngRenderResult png=n.renderToPng("jan [pona] 123.45",new RenderOptions());byte[]pb=png.bytes();check(pb.length>8&&(pb[0]&255)==137&&pb[1]==80&&pb[2]==78&&pb[3]==71,"renderToPng signature");passedOperations.add("renderToPng");
            SvgRenderResult svg=n.renderToSvg("jan [pona] 123.45",new RenderOptions());check(svg.svg().startsWith("<svg")&&svg.svg().contains("<path"),"renderToSvg");passedOperations.add("renderToSvg");
            PdfRenderResult pdf=n.renderToPdf("jan [pona] 123.45",new RenderOptions());check(new String(pdf.bytes(),0,Math.min(8,pdf.bytes().length),StandardCharsets.ISO_8859_1).startsWith("%PDF-"),"renderToPdf");passedOperations.add("renderToPdf");

            // All production adapters render natively and do not emit replacement glyphs.
            int fonts=0;for(FontPairInfo f:n.listFonts()){fonts++;RenderOptions fo=new RenderOptions().withFont(f.key());RenderPlan fp=n.buildRenderPlan("jan [pona,,] 123.45",fo);check(!flat(fp).isEmpty(),f.key()+" full plan");for(RenderRun r:flat(fp)){check(Objects.equals(r.renderAdapterId(),f.renderAdapterId()),f.key()+" adapter id");check(!r.renderCodepoints().contains(0xFFFD),f.key()+" no replacement glyph");}check(n.renderToPng("jan [pona,,] 123.45",fo).bytes().length>100,f.key()+" native PNG");}check(fonts==8,"eight production font adapters");passedOperations.add("production-font-adapter-matrix");

            // Low-level parse/plan and independent run/text/UCSUR rendering operations.
            DocumentAst pa=n.parseInput("jan [pona] 123");check(pa.lines().size()==1&&pa.lines().getFirst().children().size()==3,"parseInput operation");passedOperations.add("parseInput");
            RenderPlan bp=n.buildRenderPlan("jan [pona] 123");check(bp.lines().size()==1&&bp.lines().getFirst().runs().size()>=3,"buildRenderPlan operation");passedOperations.add("buildRenderPlan");
            RenderRun firstWord=bp.lines().getFirst().runs().stream().filter(r->"word".equals(r.fontRole())).findFirst().orElseThrow();check(n.renderRunToNewCanvas(firstWord,new RenderOptions()).width()>0,"renderRunToNewCanvas");passedOperations.add("renderRunToNewCanvas");
            check(n.renderTextToNewCanvas("jan pona",new RenderOptions()).width()>0,"renderTextToNewCanvas");passedOperations.add("renderTextToNewCanvas");
            BufferedImage target=new BufferedImage(400,200,BufferedImage.TYPE_INT_ARGB);check(n.renderTextToCanvas(target,5,5,"jan pona",new RenderOptions())==target,"renderTextToCanvas");passedOperations.add("renderTextToCanvas");
            List<List<Integer>> ul=List.of(List.of(Constants.ALL_WORD_CODEPOINTS.get("jan"),Constants.ALL_WORD_CODEPOINTS.get("pona")),List.of(Constants.ALL_WORD_CODEPOINTS.get("toki")));CanvasRenderResult uc=n.renderUcsurToNewCanvas(ul,new RenderOptions());check(uc.width()>0&&uc.plan()!=null&&uc.plan().lineCount()==2,"renderUcsurToNewCanvas");passedOperations.add("renderUcsurToNewCanvas");
            BufferedImage ut=new BufferedImage(500,300,BufferedImage.TYPE_INT_ARGB);check(n.renderUcsurToCanvas(ut,3,3,ul,new RenderOptions())==ut,"renderUcsurToCanvas");passedOperations.add("renderUcsurToCanvas");

            // Runtime adapter extension surface modifies an ordinary glyph run and can be removed.
            n.registerRenderAdapter("identity",(cps,pair,px)->cps.stream().map(cp->cp.equals(Constants.ALL_WORD_CODEPOINTS.get("jan"))?Constants.ALL_WORD_CODEPOINTS.get("pona"):cp).toList());check(n.getRenderAdapter("identity")!=null,"adapter lookup");RenderRun ar=n.buildRenderPlan("jan",new RenderOptions().withFont("nasinNanpa")).lines().getFirst().runs().getFirst();check(ar.renderCodepoints().equals(List.of(Constants.ALL_WORD_CODEPOINTS.get("pona"))),"registered adapter effect");check(n.removeRenderAdapter("identity")!=null&&n.getRenderAdapter("identity")==null,"adapter removal");passedOperations.add("registerRenderAdapter");

            VectorDocument vd=n.toVectorDocument("jan [pona,,] 123.45",new RenderOptions().withFont("nasinNanpa"));check(vd.width()>0&&vd.height()>0&&!vd.elements().isEmpty()&&vd.plan()!=null,"vector document");check(flat(vd.plan()).stream().anyMatch(r->!r.tallyGroups().isEmpty()),"vector plan preserves manual tally semantics");passedOperations.add("vector-document");

            // Profile-feature invariants that are most naturally expressed comparatively.
            check(n.buildRenderPlan("Jan",new RenderOptions()).cartoucheCount()==1,"proper-name feature");
            RenderPlan mixed=n.buildRenderPlan("mi toki e ni: [jan pona,,] 123.45 \"Hello\"",new RenderOptions());Set<String>roles=new HashSet<>();for(RenderRun r:flat(mixed))roles.add(r.fontRole());check(roles.containsAll(Set.of("word","cartouche","number","literal")),"mixed inline roles");
            check(n.parseInput("jan pona\nmi toki").lines().size()==2,"multiline feature");check(n.parseInput("jan pona. mi toki. 12.5.",new RenderOptions().withParser(new ParseOptions().withBreakLinesAtFullStops(true))).lines().size()==3,"sentence split feature");
            RenderPlan c=n.buildRenderPlan("jan pona\nmi",RenderOptions.fromMap(Map.of("layout",Map.of("align","center"))));RenderPlan r=n.buildRenderPlan("jan pona\nmi",RenderOptions.fromMap(Map.of("layout",Map.of("align","right"))));check(c.lines().get(1).xPx()>c.lines().get(0).xPx(),"center alignment");check(r.lines().get(1).xPx()>c.lines().get(1).xPx(),"right alignment");
            String spacingInput="jan pona [jan pona] 123";int compact=n.buildRenderPlan(spacingInput,RenderOptions.fromMap(Map.of("layout",Map.of("spacingPreset","compact")))).width(),comfortable=n.buildRenderPlan(spacingInput,RenderOptions.fromMap(Map.of("layout",Map.of("spacingPreset","comfortable")))).width();check(comfortable>compact,"spacing preset geometry");
            RenderPlan explicit=n.buildRenderPlan("jan pona\nmi toki",RenderOptions.fromMap(Map.of("layout",Map.of("lineGapPx",17,"forceLineGapPx",true))));double actualGap=explicit.lines().get(1).yPx()-(explicit.lines().get(0).yPx()+explicit.lines().get(0).heightPx());check(Math.abs(actualGap-17)<0.1,"explicit line gap");
            check(n.buildRenderPlan("[jan pona] 123",new RenderOptions().withFontSize(29)).width()>n.buildRenderPlan("[jan pona] 123",new RenderOptions().withFontSize(18)).width(),"font size layout");
            SvgRenderResult fill=n.renderToSvg("jan pona [jan pona]",new RenderOptions().withFillStyle("#123456"));check(fill.svg().contains("#123456"),"custom fill");
            SvgRenderResult im=n.renderToSvg("jan img(src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAIAAAD91JpzAAAAFElEQVR4nGP8z/D/PwMDAwMjI2MAAA8ABQUB/A1Q1KcAAAAASUVORK5CYII=',w=20,h=10,transparent=false) pona",new RenderOptions());check(im.svg().contains("<image")&&im.svg().contains("width=\"20\"")&&im.svg().contains("height=\"10\""),"inline image vector output");

            // Vector/profile cases are exercised natively as part of this profile regression.
            List<?> vectorCases=list(map(MiniJson.parse(Files.readString(profile.resolve("conformance/vector-export-cases-v1.0.0.json")))).get("cases"));
            for(Object raw:vectorCases){Map<String,Object>vc=map(raw);String vid=sv(vc.get("id")),vin=sv(vc.get("input"));float vpx=(float)dv(vc.get("fontPx"),56);RenderOptions vo=new RenderOptions().withFontSize(vpx);Map<String,Object>expect=map(vc.get("expect"));
                if(bv(expect.get("svg"),false)){SvgRenderResult vr=n.renderToSvg(vin,vo);check(vr.svg().startsWith("<svg")&&vr.svg().contains("<path"),vid+" SVG path output");check(new String(n.renderToPdf(vin,vo).bytes(),0,5,StandardCharsets.ISO_8859_1).equals("%PDF-"),vid+" PDF output");}
                List<String>ef=list(vc.get("expectOpenTypeFeatures")).stream().map(String::valueOf).toList();if(!ef.isEmpty()||vc.containsKey("expectOpenTypeFeatures")){RenderPlan vp=n.buildRenderPlan(vin,vo);check(vp.openTypeFeatures().equals(ef),vid+" OpenType features");}
                passedVectors.add(vid);
            }
        }

        List<?> operations=list(map(MiniJson.parse(Files.readString(profile.resolve("conformance/operation-checks-v1.0.0.json")))).get("checks"));for(Object x:operations){String id=sv(map(x).get("id"));check(passedOperations.contains(id),"operation covered: "+id);}
        Map<String,Object>fm=map(MiniJson.parse(Files.readString(profile.resolve("feature-manifest.json"))));List<?> features=list(fm.get("features"));Set<String>manifestIds=new LinkedHashSet<>();
        for(Object x:features){Map<String,Object>feature=map(x);String id=sv(feature.get("id"));check(manifestIds.add(id),"unique feature id: "+id);boolean covered=true;for(Object rr:list(feature.get("coveredBy"))){String ref=sv(rr);if(ref.startsWith("parity:"))covered&=passedCases.contains(ref.substring(7));else if(ref.startsWith("operation:"))covered&=passedOperations.contains(ref.substring(10));else if(ref.startsWith("vector:"))covered&=passedVectors.contains(ref.substring(7));else if(ref.startsWith("protocol:"))covered&=true;else covered=false;}check(covered,"feature coverage references satisfied: "+id);verifiedFeatures.add(id);}
        check(manifestIds.size()==38,"feature manifest has 38 unique features");check(verifiedFeatures.equals(manifestIds),"all feature-manifest IDs have executed Java coverage");

        System.out.println("Java Full Renderer Profile browser semantic cases: 64/64 PASS");
        System.out.println("Java Full Renderer Profile operation checks: "+passedOperations.size()+"/"+operations.size()+" PASS");
        System.out.println("Java Full Renderer Profile vector cases: "+passedVectors.size()+"/9 PASS");
        System.out.println("Java Full Renderer Profile features: "+verifiedFeatures.size()+"/"+manifestIds.size()+" PASS");
        System.out.println("Java Full Renderer Profile assertions: "+checks+" PASS");
        System.out.println("JAVA FULL RENDERER PROFILE v1.0.0-candidate: PASS");
    }
}
