package com.nanpalinjan;

import java.awt.image.BufferedImage;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public final class ProductionRenderingRegression {
    private static void check(boolean ok,String m){if(!ok)throw new IllegalStateException(m);}
    private static ParseOptions abbreviation(ParseOptions p,boolean ab){return new ParseOptions(p.enableBinaryParsing(),p.enableHexParsing(),p.mode(),p.numericMode(),p.nanpaColonParsing(),p.nanpaColonRendering(),p.relaxedNanpaLinjanParsing(),p.relaxedNanpaLinjanRendering(),ab,ab,p.numericCartoucheStartGlyph());}
    private static int ink(BufferedImage im){int n=0;for(int y=0;y<im.getHeight();y++)for(int x=0;x<im.getWidth();x++)if(((im.getRGB(x,y)>>>24)&255)!=0)n++;return n;}
    @SuppressWarnings("unchecked")
    public static void main(String[] args)throws Exception{
        if(args.length<3)throw new IllegalArgumentException("usage: ProductionRenderingRegression <font-dir> <golden-cases-json> <browser-geometry-json>");
        Path fontDir=Path.of(args[0]), fixture=Path.of(args[1]), geometryFixture=Path.of(args[2]);
        Map<String,Object> root=(Map<String,Object>)MiniJson.parse(Files.readString(fixture));
        List<Object> cases=(List<Object>)root.get("cases");
        check(cases.size()==16,"golden case count must be 16");
        Map<String,Object> geometryRoot=(Map<String,Object>)MiniJson.parse(Files.readString(geometryFixture));
        Map<String,Object> geometryCases=(Map<String,Object>)geometryRoot.get("cases");
        int geometryTolerance=((Number)geometryRoot.getOrDefault("tolerancePx",1)).intValue();
        check(geometryCases.size()==128,"browser geometry case count must be 128");
        int assetPass=0,plans=0,svgPass=0,pngPass=0,pdfPass=0,geometryPass=0,featureGeometryPass=0;
        try(NanpaLinjaN n=NanpaLinjaN.create(fontDir)){
            check(n.listFonts().size()==8,"font pair count");
            for(FontPairInfo f:n.listFonts()){
                Path fp=fontDir.resolve(f.companionFilename());
                check(Files.isRegularFile(fp)&&Files.size(fp)>1000,"missing font asset "+f.key()+": "+fp);
                assetPass++;
                Map<String,String> fullText=new HashMap<>(); Map<String,Integer> fullWidth=new HashMap<>();
                for(Object c0:cases){
                    Map<String,Object> c=(Map<String,Object>)c0;
                    String id=String.valueOf(c.get("id")), input=String.valueOf(c.get("input"));
                    float px=((Number)c.get("fontPx")).floatValue();
                    boolean ab=Boolean.TRUE.equals(c.get("abbreviateNumericCartouches"));
                    RenderOptions o=new RenderOptions().withFont(f.key()).withFontSize(px);
                    o=o.withParser(abbreviation(o.parser(),ab));
                    RenderPlan plan=n.buildRenderPlan(input,o);
                    check(plan.cartoucheCount()==1,f.key()+"/"+id+" cartouche");
                    check(plan.abbreviated()==ab,f.key()+"/"+id+" abbreviation state");
                    if(px==18)check(plan.openTypeFeatures().equals(List.of("ss12")),f.key()+"/"+id+" ss12 selection");
                    if(px==29)check(plan.openTypeFeatures().equals(List.of("ss13")),f.key()+"/"+id+" ss13 selection");
                    if(px>=30)check(plan.openTypeFeatures().isEmpty(),f.key()+"/"+id+" default feature selection");
                    SvgRenderResult svg=n.renderToSvg(input,o);
                    check(svg.svg().contains("<path")&&svg.svg().length()>80,f.key()+"/"+id+" svg path");
                    RenderOptions geometryOptions=o.withPaddingPx(8);
                    RenderPlan geometryPlan=n.buildRenderPlan(input,geometryOptions);
                    Map<String,Object> expectedGeometry=(Map<String,Object>)geometryCases.get(f.key()+"--"+id);
                    check(expectedGeometry!=null,f.key()+"/"+id+" browser geometry fixture");
                    int expectedWidth=((Number)expectedGeometry.get("width")).intValue();
                    int expectedHeight=((Number)expectedGeometry.get("height")).intValue();
                    check(Math.abs(geometryPlan.width()-expectedWidth)<=geometryTolerance,f.key()+"/"+id+" browser width: "+geometryPlan.width()+" vs "+expectedWidth);
                    check(Math.abs(geometryPlan.height()-expectedHeight)<=geometryTolerance,f.key()+"/"+id+" browser height: "+geometryPlan.height()+" vs "+expectedHeight);
                    geometryPass++;
                    if(id.contains("ss12")||id.contains("ss13")) featureGeometryPass++;
                    plans++;svgPass++;
                    if(!ab){ fullText.put(id,plan.runs().getFirst().renderText()); fullWidth.put(id,plan.width()); }
                    else { String baseId=id.replaceFirst("-abbr$",""); check(fullText.containsKey(baseId),f.key()+"/"+id+" matching full case"); check(!fullText.get(baseId).equals(plan.runs().getFirst().renderText()),f.key()+"/"+id+" abbreviated text differs"); check(plan.width()<fullWidth.get(baseId),f.key()+"/"+id+" abbreviated width shorter"); }
                }
                RenderOptions base=new RenderOptions().withFont(f.key());
                CanvasRenderResult canvas=n.renderToCanvas("123.45",base);
                check(ink(canvas.canvas())>20,f.key()+" nonblank canvas");
                PngRenderResult png=n.renderToPng("123.45",base);
                check(png.bytes().length>100&&png.bytes()[0]==(byte)137&&png.bytes()[1]==80,f.key()+" png");pngPass++;
                PdfRenderResult pdf=n.renderToPdf("#ABCDEF",base);
                check(pdf.bytes().length>100&&new String(pdf.bytes(),0,8,StandardCharsets.ISO_8859_1).startsWith("%PDF-1."),f.key()+" pdf");pdfPass++;
            }
        }
        check(plans==128&&svgPass==128,"128 production matrix");
        System.out.println("Java production font assets: "+assetPass+"/8 loadable PASS");
        System.out.println("Java production render-plan matrix: "+plans+"/128 PASS");
        System.out.println("Java production SVG vector matrix: "+svgPass+"/128 PASS");
        System.out.println("JavaScript browser geometry parity: "+geometryPass+"/128 PASS (+/-"+geometryTolerance+" px)");
        System.out.println("Java OpenType ss12/ss13 geometry cases: "+featureGeometryPass+"/32 PASS");
        System.out.println("Java production PNG font-pair smoke: "+pngPass+"/8 PASS");
        System.out.println("Java production PDF vector font-pair smoke: "+pdfPass+"/8 PASS");
    }
}
