# Java reference conformance

Targets:

- **nanpa-linja-n Protocol v1.0.0** / conformance corpus v1.0.2;
- **Production Rendering Profile v1**;
- **nanpa-linja-n Full Renderer Profile v1.0.0-candidate**.

The full-renderer profile is layered on the frozen Protocol v1.0.0 release. It does not modify the frozen numeric Core protocol.

## Mandatory full qualification

```bash
NANPA_FONT_DIR=/path/to/production/fonts ./tools/run_java_regression.sh
```

The runner compiles every shipped Java source with `javac --release 21` into a temporary directory and deletes that directory on exit. The Java implementation does not invoke JavaScript, Node, Chromium, Python, Go, Rust, Dart, or another language implementation. Browser-derived expected structures are consumed only as frozen JSON oracle data.

The full runner asserts the pre-existing qualification surface without regression:

1. 35/35 Core-v1 public API smoke checks;
2. 311/311 parser cases;
3. 15/15 frozen renderer/public-output cases;
4. 9/9 auxiliary API corpus cases;
5. 75/75 equivalence comparisons;
6. 1017/1017 frozen protocol checks, zero failures;
7. logical renderer smoke checks;
8. JavaScript-facade-equivalent high-level API availability and format dispatch;
9. 10 structural browser-renderer parity cases;
10. all eight production base+companion font pairs load through Java2D;
11. 8 production pairs × 16 full/abbreviated numeric cases = 128 render plans;
12. 128/128 SVG vector outputs contain shaped vector paths;
13. nonblank Java-native canvas/PNG output for every production pair;
14. valid vector PDF output for every production pair;
15. 128/128 numeric production cases match the frozen Chromium width/height oracle within +/-1 px;
16. all 32 `ss12`/`ss13` full+abbreviated geometry cases pass;
17. all 8 ordinary-cartouche font routes pass;
18. all 5 manual-tally font routes exclude U+F199E from their shaped font runs;
19. all 3 UCSUR-tally routes retain U+F199E;
20. 8/8 ordinary-cartouche red-halo cases pass;
21. 32/32 frozen Chromium ordinary-cartouche adapter cases pass.

It then qualifies the expanded document renderer against the Full Renderer Profile:

22. 64/64 frozen canonical-browser semantic parity cases pass;
23. 20/20 full-renderer public/structural operation checks pass;
24. 9/9 full-renderer vector/OpenType profile cases pass;
25. 38/38 feature-manifest areas have executed Java coverage;
26. manual-tally ownership is measured from the **complete shaped cartouche layout**, not independently shaped prefix strings;
27. manual-tally small-font lift changes vertical placement without changing owner-glyph horizontal centering;
28. mixed text/cartouche/numeric/quote rendering passes;
29. document AST, multiline/full-stop segmentation, renderer modes, aliases, raw Unicode, unknown text, proper names, inline images, alignment, spacing, fill, halo and font-size layout pass;
30. low-level run/text/UCSUR rendering operations pass;
31. runtime render-adapter registration/removal passes;
32. vector-document generation preserves semantic run/tally metadata;
33. PNG, SVG and PDF production outputs remain valid.

Expected full-profile summary:

```text
Java Full Renderer Profile browser semantic cases: 64/64 PASS
Java Full Renderer Profile operation checks: 20/20 PASS
Java Full Renderer Profile vector cases: 9/9 PASS
Java Full Renderer Profile features: 38/38 PASS
JAVA FULL RENDERER PROFILE v1.0.0-candidate: PASS
ALL CONFIGURED JAVA PARSING, PRODUCTION-RENDERING, AND FULL-RENDERER PROFILE TESTS PASS
```

## Output-equivalence policy

Protocol v1.0.0 and the Full Renderer Profile do not require byte-identical PNG/SVG/PDF serialization between platform renderers. Semantic run structure, parser behavior, adapter behavior, tally routing/ownership, valid output, font behavior and documented geometry invariants are the compatibility target.

Numeric production geometry retains the existing +/-1 px Chromium oracle test. The full-renderer semantic corpus compares exact observable semantic structure while implementation-specific Java2D raster/vector serialization is validated independently.

## Asset policy

Production font binaries are external production assets and are not duplicated into the Java source reference archive. Full qualification requires `NANPA_FONT_DIR` (or `assets/fonts/`) containing all base+companion filenames named by `rendering/production-font-pairs.manifest.json`.

`./tools/run_java_core_regression.sh` remains available for Core-v1-only checks when production assets are intentionally unavailable. It is not a substitute for complete Java reference qualification.

## Language independence

The Java renderer, document parser, manual-tally renderer, raster output, vector output, contact-sheet exporter and regression implementation are Java. Shell files under `tools/` are launchers only. No other programming-language implementation is used to produce or post-process Java rendering output.
