# TypeScript reference conformance

This TypeScript package is a strongly typed facade over the canonical nanpa-linja-n JavaScript production implementation. Parsing and rendering semantics remain in the bundled canonical JavaScript runtime; TypeScript adds declarations, typed loaders and typed facade methods.

## Qualification command

```bash
./tools/run_typescript_regression.sh
```

or, after installing development dependencies:

```bash
npm test
```

The top-level runner is non-fail-fast. It attempts every configured suite and writes one consolidated report to `test-output/typescript-regression-report.txt`.

## Current qualification matrix

1. TypeScript build.
2. Bundled canonical JavaScript runtime hash integrity.
3. TypeScript declaration/type-surface compilation.
4. Exact typed-wrapper export identity/parity with the bundled JavaScript modules.
5. Typed facade unit tests.
6. `astToText` regression tests.
7. Frozen Protocol v1.0.0 parser/API corpus: 1,030 checks.
8. Canonical syntax corpus: 28 cases, plus 5 production font-adapter cases.
9. Canonical full-renderer semantic corpus: 254 cases.
10. Browser production facade/output regression covering Canvas, PNG, SVG, PDF, production font selection/adaptation and AST edit/render round-trips.

The canonical syntax and full-renderer corpora are checked against the pinned renderer SHA-256:

`a7ec74577e1663ba980e49e1ca962e59c8397246190063fb84d02fb525b3f10f`

The bundled production facade is pinned at:

`e8e8cbd2b7a5f4aabff25da17ce5322b4a6684807e0f9d339d5dffff889f8884`
