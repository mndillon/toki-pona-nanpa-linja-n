#!/usr/bin/env node
import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { runInBrowserWithCanonicalRenderer } from './lib/browser-renderer-harness.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const corpusPath = path.join(root, 'conformance/full-renderer-canonical-v1.0.1/cases.json');
const referencePath = path.join(root, 'runtime/reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js');
const dataText = await fs.readFile(corpusPath, 'utf8');
const data = JSON.parse(dataText);
if (data.caseCount !== data.cases?.length) {
  console.error(`corpus count mismatch: declared ${data.caseCount} actual ${data.cases?.length ?? 0}`);
  process.exit(1);
}
const actualHash = crypto.createHash('sha256').update(await fs.readFile(referencePath)).digest('hex');
if (actualHash !== data.authority?.sha256) {
  console.error(`authority hash mismatch: got ${actualHash} want ${data.authority?.sha256}`);
  process.exit(1);
}
const payload = Buffer.from(dataText, 'utf8').toString('base64');
const result = await runInBrowserWithCanonicalRenderer(root, `(async()=>{
  const data=JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(${JSON.stringify(payload)}),c=>c.charCodeAt(0))));
  const failures=[]; let passed=0;
  const adapters={nasinNanpa:'identity',sitelenSeliKiwen:'identity',fairfaxHd:'identity',fairfaxPonaHd:'identity',linjaPona:'linja-pona-legacy-v1',linjaSike:'linja-sike-legacy-v1',nasinSitelenPuMono:'nasin-sitelen-pu-mono-v1',linjaLipamanka:'linja-lipamanka-v1'};
  const eq=(a,b)=>JSON.stringify(a)===JSON.stringify(b), arr=v=>Array.isArray(v)?v:[];
  function compareAst(a,e){const x=[];if(!a||typeof a!=='object')return['AST missing'];if(a.type!==e?.type)x.push('type');if(a.normalizedInput!==e?.normalizedInput)x.push('normalizedInput');const al=arr(a.lines),el=arr(e?.lines);if(al.length!==el.length)return[...x,'line count'];for(let i=0;i<al.length;i++){for(const k of ['index','sourceLineIndex','sentenceIndexInSourceLine','sourceText'])if(al[i]?.[k]!==el[i]?.[k])x.push('line['+i+'].'+k);const ac=arr(al[i]?.children),ec=arr(el[i]?.children);if(ac.length!==ec.length){x.push('line['+i+'] child count');continue;}for(let j=0;j<ac.length;j++){for(const k of ['kind','openQuote','closeQuote'])if((ac[j]?.[k]??null)!==(ec[j]?.[k]??null))x.push('child '+i+','+j+' '+k);const av=ac[j]?.kind==='image'?null:(ac[j]?.value??null),ev=ec[j]?.value??null;if(av!==ev)x.push('child '+i+','+j+' value');const ai=ac[j]?.image??ac[j]?.value,ei=ec[j]?.image;if(ei!=null){if(!ai||typeof ai!=='object'){x.push('child '+i+','+j+' image missing');continue;}for(const k of ['src','w','h','alt','valign','wriggle','transparent'])if((ai?.[k]??null)!==(ei?.[k]??null))x.push('image '+i+','+j+' '+k);}}}return x;}
  function compareRun(a,e,randomCps){const x=[];const checks=[['kind',a?.kind,e?.kind],['renderMode',a?.renderMode,e?.renderMode],['fontRole',a?.fontRole,e?.fontRole],['sourceText',a?.sourceText??'',e?.sourceText??''],['sourceKind',a?.sourceKind??'',e?.sourceKind??''],['renderAdapterId',a?.renderAdapterId??'',e?.renderAdapterId??''],['requestedRenderAdapterId',a?.requestedRenderAdapterId??'',e?.requestedRenderAdapterId??''],['isQuoted',!!a?.isQuoted,!!e?.isQuoted],['interpretedQuote',!!a?.interpretedQuote,!!e?.interpretedQuote],['isUnrecognized',!!a?.isUnrecognized,!!e?.isUnrecognized],['manualTallies',a?.manualTallies??null,e?.manualTallies??null],['isNumericCartouche',!!a?._element?.isNumericCartouche,!!e?.isNumericCartouche],['isLiteralCartouche',!!a?._element?.isLiteralCartouche,!!e?.isLiteralCartouche],['imageAlt',a?.imageAlt??null,e?.imageAlt??null],['encodedText',a?.encodedText??null,e?.encodedText??null]];if(!randomCps)checks.push(['canonicalCps',arr(a?.canonicalCps),arr(e?.canonicalCps)],['canonicalFullCps',arr(a?.canonicalFullCps),arr(e?.canonicalFullCps)],['renderCps',arr(a?.renderCps),arr(e?.renderCps)]);for(const [k,av,ev] of checks)if(!eq(av,ev))x.push(k);return x;}
  const renderer=await globalThis.SitelenRenderer.create({});
  for(const tc of data.cases){const errors=[];try{if(!tc.oracle?.ok)errors.push('oracle generation failed');else{const plan=await renderer.buildRenderPlan({input:tc.input,parser:tc.parser,fonts:{renderAdapterId:adapters[tc.font]||'identity'}});if(tc.compareAst)errors.push(...compareAst(plan.ast,tc.oracle.ast).map(v=>'AST '+v));const ar=arr(plan?.lines).flatMap(line=>arr(line?.runs)),er=arr(tc.oracle.runs);if(ar.length!==er.length)errors.push('run count');else for(let i=0;i<ar.length;i++)errors.push(...compareRun(ar[i],er[i],!!tc.randomCps).map(v=>'run['+i+'] '+v));}}catch(e){errors.push(String(e?.stack||e));}if(errors.length)failures.push({id:tc.id,errors});else passed++;}
  return {passed,total:data.cases.length,failures};
})()`, { timeoutMs: 240000 });

console.log(`Canonical full-renderer semantic corpus through TypeScript/browser wrapper: ${result.passed}/${result.total} PASS`);
if (result.failures?.length) {
  console.error(`FAILED CASES (${result.failures.length}):`);
  for (const item of result.failures) console.error(`[${item.id}] ${item.errors.join('; ')}`);
  process.exit(1);
}
console.log('TYPESCRIPT CANONICAL FULL-RENDERER CONFORMANCE PASS');
