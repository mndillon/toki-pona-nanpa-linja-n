#!/usr/bin/env node
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const expected = {
  'runtime/src/nanpa-linja-n.js': '81b9b0e9c16ead4f2021f8ac5c6187764b3cf96b4f01a33cb4ab37af2b3d92d1',
  'runtime/reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js': '935b6a3e664d1ef25f496b8f7af1f8e3cfd3082c64bcec46b2dabf09e3447a7c',
  'runtime/reference/sitelen-font-pair-controller.js': 'b842c7a398ac6c563634e144a9f4b48793deb1be2482a6973d99c73afcfc150e',
  'runtime/reference/sitelen-vector-exporter.js': '8ca2471de24352e5deebce940343392ce55d9a7e2811bbf4a2844beb957bf206',
  'runtime/assets/fonts/preloaded-font-pairs.manifest.json': '2457cbf1c6b8d2dd2c63b5b1cf7481664251b7c6cb1d505f2b3d515432cf6f31',
  'runtime/assets/wasm/sitelen_vector_wasm.js': 'a5b22d3954d1f191ea2bced84cacebbb32f935a31bb06fb1f37d58f11b9ddb7d',
  'runtime/assets/wasm/sitelen_vector_wasm_bg.wasm': '77be5130d9453e1de68f7520d3bf40733d66d86ed2f9f99780805f25d0aa8da4',
};

let failed = 0;
for (const [rel, wanted] of Object.entries(expected)) {
  const data = await fs.readFile(path.join(root, rel));
  const actual = crypto.createHash('sha256').update(data).digest('hex');
  if (actual === wanted) console.log(`PASS ${rel} ${actual}`);
  else { console.error(`FAIL ${rel}\n  actual:   ${actual}\n  expected: ${wanted}`); failed++; }
}
if (failed) process.exit(1);
console.log('bundled JavaScript production runtime hashes: PASS');
