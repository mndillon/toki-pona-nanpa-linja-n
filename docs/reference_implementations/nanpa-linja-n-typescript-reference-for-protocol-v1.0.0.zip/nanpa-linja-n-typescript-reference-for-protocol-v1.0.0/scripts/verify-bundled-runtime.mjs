#!/usr/bin/env node
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const expected = {
  'runtime/src/nanpa-linja-n.js': 'e8e8cbd2b7a5f4aabff25da17ce5322b4a6684807e0f9d339d5dffff889f8884',
  'runtime/src/font-zip.js': '4e70d04dcc7504ea90131f1704ca608ef46f73f47b8e16197650d8c7fb3a6202',
  'runtime/reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js': 'a7ec74577e1663ba980e49e1ca962e59c8397246190063fb84d02fb525b3f10f',
  'runtime/reference/sitelen-font-pair-controller.js': '404cb0a2853c3ebe14eaddc03ef63f3e0c465a7a71b13d229543757901808368',
  'runtime/reference/sitelen-vector-exporter.js': '86189f40830076034f0c7e63eb561fa10a6472bca99f2d0885c4f933bc1d0493',
  'resources/fonts.zip': 'e3c66bbb17c5559f6a87790ae1a9c57fbaaa81e2ec1c6f24cc954be5b3f76dc2',
  'runtime/assets/wasm/sitelen_vector_wasm.js': 'a5b22d3954d1f191ea2bced84cacebbb32f935a31bb06fb1f37d58f11b9ddb7d',
  'runtime/assets/wasm/sitelen_vector_wasm_bg.wasm': '77be5130d9453e1de68f7520d3bf40733d66d86ed2f9f99780805f25d0aa8da4',
};

let failed = 0;
for (const [rel, wanted] of Object.entries(expected)) {
  const data = await fs.readFile(path.join(root, rel));
  const actual = crypto.createHash('sha256').update(data).digest('hex');
  if (actual === wanted) console.log(`PASS ${rel} ${actual}`);
  else { console.error(`FAIL ${rel}\n  actual:   ${actual}\n  expected: ${wanted}`); failed++; }
}
if (failed) process.exit(1);
console.log('bundled JavaScript production runtime hashes: PASS');
