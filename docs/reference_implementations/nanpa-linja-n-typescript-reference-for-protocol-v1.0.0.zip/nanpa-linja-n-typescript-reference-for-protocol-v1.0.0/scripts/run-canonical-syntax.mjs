#!/usr/bin/env node
import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { runInBrowserWithCanonicalRenderer } from './lib/browser-renderer-harness.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const corpusPath = path.join(root, 'conformance/canonical-syntax-v1.0.1-phase1/cases.json');
const referencePath = path.join(root, 'runtime/reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js');
const dataText = await fs.readFile(corpusPath, 'utf8');
const data = JSON.parse(dataText);
const actualHash = crypto.createHash('sha256').update(await fs.readFile(referencePath)).digest('hex');
if (actualHash !== data.authority?.sha256) {
  console.error(`authority hash mismatch: got ${actualHash} want ${data.authority?.sha256}`);
  process.exit(1);
}
const payload = Buffer.from(dataText, 'utf8').toString('base64');
const result = await runInBrowserWithCanonicalRenderer(root, `(async()=>{
  const data=JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(${JSON.stringify(payload)}),c=>c.charCodeAt(0))));
  const failures=[]; let passed=0, adapterPassed=0;
  const adapters={linjaPona:'linja-pona-legacy-v1',linjaSike:'linja-sike-legacy-v1'};
  const cps=(values)=>(values||[]).map(v=>typeof v==='string'&&/^U\\+/i.test(v)?Number.parseInt(v.slice(2),16):Number(v));
  const runsFrom=(plan)=>(plan?.lines||[]).flatMap(line=>line.runs||[]);
  const eq=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
  const renderer=await globalThis.SitelenRenderer.create({});
  for(const tc of data.cases||[]){
    const local=[];
    try{
      const plan=await renderer.buildRenderPlan({input:tc.input,parser:{mode:tc.rendererMode}}); const runs=runsFrom(plan);
      if('expectedNormalizedInput' in tc&&plan.ast?.normalizedInput!==tc.expectedNormalizedInput)local.push('normalizedInput');
      if(tc.expectedRuns){const got=runs.map(r=>r.canonicalCps||[]),want=tc.expectedRuns.map(cps);if(!eq(got,want))local.push('runs canonical cps');}
      else if(runs.length!==1)local.push('run count');
      else {const r=runs[0],want=cps(tc.expectedCanonicalCodepoints);if(!eq(r.canonicalCps||[],want))local.push('canonical cps');if('expectedSourceText' in tc&&(r.sourceText??'')!==tc.expectedSourceText)local.push('sourceText');if('expectedFontRole' in tc&&r.fontRole!==tc.expectedFontRole)local.push('fontRole');if('expectedRenderText' in tc){const wt=/^U\\+/i.test(String(tc.expectedRenderText))?String.fromCodePoint(...cps([tc.expectedRenderText])):tc.expectedRenderText;if((r.encodedText??'')!==wt)local.push('renderText');}}
    }catch(e){local.push(String(e?.stack||e));}
    if(local.length)failures.push({id:tc.id,errors:local});else passed++;
  }
  for(const tc of data.fontAdapterCases||[]){
    const local=[];
    try{const plan=await renderer.buildRenderPlan({input:tc.input,parser:{mode:'sitelen-pona-ascii-extended'},fonts:{renderAdapterId:adapters[tc.font]||'identity'}});const runs=runsFrom(plan);if(runs.length!==1)local.push('run count');else{const r=runs[0],renderText=r.renderCps?String.fromCodePoint(...r.renderCps):(r.encodedText??'');if('expectedRenderText' in tc&&renderText!==tc.expectedRenderText)local.push('renderText');if('expectedRenderCodepoints' in tc&&!eq(r.renderCps||[],cps(tc.expectedRenderCodepoints)))local.push('render cps');if(tc.mustDifferFromCanonicalCodepoints&&eq(r.renderCps||[],r.canonicalCps||[]))local.push('adapter did not alter cps');}}catch(e){local.push(String(e?.stack||e));}
    if(local.length)failures.push({id:tc.id,errors:local});else adapterPassed++;
  }
  return {passed,adapterPassed,total:(data.cases||[]).length,adapterTotal:(data.fontAdapterCases||[]).length,failures};
})()`, { timeoutMs: 180000 });

console.log(`Canonical syntax cases through TypeScript/browser wrapper: ${result.passed}/${result.total} PASS`);
console.log(`Canonical font-adapter cases through TypeScript/browser wrapper: ${result.adapterPassed}/${result.adapterTotal} PASS`);
if (result.failures?.length) {
  console.error(`FAILURES (${result.failures.length} case(s)):`);
  for (const item of result.failures) console.error(` - ${item.id}: ${item.errors.join('; ')}`);
  process.exit(1);
}
console.log('TYPESCRIPT CANONICAL SYNTAX + FONT ADAPTER CONFORMANCE PASS');
