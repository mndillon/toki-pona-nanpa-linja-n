import { importBundledNanpaParser } from "../src/index.js";

const parser = await importBundledNanpaParser();
const parsed = parser.parseNumber("2026-09-13", {
  numericMode: "uniform",
  relaxedNanpaLinjanParsing: true,
  relaxedNanpaLinjanRendering: true,
  nanpaColonParsing: true,
  nanpaColonRendering: true,
});

if (!parsed) throw new Error("Unexpected parse failure");
console.log(parsed.properName, parsed.tpWords, parsed.ucsurCodepoints);
