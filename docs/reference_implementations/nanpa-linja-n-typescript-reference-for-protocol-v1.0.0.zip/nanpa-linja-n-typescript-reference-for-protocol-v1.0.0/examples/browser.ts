import { NanpaLinjaN } from "../src/index.js";

const nanpa = await NanpaLinjaN.create();

const result = await nanpa.renderToCanvas("12:30", {
  font: "nasinNanpa",
  fontSize: 56,
});

document.body.append(result.canvas);
