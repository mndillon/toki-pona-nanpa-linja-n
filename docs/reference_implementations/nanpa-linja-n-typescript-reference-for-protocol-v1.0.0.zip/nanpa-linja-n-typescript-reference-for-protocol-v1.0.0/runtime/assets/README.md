# Production asset layout

This suite consumes the same font manifest layout used in production. There is no test-only font manifest.

Expected files:

```text
assets/
├── fonts/
│   ├── preloaded-font-pairs.manifest.json
│   ├── <all base fonts referenced by the manifest>
│   ├── <all companion fonts referenced by the manifest>
│   └── <literal-cartouche fonts referenced by the manifest, if any>
└── wasm/
    ├── sitelen_vector_wasm.js
    └── sitelen_vector_wasm_bg.wasm
```

Production manifest URLs such as `./fonts/foo.otf` are resolved to `assets/fonts/foo.otf` by the regression runner. No font or WASM asset is downloaded from the internet.

Run `npm run inspect:assets` first. It lists every manifest pair and confirms that every referenced local file is present before the browser tests start.
