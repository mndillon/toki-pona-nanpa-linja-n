# Production asset layout

Production fonts are distributed only in the package-level bundle:

```text
resources/
└── fonts.zip
```

Inside `fonts.zip`, `fonts/preloaded-font-pairs.manifest.json` is the single source of truth for production font pairs, support fonts, and licence paths. The runtime reads the ZIP directly with the bundled `runtime/src/font-zip.js`; no external ZIP library or network font download is required.

The remaining `runtime/assets/` directory contains only the production vector WASM assets:

```text
runtime/assets/
└── wasm/
    ├── sitelen_vector_wasm.js
    └── sitelen_vector_wasm_bg.wasm
```
