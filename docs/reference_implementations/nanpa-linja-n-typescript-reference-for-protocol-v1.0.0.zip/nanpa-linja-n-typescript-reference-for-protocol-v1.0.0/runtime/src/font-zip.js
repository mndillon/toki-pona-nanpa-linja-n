const EOCD_SIGNATURE = 0x06054b50;
const CENTRAL_SIGNATURE = 0x02014b50;
const LOCAL_SIGNATURE = 0x04034b50;
const ZIP_METHOD_STORE = 0;
const ZIP_METHOD_DEFLATE = 8;
const UTF8 = new TextDecoder('utf-8');

function asUint8Array(value) {
  if (value instanceof Uint8Array) return value;
  if (value instanceof ArrayBuffer) return new Uint8Array(value);
  if (ArrayBuffer.isView(value)) return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
  throw new TypeError('ZIP input must be an ArrayBuffer or Uint8Array.');
}

function normalizeEntryName(value) {
  const name = String(value ?? '').replace(/\\/g, '/').replace(/^\/+/, '');
  if (!name || name.split('/').some(part => part === '..')) throw new Error(`Unsafe ZIP entry name: ${value}`);
  return name;
}

function findEocd(bytes) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const min = Math.max(0, bytes.byteLength - 0xffff - 22);
  for (let offset = bytes.byteLength - 22; offset >= min; offset--) {
    if (view.getUint32(offset, true) === EOCD_SIGNATURE) return offset;
  }
  throw new Error('ZIP end-of-central-directory record was not found.');
}

async function inflateRaw(bytes) {
  if (typeof DecompressionStream !== 'function') {
    throw new Error('This JavaScript runtime does not provide DecompressionStream; ZIP deflate support is unavailable.');
  }
  const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

export class ZipArchive {
  constructor(input) {
    this.bytes = asUint8Array(input);
    this.entries = new Map();
    this.#parse();
  }

  #parse() {
    const bytes = this.bytes;
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const eocd = findEocd(bytes);
    const disk = view.getUint16(eocd + 4, true);
    const centralDisk = view.getUint16(eocd + 6, true);
    const entriesOnDisk = view.getUint16(eocd + 8, true);
    const entryCount = view.getUint16(eocd + 10, true);
    const centralSize = view.getUint32(eocd + 12, true);
    const centralOffset = view.getUint32(eocd + 16, true);
    if (disk !== 0 || centralDisk !== 0 || entriesOnDisk !== entryCount) {
      throw new Error('Multi-disk ZIP archives are not supported.');
    }
    if (entryCount === 0xffff || centralSize === 0xffffffff || centralOffset === 0xffffffff) {
      throw new Error('ZIP64 archives are not supported.');
    }
    let offset = centralOffset;
    const centralEnd = centralOffset + centralSize;
    for (let i = 0; i < entryCount; i++) {
      if (offset + 46 > bytes.byteLength || view.getUint32(offset, true) !== CENTRAL_SIGNATURE) {
        throw new Error(`Invalid ZIP central-directory entry at index ${i}.`);
      }
      const flags = view.getUint16(offset + 8, true);
      const method = view.getUint16(offset + 10, true);
      const crc32 = view.getUint32(offset + 16, true);
      const compressedSize = view.getUint32(offset + 20, true);
      const uncompressedSize = view.getUint32(offset + 24, true);
      const nameLength = view.getUint16(offset + 28, true);
      const extraLength = view.getUint16(offset + 30, true);
      const commentLength = view.getUint16(offset + 32, true);
      const localOffset = view.getUint32(offset + 42, true);
      if ((flags & 0x0001) !== 0) throw new Error('Encrypted ZIP entries are not supported.');
      const nameStart = offset + 46;
      const name = normalizeEntryName(UTF8.decode(bytes.subarray(nameStart, nameStart + nameLength)));
      if (this.entries.has(name)) throw new Error(`Duplicate ZIP entry: ${name}`);
      this.entries.set(name, { name, flags, method, crc32, compressedSize, uncompressedSize, localOffset });
      offset = nameStart + nameLength + extraLength + commentLength;
    }
    if (offset > centralEnd || centralEnd > bytes.byteLength) throw new Error('Invalid ZIP central-directory bounds.');
  }

  has(name) {
    return this.entries.has(normalizeEntryName(name));
  }

  list() {
    return [...this.entries.keys()];
  }

  getEntry(name) {
    const normalized = normalizeEntryName(name);
    const entry = this.entries.get(normalized);
    if (!entry) throw new Error(`ZIP entry not found: ${normalized}`);
    return entry;
  }

  async bytesFor(name) {
    const entry = this.getEntry(name);
    if (entry.name.endsWith('/')) return new Uint8Array();
    const bytes = this.bytes;
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const offset = entry.localOffset;
    if (offset + 30 > bytes.byteLength || view.getUint32(offset, true) !== LOCAL_SIGNATURE) {
      throw new Error(`Invalid local ZIP header for ${entry.name}.`);
    }
    const nameLength = view.getUint16(offset + 26, true);
    const extraLength = view.getUint16(offset + 28, true);
    const dataStart = offset + 30 + nameLength + extraLength;
    const dataEnd = dataStart + entry.compressedSize;
    if (dataEnd > bytes.byteLength) throw new Error(`ZIP entry data is truncated: ${entry.name}`);
    const compressed = bytes.subarray(dataStart, dataEnd);
    let output;
    if (entry.method === ZIP_METHOD_STORE) output = new Uint8Array(compressed);
    else if (entry.method === ZIP_METHOD_DEFLATE) output = await inflateRaw(compressed);
    else throw new Error(`Unsupported ZIP compression method ${entry.method} for ${entry.name}.`);
    if (output.byteLength !== entry.uncompressedSize) {
      throw new Error(`ZIP entry size mismatch for ${entry.name}: ${output.byteLength} != ${entry.uncompressedSize}`);
    }
    return output;
  }

  async text(name) {
    return UTF8.decode(await this.bytesFor(name));
  }

  async json(name) {
    return JSON.parse(await this.text(name));
  }
}

export function openZipBytes(bytes) {
  return new ZipArchive(bytes);
}

export async function fetchZip(url) {
  const response = await fetch(url, { cache: 'no-store' });
  if (!response.ok) throw new Error(`Could not load ${url}: ${response.status}`);
  return new ZipArchive(await response.arrayBuffer());
}

export function mimeForFont(format, filename = '') {
  const value = String(format || '').trim().toLowerCase();
  if (value === 'opentype' || value === 'otf' || String(filename).toLowerCase().endsWith('.otf')) return 'font/otf';
  if (value === 'woff2' || String(filename).toLowerCase().endsWith('.woff2')) return 'font/woff2';
  if (value === 'woff' || String(filename).toLowerCase().endsWith('.woff')) return 'font/woff';
  return 'font/ttf';
}
