# nanpa-linja-n TypeScript reference facade

Version: **0.2.0**

This package is the strongly typed TypeScript facade for the canonical nanpa-linja-n JavaScript production reference implementation.

The JavaScript implementation remains the single behavioural renderer. The TypeScript package bundles that exact production runtime, its eight production font pairs, font-specific render adapters, production font manifest, and vector WASM, then exposes them through a typed API.

A TypeScript developer does **not** need to load the JavaScript renderer separately or understand font-specific adapter rules.

## Quick start

```ts
import { NanpaLinjaN } from "nanpa-linja-n-typescript";

const nanpa = await NanpaLinjaN.create();

const result = await nanpa.renderToCanvas("12:30");
document.body.append(result.canvas);
```

The default production font pair is `nasinNanpa`.

## PNG

```ts
const result = await nanpa.renderToPng("123.45");

console.log(result.blob.type); // image/png
console.log(result.bytes);     // Uint8Array
```

## SVG

```ts
const result = await nanpa.renderToSvg("#ABCDEF");
console.log(result.svg);
```

## PDF

```ts
const result = await nanpa.renderToPdf("0b10101");
console.log(result.blob);  // application/pdf
console.log(result.bytes); // Uint8Array
```

## Select a production font

```ts
const result = await nanpa.renderToPng("2026-09-13", {
  font: "linjaPona",
});
```

The facade automatically applies the production configuration for the selected font. For example, `linjaPona` automatically uses the `linja-pona-legacy-v1` adapter instead of incorrectly passing canonical UCSUR directly to the font.

The bundled production font keys are:

```text
nasinNanpa
sitelenSeliKiwen
fairfaxHd
fairfaxPonaHd
linjaPona
linjaSike
nasinSitelenPuMono
linjaLipamanka
```

Inspect them programmatically:

```ts
console.log(nanpa.listFonts());
console.log(nanpa.getFontInfo("linjaPona"));
```

## Unified render method

`render()` selects the output format through a typed discriminator:

```ts
const canvas = await nanpa.render("123.45");
const png = await nanpa.render("123.45", { format: "png" });
const svg = await nanpa.render("123.45", { format: "svg" });
const pdf = await nanpa.render("123.45", { format: "pdf" });
```

TypeScript overloads narrow the return type from the `format` option.

## Parse, inspect, edit, and convert an AST back to text

`parse()` is optional for normal rendering: methods such as `renderToCanvas()` and `renderToPng()` accept source text directly and parse it internally. Call `parse()` when an application needs to inspect or edit the structured document representation.

```ts
const parsed = await nanpa.parse("jan   pona [ jan  pona,, ]");
console.log(parsed.ast);
```

`astToText()` converts the current AST contents back into valid nanpa-linja-n source text. This makes a parse/edit/render workflow possible without adding a second AST-specific renderer:

```ts
const parsed = await nanpa.parse("jan   pona [ jan  pona,, ]");

const bracket = parsed.ast.lines
  .flatMap(line => line.children ?? [])
  .find(segment => segment.kind === "bracket");

if (bracket?.kind === "bracket") {
  bracket.value = " jan  suno,, ";
}

const editedText = nanpa.astToText(parsed.ast);
// "jan   pona [ jan  suno,, ]"

const png = await nanpa.renderToPng(editedText, {
  font: "linjaPona",
  fontSize: 56,
});
```

The same serializer is also available as a named export:

```ts
import { astToText } from "nanpa-linja-n-typescript";
const text = astToText(parsed.ast);
```

### Editable AST properties

The supported document segment kinds are typed as `DocumentAstSegment`. The normal editable fields are:

- `text.value` — ordinary source text, including spaces and tabs;
- `bracket.value` — the text inside `[...]`, including its internal spacing and tally commas;
- `quote.value` — quoted content;
- `quote.openQuote` / `quote.closeQuote` — quote delimiters;
- `image.value.src`, `w`, `h`, `alt`, `valign`, `wriggle`, `transparent` — structured `img(...)` properties;
- `rawUcsur.cps` — advanced raw Unicode code points, serialized as explicit `U+...` tokens.

Fields such as `sourceStart`, `sourceEnd`, `sourceLineIndex`, and other source-location metadata describe the original parsed input. They are not required for semantic edits and may become stale after nodes are inserted, removed, or rearranged. `astToText()` serializes the current editable content rather than trusting those offsets.

Whitespace stored in text/bracket/quote values is preserved, including blank physical lines. If `breakLinesAtFullStops` split one physical source line into multiple AST lines, `sourceLineIndex` is used to join those pieces without inventing new line breaks. Structured image nodes are emitted in a canonical valid `img(...)` spelling rather than promising byte-for-byte preservation of the original argument formatting.

## Inspect the render plan

`buildRenderPlan()` is an advanced inspection API. It resolves source text into the font-specific positioned runs that will be drawn, which is useful for highlighting, hit testing, custom tooling, and conformance checks. Normal rendering does not require calling it first.

```ts
const planned = await nanpa.buildRenderPlan("2026-09-13", {
  font: "linjaPona",
});

console.log(planned.plan.lines);
```

The low-level JavaScript production facade is available through `rawRuntime` when an application deliberately needs an escape hatch:

```ts
const raw = nanpa.rawRuntime;
```

## Parser-only API

The original typed `NanpaParser` facade remains available and unchanged.

To use the parser bundled with this package:

```ts
import { importBundledNanpaParser } from "nanpa-linja-n-typescript";

const parser = await importBundledNanpaParser();
const result = parser.parseNumber("12:30", {
  numericMode: "uniform",
  relaxedNanpaLinjanParsing: true,
  relaxedNanpaLinjanRendering: true,
  nanpaColonParsing: true,
  nanpaColonRendering: true,
});
```

`importNanpaParser(url)` and `getGlobalNanpaParser()` are retained for compatibility with applications that deliberately supply or pre-load another compatible canonical runtime.

## Complete typed JavaScript reference surface

The existing high-level TypeScript facade remains unchanged. Advanced consumers can now import typed wrappers that point directly at the exact bundled JavaScript exports; no parsing or rendering algorithms are duplicated in TypeScript.

```ts
import {
  NanpaParser,
  SitelenRenderer,
  SitelenVectorExporter,
  createSitelenFontPairController,
  DEFAULT_PARSER_CONFIG,
} from "nanpa-linja-n-typescript/runtime";
```

The JavaScript package subpaths are also mirrored with declarations:

```text
nanpa-linja-n-typescript/advanced
nanpa-linja-n-typescript/reference/renderer
nanpa-linja-n-typescript/reference/font-controller
nanpa-linja-n-typescript/reference/vector-exporter
```

For applications that prefer lazy loading, the root facade also provides `importBundledRuntimeModule()`, `importBundledAdvancedModule()`, `importBundledSitelenRenderer()`, `importBundledSitelenVectorExporter()`, and `importBundledFontPairControllerFactory()`.

The wrapper-parity test asserts that every value exported by these typed subpaths is the **same JavaScript object/value** exported by the bundled reference module.

## Rendering options

Common options are typed directly:

```ts
await nanpa.renderToCanvas("123.45", {
  font: "fairfaxHd",
  fontSize: 56,
  paddingPx: 12,
});
```

Advanced configuration can still be passed through with `layout`, `paint`, `parser`, `fonts`, or `config`.

## Runtime architecture

```text
TypeScript facade
      ↓
canonical JavaScript production facade
      ↓
parser + render plan
      ↓
production font-pair controller
      ↓
font-specific adapter when required
      ↓
Canvas / PNG / SVG / PDF
```

The TypeScript layer does not duplicate or reinterpret nanpa-linja-n parsing or rendering algorithms. Behavioural changes belong in the canonical JavaScript reference first.

## Browser requirement

Graphical rendering uses browser facilities such as `document`, `FontFace`, Canvas, Blob, and the bundled vector WASM. Therefore `NanpaLinjaN.create()` and graphical rendering are browser APIs.

The parser-only API can be used from Node.js without graphical browser facilities.

## Build and regression

Install the development dependency and run:

```bash
npm ci
npm test
```

Individual checks:

```bash
npm run typecheck
npm run verify:runtime
npm run test:types
npm run test:exports
npm run test:unit
npm run test:protocol
npm run test:browser
```

`test:browser` needs a Chromium-family browser. Set `NANPA_CHROMIUM=/absolute/path/to/browser` if it is not discoverable on `PATH`.

The configured regression suite verifies:

- TypeScript compilation and declarations;
- exact hashes for the bundled canonical JavaScript production runtime;
- compile-time coverage for the typed runtime/advanced/reference wrappers;
- exact export identity between typed wrappers and the bundled JavaScript modules;
- the existing frozen-runtime TypeScript parser facade behavior;
- `astToText()` whitespace/quote/cartouche/image/raw-UCSUR serialization and AST edit round-trips;
- the language-neutral **1,017-check** protocol corpus;
- real browser Canvas rendering;
- `renderToPng()` with a valid PNG signature;
- automatic `linja-pona-legacy-v1` production adaptation;
- real SVG vector output through the bundled WASM;
- real PDF output through the bundled WASM;
- all eight production font pairs exposed through the facade.

## Bundled canonical JavaScript baseline

The important JavaScript reference hashes are pinned by `npm run verify:runtime`:

```text
renderer:        935b6a3e664d1ef25f496b8f7af1f8e3cfd3082c64bcec46b2dabf09e3447a7c
font controller: b842c7a398ac6c563634e144a9f4b48793deb1be2482a6973d99c73afcfc150e
vector exporter: 8ca2471de24352e5deebce940343392ce55d9a7e2811bbf4a2844beb957bf206
JS facade:       81b9b0e9c16ead4f2021f8ac5c6187764b3cf96b4f01a33cb4ab37af2b3d92d1
```

## Licensing

No licence has been added by this conversion. Apply the same licence you intend for the canonical nanpa-linja-n JavaScript project before publishing this package publicly.
