import assert from "node:assert/strict";
import {
  NanpaLinjaN,
  bindNanpaParser,
  assertNanpaParserRuntime,
  importBundledNanpaParser,
  NanpaRuntimeError,
  astToText,
  parseNumber,
} from "../dist/index.js";

function makeRuntime() {
  return {
    parseNumber(input) { return input === "ok" ? { input: "ok" } : null; },
    encodeDecimal(input) { return `caps:${input}`; },
    decimalToUcsurCodepoints(input) { return this.parseNumber(input) ? [1, 2, 3] : []; },
    properNameToUcsurCodepoints() { return [4]; },
    splitCapsToProperName(caps) { return caps.toLowerCase(); },
    capsToUniqueCode(caps) { return `#~${caps}`; },
    decodeCaps(caps) { return caps; },
    parseIdentifier() { return null; },
    capsToWords() { return []; },
    capsToCodepoints() { return null; },
    codepointsToWords() { return []; },
  };
}

for (const runtime of [makeRuntime(), Object.freeze(makeRuntime())]) {
  assert.doesNotThrow(() => assertNanpaParserRuntime(runtime));
  const parser = bindNanpaParser(runtime);
  assert.deepEqual(parser.parseNumber("ok"), { input: "ok" });
  const detached = parser.decimalToUcsurCodepoints;
  assert.deepEqual(detached("ok"), [1, 2, 3]);
  assert.deepEqual(detached("no"), []);
  assert.equal(parser.encodeDecimal("7"), "caps:7");
  assert.equal("parseNumber" in parser, true);
  assert.equal(Object.keys(parser).includes("parseNumber"), true);
}

assert.throws(
  () => assertNanpaParserRuntime({ parseNumber() {} }),
  (err) => err instanceof NanpaRuntimeError && /missing required method/.test(err.message),
);

const bundledParser = await importBundledNanpaParser();
const parsed = bundledParser.parseNumber("12:30", {
  numericMode: "uniform",
  relaxedNanpaLinjanParsing: true,
  relaxedNanpaLinjanRendering: true,
  nanpaColonParsing: true,
  nanpaColonRendering: true,
});
assert.equal(parsed?.semanticKind, "time");
assert.equal(parsed?.tpWords?.[0], "tenpo");

const publicParsedNumber = parseNumber("123");
assert.equal(publicParsedNumber?.displayValue, "123");
assert.equal(publicParsedNumber?.properName, "Nanpa Watusen");

const mockModuleUrl = new URL("./mock-runtime.mjs", import.meta.url);
const facade = await NanpaLinjaN.create({ runtimeModuleUrl: mockModuleUrl });
assert.equal(facade.listFonts()[0]?.key, "nasinNanpa");
assert.equal(facade.getFontInfo("nasin nanpa")?.key, "nasinNanpa");
assert.equal(astToText({ lines: [{ children: [{ kind: "bracket", value: " jan pona " }] }] }), "[ jan pona ]");
assert.equal(facade.astToText({ lines: [{ children: [{ kind: "text", value: "jan  pona" }] }] }), "jan  pona");
assert.deepEqual(facade.parseNumber("ok"), { input: "ok", displayValue: "ok", properName: "Ok", uniqueCode: "#~OK", tpWords: [], words: [], ucsurCodepoints: [], hexCodepoints: "", hexWithCartouche: "", isTime: false, isDate: false, isTimeLike: false, innerCodepoints: [], codepoints: [], numericMode: "uniform" });
assert.equal((await facade.render("123")).kind, "canvas");
assert.equal((await facade.renderToPng("123")).kind, "png");
assert.equal((await facade.renderToSvg("123")).svg, "<svg/>");
assert.equal((await facade.renderToPdf("123")).blob.type, "application/pdf");
await facade.destroy();

console.log("TypeScript facade unit tests: PASS");
