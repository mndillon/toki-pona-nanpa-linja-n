import assert from "node:assert/strict";

async function assertExactModuleParity(typedPath, rawPath, label) {
  const [typed, raw] = await Promise.all([import(typedPath), import(rawPath)]);
  assert.deepEqual(Object.keys(typed).sort(), Object.keys(raw).sort(), `${label} export keys`);
  for (const key of Object.keys(raw)) {
    assert.strictEqual(typed[key], raw[key], `${label} export ${key} must be the exact bundled JS value`);
  }
}

await assertExactModuleParity("../dist/runtime.js", "../runtime/src/nanpa-linja-n.js", "runtime");
await assertExactModuleParity("../dist/advanced.js", "../runtime/src/advanced.js", "advanced");
await assertExactModuleParity(
  "../dist/reference-renderer.js",
  "../runtime/reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js",
  "reference renderer",
);
await assertExactModuleParity(
  "../dist/reference-font-controller.js",
  "../runtime/reference/sitelen-font-pair-controller.js",
  "reference font controller",
);
await assertExactModuleParity(
  "../dist/reference-vector-exporter.js",
  "../runtime/reference/sitelen-vector-exporter.js",
  "reference vector exporter",
);

console.log("TypeScript typed-wrapper export parity: PASS");
