const fakeCanvas = { width: 320, height: 120 };

const runtime = {
  fonts: [{ key: 'nasinNanpa', label: 'nasin nanpa', textFamily: 'Text', cartoucheFamily: 'Cart', literalCartoucheFamily: 'Text', parserMode: 'test', renderAdapterId: 'identity' }],
  listFonts() { return structuredClone(this.fonts); },
  getFontInfo(font) { return String(font).toLowerCase().includes('nasin') ? structuredClone(this.fonts[0]) : null; },
  normalizeFontKey() { return 'nasinNanpa'; },
  async parse(input) { return { input, ast: { input }, diagnostics: [], fontKey: 'nasinNanpa', preset: this.fonts[0], config: {} }; },
  async buildRenderPlan(input) { return { input, plan: { lines: [] }, fontKey: 'nasinNanpa', preset: this.fonts[0], config: {} }; },
  async render(input, options = {}) {
    if (options.format === 'png') return this.renderToPng(input, options);
    if (options.format === 'svg') return this.renderToSvg(input, options);
    if (options.format === 'pdf') return this.renderToPdf(input, options);
    return this.renderToCanvas(input, options);
  },
  async renderToCanvas(input) { return { kind: 'canvas', input, canvas: fakeCanvas, width: 320, height: 120, ast: {}, linesElements: [], plan: { lines: [] }, fontKey: 'nasinNanpa', preset: this.fonts[0], config: {} }; },
  async renderToPng(input) { return { ...(await this.renderToCanvas(input)), kind: 'png', blob: new Blob(['png'], { type: 'image/png' }), bytes: new Uint8Array([137,80,78,71]) }; },
  async renderToSvg(input) { return { kind: 'svg', input, blob: new Blob(['<svg/>'], { type: 'image/svg+xml' }), svg: '<svg/>', fontKey: 'nasinNanpa', preset: this.fonts[0], config: {} }; },
  async renderToPdf(input) { return { kind: 'pdf', input, blob: new Blob(['%PDF-1.7'], { type: 'application/pdf' }), bytes: new TextEncoder().encode('%PDF-1.7'), fontKey: 'nasinNanpa', preset: this.fonts[0], config: {} }; },
  async destroy() {},
};

export class NanpaLinjaN {
  static async create() { return runtime; }
}

export default NanpaLinjaN;
