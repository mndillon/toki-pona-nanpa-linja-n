import {
  DEFAULT_FONT_KEY,
  DEFAULT_FONT_SIZE,
  DEFAULT_MANIFEST_URL,
  DEFAULT_PARSER_CONFIG,
  DEFAULT_TEXT_FONT_OPTION,
  DEFAULT_VECTOR_WASM_URL,
  NanpaLinjaN as JavaScriptNanpaLinjaN,
  NanpaParser,
  SitelenRenderer,
  SitelenVectorExporter,
  TEXT_FONT_OPTION_SITELEN,
  createSitelenFontPairController,
} from "nanpa-linja-n-typescript/runtime";
import * as advanced from "nanpa-linja-n-typescript/advanced";
import * as rendererReference from "nanpa-linja-n-typescript/reference/renderer";
import * as controllerReference from "nanpa-linja-n-typescript/reference/font-controller";
import * as vectorReference from "nanpa-linja-n-typescript/reference/vector-exporter";
import {
  astToText,
  type DocumentAst,
  importBundledAdvancedModule,
  importBundledFontPairControllerFactory,
  importBundledRuntimeModule,
  importBundledSitelenRenderer,
  importBundledSitelenVectorExporter,
} from "nanpa-linja-n-typescript";

void DEFAULT_FONT_KEY;
void DEFAULT_FONT_SIZE;
void DEFAULT_MANIFEST_URL;
void DEFAULT_PARSER_CONFIG;
void DEFAULT_TEXT_FONT_OPTION;
void DEFAULT_VECTOR_WASM_URL;
void TEXT_FONT_OPTION_SITELEN;
void JavaScriptNanpaLinjaN.create;
void NanpaParser.parseNumber;
void SitelenRenderer.create;
void SitelenRenderer.registerRenderAdapter;
void SitelenVectorExporter.create;
void createSitelenFontPairController;
void advanced.TEXT_FONT_OPTION_NANPA_LINJA_N;
void rendererReference.NanpaParser.capsToWords;
void controllerReference.DEFAULT_TEXT_FONT_OPTIONS;
void vectorReference.SitelenVectorExporter.create;

async function proveDynamicWrappersAreTyped(): Promise<void> {
  const root = await importBundledRuntimeModule();
  root.NanpaParser.parseNumber("12:30");
  root.SitelenRenderer.hasRenderAdapter(root.SitelenRenderer.getDefaultRenderAdapterId());
  root.SitelenVectorExporter.create;
  root.createSitelenFontPairController;
  root.DEFAULT_PARSER_CONFIG.numericMode;

  const advancedModule = await importBundledAdvancedModule();
  advancedModule.SitelenRenderer.create;
  advancedModule.SitelenVectorExporter.create;
  advancedModule.createSitelenFontPairController;

  const renderer = await importBundledSitelenRenderer();
  renderer.registerRenderAdapter;
  const vector = await importBundledSitelenVectorExporter();
  vector.create;
  const controllerFactory = await importBundledFontPairControllerFactory();
  void controllerFactory;
}

void proveDynamicWrappersAreTyped;

const editableAst: DocumentAst = {
  lines: [{ children: [{ kind: "bracket", value: " jan pona " }] }],
};
void astToText(editableAst);
