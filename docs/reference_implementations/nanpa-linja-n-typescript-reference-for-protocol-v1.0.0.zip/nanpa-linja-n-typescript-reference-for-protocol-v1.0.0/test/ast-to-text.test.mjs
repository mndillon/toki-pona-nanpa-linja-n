import assert from 'node:assert/strict';
import { astToText } from '../dist/index.js';

let checks = 0;
function pass(name, fn) {
  fn();
  checks++;
  console.log(`PASS astToText ${name}`);
}

pass('preserves spaces, tabs, blank lines, brackets, and quote delimiters', () => {
  const ast = {
    lines: [
      { sourceLineIndex: 0, children: [
        { kind: 'text', value: 'jan\t  pona ' },
        { kind: 'bracket', value: ' jan  pona,, ' },
        { kind: 'text', value: '  ' },
        { kind: 'quote', value: 'toki  pona', openQuote: '“', closeQuote: '”' },
      ] },
      { sourceLineIndex: 1, children: [] },
      { sourceLineIndex: 2, children: [{ kind: 'text', value: 'pini' }] },
    ],
  };
  assert.equal(astToText(ast), 'jan\t  pona [ jan  pona,, ]  “toki  pona”\n\npini');
});

pass('rejoins sentence-split AST lines sharing one physical source line', () => {
  const ast = { lines: [
    { sourceLineIndex: 0, sentenceIndexInSourceLine: 0, children: [{ kind: 'text', value: 'jan li pona.' }] },
    { sourceLineIndex: 0, sentenceIndexInSourceLine: 1, children: [{ kind: 'text', value: ' ona li pona.' }] },
    { sourceLineIndex: 1, children: [{ kind: 'text', value: 'pini' }] },
  ] };
  assert.equal(astToText(ast), 'jan li pona. ona li pona.\npini');
});

pass('serializes an edited bracket value', () => {
  const ast = { lines: [{ sourceLineIndex: 0, children: [{ kind: 'bracket', value: ' jan  pona,, ' }] }] };
  ast.lines[0].children[0].value = ' jan  suno,, ';
  assert.equal(astToText(ast), '[ jan  suno,, ]');
});

pass('serializes straight quotes with their stored content', () => {
  const ast = { lines: [{ children: [{ kind: 'quote', value: 'jan pona', openQuote: '"', closeQuote: '"' }] }] };
  assert.equal(astToText(ast), '"jan pona"');
});

pass('serializes image descriptors canonically', () => {
  const ast = { lines: [{ children: [{ kind: 'image', value: { src: 'a.png', w: '50', alt: 'test', valign: 'center', wriggle: 4, transparent: false } }] }] };
  assert.equal(astToText(ast), "img(src='a.png',w='50',alt='test',valign='center',wriggle=4,transparent=false)");
});

pass('serializes raw UCSUR codepoints', () => {
  const ast = { lines: [{ children: [{ kind: 'rawUcsur', cps: [0xF1900, 0x300C] }] }] };
  assert.equal(astToText(ast), 'U+F1900 U+300C');
});

pass('rejects invalid raw UCSUR codepoints', () => {
  const ast = { lines: [{ children: [{ kind: 'rawUcsur', cps: [0x110000] }] }] };
  assert.throws(() => astToText(ast), /Invalid rawUcsur code point/);
});

pass('rejects non-document AST values', () => {
  assert.throws(() => astToText({}), /expects a document AST/);
});

console.log(`TypeScript astToText regression: ${checks}/8 PASS`);
