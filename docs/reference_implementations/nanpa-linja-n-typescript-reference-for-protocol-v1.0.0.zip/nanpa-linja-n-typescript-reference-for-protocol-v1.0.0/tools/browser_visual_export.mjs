#!/usr/bin/env node
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn, execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { SimpleWebSocket, CdpConnection } from '../test/lib/cdp-websocket.mjs';
import { findChromium } from '../scripts/lib/browser-discovery.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const fontDir = path.resolve(process.env.NANPA_FONT_DIR || '');
const outDir = path.resolve(process.env.NANPA_VISUAL_OUT || path.join(root, 'test-output'));
const visualMode = process.env.NANPA_VISUAL_MODE || 'numeric';
if (!process.env.NANPA_FONT_DIR) throw new Error('NANPA_FONT_DIR is required');
if (!['numeric','ordinary'].includes(visualMode)) throw new Error(`Unknown visual mode: ${visualMode}`);
const delay = ms => new Promise(r => setTimeout(r, ms));
const b64 = value => Buffer.isBuffer(value) ? value.toString('base64') : Buffer.from(String(value), 'utf8').toString('base64');
const decodeUtf8Expr = encoded => `new TextDecoder().decode(Uint8Array.from(atob(${JSON.stringify(encoded)}),c=>c.charCodeAt(0)))`;

function patchVectorWasmWrapper(source) {
  const re = /module_or_path\s*=\s*new URL\((['"])[^'"]*sitelen_vector_wasm_bg\.wasm[^'"]*\1,\s*import\.meta\.url\);/;
  if (!re.test(source)) throw new Error('Vector WASM wrapper does not contain the expected bg WASM URL assignment.');
  return source.replace(re, 'module_or_path = globalThis.__NANPA_VECTOR_WASM_BG_URL__;');
}

function transformJsFacade(source) {
  return `const { SitelenRenderer, NanpaParser } = globalThis;\nconst { createSitelenFontPairController, TEXT_FONT_OPTION_SITELEN } = globalThis;\nconst { SitelenVectorExporter } = globalThis;\n${source}`
    .replace(/import\s*\{[\s\S]*?\}\s*from\s*['"]\.\.\/reference\/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime\.js['"];\s*/m, '')
    .replace(/import\s*\{[\s\S]*?\}\s*from\s*['"]\.\.\/reference\/sitelen-font-pair-controller\.js['"];\s*/m, '')
    .replace(/import\s*\{[\s\S]*?\}\s*from\s*['"]\.\.\/reference\/sitelen-vector-exporter\.js['"];\s*/m, '');
}

function transformTsFacade(source) {
  return source
    .replace(/^export \* from "\.\/types\.js";\s*\n/m, '')
    .replace('export const BUNDLED_RUNTIME_MODULE_URL = new URL("../runtime/src/nanpa-linja-n.js", import.meta.url);', 'export const BUNDLED_RUNTIME_MODULE_URL = new URL(globalThis.__NANPA_TS_RUNTIME_URL__);')
    .replace('export const BUNDLED_RENDERER_MODULE_URL = new URL("../runtime/reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js", import.meta.url);', 'export const BUNDLED_RENDERER_MODULE_URL = new URL(globalThis.__NANPA_RENDERER_URL__);')
    .replace('export const BUNDLED_MANIFEST_URL = new URL("../runtime/assets/preloaded-font-pairs.manifest.json", import.meta.url);', 'export const BUNDLED_MANIFEST_URL = new URL(globalThis.__NANPA_DEFAULT_MANIFEST_URL__);')
    .replace('export const BUNDLED_VECTOR_WASM_URL = new URL("../runtime/assets/wasm/sitelen_vector_wasm.js", import.meta.url);', 'export const BUNDLED_VECTOR_WASM_URL = new URL(globalThis.__NANPA_DEFAULT_VECTOR_WASM_URL__);');
}

async function installBlobModule(cdp, sourceB64, assignCode, timeoutMs = 120000) {
  const expr = `(async()=>{const source=${decodeUtf8Expr(sourceB64)};const url=URL.createObjectURL(new Blob([source],{type:'text/javascript'}));const mod=await import(url);${assignCode};return url;})()`;
  return await evalCdp(cdp, expr, { awaitPromise: true, timeoutMs });
}

async function evalCdp(cdp, expression, { awaitPromise = true, timeoutMs = 120000 } = {}) {
  const response = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise, userGesture: false }, { timeoutMs });
  if (response?.exceptionDetails) {
    const d = response.exceptionDetails;
    throw new Error(d?.exception?.description || d?.text || 'Runtime.evaluate exception');
  }
  return response?.result?.value;
}

async function connectPageTarget(devtoolsWsUrl, timeoutMs = 15000) {
  const u = new URL(devtoolsWsUrl);
  const origin = `http://${u.hostname}:${u.port}`;
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const r = await fetch(`${origin}/json/list`, { cache: 'no-store' });
      if (r.ok) {
        const list = await r.json();
        const page = (list || []).find(x => x.type === 'page' && x.webSocketDebuggerUrl);
        if (page) return page;
      }
    } catch {}
    await delay(100);
  }
  throw new Error('DevTools page target not available.');
}

function waitForClose(cp, timeoutMs = 800) {
  if (!cp || cp.exitCode != null || cp.signalCode != null) return Promise.resolve(true);
  return new Promise(resolve => {
    const timer = setTimeout(() => resolve(false), timeoutMs);
    cp.once('close', () => { clearTimeout(timer); resolve(true); });
  });
}

async function cleanup(cp, ws, profilePath) {
  try { ws?.destroy?.(); } catch {}
  try { cp?.kill?.('SIGTERM'); } catch {}
  if (!(await waitForClose(cp))) {
    try { cp?.kill?.('SIGKILL'); } catch {}
    await waitForClose(cp, 500);
  }
  try { cp?.stdout?.destroy?.(); } catch {}
  try { cp?.stderr?.destroy?.(); } catch {}
  try { cp?.unref?.(); } catch {}
  try { fs.rmSync(profilePath, { recursive: true, force: true }); } catch {}
}

const manifestPath = path.join(root, 'runtime/assets/fonts/preloaded-font-pairs.manifest.json');
const manifest = JSON.parse(await fsp.readFile(manifestPath, 'utf8'));
const fontAssets = [];
for (const pair of manifest.pairs || []) {
  const fields = [
    ['base', pair.baseFamily, pair.baseFilename, pair.baseFormat, pair.baseSample],
    ['companion', pair.companionFamily, pair.companionFilename, pair.companionFormat, pair.companionSample],
    ['literalCartouche', pair.literalCartoucheFamily || pair.literalCartoucheFontFamily, pair.literalCartoucheFilename, pair.literalCartoucheFormat, pair.literalCartoucheSample],
  ];
  for (const [role, family, filename, format, sample] of fields) {
    if (!family || !filename) continue;
    const file = path.join(fontDir, filename);
    if (!fs.existsSync(file)) throw new Error(`Missing production font asset: ${file}`);
    fontAssets.push({
      id: `${pair.fontKey}:${role}`,
      pairKey: pair.fontKey,
      role,
      family,
      format: format || (filename.endsWith('.otf') ? 'opentype' : 'truetype'),
      sample: sample || null,
      bytesB64: (await fsp.readFile(file)).toString('base64'),
    });
  }
}

const rendererSource = await fsp.readFile(path.join(root, 'runtime/reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js'), 'utf8');
const controllerSource = await fsp.readFile(path.join(root, 'runtime/reference/sitelen-font-pair-controller.js'), 'utf8');
let vectorSource = await fsp.readFile(path.join(root, 'runtime/reference/sitelen-vector-exporter.js'), 'utf8');
const vectorDefaultLine = 'const DEFAULT_WASM_MODULE_URL = new URL("../wasm/sitelen_vector_wasm.js?v=145", import.meta.url).href;';
if (!vectorSource.includes(vectorDefaultLine)) throw new Error('Vector exporter default WASM URL line changed.');
vectorSource = vectorSource.replace(vectorDefaultLine, 'const DEFAULT_WASM_MODULE_URL = "about:blank";');
const jsFacadeSource = transformJsFacade(await fsp.readFile(path.join(root, 'runtime/src/nanpa-linja-n.js'), 'utf8'));
const tsFacadeSource = transformTsFacade(await fsp.readFile(path.join(root, 'dist/index.js'), 'utf8'));
const wasmJsSource = patchVectorWasmWrapper(await fsp.readFile(path.join(root, 'runtime/assets/wasm/sitelen_vector_wasm.js'), 'utf8'));
const wasmBgB64 = (await fsp.readFile(path.join(root, 'runtime/assets/wasm/sitelen_vector_wasm_bg.wasm'))).toString('base64');

const browser = findChromium();
const profilePath = path.join(os.tmpdir(), `nanpa-ts-embedded-${process.pid}-${crypto.randomBytes(4).toString('hex')}`);
fs.mkdirSync(profilePath, { recursive: true });
const args = [
  '--headless=new', '--disable-gpu', '--disable-dev-shm-usage', '--no-first-run', '--no-default-browser-check',
  '--disable-background-networking', '--disable-component-update', '--disable-sync', '--metrics-recording-only',
  '--remote-debugging-port=0', `--user-data-dir=${profilePath}`, 'about:blank'
];
if (typeof process.getuid === 'function' && process.getuid() === 0) args.unshift('--no-sandbox');
const cp = spawn(browser.command, [...(browser.prefixArgs || []), ...args], { stdio: ['ignore', 'pipe', 'pipe'] });
cp.stdout.setEncoding('utf8');
cp.stderr.setEncoding('utf8');
let stderr = '', devtoolsWsUrl = null;
cp.stderr.on('data', d => { stderr += d; const m = String(d).match(/DevTools listening on (ws:\/\/[^\s]+)/); if (m) devtoolsWsUrl = m[1]; });
let ws = null;
try {
  const launchDeadline = Date.now() + 20000;
  while (!devtoolsWsUrl && Date.now() < launchDeadline) await delay(50);
  if (!devtoolsWsUrl) throw new Error(`Browser did not expose DevTools. ${stderr.slice(-4000)}`);
  const page = await connectPageTarget(devtoolsWsUrl);
  ws = await new SimpleWebSocket(page.webSocketDebuggerUrl).connect({ timeoutMs: 15000 });
  const cdp = new CdpConnection(ws);
  await cdp.send('Runtime.enable');
  await cdp.send('Page.enable');
  await evalCdp(cdp, `document.body.innerHTML='<pre id="out"></pre>';true;`, { awaitPromise: false });

  const rendererUrl = await installBlobModule(cdp, b64(rendererSource), 'globalThis.SitelenRenderer=mod.SitelenRenderer;globalThis.NanpaParser=mod.NanpaParser;');
  await evalCdp(cdp, `globalThis.__NANPA_RENDERER_URL__=${JSON.stringify(rendererUrl)};true;`, { awaitPromise: false });
  await installBlobModule(cdp, b64(controllerSource), 'globalThis.createSitelenFontPairController=mod.createSitelenFontPairController;globalThis.TEXT_FONT_OPTION_SITELEN=mod.TEXT_FONT_OPTION_SITELEN;globalThis.TEXT_FONT_OPTION_NANPA_LINJA_N=mod.TEXT_FONT_OPTION_NANPA_LINJA_N;');
  await installBlobModule(cdp, b64(vectorSource), 'globalThis.SitelenVectorExporter=mod.SitelenVectorExporter;');

  await evalCdp(cdp, `globalThis.__NANPA_PRODUCTION_MANIFEST__=${JSON.stringify(manifest)};globalThis.__NANPA_FONT_ASSET_URLS__={};true;`, { awaitPromise: false });
  for (const asset of fontAssets) {
    const mime = asset.format === 'opentype' ? 'font/otf' : asset.format === 'woff2' ? 'font/woff2' : asset.format === 'woff' ? 'font/woff' : 'font/ttf';
    await evalCdp(cdp, `(()=>{const bytes=Uint8Array.from(atob(${JSON.stringify(asset.bytesB64)}),c=>c.charCodeAt(0));globalThis.__NANPA_FONT_ASSET_URLS__[${JSON.stringify(asset.id)}]=URL.createObjectURL(new Blob([bytes],{type:${JSON.stringify(mime)}}));return true;})()`, { awaitPromise: false });
  }
  await evalCdp(cdp, `(()=>{globalThis.__NANPA_DEFAULT_MANIFEST_URL__=URL.createObjectURL(new Blob([JSON.stringify(globalThis.__NANPA_PRODUCTION_MANIFEST__)],{type:'application/json'}));const bytes=Uint8Array.from(atob(${JSON.stringify(wasmBgB64)}),c=>c.charCodeAt(0));globalThis.__NANPA_VECTOR_WASM_BG_BYTES__=bytes;globalThis.__NANPA_VECTOR_WASM_BG_URL__=URL.createObjectURL(new Blob([bytes],{type:'application/wasm'}));return true;})()`, { awaitPromise: false });
  const wasmUrl = await installBlobModule(cdp, b64(wasmJsSource), 'globalThis.__NANPA_REAL_VECTOR_WASM_MODULE__=mod;globalThis.__NANPA_REAL_VECTOR_WASM_URL__=url;globalThis.__NANPA_DEFAULT_VECTOR_WASM_URL__=url;');
  await evalCdp(cdp, `(async()=>{const mod=globalThis.__NANPA_REAL_VECTOR_WASM_MODULE__;await mod.default({module_or_path:globalThis.__NANPA_VECTOR_WASM_BG_BYTES__});return typeof mod.healthcheck==='function'?String(mod.healthcheck()):'initialized';})()`);

  const runtimeUrl = await installBlobModule(cdp, b64(jsFacadeSource), 'globalThis.__NANPA_JS_FACADE_MODULE__=mod;globalThis.__NANPA_TS_RUNTIME_URL__=url;');
  await evalCdp(cdp, `globalThis.__NANPA_TS_RUNTIME_URL__=${JSON.stringify(runtimeUrl)};globalThis.__NANPA_DEFAULT_VECTOR_WASM_URL__=${JSON.stringify(wasmUrl)};true;`, { awaitPromise: false });
  await installBlobModule(cdp, b64(tsFacadeSource), 'globalThis.NanpaLinjaNTS=mod.NanpaLinjaN;globalThis.importBundledNanpaParserTS=mod.importBundledNanpaParser;');

  const result = await evalCdp(cdp, `(async()=>{
    const nanpa=await globalThis.NanpaLinjaNTS.create();
    const files={};
    const toB64=bytes=>{let s='';for(let i=0;i<bytes.length;i+=0x8000)s+=String.fromCharCode(...bytes.subarray(i,i+0x8000));return btoa(s)};
    const fonts=nanpa.listFonts();
    if(${JSON.stringify(visualMode)}==='numeric'){
      for(const f of fonts){
        let r=await nanpa.renderToPng('123.45',{font:f.key,fontSize:56,paddingPx:18,parser:{abbreviateNumericCartouches:false}});files[f.key+'-full.png']=toB64(r.bytes);
        r=await nanpa.renderToPng('123.45',{font:f.key,fontSize:56,paddingPx:18,parser:{abbreviateNumericCartouches:true}});files[f.key+'-abbreviated.png']=toB64(r.bytes);
      }
    }else{
      const vars=[['ordinary-cartouche','[jan pona]',false],['ordinary-cartouche-halo-red','[jan pona]',true],['ordinary-cartouche-tallies','[jan pona,,]',false],['ordinary-cartouche-tallies-halo-red','[jan pona,,]',true]];
      for(const f of fonts)for(const [id,input,halo] of vars){
        const paint=halo?{halo:{enabled:true,color:'#D91E18',widthPx:6}}:{};
        const r=await nanpa.renderToPng(input,{font:f.key,fontSize:56,paddingPx:18,paint});files[f.key+'--'+id+'.png']=toB64(r.bytes);
      }
    }
    await nanpa.destroy(); return files;
  })()`, { awaitPromise: true, timeoutMs: 180000 });
  await fsp.mkdir(outDir,{recursive:true});
  for(const [name,b64value] of Object.entries(result||{})){
    if(path.basename(name)!==name)throw new Error(`Unsafe output filename: ${name}`);
    await fsp.writeFile(path.join(outDir,name),Buffer.from(b64value,'base64'));
  }
  console.log(`${visualMode} TypeScript browser export: ${Object.keys(result||{}).length} PNG file(s) written to ${outDir}`);
} finally {
  await cleanup(cp, ws, profilePath);
}
