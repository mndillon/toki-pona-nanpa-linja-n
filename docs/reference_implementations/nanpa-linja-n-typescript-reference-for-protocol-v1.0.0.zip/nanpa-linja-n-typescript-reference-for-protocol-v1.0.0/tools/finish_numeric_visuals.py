#!/usr/bin/env python3
from pathlib import Path
import sys
from PIL import Image

out = Path(sys.argv[1] if len(sys.argv) > 1 else 'test-output')
count = 0
for src in sorted(out.glob('*-full.png')) + sorted(out.glob('*-abbreviated.png')):
    if src.name.endswith('-white.png'):
        continue
    im = Image.open(src).convert('RGBA')
    white = Image.new('RGBA', im.size, (255,255,255,255))
    white.alpha_composite(im)
    dst = src.with_name(src.stem + '-white.png')
    white.convert('RGB').save(dst)
    count += 1
print(f'white-background visual PNGs: {count} file(s) written')
