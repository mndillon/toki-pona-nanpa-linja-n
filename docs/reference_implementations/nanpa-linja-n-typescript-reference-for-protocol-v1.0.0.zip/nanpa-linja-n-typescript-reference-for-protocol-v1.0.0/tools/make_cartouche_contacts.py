#!/usr/bin/env python3
import sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

if len(sys.argv) != 2:
    raise SystemExit('usage: make_cartouche_contacts.py <output-dir>')
out = Path(sys.argv[1])
variants = [
    ('ordinary-cartouche', 'ordinary'),
    ('ordinary-cartouche-halo-red', 'ordinary + red halo'),
    ('ordinary-cartouche-tallies', 'ordinary + tallies'),
    ('ordinary-cartouche-tallies-halo-red', 'tallies + red halo'),
]
keys = sorted({p.name.split('--', 1)[0] for p in out.glob('*--ordinary-cartouche.png')})
if not keys:
    raise SystemExit(f'no cartouche audit PNGs found in {out}')
font = ImageFont.load_default()
for key in keys:
    ims=[]
    for suffix,label in variants:
        p=out/f'{key}--{suffix}.png'
        if not p.is_file():
            raise SystemExit(f'missing {p}')
        im=Image.open(p).convert('RGBA')
        ims.append((im,label))
    cell_w=max(im.width for im,_ in ims)+24
    cell_h=max(im.height for im,_ in ims)+46
    sheet=Image.new('RGBA',(cell_w*2,cell_h*2),'white')
    draw=ImageDraw.Draw(sheet)
    for i,(im,label) in enumerate(ims):
        col=i%2; row=i//2
        x=col*cell_w+(cell_w-im.width)//2
        y=row*cell_h+10
        sheet.alpha_composite(im,(x,y))
        bbox=draw.textbbox((0,0),label,font=font)
        tx=col*cell_w+(cell_w-(bbox[2]-bbox[0]))//2
        ty=row*cell_h+cell_h-24
        draw.text((tx,ty),label,fill='black',font=font)
    sheet.convert('RGB').save(out/f'{key}--ordinary-cartouche-contact.png')
print(f'cartouche contacts: {len(keys)}/{len(keys)} PASS')
