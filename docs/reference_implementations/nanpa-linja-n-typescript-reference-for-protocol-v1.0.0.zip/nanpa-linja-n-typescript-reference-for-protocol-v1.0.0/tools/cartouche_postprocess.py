#!/usr/bin/env python3
from __future__ import annotations
import json, math, sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter, ImageFont

if len(sys.argv) < 4:
    raise SystemExit('usage: cartouche_postprocess.py <cases.json> <raw-dir> <output-dir>')
cases = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
raw = Path(sys.argv[2]); out = Path(sys.argv[3]); out.mkdir(parents=True, exist_ok=True)
FONT_PX=56
HALO_RADIUS=max(1,round(max(8,FONT_PX)*0.10/2))
HALO=(217,30,24,255)

def alpha_bbox(im: Image.Image):
    return im.getchannel('A').getbbox()

def bottom_rule_y(im: Image.Image) -> int:
    a=im.getchannel('A'); b=a.getbbox()
    if not b: return max(0, im.height-1)
    x0,y0,x1,y1=b; span=max(1,x1-x0); threshold=max(4,round(span*0.18)); start=max(0,(y0+y1)//2)
    pix=a.load()
    for y in range(min(im.height-1,y1-1), start-1, -1):
        if sum(1 for x in range(x0,x1) if pix[x,y] > 8) >= threshold:
            return y+1
    return y1

def manual_tallies(im: Image.Image, prefix: Image.Image | None, count: int, key: str) -> Image.Image:
    if count <= 0: return im
    h=max(1,round(FONT_PX*0.10)); stroke=max(2,round(FONT_PX*0.045)); gap=FONT_PX*0.075
    lift=1 if key=='linjaPona' else 0
    ytop=bottom_rule_y(im)-lift; ybottom=ytop+h
    extra=max(0,ybottom-im.height)+2
    dst=Image.new('RGBA',(im.width,im.height+extra),(0,0,0,0)); dst.alpha_composite(im)
    b=alpha_bbox(im) or (0,0,im.width,im.height); x0,_,x1,_=b
    # The audit phrase is [jan pona]; use a prefix render when available to place
    # the tally group under the second glyph. Fall back to the second-cell center.
    if prefix is not None and alpha_bbox(prefix):
        pb=alpha_bbox(prefix); pw=max(1,pb[2]-pb[0]); fw=max(1,x1-x0)
        delta=max(stroke*2, fw-pw)
        center=x0 + min(fw*0.78, max(fw*0.58, pw + delta*0.42))
    else:
        center=x0 + (x1-x0)*0.68
    total=stroke if count<=1 else count*stroke+(count-1)*gap
    first=center-total/2+stroke/2
    d=ImageDraw.Draw(dst)
    for i in range(count):
        x=round(first+i*(stroke+gap))
        d.line((x,ytop,x,ybottom),fill=(0,0,0,255),width=stroke)
    return dst

def add_halo(im: Image.Image) -> Image.Image:
    r=HALO_RADIUS
    expanded=Image.new('RGBA',(im.width+2*r,im.height+2*r),(0,0,0,0)); expanded.alpha_composite(im,(r,r))
    a=expanded.getchannel('A')
    size=2*r+1
    dilated=a.filter(ImageFilter.MaxFilter(size=size))
    halo=Image.new('RGBA',expanded.size,HALO); halo.putalpha(dilated)
    halo.alpha_composite(expanded)
    return halo

def white(im: Image.Image) -> Image.Image:
    bg=Image.new('RGBA',im.size,(255,255,255,255)); bg.alpha_composite(im); return bg.convert('RGB')

def label_font(size=16,bold=False):
    names=['/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf']
    for n in names:
        try:return ImageFont.truetype(n,size)
        except Exception:pass
    return ImageFont.load_default()

def contact(key, variants):
    gap=24; pad=24; title_h=38; label_h=25
    cellw=max(i.width for _,i in variants); cellh=max(i.height for _,i in variants)
    w=pad*2+cellw*2+gap; h=pad*2+title_h+2*(label_h+cellh)+gap
    sh=Image.new('RGB',(w,h),(255,255,255)); d=ImageDraw.Draw(sh)
    d.text((pad,pad),f'{key} ordinary cartouche audit',fill=(0,0,0),font=label_font(24,True))
    for idx,(lab,im) in enumerate(variants):
        col=idx%2; row=idx//2; x=pad+col*(cellw+gap); y=pad+title_h+row*(label_h+cellh+gap)
        d.text((x,y),lab,fill=(0,0,0),font=label_font(16))
        wi=white(im); sh.paste(wi,(x+(cellw-wi.width)//2,y+label_h+(cellh-wi.height)//2))
    return sh

written=0
for key,case in cases.items():
    ordinary_path=raw/f'{key}--ordinary.raw.png'
    tallies_path=raw/f'{key}--tallies.raw.png'
    prefix_path=raw/f'{key}--prefix.raw.png'
    if not ordinary_path.exists() or not tallies_path.exists():
        raise SystemExit(f'missing raw ordinary audit PNG(s) for {key}: {ordinary_path} / {tallies_path}')
    ordinary=Image.open(ordinary_path).convert('RGBA')
    tallies=Image.open(tallies_path).convert('RGBA')
    prefix=Image.open(prefix_path).convert('RGBA') if prefix_path.exists() else None
    mt=case.get('manualTallies') or []
    count=max(mt) if mt else 0
    if count:
        tallies=manual_tallies(tallies,prefix,count,key)
    ordinary_h=add_halo(ordinary)
    tallies_h=add_halo(tallies)
    outputs=[
      ('ordinary',ordinary,'ordinary-cartouche'),
      ('ordinary + red halo',ordinary_h,'ordinary-cartouche-halo-red'),
      ('ordinary + tallies',tallies,'ordinary-cartouche-tallies'),
      ('ordinary + tallies + red halo',tallies_h,'ordinary-cartouche-tallies-halo-red'),
    ]
    sheet=[]
    for lab,im,suffix in outputs:
        im.save(out/f'{key}--{suffix}.png'); written+=1; sheet.append((lab,im))
    contact(key,sheet).save(out/f'{key}--ordinary-cartouche-contact.png'); written+=1
print(f'ordinary cartouche audit: {written} PNG file(s) written to {out.resolve()}')
print('Manual-tally fonts keep U+F199E out of the font run; tally strokes are added by the audit post-processor. Halo color: #D91E18.')
