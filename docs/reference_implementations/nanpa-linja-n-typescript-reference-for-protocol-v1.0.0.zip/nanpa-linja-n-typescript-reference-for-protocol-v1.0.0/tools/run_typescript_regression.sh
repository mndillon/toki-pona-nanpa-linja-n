#!/usr/bin/env bash
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if ! command -v node >/dev/null 2>&1; then
  echo "ERROR: Node.js is required." >&2
  exit 2
fi
if ! command -v npm >/dev/null 2>&1; then
  echo "ERROR: npm is required." >&2
  exit 2
fi

NODE_MAJOR="$(node -p "Number(process.versions.node.split('.')[0])")"
if [ "$NODE_MAJOR" -lt 18 ]; then
  echo "ERROR: Node.js 18 or newer is required; found $(node --version)." >&2
  exit 2
fi

if [ ! -x node_modules/.bin/tsc ] && ! command -v tsc >/dev/null 2>&1; then
  echo "TypeScript dependency is not installed; running npm install from the pinned package-lock.json..."
  if ! npm install; then
    echo "ERROR: npm install failed; regression suites were not started." >&2
    exit 2
  fi
fi

exec npm test
