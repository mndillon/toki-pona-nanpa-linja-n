#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; OUT="${1:-$ROOT/test-output}"
cd "$ROOT"
NANPA_VISUAL_PROJECT_ROOT="$ROOT" NANPA_VISUAL_OUT="$OUT" NANPA_VISUAL_MODE=numeric node "$ROOT/tools/browser_visual_export.mjs"
python3 "$ROOT/tools/finish_numeric_visuals.py" "$OUT"
echo "TypeScript numeric visual audit: 32 PNG file(s) expected in $OUT"
