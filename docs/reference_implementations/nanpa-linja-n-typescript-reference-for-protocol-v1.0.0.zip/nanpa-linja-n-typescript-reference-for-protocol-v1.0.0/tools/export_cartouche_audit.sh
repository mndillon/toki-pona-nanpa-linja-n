#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; OUT="${1:-$ROOT/test-output/cartouche-audit}"
cd "$ROOT"
NANPA_VISUAL_PROJECT_ROOT="$ROOT" NANPA_VISUAL_OUT="$OUT" NANPA_VISUAL_MODE=ordinary node "$ROOT/tools/browser_visual_export.mjs"
python3 "$ROOT/tools/make_cartouche_contacts.py" "$OUT"
echo "TypeScript ordinary-cartouche audit: 40 PNG file(s) expected in $OUT"
