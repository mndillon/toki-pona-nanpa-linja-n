import type { NanpaParserRuntime, SitelenRendererRuntime } from "./types.js";

// @ts-expect-error The renderer is the bundled canonical JavaScript reference.
import * as runtime from "../runtime/reference/renderer-fontuploads-renderer-preview-bottom-detect-final-fixed-yearless-datetime.js";

export const NanpaParser = runtime.NanpaParser as NanpaParserRuntime;
export const SitelenRenderer = runtime.SitelenRenderer as SitelenRendererRuntime;
export default SitelenRenderer;
