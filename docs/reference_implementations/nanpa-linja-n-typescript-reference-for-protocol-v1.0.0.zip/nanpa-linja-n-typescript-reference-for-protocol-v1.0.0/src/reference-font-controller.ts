import type { CreateSitelenFontPairController, TextFontOptionEntry } from "./types.js";

// @ts-expect-error The font controller is the bundled canonical JavaScript reference.
import * as runtime from "../runtime/reference/sitelen-font-pair-controller.js";

export const TEXT_FONT_OPTION_SITELEN = runtime.TEXT_FONT_OPTION_SITELEN as string;
export const TEXT_FONT_OPTION_NANPA_LINJA_N = runtime.TEXT_FONT_OPTION_NANPA_LINJA_N as string;
export const DEFAULT_TEXT_FONT_OPTIONS = runtime.DEFAULT_TEXT_FONT_OPTIONS as readonly TextFontOptionEntry[];
export const createSitelenFontPairController = runtime.createSitelenFontPairController as CreateSitelenFontPairController;
