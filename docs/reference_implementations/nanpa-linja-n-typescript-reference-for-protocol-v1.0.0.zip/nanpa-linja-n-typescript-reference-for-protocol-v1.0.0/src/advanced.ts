import type {
  CreateSitelenFontPairController,
  NanpaParserRuntime,
  SitelenRendererRuntime,
  SitelenVectorExporterRuntimeConstructor,
} from "./types.js";

// @ts-expect-error The advanced module is the bundled canonical JavaScript reference.
import * as runtime from "../runtime/src/advanced.js";

export const NanpaParser = runtime.NanpaParser as NanpaParserRuntime;
export const SitelenRenderer = runtime.SitelenRenderer as SitelenRendererRuntime;
export const SitelenVectorExporter = runtime.SitelenVectorExporter as SitelenVectorExporterRuntimeConstructor;
export const createSitelenFontPairController = runtime.createSitelenFontPairController as CreateSitelenFontPairController;
export const TEXT_FONT_OPTION_SITELEN = runtime.TEXT_FONT_OPTION_SITELEN as string;
export const TEXT_FONT_OPTION_NANPA_LINJA_N = runtime.TEXT_FONT_OPTION_NANPA_LINJA_N as string;
