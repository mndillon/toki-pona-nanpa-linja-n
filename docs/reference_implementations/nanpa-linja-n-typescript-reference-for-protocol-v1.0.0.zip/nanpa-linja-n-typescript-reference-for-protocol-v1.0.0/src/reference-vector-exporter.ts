import type { SitelenVectorExporterRuntimeConstructor } from "./types.js";

// @ts-expect-error The vector exporter is the bundled canonical JavaScript reference.
import * as runtime from "../runtime/reference/sitelen-vector-exporter.js";

export const SitelenVectorExporter = runtime.SitelenVectorExporter as SitelenVectorExporterRuntimeConstructor;
export default SitelenVectorExporter;
