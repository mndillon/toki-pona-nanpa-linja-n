import type {
  CreateSitelenFontPairController,
  NanpaLinjaNRuntimeConstructor,
  NanpaParserOptions,
  NanpaParserRuntime,
  ProductionFontKey,
  SitelenRendererRuntime,
  SitelenVectorExporterRuntimeConstructor,
} from "./types.js";

// The bundled JavaScript reference is intentionally the behavioural implementation.
// @ts-expect-error The reference JavaScript is bundled verbatim and deliberately has no authored .d.ts file.
import * as runtime from "../runtime/src/nanpa-linja-n.js";

export const DEFAULT_FONT_KEY = runtime.DEFAULT_FONT_KEY as ProductionFontKey;
export const DEFAULT_FONT_SIZE = runtime.DEFAULT_FONT_SIZE as number;
export const DEFAULT_MANIFEST_URL = runtime.DEFAULT_MANIFEST_URL as string;
export const DEFAULT_PARSER_CONFIG = runtime.DEFAULT_PARSER_CONFIG as Readonly<NanpaParserOptions>;
export const DEFAULT_TEXT_FONT_OPTION = runtime.DEFAULT_TEXT_FONT_OPTION as string;
export const DEFAULT_VECTOR_WASM_URL = runtime.DEFAULT_VECTOR_WASM_URL as string;

export const NanpaLinjaN = runtime.NanpaLinjaN as NanpaLinjaNRuntimeConstructor;
export const NanpaParser = runtime.NanpaParser as NanpaParserRuntime;
export const SitelenRenderer = runtime.SitelenRenderer as SitelenRendererRuntime;
export const SitelenVectorExporter = runtime.SitelenVectorExporter as SitelenVectorExporterRuntimeConstructor;
export const createSitelenFontPairController = runtime.createSitelenFontPairController as CreateSitelenFontPairController;
export const TEXT_FONT_OPTION_SITELEN = runtime.TEXT_FONT_OPTION_SITELEN as string;

export default NanpaLinjaN;
