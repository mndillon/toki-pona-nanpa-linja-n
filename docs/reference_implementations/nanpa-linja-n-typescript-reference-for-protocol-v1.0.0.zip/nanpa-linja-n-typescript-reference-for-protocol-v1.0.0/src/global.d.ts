import type { NanpaParserRuntime, SitelenRendererRuntime } from "./types.js";

declare global {
  var NanpaParser: NanpaParserRuntime | undefined;
  var SitelenRenderer: SitelenRendererRuntime | undefined;

  interface Window {
    NanpaParser?: NanpaParserRuntime;
    SitelenRenderer?: SitelenRendererRuntime;
  }
}

export {};
